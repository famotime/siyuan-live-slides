"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});function c(t){const e=(t.rawMarkdown||t.content||"").trim();if(!e)return"";if(e.includes('class="slidev-block-ref"')||e.includes('class="slidev-ref-tag"'))return`<div class="pdf-block pdf-block--ref">${e}</div>`;if(e.startsWith("#### "))return`<div class="pdf-block"><h4>${l(e.slice(5))}</h4></div>`;if(e.startsWith("### "))return`<div class="pdf-block"><h3>${l(e.slice(4))}</h3></div>`;if(e.startsWith("## "))return`<div class="pdf-block"><h2>${l(e.slice(3))}</h2></div>`;if(e.startsWith("# "))return`<div class="pdf-block"><h1>${l(e.slice(2))}</h1></div>`;if(e.startsWith("```")){const d=e.split(`
`).slice(1,-1).join(`
`)||e.slice(3,-3);return`<div class="pdf-block"><pre class="pdf-code"><code>${l(d)}</code></pre></div>`}if(e.startsWith("> "))return`<div class="pdf-block"><blockquote class="pdf-quote"><p>${n(e.slice(2))}</p></blockquote></div>`;const o=e.match(/^!\[(.*?)\]\((.*?)\)$/);if(o)return`<div class="pdf-block pdf-block--image"><img alt="${l(o[1])}" src="${o[2]}" class="pdf-image" /></div>`;if(/^[-*+]\s+/.test(e)){const i=e.replace(/^[-*+]\s+/,"");return`<div class="pdf-block pdf-list-item"><li>${n(i)}</li></div>`}if(/^\d+\.\s+/.test(e)){const i=e.replace(/^\d+\.\s+/,"");return`<div class="pdf-block pdf-list-item pdf-list-item--ordered"><li>${n(i)}</li></div>`}return`<div class="pdf-block"><p>${n(e)}</p></div>`}function n(t){let e=l(t);return e=e.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),e=e.replace(/\*(.*?)\*/g,"<em>$1</em>"),e=e.replace(/`([^`]+)`/g,"<code>$1</code>"),e}function l(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function x(t){const e=t.frontmatter.layout||"default",o=t.blocks||[];if(e==="two-cols"){const i=o.some(r=>r.slot==="right");let d=[],s=[];if(i)d=o.filter(r=>r.slot!=="right"),s=o.filter(r=>r.slot==="right");else{const r=Math.ceil(o.length/2);d=o.slice(0,r),s=o.slice(r)}const f=d.map(c).join(`
`),p=s.map(c).join(`
`);return`
      <div class="pdf-two-cols-wrapper">
        <div class="pdf-col pdf-col--left">${f}</div>
        <div class="pdf-col pdf-col--right">${p}</div>
      </div>
    `}return o.map(c).join(`
`)}function k(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function m(t,e){const o=(e==null?void 0:e.title)||"Slidev 演示讲义",i=(e==null?void 0:e.pageRatio)||"16:9",d=(e==null?void 0:e.showNotes)??!0,s=(e==null?void 0:e.showPageNumber)??!0,f=(e==null?void 0:e.theme)||"light",p=k(i),r=t.slides.map((a,g)=>{const u=a.frontmatter.layout||"default",b=x(a),h=`${g+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${u} theme-${f}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${l(o)}</span>
          ${s?`<span class="pdf-page-badge">P. ${h}</span>`:""}
        </header>
        <div class="pdf-slide-body">
          ${b}
        </div>
        ${d&&a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${l(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${l(o)} - 高保真讲义</title>
  <style>
    @page {
      ${p}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image {
      max-width: 100%;
      max-height: 48vh;
      object-fit: contain;
      border-radius: 6px;
    }
    .pdf-two-cols-wrapper {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 36px;
      width: 100%;
      height: 100%;
      align-items: start;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-block--ref {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 12px;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
  </style>
</head>
<body>
  ${r}
</body>
</html>`}function v(t,e){if(typeof window>"u")return!1;const o=m(t,e),i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}exports.buildPrintableHtml=m;exports.convertBlockToPrintHtml=c;exports.triggerPdfExport=v;
