"use strict";var vd=Object.defineProperty;var kd=(e,t,o)=>t in e?vd(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var Ie=(e,t,o)=>kd(e,typeof t!="symbol"?t+"":t,o);const re=require("siyuan");async function It(e,t){const o=await re.fetchSyncPost(e,t);return o.code===0?o.data:null}async function wd(){return It("/api/notebook/lsNotebooks","")}async function xd(e,t,o){return It("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Pl(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return It("/api/asset/upload",o)}async function Go(e,t,o,i,n){return It("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function $s(e,t,o){return It("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function Ts(e,t,o){return It("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Js(e){return It("/api/block/deleteBlock",{id:e})}async function Mr(e){return It("/api/transactions",{reqId:Date.now(),transactions:e})}async function Sd(e){return It("/api/block/getBlockKramdown",{id:e})}async function Si(e){return It("/api/block/getChildBlocks",{id:e})}async function Cd(e){return It("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return It("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Xs(e){return It("/api/attr/getBlockAttrs",{id:e})}async function vi(e){return It("/api/query/sql",{stmt:e})}async function _d(e,t="GET",o={},i=[],n=15e3,s="application/json"){return await It("/api/network/forwardProxy",{url:e,method:t,timeout:n,contentType:s,headers:i,payload:o})}async function Id(){return It("/api/storage/getInlineStyles","")}function Er(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Rl(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],l=n[2]??n[3]??n[4]??"";t[s]=l}return t}const zl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function $d(e){const t=[];if(!e)return t;const o=new RegExp(zl.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function Td(e,t){if(!e)return"";const o=new RegExp(zl.source,"g");return e.replace(o,(i,n,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Vi="custom-slides-theme",Ki="custom-slides-aspect-ratio",Gi="custom-slides-default-transition",Hl="custom-slides-color-schema",As="custom-slides-spacing",$n="custom-slides-background",Br="custom-slides-show-unordered-list-markers",Dr="custom-slides-show-ordered-list-markers",ho="custom-slides-slide",be="custom-slides-layout",Ct="custom-slides-transition",ct="custom-slides-background",Wt="custom-slides-image",ss="custom-slides-notes",ai="custom-slides-class",Ni="custom-slides-spacing",yt="custom-slides-layout-ratio",ci="custom-slides-mask",Zo="custom-slides-mask-ratio",di="custom-slides-mask-style",ui="custom-slides-mask-initial",Oe="custom-slides-click",Et="custom-slides-motion",ei="custom-slides-shiki-lines",Te="custom-slides-slot",qe="custom-slides-note",Ye="custom-slides-role",Yi="custom-slides-max-height",Ko="custom-slides-autoplay",Tn="custom-slides-loop",li="custom-slides-muted",An="custom-slides-controls",Fl="background",Mn="image-left",En="image-right";function fi(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Ad(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(m=>parseFloat(m.trim())).filter(m=>!isNaN(m)&&m>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const m=Math.min(100,Math.max(1,s[0]));return m===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(m*100)/100,100]}}const l=s.every((m,d)=>d===0||m>s[d-1]),r=s[s.length-1];if(l&&(r===100||s.some(m=>m>10))){const m=s.map(d=>Math.min(100,Math.round(d*100)/100));return m[m.length-1]<100&&m.push(100),{steps:m.length,breakpoints:m}}const c=s.reduce((m,d)=>m+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const h=[];for(let m=0;m<s.length;m++)u+=s[m],m===s.length-1?h.push(100):h.push(Math.round(u/c*1e4)/100);return{steps:h.length,breakpoints:h}}function jl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ul(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Lt(e,t){if(!jl(e))return e;const o=Ul(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function Md(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const l=Lt(s,t);return`![${n}](${l})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,l)=>{const r=Lt(s,t);return`${n}${r}${l}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,l)=>{const r=Lt(s,t);return`${n}${r}${l}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Qs(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Ze={},hi=[],no=()=>{},Wl=()=>!1,jn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Un=e=>e.startsWith("onUpdate:"),vt=Object.assign,er=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},Ed=Object.prototype.hasOwnProperty,je=(e,t)=>Ed.call(e,t),Me=Array.isArray,pi=e=>on(e)==="[object Map]",Ci=e=>on(e)==="[object Set]",Lr=e=>on(e)==="[object Date]",De=e=>typeof e=="function",nt=e=>typeof e=="string",Kt=e=>typeof e=="symbol",Ve=e=>e!==null&&typeof e=="object",ql=e=>(Ve(e)||De(e))&&De(e.then)&&De(e.catch),Vl=Object.prototype.toString,on=e=>Vl.call(e),Bd=e=>on(e).slice(8,-1),Kl=e=>on(e)==="[object Object]",tr=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Pi=Qs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Wn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},Dd=/-\w/g,Bt=Wn(e=>e.replace(Dd,t=>t.slice(1).toUpperCase())),Ld=/\B([A-Z])/g,jo=Wn(e=>e.replace(Ld,"-$1").toLowerCase()),qn=Wn(e=>e.charAt(0).toUpperCase()+e.slice(1)),rs=Wn(e=>e?`on${qn(e)}`:""),eo=(e,t)=>!Object.is(e,t),yn=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Gl=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},Vn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Or;const Kn=()=>Or||(Or=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function to(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=nt(i)?Rd(i):to(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(nt(e)||Ve(e))return e}const Od=/;(?![^(]*\))/g,Nd=/:([^]+)/,Pd=/\/\*[^]*?\*\//g;function Rd(e){const t={};return e.replace(Pd,"").split(Od).forEach(o=>{if(o){const i=o.split(Nd);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(nt(e))t=e;else if(Me(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(Ve(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const zd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Hd=Qs(zd);function Yl(e){return!!e||e===""}function Fd(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=_i(e[i],t[i]);return o}function _i(e,t){if(e===t)return!0;let o=Lr(e),i=Lr(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Kt(e),i=Kt(t),o||i)return e===t;if(o=Me(e),i=Me(t),o||i)return o&&i?Fd(e,t):!1;if(o=Ve(e),i=Ve(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!_i(e[l],t[l]))return!1}}return String(e)===String(t)}function or(e,t){return e.findIndex(o=>_i(o,t))}const Zl=e=>!!(e&&e.__v_isRef===!0),ve=e=>nt(e)?e:e==null?"":Me(e)||Ve(e)&&(e.toString===Vl||!De(e.toString))?Zl(e)?ve(e.value):JSON.stringify(e,Jl,2):String(e),Jl=(e,t)=>Zl(t)?Jl(e,t.value):pi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[ls(i,s)+" =>"]=n,o),{})}:Ci(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>ls(o))}:Kt(t)?ls(t):Ve(t)&&!Me(t)&&!Kl(t)?String(t):t,ls=(e,t="")=>{var o;return Kt(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let gt;class jd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&gt&&(gt.active?(this.parent=gt,this.index=(gt.scopes||(gt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=gt;try{return gt=this,t()}finally{gt=o}}}on(){++this._on===1&&(this.prevScope=gt,gt=this)}off(){if(this._on>0&&--this._on===0){if(gt===this)gt=this.prevScope;else{let t=gt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Ud(){return gt}let Xe;const as=new WeakSet;class Xl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,gt&&(gt.active?gt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,as.has(this)&&(as.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||ea(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Nr(this),ta(this);const t=Xe,o=qt;Xe=this,qt=!0;try{return this.fn()}finally{oa(this),Xe=t,qt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)sr(t);this.deps=this.depsTail=void 0,Nr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?as.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Ms(this)&&this.run()}get dirty(){return Ms(this)}}let Ql=0,Ri,zi;function ea(e,t=!1){if(e.flags|=8,t){e.next=zi,zi=e;return}e.next=Ri,Ri=e}function ir(){Ql++}function nr(){if(--Ql>0)return;if(zi){let t=zi;for(zi=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;Ri;){let t=Ri;for(Ri=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function ta(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function oa(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),sr(i),Wd(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function Ms(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(ia(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function ia(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Zi)||(e.globalVersion=Zi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!Ms(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=qt;Xe=e,qt=!0;try{ta(e);const n=e.fn(e._value);(t.version===0||eo(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,qt=i,oa(e),e.flags&=-3}}function sr(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)sr(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Wd(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let qt=!0;const na=[];function wo(){na.push(qt),qt=!1}function xo(){const e=na.pop();qt=e===void 0?!0:e}function Nr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let Zi=0;class qd{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class rr{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!qt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new qd(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,sa(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,Zi++,this.notify(t)}notify(t){ir();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{nr()}}}function sa(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)sa(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const Es=new WeakMap,Jo=Symbol(""),Bs=Symbol(""),Ji=Symbol("");function xt(e,t,o){if(qt&&Xe){let i=Es.get(e);i||Es.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new rr),n.map=i,n.key=o),n.track()}}function po(e,t,o,i,n,s){const l=Es.get(e);if(!l){Zi++;return}const r=a=>{a&&a.trigger()};if(ir(),t==="clear")l.forEach(r);else{const a=Me(e),c=a&&tr(o);if(a&&o==="length"){const u=Number(i);l.forEach((h,m)=>{(m==="length"||m===Ji||!Kt(m)&&m>=u)&&r(h)})}else switch((o!==void 0||l.has(void 0))&&r(l.get(o)),c&&r(l.get(Ji)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Jo)),pi(e)&&r(l.get(Bs)));break;case"delete":a||(r(l.get(Jo)),pi(e)&&r(l.get(Bs)));break;case"set":pi(e)&&r(l.get(Jo));break}}nr()}function ii(e){const t=Fe(e);return t===e?t:(xt(t,"iterate",Ji),jt(e)?t:t.map(Gt))}function Gn(e){return xt(e=Fe(e),"iterate",Ji),e}function Xt(e,t){return So(e)?ki(Xo(e)?Gt(t):t):Gt(t)}const Vd={__proto__:null,[Symbol.iterator](){return cs(this,Symbol.iterator,e=>Xt(this,e))},concat(...e){return ii(this).concat(...e.map(t=>Me(t)?ii(t):t))},entries(){return cs(this,"entries",e=>(e[1]=Xt(this,e[1]),e))},every(e,t){return co(this,"every",e,t,void 0,arguments)},filter(e,t){return co(this,"filter",e,t,o=>o.map(i=>Xt(this,i)),arguments)},find(e,t){return co(this,"find",e,t,o=>Xt(this,o),arguments)},findIndex(e,t){return co(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return co(this,"findLast",e,t,o=>Xt(this,o),arguments)},findLastIndex(e,t){return co(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return co(this,"forEach",e,t,void 0,arguments)},includes(...e){return ds(this,"includes",e)},indexOf(...e){return ds(this,"indexOf",e)},join(e){return ii(this).join(e)},lastIndexOf(...e){return ds(this,"lastIndexOf",e)},map(e,t){return co(this,"map",e,t,void 0,arguments)},pop(){return Mi(this,"pop")},push(...e){return Mi(this,"push",e)},reduce(e,...t){return Pr(this,"reduce",e,t)},reduceRight(e,...t){return Pr(this,"reduceRight",e,t)},shift(){return Mi(this,"shift")},some(e,t){return co(this,"some",e,t,void 0,arguments)},splice(...e){return Mi(this,"splice",e)},toReversed(){return ii(this).toReversed()},toSorted(e){return ii(this).toSorted(e)},toSpliced(...e){return ii(this).toSpliced(...e)},unshift(...e){return Mi(this,"unshift",e)},values(){return cs(this,"values",e=>Xt(this,e))}};function cs(e,t,o){const i=Gn(e),n=i[t]();return i!==e&&!jt(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const Kd=Array.prototype;function co(e,t,o,i,n,s){const l=Gn(e),r=l!==e&&!jt(e),a=l[t];if(a!==Kd[t]){const h=a.apply(e,s);return r?Gt(h):h}let c=o;l!==e&&(r?c=function(h,m){return o.call(this,Xt(e,h),m,e)}:o.length>2&&(c=function(h,m){return o.call(this,h,m,e)}));const u=a.call(l,c,i);return r&&n?n(u):u}function Pr(e,t,o,i){const n=Gn(e),s=n!==e&&!jt(e);let l=o,r=!1;n!==e&&(s?(r=i.length===0,l=function(c,u,h){return r&&(r=!1,c=Xt(e,c)),o.call(this,c,Xt(e,u),h,e)}):o.length>3&&(l=function(c,u,h){return o.call(this,c,u,h,e)}));const a=n[t](l,...i);return r?Xt(e,a):a}function ds(e,t,o){const i=Fe(e);xt(i,"iterate",Ji);const n=i[t](...o);return(n===-1||n===!1)&&cr(o[0])?(o[0]=Fe(o[0]),i[t](...o)):n}function Mi(e,t,o=[]){wo(),ir();const i=Fe(e)[t].apply(e,o);return nr(),xo(),i}const Gd=Qs("__proto__,__v_isRef,__isVue"),ra=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Kt));function Yd(e){Kt(e)||(e=String(e));const t=Fe(this);return xt(t,"has",e),t.hasOwnProperty(e)}class la{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?su:ua:s?da:ca).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const l=Me(t);if(!n){let a;if(l&&(a=Vd[o]))return a;if(o==="hasOwnProperty")return Yd}const r=Reflect.get(t,o,ot(t)?t:i);if((Kt(o)?ra.has(o):Gd(o))||(n||xt(t,"get",o),s))return r;if(ot(r)){const a=l&&tr(o)?r:r.value;return n&&Ve(a)?Ls(a):a}return Ve(r)?n?Ls(r):Yn(r):r}}class aa extends la{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const l=Me(t)&&tr(o);if(!this._isShallow){const c=So(s);if(!jt(i)&&!So(i)&&(s=Fe(s),i=Fe(i)),!l&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=l?Number(o)<t.length:je(t,o),a=Reflect.set(t,o,i,ot(t)?t:n);return t===Fe(n)&&a&&(r?eo(i,s)&&po(t,"set",o,i):po(t,"add",o,i)),a}deleteProperty(t,o){const i=je(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&po(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Kt(o)||!ra.has(o))&&xt(t,"has",o),i}ownKeys(t){return xt(t,"iterate",Me(t)?"length":Jo),Reflect.ownKeys(t)}}class Zd extends la{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const Jd=new aa,Xd=new Zd,Qd=new aa(!0);const Ds=e=>e,dn=e=>Reflect.getPrototypeOf(e);function eu(e,t,o){return function(...i){const n=this.__v_raw,s=Fe(n),l=pi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=n[e](...i),u=o?Ds:t?ki:Gt;return!t&&xt(s,"iterate",a?Bs:Jo),vt(Object.create(c),{next(){const{value:h,done:m}=c.next();return m?{value:h,done:m}:{value:r?[u(h[0]),u(h[1])]:u(h),done:m}}})}}function un(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function tu(e,t){const o={get(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);e||(eo(n,r)&&xt(l,"get",n),xt(l,"get",r));const{has:a}=dn(l),c=t?Ds:e?ki:Gt;if(a.call(l,n))return c(s.get(n));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(n)},get size(){const n=this.__v_raw;return!e&&xt(Fe(n),"iterate",Jo),n.size},has(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);return e||(eo(n,r)&&xt(l,"has",n),xt(l,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const l=this,r=l.__v_raw,a=Fe(r),c=t?Ds:e?ki:Gt;return!e&&xt(a,"iterate",Jo),r.forEach((u,h)=>n.call(s,c(u),c(h),l))}};return vt(o,e?{add:un("add"),set:un("set"),delete:un("delete"),clear:un("clear")}:{add(n){const s=Fe(this),l=dn(s),r=Fe(n),a=!t&&!jt(n)&&!So(n)?r:n;return l.has.call(s,a)||eo(n,a)&&l.has.call(s,n)||eo(r,a)&&l.has.call(s,r)||(s.add(a),po(s,"add",a,a)),this},set(n,s){!t&&!jt(s)&&!So(s)&&(s=Fe(s));const l=Fe(this),{has:r,get:a}=dn(l);let c=r.call(l,n);c||(n=Fe(n),c=r.call(l,n));const u=a.call(l,n);return l.set(n,s),c?eo(s,u)&&po(l,"set",n,s):po(l,"add",n,s),this},delete(n){const s=Fe(this),{has:l,get:r}=dn(s);let a=l.call(s,n);a||(n=Fe(n),a=l.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return a&&po(s,"delete",n,void 0),c},clear(){const n=Fe(this),s=n.size!==0,l=n.clear();return s&&po(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=eu(n,e,t)}),o}function lr(e,t){const o=tu(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(je(o,n)&&n in i?o:i,n,s)}const ou={get:lr(!1,!1)},iu={get:lr(!1,!0)},nu={get:lr(!0,!1)};const ca=new WeakMap,da=new WeakMap,ua=new WeakMap,su=new WeakMap;function ru(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Yn(e){return So(e)?e:ar(e,!1,Jd,ou,ca)}function lu(e){return ar(e,!1,Qd,iu,da)}function Ls(e){return ar(e,!0,Xd,nu,ua)}function ar(e,t,o,i,n){if(!Ve(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const l=ru(Bd(e));if(l===0)return e;const r=new Proxy(e,l===2?i:o);return n.set(e,r),r}function Xo(e){return So(e)?Xo(e.__v_raw):!!(e&&e.__v_isReactive)}function So(e){return!!(e&&e.__v_isReadonly)}function jt(e){return!!(e&&e.__v_isShallow)}function cr(e){return e?!!e.__v_raw:!1}function Fe(e){const t=e&&e.__v_raw;return t?Fe(t):e}function au(e){return!je(e,"__v_skip")&&Object.isExtensible(e)&&Gl(e,"__v_skip",!0),e}const Gt=e=>Ve(e)?Yn(e):e,ki=e=>Ve(e)?Ls(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function pe(e){return cu(e,!1)}function cu(e,t){return ot(e)?e:new du(e,t)}class du{constructor(t,o){this.dep=new rr,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:Fe(t),this._value=o?t:Gt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||jt(t)||So(t);t=i?t:Fe(t),eo(t,o)&&(this._rawValue=t,this._value=i?t:Gt(t),this.dep.trigger())}}function ue(e){return ot(e)?e.value:e}const uu={get:(e,t,o)=>t==="__v_raw"?e:ue(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function fa(e){return Xo(e)?e:new Proxy(e,uu)}class fu{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new rr(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Zi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return ea(this,!0),!0}get value(){const t=this.dep.track();return ia(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function hu(e,t,o=!1){let i,n;return De(e)?i=e:(i=e.get,n=e.set),new fu(i,n,o)}const fn={},Bn=new WeakMap;let Vo;function pu(e,t=!1,o=Vo){if(o){let i=Bn.get(o);i||Bn.set(o,i=[]),i.push(e)}}function mu(e,t,o=Ze){const{immediate:i,deep:n,once:s,scheduler:l,augmentJob:r,call:a}=o,c=v=>n?v:jt(v)||n===!1||n===0?mo(v,1):mo(v);let u,h,m,d,b=!1,g=!1;if(ot(e)?(h=()=>e.value,b=jt(e)):Xo(e)?(h=()=>c(e),b=!0):Me(e)?(g=!0,b=e.some(v=>Xo(v)||jt(v)),h=()=>e.map(v=>{if(ot(v))return v.value;if(Xo(v))return c(v);if(De(v))return a?a(v,2):v()})):De(e)?t?h=a?()=>a(e,2):e:h=()=>{if(m){wo();try{m()}finally{xo()}}const v=Vo;Vo=u;try{return a?a(e,3,[d]):e(d)}finally{Vo=v}}:h=no,t&&n){const v=h,_=n===!0?1/0:n;h=()=>mo(v(),_)}const p=Ud(),y=()=>{u.stop(),p&&p.active&&er(p.effects,u)};if(s&&t){const v=t;t=(..._)=>{const A=v(..._);return y(),A}}let x=g?new Array(e.length).fill(fn):fn;const k=v=>{if(!(!(u.flags&1)||!u.dirty&&!v))if(t){const _=u.run();if(v||n||b||(g?_.some((A,T)=>eo(A,x[T])):eo(_,x))){m&&m();const A=Vo;Vo=u;try{const T=[_,x===fn?void 0:g&&x[0]===fn?[]:x,d];x=_,a?a(t,3,T):t(...T)}finally{Vo=A}}}else u.run()};return r&&r(k),u=new Xl(h),u.scheduler=l?()=>l(k,!1):k,d=v=>pu(v,!1,u),m=u.onStop=()=>{const v=Bn.get(u);if(v){if(a)a(v,4);else for(const _ of v)_();Bn.delete(u)}},t?i?k(!0):x=u.run():l?l(k.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function mo(e,t=1/0,o){if(t<=0||!Ve(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))mo(e.value,t,o);else if(Me(e))for(let i=0;i<e.length;i++)mo(e[i],t,o);else if(Ci(e)||pi(e))e.forEach(i=>{mo(i,t,o)});else if(Kl(e)){for(const i in e)mo(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&mo(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function nn(e,t,o,i){try{return i?e(...i):e()}catch(n){Zn(n,t,o)}}function Yt(e,t,o,i){if(De(e)){const n=nn(e,t,o,i);return n&&ql(n)&&n.catch(s=>{Zn(s,t,o)}),n}if(Me(e)){const n=[];for(let s=0;s<e.length;s++)n.push(Yt(e[s],t,o,i));return n}}function Zn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ze;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let h=0;h<u.length;h++)if(u[h](e,a,c)===!1)return}r=r.parent}if(s){wo(),nn(s,null,10,[e,a,c]),xo();return}}gu(e,o,n,i,l)}function gu(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const At=[];let Jt=-1;const mi=[];let Eo=null,si=0;const ha=Promise.resolve();let Dn=null;function Ln(e){const t=Dn||ha;return e?t.then(this?e.bind(this):e):t}function yu(e){let t=Jt+1,o=At.length;for(;t<o;){const i=t+o>>>1,n=At[i],s=Xi(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function dr(e){if(!(e.flags&1)){const t=Xi(e),o=At[At.length-1];!o||!(e.flags&2)&&t>=Xi(o)?At.push(e):At.splice(yu(t),0,e),e.flags|=1,pa()}}function pa(){Dn||(Dn=ha.then(ga))}function bu(e){Me(e)?mi.push(...e):Eo&&e.id===-1?Eo.splice(si+1,0,e):e.flags&1||(mi.push(e),e.flags|=1),pa()}function Rr(e,t,o=Jt+1){for(;o<At.length;o++){const i=At[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;At.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function ma(e){if(mi.length){const t=[...new Set(mi)].sort((o,i)=>Xi(o)-Xi(i));if(mi.length=0,Eo){Eo.push(...t);return}for(Eo=t,si=0;si<Eo.length;si++){const o=Eo[si];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}Eo=null,si=0}}const Xi=e=>e.id==null?e.flags&2?-1:1/0:e.id;function ga(e){try{for(Jt=0;Jt<At.length;Jt++){const t=At[Jt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),nn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Jt<At.length;Jt++){const t=At[Jt];t&&(t.flags&=-2)}Jt=-1,At.length=0,ma(),Dn=null,(At.length||mi.length)&&ga()}}let bt=null,ya=null;function On(e){const t=bt;return bt=e,ya=e&&e.type.__scopeId||null,t}function ba(e,t=bt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&Zr(-1);const s=On(t),l=bo.length;let r;try{r=e(...n)}finally{for(let a=bo.length;a>l;a--)mr();On(s),i._d&&Zr(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Ut(e,t){if(bt===null)return e;const o=es(bt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,l,r,a=Ze]=t[n];s&&(De(s)&&(s={mounted:s,updated:s}),s.deep&&mo(l),i.push({dir:s,instance:o,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Uo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let l=0;l<n.length;l++){const r=n[l];s&&(r.oldValue=s[l].value);let a=r.dir[i];a&&(wo(),Yt(a,o,8,[e.el,r,e,t]),xo())}}function vu(e,t){if(_t){let o=_t.provides;const i=_t.parent&&_t.parent.provides;i===o&&(o=_t.provides=Object.create(i)),o[e]=t}}function Vt(e,t,o=!1){const i=bf();if(i||yi){let n=yi?yi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&De(t)?t.call(i&&i.proxy):t}}const ku=Symbol.for("v-scx"),wu=()=>Vt(ku);function Ro(e,t,o){return va(e,t,o)}function va(e,t,o=Ze){const{immediate:i,deep:n,flush:s,once:l}=o,r=vt({},o),a=t&&i||!t&&s!=="post";let c;if(en){if(s==="sync"){const d=wu();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=no,d.resume=no,d.pause=no,d}}const u=_t;r.call=(d,b,g)=>Yt(d,u,b,g);let h=!1;s==="post"?r.scheduler=d=>{Dt(d,u&&u.suspense)}:s!=="sync"&&(h=!0,r.scheduler=(d,b)=>{b?d():dr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),h&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const m=mu(e,t,r);return en&&(c?c.push(m):a&&m()),m}function xu(e,t,o){const i=this.proxy,n=nt(e)?e.includes(".")?ka(i,e):()=>i[e]:e.bind(i,i);let s;De(t)?s=t:(s=t.handler,o=t);const l=rn(this),r=va(n,s.bind(i),o);return l(),r}function ka(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const Su=Symbol("_vte"),Cu=e=>e.__isTeleport,us=Symbol("_leaveCb");function ur(e,t){e.shapeFlag&6&&e.component?(e.transition=t,ur(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function zt(e,t){return De(e)?vt({name:e.name},t,{setup:e}):e}function wa(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function zr(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const Nn=new WeakMap;function Hi(e,t,o,i,n=!1){if(Me(e)){e.forEach((g,p)=>Hi(g,t&&(Me(t)?t[p]:t),o,i,n));return}if(gi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Hi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?es(i.component):i.el,l=n?null:s,{i:r,r:a}=e,c=t&&t.r,u=r.refs===Ze?r.refs={}:r.refs,h=r.setupState,m=Fe(h),d=h===Ze?Wl:g=>zr(u,g)?!1:je(m,g),b=(g,p)=>!(p&&zr(u,p));if(c!=null&&c!==a){if(Hr(t),nt(c))u[c]=null,d(c)&&(h[c]=null);else if(ot(c)){const g=t;b(c,g.k)&&(c.value=null),g.k&&(u[g.k]=null)}}if(De(a))nn(a,r,12,[l,u]);else{const g=nt(a),p=ot(a);if(g||p){const y=()=>{if(e.f){const x=g?d(a)?h[a]:u[a]:b()||!e.k?a.value:u[e.k];if(n)Me(x)&&er(x,s);else if(Me(x))x.includes(s)||x.push(s);else if(g)u[a]=[s],d(a)&&(h[a]=u[a]);else{const k=[s];b(a,e.k)&&(a.value=k),e.k&&(u[e.k]=k)}}else g?(u[a]=l,d(a)&&(h[a]=l)):p&&(b(a,e.k)&&(a.value=l),e.k&&(u[e.k]=l))};if(l){const x=()=>{y(),Nn.delete(e)};x.id=-1,Nn.set(e,x),Dt(x,o)}else Hr(e),y()}}}function Hr(e){const t=Nn.get(e);t&&(t.flags|=8,Nn.delete(e))}Kn().requestIdleCallback;Kn().cancelIdleCallback;const gi=e=>!!e.type.__asyncLoader,xa=e=>e.type.__isKeepAlive;function _u(e,t){Sa(e,"a",t)}function Iu(e,t){Sa(e,"da",t)}function Sa(e,t,o=_t){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Jn(t,i,o),o){let n=o.parent;for(;n&&n.parent;)xa(n.parent.vnode)&&$u(i,t,o,n),n=n.parent}}function $u(e,t,o,i){const n=Jn(t,e,i,!0);sn(()=>{er(i[t],n)},o)}function Jn(e,t,o=_t,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...l)=>{wo();const r=rn(o),a=Yt(t,o,e,l);return r(),xo(),a});return i?n.unshift(s):n.push(s),s}}const _o=e=>(t,o=_t)=>{(!en||e==="sp")&&Jn(e,(...i)=>t(...i),o)},Tu=_o("bm"),ti=_o("m"),Au=_o("bu"),Mu=_o("u"),fr=_o("bum"),sn=_o("um"),Eu=_o("sp"),Bu=_o("rtg"),Du=_o("rtc");function Lu(e,t=_t){Jn("ec",e,t)}const Ou="components";function Nu(e,t){return Ru(Ou,e,!0,t)||e}const Pu=Symbol.for("v-ndc");function Ru(e,t,o=!0,i=!1){const n=bt||_t;if(n){const s=n.type;{const r=Sf(s,!1);if(r&&(r===t||r===Bt(t)||r===qn(Bt(t))))return s}const l=Fr(n[e]||s[e],t)||Fr(n.appContext[e],t);return!l&&i?s:l}}function Fr(e,t){return e&&(e[t]||e[Bt(t)]||e[qn(Bt(t))])}function Mt(e,t,o,i){let n;const s=o,l=Me(e);if(l||nt(e)){const r=l&&Xo(e);let a=!1,c=!1;r&&(a=!jt(e),c=So(e),e=Gn(e)),n=new Array(e.length);for(let u=0,h=e.length;u<h;u++)n[u]=t(a?c?ki(Gt(e[u])):Gt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(Ve(e))if(e[Symbol.iterator])n=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];n[a]=t(e[u],u,a,s)}}else n=[];return n}function hn(e,t,o={},i,n,s){if(bt.ce||bt.parent&&gi(bt.parent)&&bt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),io(Je,null,[se("slot",c,i&&i())],u?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=bo.length;J();let a;try{const c=l&&Ca(l(o)),u=o.key||s||c&&c.key;a=io(Je,{key:(u&&!Kt(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=bo.length;u>r;u--)mr();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Ca(e){return e.some(t=>gr(t)?!(t.type===Co||t.type===Je&&!Ca(t.children)):!0)?e:null}const Os=e=>e?Wa(e)?es(e):Os(e.parent):null,Fi=vt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Os(e.parent),$root:e=>Os(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Ia(e),$forceUpdate:e=>e.f||(e.f=()=>{dr(e.update)}),$nextTick:e=>e.n||(e.n=Ln.bind(e.proxy)),$watch:e=>xu.bind(e)}),fs=(e,t)=>e!==Ze&&!e.__isScriptSetup&&je(e,t),zu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const m=l[t];if(m!==void 0)switch(m){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(fs(i,t))return l[t]=1,i[t];if(n!==Ze&&je(n,t))return l[t]=2,n[t];if(je(s,t))return l[t]=3,s[t];if(o!==Ze&&je(o,t))return l[t]=4,o[t];Ns&&(l[t]=0)}}const c=Fi[t];let u,h;if(c)return t==="$attrs"&&xt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Ze&&je(o,t))return l[t]=4,o[t];if(h=a.config.globalProperties,je(h,t))return h[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return fs(n,t)?(n[t]=o,!0):i!==Ze&&je(i,t)?(i[t]=o,!0):je(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:l}},r){let a;return!!(o[r]||e!==Ze&&r[0]!=="$"&&je(e,r)||fs(t,r)||je(s,r)||je(i,r)||je(Fi,r)||je(n.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:je(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function jr(e){return Me(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let Ns=!0;function Hu(e){const t=Ia(e),o=e.proxy,i=e.ctx;Ns=!1,t.beforeCreate&&Ur(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:h,mounted:m,beforeUpdate:d,updated:b,activated:g,deactivated:p,beforeDestroy:y,beforeUnmount:x,destroyed:k,unmounted:v,render:_,renderTracked:A,renderTriggered:T,errorCaptured:N,serverPrefetch:F,expose:H,inheritAttrs:U,components:E,directives:D,filters:S}=t;if(c&&Fu(c,i,null),l)for(const I in l){const M=l[I];De(M)&&(i[I]=M.bind(o))}if(n){const I=n.call(o,o);Ve(I)&&(e.data=Yn(I))}if(Ns=!0,s)for(const I in s){const M=s[I],L=De(M)?M.bind(o,o):De(M.get)?M.get.bind(o,o):no,te=!De(M)&&De(M.set)?M.set.bind(o):no,V=ye({get:L,set:te});Object.defineProperty(i,I,{enumerable:!0,configurable:!0,get:()=>V.value,set:Z=>V.value=Z})}if(r)for(const I in r)_a(r[I],i,o,I);if(a){const I=De(a)?a.call(o):a;Reflect.ownKeys(I).forEach(M=>{vu(M,I[M])})}u&&Ur(u,e,"c");function j(I,M){Me(M)?M.forEach(L=>I(L.bind(o))):M&&I(M.bind(o))}if(j(Tu,h),j(ti,m),j(Au,d),j(Mu,b),j(_u,g),j(Iu,p),j(Lu,N),j(Du,A),j(Bu,T),j(fr,x),j(sn,v),j(Eu,F),Me(H))if(H.length){const I=e.exposed||(e.exposed={});H.forEach(M=>{Object.defineProperty(I,M,{get:()=>o[M],set:L=>o[M]=L,enumerable:!0})})}else e.exposed||(e.exposed={});_&&e.render===no&&(e.render=_),U!=null&&(e.inheritAttrs=U),E&&(e.components=E),D&&(e.directives=D),F&&wa(e)}function Fu(e,t,o=no){Me(e)&&(e=Ps(e));for(const i in e){const n=e[i];let s;Ve(n)?"default"in n?s=Vt(n.from||i,n.default,!0):s=Vt(n.from||i):s=Vt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[i]=s}}function Ur(e,t,o){Yt(Me(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function _a(e,t,o,i){let n=i.includes(".")?ka(o,i):()=>o[i];if(nt(e)){const s=t[e];De(s)&&Ro(n,s)}else if(De(e))Ro(n,e.bind(o));else if(Ve(e))if(Me(e))e.forEach(s=>_a(s,t,o,i));else{const s=De(e.handler)?e.handler.bind(o):t[e.handler];De(s)&&Ro(n,s,e)}}function Ia(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!n.length&&!o&&!i?a=t:(a={},n.length&&n.forEach(c=>Pn(a,c,l,!0)),Pn(a,t,l)),Ve(t)&&s.set(t,a),a}function Pn(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&Pn(e,s,o,!0),n&&n.forEach(l=>Pn(e,l,o,!0));for(const l in t)if(!(i&&l==="expose")){const r=ju[l]||o&&o[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const ju={data:Wr,props:qr,emits:qr,methods:Di,computed:Di,beforeCreate:Tt,created:Tt,beforeMount:Tt,mounted:Tt,beforeUpdate:Tt,updated:Tt,beforeDestroy:Tt,beforeUnmount:Tt,destroyed:Tt,unmounted:Tt,activated:Tt,deactivated:Tt,errorCaptured:Tt,serverPrefetch:Tt,components:Di,directives:Di,watch:Wu,provide:Wr,inject:Uu};function Wr(e,t){return t?e?function(){return vt(De(e)?e.call(this,this):e,De(t)?t.call(this,this):t)}:t:e}function Uu(e,t){return Di(Ps(e),Ps(t))}function Ps(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function Tt(e,t){return e?[...new Set([].concat(e,t))]:t}function Di(e,t){return e?vt(Object.create(null),e,t):t}function qr(e,t){return e?Me(e)&&Me(t)?[...new Set([...e,...t])]:vt(Object.create(null),jr(e),jr(t??{})):t}function Wu(e,t){if(!e)return t;if(!t)return e;const o=vt(Object.create(null),e);for(const i in t)o[i]=Tt(e[i],t[i]);return o}function $a(){return{app:null,config:{isNativeTag:Wl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let qu=0;function Vu(e,t){return function(i,n=null){De(i)||(i=vt({},i)),n!=null&&!Ve(n)&&(n=null);const s=$a(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:qu++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:_f,get config(){return s.config},set config(u){},use(u,...h){return l.has(u)||(u&&De(u.install)?(l.add(u),u.install(c,...h)):De(u)&&(l.add(u),u(c,...h))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,h){return h?(s.components[u]=h,c):s.components[u]},directive(u,h){return h?(s.directives[u]=h,c):s.directives[u]},mount(u,h,m){if(!a){const d=c._ceVNode||se(i,n);return d.appContext=s,m===!0?m="svg":m===!1&&(m=void 0),e(d,u,m),a=!0,c._container=u,u.__vue_app__=c,es(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Yt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,h){return s.provides[u]=h,c},runWithContext(u){const h=yi;yi=c;try{return u()}finally{yi=h}}};return c}}let yi=null;const Ku=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Bt(t)}Modifiers`]||e[`${jo(t)}Modifiers`];function Gu(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Ze;let n=o;const s=t.startsWith("update:"),l=s&&Ku(i,t.slice(7));l&&(l.trim&&(n=o.map(u=>nt(u)?u.trim():u)),l.number&&(n=o.map(Vn)));let r,a=i[r=rs(t)]||i[r=rs(Bt(t))];!a&&s&&(a=i[r=rs(jo(t))]),a&&Yt(a,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Yt(c,e,6,n)}}const Yu=new WeakMap;function Ta(e,t,o=!1){const i=o?Yu:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let l={},r=!1;if(!De(e)){const a=c=>{const u=Ta(c,t,!0);u&&(r=!0,vt(l,u))};!o&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(Ve(e)&&i.set(e,null),null):(Me(s)?s.forEach(a=>l[a]=null):vt(l,s),Ve(e)&&i.set(e,l),l)}function Xn(e,t){return!e||!jn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),je(e,t[0].toLowerCase()+t.slice(1))||je(e,jo(t))||je(e,t))}function Vr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:h,data:m,setupState:d,ctx:b,inheritAttrs:g}=e,p=On(e);let y,x;try{if(o.shapeFlag&4){const v=n||i,_=v;y=Qt(c.call(_,v,u,h,d,m,b)),x=r}else{const v=t;y=Qt(v.length>1?v(h,{attrs:r,slots:l,emit:a}):v(h,null)),x=t.props?r:Zu(r)}}catch(v){bo.length=0,Zn(v,e,1),y=se(Co)}let k=y;if(x&&g!==!1){const v=Object.keys(x),{shapeFlag:_}=k;v.length&&_&7&&(s&&v.some(Un)&&(x=Ju(x,s)),k=wi(k,x,!1,!0))}return o.dirs&&(k=wi(k,null,!1,!0),k.dirs=k.dirs?k.dirs.concat(o.dirs):o.dirs),o.transition&&ur(k,o.transition),y=k,On(p),y}const Zu=e=>{let t;for(const o in e)(o==="class"||o==="style"||jn(o))&&((t||(t={}))[o]=e[o]);return t},Ju=(e,t)=>{const o={};for(const i in e)(!Un(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function Xu(e,t,o){const{props:i,children:n,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&a>=0){if(a&1024)return!0;if(a&16)return i?Kr(i,l,c):!!l;if(a&8){const u=t.dynamicProps;for(let h=0;h<u.length;h++){const m=u[h];if(Aa(l,i,m)&&!Xn(c,m))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===l?!1:i?l?Kr(i,l,c):!0:!!l;return!1}function Kr(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(Aa(t,e,s)&&!Xn(o,s))return!0}return!1}function Aa(e,t,o){const i=e[o],n=t[o];return o==="style"&&Ve(i)&&Ve(n)?!_i(i,n):i!==n}function Qu({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const Ma={},Ea=()=>Object.create(Ma),Ba=e=>Object.getPrototypeOf(e)===Ma;function ef(e,t,o,i=!1){const n={},s=Ea();e.propsDefaults=Object.create(null),Da(e,t,n,s);for(const l in e.propsOptions[0])l in n||(n[l]=void 0);o?e.props=i?n:lu(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function tf(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:l}}=e,r=Fe(n),[a]=e.propsOptions;let c=!1;if((i||l>0)&&!(l&16)){if(l&8){const u=e.vnode.dynamicProps;for(let h=0;h<u.length;h++){let m=u[h];if(Xn(e.emitsOptions,m))continue;const d=t[m];if(a)if(je(s,m))d!==s[m]&&(s[m]=d,c=!0);else{const b=Bt(m);n[b]=Rs(a,r,b,d,e,!1)}else d!==s[m]&&(s[m]=d,c=!0)}}}else{Da(e,t,n,s)&&(c=!0);let u;for(const h in r)(!t||!je(t,h)&&((u=jo(h))===h||!je(t,u)))&&(a?o&&(o[h]!==void 0||o[u]!==void 0)&&(n[h]=Rs(a,r,h,void 0,e,!0)):delete n[h]);if(s!==r)for(const h in s)(!t||!je(t,h))&&(delete s[h],c=!0)}c&&po(e.attrs,"set","")}function Da(e,t,o,i){const[n,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(Pi(a))continue;const c=t[a];let u;n&&je(n,u=Bt(a))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:Xn(e.emitsOptions,a)||(!(a in i)||c!==i[a])&&(i[a]=c,l=!0)}if(s){const a=Fe(o),c=r||Ze;for(let u=0;u<s.length;u++){const h=s[u];o[h]=Rs(n,a,h,c[h],e,!je(c,h))}}return l}function Rs(e,t,o,i,n,s){const l=e[o];if(l!=null){const r=je(l,"default");if(r&&i===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&De(a)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=rn(n);i=c[o]=a.call(null,t),u()}}else i=a;n.ce&&n.ce._setProp(o,i)}l[0]&&(s&&!r?i=!1:l[1]&&(i===""||i===jo(o))&&(i=!0))}return i}const of=new WeakMap;function La(e,t,o=!1){const i=o?of:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,l={},r=[];let a=!1;if(!De(e)){const u=h=>{a=!0;const[m,d]=La(h,t,!0);vt(l,m),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!a)return Ve(e)&&i.set(e,hi),hi;if(Me(s))for(let u=0;u<s.length;u++){const h=Bt(s[u]);Gr(h)&&(l[h]=Ze)}else if(s)for(const u in s){const h=Bt(u);if(Gr(h)){const m=s[u],d=l[h]=Me(m)||De(m)?{type:m}:vt({},m),b=d.type;let g=!1,p=!0;if(Me(b))for(let y=0;y<b.length;++y){const x=b[y],k=De(x)&&x.name;if(k==="Boolean"){g=!0;break}else k==="String"&&(p=!1)}else g=De(b)&&b.name==="Boolean";d[0]=g,d[1]=p,(g||je(d,"default"))&&r.push(h)}}const c=[l,r];return Ve(e)&&i.set(e,c),c}function Gr(e){return e[0]!=="$"&&!Pi(e)}const hr=e=>e==="_"||e==="_ctx"||e==="$stable",pr=e=>Me(e)?e.map(Qt):[Qt(e)],nf=(e,t,o)=>{if(t._n)return t;const i=ba((...n)=>pr(t(...n)),o);return i._c=!1,i},Oa=(e,t,o)=>{const i=e._ctx;for(const n in e){if(hr(n))continue;const s=e[n];if(De(s))t[n]=nf(n,s,i);else if(s!=null){const l=pr(s);t[n]=()=>l}}},Na=(e,t)=>{const o=pr(t);e.slots.default=()=>o},Pa=(e,t,o)=>{for(const i in t)(o||!hr(i))&&(e[i]=t[i])},sf=(e,t,o)=>{const i=e.slots=Ea();if(e.vnode.shapeFlag&32){const n=t._;n?(Pa(i,t,o),o&&Gl(i,"_",n,!0)):Oa(t,i)}else t&&Na(e,t)},rf=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,l=Ze;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:Pa(n,t,o):(s=!t.$stable,Oa(t,n)),l=t}else t&&(Na(e,t),l={default:1});if(s)for(const r in n)!hr(r)&&l[r]==null&&delete n[r]},Dt=uf;function lf(e){return af(e)}function af(e,t){const o=Kn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:h,nextSibling:m,setScopeId:d=no,insertStaticContent:b}=e,g=(B,W,w,q=null,z=null,C=null,$=void 0,O=null,G=!!W.dynamicChildren)=>{if(B===W)return;B&&!Ei(B,W)&&(q=$e(B),Z(B,z,C,!0),B=null),W.patchFlag===-2&&(G=!1,W.dynamicChildren=null);const{type:K,ref:Y,shapeFlag:X}=W;switch(K){case Qn:p(B,W,w,q);break;case Co:y(B,W,w,q);break;case bn:B==null&&x(W,w,q,$);break;case Je:E(B,W,w,q,z,C,$,O,G);break;default:X&1?_(B,W,w,q,z,C,$,O,G):X&6?D(B,W,w,q,z,C,$,O,G):(X&64||X&128)&&K.process(B,W,w,q,z,C,$,O,G,R)}Y!=null&&z?Hi(Y,B&&B.ref,C,W||B,!W):Y==null&&B&&B.ref!=null&&Hi(B.ref,null,C,B,!0)},p=(B,W,w,q)=>{if(B==null)i(W.el=r(W.children),w,q);else{const z=W.el=B.el;W.children!==B.children&&c(z,W.children)}},y=(B,W,w,q)=>{B==null?i(W.el=a(W.children||""),w,q):W.el=B.el},x=(B,W,w,q)=>{[B.el,B.anchor]=b(B.children,W,w,q,B.el,B.anchor)},k=({el:B,anchor:W},w,q)=>{let z;for(;B&&B!==W;)z=m(B),i(B,w,q),B=z;i(W,w,q)},v=({el:B,anchor:W})=>{let w;for(;B&&B!==W;)w=m(B),n(B),B=w;n(W)},_=(B,W,w,q,z,C,$,O,G)=>{if(W.type==="svg"?$="svg":W.type==="math"&&($="mathml"),B==null)A(W,w,q,z,C,$,O,G);else{const K=B.el&&B.el._isVueCE?B.el:null;try{K&&K._beginPatch(),F(B,W,z,C,$,O,G)}finally{K&&K._endPatch()}}},A=(B,W,w,q,z,C,$,O)=>{let G,K;const{props:Y,shapeFlag:X,transition:ae,dirs:ne}=B;if(G=B.el=l(B.type,C,Y&&Y.is,Y),X&8?u(G,B.children):X&16&&N(B.children,G,null,q,z,hs(B,C),$,O),ne&&Uo(B,null,q,"created"),T(G,B,B.scopeId,$,q),Y){for(const _e in Y)_e!=="value"&&!Pi(_e)&&s(G,_e,null,Y[_e],C,q);"value"in Y&&s(G,"value",null,Y.value,C),(K=Y.onVnodeBeforeMount)&&Zt(K,q,B)}ne&&Uo(B,null,q,"beforeMount");const me=cf(z,ae);me&&ae.beforeEnter(G),i(G,W,w),((K=Y&&Y.onVnodeMounted)||me||ne)&&Dt(()=>{try{K&&Zt(K,q,B),me&&ae.enter(G),ne&&Uo(B,null,q,"mounted")}finally{}},z)},T=(B,W,w,q,z)=>{if(w&&d(B,w),q)for(let C=0;C<q.length;C++)d(B,q[C]);if(z){let C=z.subTree;if(W===C||Fa(C.type)&&(C.ssContent===W||C.ssFallback===W)){const $=z.vnode;T(B,$,$.scopeId,$.slotScopeIds,z.parent)}}},N=(B,W,w,q,z,C,$,O,G=0)=>{for(let K=G;K<B.length;K++){const Y=B[K]=O?fo(B[K]):Qt(B[K]);g(null,Y,W,w,q,z,C,$,O)}},F=(B,W,w,q,z,C,$)=>{const O=W.el=B.el;let{patchFlag:G,dynamicChildren:K,dirs:Y}=W;G|=B.patchFlag&16;const X=B.props||Ze,ae=W.props||Ze;let ne;if(w&&Wo(w,!1),(ne=ae.onVnodeBeforeUpdate)&&Zt(ne,w,W,B),Y&&Uo(W,B,w,"beforeUpdate"),w&&Wo(w,!0),K&&(!B.dynamicChildren||B.dynamicChildren.length!==K.length)&&(G=0,$=!1,K=null),(X.innerHTML&&ae.innerHTML==null||X.textContent&&ae.textContent==null)&&u(O,""),K?H(B.dynamicChildren,K,O,w,q,hs(W,z),C):$||M(B,W,O,null,w,q,hs(W,z),C,!1),G>0){if(G&16)U(O,X,ae,w,z);else if(G&2&&X.class!==ae.class&&s(O,"class",null,ae.class,z),G&4&&s(O,"style",X.style,ae.style,z),G&8){const me=W.dynamicProps;for(let _e=0;_e<me.length;_e++){const we=me[_e],Le=X[we],He=ae[we];(He!==Le||we==="value")&&s(O,we,Le,He,z,w)}}G&1&&B.children!==W.children&&u(O,W.children)}else!$&&K==null&&U(O,X,ae,w,z);((ne=ae.onVnodeUpdated)||Y)&&Dt(()=>{ne&&Zt(ne,w,W,B),Y&&Uo(W,B,w,"updated")},q)},H=(B,W,w,q,z,C,$)=>{for(let O=0;O<W.length;O++){const G=B[O],K=W[O],Y=G.el&&(G.type===Je||!Ei(G,K)||G.shapeFlag&198)?h(G.el):w;g(G,K,Y,null,q,z,C,$,!0)}},U=(B,W,w,q,z)=>{if(W!==w){if(W!==Ze)for(const C in W)!Pi(C)&&!(C in w)&&s(B,C,W[C],null,z,q);for(const C in w){if(Pi(C))continue;const $=w[C],O=W[C];$!==O&&C!=="value"&&s(B,C,O,$,z,q)}"value"in w&&s(B,"value",W.value,w.value,z)}},E=(B,W,w,q,z,C,$,O,G)=>{const K=W.el=B?B.el:r(""),Y=W.anchor=B?B.anchor:r("");let{patchFlag:X,dynamicChildren:ae,slotScopeIds:ne}=W;ne&&(O=O?O.concat(ne):ne),B==null?(i(K,w,q),i(Y,w,q),N(W.children||[],w,Y,z,C,$,O,G)):X>0&&X&64&&ae&&B.dynamicChildren&&B.dynamicChildren.length===ae.length?(H(B.dynamicChildren,ae,w,z,C,$,O),(W.key!=null||z&&W===z.subTree)&&Ra(B,W,!0)):M(B,W,w,Y,z,C,$,O,G)},D=(B,W,w,q,z,C,$,O,G)=>{W.slotScopeIds=O,B==null?W.shapeFlag&512?z.ctx.activate(W,w,q,$,G):S(W,w,q,z,C,$,G):P(B,W,G)},S=(B,W,w,q,z,C,$)=>{const O=B.component=yf(B,q,z);if(xa(B)&&(O.ctx.renderer=R),vf(O,!1,$),O.asyncDep){if(z&&z.registerDep(O,j,$),!B.el){const G=O.subTree=se(Co);y(null,G,W,w),B.placeholder=G.el}}else j(O,B,W,w,z,C,$)},P=(B,W,w)=>{const q=W.component=B.component;if(Xu(B,W,w))if(q.asyncDep&&!q.asyncResolved){I(q,W,w);return}else q.next=W,q.update();else W.el=B.el,q.vnode=W},j=(B,W,w,q,z,C,$)=>{const O=()=>{if(B.isMounted){let{next:X,bu:ae,u:ne,parent:me,vnode:_e}=B;{const rt=za(B);if(rt){X&&(X.el=_e.el,I(B,X,$)),rt.asyncDep.then(()=>{Dt(()=>{B.isUnmounted||K()},z)});return}}let we=X,Le;Wo(B,!1),X?(X.el=_e.el,I(B,X,$)):X=_e,ae&&yn(ae),(Le=X.props&&X.props.onVnodeBeforeUpdate)&&Zt(Le,me,X,_e),Wo(B,!0);const He=Vr(B),Ke=B.subTree;B.subTree=He,g(Ke,He,h(Ke.el),$e(Ke),B,z,C),X.el=He.el,we===null&&Qu(B,He.el),ne&&Dt(ne,z),(Le=X.props&&X.props.onVnodeUpdated)&&Dt(()=>Zt(Le,me,X,_e),z)}else{let X;const{el:ae,props:ne}=W,{bm:me,m:_e,parent:we,root:Le,type:He}=B,Ke=gi(W);Wo(B,!1),me&&yn(me),!Ke&&(X=ne&&ne.onVnodeBeforeMount)&&Zt(X,we,W),Wo(B,!0);{Le.ce&&Le.ce._hasShadowRoot()&&Le.ce._injectChildStyle(He,B.parent?B.parent.type:void 0);const rt=B.subTree=Vr(B);g(null,rt,w,q,B,z,C),W.el=rt.el}if(_e&&Dt(_e,z),!Ke&&(X=ne&&ne.onVnodeMounted)){const rt=W;Dt(()=>Zt(X,we,rt),z)}(W.shapeFlag&256||we&&gi(we.vnode)&&we.vnode.shapeFlag&256)&&B.a&&Dt(B.a,z),B.isMounted=!0,W=w=q=null}};B.scope.on();const G=B.effect=new Xl(O);B.scope.off();const K=B.update=G.run.bind(G),Y=B.job=G.runIfDirty.bind(G);Y.i=B,Y.id=B.uid,G.scheduler=()=>dr(Y),Wo(B,!0),K()},I=(B,W,w)=>{W.component=B;const q=B.vnode.props;B.vnode=W,B.next=null,tf(B,W.props,q,w),rf(B,W.children,w),wo(),Rr(B),xo()},M=(B,W,w,q,z,C,$,O,G=!1)=>{const K=B&&B.children,Y=B?B.shapeFlag:0,X=W.children,{patchFlag:ae,shapeFlag:ne}=W;if(ae>0){if(ae&128){te(K,X,w,q,z,C,$,O,G);return}else if(ae&256){L(K,X,w,q,z,C,$,O,G);return}}ne&8?(Y&16&&Se(K,z,C),X!==K&&u(w,X)):Y&16?ne&16?te(K,X,w,q,z,C,$,O,G):Se(K,z,C,!0):(Y&8&&u(w,""),ne&16&&N(X,w,q,z,C,$,O,G))},L=(B,W,w,q,z,C,$,O,G)=>{B=B||hi,W=W||hi;const K=B.length,Y=W.length,X=Math.min(K,Y);let ae;for(ae=0;ae<X;ae++){const ne=W[ae]=G?fo(W[ae]):Qt(W[ae]);g(B[ae],ne,w,null,z,C,$,O,G)}K>Y?Se(B,z,C,!0,!1,X):N(W,w,q,z,C,$,O,G,X)},te=(B,W,w,q,z,C,$,O,G)=>{let K=0;const Y=W.length;let X=B.length-1,ae=Y-1;for(;K<=X&&K<=ae;){const ne=B[K],me=W[K]=G?fo(W[K]):Qt(W[K]);if(Ei(ne,me))g(ne,me,w,null,z,C,$,O,G);else break;K++}for(;K<=X&&K<=ae;){const ne=B[X],me=W[ae]=G?fo(W[ae]):Qt(W[ae]);if(Ei(ne,me))g(ne,me,w,null,z,C,$,O,G);else break;X--,ae--}if(K>X){if(K<=ae){const ne=ae+1,me=ne<Y?W[ne].el:q;for(;K<=ae;)g(null,W[K]=G?fo(W[K]):Qt(W[K]),w,me,z,C,$,O,G),K++}}else if(K>ae)for(;K<=X;)Z(B[K],z,C,!0),K++;else{const ne=K,me=K,_e=new Map;for(K=me;K<=ae;K++){const tt=W[K]=G?fo(W[K]):Qt(W[K]);tt.key!=null&&_e.set(tt.key,K)}let we,Le=0;const He=ae-me+1;let Ke=!1,rt=0;const Pe=new Array(He);for(K=0;K<He;K++)Pe[K]=0;for(K=ne;K<=X;K++){const tt=B[K];if(Le>=He){Z(tt,z,C,!0);continue}let Ge;if(tt.key!=null)Ge=_e.get(tt.key);else for(we=me;we<=ae;we++)if(Pe[we-me]===0&&Ei(tt,W[we])){Ge=we;break}Ge===void 0?Z(tt,z,C,!0):(Pe[Ge-me]=K+1,Ge>=rt?rt=Ge:Ke=!0,g(tt,W[Ge],w,null,z,C,$,O,G),Le++)}const ft=Ke?df(Pe):hi;for(we=ft.length-1,K=He-1;K>=0;K--){const tt=me+K,Ge=W[tt],fe=W[tt+1],he=tt+1<Y?fe.el||Ha(fe):q;Pe[K]===0?g(null,Ge,w,he,z,C,$,O,G):Ke&&(we<0||K!==ft[we]?V(Ge,w,he,2):we--)}}},V=(B,W,w,q,z=null)=>{const{el:C,type:$,transition:O,children:G,shapeFlag:K}=B;if(K&6){V(B.component.subTree,W,w,q);return}if(K&128){B.suspense.move(W,w,q);return}if(K&64){$.move(B,W,w,R);return}if($===Je){i(C,W,w);for(let X=0;X<G.length;X++)V(G[X],W,w,q);i(B.anchor,W,w);return}if($===bn){k(B,W,w);return}if(q!==2&&K&1&&O)if(q===0)O.persisted&&!C[us]?i(C,W,w):(O.beforeEnter(C),i(C,W,w),Dt(()=>O.enter(C),z));else{const{leave:X,delayLeave:ae,afterLeave:ne}=O,me=()=>{B.ctx.isUnmounted?n(C):i(C,W,w)},_e=()=>{const we=C._isLeaving||!!C[us];C._isLeaving&&C[us](!0),O.persisted&&!we?me():X(C,()=>{me(),ne&&ne()})};ae?ae(C,me,_e):_e()}else i(C,W,w)},Z=(B,W,w,q=!1,z=!1)=>{const{type:C,props:$,ref:O,children:G,dynamicChildren:K,shapeFlag:Y,patchFlag:X,dirs:ae,cacheIndex:ne,memo:me}=B;if(X===-2&&(z=!1),O!=null&&(wo(),Hi(O,null,w,B,!0),xo()),ne!=null&&(W.renderCache[ne]=void 0),Y&256){W.ctx.deactivate(B);return}const _e=Y&1&&ae,we=!gi(B);let Le;if(we&&(Le=$&&$.onVnodeBeforeUnmount)&&Zt(Le,W,B),Y&6)le(B.component,w,q);else{if(Y&128){B.suspense.unmount(w,q);return}_e&&Uo(B,null,W,"beforeUnmount"),Y&64?B.type.remove(B,W,w,R,q):K&&!K.hasOnce&&(C!==Je||X>0&&X&64)?Se(K,W,w,!1,!0):(C===Je&&X&384||!z&&Y&16)&&Se(G,W,w),q&&ce(B)}const He=me!=null&&ne==null;(we&&(Le=$&&$.onVnodeUnmounted)||_e||He)&&Dt(()=>{Le&&Zt(Le,W,B),_e&&Uo(B,null,W,"unmounted"),He&&(B.el=null)},w)},ce=B=>{const{type:W,el:w,anchor:q,transition:z}=B;if(W===Je){oe(w,q);return}if(W===bn){v(B);return}const C=()=>{n(w),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(B.shapeFlag&1&&z&&!z.persisted){const{leave:$,delayLeave:O}=z,G=()=>$(w,C);O?O(B.el,C,G):G()}else C()},oe=(B,W)=>{let w;for(;B!==W;)w=m(B),n(B),B=w;n(W)},le=(B,W,w)=>{const{bum:q,scope:z,job:C,subTree:$,um:O,m:G,a:K}=B;Yr(G),Yr(K),q&&yn(q),z.stop(),C&&(C.flags|=8,Z($,B,W,w)),O&&Dt(O,W),Dt(()=>{B.isUnmounted=!0},W)},Se=(B,W,w,q=!1,z=!1,C=0)=>{for(let $=C;$<B.length;$++)Z(B[$],W,w,q,z)},$e=B=>{if(B.shapeFlag&6)return $e(B.component.subTree);if(B.shapeFlag&128)return B.suspense.next();const W=m(B.anchor||B.el),w=W&&W[Su];return w?m(w):W};let ke=!1;const Ce=(B,W,w)=>{let q;B==null?W._vnode&&(Z(W._vnode,null,null,!0),q=W._vnode.component):g(W._vnode||null,B,W,null,null,null,w),W._vnode=B,ke||(ke=!0,Rr(q),ma(),ke=!1)},R={p:g,um:Z,m:V,r:ce,mt:S,mc:N,pc:M,pbc:H,n:$e,o:e};return{render:Ce,hydrate:void 0,createApp:Vu(Ce)}}function hs({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function Wo({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function cf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ra(e,t,o=!1){const i=e.children,n=t.children;if(Me(i)&&Me(n))for(let s=0;s<i.length;s++){const l=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=fo(n[s]),r.el=l.el),!o&&r.patchFlag!==-2&&Ra(l,r)),r.type===Qn&&(r.patchFlag===-1&&(r=n[s]=fo(r)),r.el=l.el),r.type===Co&&!r.el&&(r.el=l.el)}}function df(e){const t=e.slice(),o=[0];let i,n,s,l,r;const a=e.length;for(i=0;i<a;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,l=o.length-1;s<l;)r=s+l>>1,e[o[r]]<c?s=r+1:l=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,l=o[s-1];s-- >0;)o[s]=l,l=t[l];return o}function za(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:za(t)}function Yr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Ha(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Ha(t.subTree):null}const Fa=e=>e.__isSuspense;function uf(e,t){t&&t.pendingBranch?Me(e)?t.effects.push(...e):t.effects.push(e):bu(e)}const Je=Symbol.for("v-fgt"),Qn=Symbol.for("v-txt"),Co=Symbol.for("v-cmt"),bn=Symbol.for("v-stc"),bo=[];let Rt=null;function J(e=!1){bo.push(Rt=e?null:[])}function mr(){bo.pop(),Rt=bo[bo.length-1]||null}let Qi=1;function Zr(e,t=!1){Qi+=e,e<0&&Rt&&t&&(Rt.hasOnce=!0)}function ja(e){return e.dynamicChildren=Qi>0?Rt||hi:null,mr(),Qi>0&&Rt&&Rt.push(e),e}function ee(e,t,o,i,n,s){return ja(f(e,t,o,i,n,s,!0))}function io(e,t,o,i,n){return ja(se(e,t,o,i,n,!0))}function gr(e){return e?e.__v_isVNode===!0:!1}function Ei(e,t){return e.type===t.type&&e.key===t.key}const Ua=({key:e})=>e??null,vn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||ot(e)||De(e)?{i:bt,r:e,k:t,f:!!o}:e:null);function f(e,t=null,o=null,i=0,n=null,s=e===Je?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Ua(t),ref:t&&vn(t),scopeId:ya,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:bt};return r?(Rn(a,o),s&128&&e.normalize(a)):o&&(a.shapeFlag|=nt(o)?8:16),Qi>0&&!l&&Rt&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Rt.push(a),a}const se=ff;function ff(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===Pu)&&(e=Co),gr(e)){const r=wi(e,t,!0);return o&&Rn(r,o),Qi>0&&!s&&Rt&&(r.shapeFlag&6?Rt[Rt.indexOf(e)]=r:Rt.push(r)),r.patchFlag=-2,r}if(Cf(e)&&(e=e.__vccOpts),t){t=hf(t);let{class:r,style:a}=t;r&&!nt(r)&&(t.class=xe(r)),Ve(a)&&(cr(a)&&!Me(a)&&(a=vt({},a)),t.style=to(a))}const l=nt(e)?1:Fa(e)?128:Cu(e)?64:Ve(e)?4:De(e)?2:0;return f(e,t,o,i,n,l,s,!0)}function hf(e){return e?cr(e)||Ba(e)?vt({},e):e:null}function wi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?pf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Ua(c),ref:t&&t.ref?o&&s?Me(s)?s.concat(vn(t)):[s,vn(t)]:vn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Je?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&wi(e.ssContent),ssFallback:e.ssFallback&&wi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&i&&ur(u,a.clone(u)),u}function St(e=" ",t=0){return se(Qn,null,e,t)}function mt(e,t){const o=se(bn,null,e);return o.staticCount=t,o}function Ae(e="",t=!1){return t?(J(),io(Co,null,e)):se(Co,null,e)}function Qt(e){return e==null||typeof e=="boolean"?se(Co):Me(e)?se(Je,null,e.slice()):gr(e)?fo(e):se(Qn,null,String(e))}function fo(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:wi(e)}function Rn(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Me(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Rn(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!Ba(t)?t._ctx=bt:n===3&&bt&&(bt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(De(t)){if(i&65){Rn(e,{default:t});return}t={default:t,_ctx:bt},o=32}else t=String(t),i&64?(o=16,t=[St(t)]):o=8;e.children=t,e.shapeFlag|=o}function pf(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=to([t.style,i.style]);else if(jn(n)){const s=t[n],l=i[n];l&&s!==l&&!(Me(s)&&s.includes(l))?t[n]=s?[].concat(s,l):l:l==null&&s==null&&!Un(n)&&(t[n]=l)}else n!==""&&(t[n]=i[n])}return t}function Zt(e,t,o,i=null){Yt(e,t,7,[o,i])}const mf=$a();let gf=0;function yf(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||mf,s={uid:gf++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new jd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:La(i,n),emitsOptions:Ta(i,n),emit:null,emitted:null,propsDefaults:Ze,inheritAttrs:i.inheritAttrs,ctx:Ze,data:Ze,props:Ze,attrs:Ze,slots:Ze,refs:Ze,setupState:Ze,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=Gu.bind(null,s),e.ce&&e.ce(s),s}let _t=null;const bf=()=>_t||bt;let zn,zs;{const e=Kn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(l=>l(s)):n[0](s)}};zn=t("__VUE_INSTANCE_SETTERS__",o=>_t=o),zs=t("__VUE_SSR_SETTERS__",o=>en=o)}const rn=e=>{const t=_t;return zn(e),e.scope.on(),()=>{e.scope.off(),zn(t)}},Jr=()=>{_t&&_t.scope.off(),zn(null)};function Wa(e){return e.vnode.shapeFlag&4}let en=!1;function vf(e,t=!1,o=!1){t&&zs(t);const{props:i,children:n}=e.vnode,s=Wa(e);ef(e,i,s,t),sf(e,n,o||t);const l=s?kf(e,t):void 0;return t&&zs(!1),l}function kf(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,zu);const{setup:i}=o;if(i){wo();const n=e.setupContext=i.length>1?xf(e):null,s=rn(e),l=nn(i,e,0,[e.props,n]),r=ql(l);if(xo(),s(),(r||e.sp)&&!gi(e)&&wa(e),r){if(l.then(Jr,Jr),t)return l.then(a=>{Xr(e,a)}).catch(a=>{Zn(a,e,0)});e.asyncDep=l}else Xr(e,l)}else qa(e)}function Xr(e,t,o){De(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ve(t)&&(e.setupState=fa(t)),qa(e)}function qa(e,t,o){const i=e.type;e.render||(e.render=i.render||no);{const n=rn(e);wo();try{Hu(e)}finally{xo(),n()}}}const wf={get(e,t){return xt(e,"get",""),e[t]}};function xf(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,wf),slots:e.slots,emit:e.emit,expose:t}}function es(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(fa(au(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in Fi)return Fi[o](e)},has(t,o){return o in t||o in Fi}})):e.proxy}function Sf(e,t=!0){return De(e)?e.displayName||e.name:e.name||t&&e.__name}function Cf(e){return De(e)&&"__vccOpts"in e}const ye=(e,t)=>hu(e,t,en),_f="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Hs;const Qr=typeof window<"u"&&window.trustedTypes;if(Qr)try{Hs=Qr.createPolicy("vue",{createHTML:e=>e})}catch{}const Va=Hs?e=>Hs.createHTML(e):e=>e,If="http://www.w3.org/2000/svg",$f="http://www.w3.org/1998/Math/MathML",uo=typeof document<"u"?document:null,el=uo&&uo.createElement("template"),Tf={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?uo.createElementNS(If,e):t==="mathml"?uo.createElementNS($f,e):o?uo.createElement(e,{is:o}):uo.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>uo.createTextNode(e),createComment:e=>uo.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>uo.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const l=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{el.innerHTML=Va(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=el.content;if(i==="svg"||i==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,o)}return[l?l.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},Af=Symbol("_vtc");function Mf(e,t,o){const i=e[Af];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const Hn=Symbol("_vod"),Ka=Symbol("_vsh"),Fs={name:"show",beforeMount(e,{value:t},{transition:o}){e[Hn]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Bi(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Bi(e,!0),i.enter(e)):i.leave(e,()=>{Bi(e,!1)}):Bi(e,t))},beforeUnmount(e,{value:t}){Bi(e,t)}};function Bi(e,t){e.style.display=t?e[Hn]:"none",e[Ka]=!t}const Ef=Symbol(""),Bf=/(?:^|;)\s*display\s*:/;function Df(e,t,o){const i=e.style,n=nt(o);let s=!1;if(o&&!n){if(t)if(nt(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();o[r]==null&&Li(i,r,"")}else for(const l in t)o[l]==null&&Li(i,l,"");for(const l in o){l==="display"&&(s=!0);const r=o[l];r!=null?Of(e,l,!nt(t)&&t?t[l]:void 0,r)||Li(i,l,r):Li(i,l,"")}}else if(n){if(t!==o){const l=i[Ef];l&&(o+=";"+l),i.cssText=o,s=Bf.test(o)}}else t&&e.removeAttribute("style");Hn in e&&(e[Hn]=s?i.display:"",e[Ka]&&(i.display="none"))}const tl=/\s*!important$/;function Li(e,t,o){if(Me(o))o.forEach(i=>Li(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=Lf(e,t);tl.test(o)?e.setProperty(jo(i),o.replace(tl,""),"important"):e[i]=o}}const ol=["Webkit","Moz","ms"],ps={};function Lf(e,t){const o=ps[t];if(o)return o;let i=Bt(t);if(i!=="filter"&&i in e)return ps[t]=i;i=qn(i);for(let n=0;n<ol.length;n++){const s=ol[n]+i;if(s in e)return ps[t]=s}return t}function Of(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(i)&&o===i}const il="http://www.w3.org/1999/xlink";function nl(e,t,o,i,n,s=Hd(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(il,t.slice(6,t.length)):e.setAttributeNS(il,t,o):o==null||s&&!Yl(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Kt(o)?String(o):o)}function sl(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Va(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=o==null?e.type==="checkbox"?"on":"":String(o);(r!==a||!("_value"in e))&&(e.value=a),o==null&&e.removeAttribute(t),e._value=o;return}let l=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=Yl(o):o==null&&r==="string"?(o="",l=!0):r==="number"&&(o=0,l=!0)}try{e[t]=o}catch{}l&&e.removeAttribute(n||t)}function Bo(e,t,o,i){e.addEventListener(t,o,i)}function Nf(e,t,o,i){e.removeEventListener(t,o,i)}const rl=Symbol("_vei");function Pf(e,t,o,i,n=null){const s=e[rl]||(e[rl]={}),l=s[t];if(i&&l)l.value=i;else{const[r,a]=Hf(t);if(i){const c=s[t]=Uf(i,n);Bo(e,r,c,a)}else l&&(Nf(e,r,l,a),s[t]=void 0)}}const Rf=/(Once|Passive|Capture)$/,zf=/^on:?(?:Once|Passive|Capture)$/;function Hf(e){let t,o;for(;(o=e.match(Rf))&&!zf.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):jo(e.slice(2)),t]}let ms=0;const Ff=Promise.resolve(),jf=()=>ms||(Ff.then(()=>ms=0),ms=Date.now());function Uf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Me(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const l=n.slice(),r=[i];for(let a=0;a<l.length&&!i._stopped;a++){const c=l[a];c&&Yt(c,t,5,r)}}else Yt(n,t,5,[i])};return o.value=e,o.attached=jf(),o}const ll=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Wf=(e,t,o,i,n,s)=>{const l=n==="svg";t==="class"?Mf(e,i,l):t==="style"?Df(e,o,i):jn(t)?Un(t)||Pf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):qf(e,t,i,l))?(sl(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&nl(e,t,i,l,s,t!=="value")):e._isVueCE&&(Vf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(i)))?sl(e,Bt(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),nl(e,t,i,l))};function qf(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&ll(t)&&De(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return ll(t)&&nt(o)?!1:t in e}function Vf(e,t){const o=e._def.props;if(!o)return!1;const i=Bt(t);return Array.isArray(o)?o.some(n=>Bt(n)===i):Object.keys(o).some(n=>Bt(n)===i)}const xi=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Me(t)?o=>yn(t,o):t};function Kf(e){e.target.composing=!0}function al(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const vo=Symbol("_assign");function cl(e,t,o){return t&&(e=e.trim()),o&&(e=Vn(e)),e}const js={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[vo]=xi(n);const s=i||n.props&&n.props.type==="number";Bo(e,t?"change":"input",l=>{l.target.composing||e[vo](cl(e.value,o,s))}),(o||s)&&Bo(e,"change",()=>{e.value=cl(e.value,o,s)}),t||(Bo(e,"compositionstart",Kf),Bo(e,"compositionend",al),Bo(e,"change",al))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},l){if(e[vo]=xi(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Vn(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===a)||(e.value=a)}},pn={deep:!0,created(e,t,o){e[vo]=xi(o),Bo(e,"change",()=>{const i=e._modelValue,n=tn(e),s=e.checked,l=e[vo];if(Me(i)){const r=or(i,n),a=r!==-1;if(s&&!a)l(i.concat(n));else if(!s&&a){const c=[...i];c.splice(r,1),l(c)}}else if(Ci(i)){const r=new Set(i);s?r.add(n):r.delete(n),l(r)}else l(Ga(e,s))})},mounted:dl,beforeUpdate(e,t,o){e[vo]=xi(o),dl(e,t,o)}};function dl(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Me(t))n=or(t,i.props.value)>-1;else if(Ci(t))n=t.has(i.props.value);else{if(t===o)return;n=_i(t,Ga(e,!0))}e.checked!==n&&(e.checked=n)}const Gf={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,Bo(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?Vn(tn(s)):tn(s));e[vo](e.multiple?Ci(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Ln(()=>{e._assigning=!1})}),e[vo]=xi(i)},mounted(e,{value:t}){ul(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[vo]=xi(o)},updated(e,{value:t}){e._assigning||ul(e,t)}};function ul(e,t){const o=e.multiple,i=Me(t);if(!(o&&!i&&!Ci(t))){for(let n=0,s=e.options.length;n<s;n++){const l=e.options[n],r=tn(l);if(o)if(i){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=or(t,r)>-1}else l.selected=t.has(r);else if(_i(tn(l),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function tn(e){return"_value"in e?e._value:e.value}function Ga(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const Yf=["ctrl","shift","alt","meta"],Zf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Yf.some(o=>e[`${o}Key`]&&!t.includes(o))},oo=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let l=0;l<t.length;l++){const r=Zf[t[l]];if(r&&r(n,t))return}return e(n,...s)}))},Jf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Xf=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=jo(n.key);if(t.some(l=>l===s||Jf[l]===s))return e(n)}))},Qf=vt({patchProp:Wf},Tf);let fl;function eh(){return fl||(fl=lf(Qf))}const yr=((...e)=>{const t=eh().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=oh(i);if(!n)return;const s=t._component;!De(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=o(n,!1,th(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},t});function th(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function oh(e){return nt(e)?document.querySelector(e):e}const pt={baseUrl:"",apiKey:"",model:"",requestTimeoutSeconds:60,temperature:.7,maxTokens:4096},ih="slides-config.json",go={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0,aiConfig:{...pt}},Ht=Yn({...go}),ts=pe(null);function nh(e){ts.value=e}function sh(){return ts.value}function bi(e){if(!e||typeof e!="object")return{...pt};const t=e;return{baseUrl:typeof t.baseUrl=="string"?t.baseUrl.trim():pt.baseUrl,apiKey:typeof t.apiKey=="string"?t.apiKey.trim():pt.apiKey,model:typeof t.model=="string"?t.model.trim():pt.model,requestTimeoutSeconds:typeof t.requestTimeoutSeconds=="number"&&t.requestTimeoutSeconds>0?Math.floor(t.requestTimeoutSeconds):pt.requestTimeoutSeconds,temperature:typeof t.temperature=="number"&&t.temperature>=0&&t.temperature<=2?Number(t.temperature.toFixed(2)):pt.temperature,maxTokens:typeof t.maxTokens=="number"&&t.maxTokens>0?Math.floor(t.maxTokens):pt.maxTokens}}function Fn(e){return e?!!(typeof e.baseUrl=="string"&&e.baseUrl.trim()&&typeof e.apiKey=="string"&&e.apiKey.trim()&&typeof e.model=="string"&&e.model.trim()):!1}function rh(){const e=ts.value;if(e&&Fn(e))return{isManaged:!0,profileName:e.profileName,config:{baseUrl:e.baseUrl,apiKey:e.apiKey,model:e.model,requestTimeoutSeconds:e.requestTimeoutSeconds??pt.requestTimeoutSeconds,temperature:e.temperature??pt.temperature,maxTokens:e.maxTokens??pt.maxTokens,headers:e.headers}};const t=Ht.aiConfig;return Fn(t)?{isManaged:!1,config:{...t}}:null}function lh(e){if(!e||typeof e!="object")return{...go,aiConfig:{...pt}};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():go.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:go.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:go.showOrderedListMarkers,aiConfig:bi(t.aiConfig)}}function ht(e){if(!e||typeof e!="object")return{...Ht};const t=e;return t.enableWebServeJump!==void 0&&(Ht.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ht.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ht.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ht.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ht.showOrderedListMarkers=!!t.showOrderedListMarkers),t.aiConfig!==void 0&&(Ht.aiConfig=bi(t.aiConfig)),{...Ht}}function zo(){return{...Ht}}function Ya(e,t,o){const i=(e||go.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),o!=null&&o.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const ni={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function ah(e){var n,s,l,r,a,c;const t=zo();if(!e)return{...ni,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[Br]!==void 0?e[Br]!=="false":t.showUnorderedListMarkers,i=e[Dr]!==void 0?e[Dr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Vi])==null?void 0:n.trim())||ni.theme,aspectRatio:((s=e[Ki])==null?void 0:s.trim())||ni.aspectRatio,defaultTransition:((l=e[Gi])==null?void 0:l.trim())||ni.defaultTransition,colorSchema:((r=e[Hl])==null?void 0:r.trim())||ni.colorSchema,spacing:((a=e[As])==null?void 0:a.trim())||ni.spacing,background:((c=e[$n])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function yo(e){var o,i,n,s,l;const t=(o=e.ial)==null?void 0:o[ho];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function hl(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[Ct]&&(t.transition=e[Ct].trim()),e[ct]&&(t.background=e[ct].trim()),e[Wt]&&(t.image=e[Wt].trim()),e[ai]&&(t.class=e[ai].trim()),e[Ni]&&(t.spacing=e[Ni].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[ci]&&(t.mask=e[ci].trim()),e[Zo]&&(t.maskRatio=e[Zo].trim()),e[di]&&(t.maskStyle=e[di].trim()),e[ui]&&(t.maskInitial=e[ui].trim()),e[ss]&&(o=e[ss].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,yt,ci,Zo,di,ui,Ct,ct,Wt,ai,Ni,ss,ho].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function pl(e){const t={};if(!e)return t;const o=e[qe];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ye],n=e[ct];(i===Fl||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===Mn||s===En?t.imageLayout=s:(i===Mn||i===En)&&(t.imageLayout=i);const l=e[Oe];if(l!=null&&(t.clicks=l.trim()),e[Et])try{const r=JSON.parse(e[Et]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Et].trim()}}return e[ei]&&(t.shikiLines=e[ei].trim()),e[Yi]&&(t.maxHeight=e[Yi].trim()),e[Te]&&(t.slot=e[Te].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function ko(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function ji(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),l=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),h=u?u[1].length:0;h>=l?r.push(c.slice(l)):h>n?r.push(c.slice(h)):r.push(c)}return r.join(`
`)}function Ho(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function gs(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function Ui(e){if(!e)return[];if(ut(e)&&so(e)&&!ro(e)){const i=Ii(e),n=[];for(const s of i)n.push(...Ui(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Ho);if(l.length>0)return l}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return l}}return Ho(e)?[e]:[]}function br(e){var n;if(!e||!ut(e)||!so(e)||ro(e))return null;const t=Ii(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&so(t[0])){const s=br(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ut(s)){o.push(s);const l=((n=s.children)==null?void 0:n.filter(ut))||[];o.push(...l)}const i=t.map(Ui);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=Ui(t[0]),l=Ui(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:o}}return null}function ch(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=br(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=vr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((l,r)=>`col-${r+1}`),ratio:n}}function Za(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=Ii(e);if(t.length===0)return null;const o=[];for(const i of t){const n=Ui(i);if(n.length===0)return null;o.push(...n)}return o}function dh(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=Za(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function uh(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=br(e);if(t&&t.items.length===4)return t.items;const o=Za(e);if(o&&o.length===4)return o;const i=Ii(e);return i.length===4?i:null}function fh(e,t){if(!e||e.length===0)return null;const o=[];function i(r,a){if(ut(r)){const c=uh(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,a)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),n||(n=o[0]);const l=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>Ja(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:l}}function hh(e,t,o){var u,h,m,d,b;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let g=0;g<t.length;g++){const p=t[g];if(yo(p)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=p.id,r.blocks.push(p);continue}r={pageTargetId:p.id,blocks:[p]},l.push(r)}else r.blocks.push(p)}function a(g){const p=[];for(const y of g)ut(y)&&p.push(y),y.children&&y.children.length>0&&p.push(...a(y.children));return p}function c(g,p,y){const x={blockId:g,attrs:p,previousAttrs:y};i.push(x),o!=null&&o.onTagChange&&o.onTagChange(x)}for(const g of l){const p=g.pageTargetId,y=t.find(A=>A.id===p),x=s.find(A=>A.pageTargetId===p);if(g.blocks.some(A=>{var T,N;return!!(ro(A)||Us(A)&&(((T=A.ial)==null?void 0:T[be])==="image-left"||((N=A.ial)==null?void 0:N[be])==="image-right"))})){if(x){const A=x.headerId;if(A){c(A,{[Te]:""});const T=t.find(N=>N.id===A);T!=null&&T.ial&&(T.ial[Te]="")}for(const T of x.itemIds){c(T,{[Te]:""});const N=t.find(F=>F.id===T);N!=null&&N.ial&&(N.ial[Te]="")}}continue}let v=null,_=-1;for(let A=0;A<g.blocks.length;A++){const T=g.blocks[A],N=ut(T)?[T,...a(T.children||[])]:T.children?a(T.children):[];for(const F of N){const H=ch(F);if(H){v=H,_=A;break}}if(v)break}if(v){const{superBlockNode:A,layout:T,items:N,slots:F}=v,U=g.blocks.slice(0,_).find(I=>Ja(I)),E=U==null?void 0:U.id,D=((u=y==null?void 0:y.ial)==null?void 0:u[be])||"",S=D==="clover",P=S?"clover":T;if(D!==P&&(c(p,{[be]:P},{[be]:D}),y&&(y.ial||(y.ial={}),y.ial[be]=P)),U){const I=((h=U.ial)==null?void 0:h[Te])||"";I!=="header"&&(c(U.id,{[Te]:"header"},{[Te]:I}),U.ial||(U.ial={}),U.ial[Te]="header")}if(x!=null&&x.headerId&&x.headerId!==E){c(x.headerId,{[Te]:""});const I=t.find(M=>M.id===x.headerId);I&&(I.ial||(I.ial={}),I.ial[Te]="")}const j=[];for(let I=0;I<N.length;I++){const M=N[I],L=F[I];j.push(M.id);const te=((m=M.ial)==null?void 0:m[Te])||"";if(te!==L&&(c(M.id,{[Te]:L},{[Te]:te}),M.ial||(M.ial={}),M.ial[Te]=L),M.children&&M.children.length>0)for(const V of M.children)V.ial||(V.ial={}),V.ial[Te]!==L&&(V.ial[Te]=L)}if(x!=null&&x.itemIds){for(const I of x.itemIds)if(!j.includes(I)){c(I,{[Te]:""});const M=t.find(L=>L.id===I);M&&(M.ial||(M.ial={}),M.ial[Te]="")}}n.push({superBlockId:A.id,nestedSuperBlockIds:(d=v.nestedSuperBlocks)==null?void 0:d.map(I=>I.id),pageTargetId:p,headerId:E,itemIds:j,layout:S?"clover":T})}else{let A=!1;const T=[];for(const H of g.blocks){const U=ut(H)?[H,...a(H.children||[])]:H.children?a(H.children):[];for(const E of U){const D=dh(E);if(D){A=!0;for(const S of D.items)T.push(S.id)}}}const N=((b=y==null?void 0:y.ial)==null?void 0:b[be])||"",F=fi(N);if(x||A&&F){c(p,{[be]:""},{[be]:N}),y&&(y.ial||(y.ial={}),y.ial[be]="");const H=x==null?void 0:x.headerId;if(H){c(H,{[Te]:""});const E=t.find(D=>D.id===H);E&&(E.ial||(E.ial={}),E.ial[Te]="")}const U=new Set([...(x==null?void 0:x.itemIds)||[],...T]);for(const E of U){c(E,{[Te]:""});const D=t.find(S=>S.id===E);D&&(D.ial||(D.ial={}),D.ial[Te]="")}}}}return{changes:i,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function so(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function Us(e){return!e||Ho(e)||ut(e)||!ko(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function vr(e){var m;if(!e||!ut(e)||!so(e))return null;const t=Ii(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const b=(((m=d.ial)==null?void 0:m.style)||d.style||"").trim();let g=null;if(b){const p=b.match(/calc\(\s*([\d.]+)%/i);if(p)g=parseFloat(p[1]);else{const y=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(g=parseFloat(y[1]))}}g!==null&&!isNaN(g)&&g>0?(o.push(g),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,b)=>d+(b||0),0),l=o.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/n,c=o.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const h=c.map(d=>d/u*100);if(h.length===2){const[d]=h;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),g=100-b;return`${b}:${g}`}if(h.length===3){const[d,b,g]=h;if(d>=31&&d<=35&&b>=31&&b<=35&&g>=31&&g<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&g>=23&&g<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&g>=23&&g<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&g>=48&&g<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&g>=18&&g<=22)return"1:3:1";const p=Math.round(d),y=Math.round(b),x=100-p-y;return`${p}:${y}:${x}`}return h.map(d=>Math.round(d)).join(":")}function ro(e){if(!e||!ut(e)||!so(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=Us(t[0]),i=Us(t[t.length-1]),n=vr(e)||void 0;if(o&&!i){const s=ko(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:Mn,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=ko(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:En,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function ph(e,t){const o=[];function i(n){for(const s of n){const l=ro(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[be];if(u!==a){const m={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[be]=a,o.push(m),t&&t(m)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function Ii(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function Ja(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function qo(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,a);const u=a+c;let h=1,m=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let g;for(;(g=b.exec(e))!==null;)if(g[0].startsWith("</")){if(h--,h===0){m=g.index,d=g.index+g[0].length;break}}else h++;if(m!==-1&&d!==-1){const p=e.slice(u,m);i+=o(p),n=d}else i+=e.slice(a,u),n=u}return i}function mh(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,l=!1,r=-1,a=0;for(;(s=n.exec(e))!==null;){const g=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(g)){l=!0,r=s.index,a=s[0].length;break}}if(!l){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+a;let u=1,h=-1,m=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(e))!==null;)if(b[0].startsWith("</")){if(u--,u===0){h=b.index,m=b.index+b[0].length;break}}else u++;if(h!==-1&&m!==-1){const g=e.slice(r,m),p=`__VUE_DIV_TOKEN_${t.length}__`;t.push(g),o+=p,i=m}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function gh(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),a});const{text:n,tokens:s}=mh(o);o=n;const l=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=qo(o,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),h=c[3].trim();return`**${u}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:r}),o=qo(o,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),o=qo(o,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let h="-";return u.includes("warn")?h="- ⚠️":u.includes("bad")?h="- ❌":u.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=qo(o,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const m=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${m}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=qo(o,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=qo(o,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=qo(o,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,m)=>Math.max(h,m.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,h)=>{const m=h.trim();return m.includes("<")||m.includes(`
`)?r:`[${m}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>l[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function Xa(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Ws(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function kr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function yh(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function qs(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),h=Math.min(o,c.length),m=Math.floor(c.length/h),d=c.length%h;let b=0;for(let g=0;g<h;g++){const p=m+(g<d?1:0);u[g]=c.slice(b,b+p),b+=p}return u}if(e.length===1){const c=e[0],h=(c.slot||"").trim().match(/^col-(\d+)$/i),m=h?parseInt(h[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),b=d.split(/\r?\n/),g=[];for(let x=0;x<b.length;x++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[x])&&g.push(x);if(g.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let v=0;v<o;v++){const _=o-v,A=g.length-k,T=Math.ceil(A/_),N=g[k],F=k+T<g.length?g[k+T]:b.length,H=b.slice(N,F).join(`
`);x[v]=[{...c,id:v===0?c.id:`${c.id}-col${v+1}`,rawMarkdown:H,content:H}],k+=T}return x}const p=d.match(/<li[\s\S]*?<\/li>/gi);if(p&&p.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let v=0;v<o;v++){const _=o-v,A=p.length-k,T=Math.ceil(A/_),N=`<ul>
${p.slice(k,k+T).join(`
`)}
</ul>`;x[v]=[{...c,id:v===0?c.id:`${c.id}-col${v+1}`,rawMarkdown:N,content:N}],k+=T}return x}const y=d.split(/\r?\n\s*\r?\n/).filter(x=>x.trim()!=="");if(y.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let v=0;v<o;v++){const _=o-v,A=y.length-k,T=Math.ceil(A/_),N=y.slice(k,k+T).join(`

`);x[v]=[{...c,id:v===0?c.id:`${c.id}-col${v+1}`,rawMarkdown:N,content:N}],k+=T}return x}if(m&&m>=1&&m<=o){const x=Array.from({length:o},()=>[]);return x[m-1]=[c],x}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const h=u.match(/^col-(\d+)$/i);if(h){const m=parseInt(h[1],10);if(m>=1&&m<=o)return m}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let b=1;for(const p of e){const y=i(p);y!==null&&(b=y),d[b-1].push(p)}if(!e.some(p=>/^col-\d+$/i.test((p.slot||"").trim()))&&d[0].length===0){const p=d.filter(y=>y.length>0);if(p.length===1)return[p[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),h=e.filter(d=>i(d)===null),m=o-1;if(h.length>=m){const d=Math.floor(h.length/m),b=h.length%m,g=[u];let p=0;for(let y=0;y<m;y++){const x=d+(y<b?1:0);g.push(h.slice(p,p+x)),p+=x}return g}else if(h.length>0){const d=[u];for(let b=0;b<m;b++)d.push(b<h.length?[h[b]]:[]);return d}else return[u,...Array.from({length:m},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const h=r[u],m=u+1<o?r[u+1]:e.length;c[u]=e.slice(h,m)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let h=0;h<o;h++){const m=o-h,d=e.length-u,b=Math.ceil(d/m);c[h]=e.slice(u,u+b),u+=b}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const a=Array.from({length:o},()=>[]);return a[0]=e,a}function ml(e,t,o,i){const n=ah(t),s=[],l=hl(t),r=n.background?Lt(n.background,i):void 0;let a={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};a.frontmatter.background&&(a.frontmatter.background=Lt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Lt(a.frontmatter.image,i));const c=d=>{const b=[];for(let g=d;g<o.length&&!(g>d&&yo(o[g]));g++)b.push(o[g]);return b},u=d=>{let b,g,p;const y=x=>{var T;if(b)return;const k=ro(x);if(k){b=k.layout,g=k.imageUrl,p=k.ratio;return}const v=Er(x),_=x.ial?{...x.ial}:{},A=pl(_);if(A.imageLayout==="image-left"||A.imageLayout==="image-right"){const N=ko(v,x.content);if(N){b=A.imageLayout,g=N,p=(T=x.ial)==null?void 0:T[yt];return}}if(x.children&&x.children.length>0){for(const N of x.children)if(y(N),b)return}};for(const x of d)if(y(x),b)break;return{foundLayout:b,foundImage:g,foundRatio:p}},h=(d,b)=>{const{foundLayout:g,foundImage:p,foundRatio:y}=u(b);g&&(d.frontmatter.layout=g,p&&(d.frontmatter.image=Lt(p,i)),y&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=y))};h(a,c(0)),s.push(a);let m=[];for(let d=0;d<o.length;d++){const b=o[d];if(yo(b)){m=[];const p=hl(b.ial);if(s.length===1&&a.blocks.length===0){a.startBlockId=b.id,a.allBlockIds||(a.allBlockIds=[]),a.allBlockIds.includes(b.id)||a.allBlockIds.push(b.id),p.frontmatter.layout&&(a.frontmatter.layout=p.frontmatter.layout),Object.assign(a.frontmatter,p.frontmatter),delete a.frontmatter.background,!p.frontmatter.image&&l.frontmatter.image&&(a.frontmatter.image=l.frontmatter.image),r&&(a.frontmatter.background=r),a.frontmatter.background&&(a.frontmatter.background=Lt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Lt(a.frontmatter.image,i)),h(a,c(d+1));continue}a={pageIndex:s.length+1,startBlockId:b.id,frontmatter:{layout:p.frontmatter.layout||"default",...p.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete a.frontmatter.background,a.frontmatter.background&&(a.frontmatter.background=Lt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Lt(a.frontmatter.image,i)),h(a,c(d+1)),s.push(a);continue}const g=(p,y)=>{var ce,oe,le,Se,$e,ke,Ce;if(a.allBlockIds||(a.allBlockIds=[]),p.id&&!a.allBlockIds.includes(p.id)&&a.allBlockIds.push(p.id),p.children&&p.children.length>0){const R=ie=>{for(const B of ie)B.id&&!a.allBlockIds.includes(B.id)&&a.allBlockIds.push(B.id),B.children&&B.children.length>0&&R(B.children)};R(p.children)}let x=Er(p),k=p.ial?{...p.ial}:{};const v=x.match(/\{:\s*([^}]+)\s*\}\s*$/);v&&(k={...Rl(v[0]),...k},x=x.slice(0,v.index).trim()),p.type!=="c"&&!x.startsWith("```")&&(x=Xa(x));let _=x.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(_)||_==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(_)&&/\r?\n\}\}\}$/.test(_)&&(x=_.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),_=x.trim());const A=pl(k);if(x=Md(x,i),x=Td(x,i==null?void 0:i.refContentMap),p.children&&p.children.length>0){const R=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ie=B=>{for(const W of B){if(W.ial)for(const[w,q]of Object.entries(W.ial))R.includes(w)&&!k[w]&&(k[w]=q);W.children&&W.children.length>0&&ie(W.children)}};ie(p.children)}const T=p.type==="video"||p.type==="NodeVideo"||/<video\b/i.test(x);if(T){const R=k["custom-slides-autoplay"]==="true",ie=k["custom-slides-loop"]==="true",B=k["custom-slides-muted"]==="true"||R,W=k["custom-slides-controls"]==="false";x=x.replace(/<video\b([^>]*)>/gi,(w,q)=>{let z=q;return W?z=z.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(z)||(z+=" controls"),R&&!/autoplay/i.test(z)?z+=" autoplay playsinline":!R&&k["custom-slides-autoplay"]==="false"&&(z=z.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ie&&!/loop/i.test(z)?z+=" loop":!ie&&k["custom-slides-loop"]==="false"&&(z=z.replace(/\bloop\b/gi,"").trim()),B&&!/muted/i.test(z)?z+=" muted":!B&&k["custom-slides-muted"]==="false"&&(z=z.replace(/\bmuted\b/gi,"").trim()),`<video ${z.trim()}>`})}if(A.isBackground){const R=ko(x,p.content);if(R){a.frontmatter.background=Lt(R,i);return}}const N=ro(p);if(N){a.frontmatter.layout=N.layout,a.frontmatter.image=Lt(N.imageUrl,i),!a.frontmatter.layoutRatio&&N.ratio&&(a.frontmatter.layoutRatio=N.ratio);for(const R of N.contentNodes)g(R);return}if(A.imageLayout==="image-left"||A.imageLayout==="image-right"){const R=ko(x,p.content);if(R){a.frontmatter.layout=A.imageLayout,a.frontmatter.image=Lt(R,i),!a.frontmatter.layoutRatio&&((ce=p.ial)!=null&&ce[yt])&&(a.frontmatter.layoutRatio=p.ial[yt]);return}}if(ut(p)&&p.children&&p.children.length>0){for(const R of p.children)g(R);return}const F=!!(A.slot||y!=null&&y.defaultSlot||a.frontmatter.layout==="clover"||fi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols"),H=!!(p.children&&p.children.some(R=>{var ie,B;return((ie=R.ial)==null?void 0:ie[Te])||((B=R.ial)==null?void 0:B[Oe])||R.children&&R.children.length>=2||R.children&&R.children.some(W=>{var w,q,z,C,$,O;return((w=W.ial)==null?void 0:w[Oe])||((q=W.ial)==null?void 0:q[Te])||((z=W.ial)==null?void 0:z[Ye])||((C=W.ial)==null?void 0:C[be])||(($=W.ial)==null?void 0:$["custom-slides-role"])||((O=W.ial)==null?void 0:O["custom-slides-layout"])})}));if((p.type==="l"||p.type==="NodeList"||p.type==="list")&&p.children&&p.children.length>0&&(H||A.slot||A.clicks||F)){const R=/^\s*\d+\.\s+/m.test(p.markdown||"")||p.subType==="o"||p.subtype==="o";for(let ie=0;ie<p.children.length;ie++){const B=p.children[ie];A.slot&&(!B.ial||!B.ial[Te])&&(B.ial||(B.ial={}),B.ial[Te]=A.slot),g(B,{...y,parentClicks:A.clicks||(y==null?void 0:y.parentClicks),defaultSlot:A.slot||(y==null?void 0:y.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:R,itemIndex:ie+1}})}return}const U=!!(y!=null&&y.isParentListUnpacked),E=!!(p.children&&p.children.length>=2)||!!A.clicks||!!((oe=p.children)!=null&&oe.some(R=>{var ie;return(ie=R.ial)==null?void 0:ie[Oe]}))||U||!p.markdown&&!!(p.children&&p.children.length>0);if(Ho(p)&&p.children&&p.children.length>0&&(F||U||A.clicks||p.children.some(R=>{var ie;return(ie=R.ial)==null?void 0:ie[Oe]}))&&E){const R=!!(p.children&&p.children.length>=2),ie=p.children.find($=>!!($.markdown||$.content||"").trim())||p.children[0],B=((le=ie==null?void 0:ie.ial)==null?void 0:le[Oe])||((Se=ie==null?void 0:ie.ial)==null?void 0:Se["custom-slides-click"]),W=!!(!A.clicks&&R&&B),w=A.clicks||(W?B:void 0)||(y==null?void 0:y.parentClicks),q=p.id||(y==null?void 0:y.parentContainerId),z=A.slot||(y==null?void 0:y.defaultSlot);let C=!0;for(const $ of p.children){z&&(!$.ial||!$.ial[Te])&&($.ial||($.ial={}),$.ial[Te]=z);const O=!!($.markdown||$.content||"").trim(),G=C&&O;if(G){if(!(a.frontmatter.layout==="image-right"||a.frontmatter.layout==="image-left")&&!!(a.frontmatter.layout==="clover"||fi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols")&&!!(y!=null&&y.defaultSlot||A.slot||($e=p.ial)!=null&&$e[Te]))$.markdown&&($.markdown=ji($.markdown)),$.content&&($.content=ji($.content));else{const ne=!!((ke=y==null?void 0:y.listContext)!=null&&ke.isOrdered),me=((Ce=y==null?void 0:y.listContext)==null?void 0:Ce.itemIndex)||1,_e=ne?`${me}. `:"- ",we=Le=>{if(!Le)return _e.trim();const He=Le.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?Le:`${_e}${Le}`};$.markdown&&($.markdown=we($.markdown)),$.content&&($.content=we($.content))}C=!1}let K=$;G&&w&&R?(K={...$,ial:{...$.ial||{}}},delete K.ial[Oe],delete K.ial["custom-slides-click"]):!R&&w&&(K={...$,ial:{...$.ial||{},[Oe]:w}}),g(K,{...y,parentClicks:w,parentContainerId:q,defaultSlot:z,isListItem:!0})}return}if(A.isNote){const R=kr(x);R&&(a.notes?a.notes+=`

`+R:a.notes=R),a.noteBlocks||(a.noteBlocks=[]),a.noteBlocks.push({id:p.id,type:p.type,content:R||p.content||"",rawMarkdown:x,isNote:!0,attributes:p.ial});return}_=x.trim();const D=(p.content||"").trim();if(_==="::right::"||D==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(_)||_.startsWith("::right::")){a.blocks.push({id:p.id,type:p.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:p.ial});return}const P=yh(p);let j=A.slot,I=A.clicks,M=A.motion,L={...p.ial||{}};if(P!==null){for(;m.length>0&&m[m.length-1].level>=P;)m.pop();const R=m.length>0?m[m.length-1]:void 0;!j&&(R!=null&&R.slot)&&(j=R.slot),!I&&(R!=null&&R.clicks)&&!(y!=null&&y.parentContainerId)&&(I=R.clicks),!M&&(R!=null&&R.motion)&&(M=R.motion);const ie={...(R==null?void 0:R.customAttrs)||{}};if(p.ial)for(const[B,W]of Object.entries(p.ial))B.startsWith("custom-slides-")&&!B.startsWith("custom-slides-slide")&&(ie[B]=W);y!=null&&y.parentContainerId||m.push({level:P,slot:j,clicks:I,motion:M,customAttrs:ie})}else{const R=m.length>0?m[m.length-1]:void 0;R&&(!j&&R.slot&&R.slot!=="header"&&(j=R.slot),!I&&R.clicks&&!(y!=null&&y.parentContainerId)&&(I=R.clicks),!M&&R.motion&&(M=R.motion),R.customAttrs&&(L={...R.customAttrs,...L}))}!j&&a.blocks.some(R=>R.slot==="slot-divider-right")&&(j="right"),!j&&(y!=null&&y.defaultSlot)&&(j=y.defaultSlot),j&&(L[Te]=j),I&&!L[Oe]&&(L[Oe]=I),M&&!L[Et]&&(L[Et]=JSON.stringify(M)),(T||k["custom-slides-autoplay"]||k["custom-slides-muted"])&&(k["custom-slides-autoplay"]&&(L["custom-slides-autoplay"]=k["custom-slides-autoplay"],k["custom-slides-autoplay"]==="true"&&!k["custom-slides-muted"]&&(L["custom-slides-muted"]="true")),k["custom-slides-loop"]&&(L["custom-slides-loop"]=k["custom-slides-loop"]),k["custom-slides-muted"]&&(L["custom-slides-muted"]=k["custom-slides-muted"]),k["custom-slides-controls"]&&(L["custom-slides-controls"]=k["custom-slides-controls"]));const te=A.maxHeight?Ws(A.maxHeight):void 0,V=!!(y!=null&&y.isListItem||Ho(p)),Z={id:p.id,type:p.type,content:p.content||"",rawMarkdown:x,clicks:I,parentClicks:y==null?void 0:y.parentClicks,parentContainerId:y==null?void 0:y.parentContainerId,motion:M,shikiLines:A.shikiLines,maxHeight:te,slot:j,attributes:L,attrs:L,rawNode:p,isListItem:V};a.blocks.push(Z)};g(b)}for(let d=0;d<s.length;d++){const b=s[d],g=b.blocks.filter(x=>x.slot!=="slot-divider-right"),p=x=>{const k=x.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(k.length===0)return;const v=k[0],_=(v.rawMarkdown||v.content||"").trim();(Ho(v)||/^(?:[-*+]|\d+\.)\s+/.test(_))&&(v.rawMarkdown=ji(v.rawMarkdown||v.content||""),v.content=v.rawMarkdown)},y=b.frontmatter.layout||"default";if(y==="clover"||fi(y)){let x=[];const k=g.filter(N=>N.slot==="header");if(k.length>0)x=k;else if(g.length>0){const N=g.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));N&&(x=[N])}const v=g.filter(N=>!x.includes(N));let _=2;if(y==="clover")_=4;else if(y==="three-cols-header")_=3;else if(y==="two-cols-header")_=2;else{let N=0;for(const F of v){const H=(F.slot||"").match(/^col-(\d+)$/i);H&&(N=Math.max(N,parseInt(H[1],10)))}if(N>=2)_=N;else if(b.frontmatter.layoutRatio){const F=b.frontmatter.layoutRatio.trim();if(F.includes(":")){const H=F.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);H.length>=2&&(_=H.length)}else{const H=F.split(/\s+/).filter(Boolean);H.length>=2&&(_=H.length)}}else v.length===1&&v[0].children&&v[0].children.length>=2&&(_=Math.min(6,v[0].children.length))}const A=qs(v,_);A.forEach((N,F)=>{const H=`col-${F+1}`;for(const U of N)(!U.slot||U.slot==="default")&&(U.slot=H);p(N)});const T=A.flat();if(v.length===1&&T.length>1){const N=b.blocks.findIndex(F=>F.id===v[0].id);N!==-1&&b.blocks.splice(N,1,...T)}}else if(y==="two-cols"){const x=g.filter(v=>v.slot==="right"),k=g.filter(v=>!v.slot||v.slot==="default");if(x.length===0&&k.length>=2){const[,v]=qs(k,2);for(const _ of v)_.slot="right"}p(g.filter(v=>v.slot!=="right")),p(g.filter(v=>v.slot==="right"))}b.rawMarkdown=b.blocks.filter(x=>x.slot!=="slot-divider-right").map(x=>x.rawMarkdown||x.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const gl=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function bh(e){var n,s,l,r,a,c,u,h,m,d,b,g;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const p of e.styles){if(!p||!p.id)continue;const y=`--b3-inline-style-${p.id}`;(n=p.light)!=null&&n.color&&t.push(`  ${y}-color: ${p.light.color};`),(s=p.light)!=null&&s.backgroundColor&&t.push(`  ${y}-background-color: ${p.light.backgroundColor};`),(l=p.dark)!=null&&l.color&&o.push(`  ${y}-color: ${p.dark.color};`),(r=p.dark)!=null&&r.backgroundColor&&o.push(`  ${y}-background-color: ${p.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const p of e.builtin.colors){if(!p||typeof p.index!="number")continue;const y=p.index;(a=p.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${p.light.color};`),(c=p.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${p.light.backgroundColor};`),(u=p.dark)!=null&&u.color&&o.push(`  --b3-font-color${y}: ${p.dark.color};`),(h=p.dark)!=null&&h.backgroundColor&&o.push(`  --b3-font-background${y}: ${p.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const p of e.builtin.styles){if(!p||!p.id)continue;const y=p.id;(m=p.light)!=null&&m.color&&t.push(`  --b3-card-${y}-color: ${p.light.color};`),(d=p.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${y}-background: ${p.light.backgroundColor};`),(b=p.dark)!=null&&b.color&&o.push(`  --b3-card-${y}-color: ${p.dark.color};`),(g=p.dark)!=null&&g.backgroundColor&&o.push(`  --b3-card-${y}-background: ${p.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Wi(e){const t=bh(e);return t?`${gl}

/* Custom Workspace Inline Styles */
${t}`:gl}const ys=Rl;function vh(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function kh(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=n.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(vh(l)?i.push(s.id):o.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function wh(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Vs(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function xh(e,t,o,i=8,n){const s=new Map;for(const m of t)m!=null&&m.id&&s.set(m.id,m);const l=m=>({id:m.id,parent_id:m.parent_id,root_id:m.root_id||e,type:m.type,subType:m.subtype??m.subType??"",content:m.content||"",markdown:m.markdown||"",ial:o(m.id,m.ial),children:[]}),r=m=>{let d=m.parent_id,b=0;for(;d&&d!==e&&b++<16;){const g=s.get(d);if(!g||!wh(g))return d;d=g.parent_id}return d||e},a=new Map;for(const m of t){if(!(m!=null&&m.id)||m.id===e||n&&n.size>0&&!n.has(m.id))continue;const d=r(m),b=a.get(d);b?b.push(m):a.set(d,[m])}if(n&&n.size>0)for(const m of a.values())m.sort((d,b)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(m,d)=>{const b=l(m);if(c.set(b.id,b),d>=i||!Vs(b))return b;const g=a.get(b.id);return g&&g.length>0&&(b.children=g.map(p=>u(p,d+1))),b};return{topLevel:(a.get(e)||[]).map(m=>u(m,0)),byId:c}}const Sh={getBlockAttrs:Xs,getChildBlocks:Si,getDocBlocksOrders:Cd,setBlockAttrs:ze,sql:vi,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Id};class Ch{constructor(t){Ie(this,"deps");Ie(this,"attrOverrides",new Map);Ie(this,"trackedListSuperBlocks",new Map);Ie(this,"fallbackWarnedDocId","");this.deps={...Sh,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(o))l===""||l===null||l===void 0?delete n[s]:n[s]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let j=0;j<s.length;j++)s[j]&&l.set(s[j],j);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=kh(n,c),h=new Map;if(Array.isArray(c))for(const j of c)j.id&&j.ial&&h.set(j.id,ys(j.ial));const m=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(m).catch(()=>[])||[];if(Array.isArray(d)){for(const j of d)if(j.block_id&&j.name){let I=h.get(j.block_id);I||(I={},h.set(j.block_id,I)),I[j.name]=j.value||""}}const b=(j,I)=>{const M={...h.get(j)||(I?ys(I):{})},L=this.attrOverrides.get(j);return L&&Object.assign(M,L),M},g=Array.isArray(c)&&c.length>0?xh(t,c,b,8,l):null,p=n.map(j=>j.id).filter(Boolean),y=j=>({id:j.id,parent_id:j.parent_id,root_id:j.root_id||t,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:b(j.id,j.ial),children:j.children}),x=async(j,I=0)=>{if(!j||I>8||!Vs(j))return;const M=await this.deps.getChildBlocks(j.id).catch(()=>[])||[];if(!(!Array.isArray(M)||M.length===0)){j.children=M.filter(L=>L==null?void 0:L.id).map(L=>({id:L.id,parent_id:j.id,root_id:t,type:L.type,subType:L.subType,content:L.content||"",markdown:L.markdown||"",ial:b(L.id,L.ial),children:[]}));for(const L of j.children)await x(L,I+1)}},k=new Map;for(const j of c)j!=null&&j.id&&k.set(j.id,j);const v=p.every(j=>{const I=k.get(j);return!I||!!I.type});let _=[],A=!1;if(g&&u.usable&&r&&v){this.fallbackWarnedDocId="";for(const[I,M]of u.leafPatch){const L=g.byId.get(I);L&&(L.content=M.content,L.markdown=M.markdown)}const j=new Map;for(const I of n)I!=null&&I.id&&j.set(I.id,I);for(const I of u.rebuildRoots){const M=g.byId.get(I),L=j.get(I);M&&L&&(M.content=L.content||"",M.markdown=L.markdown||""),await x(M)}for(const I of n){if(!(I!=null&&I.id)||g.byId.has(I.id))continue;const M=y(I);await x(M),g.byId.set(M.id,M),g.topLevel.push(M)}_=g.topLevel.filter(I=>l.has(I.id)).sort((I,M)=>(l.get(I.id)??0)-(l.get(M.id)??0))}else p.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${p.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),_=n.map(j=>y(j))):g&&(_=g.topLevel);const T=async(j,I=0)=>{if(!(!j||j.length===0||I>8))for(const M of j){if(Vs(M)&&(!M.children||M.children.length===0)){let te=await this.deps.getChildBlocks(M.id).catch(()=>[]);if(!te||te.length===0){const V=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${M.id}' ORDER BY sort ASC, created ASC`;te=await this.deps.sql(V).catch(()=>[])||[]}if(Array.isArray(te)&&te.length>0){const V=new Set(_.map(ce=>ce.id)),Z=te.filter(ce=>ce.id!==M.id&&!V.has(ce.id));Z.length>0&&(M.children=Z.map(ce=>{const oe=h.get(ce.id)||(ce.ial?ys(ce.ial):{}),le=this.attrOverrides.get(ce.id);return le&&Object.assign(oe,le),{id:ce.id,parent_id:ce.parent_id||M.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:oe}}))}}M.children&&M.children.length>0&&await T(M.children,I+1)}};A&&await T(_);const N=j=>{var I,M;for(const L of j)if(L.children&&L.children.length>0){N(L.children);for(const te of L.children)if(te.ial)for(const[V,Z]of Object.entries(te.ial))V.startsWith("custom-slides-")&&!((I=L.ial)!=null&&I[V])&&(L.ial||(L.ial={}),L.ial[V]=Z);if(L.ial){for(const[te,V]of Object.entries(L.ial))if(te.startsWith("custom-slides-"))for(const Z of L.children)(Z.type==="video"||Z.type==="NodeVideo"||/<video\b/i.test(Z.markdown||Z.content||""))&&!((M=Z.ial)!=null&&M[te])&&(Z.ial||(Z.ial={}),Z.ial[te]=V)}}};N(_),ph(_,j=>{const I={[be]:j.layout};this.setBlockAttrOverride(j.blockId,I),(this.deps.setBlockAttrs||ze)(j.blockId,I).catch(L=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",L)})});const F=this.trackedListSuperBlocks.get(t)||[],H=hh(t,_,{tracked:F,onTagChange:j=>{this.setBlockAttrOverride(j.blockId,j.attrs),j.blockId===t&&Object.assign(o,j.attrs);const I=L=>{for(const te of L)te.id===j.blockId&&(te.ial||(te.ial={}),Object.assign(te.ial,j.attrs)),te.children&&te.children.length>0&&I(te.children)};I(_),(this.deps.setBlockAttrs||ze)(j.blockId,j.attrs).catch(L=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",L)})}});this.trackedListSuperBlocks.set(t,H.newTracked);const U=new Set,E=j=>{for(const I of j){const M=I.markdown||I.content||"";if(M.includes("((")){const L=$d(M);for(const te of L)U.add(te.blockId)}I.children&&I.children.length>0&&E(I.children)}};E(_);const D={};if(U.size>0){const j=Array.from(U).map(M=>`'${M}'`).join(","),I=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${j})`).catch(()=>[])||[];if(Array.isArray(I))for(const M of I)M.id&&(D[M.id]=M.markdown||M.content||"")}const S=this.deps.getBaseUrl?this.deps.getBaseUrl():"",P=ml(t,o,_,{baseUrl:S,refContentMap:D});try{const j=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;P.customThemeCss=Wi(j)}catch{P.customThemeCss=Wi(null)}return P}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=ml(t,{},[],{});return i.customThemeCss=Wi(null),i}}}const Be=new Ch,_h={presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0};function Do(e){return _h[e]===!1}function Ot(e){return!Do(e)}const yl=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],bl=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function wr(e,t,o){return .299*e+.587*t+.114*o}function vl(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return wr(o,i,n)}return null}function kl(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return wr(o,i,n)}function wl(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const a=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(a)&&a<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,l,r;if(i===0)s=l=r=n*255;else{const a=n<.5?n*(1+i):n+i-n*i,c=2*n-a,u=h=>{let m=h;return m<0&&(m+=1),m>1&&(m-=1),m<1/6?c+(a-c)*6*m:m<1/2?a:m<2/3?c+(a-c)*(2/3-m)*6:c};s=u(o+1/3)*255,l=u(o)*255,r=u(o-1/3)*255}return wr(s,l,r)}function Qa(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(yl.includes(t))return!0;if(bl.includes(t))return!1;if(t.startsWith("#")){const o=vl(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=kl(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=wl(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const a of i){const c=vl(a);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const a of n){const c=kl(a);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const a of s){const c=wl(a);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const a of r)a!=="transparent"&&(yl.includes(a)?o.push(240):bl.includes(a)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function Fo(){var e,t,o,i,n,s,l,r,a,c,u,h,m;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const b=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(b==="light"||b==="dark")return b;if((l=(s=document.documentElement)==null?void 0:s.classList)!=null&&l.contains("theme--dark")||(a=(r=document.body)==null?void 0:r.classList)!=null&&a.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(m=(h=document.body)==null?void 0:h.classList)!=null&&m.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function xr(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:Fo()}function ec(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=Fo();const o=()=>{const n=Fo();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class os{constructor(){Ie(this,"iframe",null);Ie(this,"isReady",!1);Ie(this,"pendingMessages",[]);Ie(this,"slideChangedHandlers",[]);Ie(this,"blockClickedHandlers",[]);Ie(this,"openInEditorHandlers",[]);Ie(this,"clientReadyHandlers",[]);Ie(this,"openPeekDrawerHandlers",[]);Ie(this,"toggleFullscreenHandlers",[]);Ie(this,"openPresenterHandlers",[]);Ie(this,"captureProgressHandlers",[]);Ie(this,"capturePageDoneHandlers",[]);Ie(this,"captureCompleteHandlers",[]);Ie(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(l=>l.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||Fo()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",l={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const Ih={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},$h={key:0},Th={key:1},Ah={key:2},Mh={key:3},Eh={key:4},Bh={key:5},Dh={key:6},Lh={key:7},Oh={key:8},Nh={key:9},Ph={key:10},Rh={key:11},zh={key:12},Hh={key:13},Fh={key:14},jh={key:15},Uh={key:16},Wh={key:17},qh={key:18},Vh={key:19},Kh={key:20},Gh={key:21},Yh={key:22},Zh={key:23},Jh={key:24},Xh={key:25},Qh={key:26},ep={key:27},tp={key:28},op={key:29},ip={key:30},np={key:31},sp={key:32},rp={key:33},lp={key:34},ap={key:35},cp={key:36},dp={key:37},up={key:38},fp={key:39},hp={key:40},pp={key:41},mp={key:42},gp={key:43},yp={key:44},bp={key:45},vp={key:46},kp={key:47},wp={key:48},xp={key:49},Sp={key:50},Cp={key:51},_p={key:52},Ip={key:53},$p={key:54},Tp={key:55},Ap={key:56},Mp={key:57},Ep={key:58},Bp={key:59},Dp={key:60},Lp={key:61},Op={key:62},Np={key:63},Pp={key:64},Rp={key:65},zp={key:66},Hp={key:67},Fp={key:68},jp={key:69},Up={key:70},Wp={key:71},qp={key:72},Vp={key:73},Kp=zt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),ee("svg",Ih,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",$h,[...o[0]||(o[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",Th,[...o[1]||(o[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",Ah,[...o[2]||(o[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",Mh,[...o[3]||(o[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",Eh,[...o[4]||(o[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",Bh,[...o[5]||(o[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",Dh,[...o[6]||(o[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Lh,[...o[7]||(o[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",Oh,[...o[8]||(o[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",Nh,[...o[9]||(o[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",Ph,[...o[10]||(o[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",Rh,[...o[11]||(o[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",zh,[...o[12]||(o[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",Hh,[...o[13]||(o[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",Fh,[...o[14]||(o[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",jh,[...o[15]||(o[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",Uh,[...o[16]||(o[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="layout-grid"||e.name==="grid-2x2"||e.name==="grid"||e.name==="overview"?(J(),ee("g",Wh,[...o[17]||(o[17]=[f("rect",{x:"3",y:"3",width:"7",height:"7",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"7",rx:"1"},null,-1),f("rect",{x:"14",y:"14",width:"7",height:"7",rx:"1"},null,-1),f("rect",{x:"3",y:"14",width:"7",height:"7",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",qh,[...o[18]||(o[18]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",Vh,[...o[19]||(o[19]=[mt('<line x1="8" y1="6" x2="21" y2="6" data-v-3da9d853></line><line x1="8" y1="12" x2="21" y2="12" data-v-3da9d853></line><line x1="8" y1="18" x2="21" y2="18" data-v-3da9d853></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-3da9d853></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-3da9d853></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-3da9d853></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Kh,[...o[20]||(o[20]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",Gh,[...o[21]||(o[21]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",Yh,[...o[22]||(o[22]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",Zh,[...o[23]||(o[23]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",Jh,[...o[24]||(o[24]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",Xh,[...o[25]||(o[25]=[mt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-3da9d853></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-3da9d853></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-3da9d853></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-3da9d853></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-3da9d853></path>',5)])])):e.name==="ratio"?(J(),ee("g",Qh,[...o[26]||(o[26]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",ep,[...o[27]||(o[27]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",tp,[...o[28]||(o[28]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",op,[...o[29]||(o[29]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",ip,[...o[30]||(o[30]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",np,[...o[31]||(o[31]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",sp,[...o[32]||(o[32]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",rp,[...o[33]||(o[33]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",lp,[...o[34]||(o[34]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",ap,[...o[35]||(o[35]=[f("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",cp,[...o[36]||(o[36]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",dp,[...o[37]||(o[37]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",up,[...o[38]||(o[38]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",fp,[...o[39]||(o[39]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",hp,[...o[40]||(o[40]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",pp,[...o[41]||(o[41]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",mp,[...o[42]||(o[42]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",gp,[...o[43]||(o[43]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",yp,[...o[44]||(o[44]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",bp,[...o[45]||(o[45]=[mt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-3da9d853></path><polyline points="14 2 14 8 20 8" data-v-3da9d853></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-3da9d853></line><line x1="16" y1="17" x2="8" y2="17" data-v-3da9d853></line><line x1="10" y1="9" x2="8" y2="9" data-v-3da9d853></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",vp,[...o[46]||(o[46]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",kp,[...o[47]||(o[47]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",wp,[...o[48]||(o[48]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-3da9d853></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-3da9d853></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-3da9d853></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-3da9d853></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",xp,[...o[49]||(o[49]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-3da9d853></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-3da9d853></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-3da9d853></line><line x1="5" y1="15" x2="8" y2="15" data-v-3da9d853></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-3da9d853></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-3da9d853></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-3da9d853></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",Sp,[...o[50]||(o[50]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-3da9d853></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-3da9d853></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-3da9d853></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-3da9d853></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-3da9d853></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-3da9d853></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",Cp,[...o[51]||(o[51]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-3da9d853></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-3da9d853></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-3da9d853></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-3da9d853></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-3da9d853></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-3da9d853></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-3da9d853></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-3da9d853></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-3da9d853></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",_p,[...o[52]||(o[52]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="5" y1="7" x2="13" y2="7" data-v-3da9d853></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-3da9d853></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-3da9d853></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-3da9d853></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-3da9d853></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-3da9d853></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-3da9d853></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",Ip,[...o[53]||(o[53]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="12" y1="4" x2="12" y2="20" data-v-3da9d853></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-3da9d853></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-3da9d853></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-3da9d853></line><circle cx="15.5" cy="8.5" r="1.2" data-v-3da9d853></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-3da9d853></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",$p,[...o[54]||(o[54]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><line x1="12" y1="4" x2="12" y2="20" data-v-3da9d853></line><circle cx="6" cy="8.5" r="1.2" data-v-3da9d853></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-3da9d853></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-3da9d853></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-3da9d853></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-3da9d853></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",Tp,[...o[55]||(o[55]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",Ap,[...o[56]||(o[56]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><circle cx="8" cy="9" r="1.5" data-v-3da9d853></circle><line x1="14" y1="8" x2="9" y2="14" data-v-3da9d853></line><circle cx="15" cy="13" r="1.5" data-v-3da9d853></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-3da9d853></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",Mp,[...o[57]||(o[57]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><circle cx="7.5" cy="9.5" r="2" data-v-3da9d853></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-3da9d853></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-3da9d853></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-3da9d853></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-3da9d853></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",Ep,[...o[58]||(o[58]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-3da9d853></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-3da9d853></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-3da9d853></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-3da9d853></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Bp,[...o[59]||(o[59]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",Dp,[...o[60]||(o[60]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",Lp,[...o[61]||(o[61]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Op,[...o[62]||(o[62]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",Np,[...o[63]||(o[63]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",Pp,[...o[64]||(o[64]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",Rp,[...o[65]||(o[65]=[mt('<line x1="4" y1="21" x2="4" y2="14" data-v-3da9d853></line><line x1="4" y1="10" x2="4" y2="3" data-v-3da9d853></line><line x1="12" y1="21" x2="12" y2="12" data-v-3da9d853></line><line x1="12" y1="8" x2="12" y2="3" data-v-3da9d853></line><line x1="20" y1="21" x2="20" y2="16" data-v-3da9d853></line><line x1="20" y1="12" x2="20" y2="3" data-v-3da9d853></line><line x1="1" y1="14" x2="7" y2="14" data-v-3da9d853></line><line x1="9" y1="8" x2="15" y2="8" data-v-3da9d853></line><line x1="17" y1="16" x2="23" y2="16" data-v-3da9d853></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",zp,[...o[66]||(o[66]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",Hp,[...o[67]||(o[67]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",Fp,[...o[68]||(o[68]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",jp,[...o[69]||(o[69]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",Up,[...o[70]||(o[70]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-3da9d853></rect><line x1="13" y1="8" x2="19" y2="8" data-v-3da9d853></line><line x1="13" y1="12" x2="19" y2="12" data-v-3da9d853></line><line x1="13" y1="16" x2="17" y2="16" data-v-3da9d853></line>',5)])])):e.name==="image-right"?(J(),ee("g",Wp,[...o[71]||(o[71]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-3da9d853></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-3da9d853></rect><line x1="5" y1="8" x2="11" y2="8" data-v-3da9d853></line><line x1="5" y1="12" x2="11" y2="12" data-v-3da9d853></line><line x1="5" y1="16" x2="9" y2="16" data-v-3da9d853></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",qp,[...o[72]||(o[72]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",Vp,[...o[73]||(o[73]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),lo=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},de=lo(Kp,[["__scopeId","data-v-3da9d853"]]),Gp={class:"spm-immersion-header"},Yp={class:"spm-immersion-header__left"},Zp={class:"spm-immersion-title"},Jp={class:"spm-immersion-header__center"},Xp={class:"spm-immersion-header__actions"},Qp=["aria-label"],em={class:"spm-immersion-body"},tm=zt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function l(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ut((J(),ee("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:oo(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:s}),f("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",Gp,[f("div",Yp,[hn(a.$slots,"header-left",{},()=>[f("span",Zp,ve(e.title),1)])]),f("div",Jp,[hn(a.$slots,"header-center",{},void 0)]),f("div",Xp,[hn(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[se(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Qp),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[se(de,{name:"close"})])])]),f("div",em,[hn(a.$slots,"default",{},void 0)])],2)],34)),[[Fs,e.visible]])}}),om=lo(tm,[["__scopeId","data-v-9ac3f92d"]]);function im(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ln(e){const t=im();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function nm(){var t;if(typeof window<"u"&&window.process)return window.process;const e=ln("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function sm(){var t,o;const e=nm();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=ln("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function rm(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const lm={class:"spm-protyle-drawer"},am={class:"spm-protyle-drawer__subbar"},cm={class:"spm-protyle-drawer__nav"},dm=["title"],um={class:"spm-protyle-drawer__actions"},fm=["aria-label"],hm=["aria-label"],pm=zt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(i.blockId),s=pe(i.title||""),l=pe(!1),r=pe(!0),a=pe(!1),c=pe(""),u=Ht,h=pe([]),m=pe(null);let d=null;Ro(()=>i.blockId,T=>{T&&T!==n.value&&(n.value=T,s.value=i.title||"",h.value=[],g(T))}),ti(()=>{n.value&&g(n.value)}),fr(()=>{p()});async function b(T){try{const N=await vi(`SELECT id, root_id, type, content FROM blocks WHERE id = '${T}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const F=N[0];c.value=F.root_id||"";const H=F.id===F.root_id||F.type==="d";a.value=H,r.value=!H,!s.value&&F.content&&(s.value=F.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function g(T,N){if(!m.value||!T)return;p(),await b(T),typeof N=="boolean"&&(r.value=!a.value&&N);let F,H;r.value&&!a.value?(F=["cb-get-all","cb-get-hl","cb-get-focus"],H={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(F=["cb-get-context","cb-get-hl"],H={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new re.Protyle(i.plugin.app,m.value,{blockId:T,action:F,render:H}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(U){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",U)}}function p(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(T){console.warn("[ProtylePeekDrawer] Error destroying protyle:",T)}d=null}m.value&&(m.value.innerHTML="")}function y(){a.value||(r.value=!r.value,g(n.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function k(){if(n.value)try{re.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(T){console.warn("[ProtylePeekDrawer] openWindow failed:",T)}}function v(){var F;if(!n.value)return;const T=zo(),N=Ya(T.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const H=ln("electron");(F=H==null?void 0:H.shell)!=null&&F.openExternal?H.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}o("external-jump",N)}function _(){if(h.value.length>0){const T=h.value.pop();T&&(n.value=T.blockId,s.value=T.title,r.value=T.isFocusMode,a.value=T.isDoc,g(T.blockId,T.isFocusMode))}}function A(T){const N=T.target;if(!N)return;const F=N.closest('[data-type="block-ref"]');if(F){const U=F.getAttribute("data-id");if(U&&U!==n.value){T.preventDefault(),T.stopPropagation(),h.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=U,s.value=F.innerText.trim()||U,g(U);return}}const H=N.closest("a");if(H&&H.href&&H.href.startsWith("siyuan://blocks/")){T.preventDefault(),T.stopPropagation();const U=H.href.replace("siyuan://blocks/","").split("?")[0];U&&U!==n.value&&(h.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=U,s.value=H.innerText.trim()||U,g(U))}}return(T,N)=>(J(),ee("div",lm,[f("div",am,[f("div",cm,[h.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:_},[se(de,{name:"arrow-left"}),N[0]||(N[0]=f("span",null,"返回",-1))])):Ae("",!0),f("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ve(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:s.value||n.value},ve(s.value||n.value),9,dm)]),f("div",um,[a.value?Ae("",!0):(J(),ee("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[se(de,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,ve(r.value?"块聚焦":"展开全文"),1)],10,fm)),f("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[se(de,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,ve(l.value?"编辑中":"只读"),1)],10,hm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:k},[se(de,{name:"window"}),N[1]||(N[1]=f("span",null,"独立窗口",-1))]),ue(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:v},[se(de,{name:"external-link"}),N[2]||(N[2]=f("span",null,"外跳",-1))])):Ae("",!0)])]),f("div",{ref_key:"mountEl",ref:m,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:A},null,2)]))}}),mm=lo(pm,[["__scopeId","data-v-26066bbd"]]),gm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,ym=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function xl(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function tc(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function bm(e){const t=e.split(/[/?#]/)[0];return!t||ym.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function vm(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,l=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function oc(e){const t=km(e);return t.external||!t.url?t:{url:vm(t.url),external:!1}}function km(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(jl(t))return{url:`/${Ul(t)}`,external:!1};if(/^file:/i.test(t)){const i=xl(tc(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=xl(t);return i?{url:i,external:!1}:{url:t,external:!0}}return gm.test(t)?{url:t,external:!0}:bm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const wm={class:"spm-webview-drawer"},xm={class:"spm-webview-toolbar"},Sm={class:"spm-webview-toolbar__nav"},Cm=["disabled"],_m=["disabled"],Im=["aria-label"],$m={class:"spm-webview-toolbar__address"},Tm=["aria-label"],Am={class:"spm-webview-toolbar__actions"},Mm=["aria-label"],Em={class:"spm-zoom-controller"},Bm=["disabled"],Dm=["disabled"],Lm={key:1,class:"spm-webview-fallback"},Om=["src"],Nm={key:2,class:"spm-load-error"},Pm={class:"spm-load-error__code"},Rm={class:"spm-load-error__code-num"},zm={class:"spm-load-error__url"},Hm={class:"spm-load-error__hint"},Fm={class:"spm-load-error__actions"},Sl="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ic="siyuan-slides-peek-view-mode";let nc="desktop";function jm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(ic);if(e==="mobile"||e==="desktop")return e}catch{}return nc}function Um(e){if(nc=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ic,e)}catch{}}function Wm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const qm=zt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(sm()&&!rm()),s=pe(i.url),l=pe(i.url),r=i.url,a=pe(!1),c=pe(null),u=pe(!1),h=pe(!1),m=pe(1),d=pe(!1),b=pe(jm());let g=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const p=ye(()=>b.value==="mobile"?Sl:g||void 0),y=pe(null),x=pe(null);let k=null,v=null,_=null;Ro(()=>i.url,R=>{R&&R!==s.value&&(s.value=R,l.value=R,b.value==="mobile"&&H(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R))}),Ro(()=>i.visible,R=>{if(R)ce(),b.value==="mobile"&&H(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),ti(()=>{A(),x.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const R=y.value;if(R&&typeof R.invalidate=="function")try{R.invalidate()}catch{}}),k.observe(x.value)),v=R=>{var B;const ie=R.message||((B=R.error)==null?void 0:B.message);if(typeof ie=="string"&&ie.includes("Invalid guestInstanceId"))return R.preventDefault(),R.stopImmediatePropagation(),!0},window.addEventListener("error",v,!0),_=R=>{const ie=R.reason,B=typeof ie=="string"?ie:ie==null?void 0:ie.message;typeof B=="string"&&B.includes("Invalid guestInstanceId")&&R.preventDefault()},window.addEventListener("unhandledrejection",_)}),fr(()=>{if(T(),k&&(k.disconnect(),k=null),v&&(window.removeEventListener("error",v,!0),v=null),_&&(window.removeEventListener("unhandledrejection",_),_=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function A(){const R=y.value;R&&(R.addEventListener("dom-ready",N),R.addEventListener("did-start-loading",U),R.addEventListener("did-stop-loading",S),R.addEventListener("did-navigate",P),R.addEventListener("did-navigate-in-page",j),R.addEventListener("new-window",I),R.addEventListener("did-fail-load",E),R.addEventListener("did-fail-provisional-load",E))}function T(){const R=y.value;if(R)try{R.removeEventListener("dom-ready",N),R.removeEventListener("did-start-loading",U),R.removeEventListener("did-stop-loading",S),R.removeEventListener("did-navigate",P),R.removeEventListener("did-navigate-in-page",j),R.removeEventListener("new-window",I),R.removeEventListener("did-fail-load",E),R.removeEventListener("did-fail-provisional-load",E)}catch{}}function N(){const R=y.value;if(R&&typeof R.getUserAgent=="function"&&!g)try{const ie=R.getUserAgent();ie&&!ie.includes("iPhone")&&(g=ie)}catch{}b.value==="mobile"&&H(!1),ce(),M()}function F(){const R=b.value==="mobile"?"desktop":"mobile";b.value=R,Um(R),H(!0)}function H(R=!1){const ie=y.value;if(!ie)return;const B=b.value==="mobile"?Sl:g;if(typeof ie.setUserAgent=="function"&&B)try{ie.setUserAgent(B)}catch(W){console.warn("[WebviewPeekDrawer] setUserAgent error:",W)}if(R&&typeof ie.reload=="function")try{ie.reload()}catch(W){console.warn("[WebviewPeekDrawer] reload error:",W)}}function U(){a.value=!0,c.value=null}function E(R){if(R&&R.isMainFrame===!1||R&&Number(R.errorCode)===-3)return;const ie=String((R==null?void 0:R.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((R==null?void 0:R.errorCode)??0),description:ie,validatedURL:String((R==null?void 0:R.validatedURL)||s.value),hint:Wm(ie)},a.value=!1}function D(){c.value=null,V()}function S(){if(a.value=!1,M(),y.value&&typeof y.value.getURL=="function"){const R=y.value.getURL();R&&R!=="about:blank"&&(s.value=R,l.value=R)}}function P(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),M()}function j(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),M()}function I(R){R&&R.url&&(R.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R.url))}function M(){const R=y.value;R&&(typeof R.canGoBack=="function"&&(u.value=R.canGoBack()),typeof R.canGoForward=="function"&&(h.value=R.canGoForward()))}function L(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function te(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function V(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function Z(){const R=oc(l.value);if(R.url){if(R.external){s.value=R.url,Ce();return}s.value=R.url,l.value=R.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R.url)}}function ce(){const R=y.value;if(R&&typeof R.setZoomFactor=="function")try{R.setZoomFactor(m.value)}catch(ie){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ie)}}function oe(){m.value=Math.min(2.5,Math.round((m.value+.1)*10)/10),ce()}function le(){m.value=Math.max(.5,Math.round((m.value-.1)*10)/10),ce()}function Se(){m.value=1,ce()}function $e(R){R.preventDefault(),R.deltaY<0?oe():R.deltaY>0&&le()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(R){console.warn("Copy url failed:",R)}}function Ce(){var ie;const R=s.value;if(typeof window<"u"){const B=ln("electron");(ie=B==null?void 0:B.shell)!=null&&ie.openExternal?B.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}o("external-jump",R)}return(R,ie)=>{const B=Nu("webview");return J(),ee("div",wm,[f("div",xm,[f("div",Sm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:L},[se(de,{name:"arrow-left"})],8,Cm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!h.value,"aria-label":"前进",onClick:te},[se(de,{name:"arrow-right"})],8,_m),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:V},[se(de,{name:"refresh"})],8,Im)]),f("div",$m,[Ut(f("input",{"onUpdate:modelValue":ie[0]||(ie[0]=W=>l.value=W),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Xf(Z,["enter"])},null,544),[[js,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ke},[se(de,{name:"copy"})],8,Tm)]),f("div",Am,[f("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:F},[se(de,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Mm),f("div",Em,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:m.value<=.5,onClick:le},[se(de,{name:"minus"})],8,Bm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},ve(Math.round(m.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:m.value>=2.5,onClick:oe},[se(de,{name:"plus"})],8,Dm)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Ce},[se(de,{name:"external-link"}),ie[1]||(ie[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:x,class:xe(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:oo($e,["ctrl"])},[f("div",{class:xe(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[n.value?(J(),io(B,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:ue(r),useragent:p.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",Lm,[f("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Om),f("div",{class:"spm-fallback-bar"},[ie[2]||(ie[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:Ce}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",Nm,[se(de,{name:"alert",class:"spm-load-error__icon"}),ie[5]||(ie[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",Pm,[St(ve(c.value.description)+" ",1),f("span",Rm,"("+ve(c.value.errorCode)+")",1)]),f("div",zm,ve(c.value.validatedURL),1),f("p",Hm,ve(c.value.hint),1),f("div",Fm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:D},[se(de,{name:"refresh"}),ie[3]||(ie[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:Ce},[se(de,{name:"external-link"}),ie[4]||(ie[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Ae("",!0)],2)],34)])}}}),Vm=lo(qm,[["__scopeId","data-v-6e363f73"]]);class Km{constructor(){Ie(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Gm{constructor(t){Ie(this,"blockToPageMap",new Map);Ie(this,"debounceCtrl",new Km);Ie(this,"activeBlockId","");Ie(this,"activePageIndex",1);Ie(this,"currentDocId","");Ie(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t,t&&this.blockToPageMap.delete(t)}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&o.startBlockId!==this.currentDocId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;if(this.activeBlockId=t,t===this.currentDocId){this.debounceCtrl.cancel("cursor-navigate");return}const o=this.getPageByBlockId(t);if(!o){this.debounceCtrl.cancel("cursor-navigate");return}this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Pt=null,kn=null,wn="";function qi(){var e,t;if(kn&&(clearTimeout(kn),kn=null),Pt){try{Pt.classList.remove("protyle-wysiwyg--select"),wn?Pt.style.outline=wn:typeof((e=Pt.style)==null?void 0:e.removeProperty)=="function"?Pt.style.removeProperty("outline"):Pt.style&&(Pt.style.outline=""),typeof((t=Pt.style)==null?void 0:t.removeProperty)=="function"?Pt.style.removeProperty("transition"):Pt.style&&(Pt.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Pt=null,wn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,l;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((l=i.style)==null?void 0:l.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function Qo(e,t){var l,r,a,c;if(!e||typeof document>"u")return qi(),!1;qi();const o=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return re.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(a=i.focus)==null||a.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return wn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Pt=i,kn=setTimeout(()=>{qi()},500),!0}function Cl(e){var i,n,s;const t=typeof document<"u"?document:null,o=e||t;if(!o&&!t)return!1;try{const l=(typeof(o==null?void 0:o.querySelectorAll)=="function"?o.querySelectorAll(".protyle-wysiwyg--select"):null)||(typeof(t==null?void 0:t.querySelectorAll)=="function"?t.querySelectorAll(".protyle-wysiwyg--select"):[]);if(l&&l.length>1){const r=new Set;for(let a=0;a<l.length;a++){const c=l[a],u=typeof c.closest=="function"?c.closest("[data-node-id]"):c,h=(i=u==null?void 0:u.getAttribute)==null?void 0:i.call(u,"data-node-id");h?r.add(h):r.add(`elem-${a}`)}if(r.size>1)return!0}}catch{}try{const l=typeof window<"u"?window:globalThis.window,r=typeof(l==null?void 0:l.getSelection)=="function"?l.getSelection():null;if(r&&r.rangeCount>0&&!r.isCollapsed&&typeof r.getRangeAt=="function"){const a=r.getRangeAt(0);if(a){const c=a.startContainer,u=a.endContainer;if(c&&u&&c!==u){const h=c.nodeType===1?c:c.parentElement,m=u.nodeType===1?u:u.parentElement,d=typeof(h==null?void 0:h.closest)=="function"?h.closest("[data-node-id]"):null,b=typeof(m==null?void 0:m.closest)=="function"?m.closest("[data-node-id]"):null,g=(n=d==null?void 0:d.getAttribute)==null?void 0:n.call(d,"data-node-id"),p=(s=b==null?void 0:b.getAttribute)==null?void 0:s.call(b,"data-node-id");if(g&&p&&g!==p)return!0}}}}catch{}return!1}function Ym(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>dt(l)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const l=n.map(r=>dt(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${l}</p>`),n=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();i.push(`<h${a} class="slide-list-item-title">${dt(c)}</h${a}>`)}else n.push(l)}return s(),i.join(`
`)}function Zm(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>dt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function sc(e,t,o){var m,d,b,g;const i=e.split(`
`);if(!i.some(p=>/^(\s*)([-*+]|\d+\.)\s+/.test(p)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const s=[],l=[];let r=!1;for(let p=0;p<i.length;p++){const y=i[p];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const A=x[1].length,T=Math.floor(A/2);l.push({type:"task",level:T,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const k=y.match(/^(\s*)[-*+]\s+(.*)$/);if(k){const A=k[1].length,T=Math.floor(A/2);l.push({type:"unordered",level:T,text:k[2],media:[]});continue}const v=y.match(/^(\s*)\d+\.\s+(.*)$/);if(v){l.length===0&&(r=!0);const A=v[1].length,T=Math.floor(A/2);l.push({type:"ordered",level:T,text:v[2],media:[]});continue}const _=y.trim();if(!(!_||/^\{:.*?\}$/.test(_)))if(l.length>0){const A=_.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const F=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${st(A[1])}" src="${A[2]}" class="${F}" /></div>`);continue}if(_.match(/^<img\b[\s\S]*?\/?>$/i)){const N=_.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(_)){let N=_;if(!/<\/video>/i.test(N))for(;p+1<i.length&&!/<\/video>/i.test(N);)p++,N+=" "+i[p].trim();const F=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-autoplay"])==="true"||/autoplay/i.test(N),H=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(N),U=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-muted"])==="true"||F||/muted/i.test(N),E=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-controls"])==="false",D=N.match(/\bsrc=["']([^"']+)["']/i),S=D?D[1]:"",P=['class="slide-video-player"'];E||P.push("controls"),F&&(P.push("autoplay"),P.push("playsinline")),H&&P.push("loop"),U&&P.push("muted"),P.push('preload="metadata"'),S&&P.push(`src="${S}"`);const j=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let I=j?j[1].trim():"";!I&&S&&(I=`<source src="${S}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${F?"true":"false"}" data-muted="${U?"true":"false"}"><video ${P.join(" ")}>${I}</video></div>`);continue}l[l.length-1].text+=`
`+_}else s.push(_)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(p=>{const y=Ym(p.text),x=p.media&&p.media.length>0?`
${p.media.join(`
`)}`:"",k=p.level||0,v=k>0?` style="margin-left:${(k*1.25).toFixed(2)}em;${p.type==="unordered"?`list-style-type:${k%2===1?"circle":"square"} !important;`:""}"`:"",_=k>0?" slide-list-item--nested":"";if(p.type==="task"){const T=p.checked?' checked=""':"";return`<li class="pdf-task-item${_}"${v}><label><input type="checkbox" disabled=""${T}/> <span>${y}</span></label>${x}</li>`}return`<li${_?` class="${_.trim()}"`:""}${v}>${y}${x}</li>`}).join(`
`);return`${Zm(s)}<${a} class="${c}">
${u}
</${a}>`}function Jm(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<n.length;c++){const u=n[c],h=u.trim();if(/^#{1,6}\s+/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(!h){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(/<video\b/i.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]);let m=h;if(!/<\/video>/i.test(m))for(;c+1<n.length&&!/<\/video>/i.test(m);)c++,m+=`
`+n[c];s.push(m);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,g,p,y;const u=c.trim();if(!u)return"";const h=u.match(/^(#{1,6})\s+(.*)$/);if(h){r=!1;const x=h[1].length;return`<h${x} class="slide-list-item-title">${dt(h[2].trim())}</h${x}>`}const m=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(m){const x=/\.gif(?:\?|$)/i.test(m[2]),k=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(m[1])}" src="${m[2]}" class="${k}" /></div>`}if(/<video\b/i.test(u)){const x=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),k=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-loop"])==="true"||/loop/i.test(u),v=((p=o==null?void 0:o.attributes)==null?void 0:p["custom-slides-muted"])==="true"||x||/muted/i.test(u),_=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),T=A?A[1]:"",N=['class="slide-video-player"'];_||N.push("controls"),x&&N.push("autoplay playsinline"),k&&N.push("loop"),v&&N.push("muted"),N.push('preload="metadata"'),T&&N.push(`src="${T}"`);const F=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let H=F?F[1].trim():"";return!H&&T&&(H=`<source src="${T}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${v?"true":"false"}"><video ${N.join(" ")}>${H}</video></div>`}const d=sc(u,t,o);if(d)return r=!1,d;if(r){r=!1;const x=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${dt(x[0])}</p>`;const k=x[0],_=x.slice(1).map(A=>dt(A)).join("<br/>");return`<p class="slide-list-item-title">${dt(k)}</p>
<p class="slide-list-item-desc">${_}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function bs(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function rc(e,t){var r,a,c,u,h,m,d,b;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(g=>g.slot!=="slot-divider-right"),l=o==="cover"?null:n.find(bs);if(o==="two-cols"){const g=n.some(U=>U.slot==="right");let p=[],y=[];if(g)p=n.filter(U=>U.slot!=="right"),y=n.filter(U=>U.slot==="right");else{const U=Math.ceil(n.length/2);p=n.slice(0,U),y=n.slice(U)}const x=U=>{const E=U.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(E.length>0){const D=E[0],S=(D.rawMarkdown||D.content||"").trim();(Ho(D)||/^(?:[-*+]|\d+\.)\s+/.test(S))&&(D.rawMarkdown=ji(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown)}};x(p),x(y);const k=p.map(U=>Ao(U,t)).join(`
`),v=y.map(U=>Ao(U,t)).join(`
`),_=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",T=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",N=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",H=`style="grid-template-columns: ${gs((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${_}${A}" ${H}>
        <div class="${T}">${k}</div>
        <div class="${N}">${v}</div>
      </div>
    `}if(o==="clover"||fi(o)){const g=o==="clover";let p=[];const y=n.filter(P=>P.slot==="header");if(y.length>0)p=y;else if(n.length>0){const P=n.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));P&&(p=[P])}const x=n.filter(P=>!p.includes(P));let k=2;if(g)k=4;else if(o==="three-cols-header")k=3;else if(o==="two-cols-header")k=2;else{let P=0;for(const j of x){const I=(j.slot||"").match(/^col-(\d+)$/i);I&&(P=Math.max(P,parseInt(I[1],10)))}if(P>=2)k=P;else if((u=e.frontmatter)!=null&&u.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const I=j.split(":").map(M=>parseFloat(M.trim())).filter(M=>!isNaN(M)&&M>0);I.length>=2&&(k=I.length)}else{const I=j.split(/\s+/).filter(Boolean);I.length>=2&&(k=I.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(k=Math.min(6,x[0].children.length))}const v=qs(x,k),_=x.some(P=>P.slot&&/^(?:col-\d+|left|right)$/i.test(P.slot)),A=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||fi(o)&&_,T=P=>{const j=P.filter(M=>!!(M.rawMarkdown||M.content||"").trim());if(A&&j.length>0){const M=j[0],L=(M.rawMarkdown||M.content||"").trim();(Ho(M)||/^(?:[-*+]|\d+\.)\s+/.test(L))&&(M.rawMarkdown=ji(M.rawMarkdown||M.content||""),M.content=M.rawMarkdown),M.isColFirst=!0}const I=A?j.find(bs):null;return j.map(M=>Ao(M,{...t,extraClassName:M===I?"slides-col-first-heading-block":""})).join(`
`)},N=p.find(bs),F=p.map(P=>Ao(P,{...t,extraClassName:P===N?"slides-page-first-heading-block":""})).join(`
`),H=g?"repeat(2, minmax(0, 1fr))":gs((h=e.frontmatter)==null?void 0:h.layoutRatio,k),U=g?`style="grid-template-columns: ${H}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${H};"`,E=[g?"layout-clover-container":"layout-cols-header-container",k===2?"layout-two-cols-header-container":"",k===3?"layout-three-cols-header-container":"",`layout-${o}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),D=[g?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",k===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",k===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),S=v.map((P,j)=>{const I=j+1;return`<div class="${["pdf-col",k===2&&I===1?"pdf-col--left":"",k===2&&I===2?"pdf-col--right":"",`pdf-col--${I}`,`col-${I}`].filter(Boolean).join(" ")}">${T(P)}</div>`}).join(`
`);return`
      <div class="${E}">
        <div class="layout-header-section">${F}</div>
        <div class="${D}" ${U}>
          ${S}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const g=o==="image-right",p=n.map(A=>Ao(A,t)).join(`
`),y=((m=e.frontmatter)==null?void 0:m.image)||((d=e.frontmatter)==null?void 0:d.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${st(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,k=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${p}</div>`,v=g?`${k}
${x}`:`${x}
${k}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${gs((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${v}
      </div>
    `}return o==="fact"?`<div class="layout-fact-container">${n.map(p=>Ao(p,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(p=>Ao(p,t)).join(`
`)}</div>`:n.map(g=>Ao(g,{...t,extraClassName:g===l?"slides-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Xm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,l]=n.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const Qm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=Xa(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Qm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=st(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,h)=>{const d=(r??a??c??u??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return o[r]||""}),n}function eg(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(a=>/^:?-+:?$/.test(a))&&(n=o[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${i.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(a)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function vs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function _l(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${vs(e)}</span>`;const o=[];function i(s,l){return o.push(`<span class="${s}">${vs(l)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>i("token-string",`${l}${r}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=vs(n),n=n.replace(/__TOK_(\d+)__/g,(s,l)=>o[parseInt(l,10)]||""),n}function tg(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),i=a[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function og(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const h=tg(c,u+1);h&&s.push(h)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>n)return[];const h=[];for(const m of c){const d=a(m.children,u+1);u>=i?h.push({...m,children:d}):h.push(...d)}return h}return a(l,1)}function ig(e,t=1,o={}){const i=og(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",l=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const h=`slides-toc-list slides-toc-list-level-${u}`,m=c.map(d=>{const b=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",g=d.children&&d.children.length>0?r(d.children,u+1):"";let p=dt(d.title);return p.includes("LaTeX")&&(p=p.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${p}</span>
          </a>
          ${g}
        </li>
      `}).join("");return`<ol class="${h}">${m}</ol>`}const a=r(i,1);return`<div class="slides-toc${l}"${s}>${a}</div>`}function Ao(e,t){var _,A,T,N,F,H,U,E,D,S,P,j;let o="",i="",n="";const s=[];(_=e.motion)!=null&&_.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((A=e.attributes)==null?void 0:A.style)||"";l&&(s.push(l),n=" slide-styled-block"),s.length>0&&(i=` style="${st(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",h=`${r}${o}${n}${a}${u}`,m=(e.rawMarkdown||e.content||"").trim();if(!m)return`<div class="${h}"${i}></div>`;if(m.includes('class="slides-block-ref"')||m.includes('class="slides-ref-tag"'))return`<div class="${h}"${i}>${m}</div>`;if(m.startsWith("$$")&&m.endsWith("$$")){const I=m.slice(2,-2).trim();return`<div class="${h} katex-display-container"${i}><div class="katex-display font-math"><em>${st(I)}</em></div></div>`}const d=m.match(/^(#{1,6})\s+(.*)$/);if(d){const I=d[1].length,M=dt(d[2]),te=!!(e.isColFirst||e.type==="i"&&((T=t==null?void 0:t.extraClassName)!=null&&T.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${h}"${i}><h${I}${te}>${M}</h${I}></div>`}if(m.startsWith(":::")){const I=m.split(`
`),L=I[0].replace(/^:::\s*/,"").trim()||"info",te=I.slice(1,I[I.length-1].startsWith(":::")?-1:void 0).join(`
`),V=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${h}"${i}><div class="${V} ${V}--${L}"><div class="${V}-title">${L.toUpperCase()}</div><div class="${V}-body">${dt(te)}</div></div></div>`}if(m.startsWith("<<<")){const L=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,le)=>`<span class="code-line shiki-focus"><span class="line-no">${le+1}</span><span class="line-content">${_l(oe,"ts")}</span></span>`).join(`
`),te=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",V=((N=e.attrs)==null?void 0:N["custom-slides-max-height"])||((F=e.attributes)==null?void 0:F["custom-slides-max-height"])||e.maxHeight||"",Z=Ws(String(V||"")),ce=Z?` style="max-height:${st(Z)};overflow-y:auto;"`:"";return`<div class="${h}"${i}><pre class="${te}"${ce}><span class="lang-badge">TS</span><code>${L}</code></pre></div>`}if(m.startsWith("<style")||m.startsWith("<!-- Inline style -->")||m.startsWith(`<!--
Notes`))return"";if(m.startsWith("```")){const I=m.split(`
`),M=I[0].slice(3).trim(),L=M.match(/^([^\s{\[]+)/),te=L?L[1]:"",V=M.match(/\[([^\]]+)\]/),Z=V?V[1]:"",ce=M.includes("twoslash"),oe=e.shikiLines||((H=M.match(/\{([^}]+)\}/))==null?void 0:H[1])||"",le=Xm(oe),Se=I.length>2?I[I.length-1]==="```"?I.slice(1,-1):I.slice(1):[m.slice(3).replace(/```$/,"")],$e=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=Z?`${$e} has-filename`:$e,Ce=le!=="all",R=Se.map((z,C)=>{const $=C+1,G=le==="all"||le.has($)?"code-line shiki-focus":Ce?"code-line shiki-dimmed":"code-line";let Y=(t==null?void 0:t.highlight)===!0?_l(z,te):st(z);return ce&&z.includes("doubled.value = 2")?(Y=Y.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${$}</span><span class="line-content">${Y}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${$}</span><span class="line-content">${Y}</span></span>`}).join(`
`),ie=te?`<span class="lang-badge">${st(te)}</span>`:"",B=Z?`<span class="code-filename">${st(Z)}</span>`:"",W=((U=e.attrs)==null?void 0:U["custom-slides-max-height"])||((E=e.attributes)==null?void 0:E["custom-slides-max-height"])||e.maxHeight||"",w=Ws(String(W||"")),q=w?` style="max-height:${st(w)};overflow-y:auto;"`:"";return`<div class="${h}"${i}><pre class="${ke}"${q}>${B}${ie}<code>${R}</code></pre></div>`}if(m.includes("|")&&m.split(`
`).filter(I=>I.trim().startsWith("|")).length>=2){const I=m.split(`
`).filter(L=>L.trim().startsWith("|")),M=eg(I,t==null?void 0:t.tableClassName);return`<div class="${h}"${i}>${M}</div>`}if(m.startsWith("> ")){const I=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${h}"${i}><blockquote class="${I}"><p>${dt(m.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(m)||e.type==="video"||e.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(m),p=/(?:^|\n)\s*#{1,6}\s+/.test(m);if(b&&!g&&!p&&!m.includes(`
`)){const I=((D=e.attributes)==null?void 0:D["custom-slides-autoplay"])==="true"||/autoplay/i.test(m),M=((S=e.attributes)==null?void 0:S["custom-slides-loop"])==="true"||/loop/i.test(m),L=((P=e.attributes)==null?void 0:P["custom-slides-muted"])==="true"||I||/muted/i.test(m),te=((j=e.attributes)==null?void 0:j["custom-slides-controls"])==="false",V=m.match(/\bsrc=["']([^"']+)["']/i),Z=V?V[1]:"",ce=['class="slide-video-player"'];te||ce.push("controls"),I&&(ce.push("autoplay"),ce.push("playsinline")),M&&ce.push("loop"),L&&ce.push("muted"),ce.push('preload="auto"'),Z&&ce.push(`src="${Z}"`);const oe=m.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let le=oe?oe[1].trim():"";return!le&&Z&&(le=`<source src="${Z}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${h} ${h}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${I?"true":"false"}" data-muted="${L?"true":"false"}"${i}><video ${ce.join(" ")}>${le}</video></div>`}const y=m.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const I=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${h} ${h}--image slide-media-block slide-media-container"${i}><img alt="${st(y[1])}" src="${y[2]}" class="${I}" /></div>`}const x=sc(m,t,e);if(x)return`<div class="${h} pdf-list-item"${i}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(m)&&!m.startsWith("```")){const I=m.match(/minDepth=["']?(\d+)["']?/i),M=m.match(/maxDepth=["']?(\d+)["']?/i),L=m.match(/columns=["']?(\d+)["']?/i),te=(t==null?void 0:t.allSlides)||[];return`<div class="${h}"${i}>${ig(te,(t==null?void 0:t.currentPageIndex)||1,{minDepth:I?parseInt(I[1],10):1,maxDepth:M?parseInt(M[1],10):1/0,columns:L?parseInt(L[1],10):1,textSm:m.includes("text-sm")})}</div>`}if(m.includes(`
`)||p){const I=Jm(m,t,e);if(I)return`<div class="${h}"${i}>${I}</div>`}const v=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${h}"${i}><p${v}>${dt(m)}</p></div>`}function ng(e){return`
    ${Wi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function sg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function rg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function lg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function ag(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ \\t]*[-*+]\\s+|^[ \\t]*\\d+\\.\\s+/, "");
        cleaned = cleaned.replace(/\\n[ \\t]{2,4}/g, "\\n");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}\\s+/.test(md)) return true;
        if (/^(?:[-*+]|\\d+\\.)\\s+#{1,6}\\s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|\\d+\\.)\\s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const allInteractive = div.querySelectorAll("*");
          allInteractive.forEach(btn => {
            let hasNext = false;
            let hasPrev = false;
            for (let i = 0; i < btn.attributes.length; i++) {
              const a = btn.attributes[i];
              const attrName = a.name.toLowerCase();
              if (attrName.indexOf("@click") !== -1 || attrName.indexOf("v-on:click") !== -1) {
                if (a.value.indexOf("next") !== -1) hasNext = true;
                if (a.value.indexOf("prev") !== -1) hasPrev = true;
              }
            }
            if (hasNext) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex + 1);
              });
            } else if (hasPrev) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex - 1);
              });
            }
          });

          return div;
        }

        const hasHeadingTag = /(?:^|\\n)\\s*#{1,6}\\s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\\x60\\x60\\x60")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) && !hasHeadingTag && !md.includes("\\n")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) ||
          (md.includes("\\n") && /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md.split("\\n").slice(1).join("\\n"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("\\n");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^\\{:.*?\\}$/.test(tr)) continue;
            const um = line.match(/^(\\s*)[-*+]\\s+(.*)$/);
            const om = line.match(/^(\\s*)\\d+\\.\\s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^!\\[(.*?)\\]\\((.*?)\\)(?:\\{:?[^}]*\\})?$/);
              if (im) {
                const isGif = /\\.gif(?:\\?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\\b[\\s\\S]*?\\/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/\\s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\\b/i.test(tr)) {
                let vHtml = tr;
                if (!/<\\/video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/<\\/video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "\\n" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})\\s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})\\s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("\\n") + "\\n";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "\\n" + it.media.join("\\n") : "";
            const lines = (it.text || "").split("\\n").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}\\s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("\\n") + med + '</li>';
          }).join("\\n");
          div.innerHTML = leadHtml + '<' + tag + ' class="' + listCls + '">\\n' + liHtml + '\\n</' + tag + '>';
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\\r?\\n/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}\\s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              continue;
            }
            if (/^!\\[.*?\\]\\(.*?\\)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              let vRaw = trimmed;
              if (!/<\\/video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/<\\/video>/i.test(vRaw)) {
                  i++;
                  vRaw += "\\n" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("\\n"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}\\s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\\r?\\n/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>\\n<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("\\n");
          } else {
            const imgMatch = md.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }
`}function cg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function dg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function ug(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function fg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|\\/|data:|assets\\/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function hg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function pg(){return[sg(),rg(),lg(),ag(),cg(),dg(),ug(),fg(),hg()].join("")}function mg(e,t=!1){var l;const o=new Set,i=r=>{if(!r||typeof r!="string")return;const a=r.trim();!a||a.startsWith("data:")||(a.includes("/assets/")||a.startsWith("assets/")||a.startsWith("./assets/")||a.startsWith("/assets/")||t&&/^https?:\/\//i.test(a))&&o.add(a)},n=r=>{if(!r||typeof r!="string")return;const a=/!\[.*?\]\((.+?)\)/g;let c;for(;(c=a.exec(r))!==null;)c[1]&&i(c[1]);const u=/<(?:img|video|audio|source)\b[^>]*?\bsrc=["'](.*?)["']/gi;for(;(c=u.exec(r))!==null;)c[1]&&i(c[1]);const h=/url\(\s*["']?(.*?)["']?\s*\)/gi;for(;(c=h.exec(r))!==null;)c[1]&&i(c[1])},s=r=>{if(r&&(r.rawMarkdown&&n(r.rawMarkdown),r.content&&n(r.content),Array.isArray(r.children)))for(const a of r.children)s(a)};(l=e.config)!=null&&l.background&&i(e.config.background);for(const r of e.slides||[]){if(r.frontmatter)for(const a of Object.values(r.frontmatter))typeof a=="string"&&i(a);if(r.rawMarkdown&&n(r.rawMarkdown),Array.isArray(r.blocks))for(const a of r.blocks)s(a);if(Array.isArray(r.noteBlocks))for(const a of r.noteBlocks)s(a);r.notes&&n(r.notes)}try{const r=JSON.stringify(e),a=/(?:https?:\/\/[^\s"'<>\)\\]+)?(?:\.\/|\/)?assets\/[^\s"'<>\)\\]+/g,c=r.match(a);if(c)for(const u of c)i(u);if(t){const u=/https?:\/\/[^\s"'<>\)\\]+\.(?:png|jpe?g|gif|webp|svg|avif|ico|bmp)(?:\?[^\s"'<>\)\\]*)?/gi,h=r.match(u);if(h)for(const m of h)i(m)}}catch{}return Array.from(o)}async function Ks(e){if(typeof FileReader<"u")return new Promise((n,s)=>{const l=new FileReader;l.onloadend=()=>{typeof l.result=="string"?n(l.result):s(new Error("Failed to convert blob to data URL"))},l.onerror=()=>s(l.error||new Error("FileReader error")),l.readAsDataURL(e)});const t=await e.arrayBuffer(),o=Buffer.from(t);return`data:${e.type||"image/png"};base64,${o.toString("base64")}`}async function Il(e){if(typeof e=="string")return e.startsWith("data:")?e:`data:image/png;base64,${e}`;if(e instanceof ArrayBuffer){const t=new Blob([e]);return Ks(t)}return e instanceof Blob?Ks(e):""}async function gg(e,t){var l,r;const o=mg(e,t==null?void 0:t.includeRemote);if(o.length===0)return{};const i={},n=typeof window<"u"&&((r=(l=window.siyuan)==null?void 0:l.config)==null?void 0:r.apiToken)||"",s=n?{Authorization:`Token ${n}`}:{};for(const a of o){let c="",u=!1;const h=a.indexOf("/assets/");h!==-1?(c=a.slice(h+1),u=!0):a.startsWith("assets/")?(c=a,u=!0):a.startsWith("./assets/")?(c=a.slice(2),u=!0):a.startsWith("/assets/")&&(c=a.slice(1),u=!0);try{let m=null;if(t!=null&&t.fetcher){const d=await t.fetcher(a).catch(()=>null);if(d)m=await Il(d);else if(c&&c!==a){const b=await t.fetcher(`/${c}`).catch(()=>null);b&&(m=await Il(b))}}else if(typeof fetch<"u"){const d=[];(a.startsWith("http://")||a.startsWith("https://"))&&d.push({url:a,headers:u?s:void 0}),u&&c&&(d.push({url:`/${c}`,headers:s}),d.push({url:`./${c}`,headers:s}),d.push({url:c,headers:s})),u||d.push({url:a});for(const b of d)try{const g=await fetch(b.url,{credentials:"include",headers:b.headers});if(g.ok){const p=await g.blob();if(m=await Ks(p),m)break}}catch{}}if(m){const d=[a];c&&d.push(`/${c}`,`./${c}`,c);for(const b of d){i[b]=m;try{i[decodeURI(b)]=m,i[encodeURI(b)]=m}catch{}}}}catch(m){console.warn(`[single-html-exporter] Failed to inline asset "${a}":`,m)}}return i}function yg(e,t){const o=(t==null?void 0:t.title)||"即现演示文稿";let i=e.slides,n={...e.config},s=e.customThemeCss;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const c=t.inlineAssetBase64Map,u=Object.entries(c).sort((d,b)=>b[0].length-d[0].length),h=d=>{if(!d||typeof d!="string")return d;let b=d;for(const[g,p]of u)b.includes(g)&&(b=b.split(g).join(p));return b},m=d=>{const b=h(d.rawMarkdown||""),g=h(d.content||""),p=Array.isArray(d.children)?d.children.map(y=>m(y)):d.children;return{...d,rawMarkdown:b,content:g,children:p}};n.background&&typeof n.background=="string"&&(n.background=h(n.background)),s&&(s=h(s)),i=(e.slides||[]).map(d=>{const b=h(d.rawMarkdown||""),g=(d.blocks||[]).map(m),p=Array.isArray(d.noteBlocks)?d.noteBlocks.map(m):d.noteBlocks,y=h(d.notes||"");let x=d.frontmatter?{...d.frontmatter}:d.frontmatter;if(x)for(const[k,v]of Object.entries(x))typeof v=="string"&&(x[k]=h(v));return{...d,rawMarkdown:b,blocks:g,noteBlocks:p,notes:y,frontmatter:x}})}const l=xr(n.colorSchema),r=JSON.stringify(i),a=JSON.stringify({...n,hostThemeMode:n.hostThemeMode||l});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(o)}</title>
  <style>
${ng(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${r},
      config: ${a}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${l}" data-normalize-headings="${n.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${n.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${n.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${n.theme||"apple-basic"}" id="viewport" data-theme="${l}" data-slides-theme="${n.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${pg()}
  <\/script>
</body>
</html>`}async function lc(e,t){let o=t==null?void 0:t.inlineAssetBase64Map;return(!o||Object.keys(o).length===0)&&(o=await gg(e,t)),yg(e,{...t,inlineAssetBase64Map:o})}function ac(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function bg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function vg(e){const t=bg(e==null?void 0:e.pageRatio);return`
    ${Wi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function kg(e,t){const o="即现演示讲义",i="16:9",n=xr(e.config.colorSchema),s=e.config.theme||"apple-basic",l=e.slides.map((r,a)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,h=u&&u!=="inherit"?u:e.config.spacing||"normal",m=rc(r),d=`${a+1} / ${e.slides.length}`,b=r.frontmatter.background||e.config.background,g=Qa(b),p=g===!0?"light":g===!1?"dark":n,y=b&&!/^(http|\/|data:|assets\/)/.test(b)?`background: ${st(b)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${p} spacing-${h} slides-theme-${s}" data-slides-theme="${s}" style="${y}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(o)} - 高保真讲义</title>
  <style>
    ${vg({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${l}
</body>
</html>`}function cc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=kg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(n=s.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(o),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var mn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function wg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function gn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ks={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var $l;function xg(){return $l||($l=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function l(c,u){if(!n[c]){if(!i[c]){var h=typeof gn=="function"&&gn;if(!u&&h)return h(c,!0);if(r)return r(c,!0);var m=new Error("Cannot find module '"+c+"'");throw m.code="MODULE_NOT_FOUND",m}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(b){var g=i[c][1][b];return l(g||b)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof gn=="function"&&gn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(o,i,n){var s=o("./utils"),l=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,u,h,m,d,b,g,p=[],y=0,x=a.length,k=x,v=s.getTypeOf(a)!=="string";y<a.length;)k=x-y,h=v?(c=a[y++],u=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),u=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),m=c>>2,d=(3&c)<<4|u>>4,b=1<k?(15&u)<<2|h>>6:64,g=2<k?63&h:64,p.push(r.charAt(m)+r.charAt(d)+r.charAt(b)+r.charAt(g));return p.join("")},n.decode=function(a){var c,u,h,m,d,b,g=0,p=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,k=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&k--,a.charAt(a.length-2)===r.charAt(64)&&k--,k%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|k):new Array(0|k);g<a.length;)c=r.indexOf(a.charAt(g++))<<2|(m=r.indexOf(a.charAt(g++)))>>4,u=(15&m)<<4|(d=r.indexOf(a.charAt(g++)))>>2,h=(3&d)<<6|(b=r.indexOf(a.charAt(g++))),x[p++]=c,d!==64&&(x[p++]=u),b!==64&&(x[p++]=h);return x}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),l=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),a=o("./stream/DataLengthProbe");function c(u,h,m,d,b){this.compressedSize=u,this.uncompressedSize=h,this.crc32=m,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return u.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,h,m){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(h.compressWorker(m)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();i.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,h,m){var d=l,b=m+h;c^=-1;for(var g=m;g<b;g++)c=c>>>8^d[255&(c^u[g])];return-1^c})(0|a,r,r.length,0):(function(c,u,h,m){var d=l,b=m+h;c^=-1;for(var g=m;g<b;g++)c=c>>>8^d[255&(c^u.charCodeAt(g))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=o("pako"),r=o("./utils"),a=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(h,m){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=m,this.meta={}}n.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,h.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(m){h.push({data:m,meta:h.meta})}},n.compressWorker=function(h){return new u("Deflate",h)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,b){var g,p="";for(g=0;g<b;g++)p+=String.fromCharCode(255&d),d>>>=8;return p}function l(d,b,g,p,y,x){var k,v,_=d.file,A=d.compression,T=x!==c.utf8encode,N=r.transformTo("string",x(_.name)),F=r.transformTo("string",c.utf8encode(_.name)),H=_.comment,U=r.transformTo("string",x(H)),E=r.transformTo("string",c.utf8encode(H)),D=F.length!==_.name.length,S=E.length!==H.length,P="",j="",I="",M=_.dir,L=_.date,te={crc32:0,compressedSize:0,uncompressedSize:0};b&&!g||(te.crc32=d.crc32,te.compressedSize=d.compressedSize,te.uncompressedSize=d.uncompressedSize);var V=0;b&&(V|=8),T||!D&&!S||(V|=2048);var Z=0,ce=0;M&&(Z|=16),y==="UNIX"?(ce=798,Z|=(function(le,Se){var $e=le;return le||($e=Se?16893:33204),(65535&$e)<<16})(_.unixPermissions,M)):(ce=20,Z|=(function(le){return 63&(le||0)})(_.dosPermissions)),k=L.getUTCHours(),k<<=6,k|=L.getUTCMinutes(),k<<=5,k|=L.getUTCSeconds()/2,v=L.getUTCFullYear()-1980,v<<=4,v|=L.getUTCMonth()+1,v<<=5,v|=L.getUTCDate(),D&&(j=s(1,1)+s(u(N),4)+F,P+="up"+s(j.length,2)+j),S&&(I=s(1,1)+s(u(U),4)+E,P+="uc"+s(I.length,2)+I);var oe="";return oe+=`
\0`,oe+=s(V,2),oe+=A.magic,oe+=s(k,2),oe+=s(v,2),oe+=s(te.crc32,4),oe+=s(te.compressedSize,4),oe+=s(te.uncompressedSize,4),oe+=s(N.length,2),oe+=s(P.length,2),{fileRecord:h.LOCAL_FILE_HEADER+oe+N+P,dirRecord:h.CENTRAL_FILE_HEADER+s(ce,2)+oe+s(U.length,2)+"\0\0\0\0"+s(Z,4)+s(p,4)+N+P+U}}var r=o("../utils"),a=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),h=o("../signature");function m(d,b,g,p){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=g,this.encodeFileName=p,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(m,a),m.prototype.push=function(d){var b=d.meta.percent||0,g=this.entriesCount,p=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:g?(b+100*(g-p-1))/g:100}}))},m.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var g=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:g.fileRecord,meta:{percent:0}})}else this.accumulate=!0},m.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,g=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(g.dirRecord),b)this.push({data:(function(p){return h.DATA_DESCRIPTOR+s(p.crc32,4)+s(p.compressedSize,4)+s(p.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:g.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},m.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var g=this.bytesWritten-d,p=(function(y,x,k,v,_){var A=r.transformTo("string",_(v));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(y,2)+s(y,2)+s(x,4)+s(k,4)+s(A.length,2)+A})(this.dirRecords.length,g,d,this.zipComment,this.encodeFileName);this.push({data:p,meta:{percent:100}})},m.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},m.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(g){b.processChunk(g)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(g){b.error(g)}),this},m.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},m.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var g=0;g<b.length;g++)try{b[g].error(d)}catch{}return!0},m.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},i.exports=m},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),l=o("./ZipFileWorker");n.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{r.forEach(function(m,d){h++;var b=(function(x,k){var v=x||k,_=s[v];if(!_)throw new Error(v+" is not a valid compression method !");return _})(d.options.compression,a.compression),g=d.options.compressionOptions||a.compressionOptions||{},p=d.dir,y=d.date;d._compressWorker(b,g).withStreamInfo("file",{name:m,dir:p,date:y,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=h}catch(m){u.error(m)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),l=o("./external"),r=o("./utf8"),a=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function h(m){return new l.Promise(function(d,b){var g=m.decompressed.getContentWorker().pipe(new c);g.on("error",function(p){b(p)}).on("end",function(){g.streamInfo.crc32!==m.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(m,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(m)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",m,!0,d.optimizedBinaryString,d.base64).then(function(g){var p=new a(d);return p.load(g),p}).then(function(g){var p=[l.Promise.resolve(g)],y=g.files;if(d.checkCRC32)for(var x=0;x<y.length;x++)p.push(h(y[x]));return l.Promise.all(p)}).then(function(g){for(var p=g.shift(),y=p.files,x=0;x<y.length;x++){var k=y[x],v=k.fileNameStr,_=s.resolve(k.fileNameStr);b.file(_,k.decompressed,{binary:!0,optimizedBinaryString:!0,date:k.date,dir:k.dir,comment:k.fileCommentStr.length?k.fileCommentStr:null,unixPermissions:k.unixPermissions,dosPermissions:k.dosPermissions,createFolders:d.createFolders}),k.dir||(b.file(_).unsafeOriginalName=v)}return p.zipComment.length&&(b.comment=p.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),l=o("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(h,m){u.push(h)||u._helper.pause(),c&&c(m)}).on("error",function(h){u.emit("error",h)}).on("end",function(){u.push(null)})}o("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},i.exports=l},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(_,A,T){var N,F=r.getTypeOf(A),H=r.extend(T||{},u);H.date=H.date||new Date,H.compression!==null&&(H.compression=H.compression.toUpperCase()),typeof H.unixPermissions=="string"&&(H.unixPermissions=parseInt(H.unixPermissions,8)),H.unixPermissions&&16384&H.unixPermissions&&(H.dir=!0),H.dosPermissions&&16&H.dosPermissions&&(H.dir=!0),H.dir&&(_=y(_)),H.createFolders&&(N=p(_))&&x.call(this,N,!0);var U=F==="string"&&H.binary===!1&&H.base64===!1;T&&T.binary!==void 0||(H.binary=!U),(A instanceof h&&A.uncompressedSize===0||H.dir||!A||A.length===0)&&(H.base64=!1,H.binary=!0,A="",H.compression="STORE",F="string");var E=null;E=A instanceof h||A instanceof a?A:b.isNode&&b.isStream(A)?new g(_,A):r.prepareContent(_,A,H.binary,H.optimizedBinaryString,H.base64);var D=new m(_,E,H);this.files[_]=D}var l=o("./utf8"),r=o("./utils"),a=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),h=o("./compressedObject"),m=o("./zipObject"),d=o("./generate"),b=o("./nodejsUtils"),g=o("./nodejs/NodejsStreamInputAdapter"),p=function(_){_.slice(-1)==="/"&&(_=_.substring(0,_.length-1));var A=_.lastIndexOf("/");return 0<A?_.substring(0,A):""},y=function(_){return _.slice(-1)!=="/"&&(_+="/"),_},x=function(_,A){return A=A!==void 0?A:u.createFolders,_=y(_),this.files[_]||s.call(this,_,null,{dir:!0,createFolders:A}),this.files[_]};function k(_){return Object.prototype.toString.call(_)==="[object RegExp]"}var v={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(_){var A,T,N;for(A in this.files)N=this.files[A],(T=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&_(T,N)},filter:function(_){var A=[];return this.forEach(function(T,N){_(T,N)&&A.push(N)}),A},file:function(_,A,T){if(arguments.length!==1)return _=this.root+_,s.call(this,_,A,T),this;if(k(_)){var N=_;return this.filter(function(H,U){return!U.dir&&N.test(H)})}var F=this.files[this.root+_];return F&&!F.dir?F:null},folder:function(_){if(!_)return this;if(k(_))return this.filter(function(F,H){return H.dir&&_.test(F)});var A=this.root+_,T=x.call(this,A),N=this.clone();return N.root=T.name,N},remove:function(_){_=this.root+_;var A=this.files[_];if(A||(_.slice(-1)!=="/"&&(_+="/"),A=this.files[_]),A&&!A.dir)delete this.files[_];else for(var T=this.filter(function(F,H){return H.name.slice(0,_.length)===_}),N=0;N<T.length;N++)delete this.files[T[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(_){var A,T={};try{if((T=r.extend(_||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=T.type.toLowerCase(),T.compression=T.compression.toUpperCase(),T.type==="binarystring"&&(T.type="string"),!T.type)throw new Error("No output type specified.");r.checkSupport(T.type),T.platform!=="darwin"&&T.platform!=="freebsd"&&T.platform!=="linux"&&T.platform!=="sunos"||(T.platform="UNIX"),T.platform==="win32"&&(T.platform="DOS");var N=T.comment||this.comment||"";A=d.generateWorker(this,T,N)}catch(F){(A=new a("error")).error(F)}return new c(A,T.type||"string",T.mimeType)},generateAsync:function(_,A){return this.generateInternalStream(_).accumulate(A)},generateNodeStream:function(_,A){return(_=_||{}).type||(_.type="nodebuffer"),this.generateInternalStream(_).toNodejsStream(A)}};i.exports=v},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),m=this.length-4;0<=m;--m)if(this.data[m]===a&&this.data[m+1]===c&&this.data[m+2]===u&&this.data[m+3]===h)return m-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),m=this.readData(4);return a===m[0]&&c===m[1]&&u===m[2]&&h===m[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=l},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),l=o("../support"),r=o("./ArrayReader"),a=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(h){var m=s.getTypeOf(h);return s.checkSupport(m),m!=="string"||l.uint8array?m==="nodebuffer"?new c(h):l.uint8array?new u(s.transformTo("uint8array",h)):new r(s.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),l=o("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),l=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),l=o("./ConvertWorker"),r=o("./GenericWorker"),a=o("../base64"),c=o("../support"),u=o("../external"),h=null;if(c.nodestream)try{h=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function m(b,g){return new u.Promise(function(p,y){var x=[],k=b._internalType,v=b._outputType,_=b._mimeType;b.on("data",function(A,T){x.push(A),g&&g(T)}).on("error",function(A){x=[],y(A)}).on("end",function(){try{var A=(function(T,N,F){switch(T){case"blob":return s.newBlob(s.transformTo("arraybuffer",N),F);case"base64":return a.encode(N);default:return s.transformTo(T,N)}})(v,(function(T,N){var F,H=0,U=null,E=0;for(F=0;F<N.length;F++)E+=N[F].length;switch(T){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(U=new Uint8Array(E),F=0;F<N.length;F++)U.set(N[F],H),H+=N[F].length;return U;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+T+"'")}})(k,x),_);p(A)}catch(T){y(T)}x=[]}).resume()})}function d(b,g,p){var y=g;switch(g){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=g,this._mimeType=p,s.checkSupport(y),this._worker=b.pipe(new l(y)),b.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(b){return m(this,b)},on:function(b,g){var p=this;return b==="data"?this._worker.on(b,function(y){g.call(p,y.data,y.meta)}):this._worker.on(b,function(){s.delay(g,arguments,p)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},b)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),l=o("./support"),r=o("./nodejsUtils"),a=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function m(){a.call(this,"utf-8 encode")}n.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var g,p,y,x,k,v=b.length,_=0;for(x=0;x<v;x++)(64512&(p=b.charCodeAt(x)))==55296&&x+1<v&&(64512&(y=b.charCodeAt(x+1)))==56320&&(p=65536+(p-55296<<10)+(y-56320),x++),_+=p<128?1:p<2048?2:p<65536?3:4;for(g=l.uint8array?new Uint8Array(_):new Array(_),x=k=0;k<_;x++)(64512&(p=b.charCodeAt(x)))==55296&&x+1<v&&(64512&(y=b.charCodeAt(x+1)))==56320&&(p=65536+(p-55296<<10)+(y-56320),x++),p<128?g[k++]=p:(p<2048?g[k++]=192|p>>>6:(p<65536?g[k++]=224|p>>>12:(g[k++]=240|p>>>18,g[k++]=128|p>>>12&63),g[k++]=128|p>>>6&63),g[k++]=128|63&p);return g})(d)},n.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var g,p,y,x,k=b.length,v=new Array(2*k);for(g=p=0;g<k;)if((y=b[g++])<128)v[p++]=y;else if(4<(x=c[y]))v[p++]=65533,g+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&g<k;)y=y<<6|63&b[g++],x--;1<x?v[p++]=65533:y<65536?v[p++]=y:(y-=65536,v[p++]=55296|y>>10&1023,v[p++]=56320|1023&y)}return v.length!==p&&(v.subarray?v=v.subarray(0,p):v.length=p),s.applyFromCharCode(v)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(h,a),h.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var g=b;(b=new Uint8Array(g.length+this.leftOver.length)).set(this.leftOver,0),b.set(g,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var p=(function(x,k){var v;for((k=k||x.length)>x.length&&(k=x.length),v=k-1;0<=v&&(192&x[v])==128;)v--;return v<0||v===0?k:v+c[x[v]]>k?v:k})(b),y=b;p!==b.length&&(l.uint8array?(y=b.subarray(0,p),this.leftOver=b.subarray(p,b.length)):(y=b.slice(0,p),this.leftOver=b.slice(p,b.length))),this.push({data:n.utf8decode(y),meta:d.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=h,s.inherits(m,a),m.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=m},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),l=o("./base64"),r=o("./nodejsUtils"),a=o("./external");function c(g){return g}function u(g,p){for(var y=0;y<g.length;++y)p[y]=255&g.charCodeAt(y);return p}o("setimmediate"),n.newBlob=function(g,p){n.checkSupport("blob");try{return new Blob([g],{type:p})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(g),y.getBlob(p)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(g,p,y){var x=[],k=0,v=g.length;if(v<=y)return String.fromCharCode.apply(null,g);for(;k<v;)p==="array"||p==="nodebuffer"?x.push(String.fromCharCode.apply(null,g.slice(k,Math.min(k+y,v)))):x.push(String.fromCharCode.apply(null,g.subarray(k,Math.min(k+y,v)))),k+=y;return x.join("")},stringifyByChar:function(g){for(var p="",y=0;y<g.length;y++)p+=String.fromCharCode(g[y]);return p},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function m(g){var p=65536,y=n.getTypeOf(g),x=!0;if(y==="uint8array"?x=h.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=h.applyCanBeUsed.nodebuffer),x)for(;1<p;)try{return h.stringifyByChunk(g,y,p)}catch{p=Math.floor(p/2)}return h.stringifyByChar(g)}function d(g,p){for(var y=0;y<g.length;y++)p[y]=g[y];return p}n.applyFromCharCode=m;var b={};b.string={string:c,array:function(g){return u(g,new Array(g.length))},arraybuffer:function(g){return b.string.uint8array(g).buffer},uint8array:function(g){return u(g,new Uint8Array(g.length))},nodebuffer:function(g){return u(g,r.allocBuffer(g.length))}},b.array={string:m,array:c,arraybuffer:function(g){return new Uint8Array(g).buffer},uint8array:function(g){return new Uint8Array(g)},nodebuffer:function(g){return r.newBufferFrom(g)}},b.arraybuffer={string:function(g){return m(new Uint8Array(g))},array:function(g){return d(new Uint8Array(g),new Array(g.byteLength))},arraybuffer:c,uint8array:function(g){return new Uint8Array(g)},nodebuffer:function(g){return r.newBufferFrom(new Uint8Array(g))}},b.uint8array={string:m,array:function(g){return d(g,new Array(g.length))},arraybuffer:function(g){return g.buffer},uint8array:c,nodebuffer:function(g){return r.newBufferFrom(g)}},b.nodebuffer={string:m,array:function(g){return d(g,new Array(g.length))},arraybuffer:function(g){return b.nodebuffer.uint8array(g).buffer},uint8array:function(g){return d(g,new Uint8Array(g.length))},nodebuffer:c},n.transformTo=function(g,p){if(p=p||"",!g)return p;n.checkSupport(g);var y=n.getTypeOf(p);return b[y][g](p)},n.resolve=function(g){for(var p=g.split("/"),y=[],x=0;x<p.length;x++){var k=p[x];k==="."||k===""&&x!==0&&x!==p.length-1||(k===".."?y.pop():y.push(k))}return y.join("/")},n.getTypeOf=function(g){return typeof g=="string"?"string":Object.prototype.toString.call(g)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(g)?"nodebuffer":s.uint8array&&g instanceof Uint8Array?"uint8array":s.arraybuffer&&g instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(g){if(!s[g.toLowerCase()])throw new Error(g+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(g){var p,y,x="";for(y=0;y<(g||"").length;y++)x+="\\x"+((p=g.charCodeAt(y))<16?"0":"")+p.toString(16).toUpperCase();return x},n.delay=function(g,p,y){setImmediate(function(){g.apply(y||null,p||[])})},n.inherits=function(g,p){function y(){}y.prototype=p.prototype,g.prototype=new y},n.extend=function(){var g,p,y={};for(g=0;g<arguments.length;g++)for(p in arguments[g])Object.prototype.hasOwnProperty.call(arguments[g],p)&&y[p]===void 0&&(y[p]=arguments[g][p]);return y},n.prepareContent=function(g,p,y,x,k){return a.Promise.resolve(p).then(function(v){return s.blob&&(v instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(v))!==-1)&&typeof FileReader<"u"?new a.Promise(function(_,A){var T=new FileReader;T.onload=function(N){_(N.target.result)},T.onerror=function(N){A(N.target.error)},T.readAsArrayBuffer(v)}):v}).then(function(v){var _=n.getTypeOf(v);return _?(_==="arraybuffer"?v=n.transformTo("uint8array",v):_==="string"&&(k?v=l.decode(v):y&&x!==!0&&(v=(function(A){return u(A,s.uint8array?new Uint8Array(A.length):new Array(A.length))})(v))),v):a.Promise.reject(new Error("Can't read the data of '"+g+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./signature"),a=o("./zipEntry"),c=o("./support");function u(h){this.files=[],this.loadOptions=h}u.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var m=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(m)+", expected "+l.pretty(h)+")")}},isSignature:function(h,m){var d=this.reader.index;this.reader.setIndex(h);var b=this.reader.readString(4)===m;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),m=c.uint8array?"uint8array":"array",d=l.transformTo(m,h);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,m,d,b=this.zip64EndOfCentralSize-44;0<b;)h=this.reader.readInt(2),m=this.reader.readInt(4),d=this.reader.readData(m),this.zip64ExtensibleData[h]={id:h,length:m,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,m;for(h=0;h<this.files.length;h++)m=this.files[h],this.reader.setIndex(m.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),m.readLocalPart(this.reader),m.handleUTF8(),m.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var m=h;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=m-d;if(0<b)this.isSignature(m,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(h){this.reader=s(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./compressedObject"),a=o("./crc32"),c=o("./utf8"),u=o("./compressions"),h=o("./support");function m(d,b){this.options=d,this.loadOptions=b}m.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,g;if(d.skip(22),this.fileNameLength=d.readInt(2),g=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(g),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(p){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===p)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,g,p,y=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<y;)b=d.readInt(2),g=d.readInt(2),p=d.readData(g),this.extraFields[b]={id:b,length:g,value:p};d.setIndex(y)},handleUTF8:function(){var d=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var g=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(g)}var p=this.findExtraFieldUnicodeComment();if(p!==null)this.fileCommentStr=p;else{var y=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},i.exports=m},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(b,g,p){this.name=b,this.dir=p.dir,this.date=p.date,this.comment=p.comment,this.unixPermissions=p.unixPermissions,this.dosPermissions=p.dosPermissions,this._data=g,this._dataBinary=p.binary,this.options={compression:p.compression,compressionOptions:p.compressionOptions}}var l=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),a=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(b){var g=null,p="string";try{if(!b)throw new Error("No output type specified.");var y=(p=b.toLowerCase())==="string"||p==="text";p!=="binarystring"&&p!=="text"||(p="string"),g=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(g=g.pipe(new a.Utf8EncodeWorker)),!x&&y&&(g=g.pipe(new a.Utf8DecodeWorker))}catch(k){(g=new u("error")).error(k)}return new l(g,p,"")},async:function(b,g){return this.internalStream(b).accumulate(g)},nodeStream:function(b,g){return this.internalStream(b||"nodebuffer").toNodejsStream(g)},_compressWorker:function(b,g){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var p=this._decompressWorker();return this._dataBinary||(p=p.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(p,b,g)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],m=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<h.length;d++)s.prototype[h[d]]=m;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),h=s.document.createTextNode("");u.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var g=s.document.createElement("script");g.onreadystatechange=function(){b(),g.onreadystatechange=null,g.parentNode.removeChild(g),g=null},s.document.documentElement.appendChild(g)}:function(){setTimeout(b,0)};else{var m=new s.MessageChannel;m.port1.onmessage=b,l=function(){m.port2.postMessage(0)}}var d=[];function b(){var g,p;r=!0;for(var y=d.length;y;){for(p=d,d=[],g=-1;++g<y;)p[g]();y=d.length}r=!1}i.exports=function(g){d.push(g)!==1||r||l()}}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function h(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==l&&g(this,y)}function m(y,x,k){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof k=="function"&&(this.onRejected=k,this.callRejected=this.otherCallRejected)}function d(y,x,k){s(function(){var v;try{v=x(k)}catch(_){return r.reject(y,_)}v===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,v)})}function b(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function g(y,x){var k=!1;function v(T){k||(k=!0,r.reject(y,T))}function _(T){k||(k=!0,r.resolve(y,T))}var A=p(function(){x(_,v)});A.status==="error"&&v(A.value)}function p(y,x){var k={};try{k.value=y(x),k.status="success"}catch(v){k.status="error",k.value=v}return k}(i.exports=h).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(k){return x.resolve(y()).then(function(){return k})},function(k){return x.resolve(y()).then(function(){throw k})})},h.prototype.catch=function(y){return this.then(null,y)},h.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var k=new this.constructor(l);return this.state!==u?d(k,this.state===c?y:x,this.outcome):this.queue.push(new m(k,y,x)),k},m.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},m.prototype.otherCallFulfilled=function(y){d(this.promise,this.onFulfilled,y)},m.prototype.callRejected=function(y){r.reject(this.promise,y)},m.prototype.otherCallRejected=function(y){d(this.promise,this.onRejected,y)},r.resolve=function(y,x){var k=p(b,x);if(k.status==="error")return r.reject(y,k.value);var v=k.value;if(v)g(y,v);else{y.state=c,y.outcome=x;for(var _=-1,A=y.queue.length;++_<A;)y.queue[_].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var k=-1,v=y.queue.length;++k<v;)y.queue[k].callRejected(x);return y},h.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},h.reject=function(y){var x=new this(l);return r.reject(x,y)},h.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=y.length,v=!1;if(!k)return this.resolve([]);for(var _=new Array(k),A=0,T=-1,N=new this(l);++T<k;)F(y[T],T);return N;function F(H,U){x.resolve(H).then(function(E){_[U]=E,++A!==k||v||(v=!0,r.resolve(N,_))},function(E){v||(v=!0,r.reject(N,E))})}},h.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=y.length,v=!1;if(!k)return this.resolve([]);for(var _=-1,A=new this(l);++_<k;)T=y[_],x.resolve(T).then(function(N){v||(v=!0,r.resolve(A,N))},function(N){v||(v=!0,r.reject(A,N))});var T;return A}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,h=0,m=-1,d=0,b=8;function g(y){if(!(this instanceof g))return new g(y);this.options=l.assign({level:m,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var k=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(k!==h)throw new Error(a[k]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var v;if(v=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(k=s.deflateSetDictionary(this.strm,v))!==h)throw new Error(a[k]);this._dict_set=!0}}function p(y,x){var k=new g(x);if(k.push(y,!0),k.err)throw k.msg||a[k.err];return k.result}g.prototype.push=function(y,x){var k,v,_=this.strm,A=this.options.chunkSize;if(this.ended)return!1;v=x===~~x?x:x===!0?4:0,typeof y=="string"?_.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?_.input=new Uint8Array(y):_.input=y,_.next_in=0,_.avail_in=_.input.length;do{if(_.avail_out===0&&(_.output=new l.Buf8(A),_.next_out=0,_.avail_out=A),(k=s.deflate(_,v))!==1&&k!==h)return this.onEnd(k),!(this.ended=!0);_.avail_out!==0&&(_.avail_in!==0||v!==4&&v!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(_.output,_.next_out))):this.onData(l.shrinkBuf(_.output,_.next_out)))}while((0<_.avail_in||_.avail_out===0)&&k!==1);return v===4?(k=s.deflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===h):v!==2||(this.onEnd(h),!(_.avail_out=0))},g.prototype.onData=function(y){this.chunks.push(y)},g.prototype.onEnd=function(y){y===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},n.Deflate=g,n.deflate=p,n.deflateRaw=function(y,x){return(x=x||{}).raw=!0,p(y,x)},n.gzip=function(y,x){return(x=x||{}).gzip=!0,p(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),h=o("./zlib/gzheader"),m=Object.prototype.toString;function d(g){if(!(this instanceof d))return new d(g);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},g||{});var p=this.options;p.raw&&0<=p.windowBits&&p.windowBits<16&&(p.windowBits=-p.windowBits,p.windowBits===0&&(p.windowBits=-15)),!(0<=p.windowBits&&p.windowBits<16)||g&&g.windowBits||(p.windowBits+=32),15<p.windowBits&&p.windowBits<48&&(15&p.windowBits)==0&&(p.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=s.inflateInit2(this.strm,p.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new h,s.inflateGetHeader(this.strm,this.header)}function b(g,p){var y=new d(p);if(y.push(g,!0),y.err)throw y.msg||c[y.err];return y.result}d.prototype.push=function(g,p){var y,x,k,v,_,A,T=this.strm,N=this.options.chunkSize,F=this.options.dictionary,H=!1;if(this.ended)return!1;x=p===~~p?p:p===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof g=="string"?T.input=r.binstring2buf(g):m.call(g)==="[object ArrayBuffer]"?T.input=new Uint8Array(g):T.input=g,T.next_in=0,T.avail_in=T.input.length;do{if(T.avail_out===0&&(T.output=new l.Buf8(N),T.next_out=0,T.avail_out=N),(y=s.inflate(T,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&F&&(A=typeof F=="string"?r.string2buf(F):m.call(F)==="[object ArrayBuffer]"?new Uint8Array(F):F,y=s.inflateSetDictionary(this.strm,A)),y===a.Z_BUF_ERROR&&H===!0&&(y=a.Z_OK,H=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);T.next_out&&(T.avail_out!==0&&y!==a.Z_STREAM_END&&(T.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(k=r.utf8border(T.output,T.next_out),v=T.next_out-k,_=r.buf2string(T.output,k),T.next_out=v,T.avail_out=N-v,v&&l.arraySet(T.output,T.output,k,v,0),this.onData(_)):this.onData(l.shrinkBuf(T.output,T.next_out)))),T.avail_in===0&&T.avail_out===0&&(H=!0)}while((0<T.avail_in||T.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=s.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(T.avail_out=0))},d.prototype.onData=function(g){this.chunks.push(g)},d.prototype.onEnd=function(g){g===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=g,this.msg=this.strm.msg},n.Inflate=d,n.inflate=b,n.inflateRaw=function(g,p){return(p=p||{}).raw=!0,b(g,p)},n.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var h in u)u.hasOwnProperty(h)&&(a[h]=u[h])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,h,m){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+h),m);else for(var d=0;d<h;d++)a[m+d]=c[u+d]},flattenChunks:function(a){var c,u,h,m,d,b;for(c=h=0,u=a.length;c<u;c++)h+=a[c].length;for(b=new Uint8Array(h),c=m=0,u=a.length;c<u;c++)d=a[c],b.set(d,m),m+=d.length;return b}},r={arraySet:function(a,c,u,h,m){for(var d=0;d<h;d++)a[m+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(h,m){if(m<65537&&(h.subarray&&r||!h.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(h,m));for(var d="",b=0;b<m;b++)d+=String.fromCharCode(h[b]);return d}a[254]=a[254]=1,n.string2buf=function(h){var m,d,b,g,p,y=h.length,x=0;for(g=0;g<y;g++)(64512&(d=h.charCodeAt(g)))==55296&&g+1<y&&(64512&(b=h.charCodeAt(g+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),g++),x+=d<128?1:d<2048?2:d<65536?3:4;for(m=new s.Buf8(x),g=p=0;p<x;g++)(64512&(d=h.charCodeAt(g)))==55296&&g+1<y&&(64512&(b=h.charCodeAt(g+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),g++),d<128?m[p++]=d:(d<2048?m[p++]=192|d>>>6:(d<65536?m[p++]=224|d>>>12:(m[p++]=240|d>>>18,m[p++]=128|d>>>12&63),m[p++]=128|d>>>6&63),m[p++]=128|63&d);return m},n.buf2binstring=function(h){return u(h,h.length)},n.binstring2buf=function(h){for(var m=new s.Buf8(h.length),d=0,b=m.length;d<b;d++)m[d]=h.charCodeAt(d);return m},n.buf2string=function(h,m){var d,b,g,p,y=m||h.length,x=new Array(2*y);for(d=b=0;d<y;)if((g=h[d++])<128)x[b++]=g;else if(4<(p=a[g]))x[b++]=65533,d+=p-1;else{for(g&=p===2?31:p===3?15:7;1<p&&d<y;)g=g<<6|63&h[d++],p--;1<p?x[b++]=65533:g<65536?x[b++]=g:(g-=65536,x[b++]=55296|g>>10&1023,x[b++]=56320|1023&g)}return u(x,b)},n.utf8border=function(h,m){var d;for((m=m||h.length)>h.length&&(m=h.length),d=m-1;0<=d&&(192&h[d])==128;)d--;return d<0||d===0?m:d+a[h[d]]>m?d:m}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,h=0;r!==0;){for(r-=h=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--h;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();i.exports=function(l,r,a,c){var u=s,h=c+a;l^=-1;for(var m=c;m<h;m++)l=l>>>8^u[255&(l^r[m])];return-1^l}},{}],46:[function(o,i,n){var s,l=o("../utils/common"),r=o("./trees"),a=o("./adler32"),c=o("./crc32"),u=o("./messages"),h=0,m=4,d=0,b=-2,g=-1,p=4,y=2,x=8,k=9,v=286,_=30,A=19,T=2*v+1,N=15,F=3,H=258,U=H+F+1,E=42,D=113,S=1,P=2,j=3,I=4;function M(w,q){return w.msg=u[q],q}function L(w){return(w<<1)-(4<w?9:0)}function te(w){for(var q=w.length;0<=--q;)w[q]=0}function V(w){var q=w.state,z=q.pending;z>w.avail_out&&(z=w.avail_out),z!==0&&(l.arraySet(w.output,q.pending_buf,q.pending_out,z,w.next_out),w.next_out+=z,q.pending_out+=z,w.total_out+=z,w.avail_out-=z,q.pending-=z,q.pending===0&&(q.pending_out=0))}function Z(w,q){r._tr_flush_block(w,0<=w.block_start?w.block_start:-1,w.strstart-w.block_start,q),w.block_start=w.strstart,V(w.strm)}function ce(w,q){w.pending_buf[w.pending++]=q}function oe(w,q){w.pending_buf[w.pending++]=q>>>8&255,w.pending_buf[w.pending++]=255&q}function le(w,q){var z,C,$=w.max_chain_length,O=w.strstart,G=w.prev_length,K=w.nice_match,Y=w.strstart>w.w_size-U?w.strstart-(w.w_size-U):0,X=w.window,ae=w.w_mask,ne=w.prev,me=w.strstart+H,_e=X[O+G-1],we=X[O+G];w.prev_length>=w.good_match&&($>>=2),K>w.lookahead&&(K=w.lookahead);do if(X[(z=q)+G]===we&&X[z+G-1]===_e&&X[z]===X[O]&&X[++z]===X[O+1]){O+=2,z++;do;while(X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&X[++O]===X[++z]&&O<me);if(C=H-(me-O),O=me-H,G<C){if(w.match_start=q,K<=(G=C))break;_e=X[O+G-1],we=X[O+G]}}while((q=ne[q&ae])>Y&&--$!=0);return G<=w.lookahead?G:w.lookahead}function Se(w){var q,z,C,$,O,G,K,Y,X,ae,ne=w.w_size;do{if($=w.window_size-w.lookahead-w.strstart,w.strstart>=ne+(ne-U)){for(l.arraySet(w.window,w.window,ne,ne,0),w.match_start-=ne,w.strstart-=ne,w.block_start-=ne,q=z=w.hash_size;C=w.head[--q],w.head[q]=ne<=C?C-ne:0,--z;);for(q=z=ne;C=w.prev[--q],w.prev[q]=ne<=C?C-ne:0,--z;);$+=ne}if(w.strm.avail_in===0)break;if(G=w.strm,K=w.window,Y=w.strstart+w.lookahead,X=$,ae=void 0,ae=G.avail_in,X<ae&&(ae=X),z=ae===0?0:(G.avail_in-=ae,l.arraySet(K,G.input,G.next_in,ae,Y),G.state.wrap===1?G.adler=a(G.adler,K,ae,Y):G.state.wrap===2&&(G.adler=c(G.adler,K,ae,Y)),G.next_in+=ae,G.total_in+=ae,ae),w.lookahead+=z,w.lookahead+w.insert>=F)for(O=w.strstart-w.insert,w.ins_h=w.window[O],w.ins_h=(w.ins_h<<w.hash_shift^w.window[O+1])&w.hash_mask;w.insert&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[O+F-1])&w.hash_mask,w.prev[O&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=O,O++,w.insert--,!(w.lookahead+w.insert<F)););}while(w.lookahead<U&&w.strm.avail_in!==0)}function $e(w,q){for(var z,C;;){if(w.lookahead<U){if(Se(w),w.lookahead<U&&q===h)return S;if(w.lookahead===0)break}if(z=0,w.lookahead>=F&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+F-1])&w.hash_mask,z=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),z!==0&&w.strstart-z<=w.w_size-U&&(w.match_length=le(w,z)),w.match_length>=F)if(C=r._tr_tally(w,w.strstart-w.match_start,w.match_length-F),w.lookahead-=w.match_length,w.match_length<=w.max_lazy_match&&w.lookahead>=F){for(w.match_length--;w.strstart++,w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+F-1])&w.hash_mask,z=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart,--w.match_length!=0;);w.strstart++}else w.strstart+=w.match_length,w.match_length=0,w.ins_h=w.window[w.strstart],w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+1])&w.hash_mask;else C=r._tr_tally(w,0,w.window[w.strstart]),w.lookahead--,w.strstart++;if(C&&(Z(w,!1),w.strm.avail_out===0))return S}return w.insert=w.strstart<F-1?w.strstart:F-1,q===m?(Z(w,!0),w.strm.avail_out===0?j:I):w.last_lit&&(Z(w,!1),w.strm.avail_out===0)?S:P}function ke(w,q){for(var z,C,$;;){if(w.lookahead<U){if(Se(w),w.lookahead<U&&q===h)return S;if(w.lookahead===0)break}if(z=0,w.lookahead>=F&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+F-1])&w.hash_mask,z=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),w.prev_length=w.match_length,w.prev_match=w.match_start,w.match_length=F-1,z!==0&&w.prev_length<w.max_lazy_match&&w.strstart-z<=w.w_size-U&&(w.match_length=le(w,z),w.match_length<=5&&(w.strategy===1||w.match_length===F&&4096<w.strstart-w.match_start)&&(w.match_length=F-1)),w.prev_length>=F&&w.match_length<=w.prev_length){for($=w.strstart+w.lookahead-F,C=r._tr_tally(w,w.strstart-1-w.prev_match,w.prev_length-F),w.lookahead-=w.prev_length-1,w.prev_length-=2;++w.strstart<=$&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+F-1])&w.hash_mask,z=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),--w.prev_length!=0;);if(w.match_available=0,w.match_length=F-1,w.strstart++,C&&(Z(w,!1),w.strm.avail_out===0))return S}else if(w.match_available){if((C=r._tr_tally(w,0,w.window[w.strstart-1]))&&Z(w,!1),w.strstart++,w.lookahead--,w.strm.avail_out===0)return S}else w.match_available=1,w.strstart++,w.lookahead--}return w.match_available&&(C=r._tr_tally(w,0,w.window[w.strstart-1]),w.match_available=0),w.insert=w.strstart<F-1?w.strstart:F-1,q===m?(Z(w,!0),w.strm.avail_out===0?j:I):w.last_lit&&(Z(w,!1),w.strm.avail_out===0)?S:P}function Ce(w,q,z,C,$){this.good_length=w,this.max_lazy=q,this.nice_length=z,this.max_chain=C,this.func=$}function R(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*T),this.dyn_dtree=new l.Buf16(2*(2*_+1)),this.bl_tree=new l.Buf16(2*(2*A+1)),te(this.dyn_ltree),te(this.dyn_dtree),te(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*v+1),te(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*v+1),te(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ie(w){var q;return w&&w.state?(w.total_in=w.total_out=0,w.data_type=y,(q=w.state).pending=0,q.pending_out=0,q.wrap<0&&(q.wrap=-q.wrap),q.status=q.wrap?E:D,w.adler=q.wrap===2?0:1,q.last_flush=h,r._tr_init(q),d):M(w,b)}function B(w){var q=ie(w);return q===d&&(function(z){z.window_size=2*z.w_size,te(z.head),z.max_lazy_match=s[z.level].max_lazy,z.good_match=s[z.level].good_length,z.nice_match=s[z.level].nice_length,z.max_chain_length=s[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=F-1,z.match_available=0,z.ins_h=0})(w.state),q}function W(w,q,z,C,$,O){if(!w)return b;var G=1;if(q===g&&(q=6),C<0?(G=0,C=-C):15<C&&(G=2,C-=16),$<1||k<$||z!==x||C<8||15<C||q<0||9<q||O<0||p<O)return M(w,b);C===8&&(C=9);var K=new R;return(w.state=K).strm=w,K.wrap=G,K.gzhead=null,K.w_bits=C,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=$+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+F-1)/F),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<$+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=q,K.strategy=O,K.method=z,B(w)}s=[new Ce(0,0,0,0,function(w,q){var z=65535;for(z>w.pending_buf_size-5&&(z=w.pending_buf_size-5);;){if(w.lookahead<=1){if(Se(w),w.lookahead===0&&q===h)return S;if(w.lookahead===0)break}w.strstart+=w.lookahead,w.lookahead=0;var C=w.block_start+z;if((w.strstart===0||w.strstart>=C)&&(w.lookahead=w.strstart-C,w.strstart=C,Z(w,!1),w.strm.avail_out===0)||w.strstart-w.block_start>=w.w_size-U&&(Z(w,!1),w.strm.avail_out===0))return S}return w.insert=0,q===m?(Z(w,!0),w.strm.avail_out===0?j:I):(w.strstart>w.block_start&&(Z(w,!1),w.strm.avail_out),S)}),new Ce(4,4,8,4,$e),new Ce(4,5,16,8,$e),new Ce(4,6,32,32,$e),new Ce(4,4,16,16,ke),new Ce(8,16,32,32,ke),new Ce(8,16,128,128,ke),new Ce(8,32,128,256,ke),new Ce(32,128,258,1024,ke),new Ce(32,258,258,4096,ke)],n.deflateInit=function(w,q){return W(w,q,x,15,8,0)},n.deflateInit2=W,n.deflateReset=B,n.deflateResetKeep=ie,n.deflateSetHeader=function(w,q){return w&&w.state?w.state.wrap!==2?b:(w.state.gzhead=q,d):b},n.deflate=function(w,q){var z,C,$,O;if(!w||!w.state||5<q||q<0)return w?M(w,b):b;if(C=w.state,!w.output||!w.input&&w.avail_in!==0||C.status===666&&q!==m)return M(w,w.avail_out===0?-5:b);if(C.strm=w,z=C.last_flush,C.last_flush=q,C.status===E)if(C.wrap===2)w.adler=0,ce(C,31),ce(C,139),ce(C,8),C.gzhead?(ce(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),ce(C,255&C.gzhead.time),ce(C,C.gzhead.time>>8&255),ce(C,C.gzhead.time>>16&255),ce(C,C.gzhead.time>>24&255),ce(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),ce(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(ce(C,255&C.gzhead.extra.length),ce(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(w.adler=c(w.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(ce(C,0),ce(C,0),ce(C,0),ce(C,0),ce(C,0),ce(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),ce(C,3),C.status=D);else{var G=x+(C.w_bits-8<<4)<<8;G|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(G|=32),G+=31-G%31,C.status=D,oe(C,G),C.strstart!==0&&(oe(C,w.adler>>>16),oe(C,65535&w.adler)),w.adler=1}if(C.status===69)if(C.gzhead.extra){for($=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),V(w),$=C.pending,C.pending!==C.pending_buf_size));)ce(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),V(w),$=C.pending,C.pending===C.pending_buf_size)){O=1;break}O=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,ce(C,O)}while(O!==0);C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),O===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),V(w),$=C.pending,C.pending===C.pending_buf_size)){O=1;break}O=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,ce(C,O)}while(O!==0);C.gzhead.hcrc&&C.pending>$&&(w.adler=c(w.adler,C.pending_buf,C.pending-$,$)),O===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&V(w),C.pending+2<=C.pending_buf_size&&(ce(C,255&w.adler),ce(C,w.adler>>8&255),w.adler=0,C.status=D)):C.status=D),C.pending!==0){if(V(w),w.avail_out===0)return C.last_flush=-1,d}else if(w.avail_in===0&&L(q)<=L(z)&&q!==m)return M(w,-5);if(C.status===666&&w.avail_in!==0)return M(w,-5);if(w.avail_in!==0||C.lookahead!==0||q!==h&&C.status!==666){var K=C.strategy===2?(function(Y,X){for(var ae;;){if(Y.lookahead===0&&(Se(Y),Y.lookahead===0)){if(X===h)return S;break}if(Y.match_length=0,ae=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++,ae&&(Z(Y,!1),Y.strm.avail_out===0))return S}return Y.insert=0,X===m?(Z(Y,!0),Y.strm.avail_out===0?j:I):Y.last_lit&&(Z(Y,!1),Y.strm.avail_out===0)?S:P})(C,q):C.strategy===3?(function(Y,X){for(var ae,ne,me,_e,we=Y.window;;){if(Y.lookahead<=H){if(Se(Y),Y.lookahead<=H&&X===h)return S;if(Y.lookahead===0)break}if(Y.match_length=0,Y.lookahead>=F&&0<Y.strstart&&(ne=we[me=Y.strstart-1])===we[++me]&&ne===we[++me]&&ne===we[++me]){_e=Y.strstart+H;do;while(ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&me<_e);Y.match_length=H-(_e-me),Y.match_length>Y.lookahead&&(Y.match_length=Y.lookahead)}if(Y.match_length>=F?(ae=r._tr_tally(Y,1,Y.match_length-F),Y.lookahead-=Y.match_length,Y.strstart+=Y.match_length,Y.match_length=0):(ae=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++),ae&&(Z(Y,!1),Y.strm.avail_out===0))return S}return Y.insert=0,X===m?(Z(Y,!0),Y.strm.avail_out===0?j:I):Y.last_lit&&(Z(Y,!1),Y.strm.avail_out===0)?S:P})(C,q):s[C.level].func(C,q);if(K!==j&&K!==I||(C.status=666),K===S||K===j)return w.avail_out===0&&(C.last_flush=-1),d;if(K===P&&(q===1?r._tr_align(C):q!==5&&(r._tr_stored_block(C,0,0,!1),q===3&&(te(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),V(w),w.avail_out===0))return C.last_flush=-1,d}return q!==m?d:C.wrap<=0?1:(C.wrap===2?(ce(C,255&w.adler),ce(C,w.adler>>8&255),ce(C,w.adler>>16&255),ce(C,w.adler>>24&255),ce(C,255&w.total_in),ce(C,w.total_in>>8&255),ce(C,w.total_in>>16&255),ce(C,w.total_in>>24&255)):(oe(C,w.adler>>>16),oe(C,65535&w.adler)),V(w),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?d:1)},n.deflateEnd=function(w){var q;return w&&w.state?(q=w.state.status)!==E&&q!==69&&q!==73&&q!==91&&q!==103&&q!==D&&q!==666?M(w,b):(w.state=null,q===D?M(w,-3):d):b},n.deflateSetDictionary=function(w,q){var z,C,$,O,G,K,Y,X,ae=q.length;if(!w||!w.state||(O=(z=w.state).wrap)===2||O===1&&z.status!==E||z.lookahead)return b;for(O===1&&(w.adler=a(w.adler,q,ae,0)),z.wrap=0,ae>=z.w_size&&(O===0&&(te(z.head),z.strstart=0,z.block_start=0,z.insert=0),X=new l.Buf8(z.w_size),l.arraySet(X,q,ae-z.w_size,z.w_size,0),q=X,ae=z.w_size),G=w.avail_in,K=w.next_in,Y=w.input,w.avail_in=ae,w.next_in=0,w.input=q,Se(z);z.lookahead>=F;){for(C=z.strstart,$=z.lookahead-(F-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[C+F-1])&z.hash_mask,z.prev[C&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=C,C++,--$;);z.strstart=C,z.lookahead=F-1,Se(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=F-1,z.match_available=0,w.next_in=K,w.input=Y,w.avail_in=G,z.wrap=O,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,l){var r,a,c,u,h,m,d,b,g,p,y,x,k,v,_,A,T,N,F,H,U,E,D,S,P;r=s.state,a=s.next_in,S=s.input,c=a+(s.avail_in-5),u=s.next_out,P=s.output,h=u-(l-s.avail_out),m=u+(s.avail_out-257),d=r.dmax,b=r.wsize,g=r.whave,p=r.wnext,y=r.window,x=r.hold,k=r.bits,v=r.lencode,_=r.distcode,A=(1<<r.lenbits)-1,T=(1<<r.distbits)-1;e:do{k<15&&(x+=S[a++]<<k,k+=8,x+=S[a++]<<k,k+=8),N=v[x&A];t:for(;;){if(x>>>=F=N>>>24,k-=F,(F=N>>>16&255)===0)P[u++]=65535&N;else{if(!(16&F)){if((64&F)==0){N=v[(65535&N)+(x&(1<<F)-1)];continue t}if(32&F){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}H=65535&N,(F&=15)&&(k<F&&(x+=S[a++]<<k,k+=8),H+=x&(1<<F)-1,x>>>=F,k-=F),k<15&&(x+=S[a++]<<k,k+=8,x+=S[a++]<<k,k+=8),N=_[x&T];o:for(;;){if(x>>>=F=N>>>24,k-=F,!(16&(F=N>>>16&255))){if((64&F)==0){N=_[(65535&N)+(x&(1<<F)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(U=65535&N,k<(F&=15)&&(x+=S[a++]<<k,(k+=8)<F&&(x+=S[a++]<<k,k+=8)),d<(U+=x&(1<<F)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=F,k-=F,(F=u-h)<U){if(g<(F=U-F)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(D=y,(E=0)===p){if(E+=b-F,F<H){for(H-=F;P[u++]=y[E++],--F;);E=u-U,D=P}}else if(p<F){if(E+=b+p-F,(F-=p)<H){for(H-=F;P[u++]=y[E++],--F;);if(E=0,p<H){for(H-=F=p;P[u++]=y[E++],--F;);E=u-U,D=P}}}else if(E+=p-F,F<H){for(H-=F;P[u++]=y[E++],--F;);E=u-U,D=P}for(;2<H;)P[u++]=D[E++],P[u++]=D[E++],P[u++]=D[E++],H-=3;H&&(P[u++]=D[E++],1<H&&(P[u++]=D[E++]))}else{for(E=u-U;P[u++]=P[E++],P[u++]=P[E++],P[u++]=P[E++],2<(H-=3););H&&(P[u++]=P[E++],1<H&&(P[u++]=P[E++]))}break}}break}}while(a<c&&u<m);a-=H=k>>3,x&=(1<<(k-=H<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<m?m-u+257:257-(u-m),r.hold=x,r.bits=k}},{}],49:[function(o,i,n){var s=o("../utils/common"),l=o("./adler32"),r=o("./crc32"),a=o("./inffast"),c=o("./inftrees"),u=1,h=2,m=0,d=-2,b=1,g=852,p=592;function y(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function k(E){var D;return E&&E.state?(D=E.state,E.total_in=E.total_out=D.total=0,E.msg="",D.wrap&&(E.adler=1&D.wrap),D.mode=b,D.last=0,D.havedict=0,D.dmax=32768,D.head=null,D.hold=0,D.bits=0,D.lencode=D.lendyn=new s.Buf32(g),D.distcode=D.distdyn=new s.Buf32(p),D.sane=1,D.back=-1,m):d}function v(E){var D;return E&&E.state?((D=E.state).wsize=0,D.whave=0,D.wnext=0,k(E)):d}function _(E,D){var S,P;return E&&E.state?(P=E.state,D<0?(S=0,D=-D):(S=1+(D>>4),D<48&&(D&=15)),D&&(D<8||15<D)?d:(P.window!==null&&P.wbits!==D&&(P.window=null),P.wrap=S,P.wbits=D,v(E))):d}function A(E,D){var S,P;return E?(P=new x,(E.state=P).window=null,(S=_(E,D))!==m&&(E.state=null),S):d}var T,N,F=!0;function H(E){if(F){var D;for(T=new s.Buf32(512),N=new s.Buf32(32),D=0;D<144;)E.lens[D++]=8;for(;D<256;)E.lens[D++]=9;for(;D<280;)E.lens[D++]=7;for(;D<288;)E.lens[D++]=8;for(c(u,E.lens,0,288,T,0,E.work,{bits:9}),D=0;D<32;)E.lens[D++]=5;c(h,E.lens,0,32,N,0,E.work,{bits:5}),F=!1}E.lencode=T,E.lenbits=9,E.distcode=N,E.distbits=5}function U(E,D,S,P){var j,I=E.state;return I.window===null&&(I.wsize=1<<I.wbits,I.wnext=0,I.whave=0,I.window=new s.Buf8(I.wsize)),P>=I.wsize?(s.arraySet(I.window,D,S-I.wsize,I.wsize,0),I.wnext=0,I.whave=I.wsize):(P<(j=I.wsize-I.wnext)&&(j=P),s.arraySet(I.window,D,S-P,j,I.wnext),(P-=j)?(s.arraySet(I.window,D,S-P,P,0),I.wnext=P,I.whave=I.wsize):(I.wnext+=j,I.wnext===I.wsize&&(I.wnext=0),I.whave<I.wsize&&(I.whave+=j))),0}n.inflateReset=v,n.inflateReset2=_,n.inflateResetKeep=k,n.inflateInit=function(E){return A(E,15)},n.inflateInit2=A,n.inflate=function(E,D){var S,P,j,I,M,L,te,V,Z,ce,oe,le,Se,$e,ke,Ce,R,ie,B,W,w,q,z,C,$=0,O=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return d;(S=E.state).mode===12&&(S.mode=13),M=E.next_out,j=E.output,te=E.avail_out,I=E.next_in,P=E.input,L=E.avail_in,V=S.hold,Z=S.bits,ce=L,oe=te,q=m;e:for(;;)switch(S.mode){case b:if(S.wrap===0){S.mode=13;break}for(;Z<16;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(2&S.wrap&&V===35615){O[S.check=0]=255&V,O[1]=V>>>8&255,S.check=r(S.check,O,2,0),Z=V=0,S.mode=2;break}if(S.flags=0,S.head&&(S.head.done=!1),!(1&S.wrap)||(((255&V)<<8)+(V>>8))%31){E.msg="incorrect header check",S.mode=30;break}if((15&V)!=8){E.msg="unknown compression method",S.mode=30;break}if(Z-=4,w=8+(15&(V>>>=4)),S.wbits===0)S.wbits=w;else if(w>S.wbits){E.msg="invalid window size",S.mode=30;break}S.dmax=1<<w,E.adler=S.check=1,S.mode=512&V?10:12,Z=V=0;break;case 2:for(;Z<16;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(S.flags=V,(255&S.flags)!=8){E.msg="unknown compression method",S.mode=30;break}if(57344&S.flags){E.msg="unknown header flags set",S.mode=30;break}S.head&&(S.head.text=V>>8&1),512&S.flags&&(O[0]=255&V,O[1]=V>>>8&255,S.check=r(S.check,O,2,0)),Z=V=0,S.mode=3;case 3:for(;Z<32;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.head&&(S.head.time=V),512&S.flags&&(O[0]=255&V,O[1]=V>>>8&255,O[2]=V>>>16&255,O[3]=V>>>24&255,S.check=r(S.check,O,4,0)),Z=V=0,S.mode=4;case 4:for(;Z<16;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.head&&(S.head.xflags=255&V,S.head.os=V>>8),512&S.flags&&(O[0]=255&V,O[1]=V>>>8&255,S.check=r(S.check,O,2,0)),Z=V=0,S.mode=5;case 5:if(1024&S.flags){for(;Z<16;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.length=V,S.head&&(S.head.extra_len=V),512&S.flags&&(O[0]=255&V,O[1]=V>>>8&255,S.check=r(S.check,O,2,0)),Z=V=0}else S.head&&(S.head.extra=null);S.mode=6;case 6:if(1024&S.flags&&(L<(le=S.length)&&(le=L),le&&(S.head&&(w=S.head.extra_len-S.length,S.head.extra||(S.head.extra=new Array(S.head.extra_len)),s.arraySet(S.head.extra,P,I,le,w)),512&S.flags&&(S.check=r(S.check,P,le,I)),L-=le,I+=le,S.length-=le),S.length))break e;S.length=0,S.mode=7;case 7:if(2048&S.flags){if(L===0)break e;for(le=0;w=P[I+le++],S.head&&w&&S.length<65536&&(S.head.name+=String.fromCharCode(w)),w&&le<L;);if(512&S.flags&&(S.check=r(S.check,P,le,I)),L-=le,I+=le,w)break e}else S.head&&(S.head.name=null);S.length=0,S.mode=8;case 8:if(4096&S.flags){if(L===0)break e;for(le=0;w=P[I+le++],S.head&&w&&S.length<65536&&(S.head.comment+=String.fromCharCode(w)),w&&le<L;);if(512&S.flags&&(S.check=r(S.check,P,le,I)),L-=le,I+=le,w)break e}else S.head&&(S.head.comment=null);S.mode=9;case 9:if(512&S.flags){for(;Z<16;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(V!==(65535&S.check)){E.msg="header crc mismatch",S.mode=30;break}Z=V=0}S.head&&(S.head.hcrc=S.flags>>9&1,S.head.done=!0),E.adler=S.check=0,S.mode=12;break;case 10:for(;Z<32;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}E.adler=S.check=y(V),Z=V=0,S.mode=11;case 11:if(S.havedict===0)return E.next_out=M,E.avail_out=te,E.next_in=I,E.avail_in=L,S.hold=V,S.bits=Z,2;E.adler=S.check=1,S.mode=12;case 12:if(D===5||D===6)break e;case 13:if(S.last){V>>>=7&Z,Z-=7&Z,S.mode=27;break}for(;Z<3;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}switch(S.last=1&V,Z-=1,3&(V>>>=1)){case 0:S.mode=14;break;case 1:if(H(S),S.mode=20,D!==6)break;V>>>=2,Z-=2;break e;case 2:S.mode=17;break;case 3:E.msg="invalid block type",S.mode=30}V>>>=2,Z-=2;break;case 14:for(V>>>=7&Z,Z-=7&Z;Z<32;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if((65535&V)!=(V>>>16^65535)){E.msg="invalid stored block lengths",S.mode=30;break}if(S.length=65535&V,Z=V=0,S.mode=15,D===6)break e;case 15:S.mode=16;case 16:if(le=S.length){if(L<le&&(le=L),te<le&&(le=te),le===0)break e;s.arraySet(j,P,I,le,M),L-=le,I+=le,te-=le,M+=le,S.length-=le;break}S.mode=12;break;case 17:for(;Z<14;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(S.nlen=257+(31&V),V>>>=5,Z-=5,S.ndist=1+(31&V),V>>>=5,Z-=5,S.ncode=4+(15&V),V>>>=4,Z-=4,286<S.nlen||30<S.ndist){E.msg="too many length or distance symbols",S.mode=30;break}S.have=0,S.mode=18;case 18:for(;S.have<S.ncode;){for(;Z<3;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.lens[G[S.have++]]=7&V,V>>>=3,Z-=3}for(;S.have<19;)S.lens[G[S.have++]]=0;if(S.lencode=S.lendyn,S.lenbits=7,z={bits:S.lenbits},q=c(0,S.lens,0,19,S.lencode,0,S.work,z),S.lenbits=z.bits,q){E.msg="invalid code lengths set",S.mode=30;break}S.have=0,S.mode=19;case 19:for(;S.have<S.nlen+S.ndist;){for(;Ce=($=S.lencode[V&(1<<S.lenbits)-1])>>>16&255,R=65535&$,!((ke=$>>>24)<=Z);){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(R<16)V>>>=ke,Z-=ke,S.lens[S.have++]=R;else{if(R===16){for(C=ke+2;Z<C;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(V>>>=ke,Z-=ke,S.have===0){E.msg="invalid bit length repeat",S.mode=30;break}w=S.lens[S.have-1],le=3+(3&V),V>>>=2,Z-=2}else if(R===17){for(C=ke+3;Z<C;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}Z-=ke,w=0,le=3+(7&(V>>>=ke)),V>>>=3,Z-=3}else{for(C=ke+7;Z<C;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}Z-=ke,w=0,le=11+(127&(V>>>=ke)),V>>>=7,Z-=7}if(S.have+le>S.nlen+S.ndist){E.msg="invalid bit length repeat",S.mode=30;break}for(;le--;)S.lens[S.have++]=w}}if(S.mode===30)break;if(S.lens[256]===0){E.msg="invalid code -- missing end-of-block",S.mode=30;break}if(S.lenbits=9,z={bits:S.lenbits},q=c(u,S.lens,0,S.nlen,S.lencode,0,S.work,z),S.lenbits=z.bits,q){E.msg="invalid literal/lengths set",S.mode=30;break}if(S.distbits=6,S.distcode=S.distdyn,z={bits:S.distbits},q=c(h,S.lens,S.nlen,S.ndist,S.distcode,0,S.work,z),S.distbits=z.bits,q){E.msg="invalid distances set",S.mode=30;break}if(S.mode=20,D===6)break e;case 20:S.mode=21;case 21:if(6<=L&&258<=te){E.next_out=M,E.avail_out=te,E.next_in=I,E.avail_in=L,S.hold=V,S.bits=Z,a(E,oe),M=E.next_out,j=E.output,te=E.avail_out,I=E.next_in,P=E.input,L=E.avail_in,V=S.hold,Z=S.bits,S.mode===12&&(S.back=-1);break}for(S.back=0;Ce=($=S.lencode[V&(1<<S.lenbits)-1])>>>16&255,R=65535&$,!((ke=$>>>24)<=Z);){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(Ce&&(240&Ce)==0){for(ie=ke,B=Ce,W=R;Ce=($=S.lencode[W+((V&(1<<ie+B)-1)>>ie)])>>>16&255,R=65535&$,!(ie+(ke=$>>>24)<=Z);){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}V>>>=ie,Z-=ie,S.back+=ie}if(V>>>=ke,Z-=ke,S.back+=ke,S.length=R,Ce===0){S.mode=26;break}if(32&Ce){S.back=-1,S.mode=12;break}if(64&Ce){E.msg="invalid literal/length code",S.mode=30;break}S.extra=15&Ce,S.mode=22;case 22:if(S.extra){for(C=S.extra;Z<C;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.length+=V&(1<<S.extra)-1,V>>>=S.extra,Z-=S.extra,S.back+=S.extra}S.was=S.length,S.mode=23;case 23:for(;Ce=($=S.distcode[V&(1<<S.distbits)-1])>>>16&255,R=65535&$,!((ke=$>>>24)<=Z);){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if((240&Ce)==0){for(ie=ke,B=Ce,W=R;Ce=($=S.distcode[W+((V&(1<<ie+B)-1)>>ie)])>>>16&255,R=65535&$,!(ie+(ke=$>>>24)<=Z);){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}V>>>=ie,Z-=ie,S.back+=ie}if(V>>>=ke,Z-=ke,S.back+=ke,64&Ce){E.msg="invalid distance code",S.mode=30;break}S.offset=R,S.extra=15&Ce,S.mode=24;case 24:if(S.extra){for(C=S.extra;Z<C;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}S.offset+=V&(1<<S.extra)-1,V>>>=S.extra,Z-=S.extra,S.back+=S.extra}if(S.offset>S.dmax){E.msg="invalid distance too far back",S.mode=30;break}S.mode=25;case 25:if(te===0)break e;if(le=oe-te,S.offset>le){if((le=S.offset-le)>S.whave&&S.sane){E.msg="invalid distance too far back",S.mode=30;break}Se=le>S.wnext?(le-=S.wnext,S.wsize-le):S.wnext-le,le>S.length&&(le=S.length),$e=S.window}else $e=j,Se=M-S.offset,le=S.length;for(te<le&&(le=te),te-=le,S.length-=le;j[M++]=$e[Se++],--le;);S.length===0&&(S.mode=21);break;case 26:if(te===0)break e;j[M++]=S.length,te--,S.mode=21;break;case 27:if(S.wrap){for(;Z<32;){if(L===0)break e;L--,V|=P[I++]<<Z,Z+=8}if(oe-=te,E.total_out+=oe,S.total+=oe,oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,M-oe):l(S.check,j,oe,M-oe)),oe=te,(S.flags?V:y(V))!==S.check){E.msg="incorrect data check",S.mode=30;break}Z=V=0}S.mode=28;case 28:if(S.wrap&&S.flags){for(;Z<32;){if(L===0)break e;L--,V+=P[I++]<<Z,Z+=8}if(V!==(4294967295&S.total)){E.msg="incorrect length check",S.mode=30;break}Z=V=0}S.mode=29;case 29:q=1;break e;case 30:q=-3;break e;case 31:return-4;case 32:default:return d}return E.next_out=M,E.avail_out=te,E.next_in=I,E.avail_in=L,S.hold=V,S.bits=Z,(S.wsize||oe!==E.avail_out&&S.mode<30&&(S.mode<27||D!==4))&&U(E,E.output,E.next_out,oe-E.avail_out)?(S.mode=31,-4):(ce-=E.avail_in,oe-=E.avail_out,E.total_in+=ce,E.total_out+=oe,S.total+=oe,S.wrap&&oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,E.next_out-oe):l(S.check,j,oe,E.next_out-oe)),E.data_type=S.bits+(S.last?64:0)+(S.mode===12?128:0)+(S.mode===20||S.mode===15?256:0),(ce==0&&oe===0||D===4)&&q===m&&(q=-5),q)},n.inflateEnd=function(E){if(!E||!E.state)return d;var D=E.state;return D.window&&(D.window=null),E.state=null,m},n.inflateGetHeader=function(E,D){var S;return E&&E.state?(2&(S=E.state).wrap)==0?d:((S.head=D).done=!1,m):d},n.inflateSetDictionary=function(E,D){var S,P=D.length;return E&&E.state?(S=E.state).wrap!==0&&S.mode!==11?d:S.mode===11&&l(1,D,P,0)!==S.check?-3:U(E,D,P,P)?(S.mode=31,-4):(S.havedict=1,m):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,h,m,d,b,g,p,y){var x,k,v,_,A,T,N,F,H,U=y.bits,E=0,D=0,S=0,P=0,j=0,I=0,M=0,L=0,te=0,V=0,Z=null,ce=0,oe=new s.Buf16(16),le=new s.Buf16(16),Se=null,$e=0;for(E=0;E<=15;E++)oe[E]=0;for(D=0;D<d;D++)oe[h[m+D]]++;for(j=U,P=15;1<=P&&oe[P]===0;P--);if(P<j&&(j=P),P===0)return b[g++]=20971520,b[g++]=20971520,y.bits=1,0;for(S=1;S<P&&oe[S]===0;S++);for(j<S&&(j=S),E=L=1;E<=15;E++)if(L<<=1,(L-=oe[E])<0)return-1;if(0<L&&(u===0||P!==1))return-1;for(le[1]=0,E=1;E<15;E++)le[E+1]=le[E]+oe[E];for(D=0;D<d;D++)h[m+D]!==0&&(p[le[h[m+D]]++]=D);if(T=u===0?(Z=Se=p,19):u===1?(Z=l,ce-=257,Se=r,$e-=257,256):(Z=a,Se=c,-1),E=S,A=g,M=D=V=0,v=-1,_=(te=1<<(I=j))-1,u===1&&852<te||u===2&&592<te)return 1;for(;;){for(N=E-M,H=p[D]<T?(F=0,p[D]):p[D]>T?(F=Se[$e+p[D]],Z[ce+p[D]]):(F=96,0),x=1<<E-M,S=k=1<<I;b[A+(V>>M)+(k-=x)]=N<<24|F<<16|H|0,k!==0;);for(x=1<<E-1;V&x;)x>>=1;if(x!==0?(V&=x-1,V+=x):V=0,D++,--oe[E]==0){if(E===P)break;E=h[m+p[D]]}if(j<E&&(V&_)!==v){for(M===0&&(M=j),A+=S,L=1<<(I=E-M);I+M<P&&!((L-=oe[I+M])<=0);)I++,L<<=1;if(te+=1<<I,u===1&&852<te||u===2&&592<te)return 1;b[v=V&_]=j<<24|I<<16|A-g|0}}return V!==0&&(b[A+V]=E-M<<24|64<<16|0),y.bits=j,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),l=0,r=1;function a($){for(var O=$.length;0<=--O;)$[O]=0}var c=0,u=29,h=256,m=h+1+u,d=30,b=19,g=2*m+1,p=15,y=16,x=7,k=256,v=16,_=17,A=18,T=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],F=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],H=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],U=new Array(2*(m+2));a(U);var E=new Array(2*d);a(E);var D=new Array(512);a(D);var S=new Array(256);a(S);var P=new Array(u);a(P);var j,I,M,L=new Array(d);function te($,O,G,K,Y){this.static_tree=$,this.extra_bits=O,this.extra_base=G,this.elems=K,this.max_length=Y,this.has_stree=$&&$.length}function V($,O){this.dyn_tree=$,this.max_code=0,this.stat_desc=O}function Z($){return $<256?D[$]:D[256+($>>>7)]}function ce($,O){$.pending_buf[$.pending++]=255&O,$.pending_buf[$.pending++]=O>>>8&255}function oe($,O,G){$.bi_valid>y-G?($.bi_buf|=O<<$.bi_valid&65535,ce($,$.bi_buf),$.bi_buf=O>>y-$.bi_valid,$.bi_valid+=G-y):($.bi_buf|=O<<$.bi_valid&65535,$.bi_valid+=G)}function le($,O,G){oe($,G[2*O],G[2*O+1])}function Se($,O){for(var G=0;G|=1&$,$>>>=1,G<<=1,0<--O;);return G>>>1}function $e($,O,G){var K,Y,X=new Array(p+1),ae=0;for(K=1;K<=p;K++)X[K]=ae=ae+G[K-1]<<1;for(Y=0;Y<=O;Y++){var ne=$[2*Y+1];ne!==0&&($[2*Y]=Se(X[ne]++,ne))}}function ke($){var O;for(O=0;O<m;O++)$.dyn_ltree[2*O]=0;for(O=0;O<d;O++)$.dyn_dtree[2*O]=0;for(O=0;O<b;O++)$.bl_tree[2*O]=0;$.dyn_ltree[2*k]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function Ce($){8<$.bi_valid?ce($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function R($,O,G,K){var Y=2*O,X=2*G;return $[Y]<$[X]||$[Y]===$[X]&&K[O]<=K[G]}function ie($,O,G){for(var K=$.heap[G],Y=G<<1;Y<=$.heap_len&&(Y<$.heap_len&&R(O,$.heap[Y+1],$.heap[Y],$.depth)&&Y++,!R(O,K,$.heap[Y],$.depth));)$.heap[G]=$.heap[Y],G=Y,Y<<=1;$.heap[G]=K}function B($,O,G){var K,Y,X,ae,ne=0;if($.last_lit!==0)for(;K=$.pending_buf[$.d_buf+2*ne]<<8|$.pending_buf[$.d_buf+2*ne+1],Y=$.pending_buf[$.l_buf+ne],ne++,K===0?le($,Y,O):(le($,(X=S[Y])+h+1,O),(ae=T[X])!==0&&oe($,Y-=P[X],ae),le($,X=Z(--K),G),(ae=N[X])!==0&&oe($,K-=L[X],ae)),ne<$.last_lit;);le($,k,O)}function W($,O){var G,K,Y,X=O.dyn_tree,ae=O.stat_desc.static_tree,ne=O.stat_desc.has_stree,me=O.stat_desc.elems,_e=-1;for($.heap_len=0,$.heap_max=g,G=0;G<me;G++)X[2*G]!==0?($.heap[++$.heap_len]=_e=G,$.depth[G]=0):X[2*G+1]=0;for(;$.heap_len<2;)X[2*(Y=$.heap[++$.heap_len]=_e<2?++_e:0)]=1,$.depth[Y]=0,$.opt_len--,ne&&($.static_len-=ae[2*Y+1]);for(O.max_code=_e,G=$.heap_len>>1;1<=G;G--)ie($,X,G);for(Y=me;G=$.heap[1],$.heap[1]=$.heap[$.heap_len--],ie($,X,1),K=$.heap[1],$.heap[--$.heap_max]=G,$.heap[--$.heap_max]=K,X[2*Y]=X[2*G]+X[2*K],$.depth[Y]=($.depth[G]>=$.depth[K]?$.depth[G]:$.depth[K])+1,X[2*G+1]=X[2*K+1]=Y,$.heap[1]=Y++,ie($,X,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(we,Le){var He,Ke,rt,Pe,ft,tt,Ge=Le.dyn_tree,fe=Le.max_code,he=Le.stat_desc.static_tree,Qe=Le.stat_desc.has_stree,lt=Le.stat_desc.extra_bits,$t=Le.stat_desc.extra_base,at=Le.stat_desc.max_length,ao=0;for(Pe=0;Pe<=p;Pe++)we.bl_count[Pe]=0;for(Ge[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<g;He++)at<(Pe=Ge[2*Ge[2*(Ke=we.heap[He])+1]+1]+1)&&(Pe=at,ao++),Ge[2*Ke+1]=Pe,fe<Ke||(we.bl_count[Pe]++,ft=0,$t<=Ke&&(ft=lt[Ke-$t]),tt=Ge[2*Ke],we.opt_len+=tt*(Pe+ft),Qe&&(we.static_len+=tt*(he[2*Ke+1]+ft)));if(ao!==0){do{for(Pe=at-1;we.bl_count[Pe]===0;)Pe--;we.bl_count[Pe]--,we.bl_count[Pe+1]+=2,we.bl_count[at]--,ao-=2}while(0<ao);for(Pe=at;Pe!==0;Pe--)for(Ke=we.bl_count[Pe];Ke!==0;)fe<(rt=we.heap[--He])||(Ge[2*rt+1]!==Pe&&(we.opt_len+=(Pe-Ge[2*rt+1])*Ge[2*rt],Ge[2*rt+1]=Pe),Ke--)}})($,O),$e(X,_e,$.bl_count)}function w($,O,G){var K,Y,X=-1,ae=O[1],ne=0,me=7,_e=4;for(ae===0&&(me=138,_e=3),O[2*(G+1)+1]=65535,K=0;K<=G;K++)Y=ae,ae=O[2*(K+1)+1],++ne<me&&Y===ae||(ne<_e?$.bl_tree[2*Y]+=ne:Y!==0?(Y!==X&&$.bl_tree[2*Y]++,$.bl_tree[2*v]++):ne<=10?$.bl_tree[2*_]++:$.bl_tree[2*A]++,X=Y,_e=(ne=0)===ae?(me=138,3):Y===ae?(me=6,3):(me=7,4))}function q($,O,G){var K,Y,X=-1,ae=O[1],ne=0,me=7,_e=4;for(ae===0&&(me=138,_e=3),K=0;K<=G;K++)if(Y=ae,ae=O[2*(K+1)+1],!(++ne<me&&Y===ae)){if(ne<_e)for(;le($,Y,$.bl_tree),--ne!=0;);else Y!==0?(Y!==X&&(le($,Y,$.bl_tree),ne--),le($,v,$.bl_tree),oe($,ne-3,2)):ne<=10?(le($,_,$.bl_tree),oe($,ne-3,3)):(le($,A,$.bl_tree),oe($,ne-11,7));X=Y,_e=(ne=0)===ae?(me=138,3):Y===ae?(me=6,3):(me=7,4)}}a(L);var z=!1;function C($,O,G,K){oe($,(c<<1)+(K?1:0),3),(function(Y,X,ae,ne){Ce(Y),ce(Y,ae),ce(Y,~ae),s.arraySet(Y.pending_buf,Y.window,X,ae,Y.pending),Y.pending+=ae})($,O,G)}n._tr_init=function($){z||((function(){var O,G,K,Y,X,ae=new Array(p+1);for(Y=K=0;Y<u-1;Y++)for(P[Y]=K,O=0;O<1<<T[Y];O++)S[K++]=Y;for(S[K-1]=Y,Y=X=0;Y<16;Y++)for(L[Y]=X,O=0;O<1<<N[Y];O++)D[X++]=Y;for(X>>=7;Y<d;Y++)for(L[Y]=X<<7,O=0;O<1<<N[Y]-7;O++)D[256+X++]=Y;for(G=0;G<=p;G++)ae[G]=0;for(O=0;O<=143;)U[2*O+1]=8,O++,ae[8]++;for(;O<=255;)U[2*O+1]=9,O++,ae[9]++;for(;O<=279;)U[2*O+1]=7,O++,ae[7]++;for(;O<=287;)U[2*O+1]=8,O++,ae[8]++;for($e(U,m+1,ae),O=0;O<d;O++)E[2*O+1]=5,E[2*O]=Se(O,5);j=new te(U,T,h+1,m,p),I=new te(E,N,0,d,p),M=new te(new Array(0),F,0,b,x)})(),z=!0),$.l_desc=new V($.dyn_ltree,j),$.d_desc=new V($.dyn_dtree,I),$.bl_desc=new V($.bl_tree,M),$.bi_buf=0,$.bi_valid=0,ke($)},n._tr_stored_block=C,n._tr_flush_block=function($,O,G,K){var Y,X,ae=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(ne){var me,_e=4093624447;for(me=0;me<=31;me++,_e>>>=1)if(1&_e&&ne.dyn_ltree[2*me]!==0)return l;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(me=32;me<h;me++)if(ne.dyn_ltree[2*me]!==0)return r;return l})($)),W($,$.l_desc),W($,$.d_desc),ae=(function(ne){var me;for(w(ne,ne.dyn_ltree,ne.l_desc.max_code),w(ne,ne.dyn_dtree,ne.d_desc.max_code),W(ne,ne.bl_desc),me=b-1;3<=me&&ne.bl_tree[2*H[me]+1]===0;me--);return ne.opt_len+=3*(me+1)+5+5+4,me})($),Y=$.opt_len+3+7>>>3,(X=$.static_len+3+7>>>3)<=Y&&(Y=X)):Y=X=G+5,G+4<=Y&&O!==-1?C($,O,G,K):$.strategy===4||X===Y?(oe($,2+(K?1:0),3),B($,U,E)):(oe($,4+(K?1:0),3),(function(ne,me,_e,we){var Le;for(oe(ne,me-257,5),oe(ne,_e-1,5),oe(ne,we-4,4),Le=0;Le<we;Le++)oe(ne,ne.bl_tree[2*H[Le]+1],3);q(ne,ne.dyn_ltree,me-1),q(ne,ne.dyn_dtree,_e-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,ae+1),B($,$.dyn_ltree,$.dyn_dtree)),ke($),K&&Ce($)},n._tr_tally=function($,O,G){return $.pending_buf[$.d_buf+2*$.last_lit]=O>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&O,$.pending_buf[$.l_buf+$.last_lit]=255&G,$.last_lit++,O===0?$.dyn_ltree[2*G]++:($.matches++,O--,$.dyn_ltree[2*(S[G]+h+1)]++,$.dyn_dtree[2*Z(O)]++),$.last_lit===$.lit_bufsize-1},n._tr_align=function($){oe($,2,3),le($,k,U),(function(O){O.bi_valid===16?(ce(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,h,m=1,d={},b=!1,g=l.document,p=Object.getPrototypeOf&&Object.getPrototypeOf(l);p=p&&p.setTimeout?p:l,a={}.toString.call(l.process)==="[object process]"?function(v){process.nextTick(function(){x(v)})}:(function(){if(l.postMessage&&!l.importScripts){var v=!0,_=l.onmessage;return l.onmessage=function(){v=!1},l.postMessage("","*"),l.onmessage=_,v}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",k,!1):l.attachEvent("onmessage",k),function(v){l.postMessage(h+v,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(v){x(v.data)},function(v){u.port2.postMessage(v)}):g&&"onreadystatechange"in g.createElement("script")?(c=g.documentElement,function(v){var _=g.createElement("script");_.onreadystatechange=function(){x(v),_.onreadystatechange=null,c.removeChild(_),_=null},c.appendChild(_)}):function(v){setTimeout(x,0,v)},p.setImmediate=function(v){typeof v!="function"&&(v=new Function(""+v));for(var _=new Array(arguments.length-1),A=0;A<_.length;A++)_[A]=arguments[A+1];var T={callback:v,args:_};return d[m]=T,a(m),m++},p.clearImmediate=y}function y(v){delete d[v]}function x(v){if(b)setTimeout(x,0,v);else{var _=d[v];if(_){b=!0;try{(function(A){var T=A.callback,N=A.args;switch(N.length){case 0:T();break;case 1:T(N[0]);break;case 2:T(N[0],N[1]);break;case 3:T(N[0],N[1],N[2]);break;default:T.apply(r,N)}})(_)}finally{y(v),b=!1}}}}function k(v){v.source===l&&typeof v.data=="string"&&v.data.indexOf(h)===0&&x(+v.data.slice(h.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ks)),ks.exports}var Sg=xg();const dc=wg(Sg);function uc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function fc(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],l=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await vi(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function Cg(e,t,o){var c,u,h;const i=g2(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const l=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await fc(e,l));const a=uc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const m=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of m){const b=d.querySelector(".item__text"),g=((h=b==null?void 0:b.textContent)==null?void 0:h.trim())||"";if(g.includes("Slidev 演示预览")||g.startsWith("即现")){b&&(b.textContent=a),d.setAttribute("title",a);break}}}}function Oi(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Po(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const l=await o.fetchDocumentTitle(i);if(l&&l.trim())return Oi(l)}catch{}if(typeof document<"u")try{const l=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Oi(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Oi(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Oi(a)}return"presentation"}function _g(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function Tl(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function Ig(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Gs(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(a=>a()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{s(),o({success:!0,dataUrl:a.dataUrl})});i.push(l);const r=e.onCaptureError(a=>{s(),o({success:!1,error:a})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function hc(e,t){const o=[],i=Oi((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),s.forEach(d=>d()),s=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(d=>{var b;a(),(b=t==null?void 0:t.onProgress)==null||b.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{a(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const h=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new dc,b=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of o){const x=String(y.pageIndex).padStart(2,"0"),k=y.dataUrl.split(",")[1];d.file(`slide-${x}.${b}`,k,{base64:!0})}const g=await d.generateAsync({type:"blob",compression:"DEFLATE"}),p=_g(`${i}.zip`,g);n({success:p,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(h));const m=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(m),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function pc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new os;i.attach(o);try{if(await new Promise((n,s)=>{const l=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(l),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Gs(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await Po(e,e.docId);return await hc(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const $g=1500,Tg=500,Ag=4,Mg=new Set(["INPUT","TEXTAREA","SELECT"]);function mc(e){const t=e;return!t||!t.tagName?!1:Mg.has(t.tagName)||t.isContentEditable===!0}function Eg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function l(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){l(),t="",o=!1,s()}function a(){i&&clearTimeout(i),i=setTimeout(r,$g)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,Tg)}function u(h){if(e.isEnabled&&!e.isEnabled()||mc(h.target)||h.isComposing||h.ctrlKey||h.metaKey||h.altKey)return!1;if(/^[0-9]$/.test(h.key))return o||t.length>=Ag||(t+=h.key,s(),a()),!0;if(h.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),b=e.getTotalPages();return!isNaN(d)&&d>=1&&b>0&&d<=b?(r(),e.onJump(d),!0):(c(),!0)}return h.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const Bg={class:"spm-slides-tab__toolbar"},Dg={class:"spm-slides-tab__nav"},Lg=["disabled"],Og={class:"spm-page-badge"},Ng=["disabled"],Pg=["aria-label"],Rg={class:"spm-slides-tab__tools"},zg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Hg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Fg=["src"],jg=zt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Vt("plugin"),i=Vt("sandboxBridge",new os),n=new Gm(i),s=pe(null),l=pe(!1),r=pe(null),a=pe(1),c=pe(1),u=pe(!1),h=pe(!1),m=pe(!1),d=pe("siyuan"),b=pe(""),g=pe(""),p=pe(""),y=pe(!1),x=pe(!1),k=pe(""),v=pe(""),_=pe(!1),A=Eg({getTotalPages:()=>c.value,isEnabled:()=>!h.value,onJump:C=>F(C),onStateChange:C=>{v.value=C.display,_.value=C.invalid}});function T(C){if(C.key==="o"||C.key==="O"){if(h.value||C.isComposing||C.ctrlKey||C.metaKey||C.altKey||mc(C.target))return;C.preventDefault(),N();return}A.handleKeydown(C)&&C.preventDefault()}function N(){var C;i.toggleOverview(),(C=r.value)==null||C.focus()}function F(C){var $;a.value=C,i.navigatePage(C),($=r.value)==null||$.focus()}const H=pe("/plugins/siyuan-live-slides/slides-client/index.html");let U=null,E=null,D=null,S=null,P=null,j=null,I=null,M=null;ti(()=>{r.value&&i.attach(r.value),U=i.onSlideChanged((C,$)=>{a.value=C,c.value=$}),E=i.onBlockClicked((C,$)=>{a.value=$,n.setActiveBlockId(C),C||qi(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide(C,$):C&&Qo(C,o==null?void 0:o.app)}),D=i.onOpenInEditor((C,$)=>{a.value=$,n.setActiveBlockId(C),Qo(C,o==null?void 0:o.app)}),S=i.onOpenPeekDrawer(async C=>{const $=zo();if(C.peekType==="siyuan"&&$.enableWebServeJump){let O=!1;if(M&&M.docId===C.target)O=!0;else if(M&&M.slides&&M.slides.some(G=>{var K;return(K=G.blocks)==null?void 0:K.some(Y=>Y.id===C.target)}))O=!1;else try{const G=await vi(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);G&&G.length>0&&(O=G[0].type==="d"||G[0].id===G[0].root_id)}catch(G){console.warn("[SlidesPreviewTab] detect block type failed:",G)}d.value="web",y.value=!0,g.value=Ya($.webServeUrl,C.target,{focus:!O}),p.value=C.title||`${O?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,h.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=C.peekType,C.peekType==="siyuan")b.value=C.target,p.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const O=oc(C.target);if(O.external){$e(C.target);return}y.value=!0,g.value=O.url,p.value=C.title||O.url}h.value=!0,i.freezeKeyboardNav(!0)}}),P=i.onRequestToggleFullscreen(()=>{Ce()}),j=i.onOpenPresenter(()=>{R()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ke),I=ec(C=>{M&&i.updateSlides(M.slides,{...M.config,hostThemeMode:C},M.customThemeCss)})}),sn(()=>{I&&(I(),I=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ke),S&&S(),P&&P(),j&&j(),U&&U(),E&&E(),D&&D(),i.detach(),A.clear(),n.destroy()});function L(){x.value=!x.value,x.value?(k.value=(M==null?void 0:M.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",k.value)):(k.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let te=0;function V(C){if(h.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const $=Date.now();$-te<280||(te=$,C.deltaY>0?ce():Z())}function Z(){if(a.value>1){const C=a.value-1;a.value=C,i.navigatePage(C)}}function ce(){if(a.value<c.value){const C=a.value+1;a.value=C,i.navigatePage(C)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function le(){h.value=!1,i.freezeKeyboardNav(!1)}function Se(){le()}function $e(C){var K,Y;const $=/^file:/i.test(C),O=$||/^[a-zA-Z]:[\\/]/.test(C),G=ln("electron");if(O&&typeof((K=G==null?void 0:G.shell)==null?void 0:K.openPath)=="function"){G.shell.openPath($?tc(C):C),re.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Y=G==null?void 0:G.shell)==null?void 0:Y.openExternal)=="function"?G.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),re.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ke(){typeof document<"u"&&(l.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:l.value}))}function Ce(){const C=s.value||r.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function R(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function ie(){if(!M){re.showMessage("请先在主编辑区打开幻灯片文档");return}const C=await Po(M,o==null?void 0:o.currentDocId,o);re.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const $=await lc(M,{title:C});ac(`${C}.html`,$)&&re.showMessage(`已开始下载单文件离线 HTML 演示包 (${C}.html)`)}function B(){if(!M){re.showMessage("请先在主编辑区打开幻灯片文档");return}cc(M)&&re.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const W=pe(!1);async function w(){if(W.value){re.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!M){re.showMessage("请先在主编辑区打开幻灯片文档");return}W.value=!0;try{re.showMessage("正在逐页导出幻灯片图片...",2e3);const C=await Po(M,o==null?void 0:o.currentDocId,o),$=await hc(i,{title:C,onProgress:(O,G)=>{re.showMessage(`正在导出幻灯片图片 (${O} / ${G})...`,1500)}});$.success?re.showMessage(`🎉 成功导出 ${$.total||0} 张高清图片并保存为 ${C}.zip！`,4e3):re.showMessage(`导出图片失败：${$.error||"未知异常"}`)}finally{W.value=!1}}async function q(){if(!M){re.showMessage("请先在主编辑区打开幻灯片文档");return}re.showMessage("正在导出当前幻灯片图片...",1500);const C=await Gs(i);if(C.success&&C.dataUrl){const $=await Po(M,o==null?void 0:o.currentDocId,o),O=a.value||1,K=(c.value||1)>1?`${$}-${O}.png`:`${$}.png`;Tl(K,C.dataUrl),re.showMessage(`已下载当前页高清图片 (${K})`)}else re.showMessage(`导出当前页图片失败：${C.error||"未知异常"}`)}async function z(){if(!M){re.showMessage("请先在主编辑区打开幻灯片文档");return}re.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const C=await Gs(i);if(C.success&&C.dataUrl)if(await Ig(C.dataUrl))re.showMessage(`已成功将第 ${a.value||1} 页幻灯片复制到剪贴板！`);else{const O=await Po(M,o==null?void 0:o.currentDocId,o),G=a.value||1,Y=(c.value||1)>1?`${O}-${G}.png`:`${O}.png`;Tl(Y,C.dataUrl),re.showMessage(`剪贴板权限不可用，已自动下载为 ${Y}`)}else re.showMessage(`复制失败：${C.error||"未知异常"}`)}return t({updateDocument(C,$){x.value&&k.value&&$&&$!==k.value||(M=C,x.value&&!k.value&&(k.value=C.docId),c.value=C.slides.length,n.setDocId(C.docId),n.updateSlidesIndex(C.slides),i.updateSlides(C.slides,{...C.config,hostThemeMode:Fo()},C.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",C.docId))},navigateToBlock(C){n.onCursorFocusBlock(C)},isPinned:x,pinnedDocId:k}),(C,$)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:T},[f("div",Bg,[f("div",Dg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value<=1,"aria-label":"上一页",onClick:Z},[se(de,{name:"chevron-left"})],8,Lg),f("span",Og,ve(a.value)+" / "+ve(c.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value>=c.value,"aria-label":"下一页",onClick:ce},[se(de,{name:"chevron-right"})],8,Ng),f("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":x.value}]),"aria-label":x.value?"已锁定当前文档（点击解除）："+k.value:"点击锁定当前文档（不随主编辑区切换）",onClick:L},[se(de,{name:"pin"}),f("span",null,ve(x.value?"已锁定":"跟随"),1)],10,Pg)]),f("div",Rg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:N},[se(de,{name:"layout-grid"})]),ue(Ot)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:R},[se(de,{name:"presenter"})])):Ae("",!0),ue(Ot)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ie},[se(de,{name:"export-html"})])):Ae("",!0),ue(Ot)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:B},[se(de,{name:"export-pdf"})])):Ae("",!0),ue(Ot)("exportImage")?(J(),ee("div",zg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:w},[se(de,{name:"export-image"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:$[0]||($[0]=oo(O=>u.value=!u.value,["stop"]))},[se(de,{name:"chevron-down"})]),u.value?(J(),ee("div",Hg,[f("button",{class:"b3-menu__item",onClick:$[1]||($[1]=O=>{w(),u.value=!1})},[...$[6]||($[6]=[f("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),f("button",{class:"b3-menu__item",onClick:$[2]||($[2]=O=>{q(),u.value=!1})},[...$[7]||($[7]=[f("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),f("button",{class:"b3-menu__item",onClick:$[3]||($[3]=O=>{z(),u.value=!1})},[...$[8]||($[8]=[f("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Ae("",!0)])):Ae("",!0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[se(de,{name:"refresh"})]),f("button",{class:"spm-icon-btn is-primary spm-btn-fullscreen b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:Ce},[se(de,{name:"fullscreen"}),$[9]||($[9]=f("span",{class:"spm-btn-fullscreen__label"},"全屏放映",-1))])])]),f("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:V},[f("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:H.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Fg),se(om,{visible:h.value,"onUpdate:visible":$[4]||($[4]=O=>h.value=O),"is-maximized":m.value,"onUpdate:isMaximized":$[5]||($[5]=O=>m.value=O),title:p.value,onClose:le},{default:ba(()=>[d.value==="siyuan"&&b.value?(J(),io(mm,{key:0,"block-id":b.value,title:p.value,plugin:ue(o),onExternalJump:Se},null,8,["block-id","title","plugin"])):Ae("",!0),y.value?Ut((J(),io(Vm,{key:1,visible:h.value&&d.value==="web",url:g.value,title:p.value,onExternalJump:Se},null,8,["visible","url","title"])),[[Fs,d.value==="web"]]):Ae("",!0)]),_:1},8,["visible","is-maximized","title"]),Ut(f("div",{class:xe(["spm-jump-badge",{"is-invalid":_.value}])},ve(v.value),3),[[Fs,v.value]])],544)],32))}}),Ug=lo(jg,[["__scopeId","data-v-7d559c8a"]]);function gc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&o.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const h=String(r.parentClicks).trim();if(/^\d+$/.test(h)){const m=parseInt(h,10);n=Math.max(n,m),i.set(r.parentContainerId,m)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const h=i.get(r.parentContainerId);s(r,{type:"step",step:h})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const h=JSON.parse(c);if(Array.isArray(h)&&h.length>=2){const m=Math.min(Number(h[0]),Number(h[1])),d=Math.max(Number(h[0]),Number(h[1]));if(!isNaN(m)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:m,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const h=c==="true"?1:parseInt(c.slice(1),10)||1;n+=h,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const h=parseInt(c.slice(1),10)||1;n=Math.max(1,n-h),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const h=parseInt(c,10);if(!isNaN(h)){n=Math.max(n,h),s(r,{type:"step",step:h});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function Wg(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ys=980;function qg(e){if(!e)return 0;const o=gc(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=Ad(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function Vg(e,t=Ys){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",l=o.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(i=l[0]/l[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function Al(e,t,o=Ys,i=552,n=16){const s=o>0?o:Ys,l=i>0?i:552,r=Math.max(0,e-n),a=Math.max(0,t-n);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(l*u))}}function Kg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function Ml(e,t){if(!e)return"";const o=Kg(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?gc(o.blocks||[]):null,u=rc(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:a?k=>{if(Wg(k,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const _=k.id||k.blockId,A=a.blockMap.get(k)||(_?a.idMap.get(_):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(k,v)=>{let _=v.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(_)||(_+=" muted"),`<video ${_.trim()}>`}),h=i.spacing,m=h&&h!=="inherit"?h:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${m}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),b=[],g=(i.background||s.background||"").trim();if(g)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(g)){const k=g.startsWith("assets/")?`/${g}`:g.startsWith("./assets/")?g.slice(1):g;b.push(`background-image:url('${st(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${st(g)};`);const p=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,y=!isNaN(p)&&p>0?p:1;y!==1&&b.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=b.length>0?` style="${b.join("")}"`:"";return`<div class="${st(d)}"${x}>${u}</div>`}const Gg={class:"presenter-header"},Yg={class:"presenter-title-area"},Zg={class:"presenter-brand"},Jg={class:"header-pills"},Xg={class:"pill pill-page"},Qg={key:0,class:"pill pill-step"},ey={class:"header-toolbar"},ty={class:"timer-capsule"},oy={class:"timer-digits"},iy={class:"timer-actions"},ny=["aria-label"],sy={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},ry={key:0,class:"presenter-grid"},ly={class:"slide-panels"},ay={class:"panel-box current-slide-panel"},cy={class:"panel-header"},dy={class:"panel-header-left"},uy={class:"panel-page-num"},fy={class:"panel-header-meta"},hy={key:0,class:"panel-step-pill"},py={class:"panel-layout-pill"},my=["aria-label"],gy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],yy={key:1,class:"panel-fallback"},by=["aria-label"],vy={class:"panel-header"},ky={class:"panel-header-left"},wy={key:0,class:"panel-page-num"},xy={class:"panel-header-meta"},Sy={key:0,class:"panel-end-pill"},Cy={key:1,class:"panel-layout-pill"},_y=["aria-label"],Iy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],$y={key:1,class:"panel-fallback"},Ty={class:"notes-panel"},Ay={class:"panel-header"},My={class:"panel-header-left"},Ey={class:"notes-size-controls"},By=["disabled"],Dy={class:"notes-size-value"},Ly=["disabled"],Oy={key:1,class:"presenter-empty"},Ny={class:"empty-icon-wrap"},Py={class:"empty-actions"},Ry={class:"presenter-actions"},zy={class:"nav-btn-group"},Hy=["disabled"],Fy=["disabled"],jy={class:"actions-center"},Uy={class:"center-meta"},Wy={class:"progress-pill"},qy={class:"nav-btn-group"},Vy=["aria-label"],Ky={class:"step-dots-text"},Gy=["disabled"],Yy=["disabled"],Zy=280,Jy=15,Xy=zt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Vt("plugin"),i=Vt("sandboxBridge",new os),n=pe([]),s=pe({}),l=pe(1),r=pe(0),a=pe(0),c=pe(0),u=ye(()=>n.value.length||a.value),h=pe(null),m=pe(null),d=pe({width:0,height:0}),b=pe({width:0,height:0}),g=pe(Fo()),p=ye(()=>{var fe;return Vg((fe=s.value)==null?void 0:fe.aspectRatio)}),y=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.theme)||"apple-basic"}),x=ye(()=>{var fe;return xr((fe=s.value)==null?void 0:fe.colorSchema,g.value)}),k=ye(()=>{var fe;return!!((fe=s.value)!=null&&fe.normalizeHeadingSizes)}),v=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showUnorderedListMarkers)===!1}),_=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showOrderedListMarkers)===!1}),A=ye(()=>Al(d.value.width,d.value.height,p.value.baseWidth,p.value.baseHeight,14)),T=ye(()=>Al(b.value.width,b.value.height,p.value.baseWidth,p.value.baseHeight,14));function N(){h.value&&(d.value={width:h.value.clientWidth,height:h.value.clientHeight}),m.value&&(b.value={width:m.value.clientWidth,height:m.value.clientHeight})}let F=null;function H(){typeof window>"u"||typeof window.ResizeObserver!="function"||(F||(F=new window.ResizeObserver(()=>{N()})),F.disconnect(),h.value&&F.observe(h.value),m.value&&F.observe(m.value))}Ro([h,m,u],()=>{Ln(()=>{H(),N()})},{flush:"post"});const U=pe(0),E=pe(!0);let D=null,S=Date.now(),P=0;const j=ye(()=>{const fe=String(Math.floor(U.value/60)).padStart(2,"0"),he=String(U.value%60).padStart(2,"0");return`${fe}:${he}`});function I(){if(E.value){const fe=P+(Date.now()-S);U.value=Math.floor(fe/1e3)}}function M(){E.value?(P+=Date.now()-S,E.value=!1):(S=Date.now(),E.value=!0,I())}function L(){S=Date.now(),P=0,U.value=0}const te=pe("");let V=null;function Z(){const fe=new Date,he=String(fe.getHours()).padStart(2,"0"),Qe=String(fe.getMinutes()).padStart(2,"0");te.value=`${he}:${Qe}`}const ce=ye(()=>n.value.length===0?null:n.value[l.value-1]||null),oe=ye(()=>l.value>=n.value.length?null:n.value[l.value]||null);function le(fe){var $t;const he=fe==null?void 0:fe.frontmatter;if((he==null?void 0:he.colorSchema)==="light")return"light";if((he==null?void 0:he.colorSchema)==="dark")return"dark";if(typeof(he==null?void 0:he.class)=="string"){const at=he.class.split(/\s+/);if(at.includes("light"))return"light";if(at.includes("dark"))return"dark"}const Qe=(he==null?void 0:he.background)||(($t=s.value)==null?void 0:$t.background),lt=Qa(Qe);return lt===!0?"light":lt===!1?"dark":x.value}const Se=ye(()=>le(ce.value)),$e=ye(()=>le(oe.value)),ke=ye(()=>ce.value?qg(ce.value):c.value),Ce=ye(()=>l.value>1||r.value>0),R=ye(()=>l.value<u.value||r.value<ke.value),ie=ye(()=>Ml(ce.value,{config:s.value,allSlides:n.value,pageIndex:l.value,currentStep:r.value})),B=ye(()=>Ml(oe.value,{config:s.value,allSlides:n.value,pageIndex:l.value+1})),W=ye(()=>{var he;if(!ce.value)return"无内容";const fe=(he=ce.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value} 页`});function w(fe){return(fe||[]).slice(1).map(he=>(he.content||he.rawMarkdown||"").trim()).filter(he=>he&&!/^(image\s+)?assets\/\S*$/i.test(he)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(he)).join(" | ").slice(0,120)}const q=ye(()=>{var fe;return w((fe=ce.value)==null?void 0:fe.blocks)}),z=ye(()=>{var he;if(!oe.value)return"演示结束";const fe=(he=oe.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value+1} 页`}),C=ye(()=>oe.value?w(oe.value.blocks):"这是最后一页"),$=ye(()=>{var fe;return((fe=ce.value)==null?void 0:fe.notes)||""}),O=pe(20);function G(){O.value<36&&(O.value+=2)}function K(){O.value>14&&(O.value-=2)}const Y=ye(()=>u.value<=1?100:Math.round(l.value/u.value*100));let X=null;try{X=new BroadcastChannel("siyuan-slides-sync"),X.onmessage=fe=>{const he=fe.data;if(he&&(he.type==="SYNC_PAGE"&&typeof he.page=="number"&&(l.value=he.page,r.value=typeof he.step=="number"?Math.max(0,he.step):0,typeof he.maxStep=="number"&&(c.value=Math.max(0,he.maxStep))),he.type==="SYNC_SLIDES"&&Array.isArray(he.slides)&&(n.value=he.slides,he.config&&typeof he.config=="object"&&(s.value=he.config)),he.type==="REQUEST_SYNC"&&n.value.length>0))try{X==null||X.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),X==null||X.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:ke.value})}catch{}}}catch{X=null}function ae(fe,he=0){const Qe=Number(fe)||1,lt=Math.max(0,Number(he)||0);i.navigatePage(Qe,lt);try{X==null||X.postMessage({type:"SYNC_PAGE",page:Qe,step:lt,maxStep:ke.value})}catch{}}function ne(){if(r.value<ke.value){r.value++,ae(l.value,r.value);return}l.value<u.value&&(l.value++,r.value=0,ae(l.value,0))}function me(){if(r.value>0){r.value--,ae(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,ae(l.value,0))}function _e(){l.value<u.value&&(l.value++,r.value=0,ae(l.value,0))}function we(){l.value>1&&(l.value--,r.value=0,ae(l.value,0))}function Le(){l.value=1,r.value=0,L(),ae(1,0)}function He(){const fe=o;typeof(fe==null?void 0:fe.openBottomPreviewTab)=="function"&&fe.openBottomPreviewTab()}function Ke(){const fe=o;typeof(fe==null?void 0:fe.openStandalonePreviewWindow)=="function"&&fe.openStandalonePreviewWindow()}function rt(fe){var he,Qe;if(!(fe.key===" "&&((Qe=(he=fe.target)==null?void 0:he.closest)!=null&&Qe.call(he,"button")))){if(fe.shiftKey&&fe.key==="ArrowRight"||fe.key==="ArrowDown"){fe.preventDefault(),_e();return}if(fe.shiftKey&&fe.key==="ArrowLeft"||fe.key==="ArrowUp"){fe.preventDefault(),we();return}fe.key==="ArrowRight"||fe.key===" "||fe.key==="PageDown"?(fe.preventDefault(),ne()):(fe.key==="ArrowLeft"||fe.key==="PageUp")&&(fe.preventDefault(),me())}}let Pe=0;function ft(fe){var lt,$t;if(Math.abs(fe.deltaY)<Jy)return;const he=($t=(lt=fe.target)==null?void 0:lt.closest)==null?void 0:$t.call(lt,".notes-content");if(he){const at=he.scrollHeight-he.clientHeight;if(at>2&&(fe.deltaY>0&&he.scrollTop<at-1||fe.deltaY<0&&he.scrollTop>1))return}const Qe=Date.now();Qe-Pe<Zy||(Pe=Qe,fe.deltaY>0?ne():me())}let tt=null,Ge=null;return ti(()=>{var he;g.value=Fo(),Ge=ec(Qe=>{g.value=Qe}),S=Date.now(),P=0,D=window.setInterval(I,500),typeof document<"u"&&document.addEventListener("visibilitychange",I),Z(),V=window.setInterval(Z,1e3),tt=i.onSlideChanged((Qe,lt,$t,at,ao)=>{l.value=Qe,lt>0&&(a.value=lt),typeof at=="number"&&(r.value=Math.max(0,at)),typeof ao=="number"&&(c.value=Math.max(0,ao))});try{X==null||X.postMessage({type:"REQUEST_SYNC"})}catch{}const fe=o==null?void 0:o.latestCompiledDoc;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides,fe.config&&(s.value=fe.config)),typeof window<"u"&&window.addEventListener("resize",N),Ln(()=>{H(),N()})}),sn(()=>{Ge&&(Ge(),Ge=null),D&&(window.clearInterval(D),D=null),typeof document<"u"&&document.removeEventListener("visibilitychange",I),V&&(window.clearInterval(V),V=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",N),F&&(F.disconnect(),F=null);try{X==null||X.close()}catch{}X=null}),t({updateDocument(fe){var he;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides),fe!=null&&fe.config&&(s.value=fe.config)}}),(fe,he)=>{var Qe,lt,$t;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:ft},[f("header",Gg,[f("div",Yg,[f("div",Zg,[se(de,{name:"presenter",class:"brand-icon"}),he[1]||(he[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Jg,[f("span",Xg,"P."+ve(l.value)+" / "+ve(u.value||1),1),ke.value>0?(J(),ee("span",Qg,[se(de,{name:"step",class:"pill-icon"}),St(" 步进 "+ve(r.value)+" / "+ve(ke.value),1)])):Ae("",!0)])]),f("div",ey,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ke},[se(de,{name:"window"}),he[2]||(he[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",ty,[se(de,{name:"clock",class:"timer-icon"}),f("span",oy,ve(j.value),1),f("div",iy,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":E.value?"暂停计时":"继续计时",onClick:M},[se(de,{name:E.value?"pause":"play"},null,8,["name"])],8,ny),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:L},[se(de,{name:"reset"})])])]),f("div",sy,[f("span",null,ve(te.value),1)])])]),u.value>0?(J(),ee("main",ry,[f("section",ly,[f("div",ay,[f("div",cy,[f("div",dy,[he[3]||(he[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",uy,"P."+ve(l.value),1)]),f("div",fy,[ke.value>0?(J(),ee("span",hy," 步进 "+ve(r.value)+" / "+ve(ke.value),1)):Ae("",!0),f("span",py,ve(((lt=(Qe=ce.value)==null?void 0:Qe.frontmatter)==null?void 0:lt.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:h,class:"panel-preview","aria-label":W.value},[ce.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:to({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[f("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":Se.value,"data-slides-theme":y.value,"data-normalize-headings":k.value?"true":"false","data-hide-unordered-markers":v.value?"true":"false","data-hide-ordered-markers":_.value?"true":"false",style:to({width:p.value.baseWidth+"px",height:p.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:ie.value},null,14,gy)],4)):(J(),ee("div",yy,[f("h2",null,ve(W.value),1),f("p",null,ve(q.value),1)]))],8,my)]),f("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:he[0]||(he[0]=at=>oe.value&&_e())},[f("div",vy,[f("div",ky,[he[4]||(he[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<u.value?(J(),ee("span",wy,"P."+ve(l.value+1),1)):Ae("",!0)]),f("div",xy,[l.value>=u.value?(J(),ee("span",Sy,"已到尾页")):oe.value?(J(),ee("span",Cy,ve((($t=oe.value.frontmatter)==null?void 0:$t.layout)||"default"),1)):Ae("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:m,class:"panel-preview panel-preview--dim","aria-label":z.value},[oe.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:to({width:T.value.boxWidth+"px",height:T.value.boxHeight+"px"})},[f("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":$e.value,"data-slides-theme":y.value,"data-normalize-headings":k.value?"true":"false","data-hide-unordered-markers":v.value?"true":"false","data-hide-ordered-markers":_.value?"true":"false",style:to({width:p.value.baseWidth+"px",height:p.value.baseHeight+"px",transform:"scale("+T.value.scale+")"}),innerHTML:B.value},null,14,Iy)],4)):(J(),ee("div",$y,[f("h2",null,ve(z.value),1),f("p",null,ve(C.value),1)]))],8,_y)],10,by)]),f("section",Ty,[f("div",Ay,[f("div",My,[se(de,{name:"notes",class:"panel-title-icon"}),he[5]||(he[5]=f("span",null,"讲稿备忘",-1))]),f("div",Ey,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:O.value<=14,onClick:K},[se(de,{name:"minus"})],8,By),f("span",Dy,ve(O.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:O.value>=36,onClick:G},[se(de,{name:"plus"})],8,Ly)])]),f("div",{class:xe(["notes-content",{"is-empty":!$.value}]),style:to({fontSize:O.value+"px"})},ve($.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Oy,[f("div",Ny,[se(de,{name:"refresh",class:"empty-icon"})]),he[8]||(he[8]=f("h2",null,"等待大屏放映数据",-1)),he[9]||(he[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",Py,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[se(de,{name:"presenter"}),he[6]||(he[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ke},[se(de,{name:"window"}),he[7]||(he[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",Ry,[f("div",zy,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[se(de,{name:"chevrons-left"}),he[10]||(he[10]=f("span",null,"上一页",-1))],8,Hy),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Ce.value,"aria-label":"回退一步 (←)",onClick:me},[se(de,{name:"chevron-left"}),he[11]||(he[11]=f("span",null,"上一步",-1))],8,Fy)]),f("div",jy,[f("div",Uy,[f("span",Wy,ve(Y.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Le},[se(de,{name:"reset"}),he[12]||(he[12]=f("span",null,"重头放映",-1))])]),f("div",qy,[ke.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ke.value}`},[(J(!0),ee(Je,null,Mt(ke.value,at=>(J(),ee("span",{key:at,class:xe(["step-dot",{"is-active":at<=r.value}])},null,2))),128)),f("span",Ky,ve(r.value)+"/"+ve(ke.value),1)],8,Vy)):Ae("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!R.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:ne},[he[13]||(he[13]=f("span",null,"下一步",-1)),se(de,{name:"chevron-right"})],8,Gy),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:_e},[he[14]||(he[14]=f("span",null,"下一页",-1)),se(de,{name:"chevrons-right"})],8,Yy)])])],32)}}}),Qy=lo(Xy,[["__scopeId","data-v-a3262d13"]]),eb={class:"spm-layout-picker"},tb={class:"spm-layout-picker__grid"},ob=["title","onClick"],ib={class:"spm-layout-icon"},nb={class:"spm-layout-label"},sb=zt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return o.modelValue===r||r==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")}function l(r){i("update:modelValue",r),i("change",r)}return(r,a)=>(J(),ee("div",eb,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",tb,[(J(),ee(Je,null,Mt(n,c=>f("div",{key:c.name,class:xe(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[f("div",ib,[se(de,{name:"layout-"+c.name},null,8,["name"])]),f("span",nb,ve(c.label),1)],10,ob)),64))])]))}}),rb=lo(sb,[["__scopeId","data-v-b27a1cea"]]),lb={key:0,class:"spm-transition-selector__header"},ab={class:"spm-transition-list"},cb=["onClick"],db={class:"spm-transition-meta"},ub={class:"spm-transition-label"},fb={class:"spm-transition-preview-box"},hb=zt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,l)=>(J(),ee("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Ae("",!0):(J(),ee("div",lb,ve(e.title||"转场动效"),1)),f("div",ab,[(J(),ee(Je,null,Mt(i,r=>f("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>n(r.name)},[f("div",db,[f("span",ub,ve(r.label),1)]),f("div",fb,[f("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,cb)),64))])],2))}}),yc=lo(hb,[["__scopeId","data-v-4692a5d3"]]),pb={class:"spm-section spm-section--page"},mb={class:"spm-section-header"},gb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},yb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},bb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},vb={key:1,class:"spm-card-control"},kb={class:"spm-control-header"},wb={class:"spm-control-title-group"},xb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设置各列横向空间占比，默认平均分配"},Sb={class:"spm-quick-chips"},Cb=["onClick"],_b={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ib=["value"],$b=["aria-label"],Tb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Ab={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Mb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Eb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Bb={class:"spm-card-control"},Db={class:"spm-control-header"},Lb={class:"spm-control-title-group"},Ob={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"覆盖本页内衬、内容间隙与正文行距"},Nb={class:"spm-segmented-group"},Pb={class:"spm-card-control"},Rb={class:"spm-control-header"},zb={class:"spm-control-title-group"},Hb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"随着点击操作分段展露正文内容"},Fb={class:"spm-segmented-group"},jb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Ub={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Wb=["aria-label"],qb={class:"spm-quick-chips"},Vb=["onClick"],Kb=["value"],Gb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Yb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Zb={style:{flex:"1"}},Jb={class:"spm-segmented-group"},Xb={style:{flex:"1"}},Qb={class:"spm-segmented-group"},ev={key:2,class:"spm-card-control"},tv={class:"spm-control-header"},ov={class:"spm-control-title-group"},iv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"图文分栏或页面专属配图 URL / 资源路径"},nv={class:"spm-quick-chips"},sv=["onClick"],rv=["value"],lv={class:"spm-card-control"},av={class:"spm-control-header"},cv={class:"spm-control-title-group"},dv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"正文备注块驱动 · 仅演讲者视图可见"},uv={key:0,class:"spm-note-status-box"},fv=["title"],hv={class:"spm-action-grid",style:{"margin-top":"6px"}},pv={key:1,class:"spm-note-empty-box"},mv={class:"spm-card-control"},gv={class:"spm-action-grid"},yv=["disabled","aria-label"],bv=zt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider","convertToSuperBlock"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>{const x=o.pageMask;return x==="clockwise"||x==="counter-clockwise"||x==="cw"||x==="ccw"}),l=ye(()=>s.value?"1:1:1:1":"1:1"),r=ye(()=>o.pageMaskRatio||l.value);function a(x){i("update:pageMask",x),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(x){i("update:pageMask",x),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ye(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),h=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),m=ye(()=>{var v,_;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const x=(o.pageLayoutRatio||"").trim();if(x.includes(":")){const A=x.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const k=(o.detectedSbRatio||"").trim();if(k.includes(":")){const A=k.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((v=o.detectedSbInfo)!=null&&v.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((_=o.detectedSbInfo)!=null&&_.slots&&Array.isArray(o.detectedSbInfo.slots)){const A=o.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),d=ye(()=>{const x=m.value;return x===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:x===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:x===5?[{label:"默认 1:1:1:1:1",value:""}]:x===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ye(()=>o.pageLayoutRatio||"");function g(){const x=m.value||2,k=Array(x).fill("1").join(":");i("update:pageLayoutRatio",k),i("resetSuperblockRatio")}const p=ye(()=>{if(!o.pageNotes)return"";const x=o.pageNotes.replace(/[\r\n]+/g," ").trim();return x.length>50?x.slice(0,50)+"...":x}),y=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(x,k)=>(J(),ee("div",pb,[f("div",mb,[f("span",null,"幻灯片页面设置"+ve(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),se(rb,{"model-value":e.pageLayout,onChange:k[0]||(k[0]=v=>x.$emit("update:pageLayout",v))},null,8,["model-value"]),!h.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",gb,[f("div",yb,[f("div",bb,[se(de,{name:"sparkles"}),f("span",null,[k[30]||(k[30]=St("检测到本页横向超级块列宽比例：",-1)),f("b",null,ve(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:k[1]||(k[1]=v=>x.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[se(de,{name:"columns"}),k[31]||(k[31]=f("span",null,"设为分栏",-1))])])])):Ae("",!0),h.value?(J(),ee("div",vb,[f("div",kb,[f("div",wb,[f("div",xb,[se(de,{name:"ratio"}),k[32]||(k[32]=f("span",null,"分栏比例",-1))])])]),f("div",Sb,[(J(!0),ee(Je,null,Mt(d.value,v=>(J(),ee("button",{key:v.value,class:xe(["spm-chip",{active:b.value===v.value}]),onClick:_=>x.$emit("update:pageLayoutRatio",v.value)},ve(v.label),11,Cb))),128))]),f("div",_b,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:k[2]||(k[2]=v=>x.$emit("update:pageLayoutRatio",v.target.value)),onChange:k[3]||(k[3]=v=>x.$emit("update:pageLayoutRatio",v.target.value))},null,40,Ib),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:k[4]||(k[4]=v=>x.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[se(de,{name:"sparkles"}),k[33]||(k[33]=f("span",null,"读取",-1))],8,$b)):(J(),ee("button",Tb,[se(de,{name:"sparkles"}),k[34]||(k[34]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:g},[se(de,{name:"reset"}),k[35]||(k[35]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",Ab,[se(de,{name:"ratio"}),k[36]||(k[36]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",Mb,ve(e.detectedSbRatio),1)])):(J(),ee("div",Eb,[se(de,{name:"ratio"}),k[37]||(k[37]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ae("",!0),f("div",Bb,[f("div",Db,[f("div",Lb,[f("div",Ob,[se(de,{name:"ratio"}),k[38]||(k[38]=f("span",null,"页面间距",-1))])])]),f("div",Nb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:k[5]||(k[5]=v=>x.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:k[6]||(k[6]=v=>x.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:k[7]||(k[7]=v=>x.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:k[8]||(k[8]=v=>x.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),se(yc,{"model-value":e.pageTransition,onChange:k[9]||(k[9]=v=>x.$emit("update:pageTransition",v))},null,8,["model-value"]),f("div",Pb,[f("div",Rb,[f("div",zb,[f("div",Hb,[se(de,{name:"sparkles"}),k[39]||(k[39]=f("span",null,"页面动态蒙版",-1))])])]),f("div",Fb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:k[10]||(k[10]=v=>x.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:k[11]||(k[11]=v=>c("down"))}," 从上至下 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:k[12]||(k[12]=v=>c("right"))}," 从左至右 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:k[13]||(k[13]=v=>a("clockwise"))}," 顺时针 ↻ ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:k[14]||(k[14]=v=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",jb,[f("div",Ub,[k[41]||(k[41]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[se(de,{name:"help"}),k[40]||(k[40]=f("span",null,"输入规则",-1))],8,Wb)]),f("div",qb,[(J(),ee(Je,null,Mt(n,v=>f("button",{key:v.value,class:xe(["spm-chip",{active:r.value===v.value}]),onClick:_=>x.$emit("update:pageMaskRatio",v.value)},ve(v.label),11,Vb)),64))]),f("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:k[15]||(k[15]=v=>x.$emit("update:pageMaskRatio",v.target.value)),onChange:k[16]||(k[16]=v=>x.$emit("update:pageMaskRatio",v.target.value))},null,40,Kb),f("div",Gb,ve(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),f("div",Yb,[f("div",Zb,[k[42]||(k[42]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Jb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:k[17]||(k[17]=v=>x.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:k[18]||(k[18]=v=>x.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",Xb,[k[43]||(k[43]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Qb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:k[19]||(k[19]=v=>x.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:k[20]||(k[20]=v=>x.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Ae("",!0)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",ev,[f("div",tv,[f("div",ov,[f("div",iv,[se(de,{name:"image"}),k[44]||(k[44]=f("span",null,"页面图片",-1))])])]),f("div",nv,[(J(),ee(Je,null,Mt(y,v=>f("button",{key:v.value,class:xe(["spm-chip",{active:e.pageImage===v.value}]),onClick:_=>x.$emit("update:pageImage",v.value)},ve(v.label),11,sv)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:k[21]||(k[21]=v=>x.$emit("update:pageImage",v.target.value)),onChange:k[22]||(k[22]=v=>x.$emit("update:pageImage",v.target.value))},null,40,rv)])):Ae("",!0),f("div",lv,[f("div",av,[f("div",cv,[f("div",dv,[se(de,{name:"presenter"}),k[45]||(k[45]=f("span",null,"演讲者提词",-1))])]),ue(Ot)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:k[23]||(k[23]=v=>x.$emit("generateNotes"))},[se(de,{name:"sparkles"}),k[46]||(k[46]=f("span",null,"AI 讲稿",-1))])):Ae("",!0)]),e.pageNotes?(J(),ee("div",uv,[k[49]||(k[49]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},ve(p.value),9,fv),f("div",hv,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:k[24]||(k[24]=v=>x.$emit("locateNoteBlock"))},[se(de,{name:"search"}),k[47]||(k[47]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:k[25]||(k[25]=v=>x.$emit("addNoteBlock"))},[se(de,{name:"insert-below"}),k[48]||(k[48]=f("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",pv,[k[51]||(k[51]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:k[26]||(k[26]=v=>x.$emit("addNoteBlock"))},[se(de,{name:"insert-below"}),k[50]||(k[50]=f("span",null,"添加讲稿备注块",-1))])]))]),f("div",mv,[k[55]||(k[55]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",gv,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:k[27]||(k[27]=v=>x.$emit("insertDividerAfter"))},[se(de,{name:"insert-below"}),k[52]||(k[52]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:k[28]||(k[28]=v=>x.$emit("deleteDivider"))},[se(de,{name:"trash"}),k[53]||(k[53]=f("span",null,"删除此页",-1))]),f("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:k[29]||(k[29]=v=>x.$emit("convertToSuperBlock"))},[se(de,{name:"columns"}),k[54]||(k[54]=f("span",null,"转为超级块",-1))],10,yv)])])]))}}),vv=lo(bv,[["__scopeId","data-v-e67be1a7"]]),kv={class:"spm-section spm-section--block"},wv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},xv={class:"spm-control-header"},Sv={class:"spm-control-title-group"},Cv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"读取思源超级块列宽并一键同步到幻灯片分栏"},_v={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Iv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},$v={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Tv={key:0},Av={key:1},Mv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Ev={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Bv={class:"spm-action-grid"},Dv={key:1,class:"spm-card-control"},Lv={class:"spm-control-header"},Ov={class:"spm-control-title-group"},Nv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设为幻灯片背景图或图文分栏配图"},Pv={class:"spm-quick-chips"},Rv={key:2,class:"spm-card-control"},zv={class:"spm-control-header"},Hv={class:"spm-control-title-group"},Fv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"配置播放器控制条、自动播放与循环"},jv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Uv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Wv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},qv=["aria-label"],Vv=["checked"],Kv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Gv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Yv=["aria-label"],Zv=["checked"],Jv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Xv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Qv=["aria-label"],e1=["checked"],t1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},o1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},i1=["aria-label"],n1=["checked"],s1={class:"spm-card-control"},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"放映时按步长逐个呈现"},c1=["aria-label"],d1=["checked"],u1={key:0,class:"spm-quick-chips"},f1=["onClick"],h1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},p1={class:"spm-card-control"},m1={class:"spm-control-header"},g1={class:"spm-control-title-group"},y1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"为当前块添加平滑位移与渐入动画"},b1=["aria-label"],v1=["checked"],k1={key:0,class:"spm-quick-chips"},w1=["onClick"],x1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},S1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},C1={style:{display:"flex",gap:"6px"}},_1=["value"],I1=["value"],$1={key:3,class:"spm-card-control"},T1={class:"spm-control-header"},A1={class:"spm-control-title-group"},M1=["aria-label"],E1={class:"spm-segmented-group"},B1=["onClick"],D1={key:4,class:"spm-card-control"},L1={class:"spm-control-header"},O1={class:"spm-control-title-group"},N1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"翻页时动态聚光高亮特定行"},P1={class:"spm-quick-chips"},R1=["onClick"],z1=["value"],H1={key:5,class:"spm-card-control"},F1={class:"spm-control-header"},j1={class:"spm-control-title-group"},U1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"超出限高自动竖向滚动，弱提示滚动条"},W1={class:"spm-quick-chips"},q1=["onClick"],V1=["value"],K1={class:"spm-card-control"},G1={class:"spm-action-grid"},Y1=["aria-label"],Z1=["disabled","aria-label"],J1=["disabled","aria-label"],X1=zt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","convertToSuperBlock","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ye(()=>{const A=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":A}),n=ye(()=>{const A=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),s=ye(()=>{var T,N,F,H;if((T=o.detectedSbInfo)!=null&&T.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const A=(N=o.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(A){const U=parseInt(A[1],10);if(U>=2&&U<=6)return Math.max(U,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((H=(F=o.detectedSbInfo)==null?void 0:F.ratio)!=null&&H.includes(":")){const U=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(U.length>=2)return Math.min(U.length,6)}return 3}),l=ye(()=>{const A=i.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=i.value;return A==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const A=i.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const T=s.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let F=1;F<=T;F++)N.push({value:`col-${F}`,label:`第 ${F} 栏`});return N});function c(A){const T=o.elemSlot||"";return A?T===A||A==="col-1"&&T==="left"||A==="col-2"&&T==="center"||A==="col-3"&&T==="right"&&s.value===3||A==="col-2"&&T==="right"&&s.value===2||A==="left"&&T==="col-1"||A==="right"&&(T==="col-2"||T==="col-3"):!T||T==="default"}const u=t,h=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],m=ye(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const A=JSON.parse(o.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!m.value),b=ye(()=>{var A;return((A=m.value)==null?void 0:A.preset)||"slide-up"}),g=ye(()=>{var A;return((A=m.value)==null?void 0:A.duration)||0}),p=ye(()=>{var A;return((A=m.value)==null?void 0:A.delay)||0});function y(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(A){_(A,g.value,p.value)}function k(A){_(b.value,A,p.value)}function v(A){_(b.value,g.value,A)}function _(A,T,N){if(!A||A==="none"){u("update:elemMotion","");return}if(!T&&!N){u("update:elemMotion",A);return}const F={preset:A};T>0&&(F.duration=T),N>0&&(F.delay=N),u("update:elemMotion",JSON.stringify(F))}return(A,T)=>{var N,F,H,U,E,D;return J(),ee("div",kv,[T[53]||(T[53]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(N=e.detectedSbInfo)!=null&&N.hasSuperBlock?(J(),ee("div",wv,[f("div",xv,[f("div",Sv,[f("div",Cv,[se(de,{name:"ratio"}),T[24]||(T[24]=f("span",null,"超级块列宽与布局",-1))])])]),f("div",_v,[f("div",Iv,[f("div",$v,[se(de,{name:"ratio"}),(F=e.detectedSbInfo)!=null&&F.isCustomWidth?(J(),ee("span",Tv,"已识别自定义列宽比例")):(J(),ee("span",Av,"识别到 "+ve(((H=e.detectedSbInfo)==null?void 0:H.colCount)||2)+" 列超级块分栏",1))]),f("code",Mv,ve(((U=e.detectedSbInfo)==null?void 0:U.ratio)||"1:1"),1)]),f("div",Ev,ve((E=e.detectedSbInfo)!=null&&E.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",Bv,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:T[0]||(T[0]=S=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[se(de,{name:"sparkles"}),T[25]||(T[25]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:T[1]||(T[1]=S=>{var P;return A.$emit("applySuperBlockRatio",((P=e.detectedSbInfo)==null?void 0:P.ratio)||"1:1")})},[se(de,{name:"check"}),f("span",null,"应用比例 ("+ve(((D=e.detectedSbInfo)==null?void 0:D.ratio)||"1:1")+")",1)])])])):Ae("",!0),e.isImage||e.imageRole?(J(),ee("div",Dv,[f("div",Lv,[f("div",Ov,[f("div",Nv,[se(de,{name:"image"}),T[26]||(T[26]=f("span",null,"图片角色与分栏",-1))])])]),f("div",Pv,[f("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:T[2]||(T[2]=S=>A.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:T[3]||(T[3]=S=>A.$emit("update:imageRole","background"))},[se(de,{name:"image"}),T[27]||(T[27]=f("span",null,"背景图",-1))],2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:T[4]||(T[4]=S=>A.$emit("update:imageRole","image-left"))},[se(de,{name:"image-left"}),T[28]||(T[28]=f("span",null,"图左",-1))],2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:T[5]||(T[5]=S=>A.$emit("update:imageRole","image-right"))},[se(de,{name:"image-right"}),T[29]||(T[29]=f("span",null,"图右",-1))],2)])])):Ae("",!0),e.isVideo?(J(),ee("div",Rv,[f("div",zv,[f("div",Hv,[f("div",Fv,[se(de,{name:"video"}),T[30]||(T[30]=f("span",null,"视频播放设置",-1))])])]),f("div",jv,[f("div",Uv,[f("span",Wv,[se(de,{name:"sliders"}),T[31]||(T[31]=St(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:T[6]||(T[6]=S=>A.$emit("toggleVideoControls"))},null,40,Vv),T[32]||(T[32]=f("span",{class:"spm-switch-slider"},null,-1))],8,qv)]),f("div",Kv,[f("span",Gv,[se(de,{name:"video"}),T[33]||(T[33]=St(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:T[7]||(T[7]=S=>A.$emit("toggleVideoAutoplay"))},null,40,Zv),T[34]||(T[34]=f("span",{class:"spm-switch-slider"},null,-1))],8,Yv)]),f("div",Jv,[f("span",Xv,[se(de,{name:"repeat"}),T[35]||(T[35]=St(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:T[8]||(T[8]=S=>A.$emit("toggleVideoLoop"))},null,40,e1),T[36]||(T[36]=f("span",{class:"spm-switch-slider"},null,-1))],8,Qv)]),f("div",t1,[f("span",o1,[se(de,{name:"volume-x"}),T[37]||(T[37]=St(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:T[9]||(T[9]=S=>A.$emit("toggleVideoMuted"))},null,40,n1),T[38]||(T[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,i1)])])])):Ae("",!0),f("div",s1,[f("div",r1,[f("div",l1,[f("div",a1,[se(de,{name:"step"}),T[39]||(T[39]=f("span",null,"逐步呈现",-1))])]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:T[10]||(T[10]=S=>A.$emit("toggleElemClick"))},null,40,d1),T[40]||(T[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,c1)]),e.elemClick?(J(),ee("div",u1,[(J(),ee(Je,null,Mt(["+1","1","2","hide"],S=>f("button",{key:S,class:xe(["spm-chip",{active:e.elemClick===S}]),onClick:P=>A.$emit("update:elemClick",S)},ve(S==="+1"?"顺延 (+1)":S==="hide"?"隐藏":"第 "+S+" 步"),11,f1)),64))])):e.parentElemClick?(J(),ee("div",h1,[se(de,{name:"check"}),T[41]||(T[41]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ae("",!0)]),f("div",p1,[f("div",m1,[f("div",g1,[f("div",y1,[se(de,{name:"motion"}),T[42]||(T[42]=f("span",null,"入场微动效",-1))])]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[f("input",{type:"checkbox",checked:d.value,onChange:y},null,40,v1),T[43]||(T[43]=f("span",{class:"spm-switch-slider"},null,-1))],8,b1)]),d.value?(J(),ee("div",k1,[(J(),ee(Je,null,Mt(h,S=>f("button",{key:S.value,class:xe(["spm-chip",{active:b.value===S.value}]),onClick:P=>x(S.value)},ve(S.label),11,w1)),64))])):Ae("",!0),d.value?(J(),ee("div",x1,[f("div",S1,[f("span",null,"时长: "+ve(g.value?g.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+ve(p.value?p.value+"ms":"0ms"),1)]),f("div",C1,[f("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:T[11]||(T[11]=S=>k(Number(S.target.value)))},[...T[44]||(T[44]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,_1),f("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:T[12]||(T[12]=S=>v(Number(S.target.value)))},[...T[45]||(T[45]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,I1)])])):Ae("",!0)]),n.value||e.elemSlot?(J(),ee("div",$1,[f("div",T1,[f("div",A1,[f("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":r.value},[se(de,{name:"columns"}),f("span",null,ve(l.value),1)],8,M1)])]),f("div",E1,[(J(!0),ee(Je,null,Mt(a.value,S=>(J(),ee("button",{key:S.value,class:xe(["spm-segmented-item",{active:c(S.value)}]),onClick:P=>A.$emit("update:elemSlot",S.value)},ve(S.label),11,B1))),128))])])):Ae("",!0),e.isCodeBlock?(J(),ee("div",D1,[f("div",L1,[f("div",O1,[f("div",N1,[se(de,{name:"code"}),T[46]||(T[46]=f("span",null,"代码逐行聚光",-1))])])]),f("div",P1,[(J(),ee(Je,null,Mt(["1-3","all","1|2|3","2-5"],S=>f("button",{key:S,class:xe(["spm-chip",{active:e.elemShikiLines===S}]),onClick:P=>A.$emit("update:elemShikiLines",S)},ve(S),11,R1)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:T[13]||(T[13]=S=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Ae("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:T[14]||(T[14]=S=>A.$emit("update:elemShikiLines",S.target.value)),onChange:T[15]||(T[15]=S=>A.$emit("update:elemShikiLines",S.target.value))},null,40,z1)])):Ae("",!0),e.isCodeBlock?(J(),ee("div",H1,[f("div",F1,[f("div",j1,[f("div",U1,[se(de,{name:"code"}),T[47]||(T[47]=f("span",null,"代码块限高",-1))])])]),f("div",W1,[(J(),ee(Je,null,Mt(["240px","320px","400px","50%"],S=>f("button",{key:S,class:xe(["spm-chip",{active:e.elemMaxHeight===S||S==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:P=>A.$emit("update:elemMaxHeight",S)},ve(S),11,q1)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:T[16]||(T[16]=S=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ae("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:T[17]||(T[17]=S=>A.$emit("update:elemMaxHeight",S.target.value)),onChange:T[18]||(T[18]=S=>A.$emit("update:elemMaxHeight",S.target.value))},null,40,V1)])):Ae("",!0),f("div",K1,[T[52]||(T[52]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",G1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:T[19]||(T[19]=S=>A.$emit("insertDividerBefore"))},[se(de,{name:"insert-above"}),T[48]||(T[48]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:T[20]||(T[20]=S=>A.$emit("insertDividerAfter"))},[se(de,{name:"insert-below"}),T[49]||(T[49]=f("span",null,"下方分页",-1))]),f("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:T[21]||(T[21]=S=>A.$emit("toggleNote"))},[se(de,{name:"presenter"}),f("span",null,ve(e.isNote?"取消备注":"设为备注"),1)],10,Y1),f("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:T[22]||(T[22]=S=>A.$emit("clearBlockAttrs"))},[se(de,{name:"broom"}),T[50]||(T[50]=f("span",null,"清除属性",-1))],10,Z1),f("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:T[23]||(T[23]=S=>A.$emit("convertToSuperBlock"))},[se(de,{name:"columns"}),T[51]||(T[51]=f("span",null,"转为超级块",-1))],10,J1)])])])}}}),Q1={class:"spm-section spm-section--doc"},ek={class:"spm-card-control"},tk={class:"spm-control-header"},ok={class:"spm-control-title-group"},ik={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全局幻灯片视觉设计范式"},nk={class:"spm-theme-card-grid"},sk=["aria-label","onClick"],rk={key:0,class:"spm-bg-swatch-check"},lk={class:"spm-theme-card-label"},ak={class:"spm-card-control"},ck={class:"spm-control-header"},dk={class:"spm-control-title-group"},uk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全篇幻灯片统一底色、微渐变或壁纸"},fk={class:"spm-bg-swatch-grid"},hk=["aria-label","onClick"],pk={key:0,class:"spm-bg-swatch-check"},mk={class:"spm-bg-swatch-label"},gk={class:"spm-bg-input-row"},yk=["value"],bk={class:"spm-card-control"},vk={class:"spm-control-header"},kk={class:"spm-control-title-group"},wk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"演讲屏幕投影宽高比"},xk={class:"spm-segmented-group"},Sk={class:"spm-card-control"},Ck={class:"spm-control-header"},_k={class:"spm-control-title-group"},Ik={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"内衬、内容间隙与正文行距预设"},$k={class:"spm-segmented-group"},Tk={class:"spm-card-control"},Ak={class:"spm-control-header"},Mk={class:"spm-control-title-group"},Ek={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"页面切换过渡动效（未单设转场的页面将继承此动效）"},Bk={class:"spm-card-control"},Dk={class:"spm-action-grid"},Lk=["disabled"],Ok=["disabled"],Nk=["disabled"],Pk=["disabled"],Rk=["disabled"],zk=["aria-expanded"],Hk={class:"spm-advanced-toggle-label"},Fk={key:0,class:"spm-advanced-content"},jk={class:"spm-card-control"},Uk={class:"spm-control-header"},Wk={class:"spm-control-title-group"},qk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"点击文档/块链接以 Webview 抽屉呈现，支持外跳"},Vk=["aria-label"],Kk=["checked"],Gk={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Yk=["value"],Zk={class:"spm-card-control"},Jk={class:"spm-control-header"},Xk={class:"spm-control-title-group"},Qk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示"},e0=["aria-label"],t0=["checked"],o0={class:"spm-card-control"},i0={class:"spm-control-header"},n0={class:"spm-control-title-group"},s0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"分别控制正文中无序列表圆点与有序列表数字序号的呈现"},r0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},l0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},a0=["aria-label"],c0=["checked"],d0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},u0=["aria-label"],f0=["checked"],h0={class:"spm-card-control"},p0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},y0={key:0,class:"api-switch-managed-tip",style:{"margin-top":"8px","background-color":"var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08))",border:"1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2))","border-radius":"6px",padding:"8px 10px","font-size":"11px","line-height":"1.4",color:"var(--b3-theme-on-background)"}},b0={class:"spm-control-body",style:{"margin-top":"8px",display:"flex","flex-direction":"column",gap:"6px"}},v0={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},k0=["value","disabled"],w0={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},x0=["value","disabled"],S0={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},C0=["value","disabled"],_0=zt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf"],setup(e){const t=Vt("plugin"),o=Ht,i=ts,n=pe(!1);function s(){t&&typeof t.openSetting=="function"&&t.openSetting()}async function l(k){const v=o.aiConfig,_=bi({...v,model:k});ht({aiConfig:_}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({aiConfig:_}),c(_)}async function r(k){const v=o.aiConfig,_=bi({...v,baseUrl:k});ht({aiConfig:_}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({aiConfig:_}),c(_)}async function a(k){const v=o.aiConfig,_=bi({...v,apiKey:k});ht({aiConfig:_}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({aiConfig:_}),c(_)}function c(k){typeof window<"u"&&window.siyuanApiSwitch&&(t!=null&&t.name)&&window.siyuanApiSwitch.updateLocalConfig(t.name,{provider:"custom",baseUrl:k.baseUrl,apiKey:k.apiKey,model:k.model,requestTimeoutSeconds:k.requestTimeoutSeconds,temperature:k.temperature,maxTokens:k.maxTokens})}const u=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function h(k){ht({enableWebServeJump:k}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:k})}async function m(k){var v;ht({normalizeHeadingSizes:k}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:k}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((v=t.getActiveDocumentId)==null?void 0:v.call(t)))}async function d(k){var v;ht({showUnorderedListMarkers:k}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:k}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((v=t.getActiveDocumentId)==null?void 0:v.call(t)))}async function b(k){var v;ht({showOrderedListMarkers:k}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:k}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((v=t.getActiveDocumentId)==null?void 0:v.call(t)))}function g(k){ht({webServeUrl:k})}function p(k){ht({webServeUrl:k}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:k})}const y=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function x(k){const v=(k||"").trim();return v?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(v)?{backgroundImage:`url("${v.startsWith("assets/")?`/${v}`:v.startsWith("./assets/")?v.slice(1):v}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:v}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}return(k,v)=>(J(),ee("div",Q1,[v[66]||(v[66]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",ek,[f("div",tk,[f("div",ok,[f("div",ik,[se(de,{name:"palette"}),v[32]||(v[32]=f("span",null,"幻灯片主题",-1))])])]),f("div",nk,[(J(),ee(Je,null,Mt(u,(_,A)=>f("button",{key:_.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+_.value,A===0?"b3-tooltips__ne":A===u.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===_.value}]]),"aria-label":_.desc,onClick:T=>k.$emit("update:docTheme",_.value)},[f("span",{class:xe(["spm-theme-card-preview","theme-preview--"+_.value]),"aria-hidden":"true"},[v[33]||(v[33]=mt('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===_.value?(J(),ee("span",rk,"✓")):Ae("",!0)],2),f("span",lk,ve(_.label),1)],10,sk)),64))])]),f("div",ak,[f("div",ck,[f("div",dk,[f("div",uk,[se(de,{name:"palette"}),v[34]||(v[34]=f("span",null,"演示背景",-1))])])]),f("div",fk,[(J(),ee(Je,null,Mt(y,_=>f("button",{key:_.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===_.value,"is-default":!_.value}]),"aria-label":_.desc,onClick:A=>k.$emit("update:docBackground",_.value)},[f("span",{class:"spm-bg-swatch-preview",style:to(x(_.value))},[f("span",{class:xe(["spm-bg-swatch-aa","is-"+_.mode])},"Aa",2),(e.docBackground||"")===_.value?(J(),ee("span",pk,"✓")):Ae("",!0)],4),f("span",mk,ve(_.label),1)],10,hk)),64))]),f("div",gk,[f("span",{class:"spm-bg-input-preview",style:to(x(e.docBackground||"")),"aria-hidden":"true"},null,4),f("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:v[0]||(v[0]=_=>k.$emit("update:docBackground",_.target.value)),onChange:v[1]||(v[1]=_=>k.$emit("update:docBackground",_.target.value))},null,40,yk),e.docBackground?(J(),ee("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:v[2]||(v[2]=_=>k.$emit("update:docBackground",""))}," ✕ ")):Ae("",!0)])]),f("div",bk,[f("div",vk,[f("div",kk,[f("div",wk,[se(de,{name:"ratio"}),v[35]||(v[35]=f("span",null,"画幅比例",-1))])])]),f("div",xk,[f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:v[3]||(v[3]=_=>k.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:v[4]||(v[4]=_=>k.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:v[5]||(v[5]=_=>k.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",Sk,[f("div",Ck,[f("div",_k,[f("div",Ik,[se(de,{name:"ratio"}),v[36]||(v[36]=f("span",null,"间距风格",-1))])])]),f("div",$k,[f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:v[6]||(v[6]=_=>k.$emit("update:docSpacing","compact"))}," 紧凑 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:v[7]||(v[7]=_=>k.$emit("update:docSpacing","normal"))}," 标准 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:v[8]||(v[8]=_=>k.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),f("div",Tk,[f("div",Ak,[f("div",Mk,[f("div",Ek,[se(de,{name:"transition"}),v[37]||(v[37]=f("span",null,"全局默认转场",-1))])])]),se(yc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:v[9]||(v[9]=_=>k.$emit("update:docDefaultTransition",_))},null,8,["model-value"])]),f("div",Bk,[v[48]||(v[48]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",Dk,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:v[10]||(v[10]=_=>k.$emit("openBottomPreview"))},[se(de,{name:"split-preview"}),v[38]||(v[38]=f("span",null,"分屏预览",-1))]),ue(Ot)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:v[11]||(v[11]=_=>k.$emit("openPresenter"))},[se(de,{name:"presenter"}),v[39]||(v[39]=f("span",null,"演讲者视图",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:v[12]||(v[12]=_=>k.$emit("aiAutoSplit"))},[se(de,{name:"sparkles"}),v[40]||(v[40]=f("span",null,"智能分页",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线（需二次确认）",disabled:e.isBatchProcessing,onClick:v[13]||(v[13]=_=>k.$emit("clearDividers"))},[se(de,{name:"trash"}),v[41]||(v[41]=f("span",null,"清除分页",-1))],8,Lk)):Ae("",!0),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:v[14]||(v[14]=_=>k.$emit("autoAnimate"))},[se(de,{name:"step"}),v[42]||(v[42]=f("span",null,"智能动效",-1))],8,Ok),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:v[15]||(v[15]=_=>k.$emit("clearAnimations"))},[se(de,{name:"trash"}),v[43]||(v[43]=f("span",null,"清除动效",-1))],8,Nk),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:v[16]||(v[16]=_=>k.$emit("addOrIdentifyNotes"))},[se(de,{name:"notes"}),v[44]||(v[44]=f("span",null,"增加讲稿块",-1))],8,Pk),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:v[17]||(v[17]=_=>k.$emit("clearNotes"))},[se(de,{name:"trash"}),v[45]||(v[45]=f("span",null,"清除讲稿块",-1))],8,Rk),ue(Ot)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:v[18]||(v[18]=_=>k.$emit("exportHtml"))},[se(de,{name:"export-html"}),v[46]||(v[46]=f("span",null,"导出 HTML",-1))])):Ae("",!0),ue(Ot)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:v[19]||(v[19]=_=>k.$emit("exportPdf"))},[se(de,{name:"export-pdf"}),v[47]||(v[47]=f("span",null,"导出 PDF",-1))])):Ae("",!0)])]),f("div",{class:xe(["spm-advanced-menu",{"is-expanded":n.value}])},[f("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":n.value,onClick:v[20]||(v[20]=_=>n.value=!n.value)},[f("span",Hk,[se(de,{name:"settings"}),v[49]||(v[49]=f("span",null,"高级设置",-1))]),se(de,{name:"chevron-right",class:"spm-advanced-chevron"})],8,zk),n.value?(J(),ee("div",Fk,[f("div",jk,[f("div",Uk,[f("div",Wk,[f("div",qk,[se(de,{name:"external-link"}),v[50]||(v[50]=f("span",null,"本地网络伺服预览",-1))])]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(o).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:ue(o).enableWebServeJump,onChange:v[21]||(v[21]=_=>h(_.target.checked))},null,40,Kk),v[51]||(v[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,Vk)]),ue(o).enableWebServeJump?(J(),ee("div",Gk,[f("input",{value:ue(o).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:v[22]||(v[22]=oo(()=>{},["stop"])),onKeyup:v[23]||(v[23]=oo(()=>{},["stop"])),onInput:v[24]||(v[24]=_=>g(_.target.value)),onChange:v[25]||(v[25]=_=>p(_.target.value))},null,40,Yk)])):Ae("",!0)]),f("div",Zk,[f("div",Jk,[f("div",Xk,[f("div",Qk,[se(de,{name:"type"}),v[52]||(v[52]=f("span",null,"固定特定标题大小",-1))])]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(o).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:ue(o).normalizeHeadingSizes,onChange:v[26]||(v[26]=_=>m(_.target.checked))},null,40,t0),v[53]||(v[53]=f("span",{class:"spm-switch-slider"},null,-1))],8,e0)])]),f("div",o0,[f("div",i0,[f("div",n0,[f("div",s0,[se(de,{name:"list"}),v[54]||(v[54]=f("span",null,"列表前缀标记",-1))])])]),f("div",r0,[f("div",l0,[v[56]||(v[56]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(o).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[f("input",{type:"checkbox",checked:ue(o).showUnorderedListMarkers,onChange:v[27]||(v[27]=_=>d(_.target.checked))},null,40,c0),v[55]||(v[55]=f("span",{class:"spm-switch-slider"},null,-1))],8,a0)]),f("div",d0,[v[58]||(v[58]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(o).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[f("input",{type:"checkbox",checked:ue(o).showOrderedListMarkers,onChange:v[28]||(v[28]=_=>b(_.target.checked))},null,40,f0),v[57]||(v[57]=f("span",{class:"spm-switch-slider"},null,-1))],8,u0)])])]),f("div",h0,[f("div",p0,[f("div",m0,[f("div",g0,[se(de,{name:"sparkles"}),v[59]||(v[59]=f("span",null,"AI 演讲提词服务",-1))]),v[60]||(v[60]=f("span",{class:"spm-control-desc"},"提炼演讲口播提词卡，支持 API 旋钮接管调度",-1))]),f("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开完整设置弹窗",onClick:s},[se(de,{name:"settings"})])]),ue(i)?(J(),ee("div",y0,[v[61]||(v[61]=St(" 💡 通用 AI API 已由 ",-1)),v[62]||(v[62]=f("strong",null,"API 旋钮 (siyuan-api-switch)",-1)),St(" 接管 (Profile: "+ve(ue(i).profileName||"未命名")+")。相关输入框已置灰只读。 ",1)])):Ae("",!0),f("div",b0,[f("div",v0,[v[63]||(v[63]=f("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"模型:",-1)),f("input",{value:ue(i)?ue(i).model:ue(o).aiConfig.model,class:"spm-input",disabled:!!ue(i),placeholder:"例如 deepseek-chat",onChange:v[29]||(v[29]=_=>l(_.target.value))},null,40,k0)]),f("div",w0,[v[64]||(v[64]=f("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"Base URL:",-1)),f("input",{value:ue(i)?ue(i).baseUrl:ue(o).aiConfig.baseUrl,class:"spm-input",disabled:!!ue(i),placeholder:"https://api.openai.com/v1",onChange:v[30]||(v[30]=_=>r(_.target.value))},null,40,x0)]),f("div",S0,[v[65]||(v[65]=f("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"API Key:",-1)),f("input",{value:ue(i)?ue(i).apiKey:ue(o).aiConfig.apiKey,type:"password",class:"spm-input",disabled:!!ue(i),placeholder:"sk-...",onChange:v[31]||(v[31]=_=>a(_.target.value))},null,40,C0)])])])])):Ae("",!0)],2)]))}}),I0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,$0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function T0(e){const t=await dc.loadAsync(e),o={},i=[];let n="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||$0.test(c)||c.includes("snippets/")){const u=await a.file.async("string");o[c]=u;const h=c.split("/");h.length>1&&(o[h.slice(1).join("/")]=u)}else if(I0.test(c)){const u=await a.file.async("uint8array"),h=c.split("/").pop()||c,m=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:h,data:u,blob:m})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function A0(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=o(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=o(r);return a?`src="${a}"`:l}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],l=o(s);l&&(n.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const M0={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function bc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function E0(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,l=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,g]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=g;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const b=require("path");d.push(b.resolve(t.baseDir,r)),d.push(b.resolve(t.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const g=bc(b);if(g!==null){c=g;break}}}if(!c){const d=M0||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[g,p]of Object.entries(d))if(g.endsWith(`/${r}`)||b&&g.endsWith(`/${b}`)){c=p;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const g=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(g?g[1]:"")+b[1].trimEnd()}}const h=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${u}
\`\`\``}function B0(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function xn(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const l=n.indexOf(":");if(l>0){const r=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){i++;const c=[];let u=-1;for(;i<o.length;){const h=o[i];if(!h.trim()){c.push(""),i++;continue}const d=h.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(h.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=B0(a),!a){let c=i+1;const u=[];let h=-1;for(;c<o.length;){const m=o[c],d=m.trim();if(!d||d.startsWith("#")){h!==-1&&u.push(""),c++;continue}const b=m.match(/^(\s+)/),g=b?b[1].length:0;if(h===-1)if(g>0)h=g;else break;if(g<h)break;u.push(m.slice(h)),c++}if(u.length>0){t[r]=xn(u.join(`
`)),i=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}i++}return t}const D0=/^\s*```ya?ml([\s\S]*?)```/;function El(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=xn(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(D0);if(n)t=xn(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=xn(l.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function L0(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(l){if(i>=l)return;const r=t.slice(i,l).join(`
`).trim();r&&o.push(r),i=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];let u=!1,h=-1;const m=c?c.trim():"";if(a.replace(/^-+/,"").trim()===""&&m.length>0){for(let d=l+1;d<t.length;d++){const b=t[d].trimEnd();if(b.startsWith("```"))break;if(b==="---"){h=d;break}}h!==-1&&h-l<=60&&t.slice(l+1,h).some(g=>{const p=g.trim();return p.length>0&&!p.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(p)})&&(u=!0)}u&&h!==-1&&(i=l,l=h)}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let h=l+1;for(;h<t.length&&!t[h].trimStart().startsWith(u);h++);h<t.length&&(l=h)}}return i<t.length&&s(t.length),o}function Sn(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const h=L0(u),m={};let d="",b="",g=0;if(h.length>0){const U=h[0],E=El(U),D=Object.keys(E.frontmatter).length>0,S=E.content.length>0;D&&!S&&h.length>1?(g=1,y(E.frontmatter)):D&&y(E.frontmatter)}function p(U,E,D){const S=String(U);S==="two-cols-header"?E[be]="cols-header":S==="three-cols-header"?(E[be]="cols-header",!D.layoutRatio&&!D["layout-ratio"]&&(E[yt]="1:1:1")):E[be]=S}function y(U){d=U.title||"",U.theme&&(m[Vi]=String(U.theme)),U.aspectRatio&&(m[Ki]=String(U.aspectRatio)),U.transition&&(m[Gi]=String(U.transition)),U.colorSchema&&(m[Hl]=String(U.colorSchema)),U.layout&&p(U.layout,m,U),U.background&&(m[ct]=String(U.background)),U.image&&(m[Wt]=String(U.image)),U.class&&(m[ai]=String(U.class));for(const[E,D]of Object.entries(U))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(E)||(m[`custom-slides-${E}`]=typeof D=="object"?JSON.stringify(D):String(D))}const x=[];let k=0,v=0,_=0,A=0;const T=new Set,N={};let F=1;for(let U=g;U<h.length;U++){const E=h[U],{frontmatter:D,content:S}=El(E),P=E.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),j=D.src||(P?P[1]:void 0);if(j){const R=String(j).trim().replace(/^['"]|['"]$/g,"");let ie=c[R]||c[R.replace(/^\.\//,"")]||c[`pages/${R.replace(/^.*pages\//,"")}`];if(!ie){const W=R.replace(/^\.\//,""),w=[];if(t.baseDir)try{const q=require("path");w.push(q.resolve(t.baseDir,W)),w.push(q.resolve(t.baseDir,R))}catch{}try{const q=require("path");w.push(q.resolve(process.cwd(),W)),w.push(q.resolve(process.cwd(),R))}catch{}for(const q of w){const z=bc(q);if(z!==null){ie=z;break}}}const B={};D.layout&&p(D.layout,B,D),D.transition&&(B[Ct]=String(D.transition)),D.background&&(B[ct]=String(D.background)),D.image&&(B[Wt]=String(D.image)),D.class&&(B[ai]=String(D.class));for(const[W,w]of Object.entries(D))["src","layout","transition","background","image","class"].includes(W)||(B[`custom-slides-${W}`]=typeof w=="object"?JSON.stringify(w):String(w));if(ie){const W=Sn(ie,{...t,virtualFiles:c});for(const w of W.slides){w.pageIndex=F++,w.pageAttrs={...B,...w.pageAttrs},x.push(w);const q=w.pageAttrs[be]||"default";N[q]=(N[q]||0)+1}continue}else{x.push({pageIndex:F++,pageAttrs:{...B,"custom-slides-src":R},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${R}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const W=B[be]||"default";N[W]=(N[W]||0)+1;continue}}const I={};D.layout&&p(D.layout,I,D),D.transition&&(I[Ct]=String(D.transition)),D.background&&(I[ct]=String(D.background)),D.image&&(I[Wt]=String(D.image)),D.class&&(I[ai]=String(D.class)),D.mask&&(I[ci]=String(D.mask)),(D.maskRatio||D["mask-ratio"])&&(I[Zo]=String(D.maskRatio||D["mask-ratio"])),(D.maskStyle||D["mask-style"])&&(I[di]=String(D.maskStyle||D["mask-style"])),(D.maskInitial||D["mask-initial"])&&(I[ui]=String(D.maskInitial||D["mask-initial"]));for(const[R,ie]of Object.entries(D))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(R)||(I[`custom-slides-${R}`]=typeof ie=="object"?JSON.stringify(ie):String(ie));let M=S;const L=[];let te=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,R=>{const ie=`__CODE_TOKEN_NOTE_${L.length}__`;return L.push(R),ie});te=te.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,R=>{const ie=`__CODE_TOKEN_NOTE_${L.length}__`;return L.push(R),ie});let V="";const Z=Array.from(te.matchAll(/<!--([\s\S]*?)-->/g));if(Z.length>0){const R=Z[Z.length-1],ie=te.slice(R.index+R[0].length).trim();if(!ie||!ie.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const W=R[1].trim();W.startsWith("TODO:")||(V=W,k++),o&&(te=te.slice(0,R.index).trimEnd()+te.slice(R.index+R[0].length))}}o&&(te=te.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let R=0;R<L.length;R++)te=te.replace(`__CODE_TOKEN_NOTE_${R}__`,()=>L[R]);if(M=te,V){for(let B=0;B<L.length;B++)V=V.replace(`__CODE_TOKEN_NOTE_${B}__`,()=>L[B]);const ie=`> [!NOTE] 💡 演讲备注
${V.split(/\r?\n/).map(B=>`> ${B}`).join(`
`)}
{: custom-slides-note="true"}`;M=M?`${M}

${ie}`:ie}let ce=!1;if(/<style\b/i.test(M)){ce=!0;const R=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(R){for(const ie of R){const B=ie.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${B}`:B}l&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(v+=oe.length);const le=M.match(/```\w+\s+\{[^}]+\}/g);le&&(_+=le.length);const Se=M.match(/::\w+::|<template\s+#[^>]+>/g);if(Se&&(A+=Se.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,R=>E0(R,{...t,virtualFiles:c})||R),i&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=gh(M)),a){let R=M.trim(),ie="";const B=R.lastIndexOf("> [!NOTE] 💡 演讲备注");if(B!==-1&&(ie=R.slice(B),R=R.slice(0,B).trim()),(D.layout==="image-left"||D.layout==="image-right")&&D.image){const W=String(D.image).trim(),w=D.layout==="image-left"?"image-left":"image-right",q=`![配图](${W})
{: custom-slides-layout="${w}" }`;D.layout==="image-left"?R=`{{{col

${q}

${R}

}}}`:R=`{{{col

${R}

${q}

}}}`}if(D.background){const w=`![背景图](${String(D.background).trim()})
{: custom-slides-role="background" }`;R=R?`${w}

${R}`:w}M=ie?`${R}

${ie}`:R}const $e=O0(M);I[ct]&&$e.push(I[ct]),I[Wt]&&$e.push(I[Wt]);for(const R of $e)T.add(R);const ke=/<[A-Z][a-zA-Z0-9]+/.test(M),Ce=I[be]||(F===1?m[be]||"cover":"default");N[Ce]=(N[Ce]||0)+1,x.push({pageIndex:F++,pageAttrs:I,notes:V,rawMarkdown:M,hasVueComponent:ke,hasStyleTag:ce,assetReferences:$e})}if(!d&&x.length>0){const U=x[0].rawMarkdown.match(/^#\s+(.+)$/m);U&&(d=U[1].trim())}b&&(m["custom-slides-custom-css"]=b);let H=x.map(U=>`---

${U.rawMarkdown}`).join(`

`);return H.trimStart().startsWith("---")||(H=`---

${H.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:m,slides:x,totalSlides:x.length,stats:{totalNotes:k,totalVClicks:v,totalShikiHighlights:_,totalSlots:A,discoveredAssets:Array.from(T),layoutDistribution:N},flattenedMarkdown:H,customCss:b}}function O0(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function vc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function N0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function P0(e,t,o=ze){const i=e.filter(vc);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=i[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const l=t[s],r=i[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}return n}async function R0(e,t=ze){let o=!1,i=0;for(const n of e){if(vc(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Te]:"right"}).catch(()=>{}),i++)}return i}async function z0(e,t,o=Pl){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(l)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))i[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&A0(e,i),i}async function H0(e){var x;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Pl,u=a.createDocFn||xd,h=a.setAttrsFn||ze,m=a.getChildBlocksFn||Si,d=a.openTabFn||re.openTab,b=a.showMessageFn||re.showMessage;s&&n.length>0&&await z0(t,n,c);const g=N0(i),p=`/${g}`,y=await u(o,p,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const k=((x=t.slides[0])==null?void 0:x.pageAttrs)||{};await h(y,{...k,...t.docRootAttrs});const v=await m(y).catch(()=>[]);Array.isArray(v)&&v.length>0&&(await P0(v,t.slides,h),await R0(v,h))}catch(k){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",k),b(`⚠️ 文档已创建(${g})，但部分版式属性回填未完全完成: ${k.message||String(k)}`,6e3)}return b(`🎉 成功导入 Slidev 演示文档《${g}》！`),l&&r&&(r.currentDocId=y,await d({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function F0(e){const t=pe("file"),o=pe(!1),i=pe(!1),n=pe(""),s=pe(null),l=pe(null),r=pe(""),a=pe(0),c=pe(""),u=pe([]),h=pe(null),m=pe(""),d=pe([]),b=pe(""),g=pe(!0),p=pe(!0),y=pe(!0),x=pe(!0),k=ye(()=>{const I=a.value;if(I===0)return"0 B";const M=1024,L=["B","KB","MB","GB"],te=Math.floor(Math.log(I)/Math.log(M));return`${(I/M**te).toFixed(1)} ${L[te]}`}),v=ye(()=>{var I;return((I=h.value)==null?void 0:I.docRootAttrs["custom-slides-theme"])||"default"}),_=ye(()=>{var I;return u.value.length>0?u.value.length:((I=h.value)==null?void 0:I.stats.discoveredAssets.length)||0}),A=ye(()=>{var M;const I=((M=h.value)==null?void 0:M.stats.layoutDistribution)||{};return Object.entries(I).map(([L,te])=>({name:L,count:te}))});async function T(I=wd){try{const M=await I();M!=null&&M.notebooks&&Array.isArray(M.notebooks)&&(d.value=M.notebooks.filter(L=>!L.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(M){console.warn("获取笔记本列表失败:",M)}}function N(){var I;(I=s.value)==null||I.click()}function F(){l.value=null,r.value="",a.value=0,h.value=null,u.value=[],n.value=""}let H=0;async function U(I){const M=++H;n.value="",l.value=I,r.value=I.name,a.value=I.size;try{if(I.name.toLowerCase().endsWith(".zip")){const te=await I.arrayBuffer();if(M!==H)return;const V=await T0(te);if(M!==H)return;if(!V.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const Z=Sn(V.entryMarkdown,{stripNotesFromMarkdown:p.value,cleanHtmlToMarkdown:g.value,cleanSlots:!1,virtualFiles:V.virtualFiles});if(M!==H)return;h.value=Z,m.value=Z.docTitle||I.name.replace(/\.zip$/i,"")}else{const te=await I.text();if(M!==H)return;u.value=[];const V=I.path||"",Z=V?V.replace(/[\\/][^\\/]+$/,""):"",ce=Sn(te,{stripNotesFromMarkdown:p.value,cleanHtmlToMarkdown:g.value,cleanSlots:!1,baseDir:Z||void 0});if(M!==H)return;h.value=ce,m.value=ce.docTitle||I.name.replace(/\.md$/i,"")}}catch(L){if(M!==H)return;console.error("解析文件失败:",L),n.value=`解析文件失败: ${L.message||String(L)}`}}function E(){if(n.value="",!c.value.trim()){h.value=null;return}try{const I=Sn(c.value,{stripNotesFromMarkdown:p.value,cleanHtmlToMarkdown:g.value,cleanSlots:!1});h.value=I,m.value=I.docTitle||"Slidev 演示文稿"}catch(I){n.value=`解析 Markdown 源码失败: ${I.message||String(I)}`}}async function D(){l.value?await U(l.value):c.value&&E()}async function S(I){const M=I.target;M.files&&M.files[0]&&await U(M.files[0])}async function P(I){var M;o.value=!1,(M=I.dataTransfer)!=null&&M.files&&I.dataTransfer.files[0]&&await U(I.dataTransfer.files[0])}async function j(I=e){if(h.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await H0({presentation:h.value,notebookId:b.value,docTitle:m.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:x.value,plugin:I})}catch(M){console.error("导入 Slidev 演示失败:",M),n.value=`导入执行失败: ${M.message||String(M)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:h,customDocTitle:m,notebooks:d,selectedNotebookId:b,optCleanHtml:g,optStripNotes:p,optUploadAssets:y,optAutoPreview:x,formattedFileSize:k,currentTheme:v,extractedAssetsCount:_,layoutChips:A,fetchNotebooks:T,triggerFileInput:N,clearFile:F,processFile:U,onFileSelected:S,onFileDrop:P,onTextChange:E,reprocessCurrentInput:D,handleConfirmImport:j}}const j0={class:"spm-import-dialog"},U0={class:"spm-tabs-header"},W0={class:"spm-dialog-body"},q0={key:0,class:"spm-file-section"},V0={key:0,class:"spm-dropzone-prompt"},K0={class:"spm-dropzone-icon"},G0={key:1,class:"spm-dropzone-active"},Y0={class:"spm-file-badge"},Z0={class:"spm-file-size"},J0={key:1,class:"spm-text-section"},X0={key:2,class:"spm-error-banner"},Q0={key:3,class:"spm-preview-card"},ew={class:"spm-preview-card__header"},tw={style:{display:"inline-flex","align-items":"center",gap:"4px"}},ow={class:"spm-config-grid"},iw={class:"spm-form-item"},nw={class:"spm-form-item"},sw=["value"],rw={class:"spm-stats-grid"},lw={class:"spm-stat-box"},aw={class:"spm-stat-value"},cw={class:"spm-stat-box"},dw={class:"spm-stat-value"},uw={class:"spm-stat-box"},fw={class:"spm-stat-value"},hw={class:"spm-stat-box"},pw={class:"spm-stat-value"},mw={key:0,class:"spm-chips-row"},gw={class:"spm-options-group"},yw={class:"spm-checkbox-label"},bw={class:"spm-checkbox-label"},vw={class:"spm-checkbox-label"},kw={class:"spm-checkbox-label"},ww={class:"spm-dialog-footer"},xw=["disabled"],Sw=["disabled"],Cw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},_w={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Iw=zt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Vt("plugin"),{inputMode:n,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:h,parsedPresentation:m,customDocTitle:d,notebooks:b,selectedNotebookId:g,optCleanHtml:p,optStripNotes:y,optUploadAssets:x,optAutoPreview:k,formattedFileSize:v,currentTheme:_,layoutChips:A,fetchNotebooks:T,triggerFileInput:N,clearFile:F,onFileSelected:H,onFileDrop:U,onTextChange:E,reprocessCurrentInput:D,handleConfirmImport:S}=F0(i);ti(async()=>{await T()});async function P(){const I=await S();I&&(o("success",{docId:I}),o("close"))}function j(){o("close")}return(I,M)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:oo(j,["self"])},[f("div",j0,[f("div",{class:"spm-dialog-header"},[M[18]||(M[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlides"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),f("div",U0,[f("button",{class:xe(["spm-tab-btn",{active:ue(n)==="file"}]),onClick:M[0]||(M[0]=L=>n.value="file")},[se(de,{name:"package"}),M[19]||(M[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:xe(["spm-tab-btn",{active:ue(n)==="text"}]),onClick:M[1]||(M[1]=L=>n.value="text")},[se(de,{name:"notes"}),M[20]||(M[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",W0,[ue(n)==="file"?(J(),ee("div",q0,[f("div",{class:xe(["spm-dropzone",{dragover:ue(s),"has-file":!!ue(c)}]),onDragover:M[4]||(M[4]=oo(L=>s.value=!0,["prevent"])),onDragleave:M[5]||(M[5]=oo(L=>s.value=!1,["prevent"])),onDrop:M[6]||(M[6]=oo((...L)=>ue(U)&&ue(U)(...L),["prevent"])),onClick:M[7]||(M[7]=(...L)=>ue(N)&&ue(N)(...L))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:M[2]||(M[2]=(...L)=>ue(H)&&ue(H)(...L))},null,544),ue(c)?(J(),ee("div",G0,[f("span",Y0,[se(de,{name:"notes"}),St(" "+ve(ue(c)),1)]),f("span",Z0,"("+ve(ue(v))+")",1),f("button",{class:"spm-btn-text",onClick:M[3]||(M[3]=oo((...L)=>ue(F)&&ue(F)(...L),["stop"]))},"更换文件")])):(J(),ee("div",V0,[f("span",K0,[se(de,{name:"folder",style:{"font-size":"32px"}})]),M[21]||(M[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),M[22]||(M[22]=f("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(J(),ee("div",J0,[Ut(f("textarea",{"onUpdate:modelValue":M[8]||(M[8]=L=>ot(u)?u.value=L:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:M[9]||(M[9]=(...L)=>ue(E)&&ue(E)(...L))},null,544),[[js,ue(u)]])])),ue(r)?(J(),ee("div",X0," ⚠️ "+ve(ue(r)),1)):Ae("",!0),ue(m)?(J(),ee("div",Q0,[f("div",ew,[f("span",tw,[se(de,{name:"sparkles"}),M[23]||(M[23]=St(" 演示解析摘要",-1))]),M[24]||(M[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",ow,[f("div",iw,[M[25]||(M[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ut(f("input",{"onUpdate:modelValue":M[10]||(M[10]=L=>ot(d)?d.value=L:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[js,ue(d)]])]),f("div",nw,[M[26]||(M[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ut(f("select",{"onUpdate:modelValue":M[11]||(M[11]=L=>ot(g)?g.value=L:null),class:"spm-select"},[(J(!0),ee(Je,null,Mt(ue(b),L=>(J(),ee("option",{key:L.id,value:L.id},ve(L.name),9,sw))),128))],512),[[Gf,ue(g)]])])]),f("div",rw,[f("div",lw,[f("span",aw,ve(ue(m).totalSlides),1),M[27]||(M[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",cw,[f("span",dw,ve(ue(_)),1),M[28]||(M[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",uw,[f("span",fw,ve(ue(m).stats.totalNotes),1),M[29]||(M[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",hw,[f("span",pw,ve(ue(h)),1),M[30]||(M[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ue(A).length>0?(J(),ee("div",mw,[M[31]||(M[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Je,null,Mt(ue(A),L=>(J(),ee("span",{key:L.name,class:"spm-chip-badge"},ve(L.name)+": "+ve(L.count),1))),128))])):Ae("",!0),f("div",gw,[f("label",yw,[Ut(f("input",{"onUpdate:modelValue":M[12]||(M[12]=L=>ot(p)?p.value=L:null),type:"checkbox",onChange:M[13]||(M[13]=(...L)=>ue(D)&&ue(D)(...L))},null,544),[[pn,ue(p)]]),M[32]||(M[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",bw,[Ut(f("input",{"onUpdate:modelValue":M[14]||(M[14]=L=>ot(y)?y.value=L:null),type:"checkbox",onChange:M[15]||(M[15]=(...L)=>ue(D)&&ue(D)(...L))},null,544),[[pn,ue(y)]]),M[33]||(M[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",vw,[Ut(f("input",{"onUpdate:modelValue":M[16]||(M[16]=L=>ot(x)?x.value=L:null),type:"checkbox"},null,512),[[pn,ue(x)]]),M[34]||(M[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",kw,[Ut(f("input",{"onUpdate:modelValue":M[17]||(M[17]=L=>ot(k)?k.value=L:null),type:"checkbox"},null,512),[[pn,ue(k)]]),M[35]||(M[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ae("",!0)]),f("div",ww,[f("button",{class:"spm-btn-secondary",disabled:ue(l),onClick:j}," 取消 ",8,xw),f("button",{class:"spm-btn-primary",disabled:!ue(m)||ue(l),onClick:P},[ue(l)?(J(),ee("span",Cw,[se(de,{name:"refresh"}),M[36]||(M[36]=St(" 正在导入生成中...",-1))])):(J(),ee("span",_w,[se(de,{name:"rocket"}),M[37]||(M[37]=St(" 确认导入思源笔记",-1))]))],8,Sw)])])]))}}),$w=lo(Iw,[["__scopeId","data-v-5f026e48"]]);function Sr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Tw(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Sr(s)&&o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===o}),a)||(a=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),a))return a}if(n){let a=e.find(c=>c.startBlockId===n);if(a||(a=e.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===n}),a))return a}if(o){let a=e.find(u=>u.startBlockId===o);if(a||(a=e.find(u=>{var h,m;return((h=u.blocks)==null?void 0:h.some(d=>d.id===o))||((m=u.allBlockIds)==null?void 0:m.includes(o))}),a)||i&&i!==o&&(a=e.find(u=>{var h,m;return((h=u.blocks)==null?void 0:h.some(d=>d.id===i))||((m=u.allBlockIds)==null?void 0:m.includes(i))}),a)||(a=e.find(u=>{var h;return(h=u.noteBlocks)==null?void 0:h.some(m=>m.id===o||m.id===i)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Te];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(u=>{var h,m;return((h=u.frontmatter)==null?void 0:h.layout)==="three-cols-header"||((m=u.blocks)==null?void 0:m.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return e[0]||null}function ws(){var s;if(typeof window<"u"&&typeof((s=window.Lute)==null?void 0:s.NewNodeID)=="function")return window.Lute.NewNodeID();const e=new Date,t=l=>l.toString().padStart(2,"0"),o=`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`,i="0123456789abcdefghijklmnopqrstuvwxyz";let n="";for(let l=0;l<7;l++)n+=i[Math.floor(Math.random()*i.length)];return`${o}-${n}`}function kc(){return typeof document>"u"?null:document.querySelector(".layout__wnd--active .protyle-wysiwyg")||document.querySelector(".protyle:not(.fn__none) .protyle-wysiwyg")||document.querySelector(".protyle-wysiwyg")}function Aw(e,t){var l;if(typeof document>"u")return!1;const o=kc();if(!o)return!1;const i=Array.from(o.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));if(i.length>=2)return!0;const n=((l=i[0])==null?void 0:l.getAttribute("data-node-id"))||e,s=t==="NodeList"||t==="l"||t==="list";if(n){const r=o.querySelector(`[data-node-id="${n}"]`);if(r){const a=(s||r.getAttribute("data-type")==="NodeList"||r.classList.contains("list"))&&r.getAttribute("data-type")==="NodeList"?r:r.closest('[data-type="NodeList"], .list');if(a&&a.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li").length>=2)return!0}}return!1}async function Mw(e){const t=kc();if(!t)return{success:!1,error:"未找到主编辑区"};const o=Array.from(t.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));let i=!1,n=null,s=[];if(o.length>=2){const k=o[0].closest('[data-type="NodeList"], .list');if(k){const v=new Set;let _=!0;for(const A of o){const T=A.getAttribute("data-type")==="NodeListItem"||A.classList.contains("li")?A:A.closest('[data-type="NodeListItem"], .li');if(!T||T.closest('[data-type="NodeList"], .list')!==k){_=!1;break}v.add(T)}_&&v.size>=2&&(i=!0,n=k,s=Array.from(k.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")).filter(A=>v.has(A)))}}let l=!1;if(!i){const k=(o.length===1?o[0]:null)||(e.activeBlockId?t.querySelector(`[data-node-id="${e.activeBlockId}"]`):null);if(k){const v=k.getAttribute("data-type")==="NodeList"||k.classList.contains("list")?k:k.closest('[data-type="NodeList"], .list');if(v){const _=Array.from(v.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li"));_.length>=2&&(l=!0,n=v,s=_)}}}if(i||l){if(!n||s.length<2)return{success:!1,error:"选中的列表项不足 2 项，无法合并为横向超级块"};const k=Array.from(n.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")),v=s.length===k.length,_=n.getAttribute("data-subtype")||"u",A=n.getAttribute("data-node-id")||"",T=n.parentElement,N=(T==null?void 0:T.getAttribute("data-node-id"))||e.currentDocId;let F=n.previousElementSibling;for(;F&&!F.getAttribute("data-node-id");)F=F.previousElementSibling;const H=(F==null?void 0:F.getAttribute("data-node-id"))||"";let U=n.nextElementSibling;for(;U&&!U.getAttribute("data-node-id");)U=U.nextElementSibling;const E=(U==null?void 0:U.getAttribute("data-node-id"))||"",D=ws(),S=s.map(I=>({li:I,liId:I.getAttribute("data-node-id")||"",newListId:ws()})),P=[],j=[];if(v){P.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:H||void 0,nextID:H?void 0:E||void 0});for(let I=0;I<S.length;I++){const{liId:M,newListId:L}=S[I];P.push({action:"insert",id:L,data:`<div data-node-id="${L}" data-type="NodeList" data-subtype="${_}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:I===0?void 0:S[I-1].newListId}),P.push({action:"move",id:M,parentID:L})}A&&P.push({action:"delete",id:A}),A&&j.push({action:"insert",id:A,data:n.outerHTML,parentID:N,previousID:H||void 0,nextID:H?void 0:E||void 0});for(let I=0;I<S.length;I++)j.push({action:"move",id:S[I].liId,parentID:A,previousID:I===0?void 0:S[I-1].liId});for(const{newListId:I}of S)j.push({action:"delete",id:I});j.push({action:"delete",id:D})}else{P.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:A});for(let I=0;I<S.length;I++){const{liId:M,newListId:L}=S[I];P.push({action:"insert",id:L,data:`<div data-node-id="${L}" data-type="NodeList" data-subtype="${_}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:I===0?void 0:S[I-1].newListId}),P.push({action:"move",id:M,parentID:L})}for(let I=0;I<S.length;I++)j.push({action:"move",id:S[I].liId,parentID:A});for(const{newListId:I}of S)j.push({action:"delete",id:I});j.push({action:"delete",id:D})}return await Mr([{doOperations:P,undoOperations:j}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(I=>I.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:S.length,superBlockId:D}}const r=o.filter(k=>{let v=k.parentElement;for(;v&&v!==t;){if(o.includes(v))return!1;v=v.parentElement}return!0});if(r.length<2)return{success:!1,error:"请在编辑区选中多个块，或选中一个包含多个列表项的列表"};const a=r[0],c=r[r.length-1],u=a.parentElement,h=(u==null?void 0:u.getAttribute("data-node-id"))||e.currentDocId;let m=a.previousElementSibling;for(;m&&!m.getAttribute("data-node-id");)m=m.previousElementSibling;const d=(m==null?void 0:m.getAttribute("data-node-id"))||"";let b=c.nextElementSibling;for(;b&&!b.getAttribute("data-node-id");)b=b.nextElementSibling;const g=(b==null?void 0:b.getAttribute("data-node-id"))||"",p=ws(),y=[],x=[];y.push({action:"insert",id:p,data:`<div data-node-id="${p}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:h,previousID:d||void 0,nextID:d?void 0:g||void 0});for(let k=0;k<r.length;k++){const v=r[k].getAttribute("data-node-id");y.push({action:"move",id:v,parentID:p,previousID:k===0?void 0:r[k-1].getAttribute("data-node-id")})}for(let k=0;k<r.length;k++){const v=r[k].getAttribute("data-node-id");x.push({action:"move",id:v,parentID:h,previousID:k===0?d||void 0:r[k-1].getAttribute("data-node-id")})}return x.push({action:"delete",id:p}),await Mr([{doOperations:y,undoOperations:x}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(k=>k.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:r.length,superBlockId:p}}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Ew(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ye),i.removeAttribute("custom-slides-role");return}const s=e.get(n),l=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==l&&(l?i.setAttribute(be,l):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const a=(s==null?void 0:s[Ye])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ye)||i.getAttribute("custom-slides-role");c&&c!==a&&(a?i.setAttribute(Ye,a):(i.removeAttribute(Ye),i.removeAttribute("custom-slides-role")))})}function Bw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function Dw(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[b,g]of Object.entries(c))e.activeBlockAttrs.value[b]=g;Be.setBlockAttrOverride(u,c),et(u,c);const h=(d=e.parentContainerId)==null?void 0:d.value,m=!!(h&&Bw(u,h));if(Oe in c&&m&&h){const b=c[Oe];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Be.setBlockAttrOverride(h,{[Oe]:b}),et(h,{[Oe]:b}),ze(h,{[Oe]:b}).catch(()=>{})}if(be in c){const b=c[be];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(yt in c){const b=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function l(c,u){const h=s();if(h){h===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Be.setBlockAttrOverride(h,{[c]:u}),et(h,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(h,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const h=s();if(!h)return;const m={[be]:c,[yt]:u};h===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[yt]=u),e.currentPageDividerLayout.value=c,Be.setBlockAttrOverride(h,m),et(h,m),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(h,m),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function a(c,u){var m;const h=e.currentDocId.value||e.activeBlockId.value;if(h){e.activeBlockAttrs.value[c]=u,Be.setBlockAttrOverride(h,{[c]:u}),et(h,{[c]:u}),(m=e.latestDoc.value)!=null&&m.config&&(c===Vi&&(e.latestDoc.value.config.theme=u),c===Ki&&(e.latestDoc.value.config.aspectRatio=u),c===Gi&&(e.latestDoc.value.config.defaultTransition=u),c===$n&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(h,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(h)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Lw(e){const t=[{Authorization:`Bearer ${e.apiKey.trim()}`},{Accept:"application/json"}];if(e.headers&&typeof e.headers=="object")for(const[o,i]of Object.entries(e.headers))o&&i!==void 0&&i!==null&&t.push({[o]:String(i)});return t}function Ow(e){var i,n;if(!e||typeof e!="object")return null;const t=(i=e.choices)==null?void 0:i[0];if(!t)return null;const o=((n=t.message)==null?void 0:n.content)??t.text;return typeof o=="string"&&o.trim().length>0?o.trim():null}async function wc(e,t,o){const i=t.baseUrl.replace(/\/+$/,""),n=i.endsWith("/chat/completions")?i:`${i}/chat/completions`,s={model:t.model,messages:e,max_tokens:o??t.maxTokens??4096,temperature:t.temperature??.7},l=Math.max(1,t.requestTimeoutSeconds||60)*1e3,r=Lw(t),a=await _d(n,"POST",JSON.stringify(s),r,l,"application/json");if(!a||a.status<200||a.status>=300){const h=typeof(a==null?void 0:a.body)=="string"?a.body.slice(0,200):"";throw new Error(`AI 请求失败 (HTTP ${(a==null?void 0:a.status)??"未知"})${h?`: ${h}`:""}`)}let c;try{c=JSON.parse(a.body||"{}")}catch{throw new Error("AI 接口返回了非法的 JSON 响应")}const u=Ow(c);if(!u)throw new Error("AI 接口未返回有效的文本内容");return u}async function is(e){const t=rh();if(!t)return null;try{return await wc([{role:"system",content:"你是一位专业的幻灯片演讲教练与内容设计专家。请根据用户提供的幻灯片内容提供精炼、准确的输出。"},{role:"user",content:e}],t.config)}catch(o){throw console.warn("[LiveSlides AI] request failed:",(o==null?void 0:o.message)||o),o}}async function Nw(e){if(!Fn(e))return{success:!1,message:"配置不完整：请先补充 Base URL、API Key 和 Model"};const t={baseUrl:e.baseUrl.trim(),apiKey:e.apiKey.trim(),model:e.model.trim(),requestTimeoutSeconds:e.requestTimeoutSeconds||15,temperature:e.temperature??.7,maxTokens:e.maxTokens||10,headers:e.headers},o=Date.now();try{const n=await wc([{role:"user",content:'Say "OK"'}],t,10),s=Date.now()-o;return{success:!0,message:`连接成功！模型响应：${n.slice(0,50)} (${s}ms)`,elapsed:s}}catch(i){const n=Date.now()-o;return{success:!1,message:(i==null?void 0:i.message)||"连接失败，请检查 Base URL、API Key 与网络连通性",elapsed:n}}}function Bl(e){const t=(e.blocks||[]).filter(s=>{const l=(s.content||s.rawMarkdown||"").trim();return l&&l!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const o=[],i=[];for(const s of t){const l=(s.content||s.rawMarkdown||"").trim();l&&(s.type==="h"||l.startsWith("#")?o.push(l.replace(/^#+\s*/,"")):i.push(l.slice(0,50)))}const n=[];return o.length>0&&n.push(`【核心重点】：${o.join("、")}`),i.length>0&&(n.push("【口播要点】："),i.slice(0,3).forEach((s,l)=>{n.push(`${l+1}. 讲解 ${s}`)})),n.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),n.join(`
`)}async function xc(e,t=is){const o=e.blocks&&e.blocks.length>0?e.blocks.map(i=>(i.content||i.rawMarkdown||"").trim()).filter(i=>i&&i!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&o){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Bl(e),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Bl(e),isAiGenerated:!1}}async function Pw(e,t=is){return(await xc(e,t)).notes}function Rw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function zw(e,t){if(!((t==null?void 0:t[qe])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function Sc(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||Si)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(yo({...r,ial:{...r.ial||{},...Be.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const l=[];for(let r=0;r<n.length;r++){const a=n[r];if(!a||a.length===0)continue;let c=null;for(let b=a.length-1;b>=0;b--){const g=a[b];if(!((g.type==="p"||g.type==="NodeParagraph")&&!(g.content||"").trim()&&!(g.markdown||"").trim())){c=g;break}}if(!c||!Rw(c))continue;const u=Be.getBlockAttrOverride(c.id)||{};let h={...c.ial||{},...u};if(!h[qe]&&(t!=null&&t.getBlockAttrsFn)){const b=await t.getBlockAttrsFn(c.id).catch(()=>({}));h={...h,...b,...u}}let m=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const b=await t.getBlockKramdownFn(c.id);b!=null&&b.kramdown&&(m=b.kramdown)}catch{}if(zw(m,h))continue;const d=kr(m)||m.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:m,cleanContent:d||"在此输入本页讲稿提词..."})}return l}async function Cc(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||Ts,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${qe}="true"}`;await i("markdown",r,e),await n(e,{[qe]:"true"}),Be.setBlockAttrOverride(e,{[qe]:"true"}),s(e,{[qe]:"true"})}async function _c(e,t){const o=(t==null?void 0:t.showMessageFn)||re.showMessage,i=(t==null?void 0:t.confirmFn)||re.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await Sc(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(l=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,a=0;for(const u of n)try{await Cc(u.id,u.cleanContent,t),r++}catch(h){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,h),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:s,matchedCount:s,successCount:r,errorCount:a})},()=>{l({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function Hw(e,t){const o=pe(!1),{triggerSaveNotice:i}=t;async function n(p){var F,H,U,E,D,S,P,j;const k=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(I=>`> ${I}`).join(`
`)}
{: custom-slides-note="true"}`,v=((F=e.latestDoc.value)==null?void 0:F.slides)||[],_=e.targetSlide.value,A=_?v.findIndex(I=>I===_):-1;let T=null;if(A!==-1&&A<v.length-1){const I=v[A+1];T=await Go("markdown",k,I.startBlockId)}else{const I=((H=_==null?void 0:_.noteBlocks)==null?void 0:H.slice(-1)[0])||((U=_==null?void 0:_.blocks)==null?void 0:U.slice(-1)[0]),M=(I==null?void 0:I.id)||(_==null?void 0:_.startBlockId);M?T=await Go("markdown",k,void 0,M):T=await $s("markdown",k,e.currentDocId.value)}const N=((S=(D=(E=T==null?void 0:T[0])==null?void 0:E.doOperations)==null?void 0:D[0])==null?void 0:S.id)||((P=T==null?void 0:T[0])==null?void 0:P.id);return N&&(await ze(N,{[qe]:"true"}),Be.setBlockAttrOverride(N,{[qe]:"true"}),Qo(N,(j=e.plugin)==null?void 0:j.app)),e.plugin&&await e.plugin.compileCurrentDocument(),N}async function s(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){i("取消中...");try{await ze(p,{[qe]:""}),Be.setBlockAttrOverride(p,{[qe]:""}),et(p,{[qe]:""}),delete e.activeBlockAttrs.value[qe],i("已取消备注"),re.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(y){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",y),i("取消失败"),re.showMessage("取消讲稿备注失败")}}else{i("转换中...");try{let y=e.rawSnippet.value;try{const _=await Sd(p);_!=null&&_.kramdown&&(y=_.kramdown)}catch{}const v=`> [!NOTE] 💡 演讲备注
${(kr(y)||y.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slides-note="true"}`;await Ts("markdown",v,p),await ze(p,{[qe]:"true"}),Be.setBlockAttrOverride(p,{[qe]:"true"}),et(p,{[qe]:"true"}),e.activeBlockAttrs.value[qe]="true",e.activeBlockType.value="NodeCallout",i("已设为讲稿备注"),re.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(y){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",y),i("设置失败"),re.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await n(),re.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){re.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var x;const p=e.currentSlideNoteBlockId.value;if(!p){re.showMessage("未找到本页关联的讲稿备注块");return}Qo(p,(x=e.plugin)==null?void 0:x.app)?re.showMessage("已在编辑区定位讲稿备注块"):re.showMessage("定位讲稿备注块失败")}async function a(){var x;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};re.showMessage("正在调用 AI 提炼本页讲稿提词...");const y=await xc(p,is);if(y.notes){const k=e.currentSlideNoteBlockId.value;if(k){const v=`> [!NOTE] 💡 演讲备注
${y.notes.split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slides-note="true"}`;await Ts("markdown",v,k),await ze(k,{[qe]:"true"}),Be.setBlockAttrOverride(k,{[qe]:"true"}),Qo(k,(x=e.plugin)==null?void 0:x.app)}else await n(y.notes);y.isAiGenerated?re.showMessage("AI 演讲提词卡生成成功！"):re.showMessage("未获取到 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}const c=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(x=>`> ${x}`).join(`
`)}
{: custom-slides-note="true"}`;async function u(){var k,v;const p=e.currentDocId.value||((k=e.plugin)==null?void 0:k.currentDocId)||"",y=(v=e.latestDoc.value)==null?void 0:v.slides;if(Array.isArray(y)&&y.length>0)return{docId:p,slides:y};if(!p)return{docId:"",slides:[]};const x=await Be.compile(p).catch(()=>null);return{docId:p,slides:(x==null?void 0:x.slides)||[]}}async function h(p,y,x,k){var A,T,N,F,H,U;let v=null;if(y<x.length-1){const E=x[y+1];v=await Go("markdown",c,E.startBlockId)}else{const E=((A=p==null?void 0:p.noteBlocks)==null?void 0:A.slice(-1)[0])||((T=p==null?void 0:p.blocks)==null?void 0:T.slice(-1)[0]),D=(E==null?void 0:E.id)||(p==null?void 0:p.startBlockId);D?v=await Go("markdown",c,void 0,D):v=await $s("markdown",c,k||e.currentDocId.value)}const _=((H=(F=(N=v==null?void 0:v[0])==null?void 0:N.doOperations)==null?void 0:F[0])==null?void 0:H.id)||((U=v==null?void 0:v[0])==null?void 0:U.id);_&&(await ze(_,{[qe]:"true"}),Be.setBlockAttrOverride(_,{[qe]:"true"}))}async function m(){if(o.value)return;const{docId:p,slides:y}=await u();if(y.length===0){re.showMessage("当前文档无幻灯片页面");return}const x=y.map((v,_)=>({slide:v,idx:_})).filter(({slide:v})=>{var T;const _=Array.isArray(v.noteBlocks)&&v.noteBlocks.length>0,A=!!((T=v.notes)!=null&&T.trim());return!_&&!A});if(x.length===0){re.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const k=x.length;re.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${k} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,re.showMessage("正在批量追加讲稿块...");let v=0;try{for(const{slide:_,idx:A}of x)try{await h(_,A,y,p),v++}catch(T){console.error(`[SiYuanLiveSlides] 为第 ${A+1} 页追加讲稿块失败:`,T)}e.plugin&&await e.plugin.compileCurrentDocument(),re.showMessage(`已成功为 ${v} 页追加讲稿备注块`)}catch(_){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",_),re.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function d(){if(o.value)return;const{slides:p}=await u();if(p.length===0){re.showMessage("当前文档无幻灯片页面");return}const y=[];for(const v of p)if(v.noteBlocks&&v.noteBlocks.length>0)for(const _ of v.noteBlocks)_.id&&y.push({id:_.id,pageIndex:v.pageIndex});if(y.length===0){re.showMessage("当前文档中没有讲稿备注块，无需删除");return}const x=new Set(y.map(v=>v.pageIndex)).size,k=y.length;re.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${k} 个讲稿备注块（涉及 ${x} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,re.showMessage("正在批量删除讲稿块...");let v=0;try{for(const _ of y)try{await Js(_.id),Be.clearBlockAttrOverride(_.id),v++}catch(A){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${_.id} 失败:`,A)}e.activeBlockId.value&&y.some(_=>_.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[qe],e.plugin&&await e.plugin.compileCurrentDocument(),re.showMessage(`已成功删除全部 ${v} 个讲稿备注块`)}catch(_){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",_),re.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function b(){var y;const p=e.currentDocId.value||((y=e.plugin)==null?void 0:y.currentDocId);if(!p){re.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){re.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await _c(p,{onSuccessNotice:i,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function g(){if(o.value){re.showMessage("正在批量处理中，请稍候...");return}const{docId:p,slides:y}=await u();if(!p){re.showMessage("请先在主编辑区打开幻灯片文档");return}if(y.length===0){re.showMessage("当前文档无幻灯片页面");return}const x=await Sc(p),k=new Set(x.map(A=>A.pageIndex)),v=y.map((A,T)=>({slide:A,idx:T})).filter(({slide:A,idx:T})=>{var U;const N=Array.isArray(A.noteBlocks)&&A.noteBlocks.length>0,F=!!((U=A.notes)!=null&&U.trim()),H=A.pageIndex??T+1;return!N&&!F&&!k.has(H)});if(x.length===0&&v.length===0){re.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let _="";x.length>0&&v.length>0?_=`扫描检测到 ${x.length} 处已有候选讲稿待规范化，另有 ${v.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:x.length>0?_=`扫描检测到 ${x.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:_=`将在未配置讲稿的 ${v.length} 页末尾自动增加默认讲稿提示块，是否继续？`,re.confirm("增加讲稿块",_,async()=>{if(o.value)return;o.value=!0,re.showMessage("正在处理讲稿块...");let A=0,T=0;try{for(const N of x)try{await Cc(N.id,N.cleanContent),A++}catch(F){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${N.id} 失败:`,F)}for(const{slide:N,idx:F}of v)try{await h(N,F,y,p),T++}catch(H){console.error(`[SiYuanLiveSlides] 为第 ${F+1} 页增加讲稿块失败:`,H)}e.plugin&&await e.plugin.compileCurrentDocument(),i("已更新讲稿"),A>0&&T>0?re.showMessage(`已规范化 ${A} 处现有讲稿，并为 ${T} 页新增讲稿块`):A>0?re.showMessage(`已成功识别并规范化 ${A} 个讲稿块`):re.showMessage(`已成功为 ${T} 页增加讲稿备注块`)}catch(N){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",N),re.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,createNoteBlockOnCurrentSlide:n,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:m,onBatchDeleteNotes:d,onIdentifyNotesBlocks:b,onAddOrIdentifyNotesBlocks:g}}function Fw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function jw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function Uw(e){const t=[],o=i=>{var n,s,l,r,a,c,u,h,m;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[qe])==="true"||((s=d.ial)==null?void 0:s[qe])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(Fw(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Oe])||((r=d.ial)==null?void 0:r[Oe]),rawBlock:d});continue}if(jw(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Oe])||((c=d.ial)==null?void 0:c[Oe]),rawBlock:d});continue}const b=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(b)&&b.length>0){o(b);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((h=d.attributes)==null?void 0:h[Oe])||((m=d.ial)==null?void 0:m[Oe]),rawBlock:d})}};return o(e||[]),t}function Ww(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=Uw(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const l=t[s];!!!(l.currentClicks&&String(l.currentClicks).trim()!=="")&&l.id&&i.push({blockId:l.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function qw(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Be.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const l of i.slides){const r=Ww(l);r.length>0&&(n.push(...r),s.add(l.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function Ic(e,t){const o=(t==null?void 0:t.showMessageFn)||re.showMessage,i=(t==null?void 0:t.confirmFn)||re.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await qw(e,t);if(l.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${a} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var m;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,h=0;for(const d of l.targets)try{await n(d.blockId,{[Oe]:d.targetClick}),Be.setBlockAttrOverride(d.blockId,{[Oe]:d.targetClick}),s(d.blockId,{[Oe]:d.targetClick}),u++}catch(b){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,b),h++}(m=t==null?void 0:t.onSuccessNotice)==null||m.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:h})},()=>{c({...l,successCount:0,errorCount:0})})})}async function Vw(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Be.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,l=new Set,r=(a,c)=>{var u,h,m,d,b;for(const g of a){if(!g)continue;if(g.id&&!s.has(g.id)){const y=Be.getBlockAttrOverride(g.id),x=(y==null?void 0:y[Oe])??g.clicks??((u=g.attributes)==null?void 0:u[Oe])??((h=g.ial)==null?void 0:h[Oe]),k=(y==null?void 0:y[Et])??g.motion??((m=g.attributes)==null?void 0:m[Et])??((d=g.ial)==null?void 0:d[Et]),v=!!(x&&String(x).trim()!==""),_=!!(k&&String(k).trim()!=="");(v||_)&&(s.add(g.id),n.push({blockId:g.id,pageIndex:c,hasClick:v,hasMotion:_}),l.add(c))}const p=g.children&&g.children.length>0?g.children:(b=g.rawNode)==null?void 0:b.children;Array.isArray(p)&&p.length>0&&r(p,c)}};for(const a of i.slides)r(a.blocks||[],a.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:l.size,targets:n}}async function Kw(e,t){const o=(t==null?void 0:t.showMessageFn)||re.showMessage,i=(t==null?void 0:t.confirmFn)||re.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await Vw(e,t);if(l.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${a} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,h=0;const m={[Oe]:"",[Et]:""};for(const b of l.targets)try{await n(b.blockId,m),Be.setBlockAttrOverride(b.blockId,m),s(b.blockId,m),u++}catch(g){console.error(`[SiYuanLiveSlides] 清除块 ${b.blockId} 动效失败:`,g),h++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:h})},()=>{c({...l,successCount:0,errorCount:0})})})}function Gw(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Ko]:"true",[li]:"true"}),e.activeBlockAttrs.value[Ko]="true",e.activeBlockAttrs.value[li]="true"):(await o(Ko,"false"),e.activeBlockAttrs.value[Ko]="false")}async function l(){const H=e.videoLoop.value?"false":"true";await o(Tn,H)}async function r(){const H=e.videoMuted.value?"false":"true";await o(li,H)}async function a(){const H=e.videoControls.value?"false":"true";await o(An,H)}async function c(H){var P,j;const U=e.activeBlockId.value;if(!U)return;const E=e.rawSnippet.value||"",D=ko(E)||"",S=e.currentPageDividerId.value||e.currentDocId.value;if(H)if(H==="background"){const I={[Ye]:"background",[be]:""};S&&D&&(e.pageBackground&&(e.pageBackground.value=D),await ze(S,{[ct]:D}).catch(()=>{}),Be.setBlockAttrOverride(S,{[ct]:D}),et(S,{[ct]:D}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=D)),await i(I)}else(H===Mn||H===En)&&await i({[be]:H,[Ye]:""});else{const I={[Ye]:"",[be]:""};if(e.activeBlockAttrs.value[ct]==="true"&&(I[ct]=""),S&&D&&((P=e.pageBackground)==null?void 0:P.value)===D&&(e.pageBackground&&(e.pageBackground.value=""),await ze(S,{[ct]:""}).catch(()=>{}),Be.setBlockAttrOverride(S,{[ct]:""}),et(S,{[ct]:""}),(j=e.targetSlide.value)!=null&&j.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i(I),typeof document<"u"){const M=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`),L=M==null?void 0:M.closest('[data-type="NodeListItem"]'),te=L==null?void 0:L.getAttribute("data-node-id");if(te&&te!==U){const V={[be]:"",[Ye]:""};et(te,V),Be.setBlockAttrOverride(te,V),await ze(te,V).catch(()=>{})}}}}function u(){e.elemClick.value?o(Oe,""):o(Oe,"+1")}function h(H){o(Oe,H)}function m(H){o(Et,H)}function d(H){(e.activeBlockAttrs.value[Te]||"")===H?o(Te,""):o(Te,H)}function b(H){e.elemShikiLines.value=H,o(ei,H)}function g(H){const U=H?H.trim():"",E=/^\d+$/.test(U)?`${U}px`:U;e.elemMaxHeight.value=E,o(Yi,E)}async function p(){const H=e.currentSlideLayout.value==="three-cols-header";await o(Te,H?"col-1":"left"),re.showMessage(H?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function y(){const H=e.activeBlockId.value;H&&re.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const U={[Oe]:"",[Et]:"",[Te]:"",[ei]:"",[Yi]:"",[qe]:"",[be]:"",[yt]:"",[Ye]:"",[Ct]:"",[ct]:"",[Wt]:"",[Ko]:"",[Tn]:"",[li]:"",[An]:""};if(et(H,U),await ze(H,U),Be.clearBlockAttrOverride(H),typeof document<"u"){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${H}"]`),D=E==null?void 0:E.closest('[data-type="NodeListItem"]'),S=D==null?void 0:D.getAttribute("data-node-id");S&&S!==H&&(et(S,U),await ze(S,U).catch(()=>{}),Be.clearBlockAttrOverride(S))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",re.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function x(){if(e.activeBlockId.value)try{await Go("markdown","---",e.activeBlockId.value,void 0),re.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{re.showMessage("插入分页符失败")}}async function k(){const H=e.activeBlockId.value||e.currentDocId.value;if(H)try{await Go("markdown","---",void 0,H),re.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{re.showMessage("插入分页符失败")}}async function v(){if(e.activeBlockId.value)try{await Js(e.activeBlockId.value),re.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{re.showMessage("删除失败")}}async function _(){var H,U;try{let E=null;if(typeof document<"u"){const S=e.activeBlockId.value;if(S){const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);P&&(E=P.getAttribute("data-type")==="NodeSuperBlock"?P:P.closest('[data-type="NodeSuperBlock"]'))}if(!E){const P=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(P){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`);if(j){let I=j.nextElementSibling;for(;I&&!(I.getAttribute("data-type")==="NodeThematicBreak"||(H=I.classList)!=null&&H.contains("protyle-wysiwyg__block--hr"));){const M=I.getAttribute("data-type")==="NodeSuperBlock"?I:I.querySelector('[data-type="NodeSuperBlock"]');if(M){E=M;break}I=I.nextElementSibling}}}else{const j=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),I=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of I)if(!j||M.compareDocumentPosition(j)&Node.DOCUMENT_POSITION_FOLLOWING){E=M;break}}}}const D=[];if(E){const S=Array.from(E.querySelectorAll(":scope > [data-node-id]"));for(const P of S){const j=P.getAttribute("data-node-id");j&&(D.push(j),P.removeAttribute("style"))}}else if((U=e.targetSlide.value)!=null&&U.blocks){for(const S of e.targetSlide.value.blocks)if(S.children&&S.children.length>=2){for(const P of S.children)P.id&&D.push(P.id);break}}if(D.length>0)for(const S of D)await ze(S,{style:""}).catch(()=>{});await n(yt,""),re.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(E){console.error("[layout-actions] resetSuperBlockWidth error:",E),re.showMessage("重置超级块比例失败")}}async function A(){var H,U,E;try{let D=null;if(typeof document<"u"){const P=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),j=e.activeBlockId.value;let I=[];if(P){const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`);if(te){let V=te.nextElementSibling;for(;V&&!(V.getAttribute("data-type")==="NodeThematicBreak"||(H=V.classList)!=null&&H.contains("protyle-wysiwyg__block--hr"));)I.push(V),V=V.nextElementSibling}}else{const te=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),V=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const Z of V)if(!te||Z.compareDocumentPosition(te)&Node.DOCUMENT_POSITION_FOLLOWING)I.push(Z);else break}const M=[];let L;for(const te of I){const V=te.getAttribute("data-type");V==="NodeHeading"&&(L=te.getAttribute("data-node-id")||void 0);const Z=[];V==="NodeSuperBlock"?Z.push(te):Z.push(...Array.from(te.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const ce of Z){if((ce.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const le=ce.getAttribute("data-node-id")||"";let Se=[];const $e=Array.from(ce.querySelectorAll('[data-type="NodeListItem"]'));if($e.length===4&&(Se=$e.map(ke=>ke.getAttribute("data-node-id")).filter(Boolean)),Se.length!==4){const ke=Array.from(ce.querySelectorAll(":scope > [data-node-id]"));ke.length===4&&(Se=ke.map(Ce=>Ce.getAttribute("data-node-id")).filter(Boolean))}Se.length===4&&M.push({sbId:le,itemIds:Se,headerId:L})}}M.length>0&&(j&&(D=M.find(te=>{if(te.sbId===j||te.itemIds.includes(j))return!0;const V=document.querySelector(`.protyle-wysiwyg [data-node-id="${te.sbId}"]`),Z=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);return!!(V&&Z&&V.contains(Z))})||null),D||(D=M[0]))}if(!D&&((U=e.targetSlide.value)!=null&&U.blocks)){const P=e.targetSlide.value,j=[];for(const M of P.blocks)M.rawNode?j.push(M.rawNode):j.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const I=fh(j,e.activeBlockId.value);I&&I.items.length===4&&(D={sbId:I.superBlockNode.id,itemIds:I.items.map(M=>M.id),headerId:(E=I.headerNode)==null?void 0:E.id})}const S=e.currentPageDividerId.value||e.currentDocId.value;if(S&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(S,{[be]:"clover"}),et(S,{[be]:"clover"}),await ze(S,{[be]:"clover"}).catch(()=>{})),D&&D.itemIds.length>0){D.headerId&&(Be.setBlockAttrOverride(D.headerId,{[Te]:"header"}),et(D.headerId,{[Te]:"header"}),await ze(D.headerId,{[Te]:"header"}).catch(()=>{}));const P=Math.min(4,D.itemIds.length);for(let j=0;j<P;j++){const I=D.itemIds[j],M=`col-${j+1}`;Be.setBlockAttrOverride(I,{[Te]:M}),et(I,{[Te]:M}),await ze(I,{[Te]:M}).catch(()=>{})}}return re.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(D){return console.error("[layout-actions] applyCloverLayout error:",D),re.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function T(){var U,E;const H=e.currentDocId.value||((U=e.plugin)==null?void 0:U.currentDocId);if(!H){re.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){re.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await Ic(H,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function N(){var U,E;const H=e.currentDocId.value||((U=e.plugin)==null?void 0:U.currentDocId);if(!H){re.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){re.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const D=await Kw(H,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});D.successCount>0&&e.activeBlockId.value&&D.targets.some(S=>S.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Oe],delete e.activeBlockAttrs.value[Et])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function F(){var E,D,S,P;const H=await Mw({currentDocId:((E=e.currentDocId)==null?void 0:E.value)||"",activeBlockId:((D=e.activeBlockId)==null?void 0:D.value)||""});if(!H.success){re.showMessage(H.error||"合并为横向超级块失败");return}const U=`🎉 已成功合并为横向超级块 (${H.colCount||2} 列)`;re.showMessage(U),t.triggerSaveNotice&&t.triggerSaveNotice(U),(S=e.plugin)!=null&&S.compileCurrentDocument&&await e.plugin.compileCurrentDocument((P=e.currentDocId)==null?void 0:P.value)}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:h,onElemMotionChange:m,onElemSlotChange:d,onElemShikiLinesChange:b,onElemMaxHeightChange:g,onSetTwoColsContrast:p,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:k,onDeleteCurrentBlock:v,onConvertToSuperBlock:F,resetSuperBlockWidth:_,applyCloverLayout:A,onAutoAnimateDocument:T,onClearAnimationsDocument:N}}function Yw(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l}=Dw(e),r=Hw(e,{triggerSaveNotice:t}),a=Gw(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){re.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,b=await Po(d,(y=e.currentDocId)==null?void 0:y.value,e.plugin);re.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const g=await lc(d,{title:b});ac(`${b}.html`,g)&&re.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function u(){if(!e.latestDoc.value){re.showMessage("请先在主编辑区打开幻灯片文档");return}cc(e.latestDoc.value)&&re.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const h=pe(!1);async function m(){var d;if(h.value){re.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){re.showMessage("请先在主编辑区打开幻灯片文档");return}h.value=!0;try{re.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,g=await Po(b,(d=e.currentDocId)==null?void 0:d.value,e.plugin),p=await pc(b,{title:g,onProgress:(y,x)=>{re.showMessage(`正在导出幻灯片图片 (${y} / ${x})...`,2e3)}});p.success?re.showMessage(`🎉 成功导出 ${p.total||0} 张幻灯片高清图片并已保存为 ${g}.zip！`,4e3):re.showMessage(`导出图片失败：${p.error||"未知异常"}`)}finally{h.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,onConvertToSuperBlock:a.onConvertToSuperBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onAutoAnimateDocument:a.onAutoAnimateDocument,onClearAnimationsDocument:a.onClearAnimationsDocument,isExportingImages:h,onExportHtml:c,onExportPdf:u,onExportImages:m}}function Zw(e){const t=ye(()=>Sr(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:l="defined"}=i,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Be.getBlockAttrOverride(a);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function xs(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function Jw(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(yo(i)||(i.content||i.markdown||"").trim())return i}return null}function Ss(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function Dl(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const a=t[r],c=(a.markdown||a.content||"").trim();if(c.includes("![")||c.includes("<img")||a.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,l=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(l=!0);return s||n>=3?"two-cols":l&&t.length<=2?"quote":"default"}function Xw(e,t){const o=[],i=new Set,n=6,s=6;let l=0,r=0,a=0,c=0,u=null;function h(m){const d=[];for(let b=m+1;b<e.length;b++){const g=e[b];if(yo(g))break;const p=xs(g);if(p!==null&&(p===1||p===2||p===3))break;d.push(g)}return d}if(e.length>0){let m=!1,d=-1;for(let b=0;b<e.length;b++){const g=e[b];if(yo(g)){m=!0;break}if((g.content||g.markdown||"").trim()){d=b;break}}if(!m&&d>=0){const b=e[d],g=xs(b);let p=g===1?"cover":"default";if(g!==1){const x=h(d);p=Dl(g,x)}const y=g===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:b.id,recommendedLayout:p,reason:y}),i.add(b.id)}}for(let m=0;m<e.length;m++){const d=e[m];if(yo(d)){l=0,r=0,a=0,c=0,u=null;continue}const b=Jw(e,m),g=!b||yo(b),p=xs(d);if(p===1||p===2||p===3){if(!(a===1&&c===0&&u!==null&&!(u===1&&p===2))&&!g&&l>0&&!i.has(d.id)){let _=p===1?"cover":"default";{const T=h(m);_=Dl(p,T)}let A=p===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":p===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";_==="image-right"||_==="image-left"?A+=" (推荐图文版式)":_==="two-cols"?A+=" (推荐双栏版式)":_==="quote"&&(A+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:_,reason:A}),i.add(d.id),l=1,r=Ss(d),a=1,c=0,u=p;continue}l++,r+=Ss(d),a++,u=p;continue}const x=Ss(d);if((l>=n||r+x>s&&l>0)&&!g&&l>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),l=1,r=x,a=0,c=1,u=null;continue}l++,r+=x,c++}return o}async function $c(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){re.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){re.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=Xw(o);if(i.length===0){re.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}re.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await Go("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}re.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function Tc(e){var s,l,r,a,c,u;if(!e.currentDocId&&typeof document<"u"){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){re.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){re.showMessage("当前文档无内容");return}const o=[],i=[];for(const h of t)h.type==="tb"||h.type==="thematic-break"||h.type==="NodeThematicBreak"||((s=h.markdown)==null?void 0:s.trim())==="---"||((l=h.markdown)==null?void 0:l.trim())==="***"||h.type==="b"&&(((r=h.markdown)==null?void 0:r.trim())==="---"||((a=h.content)==null?void 0:a.trim())==="---")?o.push(h.id):((c=h.ial)!=null&&c[ho]||(u=h.ial)!=null&&u[be])&&i.push(h.id);if(o.length===0&&i.length===0){re.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}const n=o.length;return new Promise(h=>{re.confirm("危险操作：清除所有分页线",`此操作将从正文中彻底删除全部 ${n} 处幻灯片分页线（全篇将合并为单页），删除后无法撤销。是否确认继续？`,async()=>{re.showMessage(`正在清除文档中的 ${n} 处分页线...`);let m=0;for(const d of o)try{await Js(d),m++}catch(b){console.warn("Failed to delete divider block:",b)}for(const d of i)try{await ze(d,{[ho]:"",[be]:""})}catch(b){console.warn("Failed to clear slide attrs:",b)}re.showMessage(`已成功清除文档中的 ${m} 处分页线并重新编译`),await e.compileCurrentDocument(e.currentDocId),h()},()=>{h()})})}const Qw={class:"spm-slides-inspector"},e2={class:"spm-inspector-topbar"},t2={class:"spm-inspector-title"},o2={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},i2={class:"spm-inspector-topbar-actions"},n2={class:"spm-target-banner"},s2={class:"spm-target-info"},r2=["aria-label"],l2={key:0,class:"spm-save-status"},a2=["title"],c2={class:"spm-inspector-body"},d2=zt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Vt("plugin"),i=pe(!1);function n(Q){i.value=!1,c.value=Q.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(Q.docId)}const s=pe(""),l=pe(""),r=pe({}),a=pe(""),c=pe(""),u=pe(""),h=pe(""),m=pe(""),d=pe(""),b=pe(""),g=pe(""),p=pe(null),y=pe(""),x=pe("");function k(){var ge;const Q=s.value||c.value;Q&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(Q).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const v=ye(()=>Sr(l.value)),_=ye(()=>l.value==="NodeCodeBlock"),A=pe(!1),T=ye(()=>{if(A.value||Ke.value)return!0;const Q=a.value||"";return!!ko(Q)}),N=ye(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ge=a.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),F=ye(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),H=ye(()=>{const Q=s.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),U=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),E=ye(()=>{if(v.value)return"分页符 (---)";if(F.value)return"全局文档";if(N.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),D=ye(()=>v.value?"tag-divider":F.value?"tag-doc":"tag-block"),S=ye(()=>r.value[be]||"default"),P=ye(()=>r.value[Ct]||"slide-left"),j=pe(""),I=pe(""),M=ye(()=>r.value[Ni]||"inherit"),L=ye(()=>{var Q;return Tw((Q=p.value)==null?void 0:Q.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:h.value,activeBlockAttrs:r.value})}),te=ye(()=>{var Q;return((Q=L.value)==null?void 0:Q.notes)||""}),V=ye(()=>{var Q,ge,Ee;return((Ee=(ge=(Q=L.value)==null?void 0:Q.noteBlocks)==null?void 0:ge[0])==null?void 0:Ee.id)||""}),Z=ye(()=>{var Ue,We,Re,kt,cn,$o;if(v.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Te]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(m.value)return m.value;const ge=h.value||(v.value?s.value:"");if(ge){const it=Be.getBlockAttrOverride(ge);if(it!=null&&it[be])return it[be]}if(ge&&((Ue=p.value)!=null&&Ue.slides)){const it=p.value.slides.find(oi=>oi.startBlockId===ge);if((We=it==null?void 0:it.frontmatter)!=null&&We.layout)return it.frontmatter.layout}if((kt=(Re=L.value)==null?void 0:Re.frontmatter)!=null&&kt.layout)return L.value.frontmatter.layout;if(($o=(cn=L.value)==null?void 0:cn.blocks)!=null&&$o.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ee=Be.getBlockAttrOverride(c.value);return Ee!=null&&Ee[be]?Ee[be]:"default"}),ce=Zw({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:h}),oe=ce.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var Q,ge;return((ge=(Q=L.value)==null?void 0:Q.frontmatter)==null?void 0:ge.layoutRatio)||""}}),le=ce.resolvePageAttr({attrKey:ci,fallback:()=>{var Q,ge;return((ge=(Q=L.value)==null?void 0:Q.frontmatter)==null?void 0:ge.mask)||""}}),Se=ce.resolvePageAttr({attrKey:Zo,fallback:()=>{var Q,ge;return((ge=(Q=L.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskRatio)||""}}),$e=ce.resolvePageAttr({attrKey:di,fallback:()=>{var Q,ge;return((ge=(Q=L.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),ke=ce.resolvePageAttr({attrKey:ui,fallback:()=>{var Q,ge;return((ge=(Q=L.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function Ce(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const Ue=Ee.length,We=Ee.map($o=>{const it=$o.getAttribute("style")||"",oi=it.match(/calc\(\s*([\d.]+)%/);if(oi)return parseFloat(oi[1]);const Ti=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ti?parseFloat(Ti[1]):null});let Re="",kt=!1;if(We.some($o=>$o!==null)){kt=!0;const $o=We.reduce((Ne,wt)=>Ne+(wt||0),0),it=We.filter(Ne=>Ne===null).length,oi=it>0?Math.max(0,100-$o)/it:100/Ee.length,Ti=We.map(Ne=>Ne!==null?Ne:oi),bd=Ti.reduce((Ne,wt)=>Ne+wt,0)||1,Ai=Ti.map(Ne=>Ne/bd*100);if(Ai.length===2){const[Ne]=Ai;if(Ne>=48&&Ne<=52)Re="1:1";else if(Ne>=31&&Ne<=35)Re="1:2";else if(Ne>=65&&Ne<=69)Re="2:1";else if(Ne>=28&&Ne<=32)Re="3:7";else if(Ne>=68&&Ne<=72)Re="7:3";else if(Ne>=38&&Ne<=42)Re="4:6";else if(Ne>=58&&Ne<=62)Re="6:4";else{const wt=Math.round(Ne);Re=`${wt}:${100-wt}`}}else if(Ai.length===3){const[Ne,wt,To]=Ai;if(Ne>=31&&Ne<=35&&wt>=31&&wt<=35&&To>=31&&To<=35)Re="1:1:1";else if(Ne>=23&&Ne<=27&&wt>=48&&wt<=52&&To>=23&&To<=27)Re="1:2:1";else if(Ne>=48&&Ne<=52&&wt>=23&&wt<=27&&To>=23&&To<=27)Re="2:1:1";else if(Ne>=23&&Ne<=27&&wt>=23&&wt<=27&&To>=48&&To<=52)Re="1:1:2";else{const Tr=Math.round(Ne),Ar=Math.round(wt);Re=`${Tr}:${Ar}:${100-Tr-Ar}`}}else Re=Ai.map(Ne=>Math.round(Ne)).join(":")}else kt=!1,Re=Array.from({length:Ue},()=>1).join(":");const cn=Ue>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ue,ratio:Re,isCustomWidth:kt,recommendedLayout:cn}}function R(Q){if(!(Q!=null&&Q.blocks))return null;for(const ge of Q.blocks){const Ee=ge.rawNode;if(Ee&&ut(Ee)&&so(Ee)){const We=Ii(Ee).length,Re=vr(Ee);return{hasSuperBlock:!0,colCount:We,ratio:Re||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const ie=ye(()=>{var Q;if(typeof document<"u"){const ge=s.value;if(ge){const Ue=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(Ue){const We=Ue.getAttribute("data-type")==="NodeSuperBlock"?Ue:Ue.closest('[data-type="NodeSuperBlock"]');if(We){const Re=Ce(We);if(Re)return Re}}}const Ee=h.value||(v.value?s.value:"");if(Ee){const Ue=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(Ue){let We=Ue.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(Q=We.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Re){const kt=Ce(Re);if(kt)return kt}We=We.nextElementSibling}}}else{const Ue=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of We)if(!Ue||Re.compareDocumentPosition(Ue)&Node.DOCUMENT_POSITION_FOLLOWING){const kt=Ce(Re);if(kt)return kt}}}return R(L.value)}),B=ye(()=>{var Q;return((Q=ie.value)==null?void 0:Q.ratio)||""}),W=ye(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),w=ye(()=>{var Q;return((Q=L.value)==null?void 0:Q.pageIndex)||1}),q=ye(()=>!!r.value[qe]);function z(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!Q)return!1;const ge=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const C=ye(()=>{var ge;if(r.value[Oe]!==void 0)return r.value[Oe]||"";if(d.value&&z())return g.value||"";if(d.value)return"";const Q=s.value;if(Q&&((ge=L.value)!=null&&ge.blocks)){const Ee=L.value.blocks.find(Ue=>Ue.id===Q);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),$=ye(()=>{var ge;if(r.value[Et])return r.value[Et];const Q=s.value;if(Q&&((ge=L.value)!=null&&ge.blocks)){const Ee=L.value.blocks.find(Ue=>Ue.id===Q);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),O=ye(()=>{var ge;if(r.value[Te])return r.value[Te];const Q=s.value;if(Q&&((ge=L.value)!=null&&ge.blocks)){const Ee=L.value.blocks.find(Ue=>Ue.id===Q);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),G=pe(""),K=pe(""),Y=ye(()=>r.value[Ko]==="true"),X=ye(()=>r.value[Tn]==="true"),ae=ye(()=>r.value[li]==="true"),ne=ye(()=>r.value[An]!=="false"),me=ye(()=>{var Q,ge;return((ge=(Q=p.value)==null?void 0:Q.config)==null?void 0:ge.theme)||r.value[Vi]||"apple-basic"}),_e=ye(()=>{var Q,ge;return((ge=(Q=p.value)==null?void 0:Q.config)==null?void 0:ge.aspectRatio)||r.value[Ki]||"16/9"}),we=ye(()=>{var Q,ge;return((ge=(Q=p.value)==null?void 0:Q.config)==null?void 0:ge.defaultTransition)||r.value[Gi]||"slide-left"}),Le=ye(()=>{var Q,ge;return((ge=(Q=p.value)==null?void 0:Q.config)==null?void 0:ge.spacing)||r.value[As]||"normal"}),He=ye(()=>{var Q,ge;return((ge=(Q=p.value)==null?void 0:Q.config)==null?void 0:ge.background)||r.value[$n]||""}),Ke=ye(()=>{var We,Re;if((r.value[Ye]||r.value["slides-role"])===Fl||r.value[ct]==="true")return"background";const ge=r.value[be]||r.value["slides-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Ee=a.value||"",Ue=ko(Ee);if(Ue&&((Re=(We=L.value)==null?void 0:We.frontmatter)!=null&&Re.background)){const kt=L.value.frontmatter.background;if(kt===Ue||kt.endsWith(Ue)||Ue.endsWith(kt))return"background"}return""}),rt=ye(()=>!!(r.value[Oe]||r.value[Et]||r.value[Te]||r.value[ei]||r.value[qe]||r.value["slides-note"]||r.value[Ye]||r.value[be]||r.value[Ko]||r.value[Tn]||r.value[li]||r.value[An])),{saveAttr:Pe,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ge,resetSuperBlockWidth:fe,saveDocAttr:he,onToggleVideoAutoplay:Qe,onToggleVideoLoop:lt,onToggleVideoMuted:$t,onToggleVideoControls:at,onImageRoleChange:ao,onToggleNoteBlock:Dc,onAddNoteBlock:Lc,onLocateNoteBlock:Oc,onGenerateNotesWithAI:Nc,isBatchProcessing:an,onBatchDeleteNotes:Pc,onAddOrIdentifyNotesBlocks:Rc,onAutoAnimateDocument:zc,onClearAnimationsDocument:Hc,toggleElemClick:Fc,onElemClickStepChange:jc,onElemMotionChange:Uc,onElemSlotChange:Wc,onElemShikiLinesChange:qc,onElemMaxHeightChange:Vc,onSetTwoColsContrast:Kc,onClearBlockAttrs:Gc,onInsertDividerBefore:Yc,onInsertDividerAfter:Cr,onDeleteCurrentBlock:Zc,onConvertToSuperBlock:_r,onExportHtml:Jc,onExportPdf:Xc}=Yw({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:h,currentPageDividerLayout:m,parentContainerId:d,parentContainerClicks:g,latestDoc:p,targetSlide:L,currentSlideNoteBlockId:V,currentSlideLayout:Z,isNoteBlock:q,elemClick:C,videoAutoplay:Y,videoLoop:X,videoMuted:ae,videoControls:ne,pageBackground:j,pageImage:I,elemShikiLines:G,elemMaxHeight:K,saveStatus:y,plugin:o}),ns=pe(!1);function Io(){ns.value=Aw(s.value,l.value)}ti(()=>{typeof document<"u"&&(document.addEventListener("selectionchange",Io),document.addEventListener("mouseup",Io),document.addEventListener("keyup",Io)),Io()}),sn(()=>{typeof document<"u"&&(document.removeEventListener("selectionchange",Io),document.removeEventListener("mouseup",Io),document.removeEventListener("keyup",Io))}),Ro([s,l],()=>{Io()});async function Qc(Q){if(Q==="clover"){if(!await Ge())return}else ft(be,Q)}function ed(Q){ft(yt,Q)}async function td(Q){await ft(ci,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Se.value||Se.value==="1:1")&&await ft(Zo,"1:1:1:1")}function od(Q){ft(Zo,Q)}function id(Q){ft(di,Q)}function nd(Q){ft(ui,Q)}function Ir(Q){if(!Q)return;const ge=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ee=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");tt(ge,Ee)}function sd(Q){ft(yt,Q)}async function rd(){await fe()}function ld(Q){Pe(Ct,Q)}function ad(Q){I.value=Q,Pe(Wt,Q)}function cd(Q){Pe(Ni,Q==="inherit"?"":Q)}function dd(Q){he(Vi,Q)}function ud(Q){he($n,Q)}function fd(Q){he(Ki,Q)}function hd(Q){he(Gi,Q)}function pd(Q){he(As,Q)}function $r(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function md(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}function gd(){o&&Ot("aiScript")&&$c(o)}async function yd(){if(o&&Ot("aiScript")){if(an.value)return;an.value=!0;try{await Tc(o)}finally{an.value=!1}}}return t({setActiveBlock(Q){s.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,h.value=Q.pageDividerId||"",m.value=Q.pageDividerLayout||"",d.value=Q.parentContainerId||"",b.value=Q.parentContainerSlot||"",g.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),j.value=Q.attrs[ct]||"",I.value=Q.attrs[Wt]||"",G.value=Q.attrs[ei]||"",K.value=Q.attrs[Yi]||"",A.value=!!Q.isImage},updateDocument(Q){p.value=Q,c.value=Q.docId},openImportDialog(){i.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ge)=>(J(),ee("div",Qw,[f("div",e2,[f("div",t2,[(J(),ee("svg",o2,[...ge[2]||(ge[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=f("span",null,"演示配置",-1))]),f("div",i2,[ue(Ot)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Ee=>i.value=!0)},[se(de,{name:"import"}),ge[4]||(ge[4]=f("span",null,"导入",-1))])):Ae("",!0),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:$r},[se(de,{name:"split-preview"}),ge[5]||(ge[5]=f("span",null,"分屏预览",-1))])])]),f("div",n2,[f("div",s2,[f("span",{class:xe(["spm-target-tag",D.value])},ve(E.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:k},[se(de,{name:"copy"}),f("span",null,"#"+ve(H.value),1)],8,r2)]),y.value?(J(),ee("span",l2,"● "+ve(y.value),1)):Ae("",!0)]),U.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:a.value},ve(U.value),9,a2)):Ae("",!0),f("div",c2,[v.value?(J(),io(vv,{key:0,"page-layout":S.value,"page-layout-ratio":ue(oe),"page-mask":ue(le),"page-mask-ratio":ue(Se),"page-mask-style":ue($e),"page-mask-initial":ue(ke),"detected-sb-ratio":B.value,"detected-sb-info":ie.value,"page-transition":P.value,"page-spacing":M.value,"page-image":I.value,"page-notes":te.value,"page-index":w.value,"can-convert-to-super-block":ns.value,"onUpdate:pageLayout":Qc,"onUpdate:pageLayoutRatio":ed,"onUpdate:pageMask":td,"onUpdate:pageMaskRatio":od,"onUpdate:pageMaskStyle":id,"onUpdate:pageMaskInitial":nd,onApplySuperBlockLayout:Ir,onResetSuperblockRatio:rd,"onUpdate:pageTransition":ld,"onUpdate:pageSpacing":cd,"onUpdate:pageImage":ad,onAddNoteBlock:ue(Lc),onLocateNoteBlock:ue(Oc),onGenerateNotes:ue(Nc),onInsertDividerAfter:ue(Cr),onDeleteDivider:ue(Zc),onConvertToSuperBlock:ue(_r)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","can-convert-to-super-block","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider","onConvertToSuperBlock"])):s.value&&!F.value?(J(),io(X1,{key:1,"elem-click":C.value,"elem-motion":$.value,"elem-slot":O.value,"elem-shiki-lines":G.value,"elem-max-height":K.value,"is-code-block":_.value,"is-image":T.value,"is-video":N.value,"is-super-block":W.value,"detected-sb-info":ie.value,"video-autoplay":Y.value,"video-loop":X.value,"video-muted":ae.value,"video-controls":ne.value,"has-block-attrs":rt.value,"is-note":q.value,"image-role":Ke.value,"current-slide-layout":Z.value,"parent-elem-click":g.value,"parent-container-slot":b.value,"parent-container-id":d.value,"can-convert-to-super-block":ns.value,onToggleNote:ue(Dc),onToggleElemClick:ue(Fc),onToggleVideoAutoplay:ue(Qe),onToggleVideoLoop:ue(lt),onToggleVideoMuted:ue($t),onToggleVideoControls:ue(at),"onUpdate:imageRole":ue(ao),"onUpdate:elemClick":ue(jc),"onUpdate:elemMotion":ue(Uc),"onUpdate:elemSlot":ue(Wc),"onUpdate:elemShikiLines":ue(qc),"onUpdate:elemMaxHeight":ue(Vc),onApplySuperBlockLayout:Ir,onApplySuperBlockRatio:sd,onInsertDividerBefore:ue(Yc),onInsertDividerAfter:ue(Cr),onSetTwoColsContrast:ue(Kc),onClearBlockAttrs:ue(Gc),onConvertToSuperBlock:ue(_r)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","can-convert-to-super-block","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs","onConvertToSuperBlock"])):(J(),io(_0,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":_e.value,"doc-default-transition":we.value,"doc-spacing":Le.value,"is-batch-processing":ue(an),"onUpdate:docTheme":dd,"onUpdate:docBackground":ud,"onUpdate:docAspectRatio":fd,"onUpdate:docDefaultTransition":hd,"onUpdate:docSpacing":pd,onOpenBottomPreview:$r,onOpenPresenter:md,onAddOrIdentifyNotes:ue(Rc),onClearNotes:ue(Pc),onAutoAnimate:ue(zc),onClearAnimations:ue(Hc),onAiAutoSplit:gd,onClearDividers:yd,onExportHtml:ue(Jc),onExportPdf:ue(Xc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&ue(Ot)("import")?(J(),io($w,{key:1,onClose:ge[1]||(ge[1]=Ee=>i.value=!1),onSuccess:n})):Ae("",!0)]))}}),u2=2e3,f2=600;function h2(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function Cs(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Ll(e))return!0;const t=e.firstElementChild;return!!(t&&Ll(t))}function Ll(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function p2(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class m2{constructor(){Ie(this,"consumers",new Map);Ie(this,"seq",0);Ie(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=p2(),l={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(o)):l.visible=Cs(o),this.consumers.set(n,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?Cs(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!h2(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&Cs(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},u2))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const Cn=new m2,$i=new os;function Ac(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=Cn.register(e,t,i);return i(),n}let Lo=null,Ft=null,_n=null;function g2(){return Ft}function y2(e,t){Lo&&Mc(),Lo=yr(Ug),Lo.provide("plugin",t),Lo.provide("sandboxBridge",$i);const o=Lo.mount(e);return Ft=o,_n=Ac("preview",e,t),o}function Mc(e){_n&&(_n(),_n=null),Lo&&(Lo.unmount(),Lo=null,Ft=null)}function b2(){return Ft!==null}let Oo=null,Yo=null;function v2(e,t){return Oo&&Ec(),Oo=yr(Qy),Oo.provide("plugin",t),Oo.provide("sandboxBridge",$i),Yo=Oo.mount(e),Yo}function Ec(e){Oo&&(Oo.unmount(),Oo=null,Yo=null)}function k2(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||Fo()}}),o.close()}catch{}}let No=null,Nt=null,In=null;function w2(e,t){No&&Bc(),No=yr(d2),No.provide("plugin",t),No.provide("sandboxBridge",$i);const o=No.mount(e);return Nt=o,In=Ac("dock",e,t),o}function Bc(e){In&&(In(),In=null),No&&(No.unmount(),No=null,Nt=null)}function x2(e,t){Nt!=null&&Nt.updateDocument&&Nt.updateDocument(e),Ft!=null&&Ft.updateDocument?Ft.updateDocument(e,t):($i.updateSlides(e.slides,e.config),k2(e)),Yo!=null&&Yo.updateDocument&&Yo.updateDocument(e)}function Zs(e){Ft!=null&&Ft.navigateToBlock?Ft.navigateToBlock(e):$i.highlightElement(e)}function ri(e){Nt!=null&&Nt.setActiveBlock&&Nt.setActiveBlock(e)}function S2(){return Do("import")?!1:Nt!=null&&Nt.openImportDialog?(Nt.openImportDialog(),!0):!1}const C2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:ho,value:"true"},{key:be,value:"cover"},{key:Ct,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:ho,value:"true"},{key:be,value:"two-cols"},{key:Ct,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:ho,value:"true"},{key:be,value:"fact"},{key:Ct,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:ho,value:"true"},{key:be,value:"intro"},{key:Ct,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:ho,value:"true"},{key:be,value:"quote"},{key:Ct,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Oe,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Oe,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Te,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:ei,value:"1-3"}]}];class _s{getPresetTemplates(){return C2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Ct}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${Ct}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[Ct]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function _2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),Do("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{S2()||re.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),re.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),Do("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>$c(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>Tc(e)})),Do("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,h;if(!e.currentDocId){const m=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(m==null?void 0:m.getAttribute("data-doc-id"))||""}if(!e.currentDocId){re.showMessage("请先打开一篇思源笔记文档");return}re.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Si(e.currentDocId).catch(()=>[]),o={startBlockId:e.currentDocId,blocks:t.map(m=>({id:m.id,type:m.type,content:m.content||"",rawMarkdown:m.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await Pw(o,is)).split(/\r?\n/).map(m=>`> ${m}`).join(`
`)}
{: custom-slides-note="true"}`,l=await $s("markdown",s,e.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((h=l==null?void 0:l[0])==null?void 0:h.id);r&&(await ze(r,{"custom-slides-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Qo(r,e.app)),re.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){re.showMessage("请先在主编辑区打开幻灯片文档");return}await _c(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){re.showMessage("请先在主编辑区打开幻灯片文档");return}await Ic(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new _s,o=t.buildTransitionStatsSql(),i=await vi(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);re.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new _s().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),re.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):re.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new _s().batchUpdateTransitions("fade","slide-left",i=>vi(i).catch(()=>[]),(i,n)=>ze(i,n));re.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),Do("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!Do("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){re.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){re.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{re.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await Po(o,e.currentDocId,e),n=await pc(o,{title:i,onProgress:(s,l)=>{re.showMessage(`正在导出幻灯片图片 (${s} / ${l})...`,2e3)}});n.success?re.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):re.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class I2{constructor(t=400){Ie(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function $2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class T2{constructor(t=150){Ie(this,"lastBlockId","");Ie(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class A2{constructor(){Ie(this,"attrCache",new I2);Ie(this,"compiledIalIndex",{doc:null,map:new Map});Ie(this,"locatingLockUntil",0);Ie(this,"lockedTargetBlockId","");Ie(this,"lastKnownPageDividerId","");Ie(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Be.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const l=await Xs(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:$2(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);ri({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Zs(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,h,m;if(!t){qi();const d=typeof s=="number"&&s>0?s:1,b=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(b){const g=b.startBlockId||"",p=((h=b.frontmatter)==null?void 0:h.layout)||"",y={"custom-slides-layout":p,...b.frontmatter};return ri({id:g,rootId:i,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:g,pageDividerLayout:p}),this.resolveBlockAttrs(g,n).then(x=>{x&&Object.keys(x).length>0&&ri({id:g,rootId:i,type:"NodeThematicBreak",attrs:{...y,...x},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:g,pageDividerLayout:p})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const l=Qo(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,i,n);else{let d="",b="";if(n!=null&&n.slides){const g=n.slides.find(p=>{var y,x,k;return p.startBlockId===t||((y=p.blocks)==null?void 0:y.some(v=>v.id===t))||((x=p.allBlockIds)==null?void 0:x.includes(t))||((k=p.noteBlocks)==null?void 0:k.some(v=>v.id===t))});g!=null&&g.startBlockId&&(d=g.startBlockId),(m=g==null?void 0:g.frontmatter)!=null&&m.layout&&(b=g.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async g=>{if(d&&!b){const p=Be.getBlockAttrOverride(d);if(p!=null&&p[be]||p!=null&&p["custom-slides-layout"])b=p[be]||p["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(d,n);b=y[be]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Be.setBlockAttrOverride(d,y)}}ri({id:t,rootId:i,type:a||"NodeParagraph",attrs:g||{},pageDividerId:d,pageDividerLayout:b})}).catch(()=>{})}return l}async syncInspectorBlock(t,o,i,n,s){var P,j,I,M,L,te,V,Z,ce;if(this.isLocatingLocked(o))return;let l=t,r=o,a=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const le=await this.resolveBlockAttrs(oe,s),Se=Be.getBlockAttrOverride(oe)||{};({...le,...Se})[qe]&&(l=c,r=oe,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,h=(u==null?void 0:u.getAttribute("data-node-id"))||r,m=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((P=u==null?void 0:u.classList)!=null&&P.contains("hr")),d=a==="NodeCodeBlock",b=((j=l.innerText)==null?void 0:j.trim())||"",g=await this.resolveBlockAttrs(r,s),p=Be.getBlockAttrOverride(r)||{},y={...g,...p};let x="",k="";if(m)x=r,k=y[be]||y["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const le=oe.getAttribute("data-type");if(le==="NodeThematicBreak"||le==="tb"||(I=oe.classList)!=null&&I.contains("hr")){x=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,h];let le=l.parentElement;for(;le&&!le.classList.contains("protyle-wysiwyg");){const $e=le.getAttribute("data-node-id");$e&&!oe.includes($e)&&oe.push($e),le=le.parentElement}const Se=s.slides.find($e=>{var ke,Ce,R;return oe.includes($e.startBlockId)||((ke=$e.blocks)==null?void 0:ke.some(ie=>oe.includes(ie.id)))||((Ce=$e.allBlockIds)==null?void 0:Ce.some(ie=>oe.includes(ie)))||((R=$e.noteBlocks)==null?void 0:R.some(ie=>oe.includes(ie.id)))});Se&&(!x&&Se.startBlockId&&(x=Se.startBlockId),!k&&((M=Se.frontmatter)!=null&&M.layout)&&(k=Se.frontmatter.layout))}if(x?(this.lastKnownDocId=n,this.lastKnownPageDividerId=x):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((L=u.parentElement)==null?void 0:L.scrollTop)||0)===0||(x=this.lastKnownPageDividerId)),x){const oe=Be.getBlockAttrOverride(x);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(k=oe[be]||oe["custom-slides-layout"]||""),!k&&(s!=null&&s.slides)){const le=s.slides.find(Se=>Se.startBlockId===x);(te=le==null?void 0:le.frontmatter)!=null&&te.layout&&(k=le.frontmatter.layout)}if(!k){const le=await this.resolveBlockAttrs(x,s);k=le[be]||le["custom-slides-layout"]||"",le&&Object.keys(le).length>0&&Be.setBlockAttrOverride(x,le)}et(x,{[be]:k||""})}else if(n){const oe=Be.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?k=oe[be]||oe["custom-slides-layout"]||"":!k&&((ce=(Z=(V=s==null?void 0:s.slides)==null?void 0:V[0])==null?void 0:Z.frontmatter)!=null&&ce.layout)&&(k=s.slides[0].frontmatter.layout)}const v=l.getAttribute(be)||l.getAttribute("custom-slides-layout"),_=y[be]||y["custom-slides-layout"]||"";v&&v!==_&&et(r,{[be]:_});const A=l.getAttribute(Ye)||l.getAttribute("custom-slides-role"),T=y[Ye]||y["custom-slides-role"]||"";A&&A!==T&&et(r,{[Ye]:T});let N="",F="",H="";const U=l.closest('[data-type="NodeListItem"]');if(U&&U!==l){const oe=U.getAttribute("data-node-id");if(oe){N=oe;const le=await this.resolveBlockAttrs(oe,s),Se=Be.getBlockAttrOverride(oe)||{},$e={...le,...Se};F=$e[Te]||"",H=$e[Oe]||"";const ke=$e[be]||$e["custom-slides-layout"]||"",Ce=U.getAttribute(be)||U.getAttribute("custom-slides-layout");Ce&&Ce!==ke&&et(oe,{[be]:ke});const R=$e[Ye]||$e["custom-slides-role"]||"",ie=U.getAttribute(Ye)||U.getAttribute("custom-slides-role");ie&&ie!==R&&et(oe,{[Ye]:R})}}const E=!!l.querySelector("img, span[data-type='img']"),D=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),S=E&&D.length<=50;ri({id:r,rootId:n,type:a,content:b,attrs:y,isDivider:m,isCode:d,isImage:S,topBlockId:h,pageDividerId:x,pageDividerLayout:k,parentContainerId:N,parentContainerSlot:F,parentContainerClicks:H})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},l={};for(const r of Object.keys(n))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(i.id,l),Be.setBlockAttrOverride(i.id,l)}}}}purgeStaleDomSlidesAttrs(t){var n,s,l;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(a[be]=r.frontmatter.layout),o.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=o.get(a.id)||{};(s=a.ial)!=null&&s[be]&&(c[be]=a.ial[be]),(l=a.ial)!=null&&l[Ye]&&(c[Ye]=a.ial[Ye]),Object.keys(c).length>0&&o.set(a.id,c)}}}const i=Be.getAllAttrOverrides();for(const[r,a]of i.entries()){const c=o.get(r)||{};a[be]!==void 0&&(c[be]=a[be]),a[Ye]!==void 0&&(c[Ye]=a[Ye]),o.set(r,c)}Ew(o)}}const Mo=new A2;class M2{constructor(){Ie(this,"state","IDLE");Ie(this,"inFlightDocId",null);Ie(this,"pendingDocs",new Set);Ie(this,"lastPendingDocId",null);Ie(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}function E2(e){const t=new re.Setting({width:"680px"}),o=zo();let i=sh();const n=document.createElement("div");n.className="slides-settings__ai-panel",n.style.cssText="display: flex; flex-direction: column; gap: 10px; width: 100%;";const s=document.createElement("div");s.className="slides-settings__tip-container",n.appendChild(s);function l(P){var j,I;if(s.innerHTML="",P){const M=document.createElement("div");M.className="api-switch-managed-tip",M.style.cssText=`
        background-color: var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08));
        border: 1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2));
        border-radius: 6px;
        padding: 8px 12px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--b3-theme-on-background);
      `;const L=((I=(j=window.siyuan)==null?void 0:j.config)==null?void 0:I.lang)==="en_US",te=P.profileName||(L?"Unnamed":"未命名");M.innerHTML=L?`💡 General AI API is managed by <strong>API Switch (siyuan-api-switch)</strong> (Profile: ${te}). Related inputs are read-only. Please configure in the API Switch panel.`:`💡 通用 AI API 已由 <strong>API 旋钮 (siyuan-api-switch)</strong> 接管 (Profile: ${te})。相关输入框已置灰只读，如需修改请前往 API 旋钮面板。`,s.appendChild(M)}}l(i);function r(P,j,I){const M=document.createElement("div");M.style.cssText="display: flex; flex-direction: column; gap: 4px;";const L=document.createElement("div");L.style.cssText="display: flex; align-items: center; justify-content: space-between; gap: 12px;";const te=document.createElement("span");if(te.style.cssText="font-size: 13px; font-weight: 500; min-width: 120px; color: var(--b3-theme-on-background);",te.textContent=P,L.appendChild(te),L.appendChild(j),M.appendChild(L),I){const V=document.createElement("span");V.style.cssText="font-size: 11px; color: var(--b3-theme-on-surface); line-height: 1.4;",V.textContent=I,M.appendChild(V)}return M}const a=document.createElement("input");a.className="b3-text-field fn__flex-1",a.placeholder="https://api.openai.com/v1",a.dataset.settingKey="ai-base-url",a.value=i?i.baseUrl:o.aiConfig.baseUrl,a.disabled=!!i,a.addEventListener("change",async()=>{const P=a.value.trim();await S({baseUrl:P})});const c=document.createElement("div");c.style.cssText="display: flex; align-items: center; gap: 6px; flex: 1;";const u=document.createElement("input");u.className="b3-text-field fn__flex-1",u.type="password",u.placeholder="sk-...",u.dataset.settingKey="ai-api-key",u.value=i?i.apiKey:o.aiConfig.apiKey,u.disabled=!!i,u.addEventListener("change",async()=>{const P=u.value.trim();await S({apiKey:P})});let h=!1;const m=document.createElement("button");m.className="b3-button b3-button--text",m.type="button",m.style.cssText="padding: 4px 8px; font-size: 12px; cursor: pointer;",m.textContent="显示",m.addEventListener("click",()=>{h=!h,u.type=h?"text":"password",m.textContent=h?"隐藏":"显示"}),c.appendChild(u),c.appendChild(m);const d=document.createElement("input");d.className="b3-text-field fn__flex-1",d.placeholder="gpt-4o-mini / deepseek-chat",d.dataset.settingKey="ai-model",d.value=i?i.model:o.aiConfig.model,d.disabled=!!i,d.addEventListener("change",async()=>{const P=d.value.trim();await S({model:P})});const b=document.createElement("details");b.style.cssText="margin-top: 4px; font-size: 12px;";const g=document.createElement("summary");g.style.cssText="cursor: pointer; color: var(--b3-theme-primary); font-weight: 500; padding: 4px 0;",g.textContent="高级模型参数 (超时/采样温度/Token)",b.appendChild(g);const p=document.createElement("div");p.style.cssText="display: flex; flex-direction: column; gap: 8px; padding-top: 8px;";const y=document.createElement("input");y.className="b3-text-field fn__flex-1",y.type="number",y.dataset.settingKey="ai-timeout",y.value=String((i==null?void 0:i.requestTimeoutSeconds)??o.aiConfig.requestTimeoutSeconds??pt.requestTimeoutSeconds),y.disabled=!!i,y.addEventListener("change",async()=>{const P=Number.parseInt(y.value,10)||pt.requestTimeoutSeconds;await S({requestTimeoutSeconds:P})});const x=document.createElement("input");x.className="b3-text-field fn__flex-1",x.type="number",x.step="0.1",x.dataset.settingKey="ai-temperature",x.value=String((i==null?void 0:i.temperature)??o.aiConfig.temperature??pt.temperature),x.disabled=!!i,x.addEventListener("change",async()=>{const P=Number.parseFloat(x.value)||pt.temperature;await S({temperature:P})});const k=document.createElement("input");k.className="b3-text-field fn__flex-1",k.type="number",k.dataset.settingKey="ai-max-tokens",k.value=String((i==null?void 0:i.maxTokens)??o.aiConfig.maxTokens??pt.maxTokens),k.disabled=!!i,k.addEventListener("change",async()=>{const P=Number.parseInt(k.value,10)||pt.maxTokens;await S({maxTokens:P})}),p.appendChild(r("请求超时时间 (秒)",y)),p.appendChild(r("采样温度 (Temperature)",x,"范围 0.0 - 2.0，数值越高越富有创意")),p.appendChild(r("单次最大输出 Token",k)),b.appendChild(p);const v=document.createElement("div");v.style.cssText="display: flex; align-items: center; gap: 10px; margin-top: 6px;";const _=document.createElement("button");_.className="b3-button b3-button--outline",_.type="button",_.textContent="测试连接";const A=document.createElement("span");A.style.cssText="font-size: 12px; color: var(--b3-theme-on-surface); flex: 1; word-break: break-all;",_.addEventListener("click",async()=>{const P=i||{baseUrl:a.value.trim(),apiKey:u.value.trim(),model:d.value.trim(),requestTimeoutSeconds:Number.parseInt(y.value,10)||15,temperature:Number.parseFloat(x.value)||.7,maxTokens:10};if(!Fn(P)){A.style.color="var(--b3-theme-error, #f44336)",A.textContent="请先填写完整的 Base URL、API Key 与 Model";return}_.disabled=!0,A.style.color="var(--b3-theme-primary)",A.textContent="正在发起测试请求...";const j=await Nw(P);_.disabled=!1,j.success?(A.style.color="var(--b3-theme-primary, #4caf50)",A.textContent=j.message):(A.style.color="var(--b3-theme-error, #f44336)",A.textContent=j.message)}),v.appendChild(_),v.appendChild(A),n.appendChild(r("API 基础地址 (Base URL)",a,"兼容 OpenAI 规范的 API 根路径，如 https://api.deepseek.com/v1")),n.appendChild(r("API 鉴权密钥 (API Key)",c)),n.appendChild(r("模型名称 (Model)",d,"例如 deepseek-chat, gpt-4o-mini 等")),n.appendChild(b),n.appendChild(v),t.addItem({title:"AI 演讲提词服务",direction:"column",description:"配置兼容 OpenAI API 的大模型服务，用于提炼演讲口播提词卡 (Notes)。支持被「API 旋钮」集中调度接管。",actionElement:n});const T=document.createElement("div");T.style.cssText="display: flex; flex-direction: column; gap: 8px; width: 100%;";const N=document.createElement("input");N.className="b3-switch fn__flex-center",N.type="checkbox",N.checked=o.enableWebServeJump,N.addEventListener("change",async()=>{const P=N.checked;F.disabled=!P,ht({enableWebServeJump:P}),await e.saveGlobalSettings({enableWebServeJump:P})});const F=document.createElement("input");F.className="b3-text-field fn__flex-1",F.value=o.webServeUrl,F.placeholder="http://127.0.0.1:6806",F.disabled=!o.enableWebServeJump,F.addEventListener("change",async()=>{const P=F.value.trim()||go.webServeUrl;ht({webServeUrl:P}),await e.saveGlobalSettings({webServeUrl:P})}),T.appendChild(r("启用网络伺服链接外跳",N,"开启后，幻灯片中的思源块引用链接可以点击以外部网络伺服抽屉呈现")),T.appendChild(r("伺服主机地址",F)),t.addItem({title:"网络伺服与文档外跳",direction:"column",description:"配置思源笔记桌面端 WebServe 伺服地址及幻灯片交互行为",actionElement:T});const H=document.createElement("div");H.style.cssText="display: flex; flex-direction: column; gap: 8px; width: 100%;";const U=document.createElement("input");U.className="b3-switch fn__flex-center",U.type="checkbox",U.checked=o.normalizeHeadingSizes,U.addEventListener("change",async()=>{const P=U.checked;ht({normalizeHeadingSizes:P}),await e.saveGlobalSettings({normalizeHeadingSizes:P})});const E=document.createElement("input");E.className="b3-switch fn__flex-center",E.type="checkbox",E.checked=o.showUnorderedListMarkers,E.addEventListener("change",async()=>{const P=E.checked;ht({showUnorderedListMarkers:P}),await e.saveGlobalSettings({showUnorderedListMarkers:P})});const D=document.createElement("input");D.className="b3-switch fn__flex-center",D.type="checkbox",D.checked=o.showOrderedListMarkers,D.addEventListener("change",async()=>{const P=D.checked;ht({showOrderedListMarkers:P}),await e.saveGlobalSettings({showOrderedListMarkers:P})}),H.appendChild(r("固定特定标题大小",U,"开启后限制正文大标题在幻灯片中不超出安全展示画幅")),H.appendChild(r("无序列表圆点前缀标记",E)),H.appendChild(r("有序列表数字序号标记",D)),t.addItem({title:"排版与标记",direction:"column",description:"全局幻灯片文字大小保护与列表视觉前缀配置",actionElement:H});async function S(P){const j=zo().aiConfig,I=bi({...j,...P});ht({aiConfig:I}),await e.saveGlobalSettings({aiConfig:I}),window.siyuanApiSwitch&&window.siyuanApiSwitch.updateLocalConfig(e.name,{provider:"custom",baseUrl:I.baseUrl,apiKey:I.apiKey,model:I.model,requestTimeoutSeconds:I.requestTimeoutSeconds,temperature:I.temperature,maxTokens:I.maxTokens})}return t.updateManagedConfig=P=>{i=P,l(P);const j=!!P,I=zo().aiConfig;a.disabled=j,u.disabled=j,d.disabled=j,y.disabled=j,x.disabled=j,k.disabled=j,a.value=P?P.baseUrl:I.baseUrl,u.value=P?P.apiKey:I.apiKey,d.value=P?P.model:I.model,y.value=String((P==null?void 0:P.requestTimeoutSeconds)??I.requestTimeoutSeconds),x.value=String((P==null?void 0:P.temperature)??I.temperature),k.value=String((P==null?void 0:P.maxTokens)??I.maxTokens),A.textContent=""},t}const B2=150,D2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,L2="slides-dock",Is="slides-preview-tab",Ol="slides-presenter-tab",Nl=ih;class O2 extends re.Plugin{constructor(){super(...arguments);Ie(this,"isMobile",!1);Ie(this,"currentDocId","");Ie(this,"previewTab",null);Ie(this,"latestCompiledDoc",null);Ie(this,"setting",null);Ie(this,"debounceTimer",null);Ie(this,"activeCursorBlockId","");Ie(this,"cancelledCursorBlockId","");Ie(this,"compileScheduler",new M2);Ie(this,"dirtyDocId",null);Ie(this,"inspectorSyncThrottle",new T2);Ie(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Ie(this,"onWsMainBound",this.onWsMain.bind(this));Ie(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Ie(this,"onEditorClickBound",this.onEditorClick.bind(this));Ie(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Ie(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Ie(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const o=re.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.initApiSwitchSync(),this.addIcons(D2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),_2(this);const i=this;if(this.addTab({type:Is,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,y2(s.element,i);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!i.getActiveDocumentId()&&i.compileCurrentDocument(l,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),Mc(this.element)}}),this.addTab({type:Ol,init(n){v2((this||n).element,i)},destroy(){Ec(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:L2,init(){w2(this.element,i)},destroy(){Bc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(Nl),i=lh(o);return ht(i),i}catch{return ht(go),go}}async saveGlobalSettings(o){const i=zo(),n=ht({...i,...o||{}});try{await this.saveData(Nl,n)}catch(l){console.error("保存即现全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}openSetting(){this.setting=E2(this)}initApiSwitchSync(){const o=s=>{if(nh(s),this.setting){const l=this.setting.updateManagedConfig;typeof l=="function"&&l(s)}},i=()=>{const s=zo().aiConfig;return{provider:"custom",baseUrl:s.baseUrl,apiKey:s.apiKey,model:s.model,requestTimeoutSeconds:s.requestTimeoutSeconds,temperature:s.temperature,maxTokens:s.maxTokens}},n=()=>{window.siyuanApiSwitch&&window.siyuanApiSwitch.register(this.name,this.displayName||"即现演示 (SiYuan Live Slides)",o,i())};window.siyuanApiSwitch?n():window.addEventListener("siyuan-api-switch:ready",()=>{n()},{once:!0})}onunload(){window.siyuanApiSwitch&&window.siyuanApiSwitch.unregister(this.name),this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,Cn.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),$i.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await re.openTab({app:this.app,custom:{id:this.name+Is,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){Do("presenterMode")||(b2()||await this.openBottomPreviewTab(),await re.openTab({app:this.app,custom:{id:this.name+Ol,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=re.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),l=await re.openTab({app:this.app,custom:{id:this.name+Is,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||l}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),re.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var l,r,a,c,u;const i=(l=o.detail)==null?void 0:l.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(a=i==null?void 0:i.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const h=await Xs(n).catch(()=>({}));ri({id:n,rootId:n,type:"doc",attrs:h}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,l;const i=o==null?void 0:o.detail;if(!i)return;const n=(l=(s=i.protyle)==null?void 0:s.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return uc(o)}async fetchDocumentTitle(o){return fc(this,o)}async updatePreviewTabHeader(o,i){return Cg(this,o,i)}getActiveDocumentId(){return Mo.getActiveDocumentId()}resolveDocIdFromElement(o){return Mo.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await Mo.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&(Mo.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=B2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=Cn.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,f2);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Mo.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){var h,m;const i=o.target;if(!i)return;const n=((h=i.closest)==null?void 0:h.call(i,".protyle"))||((m=i.closest)==null?void 0:m.call(i,".protyle-wysiwyg"));if(Cl(n))return;const s=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!s){const d=this.resolveDocIdFromElement(i);if(d&&this.activeCursorBlockId!==d){const b=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=b==null?void 0:b.querySelector(".protyle-title__input"),p=((g==null?void 0:g.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,p)}return}if(!i.closest(".protyle-wysiwyg"))return;const a=i.closest("[data-node-id]");if(!a)return;const c=a.getAttribute("data-node-id"),u=a.getAttribute("data-type")||"";c&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId&&(this.activeCursorBlockId=c,Zs(c)),this.syncInspectorBlock(a,c,u))}onSelectionChange(){var h,m;if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=((h=n.closest)==null?void 0:h.call(n,".protyle"))||((m=n.closest)==null?void 0:m.call(n,".protyle-wysiwyg"));if(Cl(s))return;const l=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!l){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const b=l||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=b==null?void 0:b.querySelector(".protyle-title__input"),p=((g==null?void 0:g.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,p)}return}if(!n.closest(".protyle-wysiwyg"))return;const a=n.closest("[data-node-id]"),c=a==null?void 0:a.getAttribute("data-node-id"),u=(a==null?void 0:a.getAttribute("data-type"))||"";if(a&&c){if(Mo.isLocatingLocked(c))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId){if(c===this.cancelledCursorBlockId)return;this.activeCursorBlockId=c,Zs(c)}this.syncInspectorBlock(a,c,u)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await Mo.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&Cn.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,x2(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),a=r.length>0?r[0]:this.compileScheduler.finish();a&&this.markCompileDirty(a);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){Mo.purgeStaleDomSlidesAttrs(o)}}module.exports=O2;
