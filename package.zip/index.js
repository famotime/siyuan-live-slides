"use strict";var xa=Object.create;var To=Object.defineProperty;var _a=Object.getOwnPropertyDescriptor;var Sa=Object.getOwnPropertyNames;var Ca=Object.getPrototypeOf,$a=Object.prototype.hasOwnProperty;var Ia=(t,i,e)=>i in t?To(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var Aa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of Sa(i))!$a.call(t,o)&&o!==e&&To(t,o,{get:()=>i[o],enumerable:!(n=_a(i,o))||n.enumerable});return t};var Rn=(t,i,e)=>(e=t!=null?xa(Ca(t)):{},Aa(i||!t||!t.__esModule?To(e,"default",{value:t,enumerable:!0}):e,t));var kt=(t,i,e)=>Ia(t,typeof i!="symbol"?i+"":i,e);const mt=require("siyuan");async function pe(t,i){const e=await mt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function Ta(){return pe("/api/notebook/lsNotebooks","")}async function Ea(t,i,e){return pe("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function Ir(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return pe("/api/asset/upload",e)}async function rn(t,i,e,n,o){return pe("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Ar(t,i,e){return pe("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function zs(t,i,e){return pe("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Ba(t){return pe("/api/block/deleteBlock",{id:t})}async function Ma(t){return pe("/api/block/getBlockKramdown",{id:t})}async function Xn(t){return pe("/api/block/getChildBlocks",{id:t})}async function Ot(t,i){return pe("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ze(t){return pe("/api/attr/getBlockAttrs",{id:t})}async function gn(t){return pe("/api/query/sql",{stmt:t})}async function Wo(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),pe("/api/file/putFile",n)}async function Tr(t){const i="/api/ai/chatGPT";try{const e=await pe(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function Da(){return pe("/api/storage/getInlineStyles","")}const Er=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function La(t){const i=[];if(!t)return i;const e=new RegExp(Er.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function Pa(t,i){if(!t)return"";const e=new RegExp(Er.source,"g");return t.replace(e,(n,o,r,l,s)=>{const a=(r??l??s??"").trim();if(i&&i[o]){const d=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const vn="custom-slidev-theme",bn="custom-slidev-aspect-ratio",Br="custom-slidev-highlighter",yn="custom-slidev-default-transition",Mr="custom-slidev-color-schema",Vo="custom-slidev-spacing",$i="custom-slidev-slide",ut="custom-slidev-layout",Zt="custom-slidev-transition",Nt="custom-slidev-background",Ae="custom-slidev-image",Fi="custom-slidev-notes",ji="custom-slidev-class",cn="custom-slidev-spacing",Xt="custom-slidev-layout-ratio",_e="custom-slidev-click",Ue="custom-slidev-motion",Li="custom-slidev-shiki-lines",Tt="custom-slidev-slot",ee="custom-slidev-note",Ht="custom-slidev-role",kn="custom-slidev-max-height",Ii="custom-slidev-autoplay",Qn="custom-slidev-loop",Ni="custom-slidev-muted",to="custom-slidev-controls",Dr="background",eo="image-left",io="image-right";function Oa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Ra(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}function za(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Na(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function xe(t,i){if(!za(t))return t;const e=Na(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Fa(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,r)=>{const l=xe(r,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,r,l)=>{const s=xe(r,i);return`${o}${s}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,r,l)=>{const s=xe(r,i);return`${o}${s}${l}`}),e}const ki={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function ja(t){var i,e,n,o,r,l;return t?{theme:((i=t[vn])==null?void 0:i.trim())||ki.theme,aspectRatio:((e=t[bn])==null?void 0:e.trim())||ki.aspectRatio,highlighter:((n=t[Br])==null?void 0:n.trim())||ki.highlighter,defaultTransition:((o=t[yn])==null?void 0:o.trim())||ki.defaultTransition,colorSchema:((r=t[Mr])==null?void 0:r.trim())||ki.colorSchema,spacing:((l=t[Vo])==null?void 0:l.trim())||ki.spacing}:{...ki}}function no(t){var e,n,o,r,l;const i=(e=t.ial)==null?void 0:e[$i];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Ns(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ut]&&(i.layout=t[ut].trim()),t[Zt]&&(i.transition=t[Zt].trim()),t[Nt]&&(i.background=t[Nt].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[ji]&&(i.class=t[ji].trim()),t[cn]&&(i.spacing=t[cn].trim()),t[Xt]&&(i.layoutRatio=t[Xt].trim()),t[Fi]&&(e=t[Fi].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![ut,Xt,Zt,Nt,Ae,ji,cn,Fi,$i].includes(n)){const r=n.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(o)}catch{i[r]=o}}return{frontmatter:i,notes:e}}function Ha(t){const i={};if(!t)return i;const e=t[ee]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[Ht]??t["slidev-role"],o=t[Nt]??t["slidev-background"];(n===Dr||o==="true"||o==="1")&&(i.isBackground=!0);const r=t[ut]??t["slidev-layout"];r===eo||r===io?i.imageLayout=r:(n===eo||n===io)&&(i.imageLayout=n);const l=t[_e]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ue])try{const s=JSON.parse(t[Ue]);typeof s=="object"&&s!==null?i.motion={preset:s.preset||s.type||"fade-in",...s}:i.motion={preset:String(s).trim()}}catch{i.motion={preset:t[Ue].trim()}}return t[Li]&&(i.shikiLines=t[Li].trim()),t[kn]&&(i.maxHeight=t[kn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function hi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function Ko(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,r=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return r;const s=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){s.push("");continue}const d=c.match(/^(\s*)/),u=d?d[1].length:0;u>=l?s.push(c.slice(l)):u>o?s.push(c.slice(u)):s.push(c)}return s.join(`
`)}function Gi(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function zn(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(r=>parseFloat(r.trim())).filter(r=>!isNaN(r)&&r>0);if(o.length>=2)return o.map(r=>`${r}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function Ai(t){if(!t)return[];if(se(t)&&mi(t)&&!gi(t)){const n=ho(t),o=[];for(const r of n)o.push(...Ai(r));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Gi);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&r.push(l);if(r.length>=2){const l=[];for(let s=0;s<r.length;s++){const a=r[s],c=s+1<r.length?r[s+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${s+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Gi(t)?[t]:[]}function Lr(t){var n;if(!t||!se(t)||!mi(t)||gi(t))return null;const i=ho(t);if(i.length===0)return null;if(i.length===1&&se(i[0])&&mi(i[0])){const o=Lr(i[0]);return o?{items:o.items,nestedSuperBlocks:[i[0],...o.nestedSuperBlocks]}:null}const e=[];for(const o of i)if(se(o)){e.push(o);const r=((n=o.children)==null?void 0:n.filter(se))||[];e.push(...r)}if(i.length===3){const o=Ai(i[0]),r=Ai(i[1]),l=Ai(i[2]);if(o.length===1&&r.length===1&&l.length===1)return{items:[o[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const o=Ai(i[0]),r=Ai(i[1]);if(o.length===2&&r.length===1)return{items:[o[0],o[1],r[0]],nestedSuperBlocks:e};if(o.length===1&&r.length===2)return{items:[o[0],r[0],r[1]],nestedSuperBlocks:e};if(o.length===1&&r.length===1)return{items:[o[0],r[0]],nestedSuperBlocks:e}}return null}function Ua(t){if(!t||!se(t)||!mi(t)||gi(t))return null;const i=Lr(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length!==2&&e.length!==3)return null;const o=Pr(t)||void 0;return e.length===2?{superBlockNode:t,nestedSuperBlocks:n,count:2,layout:"two-cols-header",items:e,slots:["left","right"],ratio:o}:{superBlockNode:t,nestedSuperBlocks:n,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"],ratio:o}}function Wa(t){if(!t||!se(t)||!mi(t)||gi(t))return null;const i=ho(t);if(i.length===0)return null;const e=[];for(const n of i){const o=Ai(n);if(o.length===0)return null;e.push(...o)}return e}function Va(t){if(!t||!se(t)||!mi(t)||gi(t))return null;const i=Wa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Ka(t,i,e){var d,u,m,f,k,h;const n=[],o=[],r=(e==null?void 0:e.tracked)||[],l=[];let s={pageTargetId:t,blocks:[]};l.push(s);for(let y=0;y<i.length;y++){const b=i[y];if(no(b)){if(l.length===1&&s.blocks.length===0){s.pageTargetId=b.id,s.blocks.push(b);continue}s={pageTargetId:b.id,blocks:[b]},l.push(s)}else s.blocks.push(b)}function a(y){const b=[];for(const w of y)se(w)&&b.push(w),w.children&&w.children.length>0&&b.push(...a(w.children));return b}function c(y,b,w){const _={blockId:y,attrs:b,previousAttrs:w};n.push(_),e!=null&&e.onTagChange&&e.onTagChange(_)}for(const y of l){const b=y.pageTargetId,w=i.find(C=>C.id===b),_=r.find(C=>C.pageTargetId===b);if(y.blocks.some(C=>{var B,M;return!!(gi(C)||qo(C)&&(((B=C.ial)==null?void 0:B[ut])==="image-left"||((M=C.ial)==null?void 0:M[ut])==="image-right"))})){if(_){const C=_.headerId;if(C){c(C,{[Tt]:""});const B=i.find(M=>M.id===C);B!=null&&B.ial&&(B.ial[Tt]="")}for(const B of _.itemIds){c(B,{[Tt]:""});const M=i.find(O=>O.id===B);M!=null&&M.ial&&(M.ial[Tt]="")}}continue}let x=null,$=-1;for(let C=0;C<y.blocks.length;C++){const B=y.blocks[C],M=se(B)?[B,...a(B.children||[])]:B.children?a(B.children):[];for(const O of M){const Z=Ua(O);if(Z){x=Z,$=C;break}}if(x)break}if(x){const{superBlockNode:C,layout:B,items:M,slots:O}=x,A=y.blocks.slice(0,$).find(H=>Ga(H)),E=A==null?void 0:A.id,g=((d=w==null?void 0:w.ial)==null?void 0:d[ut])||"";g!==B&&(c(b,{[ut]:B},{[ut]:g}),w&&(w.ial||(w.ial={}),w.ial[ut]=B));const F=((u=w==null?void 0:w.ial)==null?void 0:u[Xt])||"",z=x.ratio;if(!F&&z&&(c(b,{[Xt]:z}),w&&(w.ial||(w.ial={}),w.ial[Xt]=z)),A){const H=((m=A.ial)==null?void 0:m[Tt])||"";H!=="header"&&(c(A.id,{[Tt]:"header"},{[Tt]:H}),A.ial||(A.ial={}),A.ial[Tt]="header")}if(_!=null&&_.headerId&&_.headerId!==E){c(_.headerId,{[Tt]:""});const H=i.find(U=>U.id===_.headerId);H&&(H.ial||(H.ial={}),H.ial[Tt]="")}const P=[];for(let H=0;H<M.length;H++){const U=M[H],X=O[H];P.push(U.id);const K=((f=U.ial)==null?void 0:f[Tt])||"";if(K!==X&&(c(U.id,{[Tt]:X},{[Tt]:K}),U.ial||(U.ial={}),U.ial[Tt]=X),U.children&&U.children.length>0)for(const q of U.children)q.ial||(q.ial={}),q.ial[Tt]!==X&&(q.ial[Tt]=X)}if(_!=null&&_.itemIds){for(const H of _.itemIds)if(!P.includes(H)){c(H,{[Tt]:""});const U=i.find(X=>X.id===H);U&&(U.ial||(U.ial={}),U.ial[Tt]="")}}o.push({superBlockId:C.id,nestedSuperBlockIds:(k=x.nestedSuperBlocks)==null?void 0:k.map(H=>H.id),pageTargetId:b,headerId:E,itemIds:P,layout:B})}else{let C=!1;const B=[];for(const Z of y.blocks){const A=se(Z)?[Z,...a(Z.children||[])]:Z.children?a(Z.children):[];for(const E of A){const g=Va(E);if(g){C=!0;for(const F of g.items)B.push(F.id)}}}const M=((h=w==null?void 0:w.ial)==null?void 0:h[ut])||"";if(_||C&&(M==="two-cols-header"||M==="three-cols-header")){c(b,{[ut]:""},{[ut]:M}),w&&(w.ial||(w.ial={}),w.ial[ut]="");const Z=_==null?void 0:_.headerId;if(Z){c(Z,{[Tt]:""});const E=i.find(g=>g.id===Z);E&&(E.ial||(E.ial={}),E.ial[Tt]="")}const A=new Set([...(_==null?void 0:_.itemIds)||[],...B]);for(const E of A){c(E,{[Tt]:""});const g=i.find(F=>F.id===E);g&&(g.ial||(g.ial={}),g.ial[Tt]="")}}}}return{changes:n,newTracked:o}}function se(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function mi(t){if(!se(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function qo(t){return!t||Gi(t)||se(t)||!hi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Pr(t){var m;if(!t||!se(t)||!mi(t))return null;const i=ho(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const f of i){const k=(((m=f.ial)==null?void 0:m.style)||f.style||"").trim();let h=null;if(k){const y=k.match(/calc\(\s*([\d.]+)%/i);if(y)h=parseFloat(y[1]);else{const b=k.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);b&&(h=parseFloat(b[1]))}}h!==null&&!isNaN(h)&&h>0?(e.push(h),n=!0):e.push(null)}if(!n)return null;const o=i.length,r=e.reduce((f,k)=>f+(k||0),0),l=e.filter(f=>f===null).length,s=Math.max(0,100-r),a=l>0?s/l:100/o,c=e.map(f=>f!==null?f:a),d=c.reduce((f,k)=>f+k,0);if(d<=0)return null;const u=c.map(f=>f/d*100);if(u.length===2){const[f]=u;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const k=Math.round(f),h=100-k;return`${k}:${h}`}if(u.length===3){const[f,k,h]=u;if(f>=31&&f<=35&&k>=31&&k<=35&&h>=31&&h<=35)return"1:1:1";if(f>=23&&f<=27&&k>=48&&k<=52&&h>=23&&h<=27)return"1:2:1";if(f>=48&&f<=52&&k>=23&&k<=27&&h>=23&&h<=27)return"2:1:1";if(f>=23&&f<=27&&k>=23&&k<=27&&h>=48&&h<=52)return"1:1:2";if(f>=18&&f<=22&&k>=58&&k<=62&&h>=18&&h<=22)return"1:3:1";const y=Math.round(f),b=Math.round(k),w=100-y-b;return`${y}:${b}:${w}`}return u.map(f=>Math.round(f)).join(":")}function gi(t){if(!t||!se(t)||!mi(t))return null;const i=(t.children||[]).filter(r=>{const l=r.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const s=(r.markdown||r.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")});if(i.length<2)return null;const e=qo(i[0]),n=qo(i[i.length-1]),o=Pr(t)||void 0;if(e&&!n){const r=hi(i[0].markdown,i[0].content);if(r)return{imageNode:i[0],imageUrl:r,layout:eo,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const r=hi(i[i.length-1].markdown,i[i.length-1].content);if(r)return{imageNode:i[i.length-1],imageUrl:r,layout:io,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function qa(t,i){const e=[];function n(o){for(const r of o){const l=gi(r);if(l){const{imageNode:s,layout:a,ratio:c}=l;s.ial||(s.ial={});const d=s.ial[ut],u=s.ial[Xt],m=d!==a,f=!u&&!!c;if(m||f){const k={blockId:s.id,layout:a,previousLayout:d,ratio:c||u};s.ial[ut]=a,f&&c&&(s.ial[Xt]=c),e.push(k),i&&i(k)}}r.children&&r.children.length>0&&n(r.children)}}return n(t),e}function ho(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Ga(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function wi(t,i,e){let n="",o=0;const r=/<div\b([^>]*)>/gi;for(;o<t.length;){r.lastIndex=o;let l,s=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const w=b[1];if(typeof i=="string"?w.split(/\s+/).includes(i):i.test(w)){s=!0,a=l.index,c=l[0].length;break}}}if(!s){n+=t.slice(o);break}n+=t.slice(o,a);const d=a+c;let u=1,m=-1,f=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let h;for(;(h=k.exec(t))!==null;)if(h[0].startsWith("</")){if(u--,u===0){m=h.index,f=h.index+h[0].length;break}}else u++;if(m!==-1&&f!==-1){const y=t.slice(d,m);n+=e(y),o=f}else n+=t.slice(a,d),o=d}return n}function Za(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let r,l=!1,s=-1,a=0;for(;(r=o.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,s=r.index,a=r[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,s);const c=s+a;let d=1,u=-1,m=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let k;for(;(k=f.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){u=k.index,m=k.index+k[0].length;break}}else d++;if(u!==-1&&m!==-1){const h=t.slice(s,m),y=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=y,n=m}else e+=t.slice(s,c),n=c}return{text:e,tokens:i}}function Ya(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,s=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(s),a});const{text:o,tokens:r}=Za(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(s,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(s,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=wi(e,"diff-grid",s=>{const a=Array.from(s.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),u=c[3].trim();return`**${d}:**
\`\`\`yaml
${u}
\`\`\``}).join(`

`)+`
`:s}),e=wi(e,"before-after",s=>{const a=s.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=s.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:s}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(s,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=wi(e,"timeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let u="-";return d.includes("warn")?u="- ⚠️":d.includes("bad")?u="- ❌":d.includes("ok")&&(u="- ✅"),`${u} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:s}),e=wi(e,"pipeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const m=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${m}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:s}),e=wi(e,"check-grid",s=>{const a=Array.from(s.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:s}),e=wi(e,"manifesto",s=>{const a=Array.from(s.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:s}),e=wi(e,"split-note",s=>{const a=Array.from(s.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:s}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(s,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(s,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(s,a,c)=>/@|v-|:|class=/i.test(a)?s:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(s,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((u,m)=>Math.max(u,m.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(s,a,c,d,u)=>{const m=u.trim();return m.includes("<")||m.includes(`
`)?s:`[${m}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(s,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let s=0;s<l.length;s++)e=e.replace(`__VUE_COMP_TOKEN_${s}__`,l[s]);for(let s=0;s<r.length;s++)e=e.replace(`__VUE_DIV_TOKEN_${s}__`,r[s]);for(let s=0;s<n.length;s++)e=e.replace(`__SCRIPT_TOKEN_${s}__`,n[s]);for(let s=0;s<i.length;s++)e=e.replace(`__CODE_TOKEN_${s}__`,i[s]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Or(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function Ja(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function Xa(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function Qa(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function tc(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Fs(t,i,e,n){const o=i!=null&&i.trim()!=="",r=tc(e),l=n==null?void 0:n.trim(),s=l!==void 0&&l!=="",a=s?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!r)return s?`<div${a}>

${t}

</div>`:t;if(o&&!r){if(s){const k=i.trim();let h="v-click";return k==="hide"?h="v-click.hide":k!==""&&k!=="+1"&&(h=`v-click="${k}"`),`<div ${h}${a}>

${t}

</div>`}return Qa(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),u=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${u}${a}>

${t}

</div>`;const m=i.trim();let f="v-click";return m==="hide"?f="v-click.hide":m!==""&&m!=="+1"&&(f=`v-click="${m}"`),`<div ${f} ${u}${a}>

${t}

</div>`}function Rr(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function ec(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function zr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const s=Math.ceil(l.length/3),a=Math.ceil((l.length-s)/2);return{col1:l.slice(0,s),col2:l.slice(s,s+a),col3:l.slice(s+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const s=l.slot||"";return s==="col-1"||s==="left"?1:s==="col-2"||s==="center"?2:s==="col-3"||s==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),s=e.includes(3);if(l||s){const d=[],u=[],m=[];let f=1;for(const k of t){const h=i(k);h!==null&&(f=h),f===1?d.push(k):f===2?u.push(k):m.push(k)}return{col1:d,col2:u,col3:m}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const o=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const s=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(s)},r=t.map((l,s)=>o(l)?s:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),s=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+s),col3:t.slice(l+s)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],s=(l.rawMarkdown||l.content||"").trim(),a=s.split(/\r?\n/),c=[];for(let m=0;m<a.length;m++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[m])&&c.push(m);if(c.length>=3){const m=Math.ceil(c.length/3),f=Math.ceil((c.length-m)/2),k=a.slice(c[0],c[m]).join(`
`),h=a.slice(c[m],c[m+f]).join(`
`),y=a.slice(c[m+f]).join(`
`);return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:y,content:y}]}}const d=s.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const m=Math.ceil(d.length/3),f=Math.ceil((d.length-m)/2),k=`<ul>
${d.slice(0,m).join(`
`)}
</ul>`,h=`<ul>
${d.slice(m,m+f).join(`
`)}
</ul>`,y=`<ul>
${d.slice(m+f).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:y,content:y}]}}const u=s.split(/\r?\n\s*\r?\n/).filter(m=>m.trim()!=="");if(u.length>=3){const m=Math.ceil(u.length/3),f=Math.ceil((u.length-m)/2);return{col1:[{...l,rawMarkdown:u.slice(0,m).join(`

`),content:u.slice(0,m).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:u.slice(m,m+f).join(`

`),content:u.slice(m,m+f).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:u.slice(m+f).join(`

`),content:u.slice(m+f).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function js(t,i,e,n){var d;const o=ja(i),r=[],l=Ns(i);let s={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};s.frontmatter.background&&(s.frontmatter.background=xe(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=xe(s.frontmatter.image,n)),r.push(s);let a=[];for(const u of e){if(no(u)){a=[];const f=Ns(u.ial);if(r.length===1&&s.blocks.length===0){s.startBlockId=u.id,s.allBlockIds||(s.allBlockIds=[]),s.allBlockIds.includes(u.id)||s.allBlockIds.push(u.id),f.frontmatter.layout&&(s.frontmatter.layout=f.frontmatter.layout),Object.assign(s.frontmatter,f.frontmatter),!f.frontmatter.image&&l.frontmatter.image&&(s.frontmatter.image=l.frontmatter.image),!f.frontmatter.background&&l.frontmatter.background&&(s.frontmatter.background=l.frontmatter.background),s.frontmatter.background&&(s.frontmatter.background=xe(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=xe(s.frontmatter.image,n));continue}s={pageIndex:r.length+1,startBlockId:u.id,frontmatter:{layout:f.frontmatter.layout||"default",...f.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[u.id]},s.frontmatter.background&&(s.frontmatter.background=xe(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=xe(s.frontmatter.image,n)),r.push(s);continue}const m=f=>{var E;if(s.allBlockIds||(s.allBlockIds=[]),f.id&&!s.allBlockIds.includes(f.id)&&s.allBlockIds.push(f.id),f.children&&f.children.length>0){const g=F=>{for(const z of F)z.id&&!s.allBlockIds.includes(z.id)&&s.allBlockIds.push(z.id),z.children&&z.children.length>0&&g(z.children)};g(f.children)}let k=Oa(f),h=f.ial?{...f.ial}:{};const y=k.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(h={...Ra(y[0]),...h},k=k.slice(0,y.index).trim()),f.type!=="c"&&!k.startsWith("```")&&(k=Or(k));let b=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(b)||b==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(b)&&/\r?\n\}\}\}$/.test(b)&&(k=b.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),b=k.trim());const w=Ha(h);if(k=Fa(k,n),k=Pa(k,n==null?void 0:n.refContentMap),f.children&&f.children.length>0){const g=F=>{for(const z of F){if(z.ial)for(const[P,H]of Object.entries(z.ial))P.startsWith("custom-slidev-")&&!h[P]&&(h[P]=H);z.children&&z.children.length>0&&g(z.children)}};g(f.children)}const _=f.type==="video"||f.type==="NodeVideo"||/<video\b/i.test(k);if(_){const g=h["custom-slidev-autoplay"]==="true",F=h["custom-slidev-loop"]==="true",z=h["custom-slidev-muted"]==="true"||g,P=h["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(H,U)=>{let X=U;return P?X=X.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(X)||(X+=" controls"),g&&!/autoplay/i.test(X)?X+=" autoplay playsinline":!g&&h["custom-slidev-autoplay"]==="false"&&(X=X.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),F&&!/loop/i.test(X)?X+=" loop":!F&&h["custom-slidev-loop"]==="false"&&(X=X.replace(/\bloop\b/gi,"").trim()),z&&!/muted/i.test(X)?X+=" muted":!z&&h["custom-slidev-muted"]==="false"&&(X=X.replace(/\bmuted\b/gi,"").trim()),`<video ${X.trim()}>`})}if(w.isBackground){const g=hi(k,f.content);if(g){s.frontmatter.background=xe(g,n);return}}const T=gi(f);if(T){s.frontmatter.layout=T.layout,s.frontmatter.image=xe(T.imageUrl,n),!s.frontmatter.layoutRatio&&T.ratio&&(s.frontmatter.layoutRatio=T.ratio);for(const g of T.contentNodes)m(g);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const g=hi(k,f.content);if(g){s.frontmatter.layout=w.imageLayout,s.frontmatter.image=xe(g,n),!s.frontmatter.layoutRatio&&((E=f.ial)!=null&&E[Xt])&&(s.frontmatter.layoutRatio=f.ial[Xt]);return}}if(se(f)&&f.children&&f.children.length>0){for(const g of f.children)m(g);return}if((f.type==="l"||f.type==="NodeList"||f.type==="list")&&f.children&&f.children.length>0&&(f.children.some(g=>{var F;return(F=g.ial)==null?void 0:F[Tt]})||w.slot)){for(const g of f.children)w.slot&&(!g.ial||!g.ial[Tt])&&(g.ial||(g.ial={}),g.ial[Tt]=w.slot),m(g);return}if(w.isNote){const g=Rr(k);g&&(s.notes?s.notes+=`

`+g:s.notes=g),s.noteBlocks||(s.noteBlocks=[]),s.noteBlocks.push({id:f.id,type:f.type,content:g||f.content||"",rawMarkdown:k,isNote:!0,attributes:f.ial});return}w.shikiLines&&(k=Xa(k,w.shikiLines)),b=k.trim();const x=(f.content||"").trim();if(b==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(b)||b.startsWith("::right::")){s.blocks.push({id:f.id,type:f.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:f.ial});return}const C=ec(f);let B=w.slot,M=w.clicks,O=w.motion,Z={...f.ial||{}};if(C!==null){for(;a.length>0&&a[a.length-1].level>=C;)a.pop();const g=a.length>0?a[a.length-1]:void 0;!B&&(g!=null&&g.slot)&&(B=g.slot),!M&&(g!=null&&g.clicks)&&(M=g.clicks),!O&&(g!=null&&g.motion)&&(O=g.motion);const F={...(g==null?void 0:g.customAttrs)||{}};if(f.ial)for(const[z,P]of Object.entries(f.ial))z.startsWith("custom-slidev-")&&!z.startsWith("custom-slidev-slide")&&(F[z]=P);a.push({level:C,slot:B,clicks:M,motion:O,customAttrs:F})}else{const g=a.length>0?a[a.length-1]:void 0;g&&(!B&&g.slot&&g.slot!=="header"&&(B=g.slot),!M&&g.clicks&&(M=g.clicks),!O&&g.motion&&(O=g.motion),g.customAttrs&&(Z={...g.customAttrs,...Z}))}!B&&s.blocks.some(g=>g.slot==="slot-divider-right")&&(B="right"),B&&(Z[Tt]=B),M&&!Z[_e]&&(Z[_e]=M),O&&!Z[Ue]&&(Z[Ue]=JSON.stringify(O)),(_||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(Z["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(Z["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(Z["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(Z["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(Z["custom-slidev-controls"]=h["custom-slidev-controls"]));const A={id:f.id,type:f.type,content:f.content||"",rawMarkdown:k,clicks:M,motion:O,shikiLines:w.shikiLines,slot:B,attributes:Z};s.blocks.push(A)};m(u)}for(let u=0;u<r.length;u++){const m=r[u],f=[],k={...m.frontmatter};u===0&&(k.theme=o.theme,k.aspectRatio=o.aspectRatio,k.highlighter=o.highlighter,k.transition=m.frontmatter.transition||o.defaultTransition);const h=Ja(k);h&&f.push(h);const y=m.blocks.filter(x=>x.slot!=="slot-divider-right"),b=x=>x.filter($=>!!($.rawMarkdown||$.content||"").trim()).map($=>{var C;return Fs($.rawMarkdown,$.clicks,$.motion,(C=$.attributes)==null?void 0:C.style)}).join(`

`),w=x=>{const $=x.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if($.length===0)return;const C=$[0],B=(C.rawMarkdown||C.content||"").trim();(Gi(C)||/^(?:[-*+]|\d+\.)\s+/.test(B))&&(C.rawMarkdown=Ko(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},_=x=>x.length===0?"":(w(x),b(x)),T=m.frontmatter.layout||"default";if(T==="two-cols-header"){let x=[];const $=y.filter(E=>E.slot==="header");if($.length>0)x=$;else if(y.length>0){const E=y.find(g=>g.type==="h"&&(!g.slot||g.slot==="default"));E&&(x=[E])}const C=y.filter(E=>!x.includes(E)),B=C.filter(E=>E.slot==="right"||E.slot==="col-2"),M=C.filter(E=>!B.includes(E));w(M),w(B);const O=b(x),Z=_(M),A=_(B);O&&f.push(O),Z&&f.push(`::left::

${Z}`),A&&f.push(`::right::

${A}`)}else if(T==="three-cols-header"){let x=[];const $=y.filter(z=>z.slot==="header");if($.length>0)x=$;else if(y.length>0){const z=y.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));z&&(x=[z])}const C=y.filter(z=>!x.includes(z)),B=zr(C),M=B.col1,O=B.col2,Z=B.col3;for(const z of M)z.slot||(z.slot="col-1");for(const z of O)z.slot||(z.slot="col-2");for(const z of Z)z.slot||(z.slot="col-3");if(w(M),w(O),w(Z),C.length===1&&(O.length>0||Z.length>0)){const z=m.blocks.findIndex(P=>P.id===C[0].id);z!==-1&&m.blocks.splice(z,1,...M,...O,...Z)}const A=b(x),E=_(M),g=_(O),F=_(Z);A&&f.push(A),E&&f.push(`::col-1::

${E}`),g&&f.push(`::col-2::

${g}`),F&&f.push(`::col-3::

${F}`)}else if(T==="two-cols"){const x=y.filter(M=>M.slot==="left"),$=y.filter(M=>M.slot==="right");w(x),w($);const C=b(x.length>0?x:y.filter(M=>M.slot!=="right")),B=b($);f.push(C),B&&f.push(`::right::

${B}`)}else for(const x of y)f.push(Fs(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));m.notes&&f.push(`<!--
${m.notes}
-->`),m.rawMarkdown=f.join(`

`).trim()}const c=r.map(u=>u.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:r,fullMarkdown:c}}const Go=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function ic(t){var o,r,l,s,a,c,d,u,m,f,k,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const y of t.styles){if(!y||!y.id)continue;const b=`--b3-inline-style-${y.id}`;(o=y.light)!=null&&o.color&&i.push(`  ${b}-color: ${y.light.color};`),(r=y.light)!=null&&r.backgroundColor&&i.push(`  ${b}-background-color: ${y.light.backgroundColor};`),(l=y.dark)!=null&&l.color&&e.push(`  ${b}-color: ${y.dark.color};`),(s=y.dark)!=null&&s.backgroundColor&&e.push(`  ${b}-background-color: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const y of t.builtin.colors){if(!y||typeof y.index!="number")continue;const b=y.index;(a=y.light)!=null&&a.color&&i.push(`  --b3-font-color${b}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${b}: ${y.light.backgroundColor};`),(d=y.dark)!=null&&d.color&&e.push(`  --b3-font-color${b}: ${y.dark.color};`),(u=y.dark)!=null&&u.backgroundColor&&e.push(`  --b3-font-background${b}: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const y of t.builtin.styles){if(!y||!y.id)continue;const b=y.id;(m=y.light)!=null&&m.color&&i.push(`  --b3-card-${b}-color: ${y.light.color};`),(f=y.light)!=null&&f.backgroundColor&&i.push(`  --b3-card-${b}-background: ${y.light.backgroundColor};`),(k=y.dark)!=null&&k.color&&e.push(`  --b3-card-${b}-color: ${y.dark.color};`),(h=y.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${b}-background: ${y.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function dn(t){const i=ic(t);return i?`${Go}

/* Custom Workspace Inline Styles */
${i}`:Go}function Eo(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}const nc={getBlockAttrs:Ze,getChildBlocks:Xn,setBlockAttrs:Ot,sql:gn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Da};class oc{constructor(i){kt(this,"deps");kt(this,"attrOverrides",new Map);kt(this,"trackedListSuperBlocks",new Map);this.deps={...nc,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[r]:o[r]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],s=new Map;if(Array.isArray(l))for(const _ of l)_.id&&_.ial&&s.set(_.id,Eo(_.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const _ of c)if(_.block_id&&_.name){let T=s.get(_.block_id);T||(T={},s.set(_.block_id,T)),T[_.name]=_.value||""}}if(!o||o.length===0){const _=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(_).catch(()=>[])||[]}const d=(o||[]).map(_=>{const T=s.get(_.id)||(_.ial?Eo(_.ial):{}),x=this.attrOverrides.get(_.id);return x&&Object.assign(T,x),{id:_.id,parent_id:_.parent_id,root_id:_.root_id||i,type:_.type,subType:_.subType,content:_.content||"",markdown:_.markdown||"",ial:T,children:_.children}}),u=async(_,T=0)=>{if(!(!_||_.length===0||T>8))for(const x of _){if((se(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let C=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!C||C.length===0){const B=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;C=await this.deps.sql(B).catch(()=>[])||[]}Array.isArray(C)&&C.length>0&&(x.children=C.map(B=>{const M=s.get(B.id)||(B.ial?Eo(B.ial):{}),O=this.attrOverrides.get(B.id);return O&&Object.assign(M,O),{id:B.id,parent_id:B.parent_id||x.id,root_id:B.root_id||i,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await u(x.children,T+1)}};await u(d);const m=_=>{var T,x;for(const $ of _)if($.children&&$.children.length>0){m($.children);for(const C of $.children)if(C.ial)for(const[B,M]of Object.entries(C.ial))B.startsWith("custom-slidev-")&&!((T=$.ial)!=null&&T[B])&&($.ial||($.ial={}),$.ial[B]=M);if($.ial){for(const[C,B]of Object.entries($.ial))if(C.startsWith("custom-slidev-"))for(const M of $.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[C])&&(M.ial||(M.ial={}),M.ial[C]=B)}}};m(d),qa(d,_=>{const T={[ut]:_.layout};_.ratio&&(T[Xt]=_.ratio),this.setBlockAttrOverride(_.blockId,T),(this.deps.setBlockAttrs||Ot)(_.blockId,T).catch($=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",$)})});const f=this.trackedListSuperBlocks.get(i)||[],k=Ka(i,d,{tracked:f,onTagChange:_=>{this.setBlockAttrOverride(_.blockId,_.attrs),_.blockId===i&&Object.assign(e,_.attrs);const T=$=>{for(const C of $)C.id===_.blockId&&(C.ial||(C.ial={}),Object.assign(C.ial,_.attrs)),C.children&&C.children.length>0&&T(C.children)};T(d),(this.deps.setBlockAttrs||Ot)(_.blockId,_.attrs).catch($=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",$)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const h=new Set;for(const _ of d){const T=_.markdown||_.content||"";if(T.includes("((")){const x=La(T);for(const $ of x)h.add($.blockId)}}const y={};if(h.size>0){const _=Array.from(h).map(x=>`'${x}'`).join(","),T=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${_})`).catch(()=>[])||[];if(Array.isArray(T))for(const x of T)x.id&&(y[x.id]=x.markdown||x.content||"")}const b=this.deps.getBaseUrl?this.deps.getBaseUrl():"",w=js(i,e,d,{baseUrl:b,refContentMap:y});try{const _=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;w.customThemeCss=dn(_)}catch{w.customThemeCss=dn(null)}return w}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=js(i,{},[],{});return n.customThemeCss=dn(null),n}}}const Rt=new oc;class cs{constructor(i){kt(this,"devServerUrl","http://localhost:3030");kt(this,"isConnected",!1);kt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),r=i.slides.map((l,s)=>{const a=l.frontmatter||{},c=[],d=s===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let u="";c.length>0?u=d?"":`---
${c.join(`
`)}
---

`:d||(u=`---

`);let m="";if(a.layout==="two-cols"){const k=l.blocks.filter(w=>w.slot!=="right"),h=l.blocks.filter(w=>w.slot==="right"),y=k.map(w=>w.rawMarkdown||w.content||"").join(`

`),b=h.map(w=>w.rawMarkdown||w.content||"").join(`

`);m=`${y}

::right::

${b}`}else m=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let f="";return l.notes&&l.notes.trim()&&(f=`

<!--
${l.notes.trim()}
-->`),`${u}${m}${f}`}).join(`

`);return`${o}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const r=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(o),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function ds(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Ft={},Hi=[],We=()=>{},Nr=()=>!1,mo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),go=t=>t.startsWith("onUpdate:"),le=Object.assign,us=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},sc=Object.prototype.hasOwnProperty,Lt=(t,i)=>sc.call(t,i),Ct=Array.isArray,Ui=t=>An(t)==="[object Map]",Qi=t=>An(t)==="[object Set]",Hs=t=>An(t)==="[object Date]",It=t=>typeof t=="function",Yt=t=>typeof t=="string",Me=t=>typeof t=="symbol",zt=t=>t!==null&&typeof t=="object",Fr=t=>(zt(t)||It(t))&&It(t.then)&&It(t.catch),jr=Object.prototype.toString,An=t=>jr.call(t),rc=t=>An(t).slice(8,-1),Hr=t=>An(t)==="[object Object]",fs=t=>Yt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,un=ds(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),vo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},lc=/-\w/g,fe=vo(t=>t.replace(lc,i=>i.slice(1).toUpperCase())),ac=/\B([A-Z])/g,vi=vo(t=>t.replace(ac,"-$1").toLowerCase()),bo=vo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Bo=vo(t=>t?`on${bo(t)}`:""),je=(t,i)=>!Object.is(t,i),Kn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Ur=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},yo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Us;const ko=()=>Us||(Us=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function ps(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=Yt(n)?fc(n):ps(n);if(o)for(const r in o)i[r]=o[r]}return i}else if(Yt(t)||zt(t))return t}const cc=/;(?![^(]*\))/g,dc=/:([^]+)/,uc=/\/\*[^]*?\*\//g;function fc(t){const i={};return t.replace(uc,"").split(cc).forEach(e=>{if(e){const n=e.split(dc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function $t(t){let i="";if(Yt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=$t(t[e]);n&&(i+=n+" ")}else if(zt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const pc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",hc=ds(pc);function Wr(t){return!!t||t===""}function mc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=tn(t[n],i[n]);return e}function tn(t,i){if(t===i)return!0;let e=Hs(t),n=Hs(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Me(t),n=Me(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?mc(t,i):!1;if(e=zt(t),n=zt(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,r=Object.keys(i).length;if(o!==r)return!1;for(const l in t){const s=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(s&&!a||!s&&a||!tn(t[l],i[l]))return!1}}return String(t)===String(i)}function hs(t,i){return t.findIndex(e=>tn(e,i))}const Vr=t=>!!(t&&t.__v_isRef===!0),St=t=>Yt(t)?t:t==null?"":Ct(t)||zt(t)&&(t.toString===jr||!It(t.toString))?Vr(t)?St(t.value):JSON.stringify(t,Kr,2):String(t),Kr=(t,i)=>Vr(i)?Kr(t,i.value):Ui(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],r)=>(e[Mo(n,r)+" =>"]=o,e),{})}:Qi(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>Mo(e))}:Me(i)?Mo(i):zt(i)&&!Ct(i)&&!Hr(i)?String(i):i,Mo=(t,i="")=>{var e;return Me(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ie;class gc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ie&&(ie.active?(this.parent=ie,this.index=(ie.scopes||(ie.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=ie;try{return ie=this,i()}finally{ie=e}}}on(){++this._on===1&&(this.prevScope=ie,ie=this)}off(){if(this._on>0&&--this._on===0){if(ie===this)ie=this.prevScope;else{let i=ie;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function vc(){return ie}let jt;const Do=new WeakSet;class qr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ie&&(ie.active?ie.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Do.has(this)&&(Do.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Zr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Ws(this),Yr(this);const i=jt,e=Be;jt=this,Be=!0;try{return this.fn()}finally{Jr(this),jt=i,Be=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)vs(i);this.deps=this.depsTail=void 0,Ws(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Do.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Zo(this)&&this.run()}get dirty(){return Zo(this)}}let Gr=0,fn,pn;function Zr(t,i=!1){if(t.flags|=8,i){t.next=pn,pn=t;return}t.next=fn,fn=t}function ms(){Gr++}function gs(){if(--Gr>0)return;if(pn){let i=pn;for(pn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;fn;){let i=fn;for(fn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function Yr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Jr(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),vs(n),bc(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function Zo(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Xr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function Xr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===wn)||(t.globalVersion=wn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Zo(t))))return;t.flags|=2;const i=t.dep,e=jt,n=Be;jt=t,Be=!0;try{Yr(t);const o=t.fn(t._value);(i.version===0||je(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{jt=e,Be=n,Jr(t),t.flags&=-3}}function vs(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)vs(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function bc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Be=!0;const Qr=[];function ni(){Qr.push(Be),Be=!1}function oi(){const t=Qr.pop();Be=t===void 0?!0:t}function Ws(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=jt;jt=void 0;try{i()}finally{jt=e}}}let wn=0;class yc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class bs{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!jt||!Be||jt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==jt)e=this.activeLink=new yc(jt,this),jt.deps?(e.prevDep=jt.depsTail,jt.depsTail.nextDep=e,jt.depsTail=e):jt.deps=jt.depsTail=e,tl(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=jt.depsTail,e.nextDep=void 0,jt.depsTail.nextDep=e,jt.depsTail=e,jt.deps===e&&(jt.deps=n)}return e}trigger(i){this.version++,wn++,this.notify(i)}notify(i){ms();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{gs()}}}function tl(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)tl(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Yo=new WeakMap,Ei=Symbol(""),Jo=Symbol(""),xn=Symbol("");function ae(t,i,e){if(Be&&jt){let n=Yo.get(t);n||Yo.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new bs),o.map=n,o.key=e),o.track()}}function Xe(t,i,e,n,o,r){const l=Yo.get(t);if(!l){wn++;return}const s=a=>{a&&a.trigger()};if(ms(),i==="clear")l.forEach(s);else{const a=Ct(t),c=a&&fs(e);if(a&&e==="length"){const d=Number(n);l.forEach((u,m)=>{(m==="length"||m===xn||!Me(m)&&m>=d)&&s(u)})}else switch((e!==void 0||l.has(void 0))&&s(l.get(e)),c&&s(l.get(xn)),i){case"add":a?c&&s(l.get("length")):(s(l.get(Ei)),Ui(t)&&s(l.get(Jo)));break;case"delete":a||(s(l.get(Ei)),Ui(t)&&s(l.get(Jo)));break;case"set":Ui(t)&&s(l.get(Ei));break}}gs()}function Ri(t){const i=Dt(t);return i===t?i:(ae(i,"iterate",xn),Se(t)?i:i.map(De))}function wo(t){return ae(t=Dt(t),"iterate",xn),t}function Ne(t,i){return si(t)?Zi(Bi(t)?De(i):i):De(i)}const kc={__proto__:null,[Symbol.iterator](){return Lo(this,Symbol.iterator,t=>Ne(this,t))},concat(...t){return Ri(this).concat(...t.map(i=>Ct(i)?Ri(i):i))},entries(){return Lo(this,"entries",t=>(t[1]=Ne(this,t[1]),t))},every(t,i){return Ge(this,"every",t,i,void 0,arguments)},filter(t,i){return Ge(this,"filter",t,i,e=>e.map(n=>Ne(this,n)),arguments)},find(t,i){return Ge(this,"find",t,i,e=>Ne(this,e),arguments)},findIndex(t,i){return Ge(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ge(this,"findLast",t,i,e=>Ne(this,e),arguments)},findLastIndex(t,i){return Ge(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ge(this,"forEach",t,i,void 0,arguments)},includes(...t){return Po(this,"includes",t)},indexOf(...t){return Po(this,"indexOf",t)},join(t){return Ri(this).join(t)},lastIndexOf(...t){return Po(this,"lastIndexOf",t)},map(t,i){return Ge(this,"map",t,i,void 0,arguments)},pop(){return nn(this,"pop")},push(...t){return nn(this,"push",t)},reduce(t,...i){return Vs(this,"reduce",t,i)},reduceRight(t,...i){return Vs(this,"reduceRight",t,i)},shift(){return nn(this,"shift")},some(t,i){return Ge(this,"some",t,i,void 0,arguments)},splice(...t){return nn(this,"splice",t)},toReversed(){return Ri(this).toReversed()},toSorted(t){return Ri(this).toSorted(t)},toSpliced(...t){return Ri(this).toSpliced(...t)},unshift(...t){return nn(this,"unshift",t)},values(){return Lo(this,"values",t=>Ne(this,t))}};function Lo(t,i,e){const n=wo(t),o=n[i]();return n!==t&&!Se(t)&&(o._next=o.next,o.next=()=>{const r=o._next();return r.done||(r.value=e(r.value)),r}),o}const wc=Array.prototype;function Ge(t,i,e,n,o,r){const l=wo(t),s=l!==t&&!Se(t),a=l[i];if(a!==wc[i]){const u=a.apply(t,r);return s?De(u):u}let c=e;l!==t&&(s?c=function(u,m){return e.call(this,Ne(t,u),m,t)}:e.length>2&&(c=function(u,m){return e.call(this,u,m,t)}));const d=a.call(l,c,n);return s&&o?o(d):d}function Vs(t,i,e,n){const o=wo(t),r=o!==t&&!Se(t);let l=e,s=!1;o!==t&&(r?(s=n.length===0,l=function(c,d,u){return s&&(s=!1,c=Ne(t,c)),e.call(this,c,Ne(t,d),u,t)}):e.length>3&&(l=function(c,d,u){return e.call(this,c,d,u,t)}));const a=o[i](l,...n);return s?Ne(t,a):a}function Po(t,i,e){const n=Dt(t);ae(n,"iterate",xn);const o=n[i](...e);return(o===-1||o===!1)&&ws(e[0])?(e[0]=Dt(e[0]),n[i](...e)):o}function nn(t,i,e=[]){ni(),ms();const n=Dt(t)[i].apply(t,e);return gs(),oi(),n}const xc=ds("__proto__,__v_isRef,__isVue"),el=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Me));function _c(t){Me(t)||(t=String(t));const i=Dt(this);return ae(i,"has",t),i.hasOwnProperty(t)}class il{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return r;if(e==="__v_raw")return n===(o?r?Dc:rl:r?sl:ol).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!o){let a;if(l&&(a=kc[e]))return a;if(e==="hasOwnProperty")return _c}const s=Reflect.get(i,e,qt(i)?i:n);if((Me(e)?el.has(e):xc(e))||(o||ae(i,"get",e),r))return s;if(qt(s)){const a=l&&fs(e)?s:s.value;return o&&zt(a)?Qo(a):a}return zt(s)?o?Qo(s):xo(s):s}}class nl extends il{constructor(i=!1){super(!1,i)}set(i,e,n,o){let r=i[e];const l=Ct(i)&&fs(e);if(!this._isShallow){const c=si(r);if(!Se(n)&&!si(n)&&(r=Dt(r),n=Dt(n)),!l&&qt(r)&&!qt(n))return c||(r.value=n),!0}const s=l?Number(e)<i.length:Lt(i,e),a=Reflect.set(i,e,n,qt(i)?i:o);return i===Dt(o)&&a&&(s?je(n,r)&&Xe(i,"set",e,n):Xe(i,"add",e,n)),a}deleteProperty(i,e){const n=Lt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Xe(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Me(e)||!el.has(e))&&ae(i,"has",e),n}ownKeys(i){return ae(i,"iterate",Ct(i)?"length":Ei),Reflect.ownKeys(i)}}class Sc extends il{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Cc=new nl,$c=new Sc,Ic=new nl(!0);const Xo=t=>t,Nn=t=>Reflect.getPrototypeOf(t);function Ac(t,i,e){return function(...n){const o=this.__v_raw,r=Dt(o),l=Ui(r),s=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),d=e?Xo:i?Zi:De;return!i&&ae(r,"iterate",a?Jo:Ei),le(Object.create(c),{next(){const{value:u,done:m}=c.next();return m?{value:u,done:m}:{value:s?[d(u[0]),d(u[1])]:d(u),done:m}}})}}function Fn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Tc(t,i){const e={get(o){const r=this.__v_raw,l=Dt(r),s=Dt(o);t||(je(o,s)&&ae(l,"get",o),ae(l,"get",s));const{has:a}=Nn(l),c=i?Xo:t?Zi:De;if(a.call(l,o))return c(r.get(o));if(a.call(l,s))return c(r.get(s));r!==l&&r.get(o)},get size(){const o=this.__v_raw;return!t&&ae(Dt(o),"iterate",Ei),o.size},has(o){const r=this.__v_raw,l=Dt(r),s=Dt(o);return t||(je(o,s)&&ae(l,"has",o),ae(l,"has",s)),o===s?r.has(o):r.has(o)||r.has(s)},forEach(o,r){const l=this,s=l.__v_raw,a=Dt(s),c=i?Xo:t?Zi:De;return!t&&ae(a,"iterate",Ei),s.forEach((d,u)=>o.call(r,c(d),c(u),l))}};return le(e,t?{add:Fn("add"),set:Fn("set"),delete:Fn("delete"),clear:Fn("clear")}:{add(o){const r=Dt(this),l=Nn(r),s=Dt(o),a=!i&&!Se(o)&&!si(o)?s:o;return l.has.call(r,a)||je(o,a)&&l.has.call(r,o)||je(s,a)&&l.has.call(r,s)||(r.add(a),Xe(r,"add",a,a)),this},set(o,r){!i&&!Se(r)&&!si(r)&&(r=Dt(r));const l=Dt(this),{has:s,get:a}=Nn(l);let c=s.call(l,o);c||(o=Dt(o),c=s.call(l,o));const d=a.call(l,o);return l.set(o,r),c?je(r,d)&&Xe(l,"set",o,r):Xe(l,"add",o,r),this},delete(o){const r=Dt(this),{has:l,get:s}=Nn(r);let a=l.call(r,o);a||(o=Dt(o),a=l.call(r,o)),s&&s.call(r,o);const c=r.delete(o);return a&&Xe(r,"delete",o,void 0),c},clear(){const o=Dt(this),r=o.size!==0,l=o.clear();return r&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=Ac(o,t,i)}),e}function ys(t,i){const e=Tc(t,i);return(n,o,r)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(Lt(e,o)&&o in n?e:n,o,r)}const Ec={get:ys(!1,!1)},Bc={get:ys(!1,!0)},Mc={get:ys(!0,!1)};const ol=new WeakMap,sl=new WeakMap,rl=new WeakMap,Dc=new WeakMap;function Lc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function xo(t){return si(t)?t:ks(t,!1,Cc,Ec,ol)}function Pc(t){return ks(t,!1,Ic,Bc,sl)}function Qo(t){return ks(t,!0,$c,Mc,rl)}function ks(t,i,e,n,o){if(!zt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=o.get(t);if(r)return r;const l=Lc(rc(t));if(l===0)return t;const s=new Proxy(t,l===2?n:e);return o.set(t,s),s}function Bi(t){return si(t)?Bi(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Se(t){return!!(t&&t.__v_isShallow)}function ws(t){return t?!!t.__v_raw:!1}function Dt(t){const i=t&&t.__v_raw;return i?Dt(i):t}function Oc(t){return!Lt(t,"__v_skip")&&Object.isExtensible(t)&&Ur(t,"__v_skip",!0),t}const De=t=>zt(t)?xo(t):t,Zi=t=>zt(t)?Qo(t):t;function qt(t){return t?t.__v_isRef===!0:!1}function ft(t){return Rc(t,!1)}function Rc(t,i){return qt(t)?t:new zc(t,i)}class zc{constructor(i,e){this.dep=new bs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Dt(i),this._value=e?i:De(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Se(i)||si(i);i=n?i:Dt(i),je(i,e)&&(this._rawValue=i,this._value=n?i:De(i),this.dep.trigger())}}function ht(t){return qt(t)?t.value:t}const Nc={get:(t,i,e)=>i==="__v_raw"?t:ht(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return qt(o)&&!qt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function ll(t){return Bi(t)?t:new Proxy(t,Nc)}class Fc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new bs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=wn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&jt!==this)return Zr(this,!0),!0}get value(){const i=this.dep.track();return Xr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function jc(t,i,e=!1){let n,o;return It(t)?n=t:(n=t.get,o=t.set),new Fc(n,o,e)}const jn={},oo=new WeakMap;let Ci;function Hc(t,i=!1,e=Ci){if(e){let n=oo.get(e);n||oo.set(e,n=[]),n.push(t)}}function Uc(t,i,e=Ft){const{immediate:n,deep:o,once:r,scheduler:l,augmentJob:s,call:a}=e,c=T=>o?T:Se(T)||o===!1||o===0?Qe(T,1):Qe(T);let d,u,m,f,k=!1,h=!1;if(qt(t)?(u=()=>t.value,k=Se(t)):Bi(t)?(u=()=>c(t),k=!0):Ct(t)?(h=!0,k=t.some(T=>Bi(T)||Se(T)),u=()=>t.map(T=>{if(qt(T))return T.value;if(Bi(T))return c(T);if(It(T))return a?a(T,2):T()})):It(t)?i?u=a?()=>a(t,2):t:u=()=>{if(m){ni();try{m()}finally{oi()}}const T=Ci;Ci=d;try{return a?a(t,3,[f]):t(f)}finally{Ci=T}}:u=We,i&&o){const T=u,x=o===!0?1/0:o;u=()=>Qe(T(),x)}const y=vc(),b=()=>{d.stop(),y&&y.active&&us(y.effects,d)};if(r&&i){const T=i;i=(...x)=>{const $=T(...x);return b(),$}}let w=h?new Array(t.length).fill(jn):jn;const _=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(i){const x=d.run();if(T||o||k||(h?x.some(($,C)=>je($,w[C])):je(x,w))){m&&m();const $=Ci;Ci=d;try{const C=[x,w===jn?void 0:h&&w[0]===jn?[]:w,f];w=x,a?a(i,3,C):i(...C)}finally{Ci=$}}}else d.run()};return s&&s(_),d=new qr(u),d.scheduler=l?()=>l(_,!1):_,f=T=>Hc(T,!1,d),m=d.onStop=()=>{const T=oo.get(d);if(T){if(a)a(T,4);else for(const x of T)x();oo.delete(d)}},i?n?_(!0):w=d.run():l?l(_.bind(null,!0),!0):d.run(),b.pause=d.pause.bind(d),b.resume=d.resume.bind(d),b.stop=b,b}function Qe(t,i=1/0,e){if(i<=0||!zt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,qt(t))Qe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Qe(t[n],i,e);else if(Qi(t)||Ui(t))t.forEach(n=>{Qe(n,i,e)});else if(Hr(t)){for(const n in t)Qe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Tn(t,i,e,n){try{return n?t(...n):t()}catch(o){_o(o,i,e)}}function Le(t,i,e,n){if(It(t)){const o=Tn(t,i,e,n);return o&&Fr(o)&&o.catch(r=>{_o(r,i,e)}),o}if(Ct(t)){const o=[];for(let r=0;r<t.length;r++)o.push(Le(t[r],i,e,n));return o}}function _o(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Ft;if(i){let s=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;s;){const d=s.ec;if(d){for(let u=0;u<d.length;u++)if(d[u](t,a,c)===!1)return}s=s.parent}if(r){ni(),Tn(r,null,10,[t,a,c]),oi();return}}Wc(t,e,o,n,l)}function Wc(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const ue=[];let ze=-1;const Wi=[];let di=null,zi=0;const al=Promise.resolve();let so=null;function cl(t){const i=so||al;return t?i.then(this?t.bind(this):t):i}function Vc(t){let i=ze+1,e=ue.length;for(;i<e;){const n=i+e>>>1,o=ue[n],r=_n(o);r<t||r===t&&o.flags&2?i=n+1:e=n}return i}function xs(t){if(!(t.flags&1)){const i=_n(t),e=ue[ue.length-1];!e||!(t.flags&2)&&i>=_n(e)?ue.push(t):ue.splice(Vc(i),0,t),t.flags|=1,dl()}}function dl(){so||(so=al.then(fl))}function Kc(t){Ct(t)?Wi.push(...t):di&&t.id===-1?di.splice(zi+1,0,t):t.flags&1||(Wi.push(t),t.flags|=1),dl()}function Ks(t,i,e=ze+1){for(;e<ue.length;e++){const n=ue[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ue.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function ul(t){if(Wi.length){const i=[...new Set(Wi)].sort((e,n)=>_n(e)-_n(n));if(Wi.length=0,di){di.push(...i);return}for(di=i,zi=0;zi<di.length;zi++){const e=di[zi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}di=null,zi=0}}const _n=t=>t.id==null?t.flags&2?-1:1/0:t.id;function fl(t){try{for(ze=0;ze<ue.length;ze++){const i=ue[ze];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Tn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;ze<ue.length;ze++){const i=ue[ze];i&&(i.flags&=-2)}ze=-1,ue.length=0,ul(),so=null,(ue.length||Wi.length)&&fl()}}let re=null,pl=null;function ro(t){const i=re;return re=t,pl=t&&t.type.__scopeId||null,i}function hl(t,i=re,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&or(-1);const r=ro(i),l=ei.length;let s;try{s=t(...o)}finally{for(let a=ei.length;a>l;a--)As();ro(r),n._d&&or(1)}return s};return n._n=!0,n._c=!0,n._d=!0,n}function Ie(t,i){if(re===null)return t;const e=Io(re),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[r,l,s,a=Ft]=i[o];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Qe(l),n.push({dir:r,instance:e,value:l,oldValue:void 0,arg:s,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,r=i&&i.dirs;for(let l=0;l<o.length;l++){const s=o[l];r&&(s.oldValue=r[l].value);let a=s.dir[n];a&&(ni(),Le(a,e,8,[t.el,s,t,i]),oi())}}function qc(t,i){if(ce){let e=ce.provides;const n=ce.parent&&ce.parent.provides;n===e&&(e=ce.provides=Object.create(n)),e[t]=i}}function ti(t,i,e=!1){const n=Vd();if(n||Ki){let o=Ki?Ki._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&It(i)?i.call(n&&n.proxy):i}}const Gc=Symbol.for("v-scx"),Zc=()=>ti(Gc);function Mi(t,i,e){return ml(t,i,e)}function ml(t,i,e=Ft){const{immediate:n,deep:o,flush:r,once:l}=e,s=le({},e),a=i&&n||!i&&r!=="post";let c;if(Cn){if(r==="sync"){const f=Zc();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!a){const f=()=>{};return f.stop=We,f.resume=We,f.pause=We,f}}const d=ce;s.call=(f,k,h)=>Le(f,d,k,h);let u=!1;r==="post"?s.scheduler=f=>{he(f,d&&d.suspense)}:r!=="sync"&&(u=!0,s.scheduler=(f,k)=>{k?f():xs(f)}),s.augmentJob=f=>{i&&(f.flags|=4),u&&(f.flags|=2,d&&(f.id=d.uid,f.i=d))};const m=Uc(t,i,s);return Cn&&(c?c.push(m):a&&m()),m}function Yc(t,i,e){const n=this.proxy,o=Yt(t)?t.includes(".")?gl(n,t):()=>n[t]:t.bind(n,n);let r;It(i)?r=i:(r=i.handler,e=i);const l=Bn(this),s=ml(o,r.bind(n),e);return l(),s}function gl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const Jc=Symbol("_vte"),Xc=t=>t.__isTeleport,Oo=Symbol("_leaveCb");function _s(t,i){t.shapeFlag&6&&t.component?(t.transition=i,_s(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?le({name:t.name},i,{setup:t}):t}function vl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function qs(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const lo=new WeakMap;function hn(t,i,e,n,o=!1){if(Ct(t)){t.forEach((h,y)=>hn(h,i&&(Ct(i)?i[y]:i),e,n,o));return}if(Vi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&hn(t,i,e,n.component.subTree);return}const r=n.shapeFlag&4?Io(n.component):n.el,l=o?null:r,{i:s,r:a}=t,c=i&&i.r,d=s.refs===Ft?s.refs={}:s.refs,u=s.setupState,m=Dt(u),f=u===Ft?Nr:h=>qs(d,h)?!1:Lt(m,h),k=(h,y)=>!(y&&qs(d,y));if(c!=null&&c!==a){if(Gs(i),Yt(c))d[c]=null,f(c)&&(u[c]=null);else if(qt(c)){const h=i;k(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(It(a))Tn(a,s,12,[l,d]);else{const h=Yt(a),y=qt(a);if(h||y){const b=()=>{if(t.f){const w=h?f(a)?u[a]:d[a]:k()||!t.k?a.value:d[t.k];if(o)Ct(w)&&us(w,r);else if(Ct(w))w.includes(r)||w.push(r);else if(h)d[a]=[r],f(a)&&(u[a]=d[a]);else{const _=[r];k(a,t.k)&&(a.value=_),t.k&&(d[t.k]=_)}}else h?(d[a]=l,f(a)&&(u[a]=l)):y&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const w=()=>{b(),lo.delete(t)};w.id=-1,lo.set(t,w),he(w,e)}else Gs(t),b()}}}function Gs(t){const i=lo.get(t);i&&(i.flags|=8,lo.delete(t))}ko().requestIdleCallback;ko().cancelIdleCallback;const Vi=t=>!!t.type.__asyncLoader,bl=t=>t.type.__isKeepAlive;function Qc(t,i){yl(t,"a",i)}function td(t,i){yl(t,"da",i)}function yl(t,i,e=ce){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(So(i,n,e),e){let o=e.parent;for(;o&&o.parent;)bl(o.parent.vnode)&&ed(n,i,e,o),o=o.parent}}function ed(t,i,e,n){const o=So(i,t,n,!0);Cs(()=>{us(n[i],o)},e)}function So(t,i,e=ce,n=!1){if(e){const o=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ni();const s=Bn(e),a=Le(i,e,t,l);return s(),oi(),a});return n?o.unshift(r):o.push(r),r}}const li=t=>(i,e=ce)=>{(!Cn||t==="sp")&&So(t,(...n)=>i(...n),e)},id=li("bm"),En=li("m"),nd=li("bu"),od=li("u"),Ss=li("bum"),Cs=li("um"),sd=li("sp"),rd=li("rtg"),ld=li("rtc");function ad(t,i=ce){So("ec",t,i)}const cd="components";function dd(t,i){return fd(cd,t,!0,i)||t}const ud=Symbol.for("v-ndc");function fd(t,i,e=!0,n=!1){const o=re||ce;if(o){const r=o.type;{const s=Yd(r,!1);if(s&&(s===i||s===fe(i)||s===bo(fe(i))))return r}const l=Zs(o[t]||r[t],i)||Zs(o.appContext[t],i);return!l&&n?r:l}}function Zs(t,i){return t&&(t[i]||t[fe(i)]||t[bo(fe(i))])}function me(t,i,e,n){let o;const r=e,l=Ct(t);if(l||Yt(t)){const s=l&&Bi(t);let a=!1,c=!1;s&&(a=!Se(t),c=si(t),t=wo(t)),o=new Array(t.length);for(let d=0,u=t.length;d<u;d++)o[d]=i(a?c?Zi(De(t[d])):De(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){o=new Array(t);for(let s=0;s<t;s++)o[s]=i(s+1,s,void 0,r)}else if(zt(t))if(t[Symbol.iterator])o=Array.from(t,(s,a)=>i(s,a,void 0,r));else{const s=Object.keys(t);o=new Array(s.length);for(let a=0,c=s.length;a<c;a++){const d=s[a];o[a]=i(t[d],d,a,r)}}else o=[];return o}function Hn(t,i,e={},n,o,r){if(re.ce||re.parent&&Vi(re.parent)&&re.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),Ee(Ut,null,[dt("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const s=ei.length;tt();let a;try{const c=l&&kl(l(e)),d=e.key||r||c&&c.key;a=Ee(Ut,{key:(d&&!Me(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ei.length;d>s;d--)As();throw c}finally{l&&l._c&&(l._d=!0)}return a}function kl(t){return t.some(i=>Ts(i)?!(i.type===ri||i.type===Ut&&!kl(i.children)):!0)?t:null}const ts=t=>t?Fl(t)?Io(t):ts(t.parent):null,mn=le(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>ts(t.parent),$root:t=>ts(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>xl(t),$forceUpdate:t=>t.f||(t.f=()=>{xs(t.update)}),$nextTick:t=>t.n||(t.n=cl.bind(t.proxy)),$watch:t=>Yc.bind(t)}),Ro=(t,i)=>t!==Ft&&!t.__isScriptSetup&&Lt(t,i),pd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:r,accessCache:l,type:s,appContext:a}=t;if(i[0]!=="$"){const m=l[i];if(m!==void 0)switch(m){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return r[i]}else{if(Ro(n,i))return l[i]=1,n[i];if(o!==Ft&&Lt(o,i))return l[i]=2,o[i];if(Lt(r,i))return l[i]=3,r[i];if(e!==Ft&&Lt(e,i))return l[i]=4,e[i];es&&(l[i]=0)}}const c=mn[i];let d,u;if(c)return i==="$attrs"&&ae(t.attrs,"get",""),c(t);if((d=s.__cssModules)&&(d=d[i]))return d;if(e!==Ft&&Lt(e,i))return l[i]=4,e[i];if(u=a.config.globalProperties,Lt(u,i))return u[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:r}=t;return Ro(o,i)?(o[i]=e,!0):n!==Ft&&Lt(n,i)?(n[i]=e,!0):Lt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:r,type:l}},s){let a;return!!(e[s]||t!==Ft&&s[0]!=="$"&&Lt(t,s)||Ro(i,s)||Lt(r,s)||Lt(n,s)||Lt(mn,s)||Lt(o.config.globalProperties,s)||(a=l.__cssModules)&&a[s])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Lt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function Ys(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let es=!0;function hd(t){const i=xl(t),e=t.proxy,n=t.ctx;es=!1,i.beforeCreate&&Js(i.beforeCreate,t,"bc");const{data:o,computed:r,methods:l,watch:s,provide:a,inject:c,created:d,beforeMount:u,mounted:m,beforeUpdate:f,updated:k,activated:h,deactivated:y,beforeDestroy:b,beforeUnmount:w,destroyed:_,unmounted:T,render:x,renderTracked:$,renderTriggered:C,errorCaptured:B,serverPrefetch:M,expose:O,inheritAttrs:Z,components:A,directives:E,filters:g}=i;if(c&&md(c,n,null),l)for(const P in l){const H=l[P];It(H)&&(n[P]=H.bind(e))}if(o){const P=o.call(e,e);zt(P)&&(t.data=xo(P))}if(es=!0,r)for(const P in r){const H=r[P],U=It(H)?H.bind(e,e):It(H.get)?H.get.bind(e,e):We,X=!It(H)&&It(H.set)?H.set.bind(e):We,K=_t({get:U,set:X});Object.defineProperty(n,P,{enumerable:!0,configurable:!0,get:()=>K.value,set:q=>K.value=q})}if(s)for(const P in s)wl(s[P],n,e,P);if(a){const P=It(a)?a.call(e):a;Reflect.ownKeys(P).forEach(H=>{qc(H,P[H])})}d&&Js(d,t,"c");function z(P,H){Ct(H)?H.forEach(U=>P(U.bind(e))):H&&P(H.bind(e))}if(z(id,u),z(En,m),z(nd,f),z(od,k),z(Qc,h),z(td,y),z(ad,B),z(ld,$),z(rd,C),z(Ss,w),z(Cs,T),z(sd,M),Ct(O))if(O.length){const P=t.exposed||(t.exposed={});O.forEach(H=>{Object.defineProperty(P,H,{get:()=>e[H],set:U=>e[H]=U,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===We&&(t.render=x),Z!=null&&(t.inheritAttrs=Z),A&&(t.components=A),E&&(t.directives=E),M&&vl(t)}function md(t,i,e=We){Ct(t)&&(t=is(t));for(const n in t){const o=t[n];let r;zt(o)?"default"in o?r=ti(o.from||n,o.default,!0):r=ti(o.from||n):r=ti(o),qt(r)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[n]=r}}function Js(t,i,e){Le(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function wl(t,i,e,n){let o=n.includes(".")?gl(e,n):()=>e[n];if(Yt(t)){const r=i[t];It(r)&&Mi(o,r)}else if(It(t))Mi(o,t.bind(e));else if(zt(t))if(Ct(t))t.forEach(r=>wl(r,i,e,n));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Mi(o,r,t)}}function xl(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,s=r.get(i);let a;return s?a=s:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>ao(a,c,l,!0)),ao(a,i,l)),zt(i)&&r.set(i,a),a}function ao(t,i,e,n=!1){const{mixins:o,extends:r}=i;r&&ao(t,r,e,!0),o&&o.forEach(l=>ao(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const s=gd[l]||e&&e[l];t[l]=s?s(t[l],i[l]):i[l]}return t}const gd={data:Xs,props:Qs,emits:Qs,methods:ln,computed:ln,beforeCreate:de,created:de,beforeMount:de,mounted:de,beforeUpdate:de,updated:de,beforeDestroy:de,beforeUnmount:de,destroyed:de,unmounted:de,activated:de,deactivated:de,errorCaptured:de,serverPrefetch:de,components:ln,directives:ln,watch:bd,provide:Xs,inject:vd};function Xs(t,i){return i?t?function(){return le(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function vd(t,i){return ln(is(t),is(i))}function is(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function de(t,i){return t?[...new Set([].concat(t,i))]:i}function ln(t,i){return t?le(Object.create(null),t,i):i}function Qs(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:le(Object.create(null),Ys(t),Ys(i??{})):i}function bd(t,i){if(!t)return i;if(!i)return t;const e=le(Object.create(null),t);for(const n in i)e[n]=de(t[n],i[n]);return e}function _l(){return{app:null,config:{isNativeTag:Nr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let yd=0;function kd(t,i){return function(n,o=null){It(n)||(n=le({},n)),o!=null&&!zt(o)&&(o=null);const r=_l(),l=new WeakSet,s=[];let a=!1;const c=r.app={_uid:yd++,_component:n,_props:o,_container:null,_context:r,_instance:null,version:Xd,get config(){return r.config},set config(d){},use(d,...u){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...u)):It(d)&&(l.add(d),d(c,...u))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,u){return u?(r.components[d]=u,c):r.components[d]},directive(d,u){return u?(r.directives[d]=u,c):r.directives[d]},mount(d,u,m){if(!a){const f=c._ceVNode||dt(n,o);return f.appContext=r,m===!0?m="svg":m===!1&&(m=void 0),t(f,d,m),a=!0,c._container=d,d.__vue_app__=c,Io(f.component)}},onUnmount(d){s.push(d)},unmount(){a&&(Le(s,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,u){return r.provides[d]=u,c},runWithContext(d){const u=Ki;Ki=c;try{return d()}finally{Ki=u}}};return c}}let Ki=null;const wd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${fe(i)}Modifiers`]||t[`${vi(i)}Modifiers`];function xd(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Ft;let o=e;const r=i.startsWith("update:"),l=r&&wd(n,i.slice(7));l&&(l.trim&&(o=e.map(d=>Yt(d)?d.trim():d)),l.number&&(o=e.map(yo)));let s,a=n[s=Bo(i)]||n[s=Bo(fe(i))];!a&&r&&(a=n[s=Bo(vi(i))]),a&&Le(a,t,6,o);const c=n[s+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[s])return;t.emitted[s]=!0,Le(c,t,6,o)}}const _d=new WeakMap;function Sl(t,i,e=!1){const n=e?_d:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const r=t.emits;let l={},s=!1;if(!It(t)){const a=c=>{const d=Sl(c,i,!0);d&&(s=!0,le(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!s?(zt(t)&&n.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):le(l,r),zt(t)&&n.set(t,l),l)}function Co(t,i){return!t||!mo(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Lt(t,i[0].toLowerCase()+i.slice(1))||Lt(t,vi(i))||Lt(t,i))}function tr(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[r],slots:l,attrs:s,emit:a,render:c,renderCache:d,props:u,data:m,setupState:f,ctx:k,inheritAttrs:h}=t,y=ro(t);let b,w;try{if(e.shapeFlag&4){const T=o||n,x=T;b=Fe(c.call(x,T,d,u,f,m,k)),w=s}else{const T=i;b=Fe(T.length>1?T(u,{attrs:s,slots:l,emit:a}):T(u,null)),w=i.props?s:Sd(s)}}catch(T){ei.length=0,_o(T,t,1),b=dt(ri)}let _=b;if(w&&h!==!1){const T=Object.keys(w),{shapeFlag:x}=_;T.length&&x&7&&(r&&T.some(go)&&(w=Cd(w,r)),_=Yi(_,w,!1,!0))}return e.dirs&&(_=Yi(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(e.dirs):e.dirs),e.transition&&_s(_,e.transition),b=_,ro(y),b}const Sd=t=>{let i;for(const e in t)(e==="class"||e==="style"||mo(e))&&((i||(i={}))[e]=t[e]);return i},Cd=(t,i)=>{const e={};for(const n in t)(!go(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function $d(t,i,e){const{props:n,children:o,component:r}=t,{props:l,children:s,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?er(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let u=0;u<d.length;u++){const m=d[u];if(Cl(l,n,m)&&!Co(c,m))return!0}}}else return(o||s)&&(!s||!s.$stable)?!0:n===l?!1:n?l?er(n,l,c):!0:!!l;return!1}function er(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const r=n[o];if(Cl(i,t,r)&&!Co(e,r))return!0}return!1}function Cl(t,i,e){const n=t[e],o=i[e];return e==="style"&&zt(n)&&zt(o)?!tn(n,o):n!==o}function Id({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const $l={},Il=()=>Object.create($l),Al=t=>Object.getPrototypeOf(t)===$l;function Ad(t,i,e,n=!1){const o={},r=Il();t.propsDefaults=Object.create(null),Tl(t,i,o,r);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Pc(o):t.type.props?t.props=o:t.props=r,t.attrs=r}function Td(t,i,e,n){const{props:o,attrs:r,vnode:{patchFlag:l}}=t,s=Dt(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let u=0;u<d.length;u++){let m=d[u];if(Co(t.emitsOptions,m))continue;const f=i[m];if(a)if(Lt(r,m))f!==r[m]&&(r[m]=f,c=!0);else{const k=fe(m);o[k]=ns(a,s,k,f,t,!1)}else f!==r[m]&&(r[m]=f,c=!0)}}}else{Tl(t,i,o,r)&&(c=!0);let d;for(const u in s)(!i||!Lt(i,u)&&((d=vi(u))===u||!Lt(i,d)))&&(a?e&&(e[u]!==void 0||e[d]!==void 0)&&(o[u]=ns(a,s,u,void 0,t,!0)):delete o[u]);if(r!==s)for(const u in r)(!i||!Lt(i,u))&&(delete r[u],c=!0)}c&&Xe(t.attrs,"set","")}function Tl(t,i,e,n){const[o,r]=t.propsOptions;let l=!1,s;if(i)for(let a in i){if(un(a))continue;const c=i[a];let d;o&&Lt(o,d=fe(a))?!r||!r.includes(d)?e[d]=c:(s||(s={}))[d]=c:Co(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(r){const a=Dt(e),c=s||Ft;for(let d=0;d<r.length;d++){const u=r[d];e[u]=ns(o,a,u,c[u],t,!Lt(c,u))}}return l}function ns(t,i,e,n,o,r){const l=t[e];if(l!=null){const s=Lt(l,"default");if(s&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const d=Bn(o);n=c[e]=a.call(null,i),d()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(r&&!s?n=!1:l[1]&&(n===""||n===vi(e))&&(n=!0))}return n}const Ed=new WeakMap;function El(t,i,e=!1){const n=e?Ed:i.propsCache,o=n.get(t);if(o)return o;const r=t.props,l={},s=[];let a=!1;if(!It(t)){const d=u=>{a=!0;const[m,f]=El(u,i,!0);le(l,m),f&&s.push(...f)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return zt(t)&&n.set(t,Hi),Hi;if(Ct(r))for(let d=0;d<r.length;d++){const u=fe(r[d]);ir(u)&&(l[u]=Ft)}else if(r)for(const d in r){const u=fe(d);if(ir(u)){const m=r[d],f=l[u]=Ct(m)||It(m)?{type:m}:le({},m),k=f.type;let h=!1,y=!0;if(Ct(k))for(let b=0;b<k.length;++b){const w=k[b],_=It(w)&&w.name;if(_==="Boolean"){h=!0;break}else _==="String"&&(y=!1)}else h=It(k)&&k.name==="Boolean";f[0]=h,f[1]=y,(h||Lt(f,"default"))&&s.push(u)}}const c=[l,s];return zt(t)&&n.set(t,c),c}function ir(t){return t[0]!=="$"&&!un(t)}const $s=t=>t==="_"||t==="_ctx"||t==="$stable",Is=t=>Ct(t)?t.map(Fe):[Fe(t)],Bd=(t,i,e)=>{if(i._n)return i;const n=hl((...o)=>Is(i(...o)),e);return n._c=!1,n},Bl=(t,i,e)=>{const n=t._ctx;for(const o in t){if($s(o))continue;const r=t[o];if(It(r))i[o]=Bd(o,r,n);else if(r!=null){const l=Is(r);i[o]=()=>l}}},Ml=(t,i)=>{const e=Is(i);t.slots.default=()=>e},Dl=(t,i,e)=>{for(const n in i)(e||!$s(n))&&(t[n]=i[n])},Md=(t,i,e)=>{const n=t.slots=Il();if(t.vnode.shapeFlag&32){const o=i._;o?(Dl(n,i,e),e&&Ur(n,"_",o,!0)):Bl(i,n)}else i&&Ml(t,i)},Dd=(t,i,e)=>{const{vnode:n,slots:o}=t;let r=!0,l=Ft;if(n.shapeFlag&32){const s=i._;s?e&&s===1?r=!1:Dl(o,i,e):(r=!i.$stable,Bl(i,o)),l=i}else i&&(Ml(t,i),l={default:1});if(r)for(const s in o)!$s(s)&&l[s]==null&&delete o[s]},he=zd;function Ld(t){return Pd(t)}function Pd(t,i){const e=ko();e.__VUE__=!0;const{insert:n,remove:o,patchProp:r,createElement:l,createText:s,createComment:a,setText:c,setElementText:d,parentNode:u,nextSibling:m,setScopeId:f=We,insertStaticContent:k}=t,h=(D,N,p,j=null,R=null,S=null,I=void 0,L=null,G=!!N.dynamicChildren)=>{if(D===N)return;D&&!on(D,N)&&(j=pt(D),q(D,R,S,!0),D=null),N.patchFlag===-2&&(G=!1,N.dynamicChildren=null);const{type:V,ref:W,shapeFlag:Y}=N;switch(V){case $o:y(D,N,p,j);break;case ri:b(D,N,p,j);break;case qn:D==null&&w(N,p,j,I);break;case Ut:A(D,N,p,j,R,S,I,L,G);break;default:Y&1?x(D,N,p,j,R,S,I,L,G):Y&6?E(D,N,p,j,R,S,I,L,G):(Y&64||Y&128)&&V.process(D,N,p,j,R,S,I,L,G,rt)}W!=null&&R?hn(W,D&&D.ref,S,N||D,!N):W==null&&D&&D.ref!=null&&hn(D.ref,null,S,D,!0)},y=(D,N,p,j)=>{if(D==null)n(N.el=s(N.children),p,j);else{const R=N.el=D.el;N.children!==D.children&&c(R,N.children)}},b=(D,N,p,j)=>{D==null?n(N.el=a(N.children||""),p,j):N.el=D.el},w=(D,N,p,j)=>{[D.el,D.anchor]=k(D.children,N,p,j,D.el,D.anchor)},_=({el:D,anchor:N},p,j)=>{let R;for(;D&&D!==N;)R=m(D),n(D,p,j),D=R;n(N,p,j)},T=({el:D,anchor:N})=>{let p;for(;D&&D!==N;)p=m(D),o(D),D=p;o(N)},x=(D,N,p,j,R,S,I,L,G)=>{if(N.type==="svg"?I="svg":N.type==="math"&&(I="mathml"),D==null)$(N,p,j,R,S,I,L,G);else{const V=D.el&&D.el._isVueCE?D.el:null;try{V&&V._beginPatch(),M(D,N,R,S,I,L,G)}finally{V&&V._endPatch()}}},$=(D,N,p,j,R,S,I,L)=>{let G,V;const{props:W,shapeFlag:Y,transition:nt,dirs:et}=D;if(G=D.el=l(D.type,S,W&&W.is,W),Y&8?d(G,D.children):Y&16&&B(D.children,G,null,j,R,zo(D,S),I,L),et&&xi(D,null,j,"created"),C(G,D,D.scopeId,I,j),W){for(const xt in W)xt!=="value"&&!un(xt)&&r(G,xt,null,W[xt],S,j);"value"in W&&r(G,"value",null,W.value,S),(V=W.onVnodeBeforeMount)&&Oe(V,j,D)}et&&xi(D,null,j,"beforeMount");const ct=Od(R,nt);ct&&nt.beforeEnter(G),n(G,N,p),((V=W&&W.onVnodeMounted)||ct||et)&&he(()=>{try{V&&Oe(V,j,D),ct&&nt.enter(G),et&&xi(D,null,j,"mounted")}finally{}},R)},C=(D,N,p,j,R)=>{if(p&&f(D,p),j)for(let S=0;S<j.length;S++)f(D,j[S]);if(R){let S=R.subTree;if(N===S||Rl(S.type)&&(S.ssContent===N||S.ssFallback===N)){const I=R.vnode;C(D,I,I.scopeId,I.slotScopeIds,R.parent)}}},B=(D,N,p,j,R,S,I,L,G=0)=>{for(let V=G;V<D.length;V++){const W=D[V]=L?Je(D[V]):Fe(D[V]);h(null,W,N,p,j,R,S,I,L)}},M=(D,N,p,j,R,S,I)=>{const L=N.el=D.el;let{patchFlag:G,dynamicChildren:V,dirs:W}=N;G|=D.patchFlag&16;const Y=D.props||Ft,nt=N.props||Ft;let et;if(p&&_i(p,!1),(et=nt.onVnodeBeforeUpdate)&&Oe(et,p,N,D),W&&xi(N,D,p,"beforeUpdate"),p&&_i(p,!0),V&&(!D.dynamicChildren||D.dynamicChildren.length!==V.length)&&(G=0,I=!1,V=null),(Y.innerHTML&&nt.innerHTML==null||Y.textContent&&nt.textContent==null)&&d(L,""),V?O(D.dynamicChildren,V,L,p,j,zo(N,R),S):I||H(D,N,L,null,p,j,zo(N,R),S,!1),G>0){if(G&16)Z(L,Y,nt,p,R);else if(G&2&&Y.class!==nt.class&&r(L,"class",null,nt.class,R),G&4&&r(L,"style",Y.style,nt.style,R),G&8){const ct=N.dynamicProps;for(let xt=0;xt<ct.length;xt++){const bt=ct[xt],Et=Y[bt],Wt=nt[bt];(Wt!==Et||bt==="value")&&r(L,bt,Et,Wt,R,p)}}G&1&&D.children!==N.children&&d(L,N.children)}else!I&&V==null&&Z(L,Y,nt,p,R);((et=nt.onVnodeUpdated)||W)&&he(()=>{et&&Oe(et,p,N,D),W&&xi(N,D,p,"updated")},j)},O=(D,N,p,j,R,S,I)=>{for(let L=0;L<N.length;L++){const G=D[L],V=N[L],W=G.el&&(G.type===Ut||!on(G,V)||G.shapeFlag&198)?u(G.el):p;h(G,V,W,null,j,R,S,I,!0)}},Z=(D,N,p,j,R)=>{if(N!==p){if(N!==Ft)for(const S in N)!un(S)&&!(S in p)&&r(D,S,N[S],null,R,j);for(const S in p){if(un(S))continue;const I=p[S],L=N[S];I!==L&&S!=="value"&&r(D,S,L,I,R,j)}"value"in p&&r(D,"value",N.value,p.value,R)}},A=(D,N,p,j,R,S,I,L,G)=>{const V=N.el=D?D.el:s(""),W=N.anchor=D?D.anchor:s("");let{patchFlag:Y,dynamicChildren:nt,slotScopeIds:et}=N;et&&(L=L?L.concat(et):et),D==null?(n(V,p,j),n(W,p,j),B(N.children||[],p,W,R,S,I,L,G)):Y>0&&Y&64&&nt&&D.dynamicChildren&&D.dynamicChildren.length===nt.length?(O(D.dynamicChildren,nt,p,R,S,I,L),(N.key!=null||R&&N===R.subTree)&&Ll(D,N,!0)):H(D,N,p,W,R,S,I,L,G)},E=(D,N,p,j,R,S,I,L,G)=>{N.slotScopeIds=L,D==null?N.shapeFlag&512?R.ctx.activate(N,p,j,I,G):g(N,p,j,R,S,I,G):F(D,N,G)},g=(D,N,p,j,R,S,I)=>{const L=D.component=Wd(D,j,R);if(bl(D)&&(L.ctx.renderer=rt),Kd(L,!1,I),L.asyncDep){if(R&&R.registerDep(L,z,I),!D.el){const G=L.subTree=dt(ri);b(null,G,N,p),D.placeholder=G.el}}else z(L,D,N,p,R,S,I)},F=(D,N,p)=>{const j=N.component=D.component;if($d(D,N,p))if(j.asyncDep&&!j.asyncResolved){P(j,N,p);return}else j.next=N,j.update();else N.el=D.el,j.vnode=N},z=(D,N,p,j,R,S,I)=>{const L=()=>{if(D.isMounted){let{next:Y,bu:nt,u:et,parent:ct,vnode:xt}=D;{const Qt=Pl(D);if(Qt){Y&&(Y.el=xt.el,P(D,Y,I)),Qt.asyncDep.then(()=>{he(()=>{D.isUnmounted||V()},R)});return}}let bt=Y,Et;_i(D,!1),Y?(Y.el=xt.el,P(D,Y,I)):Y=xt,nt&&Kn(nt),(Et=Y.props&&Y.props.onVnodeBeforeUpdate)&&Oe(Et,ct,Y,xt),_i(D,!0);const Wt=tr(D),Kt=D.subTree;D.subTree=Wt,h(Kt,Wt,u(Kt.el),pt(Kt),D,R,S),Y.el=Wt.el,bt===null&&Id(D,Wt.el),et&&he(et,R),(Et=Y.props&&Y.props.onVnodeUpdated)&&he(()=>Oe(Et,ct,Y,xt),R)}else{let Y;const{el:nt,props:et}=N,{bm:ct,m:xt,parent:bt,root:Et,type:Wt}=D,Kt=Vi(N);_i(D,!1),ct&&Kn(ct),!Kt&&(Y=et&&et.onVnodeBeforeMount)&&Oe(Y,bt,N),_i(D,!0);{Et.ce&&Et.ce._hasShadowRoot()&&Et.ce._injectChildStyle(Wt,D.parent?D.parent.type:void 0);const Qt=D.subTree=tr(D);h(null,Qt,p,j,D,R,S),N.el=Qt.el}if(xt&&he(xt,R),!Kt&&(Y=et&&et.onVnodeMounted)){const Qt=N;he(()=>Oe(Y,bt,Qt),R)}(N.shapeFlag&256||bt&&Vi(bt.vnode)&&bt.vnode.shapeFlag&256)&&D.a&&he(D.a,R),D.isMounted=!0,N=p=j=null}};D.scope.on();const G=D.effect=new qr(L);D.scope.off();const V=D.update=G.run.bind(G),W=D.job=G.runIfDirty.bind(G);W.i=D,W.id=D.uid,G.scheduler=()=>xs(W),_i(D,!0),V()},P=(D,N,p)=>{N.component=D;const j=D.vnode.props;D.vnode=N,D.next=null,Td(D,N.props,j,p),Dd(D,N.children,p),ni(),Ks(D),oi()},H=(D,N,p,j,R,S,I,L,G=!1)=>{const V=D&&D.children,W=D?D.shapeFlag:0,Y=N.children,{patchFlag:nt,shapeFlag:et}=N;if(nt>0){if(nt&128){X(V,Y,p,j,R,S,I,L,G);return}else if(nt&256){U(V,Y,p,j,R,S,I,L,G);return}}et&8?(W&16&&Q(V,R,S),Y!==V&&d(p,Y)):W&16?et&16?X(V,Y,p,j,R,S,I,L,G):Q(V,R,S,!0):(W&8&&d(p,""),et&16&&B(Y,p,j,R,S,I,L,G))},U=(D,N,p,j,R,S,I,L,G)=>{D=D||Hi,N=N||Hi;const V=D.length,W=N.length,Y=Math.min(V,W);let nt;for(nt=0;nt<Y;nt++){const et=N[nt]=G?Je(N[nt]):Fe(N[nt]);h(D[nt],et,p,null,R,S,I,L,G)}V>W?Q(D,R,S,!0,!1,Y):B(N,p,j,R,S,I,L,G,Y)},X=(D,N,p,j,R,S,I,L,G)=>{let V=0;const W=N.length;let Y=D.length-1,nt=W-1;for(;V<=Y&&V<=nt;){const et=D[V],ct=N[V]=G?Je(N[V]):Fe(N[V]);if(on(et,ct))h(et,ct,p,null,R,S,I,L,G);else break;V++}for(;V<=Y&&V<=nt;){const et=D[Y],ct=N[nt]=G?Je(N[nt]):Fe(N[nt]);if(on(et,ct))h(et,ct,p,null,R,S,I,L,G);else break;Y--,nt--}if(V>Y){if(V<=nt){const et=nt+1,ct=et<W?N[et].el:j;for(;V<=nt;)h(null,N[V]=G?Je(N[V]):Fe(N[V]),p,ct,R,S,I,L,G),V++}}else if(V>nt)for(;V<=Y;)q(D[V],R,S,!0),V++;else{const et=V,ct=V,xt=new Map;for(V=ct;V<=nt;V++){const Jt=N[V]=G?Je(N[V]):Fe(N[V]);Jt.key!=null&&xt.set(Jt.key,V)}let bt,Et=0;const Wt=nt-ct+1;let Kt=!1,Qt=0;const Pt=new Array(Wt);for(V=0;V<Wt;V++)Pt[V]=0;for(V=et;V<=Y;V++){const Jt=D[V];if(Et>=Wt){q(Jt,R,S,!0);continue}let Gt;if(Jt.key!=null)Gt=xt.get(Jt.key);else for(bt=ct;bt<=nt;bt++)if(Pt[bt-ct]===0&&on(Jt,N[bt])){Gt=bt;break}Gt===void 0?q(Jt,R,S,!0):(Pt[Gt-ct]=V+1,Gt>=Qt?Qt=Gt:Kt=!0,h(Jt,N[Gt],p,null,R,S,I,L,G),Et++)}const Ve=Kt?Rd(Pt):Hi;for(bt=Ve.length-1,V=Wt-1;V>=0;V--){const Jt=ct+V,Gt=N[Jt],bi=N[Jt+1],Pi=Jt+1<W?bi.el||Ol(bi):j;Pt[V]===0?h(null,Gt,p,Pi,R,S,I,L,G):Kt&&(bt<0||V!==Ve[bt]?K(Gt,p,Pi,2):bt--)}}},K=(D,N,p,j,R=null)=>{const{el:S,type:I,transition:L,children:G,shapeFlag:V}=D;if(V&6){K(D.component.subTree,N,p,j);return}if(V&128){D.suspense.move(N,p,j);return}if(V&64){I.move(D,N,p,rt);return}if(I===Ut){n(S,N,p);for(let Y=0;Y<G.length;Y++)K(G[Y],N,p,j);n(D.anchor,N,p);return}if(I===qn){_(D,N,p);return}if(j!==2&&V&1&&L)if(j===0)L.persisted&&!S[Oo]?n(S,N,p):(L.beforeEnter(S),n(S,N,p),he(()=>L.enter(S),R));else{const{leave:Y,delayLeave:nt,afterLeave:et}=L,ct=()=>{D.ctx.isUnmounted?o(S):n(S,N,p)},xt=()=>{const bt=S._isLeaving||!!S[Oo];S._isLeaving&&S[Oo](!0),L.persisted&&!bt?ct():Y(S,()=>{ct(),et&&et()})};nt?nt(S,ct,xt):xt()}else n(S,N,p)},q=(D,N,p,j=!1,R=!1)=>{const{type:S,props:I,ref:L,children:G,dynamicChildren:V,shapeFlag:W,patchFlag:Y,dirs:nt,cacheIndex:et,memo:ct}=D;if(Y===-2&&(R=!1),L!=null&&(ni(),hn(L,null,p,D,!0),oi()),et!=null&&(N.renderCache[et]=void 0),W&256){N.ctx.deactivate(D);return}const xt=W&1&&nt,bt=!Vi(D);let Et;if(bt&&(Et=I&&I.onVnodeBeforeUnmount)&&Oe(Et,N,D),W&6)st(D.component,p,j);else{if(W&128){D.suspense.unmount(p,j);return}xt&&xi(D,null,N,"beforeUnmount"),W&64?D.type.remove(D,N,p,rt,j):V&&!V.hasOnce&&(S!==Ut||Y>0&&Y&64)?Q(V,N,p,!1,!0):(S===Ut&&Y&384||!R&&W&16)&&Q(G,N,p),j&&lt(D)}const Wt=ct!=null&&et==null;(bt&&(Et=I&&I.onVnodeUnmounted)||xt||Wt)&&he(()=>{Et&&Oe(Et,N,D),xt&&xi(D,null,N,"unmounted"),Wt&&(D.el=null)},p)},lt=D=>{const{type:N,el:p,anchor:j,transition:R}=D;if(N===Ut){at(p,j);return}if(N===qn){T(D);return}const S=()=>{o(p),R&&!R.persisted&&R.afterLeave&&R.afterLeave()};if(D.shapeFlag&1&&R&&!R.persisted){const{leave:I,delayLeave:L}=R,G=()=>I(p,S);L?L(D.el,S,G):G()}else S()},at=(D,N)=>{let p;for(;D!==N;)p=m(D),o(D),D=p;o(N)},st=(D,N,p)=>{const{bum:j,scope:R,job:S,subTree:I,um:L,m:G,a:V}=D;nr(G),nr(V),j&&Kn(j),R.stop(),S&&(S.flags|=8,q(I,D,N,p)),L&&he(L,N),he(()=>{D.isUnmounted=!0},N)},Q=(D,N,p,j=!1,R=!1,S=0)=>{for(let I=S;I<D.length;I++)q(D[I],N,p,j,R)},pt=D=>{if(D.shapeFlag&6)return pt(D.component.subTree);if(D.shapeFlag&128)return D.suspense.next();const N=m(D.anchor||D.el),p=N&&N[Jc];return p?m(p):N};let gt=!1;const J=(D,N,p)=>{let j;D==null?N._vnode&&(q(N._vnode,null,null,!0),j=N._vnode.component):h(N._vnode||null,D,N,null,null,null,p),N._vnode=D,gt||(gt=!0,Ks(j),ul(),gt=!1)},rt={p:h,um:q,m:K,r:lt,mt:g,mc:B,pc:H,pbc:O,n:pt,o:t};return{render:J,hydrate:void 0,createApp:kd(J)}}function zo({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function _i({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Od(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Ll(t,i,e=!1){const n=t.children,o=i.children;if(Ct(n)&&Ct(o))for(let r=0;r<n.length;r++){const l=n[r];let s=o[r];s.shapeFlag&1&&!s.dynamicChildren&&((s.patchFlag<=0||s.patchFlag===32)&&(s=o[r]=Je(o[r]),s.el=l.el),!e&&s.patchFlag!==-2&&Ll(l,s)),s.type===$o&&(s.patchFlag===-1&&(s=o[r]=Je(s)),s.el=l.el),s.type===ri&&!s.el&&(s.el=l.el)}}function Rd(t){const i=t.slice(),e=[0];let n,o,r,l,s;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(r=0,l=e.length-1;r<l;)s=r+l>>1,t[e[s]]<c?r=s+1:l=s;c<t[e[r]]&&(r>0&&(i[n]=e[r-1]),e[r]=n)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function Pl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Pl(i)}function nr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Ol(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Ol(i.subTree):null}const Rl=t=>t.__isSuspense;function zd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Kc(t)}const Ut=Symbol.for("v-fgt"),$o=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),qn=Symbol.for("v-stc"),ei=[];let ye=null;function tt(t=!1){ei.push(ye=t?null:[])}function As(){ei.pop(),ye=ei[ei.length-1]||null}let Sn=1;function or(t,i=!1){Sn+=t,t<0&&ye&&i&&(ye.hasOnce=!0)}function zl(t){return t.dynamicChildren=Sn>0?ye||Hi:null,As(),Sn>0&&ye&&ye.push(t),t}function it(t,i,e,n,o,r){return zl(v(t,i,e,n,o,r,!0))}function Ee(t,i,e,n,o){return zl(dt(t,i,e,n,o,!0))}function Ts(t){return t?t.__v_isVNode===!0:!1}function on(t,i){return t.type===i.type&&t.key===i.key}const Nl=({key:t})=>t??null,Gn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Yt(t)||qt(t)||It(t)?{i:re,r:t,k:i,f:!!e}:t:null);function v(t,i=null,e=null,n=0,o=null,r=t===Ut?0:1,l=!1,s=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Nl(i),ref:i&&Gn(i),scopeId:pl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:re};return s?(co(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Yt(e)?8:16),Sn>0&&!l&&ye&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&ye.push(a),a}const dt=Nd;function Nd(t,i=null,e=null,n=0,o=null,r=!1){if((!t||t===ud)&&(t=ri),Ts(t)){const s=Yi(t,i,!0);return e&&co(s,e),Sn>0&&!r&&ye&&(s.shapeFlag&6?ye[ye.indexOf(t)]=s:ye.push(s)),s.patchFlag=-2,s}if(Jd(t)&&(t=t.__vccOpts),i){i=Fd(i);let{class:s,style:a}=i;s&&!Yt(s)&&(i.class=$t(s)),zt(a)&&(ws(a)&&!Ct(a)&&(a=le({},a)),i.style=ps(a))}const l=Yt(t)?1:Rl(t)?128:Xc(t)?64:zt(t)?4:It(t)?2:0;return v(t,i,e,n,o,l,r,!0)}function Fd(t){return t?ws(t)||Al(t)?le({},t):t:null}function Yi(t,i,e=!1,n=!1){const{props:o,ref:r,patchFlag:l,children:s,transition:a}=t,c=i?jd(o||{},i):o,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Nl(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Gn(i)):[r,Gn(i)]:Gn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:s,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Ut?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Yi(t.ssContent),ssFallback:t.ssFallback&&Yi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&_s(d,a.clone(d)),d}function os(t=" ",i=0){return dt($o,null,t,i)}function $e(t,i){const e=dt(qn,null,t);return e.staticCount=i,e}function Mt(t="",i=!1){return i?(tt(),Ee(ri,null,t)):dt(ri,null,t)}function Fe(t){return t==null||typeof t=="boolean"?dt(ri):Ct(t)?dt(Ut,null,t.slice()):Ts(t)?Je(t):dt($o,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Yi(t)}function co(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),co(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!Al(i)?i._ctx=re:o===3&&re&&(re.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(n&65){co(t,{default:i});return}i={default:i,_ctx:re},e=32}else i=String(i),n&64?(e=16,i=[os(i)]):e=8;t.children=i,t.shapeFlag|=e}function jd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=$t([i.class,n.class]));else if(o==="style")i.style=ps([i.style,n.style]);else if(mo(o)){const r=i[o],l=n[o];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[o]=r?[].concat(r,l):l:l==null&&r==null&&!go(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function Oe(t,i,e,n=null){Le(t,i,7,[e,n])}const Hd=_l();let Ud=0;function Wd(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Hd,r={uid:Ud++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new gc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:El(n,o),emitsOptions:Sl(n,o),emit:null,emitted:null,propsDefaults:Ft,inheritAttrs:n.inheritAttrs,ctx:Ft,data:Ft,props:Ft,attrs:Ft,slots:Ft,refs:Ft,setupState:Ft,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=xd.bind(null,r),t.ce&&t.ce(r),r}let ce=null;const Vd=()=>ce||re;let uo,ss;{const t=ko(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),r=>{o.length>1?o.forEach(l=>l(r)):o[0](r)}};uo=i("__VUE_INSTANCE_SETTERS__",e=>ce=e),ss=i("__VUE_SSR_SETTERS__",e=>Cn=e)}const Bn=t=>{const i=ce;return uo(t),t.scope.on(),()=>{t.scope.off(),uo(i)}},sr=()=>{ce&&ce.scope.off(),uo(null)};function Fl(t){return t.vnode.shapeFlag&4}let Cn=!1;function Kd(t,i=!1,e=!1){i&&ss(i);const{props:n,children:o}=t.vnode,r=Fl(t);Ad(t,n,r,i),Md(t,o,e||i);const l=r?qd(t,i):void 0;return i&&ss(!1),l}function qd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,pd);const{setup:n}=e;if(n){ni();const o=t.setupContext=n.length>1?Zd(t):null,r=Bn(t),l=Tn(n,t,0,[t.props,o]),s=Fr(l);if(oi(),r(),(s||t.sp)&&!Vi(t)&&vl(t),s){if(l.then(sr,sr),i)return l.then(a=>{rr(t,a)}).catch(a=>{_o(a,t,0)});t.asyncDep=l}else rr(t,l)}else jl(t)}function rr(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:zt(i)&&(t.setupState=ll(i)),jl(t)}function jl(t,i,e){const n=t.type;t.render||(t.render=n.render||We);{const o=Bn(t);ni();try{hd(t)}finally{oi(),o()}}}const Gd={get(t,i){return ae(t,"get",""),t[i]}};function Zd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Gd),slots:t.slots,emit:t.emit,expose:i}}function Io(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(ll(Oc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in mn)return mn[e](t)},has(i,e){return e in i||e in mn}})):t.proxy}function Yd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Jd(t){return It(t)&&"__vccOpts"in t}const _t=(t,i)=>jc(t,i,Cn),Xd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let rs;const lr=typeof window<"u"&&window.trustedTypes;if(lr)try{rs=lr.createPolicy("vue",{createHTML:t=>t})}catch{}const Hl=rs?t=>rs.createHTML(t):t=>t,Qd="http://www.w3.org/2000/svg",tu="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,ar=Ye&&Ye.createElement("template"),eu={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Ye.createElementNS(Qd,t):i==="mathml"?Ye.createElementNS(tu,t):e?Ye.createElement(t,{is:e}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,r){const l=e?e.previousSibling:i.lastChild;if(o&&(o===r||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===r||!(o=o.nextSibling)););else{ar.innerHTML=Hl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const s=ar.content;if(n==="svg"||n==="mathml"){const a=s.firstChild;for(;a.firstChild;)s.appendChild(a.firstChild);s.removeChild(a)}i.insertBefore(s,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},iu=Symbol("_vtc");function nu(t,i,e){const n=t[iu];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const fo=Symbol("_vod"),Ul=Symbol("_vsh"),Wl={name:"show",beforeMount(t,{value:i},{transition:e}){t[fo]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):sn(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),sn(t,!0),n.enter(t)):n.leave(t,()=>{sn(t,!1)}):sn(t,i))},beforeUnmount(t,{value:i}){sn(t,i)}};function sn(t,i){t.style.display=i?t[fo]:"none",t[Ul]=!i}const ou=Symbol(""),su=/(?:^|;)\s*display\s*:/;function ru(t,i,e){const n=t.style,o=Yt(e);let r=!1;if(e&&!o){if(i)if(Yt(i))for(const l of i.split(";")){const s=l.slice(0,l.indexOf(":")).trim();e[s]==null&&an(n,s,"")}else for(const l in i)e[l]==null&&an(n,l,"");for(const l in e){l==="display"&&(r=!0);const s=e[l];s!=null?au(t,l,!Yt(i)&&i?i[l]:void 0,s)||an(n,l,s):an(n,l,"")}}else if(o){if(i!==e){const l=n[ou];l&&(e+=";"+l),n.cssText=e,r=su.test(e)}}else i&&t.removeAttribute("style");fo in t&&(t[fo]=r?n.display:"",t[Ul]&&(n.display="none"))}const cr=/\s*!important$/;function an(t,i,e){if(Ct(e))e.forEach(n=>an(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=lu(t,i);cr.test(e)?t.setProperty(vi(n),e.replace(cr,""),"important"):t[n]=e}}const dr=["Webkit","Moz","ms"],No={};function lu(t,i){const e=No[i];if(e)return e;let n=fe(i);if(n!=="filter"&&n in t)return No[i]=n;n=bo(n);for(let o=0;o<dr.length;o++){const r=dr[o]+n;if(r in t)return No[i]=r}return i}function au(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Yt(n)&&e===n}const ur="http://www.w3.org/1999/xlink";function fr(t,i,e,n,o,r=hc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ur,i.slice(6,i.length)):t.setAttributeNS(ur,i,e):e==null||r&&!Wr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Me(e)?String(e):e)}function pr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Hl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const s=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(s!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const s=typeof t[i];s==="boolean"?e=Wr(e):e==null&&s==="string"?(e="",l=!0):s==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function ui(t,i,e,n){t.addEventListener(i,e,n)}function cu(t,i,e,n){t.removeEventListener(i,e,n)}const hr=Symbol("_vei");function du(t,i,e,n,o=null){const r=t[hr]||(t[hr]={}),l=r[i];if(n&&l)l.value=n;else{const[s,a]=pu(i);if(n){const c=r[i]=gu(n,o);ui(t,s,c,a)}else l&&(cu(t,s,l,a),r[i]=void 0)}}const uu=/(Once|Passive|Capture)$/,fu=/^on:?(?:Once|Passive|Capture)$/;function pu(t){let i,e;for(;(e=t.match(uu))&&!fu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):vi(t.slice(2)),i]}let Fo=0;const hu=Promise.resolve(),mu=()=>Fo||(hu.then(()=>Fo=0),Fo=Date.now());function gu(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(Ct(o)){const r=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{r.call(n),n._stopped=!0};const l=o.slice(),s=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Le(c,i,5,s)}}else Le(o,i,5,[n])};return e.value=t,e.attached=mu(),e}const mr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,vu=(t,i,e,n,o,r)=>{const l=o==="svg";i==="class"?nu(t,n,l):i==="style"?ru(t,e,n):mo(i)?go(i)||du(t,i,e,n,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):bu(t,i,n,l))?(pr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&fr(t,i,n,l,r,i!=="value")):t._isVueCE&&(yu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Yt(n)))?pr(t,fe(i),n,r,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),fr(t,i,n,l))};function bu(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&mr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return mr(i)&&Yt(e)?!1:i in t}function yu(t,i){const e=t._def.props;if(!e)return!1;const n=fe(i);return Array.isArray(e)?e.some(o=>fe(o)===n):Object.keys(e).some(o=>fe(o)===n)}const Ji=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Kn(i,e):i};function ku(t){t.target.composing=!0}function gr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function vr(t,i,e){return i&&(t=t.trim()),e&&(t=yo(t)),t}const po={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ii]=Ji(o);const r=n||o.props&&o.props.type==="number";ui(t,i?"change":"input",l=>{l.target.composing||t[ii](vr(t.value,e,r))}),(e||r)&&ui(t,"change",()=>{t.value=vr(t.value,e,r)}),i||(ui(t,"compositionstart",ku),ui(t,"compositionend",gr),ui(t,"change",gr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:r}},l){if(t[ii]=Ji(l),t.composing)return;const s=(r||t.type==="number")&&!/^0\d/.test(t.value)?yo(t.value):t.value,a=i??"";if(s===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Un={deep:!0,created(t,i,e){t[ii]=Ji(e),ui(t,"change",()=>{const n=t._modelValue,o=$n(t),r=t.checked,l=t[ii];if(Ct(n)){const s=hs(n,o),a=s!==-1;if(r&&!a)l(n.concat(o));else if(!r&&a){const c=[...n];c.splice(s,1),l(c)}}else if(Qi(n)){const s=new Set(n);r?s.add(o):s.delete(o),l(s)}else l(Vl(t,r))})},mounted:br,beforeUpdate(t,i,e){t[ii]=Ji(e),br(t,i,e)}};function br(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(Ct(i))o=hs(i,n.props.value)>-1;else if(Qi(i))o=i.has(n.props.value);else{if(i===e)return;o=tn(i,Vl(t,!0))}t.checked!==o&&(t.checked=o)}const wu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,ui(t,"change",()=>{const o=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?yo($n(r)):$n(r));t[ii](t.multiple?Qi(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,cl(()=>{t._assigning=!1})}),t[ii]=Ji(n)},mounted(t,{value:i}){yr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ii]=Ji(e)},updated(t,{value:i}){t._assigning||yr(t,i)}};function yr(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!Qi(i))){for(let o=0,r=t.options.length;o<r;o++){const l=t.options[o],s=$n(l);if(e)if(n){const a=typeof s;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(s)):l.selected=hs(i,s)>-1}else l.selected=i.has(s);else if(tn($n(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function $n(t){return"_value"in t?t._value:t.value}function Vl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const xu=["ctrl","shift","alt","meta"],_u={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>xu.some(e=>t[`${e}Key`]&&!i.includes(e))},Te=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...r)=>{for(let l=0;l<i.length;l++){const s=_u[i[l]];if(s&&s(o,i))return}return t(o,...r)}))},Su={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Cu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const r=vi(o.key);if(i.some(l=>l===r||Su[l]===r))return t(o)}))},$u=le({patchProp:vu},eu);let kr;function Iu(){return kr||(kr=Ld($u))}const Kl=((...t)=>{const i=Iu().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=Tu(n);if(!o)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,Au(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function Au(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Tu(t){return Yt(t)?document.querySelector(t):t}function Eu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ke(t){const i=Eu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function Es(){var i;if(typeof window<"u"&&window.process)return window.process;const t=ke("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function ql(){var i,e;const t=Es();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=ke("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function In(){const t=Es();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=ke("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Gl(){var n,o;const t=Es(),i={...(t==null?void 0:t.env)||{}};if(In()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function ls(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function Bu(){const t=ke("os"),i=ke("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Bs{constructor(i){kt(this,"runner");this.runner=i||Bs.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=ke("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=In()==="win32",s=Gl();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:s},(c,d,u)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:u?String(u).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=ql(),e=In();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,r=!1,l;try{const s=await this.runner("node",["-v"]);s.code===0&&s.stdout.startsWith("v")&&(n=!0,o=s.stdout)}catch{}if(n){try{const s=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(s,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const s=e==="win32"?"npx.cmd":"npx",a=await this.runner(s,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class Mu{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pageChangedHandlers",[]);kt(this,"readyHandlers",[]);kt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class Du{constructor(i){kt(this,"childProcess",null);kt(this,"activePort",null);kt(this,"isRunning",!1);kt(this,"defaultPort");kt(this,"maxPortRetries");kt(this,"probeTimeoutMs");kt(this,"customSpawner");kt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=ke("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),n),s=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),s)return!0}catch{}await new Promise(r=>setTimeout(r,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const r=In()==="win32"?"npx.cmd":"npx",l=ls(i),s=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,s,{detached:!1});else{let u=(a=ke("child_process"))==null?void 0:a.spawn;if(!u){const k=await import("node:child_process").catch(()=>({}));u=k==null?void 0:k.spawn}if(!u)throw new Error("child_process spawn not available in current runtime");const m=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,f=Gl();this.childProcess=u(r,s,{cwd:m,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),In()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=ke("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var r;o(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ms{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pendingMessages",[]);kt(this,"slideChangedHandlers",[]);kt(this,"blockClickedHandlers",[]);kt(this,"openInEditorHandlers",[]);kt(this,"clientReadyHandlers",[]);kt(this,"openPeekDrawerHandlers",[]);kt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const Zl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Lu=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Pu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Ou=`${Go}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Ru(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const r=(o=n[1])==null?void 0:o.trim();r&&!i.includes(r)&&i.push(r)}return i}class zu{constructor(i){kt(this,"workspacePath");kt(this,"slidesFileName");kt(this,"cliBridge",new cs);const e=Bu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,s=ls(r),a=ls(l),c=Ru(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const b of c){const w=Zl[b]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${b}
// #endregion snippet
`;d.set(b,w)}i.slides.some(b=>{var w;return((w=b.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Lu),d.set("setup/root.ts",Pu),d.set("styles/index.css",Ou);const m=ke("fs"),f=ke("path");let k=!1;const h=f!=null&&f.dirname?f.dirname(s):"",y=/^[a-zA-Z]:[/\\]/.test(s)||s.includes("siyuan-slidev-pro");if(m&&f&&y)try{m.existsSync(h)||m.mkdirSync(h,{recursive:!0}),m.writeFileSync(a,o,"utf-8"),m.writeFileSync(s,n,"utf-8");for(const[b,w]of d.entries()){const _=f.join(h,b),T=f.dirname(_);m.existsSync(T)||m.mkdirSync(T,{recursive:!0}),m.existsSync(_)||m.writeFileSync(_,w,"utf-8")}k=!0}catch{}if(!k&&e)try{const b=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),w=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,w),await e(r,!1,b);for(const[_,T]of d.entries()){const x=`${this.workspacePath}/${_}`,$=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await e(x,!1,$).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}catch(b){return{success:!1,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l,error:String(b)}}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}}class Nu{constructor(){kt(this,"mode","web-sandbox");kt(this,"webBridge");kt(this,"cliBridge");kt(this,"nativeBridge");kt(this,"processManager");kt(this,"scaffolder");kt(this,"envDetector");this.webBridge=new Ms,this.cliBridge=new cs,this.nativeBridge=new Mu,this.processManager=new Du,this.scaffolder=new zu,this.envDetector=new Bs}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const r=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Fu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},ju={key:0},Hu={key:1},Uu={key:2},Wu={key:3},Vu={key:4},Ku={key:5},qu={key:6},Gu={key:7},Zu={key:8},Yu={key:9},Ju={key:10},Xu={key:11},Qu={key:12},tf={key:13},ef={key:14},nf={key:15},of={key:16},sf={key:17},rf={key:18},lf={key:19},af={key:20},cf={key:21},df={key:22},uf={key:23},ff={key:24},pf={key:25},hf={key:26},mf={key:27},gf={key:28},vf={key:29},bf={key:30},yf={key:31},kf={key:32},wf={key:33},xf={key:34},_f={key:35},Sf={key:36},Cf={key:37},$f={key:38},If={key:39},Af={key:40},Tf={key:41},Ef={key:42},Bf={key:43},Mf={key:44},Df={key:45},Lf={key:46},Pf={key:47},Of={key:48},Rf={key:49},zf={key:50},Nf={key:51},Ff={key:52},jf=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),it("svg",Fu,[t.name==="fullscreen"||t.name==="maximize"?(tt(),it("g",ju,[...e[0]||(e[0]=[v("polyline",{points:"15 3 21 3 21 9"},null,-1),v("polyline",{points:"9 21 3 21 3 15"},null,-1),v("polyline",{points:"21 15 21 21 15 21"},null,-1),v("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),it("g",Hu,[...e[1]||(e[1]=[v("polyline",{points:"4 14 10 14 10 20"},null,-1),v("polyline",{points:"20 10 14 10 14 4"},null,-1),v("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),v("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),it("g",Uu,[...e[2]||(e[2]=[v("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),v("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),it("g",Wu,[...e[3]||(e[3]=[v("path",{d:"M12 20h9"},null,-1),v("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),it("g",Vu,[...e[4]||(e[4]=[v("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),v("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),it("g",Ku,[...e[5]||(e[5]=[v("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),v("polyline",{points:"15 3 21 3 21 9"},null,-1),v("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),it("g",qu,[...e[6]||(e[6]=[v("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),v("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),it("g",Gu,[...e[7]||(e[7]=[v("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),v("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),it("g",Zu,[...e[8]||(e[8]=[v("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),v("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),it("g",Yu,[...e[9]||(e[9]=[v("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),it("g",Ju,[...e[10]||(e[10]=[v("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),v("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),it("g",Xu,[...e[11]||(e[11]=[v("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),v("polyline",{points:"7 9 12 14 17 9"},null,-1),v("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),it("g",Qu,[...e[12]||(e[12]=[v("path",{d:"M2 3h20"},null,-1),v("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),v("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),it("g",tf,[...e[13]||(e[13]=[v("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),v("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),it("g",ef,[...e[14]||(e[14]=[v("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),it("g",nf,[...e[15]||(e[15]=[v("path",{d:"M5 12h14"},null,-1),v("path",{d:"m12 5 7 7-7 7"},null,-1),v("path",{d:"M5 6h4"},null,-1),v("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),it("g",of,[...e[16]||(e[16]=[v("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),v("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),it("g",sf,[...e[17]||(e[17]=[v("polyline",{points:"16 18 22 12 16 6"},null,-1),v("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),it("g",rf,[...e[18]||(e[18]=[v("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),v("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),v("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),it("g",lf,[...e[19]||(e[19]=[v("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),v("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),v("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),it("g",af,[...e[20]||(e[20]=[v("path",{d:"m18 15-6-6"},null,-1),v("path",{d:"M4 20h16"},null,-1),v("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),it("g",cf,[...e[21]||(e[21]=[v("path",{d:"M3 6h18"},null,-1),v("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),v("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),it("g",df,[...e[22]||(e[22]=[v("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),it("g",uf,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(tt(),it("g",ff,[...e[24]||(e[24]=[v("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),v("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),it("g",pf,[...e[25]||(e[25]=[v("path",{d:"M8 3 4 7l4 4"},null,-1),v("path",{d:"M4 7h16"},null,-1),v("path",{d:"m16 21 4-4-4-4"},null,-1),v("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),it("g",hf,[...e[26]||(e[26]=[v("polyline",{points:"16 16 12 12 8 16"},null,-1),v("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),v("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),it("g",mf,[...e[27]||(e[27]=[v("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),v("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),v("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),it("g",gf,[...e[28]||(e[28]=[v("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),v("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),it("g",vf,[...e[29]||(e[29]=[v("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),v("path",{d:"M21 3v5h-5"},null,-1),v("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),v("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),it("g",bf,[...e[30]||(e[30]=[v("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),v("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),v("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),it("g",yf,[...e[31]||(e[31]=[v("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),it("g",kf,[...e[32]||(e[32]=[v("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),it("g",wf,[...e[33]||(e[33]=[v("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),v("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),it("g",xf,[...e[34]||(e[34]=[v("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),v("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),v("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),it("g",_f,[...e[35]||(e[35]=[v("circle",{cx:"11",cy:"11",r:"7"},null,-1),v("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),it("g",Sf,[...e[36]||(e[36]=[v("circle",{cx:"12",cy:"12",r:"3"},null,-1),v("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),it("g",Cf,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),it("g",$f,[...e[38]||(e[38]=[v("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),v("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),v("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),it("g",If,[...e[39]||(e[39]=[v("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),v("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),v("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),v("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),it("g",Af,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),it("g",Tf,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),it("g",Ef,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),it("g",Bf,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),it("g",Mf,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),it("g",Df,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),it("g",Lf,[...e[46]||(e[46]=[v("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),v("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),v("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),v("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),it("g",Pf,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),it("g",Of,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),it("g",Rf,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),it("g",zf,[...e[50]||(e[50]=[v("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),v("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),v("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),it("g",Nf,[...e[51]||(e[51]=[v("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),v("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),it("g",Ff,[...e[52]||(e[52]=[v("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),v("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),v("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Pe=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},yt=Pe(jf,[["__scopeId","data-v-b8552023"]]);function ne(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(r=>{for(const[l,s]of Object.entries(i))s!=null&&s!==""?r.setAttribute(l,String(s)):r.removeAttribute(l)})}function Hf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ut}], .protyle-wysiwyg [${Ht}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Ht),n.removeAttribute("custom-slidev-role");return}const r=t.get(o),l=(r==null?void 0:r[ut])||(r==null?void 0:r["custom-slidev-layout"])||"",s=n.getAttribute(ut)||n.getAttribute("custom-slidev-layout");s&&s!==l&&(l?n.setAttribute(ut,l):(n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[Ht])||(r==null?void 0:r["custom-slidev-role"])||"",c=n.getAttribute(Ht)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Ht,a):(n.removeAttribute(Ht),n.removeAttribute("custom-slidev-role")))})}const Uf={class:"spm-layout-picker"},Wf={class:"spm-layout-picker__grid"},Vf=["title","onClick"],Kf={class:"spm-layout-icon"},qf={class:"spm-layout-label"},Gf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),it("div",Uf,[l[0]||(l[0]=v("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),v("div",Wf,[(tt(),it(Ut,null,me(n,s=>v("div",{key:s.name,class:$t(["spm-layout-item",{active:t.modelValue===s.name}]),title:s.desc,onClick:a=>o(s.name)},[v("div",Kf,[dt(yt,{name:"layout-"+s.name},null,8,["name"])]),v("span",qf,St(s.label),1)],10,Vf)),64))])]))}}),Yl=Pe(Gf,[["__scopeId","data-v-c57441d5"]]),Zf={key:0,class:"spm-transition-selector__header"},Yf={class:"spm-transition-list"},Jf=["onClick"],Xf={class:"spm-transition-meta"},Qf={class:"spm-transition-label"},tp={class:"spm-transition-name"},ep={class:"spm-transition-preview-box"},ip=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),it("div",{class:$t(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Mt("",!0):(tt(),it("div",Zf,St(t.title||"转场动效"),1)),v("div",Yf,[(tt(),it(Ut,null,me(n,s=>v("div",{key:s.name,class:$t(["spm-transition-item",{active:t.modelValue===s.name}]),onClick:a=>o(s.name)},[v("div",Xf,[v("span",Qf,St(s.label),1),v("span",tp,"("+St(s.name)+")",1)]),v("div",ep,[v("div",{class:$t(["spm-anim-cube","anim-"+s.name])},null,2)])],10,Jf)),64))])],2))}}),Ds=Pe(ip,[["__scopeId","data-v-b0aa61ff"]]),np={class:"spm-divider-popover"},op={class:"spm-divider-popover__title"},sp={class:"spm-form-item"},rp={class:"spm-popover-footer"},lp={class:"spm-save-hint"},ap=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var m,f,k;const e=t,n=i,o=ft(((m=e.initialAttrs)==null?void 0:m[ut])||"default"),r=ft(((f=e.initialAttrs)==null?void 0:f[Zt])||"slide-left"),l=ft(((k=e.initialAttrs)==null?void 0:k[Nt])||""),s=ft("");Mi(()=>e.initialAttrs,h=>{o.value=(h==null?void 0:h[ut])||"default",r.value=(h==null?void 0:h[Zt])||"slide-left",l.value=(h==null?void 0:h[Nt])||""},{deep:!0});async function a(h,y){if(e.blockId){s.value="正在同步...",Rt.setBlockAttrOverride(e.blockId,{[h]:y}),ne(e.blockId,{[h]:y});try{await Ot(e.blockId,{[h]:y}),s.value="已同步至块属性",n("updated",{[h]:y}),setTimeout(()=>{s.value=""},1500)}catch{s.value="同步失败"}}}function c(h){a(ut,h)}function d(h){a(Zt,h)}function u(){a(Nt,l.value.trim())}return(h,y)=>(tt(),it("div",np,[v("div",op,[y[4]||(y[4]=v("span",null,"幻灯片页面设置",-1)),v("button",{class:"spm-close-btn",onClick:y[0]||(y[0]=b=>n("close"))},"✕")]),dt(Yl,{modelValue:o.value,"onUpdate:modelValue":y[1]||(y[1]=b=>o.value=b),onChange:c},null,8,["modelValue"]),dt(Ds,{modelValue:r.value,"onUpdate:modelValue":y[2]||(y[2]=b=>r.value=b),onChange:d},null,8,["modelValue"]),v("div",sp,[y[5]||(y[5]=v("label",{class:"spm-form-label"},"页面背景",-1)),Ie(v("input",{"onUpdate:modelValue":y[3]||(y[3]=b=>l.value=b),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:u},null,544),[[po,l.value]])]),v("div",rp,[v("span",lp,St(s.value),1)])]))}}),cp=Pe(ap,[["__scopeId","data-v-e4871368"]]),dp={class:"spm-slide-inspector"},up={class:"spm-inspector-header"},fp={class:"spm-inspector-list"},pp=["onClick"],hp={class:"spm-card-top"},mp={class:"spm-card-badge"},gp={class:"spm-card-layout"},vp=["onClick"],bp={class:"spm-card-preview"},yp={key:0,class:"spm-card-notes",title:"演讲备忘录"},kp={class:"spm-inspector-modal-content"},wp=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=ft(null);function o(c){n.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ut]=c.frontmatter.layout),c.frontmatter.transition&&(d[Zt]=c.frontmatter.transition),c.frontmatter.background&&(d[Nt]=c.frontmatter.background),c.notes&&(d[Fi]=c.notes),d}function l(c){n.value&&(c[ut]&&(n.value.frontmatter.layout=c[ut]),c[Zt]&&(n.value.frontmatter.transition=c[Zt]),c[Nt]&&(n.value.frontmatter.background=c[Nt]),c[Fi]&&(n.value.notes=c[Fi]),e("refresh"))}function s(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],u=d.content||d.rawMarkdown||"";return u.slice(0,40)+(u.length>40?"...":"")}return(c,d)=>(tt(),it("div",dp,[v("div",up,[v("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),v("div",fp,[(tt(!0),it(Ut,null,me(t.slides,u=>(tt(),it("div",{key:u.pageIndex,class:$t(["spm-card",{active:t.currentActivePage===u.pageIndex}]),onClick:m=>s(u.pageIndex)},[v("div",hp,[v("span",mp,"P"+St(u.pageIndex),1),v("span",gp,St(u.frontmatter.layout||"default"),1),v("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Te(m=>o(u),["stop"])},[dt(yt,{name:"settings"})],8,vp)]),v("div",bp,St(a(u)),1),u.notes?(tt(),it("div",yp,[dt(yt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),v("span",null,St(u.notes),1)])):Mt("",!0)],10,pp))),128))]),n.value?(tt(),it("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Te(u=>n.value=null,["self"]))},[v("div",kp,[dt(cp,{"block-id":n.value.startBlockId,"initial-attrs":r(n.value),onClose:d[0]||(d[0]=u=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Mt("",!0)]))}}),xp=Pe(wp,[["__scopeId","data-v-68b25edd"]]),_p={class:"spm-immersion-header"},Sp={class:"spm-immersion-header__left"},Cp={class:"spm-immersion-title"},$p={class:"spm-immersion-header__center"},Ip={class:"spm-immersion-header__actions"},Ap=["aria-label"],Tp={class:"spm-immersion-body"},Ep=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function r(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function s(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Ie((tt(),it("div",{class:$t(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Te(s,["stop"])},[v("div",{class:"spm-immersion-mask",onClick:r}),v("div",{class:$t(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[v("div",_p,[v("div",Sp,[Hn(a.$slots,"header-left",{},()=>[v("span",Cp,St(t.title),1)])]),v("div",$p,[Hn(a.$slots,"header-center",{},void 0)]),v("div",Ip,[Hn(a.$slots,"header-actions",{},void 0),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[dt(yt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Ap),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[dt(yt,{name:"close"})])])]),v("div",Tp,[Hn(a.$slots,"default",{},void 0)])],2)],34)),[[Wl,t.visible]])}}),Bp=Pe(Ep,[["__scopeId","data-v-3f1665db"]]),Mp="slidev-config.json",Xi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ti=xo({...Xi});function Dp(t){if(!t||typeof t!="object")return{...Xi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Xi.webServeUrl}}function qi(t){if(!t||typeof t!="object")return{...Ti};const i=t;return i.enableWebServeJump!==void 0&&(Ti.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ti.webServeUrl=String(i.webServeUrl)),{...Ti}}function Ls(){return{...Ti}}function Jl(t,i,e){const n=(t||Xi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let s=l.pathname.replace(/\/+$/,"");return s.endsWith("/stage/build/desktop")||(s=s?`${s}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${s}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const Lp={class:"spm-protyle-drawer"},Pp={class:"spm-protyle-drawer__subbar"},Op={class:"spm-protyle-drawer__nav"},Rp=["title"],zp={class:"spm-protyle-drawer__actions"},Np=["aria-label"],Fp=["aria-label"],jp=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(n.blockId),r=ft(n.title||""),l=ft(!1),s=ft(!0),a=ft(!1),c=ft(""),d=Ti,u=ft([]),m=ft(null);let f=null;Mi(()=>n.blockId,C=>{C&&C!==o.value&&(o.value=C,r.value=n.title||"",u.value=[],h(C))}),En(()=>{o.value&&h(o.value)}),Ss(()=>{y()});async function k(C){try{const B=await gn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(B)&&B.length>0){const M=B[0];c.value=M.root_id||"";const O=M.id===M.root_id||M.type==="d";a.value=O,s.value=!O,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(B){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",B)}a.value=!1,s.value=!0}async function h(C,B){if(!m.value||!C)return;y(),await k(C),typeof B=="boolean"&&(s.value=!a.value&&B);let M,O;s.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],O={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],O={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new mt.Protyle(n.plugin.app,m.value,{blockId:C,action:M,render:O}),!l.value&&f&&typeof f.disable=="function"&&f.disable()}catch(Z){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",Z)}}function y(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}f=null}m.value&&(m.value.innerHTML="")}function b(){a.value||(s.value=!s.value,h(o.value,s.value))}function w(){l.value=!l.value,f&&(l.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function _(){if(o.value)try{mt.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function T(){var M;if(!o.value)return;const C=Ls(),B=Jl(C.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const O=ke("electron");(M=O==null?void 0:O.shell)!=null&&M.openExternal?O.shell.openExternal(B).catch(()=>{window.open(B,"_blank")}):window.open(B,"_blank")}e("external-jump",B)}function x(){if(u.value.length>0){const C=u.value.pop();C&&(o.value=C.blockId,r.value=C.title,s.value=C.isFocusMode,a.value=C.isDoc,h(C.blockId,C.isFocusMode))}}function $(C){const B=C.target;if(!B)return;const M=B.closest('[data-type="block-ref"]');if(M){const Z=M.getAttribute("data-id");if(Z&&Z!==o.value){C.preventDefault(),C.stopPropagation(),u.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=Z,r.value=M.innerText.trim()||Z,h(Z);return}}const O=B.closest("a");if(O&&O.href&&O.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const Z=O.href.replace("siyuan://blocks/","").split("?")[0];Z&&Z!==o.value&&(u.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=Z,r.value=O.innerText.trim()||Z,h(Z))}}return(C,B)=>(tt(),it("div",Lp,[v("div",Pp,[v("div",Op,[u.value.length>0?(tt(),it("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[dt(yt,{name:"arrow-left"}),B[0]||(B[0]=v("span",null,"返回",-1))])):Mt("",!0),v("span",{class:$t(["spm-protyle-badge",{"is-focus":s.value&&!a.value}])},St(s.value&&!a.value?"思源块聚焦":"思源文档速览"),3),v("span",{class:"spm-protyle-id",title:r.value||o.value},St(r.value||o.value),9,Rp)]),v("div",zp,[a.value?Mt("",!0):(tt(),it("button",{key:0,class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":s.value}]),"aria-label":s.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[dt(yt,{name:s.value?"focus":"file-text"},null,8,["name"]),v("span",null,St(s.value?"块聚焦":"展开全文"),1)],10,Np)),v("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[dt(yt,{name:l.value?"edit":"eye"},null,8,["name"]),v("span",null,St(l.value?"编辑中":"只读"),1)],10,Fp),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[dt(yt,{name:"window"}),B[1]||(B[1]=v("span",null,"独立窗口",-1))]),ht(d).enableWebServeJump?(tt(),it("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[dt(yt,{name:"external-link"}),B[2]||(B[2]=v("span",null,"外跳",-1))])):Mt("",!0)])]),v("div",{ref_key:"mountEl",ref:m,class:$t(["spm-protyle-mount",{"is-focus-mode":s.value&&!a.value}]),onClick:$},null,2)]))}}),Hp=Pe(jp,[["__scopeId","data-v-7e586ef3"]]),Up={class:"spm-webview-drawer"},Wp={class:"spm-webview-toolbar"},Vp={class:"spm-webview-toolbar__nav"},Kp=["disabled"],qp=["disabled"],Gp=["aria-label"],Zp={class:"spm-webview-toolbar__address"},Yp=["aria-label"],Jp={class:"spm-webview-toolbar__actions"},Xp=["aria-label"],Qp={class:"spm-zoom-controller"},th=["disabled"],eh=["disabled"],ih={key:1,class:"spm-webview-fallback"},nh=["src"],wr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Xl="siyuan-slidev-peek-view-mode";let Ql="desktop";function oh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(Xl);if(t==="mobile"||t==="desktop")return t}catch{}return Ql}function sh(t){if(Ql=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Xl,t)}catch{}}const rh=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(ql()),r=ft(n.url),l=ft(n.url),s=ft(!1),a=ft(!1),c=ft(!1),d=ft(1),u=ft(!1),m=ft(oh());let f=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=_t(()=>m.value==="mobile"?wr:f||void 0),h=ft(null),y=ft(null);let b=null,w=null,_=null;Mi(()=>n.url,Q=>{Q&&Q!==r.value&&(r.value=Q,l.value=Q,m.value==="mobile"&&B(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q))}),Mi(()=>n.visible,Q=>{if(Q)U(),m.value==="mobile"&&B(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),En(()=>{T(),y.value&&typeof ResizeObserver<"u"&&(b=new ResizeObserver(()=>{const Q=h.value;if(Q&&typeof Q.invalidate=="function")try{Q.invalidate()}catch{}}),b.observe(y.value)),w=Q=>{var gt;const pt=Q.message||((gt=Q.error)==null?void 0:gt.message);if(typeof pt=="string"&&pt.includes("Invalid guestInstanceId"))return Q.preventDefault(),Q.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),_=Q=>{const pt=Q.reason,gt=typeof pt=="string"?pt:pt==null?void 0:pt.message;typeof gt=="string"&&gt.includes("Invalid guestInstanceId")&&Q.preventDefault()},window.addEventListener("unhandledrejection",_)}),Ss(()=>{if(x(),b&&(b.disconnect(),b=null),w&&(window.removeEventListener("error",w,!0),w=null),_&&(window.removeEventListener("unhandledrejection",_),_=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function T(){const Q=h.value;Q&&(Q.addEventListener("dom-ready",$),Q.addEventListener("did-start-loading",M),Q.addEventListener("did-stop-loading",O),Q.addEventListener("did-navigate",Z),Q.addEventListener("did-navigate-in-page",A),Q.addEventListener("new-window",E))}function x(){const Q=h.value;if(Q)try{Q.removeEventListener("dom-ready",$),Q.removeEventListener("did-start-loading",M),Q.removeEventListener("did-stop-loading",O),Q.removeEventListener("did-navigate",Z),Q.removeEventListener("did-navigate-in-page",A),Q.removeEventListener("new-window",E)}catch{}}function $(){const Q=h.value;if(Q&&typeof Q.getUserAgent=="function"&&!f)try{const pt=Q.getUserAgent();pt&&!pt.includes("iPhone")&&(f=pt)}catch{}m.value==="mobile"&&B(!1),U(),g()}function C(){const Q=m.value==="mobile"?"desktop":"mobile";m.value=Q,sh(Q),B(!0)}function B(Q=!1){const pt=h.value;if(!pt)return;const gt=m.value==="mobile"?wr:f;if(typeof pt.setUserAgent=="function"&&gt)try{pt.setUserAgent(gt)}catch(J){console.warn("[WebviewPeekDrawer] setUserAgent error:",J)}if(Q&&typeof pt.reload=="function")try{pt.reload()}catch(J){console.warn("[WebviewPeekDrawer] reload error:",J)}}function M(){s.value=!0}function O(){if(s.value=!1,g(),h.value&&typeof h.value.getURL=="function"){const Q=h.value.getURL();Q&&Q!=="about:blank"&&(r.value=Q,l.value=Q)}}function Z(Q){Q!=null&&Q.url&&(r.value=Q.url,l.value=Q.url),g()}function A(Q){Q!=null&&Q.url&&(r.value=Q.url,l.value=Q.url),g()}function E(Q){Q&&Q.url&&(Q.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q.url))}function g(){const Q=h.value;Q&&(typeof Q.canGoBack=="function"&&(a.value=Q.canGoBack()),typeof Q.canGoForward=="function"&&(c.value=Q.canGoForward()))}function F(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function z(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function P(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function H(){let Q=l.value.trim();Q&&(/^https?:\/\//i.test(Q)||(Q=`https://${Q}`),r.value=Q,l.value=Q,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q))}function U(){const Q=h.value;if(Q&&typeof Q.setZoomFactor=="function")try{Q.setZoomFactor(d.value)}catch(pt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pt)}}function X(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),U()}function K(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),U()}function q(){d.value=1,U()}function lt(Q){Q.preventDefault(),Q.deltaY<0?X():Q.deltaY>0&&K()}async function at(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Q){console.warn("Copy url failed:",Q)}}function st(){var pt;const Q=r.value;if(typeof window<"u"){const gt=ke("electron");(pt=gt==null?void 0:gt.shell)!=null&&pt.openExternal?gt.shell.openExternal(Q).catch(()=>{window.open(Q,"_blank")}):window.open(Q,"_blank")}e("external-jump",Q)}return(Q,pt)=>{const gt=dd("webview");return tt(),it("div",Up,[v("div",Wp,[v("div",Vp,[v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:F},[dt(yt,{name:"arrow-left"})],8,Kp),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:z},[dt(yt,{name:"arrow-right"})],8,qp),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":s.value?"正在加载...":"刷新页面",onClick:P},[dt(yt,{name:"refresh"})],8,Gp)]),v("div",Zp,[Ie(v("input",{"onUpdate:modelValue":pt[0]||(pt[0]=J=>l.value=J),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Cu(H,["enter"])},null,544),[[po,l.value]]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:at},[dt(yt,{name:"copy"})],8,Yp)]),v("div",Jp,[v("button",{class:$t(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:C},[dt(yt,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Xp),v("div",Qp,[v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:K},[dt(yt,{name:"minus"})],8,th),v("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:q},St(Math.round(d.value*100))+"% ",1),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:X},[dt(yt,{name:"plus"})],8,eh)]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[dt(yt,{name:"external-link"}),pt[1]||(pt[1]=v("span",null,"外跳",-1))])])]),v("div",{ref_key:"containerEl",ref:y,class:$t(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:Te(lt,["ctrl"])},[v("div",{class:$t(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[o.value?(tt(),Ee(gt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),it("div",ih,[v("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,nh),v("div",{class:"spm-fallback-bar"},[pt[2]||(pt[2]=v("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),v("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),lh=Pe(rh,[["__scopeId","data-v-40e35375"]]);class ah{constructor(){kt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class ch{constructor(i){kt(this,"blockToPageMap",new Map);kt(this,"debounceCtrl",new ah);kt(this,"activeBlockId","");kt(this,"activePageIndex",1);kt(this,"currentDocId","");kt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Di(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return mt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(s){console.warn("[SelectionMirror] openTab fallback failed:",s)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function dh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return ge(i.join(" "));const n=[];let o=[];const r=()=>{if(o.length>0){const l=o.join(" ");n.push(`<p class="slide-list-item-desc">${ge(l)}</p>`),o=[]}};for(const l of i){const s=l.match(/^(#{1,6})\s+(.*)$/);if(s){r();const a=s[1].length,c=s[2].trim();n.push(`<h${a} class="slide-list-item-title">${ge(c)}</h${a}>`)}else o.push(l)}return r(),n.join(`
`)}function uh(t){if(t.length===0)return"";const i=[];let e=[];const n=r=>{if(e.length>0){const l=e.join(" "),s=r?"slide-list-item-title":"slide-list-item-desc";i.push(`<p class="${s}">${ge(l)}</p>`),e=[]}};let o=!0;for(const r of t){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){n(o);const s=l[1].length,a=l[2].trim();i.push(`<h${s} class="slide-list-item-title">${ge(a)}</h${s}>`),o=!1}else e.push(r)}return n(o),i.join(`
`)+(i.length>0?`
`:"")}function ta(t,i,e){var m,f,k,h;const n=t.split(`
`);if(!n.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const r=[],l=[];let s=!1;for(let y=0;y<n.length;y++){const b=n[y];if(!b.trim())continue;const w=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(w){const $=w[1].length,C=Math.floor($/2);l.push({type:"task",level:C,checked:w[2].toLowerCase()==="x",text:w[3],media:[]});continue}const _=b.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const $=_[1].length,C=Math.floor($/2);l.push({type:"unordered",level:C,text:_[2],media:[]});continue}const T=b.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(s=!0);const $=T[1].length,C=Math.floor($/2);l.push({type:"ordered",level:C,text:T[2],media:[]});continue}const x=b.trim();if(!(!x||/^\{:.*?\}$/.test(x)))if(l.length>0){const $=x.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if($){const M=/\.gif(?:\?|$)/i.test($[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${oe($[1])}" src="${$[2]}" class="${M}" /></div>`);continue}if(x.match(/^<img\b[\s\S]*?\/?>$/i)){const B=x.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${B}</div>`);continue}if(/<video\b/i.test(x)){let B=x;if(!/<\/video>/i.test(B))for(;y+1<n.length&&!/<\/video>/i.test(B);)y++,B+=" "+n[y].trim();const M=((m=e==null?void 0:e.attributes)==null?void 0:m["custom-slidev-autoplay"])==="true"||/autoplay/i.test(B),O=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(B),Z=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-muted"])==="true"||M||/muted/i.test(B),A=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-controls"])==="false",E=B.match(/\bsrc=["']([^"']+)["']/i),g=E?E[1]:"",F=['class="slide-video-player"'];A||F.push("controls"),M&&(F.push("autoplay"),F.push("playsinline")),O&&F.push("loop"),Z&&F.push("muted"),F.push('preload="metadata"'),g&&F.push(`src="${g}"`);const z=B.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=z?z[1].trim():"";!P&&g&&(P=`<source src="${g}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${Z?"true":"false"}"><video ${F.join(" ")}>${P}</video></div>`);continue}l[l.length-1].text+=`
`+x}else r.push(x)}if(l.length===0)return null;const a=s?"ol":"ul",c=s?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",d=l.map(y=>{const b=dh(y.text),w=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",_=y.level||0,T=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",x=_>0?" slide-list-item--nested":"";if(y.type==="task"){const C=y.checked?' checked=""':"";return`<li class="pdf-task-item${x}"${T}><label><input type="checkbox" disabled=""${C}/> <span>${b}</span></label>${w}</li>`}return`<li${x?` class="${x.trim()}"`:""}${T}>${b}${w}</li>`}).join(`
`);return`${uh(r)}<${a} class="${c}">
${d}
</${a}>`}function fh(t,i,e){const n="pdf-block",o=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<o.length;a++){const c=o[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let u=d;if(!/<\/video>/i.test(u))for(;a+1<o.length&&!/<\/video>/i.test(u);)a++,u+=`
`+o[a];r.push(u);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var f,k,h,y;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const b=d[1].length;return`<h${b} class="slide-list-item-title">${ge(d[2].trim())}</h${b}>`}const u=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(u){const w=/\.gif(?:\?|$)/i.test(u[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${oe(u[1])}" src="${u[2]}" class="${w}" /></div>`}if(/<video\b/i.test(c)){const b=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),w=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-loop"])==="true"||/loop/i.test(c),_=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||b||/muted/i.test(c),T=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),$=x?x[1]:"",C=['class="slide-video-player"'];T||C.push("controls"),b&&C.push("autoplay playsinline"),w&&C.push("loop"),_&&C.push("muted"),C.push('preload="metadata"'),$&&C.push(`src="${$}"`);const B=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=B?B[1].trim():"";return!M&&$&&(M=`<source src="${$}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${b?"true":"false"}" data-muted="${_?"true":"false"}"><video ${C.join(" ")}>${M}</video></div>`}const m=ta(c,i,e);return m||`<p class="slide-list-item-desc">${ge(c)}</p>`}).filter(Boolean).join(`
`)}function ph(t,i){var r,l,s,a,c,d,u,m;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right");if(e==="two-cols"){const f=o.some(B=>B.slot==="right");let k=[],h=[];if(f)k=o.filter(B=>B.slot!=="right"),h=o.filter(B=>B.slot==="right");else{const B=Math.ceil(o.length/2);k=o.slice(0,B),h=o.slice(B)}const y=k.map(B=>Re(B,i)).join(`
`),b=h.map(B=>Re(B,i)).join(`
`),w="pdf-two-cols-wrapper layout-two-cols-grid",_=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"",T="pdf-col pdf-col--left",x="pdf-col pdf-col--right",C=`style="grid-template-columns: ${zn((s=t.frontmatter)==null?void 0:s.layoutRatio,2)};"`;return`
      <div class="${w}${_}" ${C}>
        <div class="${T}">${y}</div>
        <div class="${x}">${b}</div>
      </div>
    `}if(e==="two-cols-header"){let f=[];const k=o.filter(B=>B.slot==="header");if(k.length>0)f=k;else if(o.length>0){const B=o.find(M=>M.type==="h"&&(!M.slot||M.slot==="default"));B&&(f=[B])}const h=o.filter(B=>!f.includes(B)),y=h.filter(B=>B.slot==="right"||B.slot==="col-2"),b=h.filter(B=>!y.includes(B)),w=B=>{const M=B.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if(M.length>0){const O=M[0],Z=(O.rawMarkdown||O.content||"").trim();(Gi(O)||/^(?:[-*+]|\d+\.)\s+/.test(Z))&&(O.rawMarkdown=Ko(O.rawMarkdown||O.content||""),O.content=O.rawMarkdown)}return M.map(O=>Re(O,i)).join(`
`)},_=f.map(B=>Re(B,i)).join(`
`),T=w(b),x=w(y),C=`style="grid-template-columns: ${zn((a=t.frontmatter)==null?void 0:a.layoutRatio,2)};"`;return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${_}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid" ${C}>
          <div class="pdf-col pdf-col--left">${T}</div>
          <div class="pdf-col pdf-col--right">${x}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let f=[];const k=o.filter(O=>O.slot==="header");if(k.length>0)f=k;else if(o.length>0){const O=o.find(Z=>Z.type==="h"&&(!Z.slot||Z.slot==="default"));O&&(f=[O])}const h=o.filter(O=>!f.includes(O)),{col1:y,col2:b,col3:w}=zr(h),_=O=>{const Z=O.filter(A=>!!(A.rawMarkdown||A.content||"").trim());if(Z.length>0){const A=Z[0],E=(A.rawMarkdown||A.content||"").trim();(Gi(A)||/^(?:[-*+]|\d+\.)\s+/.test(E))&&(A.rawMarkdown=Ko(A.rawMarkdown||A.content||""),A.content=A.rawMarkdown)}return Z.map(A=>Re(A,i)).join(`
`)},T=f.map(O=>Re(O,i)).join(`
`),x=_(y),$=_(b),C=_(w),M=`style="grid-template-columns: ${zn((c=t.frontmatter)==null?void 0:c.layoutRatio,3)};"`;return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${T}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid" ${M}>
          <div class="pdf-col pdf-col--1">${x}</div>
          <div class="pdf-col pdf-col--2">${$}</div>
          <div class="pdf-col pdf-col--3">${C}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",k=o.map(T=>Re(T,i)).join(`
`),h=((d=t.frontmatter)==null?void 0:d.image)||((u=t.frontmatter)==null?void 0:u.background)||"",y=`<div class="pdf-image-col" style="background-image:url('${oe(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${oe(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,b=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${k}</div>`,w=f?`${b}
${y}`:`${y}
${b}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${zn((m=t.frontmatter)==null?void 0:m.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${w}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(k=>Re(k,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(k=>Re(k,i)).join(`
`)}</div>`:o.map(f=>Re(f,i)).join(`
`)}function oe(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function hh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[r,l]=o.split("-"),s=parseInt(r,10),a=parseInt(l,10);if(!isNaN(s)&&!isNaN(a))for(let c=Math.min(s,a);c<=Math.max(s,a);c++)i.add(c)}else{const r=parseInt(o,10);isNaN(r)||i.add(r)}}return i}const mh=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ge(t){if(!t)return"";const i=Or(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const s=l.toLowerCase();if(!mh.has(s)||/on\w+\s*=|javascript:/i.test(r))return r;if(s==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let o=oe(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,s,a,c,d,u)=>{const f=(s??a??c??d??u??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${f}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{const c=/\.gif(?:\?|$)/i.test(s)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${s}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{if(s.startsWith("siyuan://blocks/")){const a=s.replace("siyuan://blocks/","").split("?")[0];return`<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${s}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,s,a)=>`${l}<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${s}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const s=parseInt(l,10);return e[s]||""}),o}function gh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${ge(a)}</th>`).join("")}</tr></thead>`,s=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${ge(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${s}</tbody></table>`}function jo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function vh(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${jo(t)}</span>`;const e=[];function n(r,l){return e.push(`<span class="${r}">${jo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(r,l,s)=>n("token-string",`${l}${s}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>n("token-keyword",r)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>n("token-type",r)),o=o.replace(/\b(\d+)\b/g,r=>n("token-number",r)),o=jo(o),o=o.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),o}function bh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function yh(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const u=bh(c,d+1);u&&r.push(u)});const l=[];let s=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),s=d):s?(d.active&&(s.hasActiveChild=!0),s.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const u=[];for(const m of c){const f=a(m.children,d+1);d>=n?u.push({...m,children:f}):u.push(...f)}return u}return a(l,1)}function kh(t,i=1,e={}){const n=yh(t,i,e),o=e.columns?Number(e.columns):1,r=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function s(c,d=1){if(!c||c.length===0)return"";const u=`slidev-toc-list slidev-toc-list-level-${d}`,m=c.map(f=>{const k=f.active?" slidev-toc-item-active":f.hasActiveChild?" slidev-toc-item-parent-active":"",h=f.children&&f.children.length>0?s(f.children,d+1):"";let y=ge(f.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${f.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${y}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${u}">${m}</ol>`}const a=s(n,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Re(t,i){var y,b,w,_,T,x,$,C,B;let e="",n="",o="";const r=[];(y=t.motion)!=null&&y.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),o=" slide-styled-block"),r.length>0&&(n=` style="${oe(r.join(";"))}"`);const a=`pdf-block${e}${o}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${n}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${n}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${n}><div class="katex-display font-math"><em>${oe(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,O=ge(d[2]);return`<div class="${a}"${n}><h${M}>${O}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),Z=M[0].replace(/^:::\s*/,"").trim()||"info",A=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),E="pdf-callout";return`<div class="${a}"${n}><div class="${E} ${E}--${Z}"><div class="${E}-title">${Z.toUpperCase()}</div><div class="${E}-body">${ge(A)}</div></div></div>`}if(c.startsWith("<<<")){const Z=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((F,z)=>`<span class="code-line shiki-focus"><span class="line-no">${z+1}</span><span class="line-content">${vh(F,"ts")}</span></span>`).join(`
`),A="pdf-code shiki-container",E=((w=t.attrs)==null?void 0:w["custom-slidev-max-height"])||t.maxHeight||"",g=E?` style="max-height:${oe(E)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${A}"${g}><span class="lang-badge">TS</span><code>${Z}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),O=M[0].slice(3).trim(),Z=O.match(/^([^\s{\[]+)/),A=Z?Z[1]:"",E=O.match(/\[([^\]]+)\]/),g=E?E[1]:"",F=O.includes("twoslash"),z=t.shikiLines||((_=O.match(/\{([^}]+)\}/))==null?void 0:_[1])||"",P=hh(z),H=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],U="pdf-code shiki-container",X=g?`${U} has-filename`:U,K=P!=="all",q=H.map((pt,gt)=>{const J=gt+1,vt=P==="all"||P.has(J)?"code-line shiki-focus":K?"code-line shiki-dimmed":"code-line";let D=oe(pt);return F&&pt.includes("doubled.value = 2")?(D=D.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${vt}"><span class="line-no">${J}</span><span class="line-content">${D}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${vt}"><span class="line-no">${J}</span><span class="line-content">${D}</span></span>`}).join(`
`),lt=A?`<span class="lang-badge">${oe(A)}</span>`:"",at=g?`<span class="code-filename">${oe(g)}</span>`:"",st=((T=t.attrs)==null?void 0:T["custom-slidev-max-height"])||t.maxHeight||"",Q=st?` style="max-height:${oe(st)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${X}"${Q}>${at}${lt}<code>${q}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(Z=>Z.trim().startsWith("|")),O=gh(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${n}>${O}</div>`}if(c.startsWith("> "))return`<div class="${a}"${n}><blockquote class="pdf-quote"><p>${ge(c.slice(2))}</p></blockquote></div>`;const u=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),f=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(u&&!m&&!f&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),O=(($=t.attributes)==null?void 0:$["custom-slidev-loop"])==="true"||/loop/i.test(c),Z=((C=t.attributes)==null?void 0:C["custom-slidev-muted"])==="true"||M||/muted/i.test(c),A=((B=t.attributes)==null?void 0:B["custom-slidev-controls"])==="false",E=c.match(/\bsrc=["']([^"']+)["']/i),g=E?E[1]:"",F=['class="slide-video-player"'];A||F.push("controls"),M&&(F.push("autoplay"),F.push("playsinline")),O&&F.push("loop"),Z&&F.push("muted"),F.push('preload="metadata"'),g&&F.push(`src="${g}"`);const z=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=z?z[1].trim():"";return!P&&g&&(P=`<source src="${g}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${Z?"true":"false"}"${n}><video ${F.join(" ")}>${P}</video></div>`}const k=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(k)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${n}><img alt="${oe(k[1])}" src="${k[2]}" class="pdf-image slide-media-img" /></div>`;const h=ta(c,i,t);if(h)return`<div class="${a} pdf-list-item"${n}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),O=c.match(/maxDepth=["']?(\d+)["']?/i),Z=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${n}>${kh([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:O?parseInt(O[1],10):1/0,columns:Z?parseInt(Z[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||f){const M=fh(c,i,t);if(M)return`<div class="${a}"${n}>${M}</div>`}return`<div class="${a}"${n}><p>${ge(c)}</p></div>`}function wh(t){return`
    ${dn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function xh(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function ea(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${oe(e)}</title>
  <style>
${wh(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${xh()}
  <\/script>
</body>
</html>`}function ia(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function _h(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Sh(t){const i=_h(t==null?void 0:t.pageRatio);return`
    ${dn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function Ch(t,i){const e="Slidev 演示讲义",n="16:9",o="light",r=t.slides.map((l,s)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:t.config.spacing||"normal",u=ph(l),m=`${s+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${oe(e)}</span>
          ${`<span class="pdf-page-badge">P. ${m}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${u}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${oe(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${oe(e)} - 高保真讲义</title>
  <style>
    ${Sh({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body>
  ${r}
</body>
</html>`}function na(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=Ch(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(o=r.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var s,a;try{(s=r.contentWindow)==null||s.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const $h={class:"spm-slidev-preview-tab"},Ih={class:"spm-slidev-tab__toolbar"},Ah={class:"spm-slidev-tab__actions"},Th=["disabled"],Eh={class:"spm-page-badge"},Bh=["disabled"],Mh=["aria-label"],Dh=["aria-label"],Lh=["src"],Ph=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ti("plugin"),n=ti("sandboxBridge",new Ms),o=new ch(n),r=new Nu,l=ft("web-sandbox"),s=ft(3030),a=ft(null),c=ft(!1),d=ft(null),u=ft(1),m=ft(1),f=ft([]),k=ft(!1),h=ft(!1),y=ft(!1),b=ft("siyuan"),w=ft(""),_=ft(""),T=ft(""),x=ft(!1),$=ft(!1),C=ft(""),B=ft("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,O=null,Z=null,A=null,E=null,g=null,F=null;En(()=>{d.value&&(n.attach(d.value),r.nativeBridge.attach(d.value)),M=n.onSlideChanged((J,rt)=>{u.value=J,m.value=rt}),O=n.onBlockClicked((J,rt)=>{u.value=rt,o.setActiveBlockId(J),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(J,rt):Di(J,e==null?void 0:e.app)}),Z=n.onOpenInEditor((J,rt)=>{u.value=rt,o.setActiveBlockId(J),Di(J,e==null?void 0:e.app)}),A=r.nativeBridge.onPageChanged((J,rt)=>{u.value=J,m.value=rt}),E=n.onOpenPeekDrawer(async J=>{const rt=Ls();if(J.peekType==="siyuan"&&rt.enableWebServeJump){let vt=!1;if(F&&F.docId===J.target)vt=!0;else if(F&&F.slides&&F.slides.some(D=>{var N;return(N=D.blocks)==null?void 0:N.some(p=>p.id===J.target)}))vt=!1;else try{const D=await gn(`SELECT id, root_id, type FROM blocks WHERE id = '${J.target}' LIMIT 1`);D&&D.length>0&&(vt=D[0].type==="d"||D[0].id===D[0].root_id)}catch(D){console.warn("[SlidevPreviewTab] detect block type failed:",D)}b.value="web",x.value=!0,_.value=Jl(rt.webServeUrl,J.target,{focus:!vt}),T.value=J.title||`${vt?"思源文档":"思源块"}: ${J.target.slice(0,8)}`,h.value=!0,n.freezeKeyboardNav(!0)}else b.value=J.peekType,J.peekType==="siyuan"?(w.value=J.target,T.value=J.title||`块速览: ${J.target.slice(0,8)}`):(x.value=!0,_.value=J.target,T.value=J.title||J.target),h.value=!0,n.freezeKeyboardNav(!0)}),g=n.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",at)}),Cs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",at),E&&E(),g&&g(),M&&M(),O&&O(),Z&&Z(),A&&A(),n.detach(),o.destroy(),r.destroy()});async function z(){if(l.value==="web-sandbox"){if(!F){mt.showMessage("请先在主编辑区打开演示文档");return}mt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const J=await r.startProMode(F,Wo);if(!J.success){mt.showMessage(`无法启动官方 Pro 模式：${J.error}`);return}l.value="pro-cli",s.value=J.port||3030,B.value=J.url,d.value&&r.nativeBridge.attach(d.value),mt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${s.value})`)}else r.stopProMode(),l.value="web-sandbox",B.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),mt.showMessage("已切回内置高保真沙箱")}function P(){$.value=!$.value,$.value?C.value=(F==null?void 0:F.docId)||"":(C.value="",K())}function H(){u.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(u.value-1):n.navigatePage(u.value-1))}function U(){u.value<m.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(u.value+1):n.navigatePage(u.value+1))}function X(J){u.value=J,l.value==="pro-cli"?r.nativeBridge.navigateToPage(J):n.navigatePage(J)}function K(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function q(){h.value=!1,n.freezeKeyboardNav(!1)}function lt(){q()}function at(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const J=a.value||d.value;J&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):J.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function Q(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function pt(){if(!F){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const J=ea(F);ia("presentation.html",J)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function gt(){if(!F){mt.showMessage("请先在主编辑区打开幻灯片文档");return}na(F)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(J,rt){$.value&&C.value&&rt&&rt!==C.value||(F=J,$.value&&!C.value&&(C.value=J.docId),f.value=J.slides,m.value=J.slides.length,o.setDocId(J.docId),o.updateSlidesIndex(J.slides),l.value==="pro-cli"?r.scaffolder.scaffold(J,Wo).catch(()=>{}):n.updateSlides(J.slides,J.config,J.fullMarkdown,J.customThemeCss))},navigateToBlock(J){o.onCursorFocusBlock(J)},isPinned:$,pinnedDocId:C,engineMode:l,toggleEngineMode:z}),(J,rt)=>(tt(),it("div",$h,[v("div",Ih,[rt[4]||(rt[4]=v("div",{class:"spm-slidev-tab__title"},[v("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[v("use",{"xlink:href":"#iconSlidev"})]),v("span",null,"Slidev 演示预览")],-1)),v("div",Ah,[v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value<=1,"aria-label":"上一页",onClick:H},[dt(yt,{name:"chevron-left"})],8,Th),v("span",Eh,St(u.value)+" / "+St(m.value||1),1),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value>=m.value,"aria-label":"下一页",onClick:U},[dt(yt,{name:"chevron-right"})],8,Bh),v("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":$.value}]),"aria-label":$.value?"已锁定当前文档（点击解除）："+C.value:"点击锁定当前文档（不随主编辑区切换）",onClick:P},[dt(yt,{name:"pin"}),v("span",null,St($.value?"已锁定":"跟随"),1)],10,Mh),v("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+s.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:z},[dt(yt,{name:"step"}),v("span",null,St(l.value==="pro-cli"?"Pro ("+s.value+")":"沙箱"),1)],10,Dh),rt[3]||(rt[3]=v("span",{class:"spm-toolbar-divider"},null,-1)),v("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:rt[0]||(rt[0]=vt=>k.value=!k.value)},[dt(yt,{name:"outline"})],2),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:Q},[dt(yt,{name:"presenter"})]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:pt},[dt(yt,{name:"export-html"})]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:gt},[dt(yt,{name:"export-pdf"})]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:K},[dt(yt,{name:"refresh"})]),v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[dt(yt,{name:"fullscreen"})])])]),v("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[v("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:B.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Lh),dt(Bp,{visible:h.value,"onUpdate:visible":rt[1]||(rt[1]=vt=>h.value=vt),"is-maximized":y.value,"onUpdate:isMaximized":rt[2]||(rt[2]=vt=>y.value=vt),title:T.value,onClose:q},{default:hl(()=>[b.value==="siyuan"&&w.value?(tt(),Ee(Hp,{key:0,"block-id":w.value,title:T.value,plugin:ht(e),onExternalJump:lt},null,8,["block-id","title","plugin"])):Mt("",!0),x.value?Ie((tt(),Ee(lh,{key:1,visible:h.value&&b.value==="web",url:_.value,title:T.value,onExternalJump:lt},null,8,["visible","url","title"])),[[Wl,b.value==="web"]]):Mt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&f.value.length>0?(tt(),Ee(xp,{key:0,slides:f.value,"current-active-page":u.value,onNavigate:X,onRefresh:K},null,8,["slides","current-active-page"])):Mt("",!0)]))}}),Oh=Pe(Ph,[["__scopeId","data-v-2622f6d8"]]),Rh={class:"spm-section spm-section--page"},zh={class:"spm-section-header"},Nh={key:0,class:"spm-card-control"},Fh={class:"spm-control-header"},jh={class:"spm-control-title-group"},Hh={class:"spm-control-title"},Uh={class:"spm-quick-chips"},Wh=["onClick"],Vh={style:{display:"flex",gap:"8px","align-items":"center","margin-top":"6px"}},Kh=["value"],qh={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.75",display:"flex","align-items":"center",gap:"4px"}},Gh={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px"}},Zh={class:"spm-card-control"},Yh={class:"spm-control-header"},Jh={class:"spm-control-title-group"},Xh={class:"spm-control-title"},Qh={class:"spm-segmented-group"},tm={class:"spm-card-control"},em={class:"spm-control-header"},im={class:"spm-control-title-group"},nm={class:"spm-control-title"},om={class:"spm-quick-chips"},sm=["onClick"],rm=["value"],lm={key:1,class:"spm-card-control"},am={class:"spm-control-header"},cm={class:"spm-control-title-group"},dm={class:"spm-control-title"},um={class:"spm-quick-chips"},fm=["onClick"],pm=["value"],hm={class:"spm-card-control"},mm={class:"spm-control-header"},gm={class:"spm-control-title-group"},vm={class:"spm-control-title"},bm={key:0,class:"spm-note-status-box"},ym=["title"],km={class:"spm-action-grid",style:{"margin-top":"6px"}},wm={key:1,class:"spm-note-empty-box"},xm={class:"spm-card-control"},_m={class:"spm-action-grid"},Sm=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=_t(()=>["two-cols","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),o=_t(()=>e.pageLayout==="three-cols-header"),r=_t(()=>o.value?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]),l=_t(()=>e.pageLayoutRatio||""),s=_t(()=>{if(!e.pageNotes)return"";const d=e.pageNotes.replace(/[\r\n]+/g," ").trim();return d.length>50?d.slice(0,50)+"...":d}),a=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],c=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(d,u)=>(tt(),it("div",Rh,[v("div",zh,[v("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),dt(Yl,{"model-value":t.pageLayout,onChange:u[0]||(u[0]=m=>d.$emit("update:pageLayout",m))},null,8,["model-value"]),n.value?(tt(),it("div",Nh,[v("div",Fh,[v("div",jh,[v("div",Hh,[dt(yt,{name:"ratio"}),u[20]||(u[20]=v("span",null,"分栏比例 (Ratio)",-1))]),u[21]||(u[21]=v("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))]),t.detectedSbRatio?(tt(),it("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"从当前页思源超级块读取实际宽度比例",onClick:u[1]||(u[1]=m=>d.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[dt(yt,{name:"sparkles"}),u[22]||(u[22]=v("span",null,"从超级块读取",-1))])):Mt("",!0)]),v("div",Uh,[(tt(!0),it(Ut,null,me(r.value,m=>(tt(),it("button",{key:m.value,class:$t(["spm-chip",{active:l.value===m.value}]),onClick:f=>d.$emit("update:pageLayoutRatio",m.value)},St(m.label),11,Wh))),128))]),v("div",Vh,[v("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:u[2]||(u[2]=m=>d.$emit("update:pageLayoutRatio",m.target.value)),onChange:u[3]||(u[3]=m=>d.$emit("update:pageLayoutRatio",m.target.value))},null,40,Kh),t.pageLayoutRatio?(tt(),it("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"重置为默认平均分配",style:{"flex-shrink":"0",padding:"0 10px",height:"28px"},onClick:u[4]||(u[4]=m=>d.$emit("update:pageLayoutRatio",""))}," 重置 ")):Mt("",!0)]),t.detectedSbRatio?(tt(),it("div",qh,[u[23]||(u[23]=v("span",null,"📐 检测到思源超级块宽度：",-1)),v("code",Gh,St(t.detectedSbRatio),1)])):Mt("",!0)])):Mt("",!0),dt(Ds,{"model-value":t.pageTransition,onChange:u[5]||(u[5]=m=>d.$emit("update:pageTransition",m))},null,8,["model-value"]),v("div",Zh,[v("div",Yh,[v("div",Jh,[v("div",Xh,[dt(yt,{name:"ratio"}),u[24]||(u[24]=v("span",null,"页面间距 (Spacing)",-1))]),u[25]||(u[25]=v("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),v("div",Qh,[v("button",{class:$t(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:u[6]||(u[6]=m=>d.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),v("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:u[7]||(u[7]=m=>d.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),v("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:u[8]||(u[8]=m=>d.$emit("update:pageSpacing","normal"))}," 标准 ",2),v("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:u[9]||(u[9]=m=>d.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),v("div",tm,[v("div",em,[v("div",im,[v("div",nm,[dt(yt,{name:"palette"}),u[26]||(u[26]=v("span",null,"页面背景 (Background)",-1))]),u[27]||(u[27]=v("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),v("div",om,[(tt(),it(Ut,null,me(a,m=>v("button",{key:m.value,class:$t(["spm-chip",{active:t.pageBackground===m.value}]),onClick:f=>d.$emit("update:pageBackground",m.value)},St(m.label),11,sm)),64))]),v("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:u[10]||(u[10]=m=>d.$emit("update:pageBackground",m.target.value)),onChange:u[11]||(u[11]=m=>d.$emit("update:pageBackground",m.target.value))},null,40,rm)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),it("div",lm,[v("div",am,[v("div",cm,[v("div",dm,[dt(yt,{name:"image"}),u[28]||(u[28]=v("span",null,"页面图片 (Image)",-1))]),u[29]||(u[29]=v("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),v("div",um,[(tt(),it(Ut,null,me(c,m=>v("button",{key:m.value,class:$t(["spm-chip",{active:t.pageImage===m.value}]),onClick:f=>d.$emit("update:pageImage",m.value)},St(m.label),11,fm)),64))]),v("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:u[12]||(u[12]=m=>d.$emit("update:pageImage",m.target.value)),onChange:u[13]||(u[13]=m=>d.$emit("update:pageImage",m.target.value))},null,40,pm)])):Mt("",!0),v("div",hm,[v("div",mm,[v("div",gm,[v("div",vm,[dt(yt,{name:"presenter"}),u[30]||(u[30]=v("span",null,"演讲者提词 (Notes)",-1))]),u[31]||(u[31]=v("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),v("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:u[14]||(u[14]=m=>d.$emit("generateNotes"))},[dt(yt,{name:"sparkles"}),u[32]||(u[32]=v("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),it("div",bm,[u[35]||(u[35]=v("div",{class:"spm-note-status-badge"},[v("span",{class:"spm-badge-dot"}),v("span",null,"已配置正文讲稿")],-1)),v("div",{class:"spm-note-preview-text",title:t.pageNotes},St(s.value),9,ym),v("div",km,[v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:u[15]||(u[15]=m=>d.$emit("locateNoteBlock"))},[dt(yt,{name:"search"}),u[33]||(u[33]=v("span",null,"定位讲稿块",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:u[16]||(u[16]=m=>d.$emit("addNoteBlock"))},[dt(yt,{name:"insert-below"}),u[34]||(u[34]=v("span",null,"追加讲稿块",-1))])])])):(tt(),it("div",wm,[u[37]||(u[37]=v("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:u[17]||(u[17]=m=>d.$emit("addNoteBlock"))},[dt(yt,{name:"insert-below"}),u[36]||(u[36]=v("span",null,"添加讲稿备注块",-1))])]))]),v("div",xm,[u[40]||(u[40]=v("div",{class:"spm-control-header"},[v("div",{class:"spm-control-title-group"},[v("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),v("div",_m,[v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:u[18]||(u[18]=m=>d.$emit("insertDividerAfter"))},[dt(yt,{name:"insert-below"}),u[38]||(u[38]=v("span",null,"插入新页",-1))]),v("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:u[19]||(u[19]=m=>d.$emit("deleteDivider"))},[dt(yt,{name:"trash"}),u[39]||(u[39]=v("span",null,"删除此页",-1))])])])]))}}),Cm=Pe(Sm,[["__scopeId","data-v-58d81c02"]]),$m={class:"spm-section spm-section--block"},Im={class:"spm-card-control"},Am={class:"spm-control-header"},Tm={class:"spm-control-title-group"},Em={class:"spm-control-title"},Bm=["aria-label"],Mm=["checked"],Dm={key:0,class:"spm-card-control"},Lm={class:"spm-control-header"},Pm={class:"spm-control-title-group"},Om={class:"spm-control-title"},Rm={class:"spm-quick-chips"},zm={key:1,class:"spm-card-control"},Nm={class:"spm-control-header"},Fm={class:"spm-control-title-group"},jm={class:"spm-control-title"},Hm={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Um={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Wm=["aria-label"],Vm=["checked"],Km={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},qm=["aria-label"],Gm=["checked"],Zm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Ym=["aria-label"],Jm=["checked"],Xm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Qm=["aria-label"],tg=["checked"],eg={class:"spm-card-control"},ig={class:"spm-control-header"},ng={class:"spm-control-title-group"},og={class:"spm-control-title"},sg=["aria-label"],rg=["checked"],lg={key:0,class:"spm-quick-chips"},ag=["onClick"],cg={class:"spm-card-control"},dg={class:"spm-control-header"},ug={class:"spm-control-title-group"},fg={class:"spm-control-title"},pg=["aria-label"],hg=["checked"],mg={key:0,class:"spm-quick-chips"},gg=["onClick"],vg={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},bg={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},yg={style:{display:"flex",gap:"6px"}},kg=["value"],wg=["value"],xg={key:2,class:"spm-card-control"},_g={class:"spm-control-header"},Sg={class:"spm-control-title-group"},Cg={class:"spm-control-title"},$g={class:"spm-control-desc"},Ig={class:"spm-segmented-group"},Ag=["onClick"],Tg={key:3,class:"spm-card-control"},Eg={class:"spm-control-header"},Bg={class:"spm-control-title-group"},Mg={class:"spm-control-title"},Dg={class:"spm-quick-chips"},Lg=["onClick"],Pg=["value"],Og={key:4,class:"spm-card-control"},Rg={class:"spm-control-header"},zg={class:"spm-control-title-group"},Ng={class:"spm-control-title"},Fg={class:"spm-quick-chips"},jg=["onClick"],Hg=["value"],Ug={class:"spm-card-control"},Wg={class:"spm-action-grid"},Vg=["aria-label"],Kg=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=_t(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),o=_t(()=>{const x=n.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=_t(()=>{const x=n.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=_t(()=>{const x=n.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),s=_t(()=>{const x=n.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const $=e.elemSlot||"";return x?$===x||x==="col-1"&&$==="left"||x==="col-2"&&$==="center"||x==="col-3"&&$==="right"||x==="left"&&$==="col-1"||x==="right"&&($==="col-2"||$==="col-3"):!$||$==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],u=_t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),m=_t(()=>!!u.value),f=_t(()=>{var x;return((x=u.value)==null?void 0:x.preset)||"slide-up"}),k=_t(()=>{var x;return((x=u.value)==null?void 0:x.duration)||0}),h=_t(()=>{var x;return((x=u.value)==null?void 0:x.delay)||0});function y(){m.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function b(x){T(x,k.value,h.value)}function w(x){T(f.value,x,h.value)}function _(x){T(f.value,k.value,x)}function T(x,$,C){if(!x||x==="none"){c("update:elemMotion","");return}if(!$&&!C){c("update:elemMotion",x);return}const B={preset:x};$>0&&(B.duration=$),C>0&&(B.delay=C),c("update:elemMotion",JSON.stringify(B))}return(x,$)=>(tt(),it("div",$m,[$[53]||($[53]=v("div",{class:"spm-section-header"},[v("span",null,"元素动效与排版")],-1)),v("div",Im,[v("div",Am,[v("div",Tm,[v("div",Em,[dt(yt,{name:"presenter"}),$[22]||($[22]=v("span",null,"设为讲稿备注 (slidev-note)",-1))]),$[23]||($[23]=v("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[v("input",{type:"checkbox",checked:!!t.isNote,onChange:$[0]||($[0]=C=>x.$emit("toggleNote"))},null,40,Mm),$[24]||($[24]=v("span",{class:"spm-switch-slider"},null,-1))],8,Bm)])]),t.isImage||t.imageRole?(tt(),it("div",Dm,[v("div",Lm,[v("div",Pm,[v("div",Om,[dt(yt,{name:"image"}),$[25]||($[25]=v("span",null,"图片角色与分栏 (Image & Layout)",-1))]),$[26]||($[26]=v("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),v("div",Rm,[v("button",{class:$t(["spm-chip",{active:!t.imageRole}]),onClick:$[1]||($[1]=C=>x.$emit("update:imageRole",""))}," 普通内容 ",2),v("button",{class:$t(["spm-chip",{active:t.imageRole==="background"}]),onClick:$[2]||($[2]=C=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),v("button",{class:$t(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:$[3]||($[3]=C=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),v("button",{class:$t(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:$[4]||($[4]=C=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Mt("",!0),t.isVideo?(tt(),it("div",zm,[v("div",Nm,[v("div",Fm,[v("div",jm,[dt(yt,{name:"video"}),$[27]||($[27]=v("span",null,"视频播放设置 (Video Playback)",-1))]),$[28]||($[28]=v("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),v("div",Hm,[v("div",Um,[$[30]||($[30]=v("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[v("input",{type:"checkbox",checked:!!t.videoControls,onChange:$[5]||($[5]=C=>x.$emit("toggleVideoControls"))},null,40,Vm),$[29]||($[29]=v("span",{class:"spm-switch-slider"},null,-1))],8,Wm)]),v("div",Km,[$[32]||($[32]=v("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[v("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:$[6]||($[6]=C=>x.$emit("toggleVideoAutoplay"))},null,40,Gm),$[31]||($[31]=v("span",{class:"spm-switch-slider"},null,-1))],8,qm)]),v("div",Zm,[$[34]||($[34]=v("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[v("input",{type:"checkbox",checked:!!t.videoLoop,onChange:$[7]||($[7]=C=>x.$emit("toggleVideoLoop"))},null,40,Jm),$[33]||($[33]=v("span",{class:"spm-switch-slider"},null,-1))],8,Ym)]),v("div",Xm,[$[36]||($[36]=v("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[v("input",{type:"checkbox",checked:!!t.videoMuted,onChange:$[8]||($[8]=C=>x.$emit("toggleVideoMuted"))},null,40,tg),$[35]||($[35]=v("span",{class:"spm-switch-slider"},null,-1))],8,Qm)])])])):Mt("",!0),v("div",eg,[v("div",ig,[v("div",ng,[v("div",og,[dt(yt,{name:"step"}),$[37]||($[37]=v("span",null,"逐步呈现 (v-click)",-1))]),$[38]||($[38]=v("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[v("input",{type:"checkbox",checked:!!t.elemClick,onChange:$[9]||($[9]=C=>x.$emit("toggleElemClick"))},null,40,rg),$[39]||($[39]=v("span",{class:"spm-switch-slider"},null,-1))],8,sg)]),t.elemClick?(tt(),it("div",lg,[(tt(),it(Ut,null,me(["+1","1","2","hide"],C=>v("button",{key:C,class:$t(["spm-chip",{active:t.elemClick===C}]),onClick:B=>x.$emit("update:elemClick",C)},St(C==="+1"?"顺延 (+1)":C==="hide"?"隐藏 (hide)":"第 "+C+" 步"),11,ag)),64))])):Mt("",!0)]),v("div",cg,[v("div",dg,[v("div",ug,[v("div",fg,[dt(yt,{name:"motion"}),$[40]||($[40]=v("span",null,"入场微动效 (v-motion)",-1))]),$[41]||($[41]=v("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":m.value?"关闭微动效":"开启微动效 (slide-up)"},[v("input",{type:"checkbox",checked:m.value,onChange:y},null,40,hg),$[42]||($[42]=v("span",{class:"spm-switch-slider"},null,-1))],8,pg)]),m.value?(tt(),it("div",mg,[(tt(),it(Ut,null,me(d,C=>v("button",{key:C.value,class:$t(["spm-chip",{active:f.value===C.value}]),onClick:B=>b(C.value)},St(C.label),11,gg)),64))])):Mt("",!0),m.value?(tt(),it("div",vg,[v("div",bg,[v("span",null,"时长: "+St(k.value?k.value+"ms":"默认 (450ms)"),1),v("span",null,"延迟: "+St(h.value?h.value+"ms":"0ms"),1)]),v("div",yg,[v("select",{class:"spm-select",style:{flex:"1"},value:k.value,onChange:$[10]||($[10]=C=>w(Number(C.target.value)))},[...$[43]||($[43]=[v("option",{value:0},"默认耗时",-1),v("option",{value:200},"极速 (200ms)",-1),v("option",{value:350},"较快 (350ms)",-1),v("option",{value:500},"平滑 (500ms)",-1),v("option",{value:800},"缓慢 (800ms)",-1)])],40,kg),v("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:$[11]||($[11]=C=>_(Number(C.target.value)))},[...$[44]||($[44]=[v("option",{value:0},"无延迟",-1),v("option",{value:150},"延迟 150ms",-1),v("option",{value:300},"延迟 300ms",-1),v("option",{value:500},"延迟 500ms",-1)])],40,wg)])])):Mt("",!0)]),o.value||t.elemSlot?(tt(),it("div",xg,[v("div",_g,[v("div",Sg,[v("div",Cg,[dt(yt,{name:"columns"}),v("span",null,St(r.value),1)]),v("span",$g,St(l.value),1)])]),v("div",Ig,[(tt(!0),it(Ut,null,me(s.value,C=>(tt(),it("button",{key:C.value,class:$t(["spm-segmented-item",{active:a(C.value)}]),onClick:B=>x.$emit("update:elemSlot",C.value)},St(C.label),11,Ag))),128))])])):Mt("",!0),t.isCodeBlock?(tt(),it("div",Tg,[v("div",Eg,[v("div",Bg,[v("div",Mg,[dt(yt,{name:"code"}),$[45]||($[45]=v("span",null,"代码逐行聚光 (Shiki)",-1))]),$[46]||($[46]=v("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),v("div",Dg,[(tt(),it(Ut,null,me(["1-3","all","1|2|3","2-5"],C=>v("button",{key:C,class:$t(["spm-chip",{active:t.elemShikiLines===C}]),onClick:B=>x.$emit("update:elemShikiLines",C)},St(C),11,Lg)),64)),t.elemShikiLines?(tt(),it("button",{key:0,class:"spm-chip spm-chip-clear",onClick:$[12]||($[12]=C=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Mt("",!0)]),v("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:$[13]||($[13]=C=>x.$emit("update:elemShikiLines",C.target.value)),onChange:$[14]||($[14]=C=>x.$emit("update:elemShikiLines",C.target.value))},null,40,Pg)])):Mt("",!0),t.isCodeBlock?(tt(),it("div",Og,[v("div",Rg,[v("div",zg,[v("div",Ng,[dt(yt,{name:"code"}),$[47]||($[47]=v("span",null,"代码块限高 (Max Height)",-1))]),$[48]||($[48]=v("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),v("div",Fg,[(tt(),it(Ut,null,me(["240px","320px","400px","50vh"],C=>v("button",{key:C,class:$t(["spm-chip",{active:t.elemMaxHeight===C}]),onClick:B=>x.$emit("update:elemMaxHeight",C)},St(C),11,jg)),64)),t.elemMaxHeight?(tt(),it("button",{key:0,class:"spm-chip spm-chip-clear",onClick:$[15]||($[15]=C=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Mt("",!0)]),v("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:$[16]||($[16]=C=>x.$emit("update:elemMaxHeight",C.target.value)),onChange:$[17]||($[17]=C=>x.$emit("update:elemMaxHeight",C.target.value))},null,40,Hg)])):Mt("",!0),v("div",Ug,[$[52]||($[52]=v("div",{class:"spm-control-header"},[v("div",{class:"spm-control-title-group"},[v("span",{class:"spm-control-title"},"快捷操作")])],-1)),v("div",Wg,[v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:$[18]||($[18]=C=>x.$emit("insertDividerBefore"))},[dt(yt,{name:"insert-above"}),$[49]||($[49]=v("span",null,"上方分页",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:$[19]||($[19]=C=>x.$emit("insertDividerAfter"))},[dt(yt,{name:"insert-below"}),$[50]||($[50]=v("span",null,"下方分页",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:$[20]||($[20]=C=>x.$emit("setTwoColsContrast"))},[dt(yt,{name:"columns"}),v("span",null,St(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Vg),t.hasBlockAttrs?(tt(),it("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:$[21]||($[21]=C=>x.$emit("clearBlockAttrs"))},[dt(yt,{name:"broom"}),$[51]||($[51]=v("span",null,"清除属性",-1))])):Mt("",!0)])])]))}}),qg={class:"spm-section spm-section--doc"},Gg={class:"spm-card-control"},Zg={class:"spm-control-header"},Yg={class:"spm-control-title-group"},Jg={class:"spm-control-title"},Xg={class:"spm-segmented-group"},Qg=["aria-label","onClick"],tv={class:"spm-card-control"},ev={class:"spm-control-header"},iv={class:"spm-control-title-group"},nv={class:"spm-control-title"},ov={class:"spm-segmented-group"},sv={class:"spm-card-control"},rv={class:"spm-control-header"},lv={class:"spm-control-title-group"},av={class:"spm-control-title"},cv={class:"spm-segmented-group"},dv={class:"spm-card-control"},uv={class:"spm-control-header"},fv={class:"spm-control-title-group"},pv={class:"spm-control-title"},hv={class:"spm-card-control"},mv={class:"spm-control-header"},gv={class:"spm-control-title-group"},vv={class:"spm-control-title"},bv=["aria-label"],yv=["checked"],kv={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},wv=["value"],xv={class:"spm-card-control"},_v={class:"spm-action-grid"},Sv=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ti("plugin"),e=Ti,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(s){qi({enableWebServeJump:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:s})}function r(s){qi({webServeUrl:s})}function l(s){qi({webServeUrl:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:s})}return(s,a)=>(tt(),it("div",qg,[a[35]||(a[35]=v("div",{class:"spm-section-header"},[v("span",null,"全局演示配置")],-1)),v("div",Gg,[v("div",Zg,[v("div",Yg,[v("div",Jg,[dt(yt,{name:"palette"}),a[17]||(a[17]=v("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=v("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),v("div",Xg,[(tt(),it(Ut,null,me(n,c=>v("button",{key:c.value,class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>s.$emit("update:docTheme",c.value)},St(c.label),11,Qg)),64))])]),v("div",tv,[v("div",ev,[v("div",iv,[v("div",nv,[dt(yt,{name:"ratio"}),a[19]||(a[19]=v("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=v("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),v("div",ov,[v("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>s.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),v("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>s.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),v("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>s.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),v("div",sv,[v("div",rv,[v("div",lv,[v("div",av,[dt(yt,{name:"ratio"}),a[21]||(a[21]=v("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=v("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),v("div",cv,[v("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>s.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),v("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>s.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),v("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>s.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),v("div",dv,[v("div",uv,[v("div",fv,[v("div",pv,[dt(yt,{name:"transition"}),a[23]||(a[23]=v("span",null,"全局默认转场",-1))]),a[24]||(a[24]=v("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),dt(Ds,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>s.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),v("div",hv,[v("div",mv,[v("div",gv,[v("div",vv,[dt(yt,{name:"external-link"}),a[25]||(a[25]=v("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=v("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),v("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ht(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[v("input",{type:"checkbox",checked:ht(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>o(c.target.checked))},null,40,yv),a[27]||(a[27]=v("span",{class:"spm-switch-slider"},null,-1))],8,bv)]),ht(e).enableWebServeJump?(tt(),it("div",kv,[v("input",{value:ht(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Te(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Te(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>r(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,wv),a[28]||(a[28]=v("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Mt("",!0)]),v("div",xv,[a[34]||(a[34]=v("div",{class:"spm-control-header"},[v("div",{class:"spm-control-title-group"},[v("span",{class:"spm-control-title"},"演示全局操作")])],-1)),v("div",_v,[v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>s.$emit("openBottomPreview"))},[dt(yt,{name:"split-preview"}),a[29]||(a[29]=v("span",null,"分屏预览",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>s.$emit("openPresenter"))},[dt(yt,{name:"presenter"}),a[30]||(a[30]=v("span",null,"演讲者视图",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>s.$emit("aiAutoSplit"))},[dt(yt,{name:"sparkles"}),a[31]||(a[31]=v("span",null,"AI 智能分页",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>s.$emit("exportHtml"))},[dt(yt,{name:"export-html"}),a[32]||(a[32]=v("span",null,"导出 HTML",-1))]),v("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>s.$emit("exportPdf"))},[dt(yt,{name:"export-pdf"}),a[33]||(a[33]=v("span",null,"导出 PDF",-1))])])])]))}});var Wn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Cv(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Vn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ho={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var xr;function $v(){return xr||(xr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,r){function l(c,d){if(!o[c]){if(!n[c]){var u=typeof Vn=="function"&&Vn;if(!d&&u)return u(c,!0);if(s)return s(c,!0);var m=new Error("Cannot find module '"+c+"'");throw m.code="MODULE_NOT_FOUND",m}var f=o[c]={exports:{}};n[c][0].call(f.exports,function(k){var h=n[c][1][k];return l(h||k)},f,f.exports,e,n,o,r)}return o[c].exports}for(var s=typeof Vn=="function"&&Vn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,n,o){var r=e("./utils"),l=e("./support"),s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,u,m,f,k,h,y=[],b=0,w=a.length,_=w,T=r.getTypeOf(a)!=="string";b<a.length;)_=w-b,u=T?(c=a[b++],d=b<w?a[b++]:0,b<w?a[b++]:0):(c=a.charCodeAt(b++),d=b<w?a.charCodeAt(b++):0,b<w?a.charCodeAt(b++):0),m=c>>2,f=(3&c)<<4|d>>4,k=1<_?(15&d)<<2|u>>6:64,h=2<_?63&u:64,y.push(s.charAt(m)+s.charAt(f)+s.charAt(k)+s.charAt(h));return y.join("")},o.decode=function(a){var c,d,u,m,f,k,h=0,y=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var w,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===s.charAt(64)&&_--,a.charAt(a.length-2)===s.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=l.uint8array?new Uint8Array(0|_):new Array(0|_);h<a.length;)c=s.indexOf(a.charAt(h++))<<2|(m=s.indexOf(a.charAt(h++)))>>4,d=(15&m)<<4|(f=s.indexOf(a.charAt(h++)))>>2,u=(3&f)<<6|(k=s.indexOf(a.charAt(h++))),w[y++]=c,f!==64&&(w[y++]=d),k!==64&&(w[y++]=u);return w}},{"./support":30,"./utils":32}],2:[function(e,n,o){var r=e("./external"),l=e("./stream/DataWorker"),s=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,u,m,f,k){this.compressedSize=d,this.uncompressedSize=u,this.crc32=m,this.compression=f,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),u=this;return d.on("end",function(){if(this.streamInfo.data_length!==u.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,u,m){return d.pipe(new s).pipe(new a("uncompressedSize")).pipe(u.compressWorker(m)).pipe(new a("compressedSize")).withStreamInfo("compression",u)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var r=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var r=e("./utils"),l=(function(){for(var s,a=[],c=0;c<256;c++){s=c;for(var d=0;d<8;d++)s=1&s?3988292384^s>>>1:s>>>1;a[c]=s}return a})();n.exports=function(s,a){return s!==void 0&&s.length?r.getTypeOf(s)!=="string"?(function(c,d,u,m){var f=l,k=m+u;c^=-1;for(var h=m;h<k;h++)c=c>>>8^f[255&(c^d[h])];return-1^c})(0|a,s,s.length,0):(function(c,d,u,m){var f=l,k=m+u;c^=-1;for(var h=m;h<k;h++)c=c>>>8^f[255&(c^d.charCodeAt(h))];return-1^c})(0|a,s,s.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var r=null;r=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:r}},{lie:37}],7:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),s=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(u,m){a.call(this,"FlateWorker/"+u),this._pako=null,this._pakoAction=u,this._pakoOptions=m,this.meta={}}o.magic="\b\0",s.inherits(d,a),d.prototype.processChunk=function(u){this.meta=u.meta,this._pako===null&&this._createPako(),this._pako.push(s.transformTo(c,u.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var u=this;this._pako.onData=function(m){u.push({data:m,meta:u.meta})}},o.compressWorker=function(u){return new d("Deflate",u)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function r(f,k){var h,y="";for(h=0;h<k;h++)y+=String.fromCharCode(255&f),f>>>=8;return y}function l(f,k,h,y,b,w){var _,T,x=f.file,$=f.compression,C=w!==c.utf8encode,B=s.transformTo("string",w(x.name)),M=s.transformTo("string",c.utf8encode(x.name)),O=x.comment,Z=s.transformTo("string",w(O)),A=s.transformTo("string",c.utf8encode(O)),E=M.length!==x.name.length,g=A.length!==O.length,F="",z="",P="",H=x.dir,U=x.date,X={crc32:0,compressedSize:0,uncompressedSize:0};k&&!h||(X.crc32=f.crc32,X.compressedSize=f.compressedSize,X.uncompressedSize=f.uncompressedSize);var K=0;k&&(K|=8),C||!E&&!g||(K|=2048);var q=0,lt=0;H&&(q|=16),b==="UNIX"?(lt=798,q|=(function(st,Q){var pt=st;return st||(pt=Q?16893:33204),(65535&pt)<<16})(x.unixPermissions,H)):(lt=20,q|=(function(st){return 63&(st||0)})(x.dosPermissions)),_=U.getUTCHours(),_<<=6,_|=U.getUTCMinutes(),_<<=5,_|=U.getUTCSeconds()/2,T=U.getUTCFullYear()-1980,T<<=4,T|=U.getUTCMonth()+1,T<<=5,T|=U.getUTCDate(),E&&(z=r(1,1)+r(d(B),4)+M,F+="up"+r(z.length,2)+z),g&&(P=r(1,1)+r(d(Z),4)+A,F+="uc"+r(P.length,2)+P);var at="";return at+=`
\0`,at+=r(K,2),at+=$.magic,at+=r(_,2),at+=r(T,2),at+=r(X.crc32,4),at+=r(X.compressedSize,4),at+=r(X.uncompressedSize,4),at+=r(B.length,2),at+=r(F.length,2),{fileRecord:u.LOCAL_FILE_HEADER+at+B+F,dirRecord:u.CENTRAL_FILE_HEADER+r(lt,2)+at+r(Z.length,2)+"\0\0\0\0"+r(q,4)+r(y,4)+B+F+Z}}var s=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),u=e("../signature");function m(f,k,h,y){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=h,this.encodeFileName=y,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}s.inherits(m,a),m.prototype.push=function(f){var k=f.meta.percent||0,h=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,a.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:h?(k+100*(h-y-1))/h:100}}))},m.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var k=this.streamFiles&&!f.file.dir;if(k){var h=l(f,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},m.prototype.closedSource=function(f){this.accumulate=!1;var k=this.streamFiles&&!f.file.dir,h=l(f,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),k)this.push({data:(function(y){return u.DATA_DESCRIPTOR+r(y.crc32,4)+r(y.compressedSize,4)+r(y.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},m.prototype.flush=function(){for(var f=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var h=this.bytesWritten-f,y=(function(b,w,_,T,x){var $=s.transformTo("string",x(T));return u.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(b,2)+r(b,2)+r(w,4)+r(_,4)+r($.length,2)+$})(this.dirRecords.length,h,f,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},m.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},m.prototype.registerPrevious=function(f){this._sources.push(f);var k=this;return f.on("data",function(h){k.processChunk(h)}),f.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),f.on("error",function(h){k.error(h)}),this},m.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},m.prototype.error=function(f){var k=this._sources;if(!a.prototype.error.call(this,f))return!1;for(var h=0;h<k.length;h++)try{k[h].error(f)}catch{}return!0},m.prototype.lock=function(){a.prototype.lock.call(this);for(var f=this._sources,k=0;k<f.length;k++)f[k].lock()},n.exports=m},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var r=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(s,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),u=0;try{s.forEach(function(m,f){u++;var k=(function(w,_){var T=w||_,x=r[T];if(!x)throw new Error(T+" is not a valid compression method !");return x})(f.options.compression,a.compression),h=f.options.compressionOptions||a.compressionOptions||{},y=f.dir,b=f.date;f._compressWorker(k,h).withStreamInfo("file",{name:m,dir:y,date:b,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(d)}),d.entriesCount=u}catch(m){d.error(m)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var s in this)typeof this[s]!="function"&&(l[s]=this[s]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,s){return new r().loadAsync(l,s)},r.external=e("./external"),n.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var r=e("./utils"),l=e("./external"),s=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function u(m){return new l.Promise(function(f,k){var h=m.decompressed.getContentWorker().pipe(new c);h.on("error",function(y){k(y)}).on("end",function(){h.streamInfo.crc32!==m.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(m,f){var k=this;return f=r.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:s.utf8decode}),d.isNode&&d.isStream(m)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",m,!0,f.optimizedBinaryString,f.base64).then(function(h){var y=new a(f);return y.load(h),y}).then(function(h){var y=[l.Promise.resolve(h)],b=h.files;if(f.checkCRC32)for(var w=0;w<b.length;w++)y.push(u(b[w]));return l.Promise.all(y)}).then(function(h){for(var y=h.shift(),b=y.files,w=0;w<b.length;w++){var _=b[w],T=_.fileNameStr,x=r.resolve(_.fileNameStr);k.file(x,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:f.createFolders}),_.dir||(k.file(x).unsafeOriginalName=T)}return y.zipComment.length&&(k.comment=y.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var r=e("../utils"),l=e("../stream/GenericWorker");function s(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(s,l),s.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},s.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=s},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var r=e("readable-stream").Readable;function l(s,a,c){r.call(this,a),this._helper=s;var d=this;s.on("data",function(u,m){d.push(u)||d._helper.pause(),c&&c(m)}).on("error",function(u){d.emit("error",u)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,n,o){function r(x,$,C){var B,M=s.getTypeOf($),O=s.extend(C||{},d);O.date=O.date||new Date,O.compression!==null&&(O.compression=O.compression.toUpperCase()),typeof O.unixPermissions=="string"&&(O.unixPermissions=parseInt(O.unixPermissions,8)),O.unixPermissions&&16384&O.unixPermissions&&(O.dir=!0),O.dosPermissions&&16&O.dosPermissions&&(O.dir=!0),O.dir&&(x=b(x)),O.createFolders&&(B=y(x))&&w.call(this,B,!0);var Z=M==="string"&&O.binary===!1&&O.base64===!1;C&&C.binary!==void 0||(O.binary=!Z),($ instanceof u&&$.uncompressedSize===0||O.dir||!$||$.length===0)&&(O.base64=!1,O.binary=!0,$="",O.compression="STORE",M="string");var A=null;A=$ instanceof u||$ instanceof a?$:k.isNode&&k.isStream($)?new h(x,$):s.prepareContent(x,$,O.binary,O.optimizedBinaryString,O.base64);var E=new m(x,A,O);this.files[x]=E}var l=e("./utf8"),s=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),u=e("./compressedObject"),m=e("./zipObject"),f=e("./generate"),k=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),y=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var $=x.lastIndexOf("/");return 0<$?x.substring(0,$):""},b=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},w=function(x,$){return $=$!==void 0?$:d.createFolders,x=b(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:$}),this.files[x]};function _(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var $,C,B;for($ in this.files)B=this.files[$],(C=$.slice(this.root.length,$.length))&&$.slice(0,this.root.length)===this.root&&x(C,B)},filter:function(x){var $=[];return this.forEach(function(C,B){x(C,B)&&$.push(B)}),$},file:function(x,$,C){if(arguments.length!==1)return x=this.root+x,r.call(this,x,$,C),this;if(_(x)){var B=x;return this.filter(function(O,Z){return!Z.dir&&B.test(O)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if(_(x))return this.filter(function(M,O){return O.dir&&x.test(M)});var $=this.root+x,C=w.call(this,$),B=this.clone();return B.root=C.name,B},remove:function(x){x=this.root+x;var $=this.files[x];if($||(x.slice(-1)!=="/"&&(x+="/"),$=this.files[x]),$&&!$.dir)delete this.files[x];else for(var C=this.filter(function(M,O){return O.name.slice(0,x.length)===x}),B=0;B<C.length;B++)delete this.files[C[B].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var $,C={};try{if((C=s.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");s.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var B=C.comment||this.comment||"";$=f.generateWorker(this,C,B)}catch(M){($=new a("error")).error(M)}return new c($,C.type||"string",C.mimeType)},generateAsync:function(x,$){return this.generateInternalStream(x).accumulate($)},generateNodeStream:function(x,$){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream($)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s);for(var a=0;a<this.data.length;a++)s[a]=255&s[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data[this.zero+s]},l.prototype.lastIndexOfSignature=function(s){for(var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),u=s.charCodeAt(3),m=this.length-4;0<=m;--m)if(this.data[m]===a&&this.data[m+1]===c&&this.data[m+2]===d&&this.data[m+3]===u)return m-this.zero;return-1},l.prototype.readAndCheckSignature=function(s){var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),u=s.charCodeAt(3),m=this.readData(4);return a===m[0]&&c===m[1]&&d===m[2]&&u===m[3]},l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var r=e("../utils");function l(s){this.data=s,this.length=s.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(s){this.checkIndex(this.index+s)},checkIndex:function(s){if(this.length<this.zero+s||s<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+s+"). Corrupted zip ?")},setIndex:function(s){this.checkIndex(s),this.index=s},skip:function(s){this.setIndex(this.index+s)},byteAt:function(){},readInt:function(s){var a,c=0;for(this.checkOffset(s),a=this.index+s-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=s,c},readString:function(s){return r.transformTo("string",this.readData(s))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var s=this.readInt(4);return new Date(Date.UTC(1980+(s>>25&127),(s>>21&15)-1,s>>16&31,s>>11&31,s>>5&63,(31&s)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var r=e("./Uint8ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data.charCodeAt(this.zero+s)},l.prototype.lastIndexOfSignature=function(s){return this.data.lastIndexOf(s)-this.zero},l.prototype.readAndCheckSignature=function(s){return s===this.readData(4)},l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var r=e("./ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var r=e("../utils"),l=e("../support"),s=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(u){var m=r.getTypeOf(u);return r.checkSupport(m),m!=="string"||l.uint8array?m==="nodebuffer"?new c(u):l.uint8array?new d(r.transformTo("uint8array",u)):new s(r.transformTo("array",u)):new a(u)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var r=e("./GenericWorker"),l=e("../utils");function s(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(s,r),s.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=s},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var r=e("./GenericWorker"),l=e("../crc32");function s(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(s,r),s.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=s},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(s,l),s.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=s},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(s,l),s.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},s.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},s.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=s},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,s){return this._listeners[l].push(s),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,s){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,s)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var s=this;return l.on("data",function(a){s.processChunk(a)}),l.on("end",function(){s.end()}),l.on("error",function(a){s.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,s){return this.extraStreamInfo[l]=s,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=r},{}],29:[function(e,n,o){var r=e("../utils"),l=e("./ConvertWorker"),s=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),u=null;if(c.nodestream)try{u=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function m(k,h){return new d.Promise(function(y,b){var w=[],_=k._internalType,T=k._outputType,x=k._mimeType;k.on("data",function($,C){w.push($),h&&h(C)}).on("error",function($){w=[],b($)}).on("end",function(){try{var $=(function(C,B,M){switch(C){case"blob":return r.newBlob(r.transformTo("arraybuffer",B),M);case"base64":return a.encode(B);default:return r.transformTo(C,B)}})(T,(function(C,B){var M,O=0,Z=null,A=0;for(M=0;M<B.length;M++)A+=B[M].length;switch(C){case"string":return B.join("");case"array":return Array.prototype.concat.apply([],B);case"uint8array":for(Z=new Uint8Array(A),M=0;M<B.length;M++)Z.set(B[M],O),O+=B[M].length;return Z;case"nodebuffer":return Buffer.concat(B);default:throw new Error("concat : unsupported type '"+C+"'")}})(_,w),x);y($)}catch(C){b(C)}w=[]}).resume()})}function f(k,h,y){var b=h;switch(h){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=h,this._mimeType=y,r.checkSupport(b),this._worker=k.pipe(new l(b)),k.lock()}catch(w){this._worker=new s("error"),this._worker.error(w)}}f.prototype={accumulate:function(k){return m(this,k)},on:function(k,h){var y=this;return k==="data"?this._worker.on(k,function(b){h.call(y,b.data,b.meta)}):this._worker.on(k,function(){r.delay(h,arguments,y)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new u(this,{objectMode:this._outputType!=="nodebuffer"},k)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var r=new ArrayBuffer(0);try{o.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var r=e("./utils"),l=e("./support"),s=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function u(){a.call(this,"utf-8 decode"),this.leftOver=null}function m(){a.call(this,"utf-8 encode")}o.utf8encode=function(f){return l.nodebuffer?s.newBufferFrom(f,"utf-8"):(function(k){var h,y,b,w,_,T=k.length,x=0;for(w=0;w<T;w++)(64512&(y=k.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=k.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),w++),x+=y<128?1:y<2048?2:y<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),w=_=0;_<x;w++)(64512&(y=k.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=k.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),w++),y<128?h[_++]=y:(y<2048?h[_++]=192|y>>>6:(y<65536?h[_++]=224|y>>>12:(h[_++]=240|y>>>18,h[_++]=128|y>>>12&63),h[_++]=128|y>>>6&63),h[_++]=128|63&y);return h})(f)},o.utf8decode=function(f){return l.nodebuffer?r.transformTo("nodebuffer",f).toString("utf-8"):(function(k){var h,y,b,w,_=k.length,T=new Array(2*_);for(h=y=0;h<_;)if((b=k[h++])<128)T[y++]=b;else if(4<(w=c[b]))T[y++]=65533,h+=w-1;else{for(b&=w===2?31:w===3?15:7;1<w&&h<_;)b=b<<6|63&k[h++],w--;1<w?T[y++]=65533:b<65536?T[y++]=b:(b-=65536,T[y++]=55296|b>>10&1023,T[y++]=56320|1023&b)}return T.length!==y&&(T.subarray?T=T.subarray(0,y):T.length=y),r.applyFromCharCode(T)})(f=r.transformTo(l.uint8array?"uint8array":"array",f))},r.inherits(u,a),u.prototype.processChunk=function(f){var k=r.transformTo(l.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=k;(k=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),k.set(h,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var y=(function(w,_){var T;for((_=_||w.length)>w.length&&(_=w.length),T=_-1;0<=T&&(192&w[T])==128;)T--;return T<0||T===0?_:T+c[w[T]]>_?T:_})(k),b=k;y!==k.length&&(l.uint8array?(b=k.subarray(0,y),this.leftOver=k.subarray(y,k.length)):(b=k.slice(0,y),this.leftOver=k.slice(y,k.length))),this.push({data:o.utf8decode(b),meta:f.meta})},u.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=u,r.inherits(m,a),m.prototype.processChunk=function(f){this.push({data:o.utf8encode(f.data),meta:f.meta})},o.Utf8EncodeWorker=m},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var r=e("./support"),l=e("./base64"),s=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,y){for(var b=0;b<h.length;++b)y[b]=255&h.charCodeAt(b);return y}e("setimmediate"),o.newBlob=function(h,y){o.checkSupport("blob");try{return new Blob([h],{type:y})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(h),b.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var u={stringifyByChunk:function(h,y,b){var w=[],_=0,T=h.length;if(T<=b)return String.fromCharCode.apply(null,h);for(;_<T;)y==="array"||y==="nodebuffer"?w.push(String.fromCharCode.apply(null,h.slice(_,Math.min(_+b,T)))):w.push(String.fromCharCode.apply(null,h.subarray(_,Math.min(_+b,T)))),_+=b;return w.join("")},stringifyByChar:function(h){for(var y="",b=0;b<h.length;b++)y+=String.fromCharCode(h[b]);return y},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,s.allocBuffer(1)).length===1}catch{return!1}})()}};function m(h){var y=65536,b=o.getTypeOf(h),w=!0;if(b==="uint8array"?w=u.applyCanBeUsed.uint8array:b==="nodebuffer"&&(w=u.applyCanBeUsed.nodebuffer),w)for(;1<y;)try{return u.stringifyByChunk(h,b,y)}catch{y=Math.floor(y/2)}return u.stringifyByChar(h)}function f(h,y){for(var b=0;b<h.length;b++)y[b]=h[b];return y}o.applyFromCharCode=m;var k={};k.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return k.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,s.allocBuffer(h.length))}},k.array={string:m,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(h)}},k.arraybuffer={string:function(h){return m(new Uint8Array(h))},array:function(h){return f(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(new Uint8Array(h))}},k.uint8array={string:m,array:function(h){return f(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return s.newBufferFrom(h)}},k.nodebuffer={string:m,array:function(h){return f(h,new Array(h.length))},arraybuffer:function(h){return k.nodebuffer.uint8array(h).buffer},uint8array:function(h){return f(h,new Uint8Array(h.length))},nodebuffer:c},o.transformTo=function(h,y){if(y=y||"",!h)return y;o.checkSupport(h);var b=o.getTypeOf(y);return k[b][h](y)},o.resolve=function(h){for(var y=h.split("/"),b=[],w=0;w<y.length;w++){var _=y[w];_==="."||_===""&&w!==0&&w!==y.length-1||(_===".."?b.pop():b.push(_))}return b.join("/")},o.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&s.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(h){var y,b,w="";for(b=0;b<(h||"").length;b++)w+="\\x"+((y=h.charCodeAt(b))<16?"0":"")+y.toString(16).toUpperCase();return w},o.delay=function(h,y,b){setImmediate(function(){h.apply(b||null,y||[])})},o.inherits=function(h,y){function b(){}b.prototype=y.prototype,h.prototype=new b},o.extend=function(){var h,y,b={};for(h=0;h<arguments.length;h++)for(y in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],y)&&b[y]===void 0&&(b[y]=arguments[h][y]);return b},o.prepareContent=function(h,y,b,w,_){return a.Promise.resolve(y).then(function(T){return r.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,$){var C=new FileReader;C.onload=function(B){x(B.target.result)},C.onerror=function(B){$(B.target.error)},C.readAsArrayBuffer(T)}):T}).then(function(T){var x=o.getTypeOf(T);return x?(x==="arraybuffer"?T=o.transformTo("uint8array",T):x==="string"&&(_?T=l.decode(T):b&&w!==!0&&(T=(function($){return d($,r.uint8array?new Uint8Array($.length):new Array($.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(u){this.files=[],this.loadOptions=u}d.prototype={checkSignature:function(u){if(!this.reader.readAndCheckSignature(u)){this.reader.index-=4;var m=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(m)+", expected "+l.pretty(u)+")")}},isSignature:function(u,m){var f=this.reader.index;this.reader.setIndex(u);var k=this.reader.readString(4)===m;return this.reader.setIndex(f),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var u=this.reader.readData(this.zipCommentLength),m=c.uint8array?"uint8array":"array",f=l.transformTo(m,u);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var u,m,f,k=this.zip64EndOfCentralSize-44;0<k;)u=this.reader.readInt(2),m=this.reader.readInt(4),f=this.reader.readData(m),this.zip64ExtensibleData[u]={id:u,length:m,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var u,m;for(u=0;u<this.files.length;u++)m=this.files[u],this.reader.setIndex(m.localHeaderOffset),this.checkSignature(s.LOCAL_FILE_HEADER),m.readLocalPart(this.reader),m.handleUTF8(),m.processAttributes()},readCentralDir:function(){var u;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);)(u=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(u);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var u=this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);if(u<0)throw this.isSignature(0,s.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(u);var m=u;if(this.checkSignature(s.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(u=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(u),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,s.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var k=m-f;if(0<k)this.isSignature(m,s.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(u){this.reader=r(u)},load:function(u){this.prepareReader(u),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),u=e("./support");function m(f,k){this.options=f,this.loadOptions=k}m.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var k,h;if(f.skip(22),this.fileNameLength=f.readInt(2),h=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(y){for(var b in d)if(Object.prototype.hasOwnProperty.call(d,b)&&d[b].magic===y)return d[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new s(this.compressedSize,this.uncompressedSize,this.crc32,k,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var k=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(k),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var k,h,y,b=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<b;)k=f.readInt(2),h=f.readInt(2),y=f.readData(h),this.extraFields[k]={id:k,length:h,value:y};f.setIndex(b)},handleUTF8:function(){var f=u.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var h=l.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var b=l.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var k=r(f.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var k=r(f.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(f.length-5))}return null}},n.exports=m},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function r(k,h,y){this.name=k,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=h,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var l=e("./stream/StreamHelper"),s=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(k){var h=null,y="string";try{if(!k)throw new Error("No output type specified.");var b=(y=k.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),h=this._decompressWorker();var w=!this._dataBinary;w&&!b&&(h=h.pipe(new a.Utf8EncodeWorker)),!w&&b&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(_){(h=new d("error")).error(_)}return new l(h,y,"")},async:function(k,h){return this.internalStream(k).accumulate(h)},nodeStream:function(k,h){return this.internalStream(k||"nodebuffer").toNodejsStream(h)},_compressWorker:function(k,h){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(y,k,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new s(this._data)}};for(var u=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],m=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<u.length;f++)r.prototype[u[f]]=m;n.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(r){var l,s,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(k),u=r.document.createTextNode("");d.observe(u,{characterData:!0}),l=function(){u.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){k(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(k,0)};else{var m=new r.MessageChannel;m.port1.onmessage=k,l=function(){m.port2.postMessage(0)}}var f=[];function k(){var h,y;s=!0;for(var b=f.length;b;){for(y=f,f=[],h=-1;++h<b;)y[h]();b=f.length}s=!1}n.exports=function(h){f.push(h)!==1||s||l()}}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var r=e("immediate");function l(){}var s={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function u(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,b!==l&&h(this,b)}function m(b,w,_){this.promise=b,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function f(b,w,_){r(function(){var T;try{T=w(_)}catch(x){return s.reject(b,x)}T===b?s.reject(b,new TypeError("Cannot resolve promise with itself")):s.resolve(b,T)})}function k(b){var w=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof w=="function")return function(){w.apply(b,arguments)}}function h(b,w){var _=!1;function T(C){_||(_=!0,s.reject(b,C))}function x(C){_||(_=!0,s.resolve(b,C))}var $=y(function(){w(x,T)});$.status==="error"&&T($.value)}function y(b,w){var _={};try{_.value=b(w),_.status="success"}catch(T){_.status="error",_.value=T}return _}(n.exports=u).prototype.finally=function(b){if(typeof b!="function")return this;var w=this.constructor;return this.then(function(_){return w.resolve(b()).then(function(){return _})},function(_){return w.resolve(b()).then(function(){throw _})})},u.prototype.catch=function(b){return this.then(null,b)},u.prototype.then=function(b,w){if(typeof b!="function"&&this.state===c||typeof w!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?f(_,this.state===c?b:w,this.outcome):this.queue.push(new m(_,b,w)),_},m.prototype.callFulfilled=function(b){s.resolve(this.promise,b)},m.prototype.otherCallFulfilled=function(b){f(this.promise,this.onFulfilled,b)},m.prototype.callRejected=function(b){s.reject(this.promise,b)},m.prototype.otherCallRejected=function(b){f(this.promise,this.onRejected,b)},s.resolve=function(b,w){var _=y(k,w);if(_.status==="error")return s.reject(b,_.value);var T=_.value;if(T)h(b,T);else{b.state=c,b.outcome=w;for(var x=-1,$=b.queue.length;++x<$;)b.queue[x].callFulfilled(w)}return b},s.reject=function(b,w){b.state=a,b.outcome=w;for(var _=-1,T=b.queue.length;++_<T;)b.queue[_].callRejected(w);return b},u.resolve=function(b){return b instanceof this?b:s.resolve(new this(l),b)},u.reject=function(b){var w=new this(l);return s.reject(w,b)},u.all=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=b.length,T=!1;if(!_)return this.resolve([]);for(var x=new Array(_),$=0,C=-1,B=new this(l);++C<_;)M(b[C],C);return B;function M(O,Z){w.resolve(O).then(function(A){x[Z]=A,++$!==_||T||(T=!0,s.resolve(B,x))},function(A){T||(T=!0,s.reject(B,A))})}},u.race=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=b.length,T=!1;if(!_)return this.resolve([]);for(var x=-1,$=new this(l);++x<_;)C=b[x],w.resolve(C).then(function(B){T||(T=!0,s.resolve($,B))},function(B){T||(T=!0,s.reject($,B))});var C;return $}},{immediate:36}],38:[function(e,n,o){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var r=e("./zlib/deflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,u=0,m=-1,f=0,k=8;function h(b){if(!(this instanceof h))return new h(b);this.options=l.assign({level:m,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},b||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=r.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if(_!==u)throw new Error(a[_]);if(w.header&&r.deflateSetHeader(this.strm,w.header),w.dictionary){var T;if(T=typeof w.dictionary=="string"?s.string2buf(w.dictionary):d.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,(_=r.deflateSetDictionary(this.strm,T))!==u)throw new Error(a[_]);this._dict_set=!0}}function y(b,w){var _=new h(w);if(_.push(b,!0),_.err)throw _.msg||a[_.err];return _.result}h.prototype.push=function(b,w){var _,T,x=this.strm,$=this.options.chunkSize;if(this.ended)return!1;T=w===~~w?w:w===!0?4:0,typeof b=="string"?x.input=s.string2buf(b):d.call(b)==="[object ArrayBuffer]"?x.input=new Uint8Array(b):x.input=b,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8($),x.next_out=0,x.avail_out=$),(_=r.deflate(x,T))!==1&&_!==u)return this.onEnd(_),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(s.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&_!==1);return T===4?(_=r.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===u):T!==2||(this.onEnd(u),!(x.avail_out=0))},h.prototype.onData=function(b){this.chunks.push(b)},h.prototype.onEnd=function(b){b===u&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},o.Deflate=h,o.deflate=y,o.deflateRaw=function(b,w){return(w=w||{}).raw=!0,y(b,w)},o.gzip=function(b,w){return(w=w||{}).gzip=!0,y(b,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var r=e("./zlib/inflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),u=e("./zlib/gzheader"),m=Object.prototype.toString;function f(h){if(!(this instanceof f))return new f(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||h&&h.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var b=r.inflateInit2(this.strm,y.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new u,r.inflateGetHeader(this.strm,this.header)}function k(h,y){var b=new f(y);if(b.push(h,!0),b.err)throw b.msg||c[b.err];return b.result}f.prototype.push=function(h,y){var b,w,_,T,x,$,C=this.strm,B=this.options.chunkSize,M=this.options.dictionary,O=!1;if(this.ended)return!1;w=y===~~y?y:y===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?C.input=s.binstring2buf(h):m.call(h)==="[object ArrayBuffer]"?C.input=new Uint8Array(h):C.input=h,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new l.Buf8(B),C.next_out=0,C.avail_out=B),(b=r.inflate(C,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&($=typeof M=="string"?s.string2buf(M):m.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,b=r.inflateSetDictionary(this.strm,$)),b===a.Z_BUF_ERROR&&O===!0&&(b=a.Z_OK,O=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&b!==a.Z_STREAM_END&&(C.avail_in!==0||w!==a.Z_FINISH&&w!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=s.utf8border(C.output,C.next_out),T=C.next_out-_,x=s.buf2string(C.output,_),C.next_out=T,C.avail_out=B-T,T&&l.arraySet(C.output,C.output,_,T,0),this.onData(x)):this.onData(l.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(O=!0)}while((0<C.avail_in||C.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(w=a.Z_FINISH),w===a.Z_FINISH?(b=r.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):w!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(C.avail_out=0))},f.prototype.onData=function(h){this.chunks.push(h)},f.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},o.Inflate=f,o.inflate=k,o.inflateRaw=function(h,y){return(y=y||{}).raw=!0,k(h,y)},o.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var u in d)d.hasOwnProperty(u)&&(a[u]=d[u])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,u,m){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+u),m);else for(var f=0;f<u;f++)a[m+f]=c[d+f]},flattenChunks:function(a){var c,d,u,m,f,k;for(c=u=0,d=a.length;c<d;c++)u+=a[c].length;for(k=new Uint8Array(u),c=m=0,d=a.length;c<d;c++)f=a[c],k.set(f,m),m+=f.length;return k}},s={arraySet:function(a,c,d,u,m){for(var f=0;f<u;f++)a[m+f]=c[d+f]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,s))},o.setTyped(r)},{}],42:[function(e,n,o){var r=e("./common"),l=!0,s=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{s=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(u,m){if(m<65537&&(u.subarray&&s||!u.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(u,m));for(var f="",k=0;k<m;k++)f+=String.fromCharCode(u[k]);return f}a[254]=a[254]=1,o.string2buf=function(u){var m,f,k,h,y,b=u.length,w=0;for(h=0;h<b;h++)(64512&(f=u.charCodeAt(h)))==55296&&h+1<b&&(64512&(k=u.charCodeAt(h+1)))==56320&&(f=65536+(f-55296<<10)+(k-56320),h++),w+=f<128?1:f<2048?2:f<65536?3:4;for(m=new r.Buf8(w),h=y=0;y<w;h++)(64512&(f=u.charCodeAt(h)))==55296&&h+1<b&&(64512&(k=u.charCodeAt(h+1)))==56320&&(f=65536+(f-55296<<10)+(k-56320),h++),f<128?m[y++]=f:(f<2048?m[y++]=192|f>>>6:(f<65536?m[y++]=224|f>>>12:(m[y++]=240|f>>>18,m[y++]=128|f>>>12&63),m[y++]=128|f>>>6&63),m[y++]=128|63&f);return m},o.buf2binstring=function(u){return d(u,u.length)},o.binstring2buf=function(u){for(var m=new r.Buf8(u.length),f=0,k=m.length;f<k;f++)m[f]=u.charCodeAt(f);return m},o.buf2string=function(u,m){var f,k,h,y,b=m||u.length,w=new Array(2*b);for(f=k=0;f<b;)if((h=u[f++])<128)w[k++]=h;else if(4<(y=a[h]))w[k++]=65533,f+=y-1;else{for(h&=y===2?31:y===3?15:7;1<y&&f<b;)h=h<<6|63&u[f++],y--;1<y?w[k++]=65533:h<65536?w[k++]=h:(h-=65536,w[k++]=55296|h>>10&1023,w[k++]=56320|1023&h)}return d(w,k)},o.utf8border=function(u,m){var f;for((m=m||u.length)>u.length&&(m=u.length),f=m-1;0<=f&&(192&u[f])==128;)f--;return f<0||f===0?m:f+a[u[f]]>m?f:m}},{"./common":41}],43:[function(e,n,o){n.exports=function(r,l,s,a){for(var c=65535&r|0,d=r>>>16&65535|0,u=0;s!==0;){for(s-=u=2e3<s?2e3:s;d=d+(c=c+l[a++]|0)|0,--u;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var r=(function(){for(var l,s=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;s[a]=l}return s})();n.exports=function(l,s,a,c){var d=r,u=c+a;l^=-1;for(var m=c;m<u;m++)l=l>>>8^d[255&(l^s[m])];return-1^l}},{}],46:[function(e,n,o){var r,l=e("../utils/common"),s=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),u=0,m=4,f=0,k=-2,h=-1,y=4,b=2,w=8,_=9,T=286,x=30,$=19,C=2*T+1,B=15,M=3,O=258,Z=O+M+1,A=42,E=113,g=1,F=2,z=3,P=4;function H(p,j){return p.msg=d[j],j}function U(p){return(p<<1)-(4<p?9:0)}function X(p){for(var j=p.length;0<=--j;)p[j]=0}function K(p){var j=p.state,R=j.pending;R>p.avail_out&&(R=p.avail_out),R!==0&&(l.arraySet(p.output,j.pending_buf,j.pending_out,R,p.next_out),p.next_out+=R,j.pending_out+=R,p.total_out+=R,p.avail_out-=R,j.pending-=R,j.pending===0&&(j.pending_out=0))}function q(p,j){s._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,j),p.block_start=p.strstart,K(p.strm)}function lt(p,j){p.pending_buf[p.pending++]=j}function at(p,j){p.pending_buf[p.pending++]=j>>>8&255,p.pending_buf[p.pending++]=255&j}function st(p,j){var R,S,I=p.max_chain_length,L=p.strstart,G=p.prev_length,V=p.nice_match,W=p.strstart>p.w_size-Z?p.strstart-(p.w_size-Z):0,Y=p.window,nt=p.w_mask,et=p.prev,ct=p.strstart+O,xt=Y[L+G-1],bt=Y[L+G];p.prev_length>=p.good_match&&(I>>=2),V>p.lookahead&&(V=p.lookahead);do if(Y[(R=j)+G]===bt&&Y[R+G-1]===xt&&Y[R]===Y[L]&&Y[++R]===Y[L+1]){L+=2,R++;do;while(Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&Y[++L]===Y[++R]&&L<ct);if(S=O-(ct-L),L=ct-O,G<S){if(p.match_start=j,V<=(G=S))break;xt=Y[L+G-1],bt=Y[L+G]}}while((j=et[j&nt])>W&&--I!=0);return G<=p.lookahead?G:p.lookahead}function Q(p){var j,R,S,I,L,G,V,W,Y,nt,et=p.w_size;do{if(I=p.window_size-p.lookahead-p.strstart,p.strstart>=et+(et-Z)){for(l.arraySet(p.window,p.window,et,et,0),p.match_start-=et,p.strstart-=et,p.block_start-=et,j=R=p.hash_size;S=p.head[--j],p.head[j]=et<=S?S-et:0,--R;);for(j=R=et;S=p.prev[--j],p.prev[j]=et<=S?S-et:0,--R;);I+=et}if(p.strm.avail_in===0)break;if(G=p.strm,V=p.window,W=p.strstart+p.lookahead,Y=I,nt=void 0,nt=G.avail_in,Y<nt&&(nt=Y),R=nt===0?0:(G.avail_in-=nt,l.arraySet(V,G.input,G.next_in,nt,W),G.state.wrap===1?G.adler=a(G.adler,V,nt,W):G.state.wrap===2&&(G.adler=c(G.adler,V,nt,W)),G.next_in+=nt,G.total_in+=nt,nt),p.lookahead+=R,p.lookahead+p.insert>=M)for(L=p.strstart-p.insert,p.ins_h=p.window[L],p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+M-1])&p.hash_mask,p.prev[L&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=L,L++,p.insert--,!(p.lookahead+p.insert<M)););}while(p.lookahead<Z&&p.strm.avail_in!==0)}function pt(p,j){for(var R,S;;){if(p.lookahead<Z){if(Q(p),p.lookahead<Z&&j===u)return g;if(p.lookahead===0)break}if(R=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),R!==0&&p.strstart-R<=p.w_size-Z&&(p.match_length=st(p,R)),p.match_length>=M)if(S=s._tr_tally(p,p.strstart-p.match_start,p.match_length-M),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=M){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else S=s._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(S&&(q(p,!1),p.strm.avail_out===0))return g}return p.insert=p.strstart<M-1?p.strstart:M-1,j===m?(q(p,!0),p.strm.avail_out===0?z:P):p.last_lit&&(q(p,!1),p.strm.avail_out===0)?g:F}function gt(p,j){for(var R,S,I;;){if(p.lookahead<Z){if(Q(p),p.lookahead<Z&&j===u)return g;if(p.lookahead===0)break}if(R=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=M-1,R!==0&&p.prev_length<p.max_lazy_match&&p.strstart-R<=p.w_size-Z&&(p.match_length=st(p,R),p.match_length<=5&&(p.strategy===1||p.match_length===M&&4096<p.strstart-p.match_start)&&(p.match_length=M-1)),p.prev_length>=M&&p.match_length<=p.prev_length){for(I=p.strstart+p.lookahead-M,S=s._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-M),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=I&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=M-1,p.strstart++,S&&(q(p,!1),p.strm.avail_out===0))return g}else if(p.match_available){if((S=s._tr_tally(p,0,p.window[p.strstart-1]))&&q(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return g}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(S=s._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<M-1?p.strstart:M-1,j===m?(q(p,!0),p.strm.avail_out===0?z:P):p.last_lit&&(q(p,!1),p.strm.avail_out===0)?g:F}function J(p,j,R,S,I){this.good_length=p,this.max_lazy=j,this.nice_length=R,this.max_chain=S,this.func=I}function rt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*C),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*$+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(B+1),this.heap=new l.Buf16(2*T+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function vt(p){var j;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=b,(j=p.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?A:E,p.adler=j.wrap===2?0:1,j.last_flush=u,s._tr_init(j),f):H(p,k)}function D(p){var j=vt(p);return j===f&&(function(R){R.window_size=2*R.w_size,X(R.head),R.max_lazy_match=r[R.level].max_lazy,R.good_match=r[R.level].good_length,R.nice_match=r[R.level].nice_length,R.max_chain_length=r[R.level].max_chain,R.strstart=0,R.block_start=0,R.lookahead=0,R.insert=0,R.match_length=R.prev_length=M-1,R.match_available=0,R.ins_h=0})(p.state),j}function N(p,j,R,S,I,L){if(!p)return k;var G=1;if(j===h&&(j=6),S<0?(G=0,S=-S):15<S&&(G=2,S-=16),I<1||_<I||R!==w||S<8||15<S||j<0||9<j||L<0||y<L)return H(p,k);S===8&&(S=9);var V=new rt;return(p.state=V).strm=p,V.wrap=G,V.gzhead=null,V.w_bits=S,V.w_size=1<<V.w_bits,V.w_mask=V.w_size-1,V.hash_bits=I+7,V.hash_size=1<<V.hash_bits,V.hash_mask=V.hash_size-1,V.hash_shift=~~((V.hash_bits+M-1)/M),V.window=new l.Buf8(2*V.w_size),V.head=new l.Buf16(V.hash_size),V.prev=new l.Buf16(V.w_size),V.lit_bufsize=1<<I+6,V.pending_buf_size=4*V.lit_bufsize,V.pending_buf=new l.Buf8(V.pending_buf_size),V.d_buf=1*V.lit_bufsize,V.l_buf=3*V.lit_bufsize,V.level=j,V.strategy=L,V.method=R,D(p)}r=[new J(0,0,0,0,function(p,j){var R=65535;for(R>p.pending_buf_size-5&&(R=p.pending_buf_size-5);;){if(p.lookahead<=1){if(Q(p),p.lookahead===0&&j===u)return g;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var S=p.block_start+R;if((p.strstart===0||p.strstart>=S)&&(p.lookahead=p.strstart-S,p.strstart=S,q(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-Z&&(q(p,!1),p.strm.avail_out===0))return g}return p.insert=0,j===m?(q(p,!0),p.strm.avail_out===0?z:P):(p.strstart>p.block_start&&(q(p,!1),p.strm.avail_out),g)}),new J(4,4,8,4,pt),new J(4,5,16,8,pt),new J(4,6,32,32,pt),new J(4,4,16,16,gt),new J(8,16,32,32,gt),new J(8,16,128,128,gt),new J(8,32,128,256,gt),new J(32,128,258,1024,gt),new J(32,258,258,4096,gt)],o.deflateInit=function(p,j){return N(p,j,w,15,8,0)},o.deflateInit2=N,o.deflateReset=D,o.deflateResetKeep=vt,o.deflateSetHeader=function(p,j){return p&&p.state?p.state.wrap!==2?k:(p.state.gzhead=j,f):k},o.deflate=function(p,j){var R,S,I,L;if(!p||!p.state||5<j||j<0)return p?H(p,k):k;if(S=p.state,!p.output||!p.input&&p.avail_in!==0||S.status===666&&j!==m)return H(p,p.avail_out===0?-5:k);if(S.strm=p,R=S.last_flush,S.last_flush=j,S.status===A)if(S.wrap===2)p.adler=0,lt(S,31),lt(S,139),lt(S,8),S.gzhead?(lt(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),lt(S,255&S.gzhead.time),lt(S,S.gzhead.time>>8&255),lt(S,S.gzhead.time>>16&255),lt(S,S.gzhead.time>>24&255),lt(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),lt(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(lt(S,255&S.gzhead.extra.length),lt(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(p.adler=c(p.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(lt(S,0),lt(S,0),lt(S,0),lt(S,0),lt(S,0),lt(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),lt(S,3),S.status=E);else{var G=w+(S.w_bits-8<<4)<<8;G|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(G|=32),G+=31-G%31,S.status=E,at(S,G),S.strstart!==0&&(at(S,p.adler>>>16),at(S,65535&p.adler)),p.adler=1}if(S.status===69)if(S.gzhead.extra){for(I=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),K(p),I=S.pending,S.pending!==S.pending_buf_size));)lt(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),K(p),I=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,lt(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),L===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),K(p),I=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,lt(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>I&&(p.adler=c(p.adler,S.pending_buf,S.pending-I,I)),L===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&K(p),S.pending+2<=S.pending_buf_size&&(lt(S,255&p.adler),lt(S,p.adler>>8&255),p.adler=0,S.status=E)):S.status=E),S.pending!==0){if(K(p),p.avail_out===0)return S.last_flush=-1,f}else if(p.avail_in===0&&U(j)<=U(R)&&j!==m)return H(p,-5);if(S.status===666&&p.avail_in!==0)return H(p,-5);if(p.avail_in!==0||S.lookahead!==0||j!==u&&S.status!==666){var V=S.strategy===2?(function(W,Y){for(var nt;;){if(W.lookahead===0&&(Q(W),W.lookahead===0)){if(Y===u)return g;break}if(W.match_length=0,nt=s._tr_tally(W,0,W.window[W.strstart]),W.lookahead--,W.strstart++,nt&&(q(W,!1),W.strm.avail_out===0))return g}return W.insert=0,Y===m?(q(W,!0),W.strm.avail_out===0?z:P):W.last_lit&&(q(W,!1),W.strm.avail_out===0)?g:F})(S,j):S.strategy===3?(function(W,Y){for(var nt,et,ct,xt,bt=W.window;;){if(W.lookahead<=O){if(Q(W),W.lookahead<=O&&Y===u)return g;if(W.lookahead===0)break}if(W.match_length=0,W.lookahead>=M&&0<W.strstart&&(et=bt[ct=W.strstart-1])===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]){xt=W.strstart+O;do;while(et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&et===bt[++ct]&&ct<xt);W.match_length=O-(xt-ct),W.match_length>W.lookahead&&(W.match_length=W.lookahead)}if(W.match_length>=M?(nt=s._tr_tally(W,1,W.match_length-M),W.lookahead-=W.match_length,W.strstart+=W.match_length,W.match_length=0):(nt=s._tr_tally(W,0,W.window[W.strstart]),W.lookahead--,W.strstart++),nt&&(q(W,!1),W.strm.avail_out===0))return g}return W.insert=0,Y===m?(q(W,!0),W.strm.avail_out===0?z:P):W.last_lit&&(q(W,!1),W.strm.avail_out===0)?g:F})(S,j):r[S.level].func(S,j);if(V!==z&&V!==P||(S.status=666),V===g||V===z)return p.avail_out===0&&(S.last_flush=-1),f;if(V===F&&(j===1?s._tr_align(S):j!==5&&(s._tr_stored_block(S,0,0,!1),j===3&&(X(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),K(p),p.avail_out===0))return S.last_flush=-1,f}return j!==m?f:S.wrap<=0?1:(S.wrap===2?(lt(S,255&p.adler),lt(S,p.adler>>8&255),lt(S,p.adler>>16&255),lt(S,p.adler>>24&255),lt(S,255&p.total_in),lt(S,p.total_in>>8&255),lt(S,p.total_in>>16&255),lt(S,p.total_in>>24&255)):(at(S,p.adler>>>16),at(S,65535&p.adler)),K(p),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?f:1)},o.deflateEnd=function(p){var j;return p&&p.state?(j=p.state.status)!==A&&j!==69&&j!==73&&j!==91&&j!==103&&j!==E&&j!==666?H(p,k):(p.state=null,j===E?H(p,-3):f):k},o.deflateSetDictionary=function(p,j){var R,S,I,L,G,V,W,Y,nt=j.length;if(!p||!p.state||(L=(R=p.state).wrap)===2||L===1&&R.status!==A||R.lookahead)return k;for(L===1&&(p.adler=a(p.adler,j,nt,0)),R.wrap=0,nt>=R.w_size&&(L===0&&(X(R.head),R.strstart=0,R.block_start=0,R.insert=0),Y=new l.Buf8(R.w_size),l.arraySet(Y,j,nt-R.w_size,R.w_size,0),j=Y,nt=R.w_size),G=p.avail_in,V=p.next_in,W=p.input,p.avail_in=nt,p.next_in=0,p.input=j,Q(R);R.lookahead>=M;){for(S=R.strstart,I=R.lookahead-(M-1);R.ins_h=(R.ins_h<<R.hash_shift^R.window[S+M-1])&R.hash_mask,R.prev[S&R.w_mask]=R.head[R.ins_h],R.head[R.ins_h]=S,S++,--I;);R.strstart=S,R.lookahead=M-1,Q(R)}return R.strstart+=R.lookahead,R.block_start=R.strstart,R.insert=R.lookahead,R.lookahead=0,R.match_length=R.prev_length=M-1,R.match_available=0,p.next_in=V,p.input=W,p.avail_in=G,R.wrap=L,f},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(r,l){var s,a,c,d,u,m,f,k,h,y,b,w,_,T,x,$,C,B,M,O,Z,A,E,g,F;s=r.state,a=r.next_in,g=r.input,c=a+(r.avail_in-5),d=r.next_out,F=r.output,u=d-(l-r.avail_out),m=d+(r.avail_out-257),f=s.dmax,k=s.wsize,h=s.whave,y=s.wnext,b=s.window,w=s.hold,_=s.bits,T=s.lencode,x=s.distcode,$=(1<<s.lenbits)-1,C=(1<<s.distbits)-1;t:do{_<15&&(w+=g[a++]<<_,_+=8,w+=g[a++]<<_,_+=8),B=T[w&$];e:for(;;){if(w>>>=M=B>>>24,_-=M,(M=B>>>16&255)===0)F[d++]=65535&B;else{if(!(16&M)){if((64&M)==0){B=T[(65535&B)+(w&(1<<M)-1)];continue e}if(32&M){s.mode=12;break t}r.msg="invalid literal/length code",s.mode=30;break t}O=65535&B,(M&=15)&&(_<M&&(w+=g[a++]<<_,_+=8),O+=w&(1<<M)-1,w>>>=M,_-=M),_<15&&(w+=g[a++]<<_,_+=8,w+=g[a++]<<_,_+=8),B=x[w&C];i:for(;;){if(w>>>=M=B>>>24,_-=M,!(16&(M=B>>>16&255))){if((64&M)==0){B=x[(65535&B)+(w&(1<<M)-1)];continue i}r.msg="invalid distance code",s.mode=30;break t}if(Z=65535&B,_<(M&=15)&&(w+=g[a++]<<_,(_+=8)<M&&(w+=g[a++]<<_,_+=8)),f<(Z+=w&(1<<M)-1)){r.msg="invalid distance too far back",s.mode=30;break t}if(w>>>=M,_-=M,(M=d-u)<Z){if(h<(M=Z-M)&&s.sane){r.msg="invalid distance too far back",s.mode=30;break t}if(E=b,(A=0)===y){if(A+=k-M,M<O){for(O-=M;F[d++]=b[A++],--M;);A=d-Z,E=F}}else if(y<M){if(A+=k+y-M,(M-=y)<O){for(O-=M;F[d++]=b[A++],--M;);if(A=0,y<O){for(O-=M=y;F[d++]=b[A++],--M;);A=d-Z,E=F}}}else if(A+=y-M,M<O){for(O-=M;F[d++]=b[A++],--M;);A=d-Z,E=F}for(;2<O;)F[d++]=E[A++],F[d++]=E[A++],F[d++]=E[A++],O-=3;O&&(F[d++]=E[A++],1<O&&(F[d++]=E[A++]))}else{for(A=d-Z;F[d++]=F[A++],F[d++]=F[A++],F[d++]=F[A++],2<(O-=3););O&&(F[d++]=F[A++],1<O&&(F[d++]=F[A++]))}break}}break}}while(a<c&&d<m);a-=O=_>>3,w&=(1<<(_-=O<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<m?m-d+257:257-(d-m),s.hold=w,s.bits=_}},{}],49:[function(e,n,o){var r=e("../utils/common"),l=e("./adler32"),s=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,u=2,m=0,f=-2,k=1,h=852,y=592;function b(A){return(A>>>24&255)+(A>>>8&65280)+((65280&A)<<8)+((255&A)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(A){var E;return A&&A.state?(E=A.state,A.total_in=A.total_out=E.total=0,A.msg="",E.wrap&&(A.adler=1&E.wrap),E.mode=k,E.last=0,E.havedict=0,E.dmax=32768,E.head=null,E.hold=0,E.bits=0,E.lencode=E.lendyn=new r.Buf32(h),E.distcode=E.distdyn=new r.Buf32(y),E.sane=1,E.back=-1,m):f}function T(A){var E;return A&&A.state?((E=A.state).wsize=0,E.whave=0,E.wnext=0,_(A)):f}function x(A,E){var g,F;return A&&A.state?(F=A.state,E<0?(g=0,E=-E):(g=1+(E>>4),E<48&&(E&=15)),E&&(E<8||15<E)?f:(F.window!==null&&F.wbits!==E&&(F.window=null),F.wrap=g,F.wbits=E,T(A))):f}function $(A,E){var g,F;return A?(F=new w,(A.state=F).window=null,(g=x(A,E))!==m&&(A.state=null),g):f}var C,B,M=!0;function O(A){if(M){var E;for(C=new r.Buf32(512),B=new r.Buf32(32),E=0;E<144;)A.lens[E++]=8;for(;E<256;)A.lens[E++]=9;for(;E<280;)A.lens[E++]=7;for(;E<288;)A.lens[E++]=8;for(c(d,A.lens,0,288,C,0,A.work,{bits:9}),E=0;E<32;)A.lens[E++]=5;c(u,A.lens,0,32,B,0,A.work,{bits:5}),M=!1}A.lencode=C,A.lenbits=9,A.distcode=B,A.distbits=5}function Z(A,E,g,F){var z,P=A.state;return P.window===null&&(P.wsize=1<<P.wbits,P.wnext=0,P.whave=0,P.window=new r.Buf8(P.wsize)),F>=P.wsize?(r.arraySet(P.window,E,g-P.wsize,P.wsize,0),P.wnext=0,P.whave=P.wsize):(F<(z=P.wsize-P.wnext)&&(z=F),r.arraySet(P.window,E,g-F,z,P.wnext),(F-=z)?(r.arraySet(P.window,E,g-F,F,0),P.wnext=F,P.whave=P.wsize):(P.wnext+=z,P.wnext===P.wsize&&(P.wnext=0),P.whave<P.wsize&&(P.whave+=z))),0}o.inflateReset=T,o.inflateReset2=x,o.inflateResetKeep=_,o.inflateInit=function(A){return $(A,15)},o.inflateInit2=$,o.inflate=function(A,E){var g,F,z,P,H,U,X,K,q,lt,at,st,Q,pt,gt,J,rt,vt,D,N,p,j,R,S,I=0,L=new r.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!A||!A.state||!A.output||!A.input&&A.avail_in!==0)return f;(g=A.state).mode===12&&(g.mode=13),H=A.next_out,z=A.output,X=A.avail_out,P=A.next_in,F=A.input,U=A.avail_in,K=g.hold,q=g.bits,lt=U,at=X,j=m;t:for(;;)switch(g.mode){case k:if(g.wrap===0){g.mode=13;break}for(;q<16;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(2&g.wrap&&K===35615){L[g.check=0]=255&K,L[1]=K>>>8&255,g.check=s(g.check,L,2,0),q=K=0,g.mode=2;break}if(g.flags=0,g.head&&(g.head.done=!1),!(1&g.wrap)||(((255&K)<<8)+(K>>8))%31){A.msg="incorrect header check",g.mode=30;break}if((15&K)!=8){A.msg="unknown compression method",g.mode=30;break}if(q-=4,p=8+(15&(K>>>=4)),g.wbits===0)g.wbits=p;else if(p>g.wbits){A.msg="invalid window size",g.mode=30;break}g.dmax=1<<p,A.adler=g.check=1,g.mode=512&K?10:12,q=K=0;break;case 2:for(;q<16;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(g.flags=K,(255&g.flags)!=8){A.msg="unknown compression method",g.mode=30;break}if(57344&g.flags){A.msg="unknown header flags set",g.mode=30;break}g.head&&(g.head.text=K>>8&1),512&g.flags&&(L[0]=255&K,L[1]=K>>>8&255,g.check=s(g.check,L,2,0)),q=K=0,g.mode=3;case 3:for(;q<32;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.head&&(g.head.time=K),512&g.flags&&(L[0]=255&K,L[1]=K>>>8&255,L[2]=K>>>16&255,L[3]=K>>>24&255,g.check=s(g.check,L,4,0)),q=K=0,g.mode=4;case 4:for(;q<16;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.head&&(g.head.xflags=255&K,g.head.os=K>>8),512&g.flags&&(L[0]=255&K,L[1]=K>>>8&255,g.check=s(g.check,L,2,0)),q=K=0,g.mode=5;case 5:if(1024&g.flags){for(;q<16;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.length=K,g.head&&(g.head.extra_len=K),512&g.flags&&(L[0]=255&K,L[1]=K>>>8&255,g.check=s(g.check,L,2,0)),q=K=0}else g.head&&(g.head.extra=null);g.mode=6;case 6:if(1024&g.flags&&(U<(st=g.length)&&(st=U),st&&(g.head&&(p=g.head.extra_len-g.length,g.head.extra||(g.head.extra=new Array(g.head.extra_len)),r.arraySet(g.head.extra,F,P,st,p)),512&g.flags&&(g.check=s(g.check,F,st,P)),U-=st,P+=st,g.length-=st),g.length))break t;g.length=0,g.mode=7;case 7:if(2048&g.flags){if(U===0)break t;for(st=0;p=F[P+st++],g.head&&p&&g.length<65536&&(g.head.name+=String.fromCharCode(p)),p&&st<U;);if(512&g.flags&&(g.check=s(g.check,F,st,P)),U-=st,P+=st,p)break t}else g.head&&(g.head.name=null);g.length=0,g.mode=8;case 8:if(4096&g.flags){if(U===0)break t;for(st=0;p=F[P+st++],g.head&&p&&g.length<65536&&(g.head.comment+=String.fromCharCode(p)),p&&st<U;);if(512&g.flags&&(g.check=s(g.check,F,st,P)),U-=st,P+=st,p)break t}else g.head&&(g.head.comment=null);g.mode=9;case 9:if(512&g.flags){for(;q<16;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(K!==(65535&g.check)){A.msg="header crc mismatch",g.mode=30;break}q=K=0}g.head&&(g.head.hcrc=g.flags>>9&1,g.head.done=!0),A.adler=g.check=0,g.mode=12;break;case 10:for(;q<32;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}A.adler=g.check=b(K),q=K=0,g.mode=11;case 11:if(g.havedict===0)return A.next_out=H,A.avail_out=X,A.next_in=P,A.avail_in=U,g.hold=K,g.bits=q,2;A.adler=g.check=1,g.mode=12;case 12:if(E===5||E===6)break t;case 13:if(g.last){K>>>=7&q,q-=7&q,g.mode=27;break}for(;q<3;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}switch(g.last=1&K,q-=1,3&(K>>>=1)){case 0:g.mode=14;break;case 1:if(O(g),g.mode=20,E!==6)break;K>>>=2,q-=2;break t;case 2:g.mode=17;break;case 3:A.msg="invalid block type",g.mode=30}K>>>=2,q-=2;break;case 14:for(K>>>=7&q,q-=7&q;q<32;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if((65535&K)!=(K>>>16^65535)){A.msg="invalid stored block lengths",g.mode=30;break}if(g.length=65535&K,q=K=0,g.mode=15,E===6)break t;case 15:g.mode=16;case 16:if(st=g.length){if(U<st&&(st=U),X<st&&(st=X),st===0)break t;r.arraySet(z,F,P,st,H),U-=st,P+=st,X-=st,H+=st,g.length-=st;break}g.mode=12;break;case 17:for(;q<14;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(g.nlen=257+(31&K),K>>>=5,q-=5,g.ndist=1+(31&K),K>>>=5,q-=5,g.ncode=4+(15&K),K>>>=4,q-=4,286<g.nlen||30<g.ndist){A.msg="too many length or distance symbols",g.mode=30;break}g.have=0,g.mode=18;case 18:for(;g.have<g.ncode;){for(;q<3;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.lens[G[g.have++]]=7&K,K>>>=3,q-=3}for(;g.have<19;)g.lens[G[g.have++]]=0;if(g.lencode=g.lendyn,g.lenbits=7,R={bits:g.lenbits},j=c(0,g.lens,0,19,g.lencode,0,g.work,R),g.lenbits=R.bits,j){A.msg="invalid code lengths set",g.mode=30;break}g.have=0,g.mode=19;case 19:for(;g.have<g.nlen+g.ndist;){for(;J=(I=g.lencode[K&(1<<g.lenbits)-1])>>>16&255,rt=65535&I,!((gt=I>>>24)<=q);){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(rt<16)K>>>=gt,q-=gt,g.lens[g.have++]=rt;else{if(rt===16){for(S=gt+2;q<S;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(K>>>=gt,q-=gt,g.have===0){A.msg="invalid bit length repeat",g.mode=30;break}p=g.lens[g.have-1],st=3+(3&K),K>>>=2,q-=2}else if(rt===17){for(S=gt+3;q<S;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}q-=gt,p=0,st=3+(7&(K>>>=gt)),K>>>=3,q-=3}else{for(S=gt+7;q<S;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}q-=gt,p=0,st=11+(127&(K>>>=gt)),K>>>=7,q-=7}if(g.have+st>g.nlen+g.ndist){A.msg="invalid bit length repeat",g.mode=30;break}for(;st--;)g.lens[g.have++]=p}}if(g.mode===30)break;if(g.lens[256]===0){A.msg="invalid code -- missing end-of-block",g.mode=30;break}if(g.lenbits=9,R={bits:g.lenbits},j=c(d,g.lens,0,g.nlen,g.lencode,0,g.work,R),g.lenbits=R.bits,j){A.msg="invalid literal/lengths set",g.mode=30;break}if(g.distbits=6,g.distcode=g.distdyn,R={bits:g.distbits},j=c(u,g.lens,g.nlen,g.ndist,g.distcode,0,g.work,R),g.distbits=R.bits,j){A.msg="invalid distances set",g.mode=30;break}if(g.mode=20,E===6)break t;case 20:g.mode=21;case 21:if(6<=U&&258<=X){A.next_out=H,A.avail_out=X,A.next_in=P,A.avail_in=U,g.hold=K,g.bits=q,a(A,at),H=A.next_out,z=A.output,X=A.avail_out,P=A.next_in,F=A.input,U=A.avail_in,K=g.hold,q=g.bits,g.mode===12&&(g.back=-1);break}for(g.back=0;J=(I=g.lencode[K&(1<<g.lenbits)-1])>>>16&255,rt=65535&I,!((gt=I>>>24)<=q);){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(J&&(240&J)==0){for(vt=gt,D=J,N=rt;J=(I=g.lencode[N+((K&(1<<vt+D)-1)>>vt)])>>>16&255,rt=65535&I,!(vt+(gt=I>>>24)<=q);){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}K>>>=vt,q-=vt,g.back+=vt}if(K>>>=gt,q-=gt,g.back+=gt,g.length=rt,J===0){g.mode=26;break}if(32&J){g.back=-1,g.mode=12;break}if(64&J){A.msg="invalid literal/length code",g.mode=30;break}g.extra=15&J,g.mode=22;case 22:if(g.extra){for(S=g.extra;q<S;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.length+=K&(1<<g.extra)-1,K>>>=g.extra,q-=g.extra,g.back+=g.extra}g.was=g.length,g.mode=23;case 23:for(;J=(I=g.distcode[K&(1<<g.distbits)-1])>>>16&255,rt=65535&I,!((gt=I>>>24)<=q);){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if((240&J)==0){for(vt=gt,D=J,N=rt;J=(I=g.distcode[N+((K&(1<<vt+D)-1)>>vt)])>>>16&255,rt=65535&I,!(vt+(gt=I>>>24)<=q);){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}K>>>=vt,q-=vt,g.back+=vt}if(K>>>=gt,q-=gt,g.back+=gt,64&J){A.msg="invalid distance code",g.mode=30;break}g.offset=rt,g.extra=15&J,g.mode=24;case 24:if(g.extra){for(S=g.extra;q<S;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}g.offset+=K&(1<<g.extra)-1,K>>>=g.extra,q-=g.extra,g.back+=g.extra}if(g.offset>g.dmax){A.msg="invalid distance too far back",g.mode=30;break}g.mode=25;case 25:if(X===0)break t;if(st=at-X,g.offset>st){if((st=g.offset-st)>g.whave&&g.sane){A.msg="invalid distance too far back",g.mode=30;break}Q=st>g.wnext?(st-=g.wnext,g.wsize-st):g.wnext-st,st>g.length&&(st=g.length),pt=g.window}else pt=z,Q=H-g.offset,st=g.length;for(X<st&&(st=X),X-=st,g.length-=st;z[H++]=pt[Q++],--st;);g.length===0&&(g.mode=21);break;case 26:if(X===0)break t;z[H++]=g.length,X--,g.mode=21;break;case 27:if(g.wrap){for(;q<32;){if(U===0)break t;U--,K|=F[P++]<<q,q+=8}if(at-=X,A.total_out+=at,g.total+=at,at&&(A.adler=g.check=g.flags?s(g.check,z,at,H-at):l(g.check,z,at,H-at)),at=X,(g.flags?K:b(K))!==g.check){A.msg="incorrect data check",g.mode=30;break}q=K=0}g.mode=28;case 28:if(g.wrap&&g.flags){for(;q<32;){if(U===0)break t;U--,K+=F[P++]<<q,q+=8}if(K!==(4294967295&g.total)){A.msg="incorrect length check",g.mode=30;break}q=K=0}g.mode=29;case 29:j=1;break t;case 30:j=-3;break t;case 31:return-4;case 32:default:return f}return A.next_out=H,A.avail_out=X,A.next_in=P,A.avail_in=U,g.hold=K,g.bits=q,(g.wsize||at!==A.avail_out&&g.mode<30&&(g.mode<27||E!==4))&&Z(A,A.output,A.next_out,at-A.avail_out)?(g.mode=31,-4):(lt-=A.avail_in,at-=A.avail_out,A.total_in+=lt,A.total_out+=at,g.total+=at,g.wrap&&at&&(A.adler=g.check=g.flags?s(g.check,z,at,A.next_out-at):l(g.check,z,at,A.next_out-at)),A.data_type=g.bits+(g.last?64:0)+(g.mode===12?128:0)+(g.mode===20||g.mode===15?256:0),(lt==0&&at===0||E===4)&&j===m&&(j=-5),j)},o.inflateEnd=function(A){if(!A||!A.state)return f;var E=A.state;return E.window&&(E.window=null),A.state=null,m},o.inflateGetHeader=function(A,E){var g;return A&&A.state?(2&(g=A.state).wrap)==0?f:((g.head=E).done=!1,m):f},o.inflateSetDictionary=function(A,E){var g,F=E.length;return A&&A.state?(g=A.state).wrap!==0&&g.mode!==11?f:g.mode===11&&l(1,E,F,0)!==g.check?-3:Z(A,E,F,F)?(g.mode=31,-4):(g.havedict=1,m):f},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],s=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,u,m,f,k,h,y,b){var w,_,T,x,$,C,B,M,O,Z=b.bits,A=0,E=0,g=0,F=0,z=0,P=0,H=0,U=0,X=0,K=0,q=null,lt=0,at=new r.Buf16(16),st=new r.Buf16(16),Q=null,pt=0;for(A=0;A<=15;A++)at[A]=0;for(E=0;E<f;E++)at[u[m+E]]++;for(z=Z,F=15;1<=F&&at[F]===0;F--);if(F<z&&(z=F),F===0)return k[h++]=20971520,k[h++]=20971520,b.bits=1,0;for(g=1;g<F&&at[g]===0;g++);for(z<g&&(z=g),A=U=1;A<=15;A++)if(U<<=1,(U-=at[A])<0)return-1;if(0<U&&(d===0||F!==1))return-1;for(st[1]=0,A=1;A<15;A++)st[A+1]=st[A]+at[A];for(E=0;E<f;E++)u[m+E]!==0&&(y[st[u[m+E]]++]=E);if(C=d===0?(q=Q=y,19):d===1?(q=l,lt-=257,Q=s,pt-=257,256):(q=a,Q=c,-1),A=g,$=h,H=E=K=0,T=-1,x=(X=1<<(P=z))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(B=A-H,O=y[E]<C?(M=0,y[E]):y[E]>C?(M=Q[pt+y[E]],q[lt+y[E]]):(M=96,0),w=1<<A-H,g=_=1<<P;k[$+(K>>H)+(_-=w)]=B<<24|M<<16|O|0,_!==0;);for(w=1<<A-1;K&w;)w>>=1;if(w!==0?(K&=w-1,K+=w):K=0,E++,--at[A]==0){if(A===F)break;A=u[m+y[E]]}if(z<A&&(K&x)!==T){for(H===0&&(H=z),$+=g,U=1<<(P=A-H);P+H<F&&!((U-=at[P+H])<=0);)P++,U<<=1;if(X+=1<<P,d===1&&852<X||d===2&&592<X)return 1;k[T=K&x]=z<<24|P<<16|$-h|0}}return K!==0&&(k[$+K]=A-H<<24|64<<16|0),b.bits=z,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var r=e("../utils/common"),l=0,s=1;function a(I){for(var L=I.length;0<=--L;)I[L]=0}var c=0,d=29,u=256,m=u+1+d,f=30,k=19,h=2*m+1,y=15,b=16,w=7,_=256,T=16,x=17,$=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],B=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],O=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Z=new Array(2*(m+2));a(Z);var A=new Array(2*f);a(A);var E=new Array(512);a(E);var g=new Array(256);a(g);var F=new Array(d);a(F);var z,P,H,U=new Array(f);function X(I,L,G,V,W){this.static_tree=I,this.extra_bits=L,this.extra_base=G,this.elems=V,this.max_length=W,this.has_stree=I&&I.length}function K(I,L){this.dyn_tree=I,this.max_code=0,this.stat_desc=L}function q(I){return I<256?E[I]:E[256+(I>>>7)]}function lt(I,L){I.pending_buf[I.pending++]=255&L,I.pending_buf[I.pending++]=L>>>8&255}function at(I,L,G){I.bi_valid>b-G?(I.bi_buf|=L<<I.bi_valid&65535,lt(I,I.bi_buf),I.bi_buf=L>>b-I.bi_valid,I.bi_valid+=G-b):(I.bi_buf|=L<<I.bi_valid&65535,I.bi_valid+=G)}function st(I,L,G){at(I,G[2*L],G[2*L+1])}function Q(I,L){for(var G=0;G|=1&I,I>>>=1,G<<=1,0<--L;);return G>>>1}function pt(I,L,G){var V,W,Y=new Array(y+1),nt=0;for(V=1;V<=y;V++)Y[V]=nt=nt+G[V-1]<<1;for(W=0;W<=L;W++){var et=I[2*W+1];et!==0&&(I[2*W]=Q(Y[et]++,et))}}function gt(I){var L;for(L=0;L<m;L++)I.dyn_ltree[2*L]=0;for(L=0;L<f;L++)I.dyn_dtree[2*L]=0;for(L=0;L<k;L++)I.bl_tree[2*L]=0;I.dyn_ltree[2*_]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function J(I){8<I.bi_valid?lt(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function rt(I,L,G,V){var W=2*L,Y=2*G;return I[W]<I[Y]||I[W]===I[Y]&&V[L]<=V[G]}function vt(I,L,G){for(var V=I.heap[G],W=G<<1;W<=I.heap_len&&(W<I.heap_len&&rt(L,I.heap[W+1],I.heap[W],I.depth)&&W++,!rt(L,V,I.heap[W],I.depth));)I.heap[G]=I.heap[W],G=W,W<<=1;I.heap[G]=V}function D(I,L,G){var V,W,Y,nt,et=0;if(I.last_lit!==0)for(;V=I.pending_buf[I.d_buf+2*et]<<8|I.pending_buf[I.d_buf+2*et+1],W=I.pending_buf[I.l_buf+et],et++,V===0?st(I,W,L):(st(I,(Y=g[W])+u+1,L),(nt=C[Y])!==0&&at(I,W-=F[Y],nt),st(I,Y=q(--V),G),(nt=B[Y])!==0&&at(I,V-=U[Y],nt)),et<I.last_lit;);st(I,_,L)}function N(I,L){var G,V,W,Y=L.dyn_tree,nt=L.stat_desc.static_tree,et=L.stat_desc.has_stree,ct=L.stat_desc.elems,xt=-1;for(I.heap_len=0,I.heap_max=h,G=0;G<ct;G++)Y[2*G]!==0?(I.heap[++I.heap_len]=xt=G,I.depth[G]=0):Y[2*G+1]=0;for(;I.heap_len<2;)Y[2*(W=I.heap[++I.heap_len]=xt<2?++xt:0)]=1,I.depth[W]=0,I.opt_len--,et&&(I.static_len-=nt[2*W+1]);for(L.max_code=xt,G=I.heap_len>>1;1<=G;G--)vt(I,Y,G);for(W=ct;G=I.heap[1],I.heap[1]=I.heap[I.heap_len--],vt(I,Y,1),V=I.heap[1],I.heap[--I.heap_max]=G,I.heap[--I.heap_max]=V,Y[2*W]=Y[2*G]+Y[2*V],I.depth[W]=(I.depth[G]>=I.depth[V]?I.depth[G]:I.depth[V])+1,Y[2*G+1]=Y[2*V+1]=W,I.heap[1]=W++,vt(I,Y,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(bt,Et){var Wt,Kt,Qt,Pt,Ve,Jt,Gt=Et.dyn_tree,bi=Et.max_code,Pi=Et.stat_desc.static_tree,Dn=Et.stat_desc.has_stree,Ao=Et.stat_desc.extra_bits,Ln=Et.stat_desc.extra_base,yi=Et.stat_desc.max_length,Oi=0;for(Pt=0;Pt<=y;Pt++)bt.bl_count[Pt]=0;for(Gt[2*bt.heap[bt.heap_max]+1]=0,Wt=bt.heap_max+1;Wt<h;Wt++)yi<(Pt=Gt[2*Gt[2*(Kt=bt.heap[Wt])+1]+1]+1)&&(Pt=yi,Oi++),Gt[2*Kt+1]=Pt,bi<Kt||(bt.bl_count[Pt]++,Ve=0,Ln<=Kt&&(Ve=Ao[Kt-Ln]),Jt=Gt[2*Kt],bt.opt_len+=Jt*(Pt+Ve),Dn&&(bt.static_len+=Jt*(Pi[2*Kt+1]+Ve)));if(Oi!==0){do{for(Pt=yi-1;bt.bl_count[Pt]===0;)Pt--;bt.bl_count[Pt]--,bt.bl_count[Pt+1]+=2,bt.bl_count[yi]--,Oi-=2}while(0<Oi);for(Pt=yi;Pt!==0;Pt--)for(Kt=bt.bl_count[Pt];Kt!==0;)bi<(Qt=bt.heap[--Wt])||(Gt[2*Qt+1]!==Pt&&(bt.opt_len+=(Pt-Gt[2*Qt+1])*Gt[2*Qt],Gt[2*Qt+1]=Pt),Kt--)}})(I,L),pt(Y,xt,I.bl_count)}function p(I,L,G){var V,W,Y=-1,nt=L[1],et=0,ct=7,xt=4;for(nt===0&&(ct=138,xt=3),L[2*(G+1)+1]=65535,V=0;V<=G;V++)W=nt,nt=L[2*(V+1)+1],++et<ct&&W===nt||(et<xt?I.bl_tree[2*W]+=et:W!==0?(W!==Y&&I.bl_tree[2*W]++,I.bl_tree[2*T]++):et<=10?I.bl_tree[2*x]++:I.bl_tree[2*$]++,Y=W,xt=(et=0)===nt?(ct=138,3):W===nt?(ct=6,3):(ct=7,4))}function j(I,L,G){var V,W,Y=-1,nt=L[1],et=0,ct=7,xt=4;for(nt===0&&(ct=138,xt=3),V=0;V<=G;V++)if(W=nt,nt=L[2*(V+1)+1],!(++et<ct&&W===nt)){if(et<xt)for(;st(I,W,I.bl_tree),--et!=0;);else W!==0?(W!==Y&&(st(I,W,I.bl_tree),et--),st(I,T,I.bl_tree),at(I,et-3,2)):et<=10?(st(I,x,I.bl_tree),at(I,et-3,3)):(st(I,$,I.bl_tree),at(I,et-11,7));Y=W,xt=(et=0)===nt?(ct=138,3):W===nt?(ct=6,3):(ct=7,4)}}a(U);var R=!1;function S(I,L,G,V){at(I,(c<<1)+(V?1:0),3),(function(W,Y,nt,et){J(W),lt(W,nt),lt(W,~nt),r.arraySet(W.pending_buf,W.window,Y,nt,W.pending),W.pending+=nt})(I,L,G)}o._tr_init=function(I){R||((function(){var L,G,V,W,Y,nt=new Array(y+1);for(W=V=0;W<d-1;W++)for(F[W]=V,L=0;L<1<<C[W];L++)g[V++]=W;for(g[V-1]=W,W=Y=0;W<16;W++)for(U[W]=Y,L=0;L<1<<B[W];L++)E[Y++]=W;for(Y>>=7;W<f;W++)for(U[W]=Y<<7,L=0;L<1<<B[W]-7;L++)E[256+Y++]=W;for(G=0;G<=y;G++)nt[G]=0;for(L=0;L<=143;)Z[2*L+1]=8,L++,nt[8]++;for(;L<=255;)Z[2*L+1]=9,L++,nt[9]++;for(;L<=279;)Z[2*L+1]=7,L++,nt[7]++;for(;L<=287;)Z[2*L+1]=8,L++,nt[8]++;for(pt(Z,m+1,nt),L=0;L<f;L++)A[2*L+1]=5,A[2*L]=Q(L,5);z=new X(Z,C,u+1,m,y),P=new X(A,B,0,f,y),H=new X(new Array(0),M,0,k,w)})(),R=!0),I.l_desc=new K(I.dyn_ltree,z),I.d_desc=new K(I.dyn_dtree,P),I.bl_desc=new K(I.bl_tree,H),I.bi_buf=0,I.bi_valid=0,gt(I)},o._tr_stored_block=S,o._tr_flush_block=function(I,L,G,V){var W,Y,nt=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(et){var ct,xt=4093624447;for(ct=0;ct<=31;ct++,xt>>>=1)if(1&xt&&et.dyn_ltree[2*ct]!==0)return l;if(et.dyn_ltree[18]!==0||et.dyn_ltree[20]!==0||et.dyn_ltree[26]!==0)return s;for(ct=32;ct<u;ct++)if(et.dyn_ltree[2*ct]!==0)return s;return l})(I)),N(I,I.l_desc),N(I,I.d_desc),nt=(function(et){var ct;for(p(et,et.dyn_ltree,et.l_desc.max_code),p(et,et.dyn_dtree,et.d_desc.max_code),N(et,et.bl_desc),ct=k-1;3<=ct&&et.bl_tree[2*O[ct]+1]===0;ct--);return et.opt_len+=3*(ct+1)+5+5+4,ct})(I),W=I.opt_len+3+7>>>3,(Y=I.static_len+3+7>>>3)<=W&&(W=Y)):W=Y=G+5,G+4<=W&&L!==-1?S(I,L,G,V):I.strategy===4||Y===W?(at(I,2+(V?1:0),3),D(I,Z,A)):(at(I,4+(V?1:0),3),(function(et,ct,xt,bt){var Et;for(at(et,ct-257,5),at(et,xt-1,5),at(et,bt-4,4),Et=0;Et<bt;Et++)at(et,et.bl_tree[2*O[Et]+1],3);j(et,et.dyn_ltree,ct-1),j(et,et.dyn_dtree,xt-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,nt+1),D(I,I.dyn_ltree,I.dyn_dtree)),gt(I),V&&J(I)},o._tr_tally=function(I,L,G){return I.pending_buf[I.d_buf+2*I.last_lit]=L>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&L,I.pending_buf[I.l_buf+I.last_lit]=255&G,I.last_lit++,L===0?I.dyn_ltree[2*G]++:(I.matches++,L--,I.dyn_ltree[2*(g[G]+u+1)]++,I.dyn_dtree[2*q(L)]++),I.last_lit===I.lit_bufsize-1},o._tr_align=function(I){at(I,2,3),st(I,_,Z),(function(L){L.bi_valid===16?(lt(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(r){(function(l,s){if(!l.setImmediate){var a,c,d,u,m=1,f={},k=!1,h=l.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(l);y=y&&y.setTimeout?y:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){w(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,x=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=x,T}})()?(u="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(T){l.postMessage(u+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){w(T.data)},function(T){d.port2.postMessage(T)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(T){var x=h.createElement("script");x.onreadystatechange=function(){w(T),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(T){setTimeout(w,0,T)},y.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var x=new Array(arguments.length-1),$=0;$<x.length;$++)x[$]=arguments[$+1];var C={callback:T,args:x};return f[m]=C,a(m),m++},y.clearImmediate=b}function b(T){delete f[T]}function w(T){if(k)setTimeout(w,0,T);else{var x=f[T];if(x){k=!0;try{(function($){var C=$.callback,B=$.args;switch(B.length){case 0:C();break;case 1:C(B[0]);break;case 2:C(B[0],B[1]);break;case 3:C(B[0],B[1],B[2]);break;default:C.apply(s,B)}})(x)}finally{b(T),k=!1}}}}function _(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(u)===0&&w(+T.data.slice(u.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ho)),Ho.exports}var Iv=$v();const Av=Cv(Iv),Tv=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Ev=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Bv(t){const i=await Av.loadAsync(t),e={},n=[];let o="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let s=l.find(a=>a.path.toLowerCase()==="slides.md");s||(s=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),s||(s=l.find(a=>a.path.toLowerCase().endsWith(".md"))),s&&(o=await s.file.async("string"),r=s.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Ev.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const u=c.split("/");u.length>1&&(e[u.slice(1).join("/")]=d)}else if(Tv.test(c)){const d=await a.file.async("uint8array"),u=c.split("/").pop()||c,m=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:u,data:d,blob:m})}}return{entryMarkdown:o,entryMarkdownPath:r,virtualFiles:e,assets:n}}function Mv(t,i){if(Object.keys(i).length===0)return t;function e(o){const r=o.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const s=r.replace(/^\.?\//,"");return i[s]?i[s]:i[l]?i[l]:null}function n(o){let r=o;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,s,a)=>{const c=e(a);return c?`![${s}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,s)=>{const a=e(s);return a?`src="${a}"`:l}),r}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const r=o.pageAttrs["custom-slidev-background"],l=e(r);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],r=e(o);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function oa(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Dv(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),r=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",s=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[s]||a[`./${s}`]||a[`@/${s}`];if(!c&&Object.keys(a).length>0){const f=s.split("/").pop();for(const[k,h]of Object.entries(a))if(k.endsWith(`/${s}`)||f&&k.endsWith(`/${f}`)){c=h;break}}if(!c){const f=[];if(i!=null&&i.baseDir)try{const k=require("path");f.push(k.resolve(i.baseDir,s)),f.push(k.resolve(i.baseDir,r))}catch{}try{const k=require("path");f.push(k.resolve(process.cwd(),s))}catch{}for(const k of f){const h=oa(k);if(h!==null){c=h;break}}}if(!c){const f=Zl||{};if(c=f[r]||f[s]||f[`snippets/${s}`],!c){const k=s.split("/").pop();for(const[h,y]of Object.entries(f))if(h.endsWith(`/${s}`)||k&&h.endsWith(`/${k}`)){c=y;break}}}if(!c)return null;let d=c;if(l){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(f);if(k){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+k[1].trimEnd()}}const u=s.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${u?u[1]:""}
${d}
\`\`\``}function Lv(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Zn(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],r=o.trim();if(!r||r.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const s=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const u=e[n];if(!u.trim()){c.push(""),n++;continue}const f=u.match(/^(\s+)/),k=f?f[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(u.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[s]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Lv(a),!a){let c=n+1;const d=[];let u=-1;for(;c<e.length;){const m=e[c],f=m.trim();if(!f||f.startsWith("#")){u!==-1&&d.push(""),c++;continue}const k=m.match(/^(\s+)/),h=k?k[1].length:0;if(u===-1)if(h>0)u=h;else break;if(h<u)break;d.push(m.slice(u)),c++}if(d.length>0){i[s]=Zn(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[s]=a}n++}return i}const Pv=/^\s*```ya?ml([\s\S]*?)```/;function _r(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const r=Zn(n[1]);if(Object.keys(r).length>0||!n[1].trim())return i=r,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const o=e.match(Pv);if(o)i=Zn(o[1]),e=e.slice(o[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let s=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){s=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{s=a;break}}l.length>0&&(i=Zn(l.join(`
`)),e=r.slice(s).join(`
`).trim())}return{frontmatter:i,content:e}}function Ov(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function r(l){if(n>=l)return;const s=i.slice(n,l).join(`
`).trim();s&&e.push(s),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let u=l+1;for(;u<i.length&&!i[u].trimStart().startsWith(d);u++);u<i.length&&(l=u)}}return n<i.length&&r(i.length),e}function Yn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:s=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const u=Ov(d),m={};let f="",k="",h=0;if(u.length>0){const O=u[0],Z=_r(O),A=Object.keys(Z.frontmatter).length>0,E=Z.content.length>0;A&&!E&&u.length>1?(h=1,y(Z.frontmatter)):A&&y(Z.frontmatter)}function y(O){f=O.title||"",O.theme&&(m[vn]=String(O.theme)),O.aspectRatio&&(m[bn]=String(O.aspectRatio)),O.highlighter&&(m[Br]=String(O.highlighter)),O.transition&&(m[yn]=String(O.transition)),O.colorSchema&&(m[Mr]=String(O.colorSchema)),O.layout&&(m[ut]=String(O.layout)),O.background&&(m[Nt]=String(O.background)),O.image&&(m[Ae]=String(O.image)),O.class&&(m[ji]=String(O.class));for(const[Z,A]of Object.entries(O))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(Z)||(m[`custom-slidev-${Z}`]=typeof A=="object"?JSON.stringify(A):String(A))}const b=[];let w=0,_=0,T=0,x=0;const $=new Set,C={};let B=1;for(let O=h;O<u.length;O++){const Z=u[O],{frontmatter:A,content:E}=_r(Z),g=Z.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),F=A.src||(g?g[1]:void 0);if(F){const J=String(F).trim().replace(/^['"]|['"]$/g,"");let rt=c[J]||c[J.replace(/^\.\//,"")]||c[`pages/${J.replace(/^.*pages\//,"")}`];if(!rt){const D=J.replace(/^\.\//,""),N=[];if(i.baseDir)try{const p=require("path");N.push(p.resolve(i.baseDir,D)),N.push(p.resolve(i.baseDir,J))}catch{}try{const p=require("path");N.push(p.resolve(process.cwd(),D)),N.push(p.resolve(process.cwd(),J))}catch{}for(const p of N){const j=oa(p);if(j!==null){rt=j;break}}}const vt={};A.layout&&(vt[ut]=String(A.layout)),A.transition&&(vt[Zt]=String(A.transition)),A.background&&(vt[Nt]=String(A.background)),A.image&&(vt[Ae]=String(A.image)),A.class&&(vt[ji]=String(A.class));for(const[D,N]of Object.entries(A))["src","layout","transition","background","image","class"].includes(D)||(vt[`custom-slidev-${D}`]=typeof N=="object"?JSON.stringify(N):String(N));if(rt){const D=Yn(rt,{...i,virtualFiles:c});for(const N of D.slides){N.pageIndex=B++,N.pageAttrs={...vt,...N.pageAttrs},b.push(N);const p=N.pageAttrs[ut]||"default";C[p]=(C[p]||0)+1}continue}else{b.push({pageIndex:B++,pageAttrs:{...vt,"custom-slidev-src":J},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${J}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const D=vt[ut]||"default";C[D]=(C[D]||0)+1;continue}}const z={};A.layout&&(z[ut]=String(A.layout)),A.transition&&(z[Zt]=String(A.transition)),A.background&&(z[Nt]=String(A.background)),A.image&&(z[Ae]=String(A.image)),A.class&&(z[ji]=String(A.class));for(const[J,rt]of Object.entries(A))["layout","transition","background","image","class"].includes(J)||(z[`custom-slidev-${J}`]=typeof rt=="object"?JSON.stringify(rt):String(rt));let P=E;const H=[];let U=P.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,J=>{const rt=`__CODE_TOKEN_NOTE_${H.length}__`;return H.push(J),rt});U=U.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,J=>{const rt=`__CODE_TOKEN_NOTE_${H.length}__`;return H.push(J),rt});let X="";const K=Array.from(U.matchAll(/<!--([\s\S]*?)-->/g));if(K.length>0){const J=K[K.length-1],rt=U.slice(J.index+J[0].length).trim();if(!rt||!rt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const D=J[1].trim();D.startsWith("TODO:")||(X=D,w++),e&&(U=U.slice(0,J.index).trimEnd()+U.slice(J.index+J[0].length))}}e&&(U=U.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let J=0;J<H.length;J++)U=U.replace(`__CODE_TOKEN_NOTE_${J}__`,H[J]);if(P=U,X){for(let vt=0;vt<H.length;vt++)X=X.replace(`__CODE_TOKEN_NOTE_${vt}__`,H[vt]);const rt=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(vt=>`> ${vt}`).join(`
`)}
{: custom-slidev-note="true"}`;P=P?`${P}

${rt}`:rt}let q=!1;if(/<style\b/i.test(P)){q=!0;const J=P.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(J){for(const rt of J){const vt=rt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${vt}`:vt}l&&(P=P.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const lt=P.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);lt&&(_+=lt.length);const at=P.match(/```\w+\s+\{[^}]+\}/g);at&&(T+=at.length);const st=P.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),P=P.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,J=>Dv(J,{...i,virtualFiles:c})||J),n&&(P=P.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(P=P.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),P=P.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(P=P.replace(/^::\w+::\s*$/gm,"")),s&&(P=Ya(P)),a){let J=P.trim(),rt="";const vt=J.lastIndexOf("> [!NOTE] 💡 演讲备注");if(vt!==-1&&(rt=J.slice(vt),J=J.slice(0,vt).trim()),(A.layout==="image-left"||A.layout==="image-right")&&A.image){const D=String(A.image).trim(),N=A.layout==="image-left"?"image-left":"image-right",p=`![配图](${D})
{: custom-slidev-layout="${N}" }`;A.layout==="image-left"?J=`{{{col

${p}

${J}

}}}`:J=`{{{col

${J}

${p}

}}}`}if(A.background){const N=`![背景图](${String(A.background).trim()})
{: custom-slidev-role="background" }`;J=J?`${N}

${J}`:N}P=rt?`${J}

${rt}`:J}const Q=Rv(P);z[Nt]&&Q.push(z[Nt]),z[Ae]&&Q.push(z[Ae]);for(const J of Q)$.add(J);const pt=/<[A-Z][a-zA-Z0-9]+/.test(P),gt=z[ut]||(B===1?m[ut]||"cover":"default");C[gt]=(C[gt]||0)+1,b.push({pageIndex:B++,pageAttrs:z,notes:X,rawMarkdown:P,hasVueComponent:pt,hasStyleTag:q,assetReferences:Q})}if(!f&&b.length>0){const O=b[0].rawMarkdown.match(/^#\s+(.+)$/m);O&&(f=O[1].trim())}k&&(m["custom-slidev-custom-css"]=k);let M=b.map(O=>`---

${O.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:m,slides:b,totalSlides:b.length,stats:{totalNotes:w,totalVClicks:_,totalShikiHighlights:T,totalSlots:x,discoveredAssets:Array.from($),layoutDistribution:C},flattenedMarkdown:M,customCss:k}}function Rv(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const r=n[1].split(/\s+/)[0].trim();r&&i.push(r)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const r=n[1].trim();r&&i.push(r)}return i}function sa(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function zv(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Nv(t,i,e=Ot){const n=t.filter(sa);let o=0;if(n.length>=i.length)for(let r=0;r<i.length;r++){const l=i[r],s=n[r];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),o++)}else for(let r=1;r<i.length;r++){const l=i[r],s=n[r-1];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),o++)}return o}async function Fv(t,i=Ot){let e=!1,n=0;for(const o of t){if(sa(o)){e=!1;continue}const r=(o.markdown||o.content||"").trim();if(r==="::right::"||r.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[Tt]:"right"}).catch(()=>{}),n++)}return n}async function jv(t,i,e=Ir){const n={};if(!i||i.length===0)return n;const o=[];for(const r of i){const l=new File([r.data],r.fileName,{type:"application/octet-stream"});o.push(l)}try{const r=await e("/data/assets",o);if(r!=null&&r.succMap)for(const[l,s]of Object.entries(r.succMap))n[l]=String(s)}catch(r){console.warn("上传本地静态资产失败，保留原路径:",r)}return Object.keys(n).length>0&&Mv(t,n),n}async function Hv(t){var T;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:r=!0,autoPreview:l=!0,plugin:s,api:a={}}=t,c=a.uploadFn||Ir,d=a.createDocFn||Ea,u=a.setAttrsFn||Ot,m=a.getChildBlocksFn||Xn,f=a.openTabFn||mt.openTab,k=a.showMessageFn||mt.showMessage;r&&o.length>0&&await jv(i,o,c);const h=zv(n),y=`/${h}`,b=await d(e,y,i.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const w=((T=i.slides[0])==null?void 0:T.pageAttrs)||{};await u(b,{...w,...i.docRootAttrs});const _=await m(b).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await Nv(_,i.slides,u),await Fv(_,u)),k(`🎉 成功导入 Slidev 演示文档《${h}》！`),l&&s&&(s.currentDocId=b,await f({app:s.app,doc:{id:b}}),s.openBottomPreviewTab&&s.openBottomPreviewTab()),b}function Uv(t){const i=ft("file"),e=ft(!1),n=ft(!1),o=ft(""),r=ft(null),l=ft(null),s=ft(""),a=ft(0),c=ft(""),d=ft([]),u=ft(null),m=ft(""),f=ft([]),k=ft(""),h=ft(!0),y=ft(!0),b=ft(!0),w=ft(!0),_=_t(()=>{const z=a.value;if(z===0)return"0 B";const P=1024,H=["B","KB","MB","GB"],U=Math.floor(Math.log(z)/Math.log(P));return`${(z/P**U).toFixed(1)} ${H[U]}`}),T=_t(()=>{var z;return((z=u.value)==null?void 0:z.docRootAttrs["custom-slidev-theme"])||"default"}),x=_t(()=>{var z;return d.value.length>0?d.value.length:((z=u.value)==null?void 0:z.stats.discoveredAssets.length)||0}),$=_t(()=>{var P;const z=((P=u.value)==null?void 0:P.stats.layoutDistribution)||{};return Object.entries(z).map(([H,U])=>({name:H,count:U}))});async function C(z=Ta){try{const P=await z();P!=null&&P.notebooks&&Array.isArray(P.notebooks)&&(f.value=P.notebooks.filter(H=>!H.closed),f.value.length>0&&!k.value&&(k.value=f.value[0].id))}catch(P){console.warn("获取笔记本列表失败:",P)}}function B(){var z;(z=r.value)==null||z.click()}function M(){l.value=null,s.value="",a.value=0,u.value=null,d.value=[],o.value=""}async function O(z){o.value="",l.value=z,s.value=z.name,a.value=z.size;try{if(z.name.toLowerCase().endsWith(".zip")){const H=await z.arrayBuffer(),U=await Bv(H);if(!U.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=U.assets;const X=Yn(U.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,virtualFiles:U.virtualFiles});u.value=X,m.value=X.docTitle||z.name.replace(/\.zip$/i,"")}else{const H=await z.text();d.value=[];const U=z.path||"",X=U?U.replace(/[\\/][^\\/]+$/,""):"",K=Yn(H,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,baseDir:X||void 0});u.value=K,m.value=K.docTitle||z.name.replace(/\.md$/i,"")}}catch(P){console.error("解析文件失败:",P),o.value=`解析文件失败: ${P.message||String(P)}`}}function Z(){if(o.value="",!c.value.trim()){u.value=null;return}try{const z=Yn(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1});u.value=z,m.value=z.docTitle||"Slidev 演示文稿"}catch(z){o.value=`解析 Markdown 源码失败: ${z.message||String(z)}`}}async function A(){l.value?await O(l.value):c.value&&Z()}async function E(z){const P=z.target;P.files&&P.files[0]&&await O(P.files[0])}async function g(z){var P;e.value=!1,(P=z.dataTransfer)!=null&&P.files&&z.dataTransfer.files[0]&&await O(z.dataTransfer.files[0])}async function F(z=t){if(u.value){if(!k.value&&f.value.length>0&&(k.value=f.value[0].id),!k.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await Hv({presentation:u.value,notebookId:k.value,docTitle:m.value,extractedAssets:d.value,uploadAssets:b.value,autoPreview:w.value,plugin:z})}catch(P){console.error("导入 Slidev 演示失败:",P),o.value=`导入执行失败: ${P.message||String(P)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:r,selectedFile:l,selectedFileName:s,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:u,customDocTitle:m,notebooks:f,selectedNotebookId:k,optCleanHtml:h,optStripNotes:y,optUploadAssets:b,optAutoPreview:w,formattedFileSize:_,currentTheme:T,extractedAssetsCount:x,layoutChips:$,fetchNotebooks:C,triggerFileInput:B,clearFile:M,processFile:O,onFileSelected:E,onFileDrop:g,onTextChange:Z,reprocessCurrentInput:A,handleConfirmImport:F}}const Wv={class:"spm-import-dialog"},Vv={class:"spm-tabs-header"},Kv={class:"spm-dialog-body"},qv={key:0,class:"spm-file-section"},Gv={key:0,class:"spm-dropzone-prompt"},Zv={key:1,class:"spm-dropzone-active"},Yv={class:"spm-file-badge"},Jv={class:"spm-file-size"},Xv={key:1,class:"spm-text-section"},Qv={key:2,class:"spm-error-banner"},tb={key:3,class:"spm-preview-card"},eb={class:"spm-config-grid"},ib={class:"spm-form-item"},nb={class:"spm-form-item"},ob=["value"],sb={class:"spm-stats-grid"},rb={class:"spm-stat-box"},lb={class:"spm-stat-value"},ab={class:"spm-stat-box"},cb={class:"spm-stat-value"},db={class:"spm-stat-box"},ub={class:"spm-stat-value"},fb={class:"spm-stat-box"},pb={class:"spm-stat-value"},hb={key:0,class:"spm-chips-row"},mb={class:"spm-options-group"},gb={class:"spm-checkbox-label"},vb={class:"spm-checkbox-label"},bb={class:"spm-checkbox-label"},yb={class:"spm-checkbox-label"},kb={class:"spm-dialog-footer"},wb=["disabled"],xb=["disabled"],_b={key:0},Sb={key:1},Cb=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=ti("plugin"),{inputMode:o,isDragging:r,isImporting:l,errorMessage:s,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:u,parsedPresentation:m,customDocTitle:f,notebooks:k,selectedNotebookId:h,optCleanHtml:y,optStripNotes:b,optUploadAssets:w,optAutoPreview:_,formattedFileSize:T,currentTheme:x,layoutChips:$,fetchNotebooks:C,triggerFileInput:B,clearFile:M,onFileSelected:O,onFileDrop:Z,onTextChange:A,reprocessCurrentInput:E,handleConfirmImport:g}=Uv(n);En(async()=>{await C()});async function F(){const P=await g();P&&(e("success",{docId:P}),e("close"))}function z(){e("close")}return(P,H)=>(tt(),it("div",{class:"spm-modal-overlay",onClick:Te(z,["self"])},[v("div",Wv,[v("div",{class:"spm-dialog-header"},[H[18]||(H[18]=v("div",{class:"spm-dialog-title"},[v("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[v("use",{"xlink:href":"#iconSlidev"})]),v("span",null,"导入 Slidev 演示文档")],-1)),v("button",{class:"spm-close-btn",title:"关闭",onClick:z},"✕")]),v("div",Vv,[v("button",{class:$t(["spm-tab-btn",{active:ht(o)==="file"}]),onClick:H[0]||(H[0]=U=>o.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),v("button",{class:$t(["spm-tab-btn",{active:ht(o)==="text"}]),onClick:H[1]||(H[1]=U=>o.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),v("div",Kv,[ht(o)==="file"?(tt(),it("div",qv,[v("div",{class:$t(["spm-dropzone",{dragover:ht(r),"has-file":!!ht(c)}]),onDragover:H[4]||(H[4]=Te(U=>r.value=!0,["prevent"])),onDragleave:H[5]||(H[5]=Te(U=>r.value=!1,["prevent"])),onDrop:H[6]||(H[6]=Te((...U)=>ht(Z)&&ht(Z)(...U),["prevent"])),onClick:H[7]||(H[7]=(...U)=>ht(B)&&ht(B)(...U))},[v("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:H[2]||(H[2]=(...U)=>ht(O)&&ht(O)(...U))},null,544),ht(c)?(tt(),it("div",Zv,[v("span",Yv,"📄 "+St(ht(c)),1),v("span",Jv,"("+St(ht(T))+")",1),v("button",{class:"spm-btn-text",onClick:H[3]||(H[3]=Te((...U)=>ht(M)&&ht(M)(...U),["stop"]))},"更换文件")])):(tt(),it("div",Gv,[...H[19]||(H[19]=[v("span",{class:"spm-dropzone-icon"},"📁",-1),v("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),v("p",{class:"spm-dropzone-hint"},[os(" 支持 Slidev 完整工程 "),v("strong",null,".zip"),os("（自动解包 public/ 静态素材）或单文件 "),v("strong",null,".md")],-1)])]))],34)])):(tt(),it("div",Xv,[Ie(v("textarea",{"onUpdate:modelValue":H[8]||(H[8]=U=>qt(d)?d.value=U:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:H[9]||(H[9]=(...U)=>ht(A)&&ht(A)(...U))},null,544),[[po,ht(d)]])])),ht(s)?(tt(),it("div",Qv," ⚠️ "+St(ht(s)),1)):Mt("",!0),ht(m)?(tt(),it("div",tb,[H[31]||(H[31]=v("div",{class:"spm-preview-card__header"},[v("span",null,"✨ 演示解析摘要"),v("span",{class:"spm-badge-success"},"预检就绪")],-1)),v("div",eb,[v("div",ib,[H[20]||(H[20]=v("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(v("input",{"onUpdate:modelValue":H[10]||(H[10]=U=>qt(f)?f.value=U:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[po,ht(f)]])]),v("div",nb,[H[21]||(H[21]=v("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(v("select",{"onUpdate:modelValue":H[11]||(H[11]=U=>qt(h)?h.value=U:null),class:"spm-select"},[(tt(!0),it(Ut,null,me(ht(k),U=>(tt(),it("option",{key:U.id,value:U.id},St(U.name),9,ob))),128))],512),[[wu,ht(h)]])])]),v("div",sb,[v("div",rb,[v("span",lb,St(ht(m).totalSlides),1),H[22]||(H[22]=v("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),v("div",ab,[v("span",cb,St(ht(x)),1),H[23]||(H[23]=v("span",{class:"spm-stat-label"},"演示主题",-1))]),v("div",db,[v("span",ub,St(ht(m).stats.totalNotes),1),H[24]||(H[24]=v("span",{class:"spm-stat-label"},"演讲者提词",-1))]),v("div",fb,[v("span",pb,St(ht(u)),1),H[25]||(H[25]=v("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ht($).length>0?(tt(),it("div",hb,[H[26]||(H[26]=v("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),it(Ut,null,me(ht($),U=>(tt(),it("span",{key:U.name,class:"spm-chip-badge"},St(U.name)+": "+St(U.count),1))),128))])):Mt("",!0),v("div",mb,[v("label",gb,[Ie(v("input",{"onUpdate:modelValue":H[12]||(H[12]=U=>qt(y)?y.value=U:null),type:"checkbox",onChange:H[13]||(H[13]=(...U)=>ht(E)&&ht(E)(...U))},null,544),[[Un,ht(y)]]),H[27]||(H[27]=v("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),v("label",vb,[Ie(v("input",{"onUpdate:modelValue":H[14]||(H[14]=U=>qt(b)?b.value=U:null),type:"checkbox",onChange:H[15]||(H[15]=(...U)=>ht(E)&&ht(E)(...U))},null,544),[[Un,ht(b)]]),H[28]||(H[28]=v("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),v("label",bb,[Ie(v("input",{"onUpdate:modelValue":H[16]||(H[16]=U=>qt(w)?w.value=U:null),type:"checkbox"},null,512),[[Un,ht(w)]]),H[29]||(H[29]=v("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),v("label",yb,[Ie(v("input",{"onUpdate:modelValue":H[17]||(H[17]=U=>qt(_)?_.value=U:null),type:"checkbox"},null,512),[[Un,ht(_)]]),H[30]||(H[30]=v("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Mt("",!0)]),v("div",kb,[v("button",{class:"spm-btn-secondary",disabled:ht(l),onClick:z}," 取消 ",8,wb),v("button",{class:"spm-btn-primary",disabled:!ht(m)||ht(l),onClick:F},[ht(l)?(tt(),it("span",_b,"⏳ 正在导入生成中...")):(tt(),it("span",Sb,"🚀 确认导入思源笔记"))],8,xb)])])]))}}),$b=Pe(Cb,[["__scopeId","data-v-59ad789d"]]);function ra(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function Ib(t,i){var s;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",r=i.activeBlockType||"";if(ra(r)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===o}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var u,m;return((u=d.blocks)==null?void 0:u.some(f=>f.id===e))||((m=d.allBlockIds)==null?void 0:m.includes(e))}),a)||n&&n!==e&&(a=t.find(d=>{var u,m;return((u=d.blocks)==null?void 0:u.some(f=>f.id===n))||((m=d.allBlockIds)==null?void 0:m.includes(n))}),a)||(a=t.find(d=>{var u;return(u=d.noteBlocks)==null?void 0:u.some(m=>m.id===e||m.id===n)}),a))return a;const c=(s=i.activeBlockAttrs)==null?void 0:s[Tt];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var u,m;return((u=d.frontmatter)==null?void 0:u.layout)==="three-cols-header"||((m=d.blocks)==null?void 0:m.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),a))return a}return t[0]||null}function Sr(t,i){const e=(t.blocks||[]).filter(l=>{const s=(l.content||l.rawMarkdown||"").trim();return s&&s!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const s=(l.content||l.rawMarkdown||"").trim();s&&(l.type==="h"||s.startsWith("#")?n.push(s.replace(/^#+\s*/,"")):o.push(s.slice(0,50)))}const r=[];return n.length>0&&r.push(`【核心重点】：${n.join("、")}`),o.length>0&&(r.push("【口播要点】："),o.slice(0,3).forEach((l,s)=>{r.push(`${s+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function la(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Sr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Sr(t),isAiGenerated:!1}}async function Ab(t,i){return(await la(t,i)).notes}function Tb(t){let i=null;function e(E="已同步"){t.saveStatus.value=E,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const g=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(g,1200):i=setTimeout(g,1200)}async function n(E){const g=t.activeBlockId.value||t.currentDocId.value;if(g){for(const[F,z]of Object.entries(E))t.activeBlockAttrs.value[F]=z;if(Rt.setBlockAttrOverride(g,E),ne(g,E),ut in E){const F=E[ut];t.currentPageDividerLayout.value=F,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=F)}if(Xt in E){const F=E[Xt];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=F)}e("保存中...");try{await Ot(g,E),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function o(E,g){const F=t.activeBlockId.value||t.currentDocId.value;if(F){t.activeBlockAttrs.value[E]=g,Rt.setBlockAttrOverride(F,{[E]:g}),ne(F,{[E]:g}),E===ut&&(t.currentPageDividerLayout.value=g,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=g)),E===Xt&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=g),e("保存中...");try{await Ot(F,{[E]:g}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function r(E,g){var z;const F=t.currentDocId.value||t.activeBlockId.value;if(F){t.activeBlockAttrs.value[E]=g,Rt.setBlockAttrOverride(F,{[E]:g}),ne(F,{[E]:g}),(z=t.latestDoc.value)!=null&&z.config&&(E===vn&&(t.latestDoc.value.config.theme=g),E===bn&&(t.latestDoc.value.config.aspectRatio=g),E===yn&&(t.latestDoc.value.config.defaultTransition=g)),e("更新中...");try{await Ot(F,{[E]:g}),e("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(F)}catch{e("更新失败")}}}async function l(){(t.videoAutoplay.value?"false":"true")==="true"?(await n({[Ii]:"true",[Ni]:"true"}),t.activeBlockAttrs.value[Ii]="true",t.activeBlockAttrs.value[Ni]="true"):(await o(Ii,"false"),t.activeBlockAttrs.value[Ii]="false")}async function s(){const E=t.videoLoop.value?"false":"true";await o(Qn,E)}async function a(){const E=t.videoMuted.value?"false":"true";await o(Ni,E)}async function c(){const E=t.videoControls.value?"false":"true";await o(to,E)}async function d(E){var H;const g=t.activeBlockId.value;if(!g)return;const F=t.rawSnippet.value||"",z=hi(F)||"",P=t.currentPageDividerId.value||t.currentDocId.value;if(E)if(E==="background"){const U={[Ht]:"background",[ut]:""};P&&z&&(t.pageBackground.value=z,await Ot(P,{[Nt]:z}).catch(()=>{}),Rt.setBlockAttrOverride(P,{[Nt]:z}),ne(P,{[Nt]:z}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=z)),await n(U)}else(E===eo||E===io)&&await n({[ut]:E,[Ht]:""});else{const U={[Ht]:"",[ut]:""};if(t.activeBlockAttrs.value[Nt]==="true"&&(U[Nt]=""),P&&z&&t.pageBackground.value===z&&(t.pageBackground.value="",await Ot(P,{[Nt]:""}).catch(()=>{}),Rt.setBlockAttrOverride(P,{[Nt]:""}),ne(P,{[Nt]:""}),(H=t.targetSlide.value)!=null&&H.frontmatter&&delete t.targetSlide.value.frontmatter.background),await n(U),typeof document<"u"){const X=document.querySelector(`.protyle-wysiwyg [data-node-id="${g}"]`),K=X==null?void 0:X.closest('[data-type="NodeListItem"]'),q=K==null?void 0:K.getAttribute("data-node-id");if(q&&q!==g){const lt={[ut]:"",[Ht]:""};ne(q,lt),Rt.setBlockAttrOverride(q,lt),await Ot(q,lt).catch(()=>{})}}}}async function u(E){var q,lt,at,st,Q,pt,gt,J;const z=`> [!NOTE] 💡 演讲备注
${(E||"在此输入本页讲稿提词...").split(/\r?\n/).map(rt=>`> ${rt}`).join(`
`)}
{: custom-slidev-note="true"}`,P=((q=t.latestDoc.value)==null?void 0:q.slides)||[],H=t.targetSlide.value,U=H?P.findIndex(rt=>rt===H):-1;let X=null;if(U!==-1&&U<P.length-1){const rt=P[U+1];X=await rn("markdown",z,rt.startBlockId)}else{const rt=((lt=H==null?void 0:H.noteBlocks)==null?void 0:lt.slice(-1)[0])||((at=H==null?void 0:H.blocks)==null?void 0:at.slice(-1)[0]),vt=(rt==null?void 0:rt.id)||(H==null?void 0:H.startBlockId);vt?X=await rn("markdown",z,void 0,vt):X=await Ar("markdown",z,t.currentDocId.value)}const K=((pt=(Q=(st=X==null?void 0:X[0])==null?void 0:st.doOperations)==null?void 0:Q[0])==null?void 0:pt.id)||((gt=X==null?void 0:X[0])==null?void 0:gt.id);return K&&(await Ot(K,{[ee]:"true"}),Rt.setBlockAttrOverride(K,{[ee]:"true"}),Di(K,(J=t.plugin)==null?void 0:J.app)),t.plugin&&await t.plugin.compileCurrentDocument(),K}async function m(){const E=t.activeBlockId.value;if(E)if(t.isNoteBlock.value){e("取消中...");try{await Ot(E,{[ee]:"","slidev-note":""}),Rt.setBlockAttrOverride(E,{[ee]:"","slidev-note":""}),ne(E,{[ee]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ee],delete t.activeBlockAttrs.value["slidev-note"],e("已取消备注"),mt.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 取消讲稿备注失败:",g),e("取消失败"),mt.showMessage("取消讲稿备注失败")}}else{e("转换中...");try{let g=t.rawSnippet.value;try{const H=await Ma(E);H!=null&&H.kramdown&&(g=H.kramdown)}catch{}const P=`> [!NOTE] 💡 演讲备注
${(Rr(g)||g.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slidev-note="true"}`;await zs("markdown",P,E),await Ot(E,{[ee]:"true"}),Rt.setBlockAttrOverride(E,{[ee]:"true"}),ne(E,{[ee]:"true"}),t.activeBlockAttrs.value[ee]="true",t.activeBlockType.value="NodeCallout",e("已设为讲稿备注"),mt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",g),e("设置失败"),mt.showMessage("转为讲稿备注提示块失败")}}}async function f(){try{await u(),mt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(E){mt.showMessage("插入讲稿备注块失败"),console.error(E)}}function k(){var F;const E=t.currentSlideNoteBlockId.value;if(!E){mt.showMessage("未找到本页关联的讲稿备注块");return}Di(E,(F=t.plugin)==null?void 0:F.app)?mt.showMessage("已在编辑区定位讲稿备注块"):mt.showMessage("定位讲稿备注块失败")}async function h(){var F;if(!t.currentDocId.value)return;const E=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};mt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const g=await la(E,Tr);if(g.notes){const z=t.currentSlideNoteBlockId.value;if(z){const P=`> [!NOTE] 💡 演讲备注
${g.notes.split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slidev-note="true"}`;await zs("markdown",P,z),await Ot(z,{[ee]:"true"}),Rt.setBlockAttrOverride(z,{[ee]:"true"}),Di(z,(F=t.plugin)==null?void 0:F.app)}else await u(g.notes);g.isAiGenerated?mt.showMessage("思源 AI 演讲提词卡生成成功！"):mt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}function y(){t.elemClick.value?o(_e,""):o(_e,"+1")}function b(E){o(_e,E)}function w(E){o(Ue,E)}function _(E){(t.activeBlockAttrs.value[Tt]||"")===E?o(Tt,""):o(Tt,E)}function T(E){t.elemShikiLines.value=E,o(Li,E)}function x(E){t.elemMaxHeight.value=E,o(kn,E)}async function $(){const E=t.currentSlideLayout.value==="three-cols-header";await o(Tt,E?"col-1":"left"),mt.showMessage(E?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function C(){const E=t.activeBlockId.value;if(!E)return;const g={[_e]:"",[Ue]:"",[Tt]:"",[Li]:"",[kn]:"",[ee]:"","slidev-note":"",[ut]:"",[Xt]:"",[Ht]:"",[Zt]:"",[Nt]:"",[Ae]:"",[Ii]:"",[Qn]:"",[Ni]:"",[to]:""};if(ne(E,g),await Ot(E,g),Rt.clearBlockAttrOverride(E),typeof document<"u"){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${E}"]`),z=F==null?void 0:F.closest('[data-type="NodeListItem"]'),P=z==null?void 0:z.getAttribute("data-node-id");P&&P!==E&&(ne(P,g),await Ot(P,g).catch(()=>{}),Rt.clearBlockAttrOverride(P))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",mt.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function B(){if(t.activeBlockId.value)try{await rn("markdown","---",t.activeBlockId.value,void 0),mt.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function M(){const E=t.activeBlockId.value||t.currentDocId.value;if(E)try{await rn("markdown","---",void 0,E),mt.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function O(){if(t.activeBlockId.value)try{await Ba(t.activeBlockId.value),mt.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("删除失败")}}function Z(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const E=ea(t.latestDoc.value);ia("presentation.html",E)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function A(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}na(t.latestDoc.value)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:e,saveAttrs:n,saveAttr:o,saveDocAttr:r,onToggleVideoAutoplay:l,onToggleVideoLoop:s,onToggleVideoMuted:a,onToggleVideoControls:c,onImageRoleChange:d,onToggleNoteBlock:m,createNoteBlockOnCurrentSlide:u,onAddNoteBlock:f,onLocateNoteBlock:k,onGenerateNotesWithAI:h,toggleElemClick:y,onElemClickStepChange:b,onElemMotionChange:w,onElemSlotChange:_,onElemShikiLinesChange:T,onElemMaxHeightChange:x,onSetTwoColsContrast:$,onClearBlockAttrs:C,onInsertDividerBefore:B,onInsertDividerAfter:M,onDeleteCurrentBlock:O,onExportHtml:Z,onExportPdf:A}}const Eb={class:"spm-slidev-inspector"},Bb={class:"spm-inspector-topbar"},Mb={class:"spm-inspector-title"},Db={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Lb={class:"spm-inspector-topbar-actions"},Pb={class:"spm-target-banner"},Ob={class:"spm-target-info"},Rb=["aria-label"],zb={key:0,class:"spm-save-status"},Nb=["title"],Fb={class:"spm-inspector-body"},jb=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ti("plugin"),n=ft(!1);function o(ot){n.value=!1,c.value=ot.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(ot.docId)}const r=ft(""),l=ft(""),s=ft({}),a=ft(""),c=ft(""),d=ft(""),u=ft(""),m=ft(""),f=ft(null),k=ft(""),h=ft("");function y(){var wt;const ot=r.value||c.value;ot&&typeof navigator<"u"&&(wt=navigator==null?void 0:navigator.clipboard)!=null&&wt.writeText&&navigator.clipboard.writeText(ot).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const b=_t(()=>ra(l.value)),w=_t(()=>l.value==="NodeCodeBlock"),_=ft(!1),T=_t(()=>{if(_.value||S.value)return!0;const ot=a.value||"";return!!hi(ot)}),x=_t(()=>{const ot=l.value||"";if(ot==="NodeVideo"||ot==="video")return!0;const wt=a.value||"";return!!(/<video\b/i.test(wt)||/\.mp4\b/i.test(wt))}),$=_t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),C=_t(()=>{const ot=r.value||c.value||"";return ot.length>8?ot.slice(-8):ot||"无"}),B=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),M=_t(()=>{if(b.value)return"分页符 (---)";if($.value)return"全局文档";if(x.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),O=_t(()=>b.value?"tag-divider":$.value?"tag-doc":"tag-block"),Z=_t(()=>s.value[ut]||"default"),A=_t(()=>s.value[Zt]||"slide-left"),E=ft(""),g=ft(""),F=_t(()=>s.value[cn]||"inherit"),z=_t(()=>{var ot;return Ib((ot=f.value)==null?void 0:ot.slides,{activeBlockId:r.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:u.value,activeBlockAttrs:s.value})}),P=_t(()=>{var ot;return((ot=z.value)==null?void 0:ot.notes)||""}),H=_t(()=>{var ot,wt,At;return((At=(wt=(ot=z.value)==null?void 0:ot.noteBlocks)==null?void 0:wt[0])==null?void 0:At.id)||""}),U=_t(()=>{var Vt,Ke,qe,Ce,ai,ci;if(b.value){const te=s.value[ut]||s.value["custom-slidev-layout"];if(te)return te}const ot=s.value[Tt]||s.value["custom-slidev-slot"];if(ot&&["col-1","col-2","col-3"].includes(ot))return"three-cols-header";if(m.value)return m.value;const wt=u.value||(b.value?r.value:"");if(wt){const te=Rt.getBlockAttrOverride(wt);if(te!=null&&te[ut])return te[ut]}if(wt&&((Vt=f.value)!=null&&Vt.slides)){const te=f.value.slides.find(Pn=>Pn.startBlockId===wt);if((Ke=te==null?void 0:te.frontmatter)!=null&&Ke.layout)return te.frontmatter.layout}if((Ce=(qe=z.value)==null?void 0:qe.frontmatter)!=null&&Ce.layout)return z.value.frontmatter.layout;if((ci=(ai=z.value)==null?void 0:ai.blocks)!=null&&ci.some(te=>te.slot==="col-1"||te.slot==="col-2"||te.slot==="col-3"))return"three-cols-header";const At=Rt.getBlockAttrOverride(c.value);return At!=null&&At[ut]?At[ut]:"default"}),X=_t(()=>{var wt,At;if(b.value){const Vt=s.value[Xt]||s.value["custom-slidev-layout-ratio"];if(Vt)return Vt}const ot=u.value||(b.value?r.value:"");if(ot){const Vt=Rt.getBlockAttrOverride(ot);if(Vt!=null&&Vt[Xt])return Vt[Xt]}return((At=(wt=z.value)==null?void 0:wt.frontmatter)==null?void 0:At.layoutRatio)||""}),K=_t(()=>{var Vt;if(typeof document>"u")return"";const ot=u.value||(b.value?r.value:"");if(!ot)return"";const wt=document.querySelector(`.protyle-wysiwyg [data-node-id="${ot}"]`);if(!wt)return"";let At=wt.nextElementSibling;for(;At&&!(At.getAttribute("data-type")==="NodeThematicBreak"||(Vt=At.classList)!=null&&Vt.contains("protyle-wysiwyg__block--hr"));){const Ke=At.getAttribute("data-type")==="NodeSuperBlock"?At:At.querySelector('[data-type="NodeSuperBlock"]');if(Ke&&Ke.getAttribute("data-sb-layout")==="col"){const qe=Array.from(Ke.querySelectorAll(":scope > [data-node-id]"));if(qe.length>=2){const Ce=qe.map(ai=>{const ci=(ai.getAttribute("style")||"").match(/calc\(([\d.]+)%/);return ci?parseFloat(ci[1]):null});if(Ce.some(ai=>ai!==null)){const ai=Ce.reduce((Bt,we)=>Bt+(we||0),0),ci=Ce.filter(Bt=>Bt===null).length,te=ci>0?(100-ai)/ci:100/qe.length,Pn=Ce.map(Bt=>Bt!==null?Bt:te),wa=Pn.reduce((Bt,we)=>Bt+we,0)||1,en=Pn.map(Bt=>Bt/wa*100);if(en.length===2){const[Bt]=en;if(Bt>=48&&Bt<=52)return"1:1";if(Bt>=31&&Bt<=35)return"1:2";if(Bt>=65&&Bt<=69)return"2:1";if(Bt>=28&&Bt<=32)return"3:7";if(Bt>=68&&Bt<=72)return"7:3";if(Bt>=38&&Bt<=42)return"4:6";if(Bt>=58&&Bt<=62)return"6:4";const we=Math.round(Bt);return`${we}:${100-we}`}if(en.length===3){const[Bt,we,On]=en;if(Bt>=31&&Bt<=35&&we>=31&&we<=35&&On>=31&&On<=35)return"1:1:1";if(Bt>=23&&Bt<=27&&we>=48&&we<=52&&On>=23&&On<=27)return"1:2:1";const Os=Math.round(Bt),Rs=Math.round(we);return`${Os}:${Rs}:${100-Os-Rs}`}return en.map(Bt=>Math.round(Bt)).join(":")}}}At=At.nextElementSibling}return""}),q=_t(()=>{var ot;return((ot=z.value)==null?void 0:ot.pageIndex)||1}),lt=_t(()=>!!(s.value[ee]||s.value["slidev-note"])),at=_t(()=>{var wt;if(s.value[_e])return s.value[_e];const ot=r.value;if(ot&&((wt=z.value)!=null&&wt.blocks)){const At=z.value.blocks.find(Vt=>Vt.id===ot);if(At!=null&&At.clicks)return At.clicks}return""}),st=_t(()=>{var wt;if(s.value[Ue])return s.value[Ue];const ot=r.value;if(ot&&((wt=z.value)!=null&&wt.blocks)){const At=z.value.blocks.find(Vt=>Vt.id===ot);if(At!=null&&At.motion)return typeof At.motion=="string"?At.motion:JSON.stringify(At.motion)}return""}),Q=_t(()=>{var wt;if(s.value[Tt])return s.value[Tt];const ot=r.value;if(ot&&((wt=z.value)!=null&&wt.blocks)){const At=z.value.blocks.find(Vt=>Vt.id===ot);if(At!=null&&At.slot)return At.slot}return""}),pt=ft(""),gt=ft(""),J=_t(()=>s.value[Ii]==="true"),rt=_t(()=>s.value[Qn]==="true"),vt=_t(()=>s.value[Ni]==="true"),D=_t(()=>s.value[to]!=="false"),N=_t(()=>{var ot,wt;return((wt=(ot=f.value)==null?void 0:ot.config)==null?void 0:wt.theme)||s.value[vn]||"default"}),p=_t(()=>{var ot,wt;return((wt=(ot=f.value)==null?void 0:ot.config)==null?void 0:wt.aspectRatio)||s.value[bn]||"16/9"}),j=_t(()=>{var ot,wt;return((wt=(ot=f.value)==null?void 0:ot.config)==null?void 0:wt.defaultTransition)||s.value[yn]||"slide-left"}),R=_t(()=>{var ot,wt;return((wt=(ot=f.value)==null?void 0:ot.config)==null?void 0:wt.spacing)||s.value[Vo]||"normal"}),S=_t(()=>{var Ke,qe;if((s.value[Ht]||s.value["slidev-role"])===Dr||s.value[Nt]==="true")return"background";const wt=s.value[ut]||s.value["slidev-layout"];if(wt==="image-left"||wt==="image-right")return wt;const At=a.value||"",Vt=hi(At);if(Vt&&((qe=(Ke=z.value)==null?void 0:Ke.frontmatter)!=null&&qe.background)){const Ce=z.value.frontmatter.background;if(Ce===Vt||Ce.endsWith(Vt)||Vt.endsWith(Ce))return"background"}return""}),I=_t(()=>!!(s.value[_e]||s.value[Ue]||s.value[Tt]||s.value[Li]||s.value[ee]||s.value["slidev-note"]||s.value[Ht]||s.value[ut]||s.value[Ii]||s.value[Qn]||s.value[Ni]||s.value[to])),{saveAttr:L,saveDocAttr:G,onToggleVideoAutoplay:V,onToggleVideoLoop:W,onToggleVideoMuted:Y,onToggleVideoControls:nt,onImageRoleChange:et,onToggleNoteBlock:ct,onAddNoteBlock:xt,onLocateNoteBlock:bt,onGenerateNotesWithAI:Et,toggleElemClick:Wt,onElemClickStepChange:Kt,onElemMotionChange:Qt,onElemSlotChange:Pt,onElemShikiLinesChange:Ve,onElemMaxHeightChange:Jt,onSetTwoColsContrast:Gt,onClearBlockAttrs:bi,onInsertDividerBefore:Pi,onInsertDividerAfter:Dn,onDeleteCurrentBlock:Ao,onExportHtml:Ln,onExportPdf:yi}=Tb({activeBlockId:r,activeBlockType:l,activeBlockAttrs:s,rawSnippet:a,currentDocId:c,currentPageDividerId:u,currentPageDividerLayout:m,latestDoc:f,targetSlide:z,currentSlideNoteBlockId:H,currentSlideLayout:U,isNoteBlock:lt,elemClick:at,videoAutoplay:J,videoLoop:rt,videoMuted:vt,videoControls:D,pageBackground:E,pageImage:g,elemShikiLines:pt,elemMaxHeight:gt,saveStatus:k,plugin:e});function Oi(ot){L(ut,ot)}function da(ot){L(Xt,ot)}function ua(ot){L(Zt,ot)}function fa(ot){E.value=ot,L(Nt,ot)}function pa(ot){g.value=ot,L(Ae,ot)}function ha(ot){L(cn,ot==="inherit"?"":ot)}function ma(ot){G(vn,ot)}function ga(ot){G(bn,ot)}function va(ot){G(yn,ot)}function ba(ot){G(Vo,ot)}function Ps(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function ya(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ka(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(ot){r.value=ot.id,l.value=ot.type,s.value={...ot.attrs},a.value=ot.content||ot.markdown||"",d.value=ot.topBlockId||ot.id,u.value=ot.pageDividerId||"",m.value=ot.pageDividerLayout||"",ot.rootId?c.value=ot.rootId:(ot.type==="doc"||ot.type==="NodeDocument")&&ot.id&&(c.value=ot.id),E.value=ot.attrs[Nt]||"",g.value=ot.attrs[Ae]||"",pt.value=ot.attrs[Li]||"",gt.value=ot.attrs[kn]||"",_.value=!!ot.isImage},updateDocument(ot){f.value=ot,c.value=ot.docId},openImportDialog(){n.value=!0},setCurrentDocId(ot){c.value=ot}}),(ot,wt)=>(tt(),it("div",Eb,[v("div",Bb,[v("div",Mb,[(tt(),it("svg",Db,[...wt[2]||(wt[2]=[v("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),v("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),v("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),wt[3]||(wt[3]=v("span",null,"演示配置",-1))]),v("div",Lb,[v("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:wt[0]||(wt[0]=At=>n.value=!0)},[dt(yt,{name:"import"}),wt[4]||(wt[4]=v("span",null,"导入",-1))]),v("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ps},[dt(yt,{name:"split-preview"}),wt[5]||(wt[5]=v("span",null,"分屏预览",-1))])])]),v("div",Pb,[v("div",Ob,[v("span",{class:$t(["spm-target-tag",O.value])},St(M.value),3),v("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:y},[dt(yt,{name:"copy"}),v("span",null,"#"+St(C.value),1)],8,Rb)]),k.value?(tt(),it("span",zb,"● "+St(k.value),1)):Mt("",!0)]),B.value?(tt(),it("div",{key:0,class:"spm-context-quote",title:a.value},St(B.value),9,Nb)):Mt("",!0),v("div",Fb,[b.value?(tt(),Ee(Cm,{key:0,"page-layout":Z.value,"page-layout-ratio":X.value,"detected-sb-ratio":K.value,"page-transition":A.value,"page-background":E.value,"page-spacing":F.value,"page-image":g.value,"page-notes":P.value,"page-index":q.value,"onUpdate:pageLayout":Oi,"onUpdate:pageLayoutRatio":da,"onUpdate:pageTransition":ua,"onUpdate:pageBackground":fa,"onUpdate:pageSpacing":ha,"onUpdate:pageImage":pa,onAddNoteBlock:ht(xt),onLocateNoteBlock:ht(bt),onGenerateNotes:ht(Et),onInsertDividerAfter:ht(Dn),onDeleteDivider:ht(Ao)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):r.value&&!$.value?(tt(),Ee(Kg,{key:1,"elem-click":at.value,"elem-motion":st.value,"elem-slot":Q.value,"elem-shiki-lines":pt.value,"elem-max-height":gt.value,"is-code-block":w.value,"is-image":T.value,"is-video":x.value,"video-autoplay":J.value,"video-loop":rt.value,"video-muted":vt.value,"video-controls":D.value,"has-block-attrs":I.value,"is-note":lt.value,"image-role":S.value,"current-slide-layout":U.value,onToggleNote:ht(ct),onToggleElemClick:ht(Wt),onToggleVideoAutoplay:ht(V),onToggleVideoLoop:ht(W),onToggleVideoMuted:ht(Y),onToggleVideoControls:ht(nt),"onUpdate:imageRole":ht(et),"onUpdate:elemClick":ht(Kt),"onUpdate:elemMotion":ht(Qt),"onUpdate:elemSlot":ht(Pt),"onUpdate:elemShikiLines":ht(Ve),"onUpdate:elemMaxHeight":ht(Jt),onInsertDividerBefore:ht(Pi),onInsertDividerAfter:ht(Dn),onSetTwoColsContrast:ht(Gt),onClearBlockAttrs:ht(bi)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(tt(),Ee(Sv,{key:2,"doc-theme":N.value,"doc-aspect-ratio":p.value,"doc-default-transition":j.value,"doc-spacing":R.value,"onUpdate:docTheme":ma,"onUpdate:docAspectRatio":ga,"onUpdate:docDefaultTransition":va,"onUpdate:docSpacing":ba,onOpenBottomPreview:Ps,onOpenPresenter:ya,onAiAutoSplit:ka,onExportHtml:ht(Ln),onExportPdf:ht(yi)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(tt(),Ee($b,{key:1,onClose:wt[1]||(wt[1]=At=>n.value=!1),onSuccess:o})):Mt("",!0)]))}}),Mn=new Ms;let fi=null,He=null;function Hb(t,i){fi&&aa(),fi=Kl(Oh),fi.provide("plugin",i),fi.provide("sandboxBridge",Mn);const e=fi.mount(t);return He=e,e}function aa(t){fi&&(fi.unmount(),fi=null,He=null)}let pi=null,ve=null;function Ub(t,i){pi&&ca(),pi=Kl(jb),pi.provide("plugin",i),pi.provide("sandboxBridge",Mn);const e=pi.mount(t);return ve=e,e}function ca(t){pi&&(pi.unmount(),pi=null,ve=null)}function Wb(t,i){ve!=null&&ve.updateDocument&&ve.updateDocument(t),He!=null&&He.updateDocument?He.updateDocument(t,i):Mn.updateSlides(t.slides,t.config,t.fullMarkdown)}function as(t){He!=null&&He.navigateToBlock?He.navigateToBlock(t):Mn.highlightElement(t)}function Jn(t){ve!=null&&ve.setActiveBlock&&ve.setActiveBlock(t)}function Vb(){return ve!=null&&ve.openImportDialog?(ve.openImportDialog(),!0):!1}function Kb(t,i){const e=[];let o=0;for(let r=0;r<t.length;r++){const l=t[r];if(no(l)){o=0;continue}const s=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||s.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||s.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&r<t.length-1){const c=t[r+1];no(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const qb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:$i,value:"true"},{key:ut,value:"cover"},{key:Zt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:$i,value:"true"},{key:ut,value:"two-cols"},{key:Zt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:$i,value:"true"},{key:ut,value:"fact"},{key:Zt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:$i,value:"true"},{key:ut,value:"intro"},{key:Zt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:$i,value:"true"},{key:ut,value:"quote"},{key:Zt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:_e,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:_e,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Li,value:"1-3"}]}];class Uo{getPresetTemplates(){return qb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Zt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = '${Zt}' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Zt]:e}),s++)}return{updatedCount:s}}async batchUpdateLayout(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),s++)}return{updatedCount:s}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Gb(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Vb()||mt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Ot(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const r=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(r==null?void 0:r.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}const i=await Xn(t.currentDocId).catch(()=>[]);if(!i||i.length===0){mt.showMessage("当前文档无内容，无需断页");return}const e=i.map(r=>({id:r.id,type:r.type,subType:r.subType,content:r.content||"",markdown:r.markdown||""})),n=Kb(e);if(n.length===0){mt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}mt.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const r of n)try{await rn("markdown","---",void 0,r.blockId),await Ot(r.blockId,{"custom-slidev-layout":r.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}mt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,u;if(!t.currentDocId){const m=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(m==null?void 0:m.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}mt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await Xn(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(m=>({id:m.id,type:m.type,content:m.content||"",rawMarkdown:m.markdown||""})),rawMarkdown:""},r=`> [!NOTE] 💡 演讲备注
${(await Ab(e,Tr)).split(/\r?\n/).map(m=>`> ${m}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Ar("markdown",r,t.currentDocId).catch(()=>null),s=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((u=l==null?void 0:l[0])==null?void 0:u.id);s&&(await Ot(s,{"custom-slidev-note":"true"}),Rt.setBlockAttrOverride(s,{"custom-slidev-note":"true"}),Di(s,t.app)),mt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Uo,e=i.buildTransitionStatsSql(),n=await gn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);mt.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Uo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),mt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):mt.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Uo().batchUpdateTransitions("fade","slide-left",n=>gn(n).catch(()=>[]),(n,o)=>Ot(n,o));mt.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&mt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{mt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?mt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):mt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Wo);i.success?mt.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):mt.showMessage(`同步失败：${i.error}`)}})}class Zb{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=document.querySelector("[data-doc-id]"),l=r==null?void 0:r.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=i.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),s=l==null?void 0:l.getAttribute("data-node-id");if(s)return s;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||e}async switchToDocGlobalInspector(i,e){var r;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((r=l==null?void 0:l.innerText)==null?void 0:r.trim())||""}const o=await Ze(i).catch(()=>({}));Jn({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),as(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const r=Di(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),s=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,s,n,o);else{let c="",d="";if(o!=null&&o.slides){const u=o.slides.find(m=>{var f,k,h;return m.startBlockId===i||((f=m.blocks)==null?void 0:f.some(y=>y.id===i))||((k=m.allBlockIds)==null?void 0:k.includes(i))||((h=m.noteBlocks)==null?void 0:h.some(y=>y.id===i))});u!=null&&u.startBlockId&&(c=u.startBlockId),(a=u==null?void 0:u.frontmatter)!=null&&a.layout&&(d=u.frontmatter.layout)}Ze(i).then(async u=>{if(c&&!d){const m=Rt.getBlockAttrOverride(c);if(m!=null&&m[ut]||m!=null&&m["custom-slidev-layout"])d=m[ut]||m["custom-slidev-layout"]||"";else{const f=await Ze(c).catch(()=>({}))||{};d=f[ut]||f["custom-slidev-layout"]||"",f&&Object.keys(f).length>0&&Rt.setBlockAttrOverride(c,f)}}Jn({id:i,rootId:n,type:s||"NodeParagraph",attrs:u||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return r}async syncInspectorBlock(i,e,n,o,r){var A,E,g,F,z,P,H,U;let l=i,s=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const X=c.getAttribute("data-node-id");if(X){const K=await Ze(X).catch(()=>({}))||{},q=Rt.getBlockAttrOverride(X)||{},lt={...K,...q};(lt[ee]||lt["slidev-note"])&&(l=c,s=X,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,u=(d==null?void 0:d.getAttribute("data-node-id"))||s,m=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((A=d==null?void 0:d.classList)!=null&&A.contains("hr")),f=a==="NodeCodeBlock",k=((E=l.innerText)==null?void 0:E.trim())||"",h=await Ze(s).catch(()=>({}))||{},y=Rt.getBlockAttrOverride(s)||{},b={...h,...y};let w="",_="";if(m)w=s,_=b[ut]||b["custom-slidev-layout"]||"";else{let X=d.previousElementSibling;for(;X;){const K=X.getAttribute("data-type");if(K==="NodeThematicBreak"||K==="tb"||(g=X.classList)!=null&&g.contains("hr")){w=X.getAttribute("data-node-id")||"";break}X=X.previousElementSibling}}if(r!=null&&r.slides){const X=[s,u];let K=l.parentElement;for(;K&&!K.classList.contains("protyle-wysiwyg");){const lt=K.getAttribute("data-node-id");lt&&!X.includes(lt)&&X.push(lt),K=K.parentElement}const q=r.slides.find(lt=>{var at,st,Q;return X.includes(lt.startBlockId)||((at=lt.blocks)==null?void 0:at.some(pt=>X.includes(pt.id)))||((st=lt.allBlockIds)==null?void 0:st.some(pt=>X.includes(pt)))||((Q=lt.noteBlocks)==null?void 0:Q.some(pt=>X.includes(pt.id)))});q&&(!w&&q.startBlockId&&(w=q.startBlockId),!_&&((F=q.frontmatter)!=null&&F.layout)&&(_=q.frontmatter.layout))}if(w){const X=Rt.getBlockAttrOverride(w);if(X&&(ut in X||"custom-slidev-layout"in X)&&(_=X[ut]||X["custom-slidev-layout"]||""),!_&&(r!=null&&r.slides)){const K=r.slides.find(q=>q.startBlockId===w);(z=K==null?void 0:K.frontmatter)!=null&&z.layout&&(_=K.frontmatter.layout)}if(!_){const K=await Ze(w).catch(()=>({}))||{};_=K[ut]||K["custom-slidev-layout"]||"",K&&Object.keys(K).length>0&&Rt.setBlockAttrOverride(w,K)}ne(w,{[ut]:_||""})}else if(o){const X=Rt.getBlockAttrOverride(o);X&&(ut in X||"custom-slidev-layout"in X)?_=X[ut]||X["custom-slidev-layout"]||"":!_&&((U=(H=(P=r==null?void 0:r.slides)==null?void 0:P[0])==null?void 0:H.frontmatter)!=null&&U.layout)&&(_=r.slides[0].frontmatter.layout)}const T=l.getAttribute(ut)||l.getAttribute("custom-slidev-layout"),x=b[ut]||b["custom-slidev-layout"]||"";T&&T!==x&&ne(s,{[ut]:x});const $=l.getAttribute(Ht)||l.getAttribute("custom-slidev-role"),C=b[Ht]||b["custom-slidev-role"]||"";$&&$!==C&&ne(s,{[Ht]:C});const B=l.closest('[data-type="NodeListItem"]');if(B&&B!==l){const X=B.getAttribute("data-node-id");if(X){const K=await Ze(X).catch(()=>({}))||{},q=Rt.getBlockAttrOverride(X)||{},lt={...K,...q},at=lt[ut]||lt["custom-slidev-layout"]||"",st=B.getAttribute(ut)||B.getAttribute("custom-slidev-layout");st&&st!==at&&ne(X,{[ut]:at});const Q=lt[Ht]||lt["custom-slidev-role"]||"",pt=B.getAttribute(Ht)||B.getAttribute("custom-slidev-role");pt&&pt!==Q&&ne(X,{[Ht]:Q})}}const M=!!l.querySelector("img, span[data-type='img']"),O=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),Z=M&&O.length<=50;Jn({id:s,rootId:o,type:a,content:k,attrs:b,isDivider:m,isCode:f,isImage:Z,topBlockId:u,pageDividerId:w,pageDividerLayout:_})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},r=n.data.new||{},l={};for(const s of Object.keys(o))s in r||(l[s]="");for(const[s,a]of Object.entries(r))l[s]=String(a??"");ne(n.id,l),Rt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,r,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const s of i.slides){if(s.startBlockId){const a=e.get(s.startBlockId)||{};(o=s.frontmatter)!=null&&o.layout&&(a[ut]=s.frontmatter.layout),e.set(s.startBlockId,a)}if(Array.isArray(s.blocks)){for(const a of s.blocks)if(a.id){const c=e.get(a.id)||{};(r=a.ial)!=null&&r[ut]&&(c[ut]=a.ial[ut]),(l=a.ial)!=null&&l[Ht]&&(c[Ht]=a.ial[Ht]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Rt.getAllAttrOverrides();for(const[s,a]of n.entries()){const c=e.get(s)||{};a[ut]!==void 0&&(c[ut]=a[ut]),a[Ht]!==void 0&&(c[Ht]=a[Ht]),e.set(s,c)}Hf(e)}}const Si=new Zb,Yb=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Jb="slidev-dock",Cr="slidev-preview-tab",$r=Mp;class Xb extends mt.Plugin{constructor(){super(...arguments);kt(this,"isMobile",!1);kt(this,"currentDocId","");kt(this,"latestCompiledDoc",null);kt(this,"cliBridge",new cs);kt(this,"debounceTimer",null);kt(this,"activeCursorBlockId","");kt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));kt(this,"onWsMainBound",this.onWsMain.bind(this));kt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));kt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));kt(this,"onEditorClickBound",this.onEditorClick.bind(this));kt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));kt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=mt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Yb),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Gb(this);const n=this;if(this.addTab({type:Cr,init(){Hb(this.element,n)},destroy(){aa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Jb,init(){Ub(this.element,n)},destroy(){ca(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData($r),n=Dp(e);return qi(n),n}catch{return qi(Xi),Xi}}async saveGlobalSettings(e){const n=Ls(),o=qi({...n,...e||{}});try{await this.saveData($r,o)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Mn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await mt.openTab({app:this.app,custom:{id:this.name+Cr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,r=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!r||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Ot(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Ot(r,{"custom-slidev-theme":"default"}),mt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Ot(r,{"custom-slidev-theme":"seriph"}),mt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Ot(r,{"custom-slidev-theme":"apple-basic"}),mt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Ot(r,{"custom-slidev-aspect-ratio":"16/9"}),mt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Ot(r,{"custom-slidev-aspect-ratio":"4/3"}),mt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const n=(r=e.detail)==null?void 0:r.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const s=await Ze(o).catch(()=>({}));Jn({id:o,rootId:o,type:"doc",attrs:s}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var r,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(r=n.protyle)==null?void 0:r.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return Si.getActiveDocumentId()}resolveDocIdFromElement(e){return Si.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await Si.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&(Si.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,Si.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const u=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=u==null?void 0:u.querySelector(".protyle-title__input"),f=((m==null?void 0:m.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const s=n.closest("[data-node-id]");if(!s)return;const a=s.getAttribute("data-node-id"),c=s.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,as(a)),this.syncInspectorBlock(s,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const r=o.closest(".protyle-title");if(!!(r||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const u=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=u==null?void 0:u.querySelector(".protyle-title__input"),f=((m==null?void 0:m.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!o.closest(".protyle-wysiwyg"))return;const s=o.closest("[data-node-id]"),a=s==null?void 0:s.getAttribute("data-node-id"),c=(s==null?void 0:s.getAttribute("data-type"))||"";s&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,as(a)),this.syncInspectorBlock(s,a,c))}async syncInspectorBlock(e,n,o){await Si.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Rt.compile(n);this.latestCompiledDoc=o,Wb(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){Si.purgeStaleDomSlidevAttrs(e)}}module.exports=Xb;
