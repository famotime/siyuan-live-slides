"use strict";var lc=Object.create;var Po=Object.defineProperty;var ac=Object.getOwnPropertyDescriptor;var cc=Object.getOwnPropertyNames;var dc=Object.getPrototypeOf,uc=Object.prototype.hasOwnProperty;var fc=(t,e,i)=>e in t?Po(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var pc=(t,e,i,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let o of cc(e))!uc.call(t,o)&&o!==i&&Po(t,o,{get:()=>e[o],enumerable:!(n=ac(e,o))||n.enumerable});return t};var Hn=(t,e,i)=>(i=t!=null?lc(dc(t)):{},pc(e||!t||!t.__esModule?Po(i,"default",{value:t,enumerable:!0}):i,t));var yt=(t,e,i)=>fc(t,typeof e!="symbol"?e+"":e,i);const ht=require("siyuan");async function ge(t,e){const i=await ht.fetchSyncPost(t,e);return i.code===0?i.data:null}async function hc(){return ge("/api/notebook/lsNotebooks","")}async function mc(t,e,i){return ge("/api/filetree/createDocWithMd",{notebook:t,path:e,markdown:i})}async function Vr(t,e){const i=new FormData;i.append("assetsDirPath",t);for(const o of e)i.append("file[]",o);return ge("/api/asset/upload",i)}async function $i(t,e,i,n,o){return ge("/api/block/insertBlock",{dataType:t,data:e,nextID:i,previousID:n,parentID:o})}async function es(t,e,i){return ge("/api/block/appendBlock",{dataType:t,data:e,parentID:i})}async function Xs(t,e,i){return ge("/api/block/updateBlock",{dataType:t,data:e,id:i})}async function Qs(t){return ge("/api/block/deleteBlock",{id:t})}async function gc(t){return ge("/api/block/getBlockKramdown",{id:t})}async function so(t){return ge("/api/block/getChildBlocks",{id:t})}async function vc(t){return ge("/api/block/getDocBlocksOrders",{id:t})}async function Et(t,e){return ge("/api/attr/setBlockAttrs",{id:t,attrs:e})}async function ks(t){return ge("/api/attr/getBlockAttrs",{id:t})}async function kn(t){return ge("/api/query/sql",{stmt:t})}async function is(t,e,i){const n=new FormData;return n.append("path",t),n.append("isDir",e.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),ge("/api/file/putFile",n)}async function qr(t){const e="/api/ai/chatGPT";try{const i=await ge(e,{msg:t});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function bc(){return ge("/api/storage/getInlineStyles","")}const Kr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function yc(t){const e=[];if(!t)return e;const i=new RegExp(Kr.source,"g");let n;for(;(n=i.exec(t))!==null;){const o=n[2]??n[3]??n[4];e.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return e}function kc(t,e){if(!t)return"";const i=new RegExp(Kr.source,"g");return t.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(e&&e[o]){const u=e[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const wn="custom-slidev-theme",xn="custom-slidev-aspect-ratio",Gr="custom-slidev-highlighter",_n="custom-slidev-default-transition",Zr="custom-slidev-color-schema",ns="custom-slidev-spacing",Ai="custom-slidev-slide",gt="custom-slidev-layout",te="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Ui="custom-slidev-notes",Wi="custom-slidev-class",un="custom-slidev-spacing",le="custom-slidev-layout-ratio",jt="custom-slidev-click",Ve="custom-slidev-motion",Ri="custom-slidev-shiki-lines",Ct="custom-slidev-slot",ne="custom-slidev-note",qt="custom-slidev-role",Sn="custom-slidev-max-height",Bi="custom-slidev-autoplay",ro="custom-slidev-loop",ji="custom-slidev-muted",lo="custom-slidev-controls",Yr="background",ao="image-left",co="image-right";function Cn(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function wc(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function xc(t){const e={};if(!t)return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}function Jr(t){if(!t)return!1;const e=t.trim();return e.startsWith("assets/")||e.startsWith("./assets/")||e.startsWith("/assets/")}function Xr(t){const e=t.trim();return e.startsWith("./assets/")?e.slice(2):e.startsWith("/assets/")?e.slice(1):e}function Ae(t,e){if(!Jr(t))return t;const i=Xr(t);return e!=null&&e.base64Map&&e.base64Map[i]?e.base64Map[i]:e!=null&&e.baseUrl?`${e.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function _c(t,e){if(!t)return"";let i=t;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ae(s,e);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ae(s,e);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ae(s,e);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function ws(t){const e=Object.create(null);for(const i of t.split(","))e[i]=1;return i=>i in e}const Wt={},Vi=[],qe=()=>{},Qr=()=>!1,wo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),xo=t=>t.startsWith("onUpdate:"),ue=Object.assign,xs=(t,e)=>{const i=t.indexOf(e);i>-1&&t.splice(i,1)},Sc=Object.prototype.hasOwnProperty,zt=(t,e)=>Sc.call(t,e),$t=Array.isArray,qi=t=>Ln(t)==="[object Map]",tn=t=>Ln(t)==="[object Set]",tr=t=>Ln(t)==="[object Date]",Bt=t=>typeof t=="function",ee=t=>typeof t=="string",Re=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",tl=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),el=Object.prototype.toString,Ln=t=>el.call(t),Cc=t=>Ln(t).slice(8,-1),il=t=>Ln(t)==="[object Object]",_s=t=>ee(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=ws(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),_o=t=>{const e=Object.create(null);return(i=>e[i]||(e[i]=t(i)))},$c=/-\w/g,ke=_o(t=>t.replace($c,e=>e.slice(1).toUpperCase())),Ic=/\B([A-Z])/g,bi=_o(t=>t.replace(Ic,"-$1").toLowerCase()),So=_o(t=>t.charAt(0).toUpperCase()+t.slice(1)),zo=_o(t=>t?`on${So(t)}`:""),Ue=(t,e)=>!Object.is(t,e),Yn=(t,...e)=>{for(let i=0;i<t.length;i++)t[i](...e)},nl=(t,e,i,n=!1)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,writable:n,value:i})},Co=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let er;const $o=()=>er||(er=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function $n(t){if($t(t)){const e={};for(let i=0;i<t.length;i++){const n=t[i],o=ee(n)?Ec(n):$n(n);if(o)for(const s in o)e[s]=o[s]}return e}else if(ee(t)||Ht(t))return t}const Ac=/;(?![^(]*\))/g,Bc=/:([^]+)/,Tc=/\/\*[^]*?\*\//g;function Ec(t){const e={};return t.replace(Tc,"").split(Ac).forEach(i=>{if(i){const n=i.split(Bc);n.length>1&&(e[n[0].trim()]=n[1].trim())}}),e}function At(t){let e="";if(ee(t))e=t;else if($t(t))for(let i=0;i<t.length;i++){const n=At(t[i]);n&&(e+=n+" ")}else if(Ht(t))for(const i in t)t[i]&&(e+=i+" ");return e.trim()}const Mc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Dc=ws(Mc);function ol(t){return!!t||t===""}function Lc(t,e){if(t.length!==e.length)return!1;let i=!0;for(let n=0;i&&n<t.length;n++)i=en(t[n],e[n]);return i}function en(t,e){if(t===e)return!0;let i=tr(t),n=tr(e);if(i||n)return i&&n?t.getTime()===e.getTime():!1;if(i=Re(t),n=Re(e),i||n)return t===e;if(i=$t(t),n=$t(e),i||n)return i&&n?Lc(t,e):!1;if(i=Ht(t),n=Ht(e),i||n){if(!i||!n)return!1;const o=Object.keys(t).length,s=Object.keys(e).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=e.hasOwnProperty(l);if(r&&!a||!r&&a||!en(t[l],e[l]))return!1}}return String(t)===String(e)}function Ss(t,e){return t.findIndex(i=>en(i,e))}const sl=t=>!!(t&&t.__v_isRef===!0),xt=t=>ee(t)?t:t==null?"":$t(t)||Ht(t)&&(t.toString===el||!Bt(t.toString))?sl(t)?xt(t.value):JSON.stringify(t,rl,2):String(t),rl=(t,e)=>sl(e)?rl(t,e.value):qi(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((i,[n,o],s)=>(i[No(n,s)+" =>"]=o,i),{})}:tn(e)?{[`Set(${e.size})`]:[...e.values()].map(i=>No(i))}:Re(e)?No(e):Ht(e)&&!$t(e)&&!il(e)?String(e):e,No=(t,e="")=>{var i;return Re(t)?`Symbol(${(i=t.description)!=null?i:e})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class Rc{constructor(e=!1){this.detached=e,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!e&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let e,i;if(this.scopes){const n=this.scopes.slice();for(e=0,i=n.length;e<i;e++)n[e].pause()}for(e=0,i=this.effects.length;e<i;e++)this.effects[e].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let e,i;if(this.scopes){const o=this.scopes.slice();for(e=0,i=o.length;e<i;e++)o[e].resume()}const n=this.effects.slice();for(e=0,i=n.length;e<i;e++)n[e].resume()}}run(e){if(this._active){const i=ae;try{return ae=this,e()}finally{ae=i}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let e=ae;for(;e;){if(e.prevScope===this){e.prevScope=this.prevScope;break}e=e.prevScope}}this.prevScope=void 0}}stop(e){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!e){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Oc(){return ae}let Vt;const Fo=new WeakSet;class ll{constructor(e){this.fn=e,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Fo.has(this)&&(Fo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||cl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,ir(this),dl(this);const e=Vt,i=Le;Vt=this,Le=!0;try{return this.fn()}finally{ul(this),Vt=e,Le=i,this.flags&=-3}}stop(){if(this.flags&1){for(let e=this.deps;e;e=e.nextDep)Is(e);this.deps=this.depsTail=void 0,ir(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Fo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){os(this)&&this.run()}get dirty(){return os(this)}}let al=0,pn,hn;function cl(t,e=!1){if(t.flags|=8,e){t.next=hn,hn=t;return}t.next=pn,pn=t}function Cs(){al++}function $s(){if(--al>0)return;if(hn){let e=hn;for(hn=void 0;e;){const i=e.next;e.next=void 0,e.flags&=-9,e=i}}let t;for(;pn;){let e=pn;for(pn=void 0;e;){const i=e.next;if(e.next=void 0,e.flags&=-9,e.flags&1)try{e.trigger()}catch(n){t||(t=n)}e=i}}if(t)throw t}function dl(t){for(let e=t.deps;e;e=e.nextDep)e.version=-1,e.prevActiveLink=e.dep.activeLink,e.dep.activeLink=e}function ul(t){let e,i=t.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),Is(n),Pc(n)):e=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=e,t.depsTail=i}function os(t){for(let e=t.deps;e;e=e.nextDep)if(e.dep.version!==e.version||e.dep.computed&&(fl(e.dep.computed)||e.dep.version!==e.version))return!0;return!!t._dirty}function fl(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===In)||(t.globalVersion=In,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!os(t))))return;t.flags|=2;const e=t.dep,i=Vt,n=Le;Vt=t,Le=!0;try{dl(t);const o=t.fn(t._value);(e.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,e.version++)}catch(o){throw e.version++,o}finally{Vt=i,Le=n,ul(t),t.flags&=-3}}function Is(t,e=!1){const{dep:i,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),i.subs===t&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)Is(s,!0)}!e&&!--i.sc&&i.map&&i.map.delete(i.key)}function Pc(t){const{prevDep:e,nextDep:i}=t;e&&(e.nextDep=i,t.prevDep=void 0),i&&(i.prevDep=e,t.nextDep=void 0)}let Le=!0;const pl=[];function ni(){pl.push(Le),Le=!1}function oi(){const t=pl.pop();Le=t===void 0?!0:t}function ir(t){const{cleanup:e}=t;if(t.cleanup=void 0,e){const i=Vt;Vt=void 0;try{e()}finally{Vt=i}}}let In=0;class zc{constructor(e,i){this.sub=e,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class As{constructor(e){this.computed=e,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(e){if(!Vt||!Le||Vt===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Vt)i=this.activeLink=new zc(Vt,this),Vt.deps?(i.prevDep=Vt.depsTail,Vt.depsTail.nextDep=i,Vt.depsTail=i):Vt.deps=Vt.depsTail=i,hl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Vt.depsTail,i.nextDep=void 0,Vt.depsTail.nextDep=i,Vt.depsTail=i,Vt.deps===i&&(Vt.deps=n)}return i}trigger(e){this.version++,In++,this.notify(e)}notify(e){Cs();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{$s()}}}function hl(t){if(t.dep.sc++,t.sub.flags&4){const e=t.dep.computed;if(e&&!t.dep.subs){e.flags|=20;for(let n=e.deps;n;n=n.nextDep)hl(n)}const i=t.dep.subs;i!==t&&(t.prevSub=i,i&&(i.nextSub=t)),t.dep.subs=t}}const ss=new WeakMap,Ei=Symbol(""),rs=Symbol(""),An=Symbol("");function he(t,e,i){if(Le&&Vt){let n=ss.get(t);n||ss.set(t,n=new Map);let o=n.get(i);o||(n.set(i,o=new As),o.map=n,o.key=i),o.track()}}function Xe(t,e,i,n,o,s){const l=ss.get(t);if(!l){In++;return}const r=a=>{a&&a.trigger()};if(Cs(),e==="clear")l.forEach(r);else{const a=$t(t),c=a&&_s(i);if(a&&i==="length"){const u=Number(n);l.forEach((h,v)=>{(v==="length"||v===An||!Re(v)&&v>=u)&&r(h)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(An)),e){case"add":a?c&&r(l.get("length")):(r(l.get(Ei)),qi(t)&&r(l.get(rs)));break;case"delete":a||(r(l.get(Ei)),qi(t)&&r(l.get(rs)));break;case"set":qi(t)&&r(l.get(Ei));break}}$s()}function Fi(t){const e=Pt(t);return e===t?e:(he(e,"iterate",An),Be(t)?e:e.map(Oe))}function Io(t){return he(t=Pt(t),"iterate",An),t}function He(t,e){return si(t)?Yi(Mi(t)?Oe(e):e):Oe(e)}const Nc={__proto__:null,[Symbol.iterator](){return Ho(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Fi(this).concat(...t.map(e=>$t(e)?Fi(e):e))},entries(){return Ho(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,e){return Ze(this,"every",t,e,void 0,arguments)},filter(t,e){return Ze(this,"filter",t,e,i=>i.map(n=>He(this,n)),arguments)},find(t,e){return Ze(this,"find",t,e,i=>He(this,i),arguments)},findIndex(t,e){return Ze(this,"findIndex",t,e,void 0,arguments)},findLast(t,e){return Ze(this,"findLast",t,e,i=>He(this,i),arguments)},findLastIndex(t,e){return Ze(this,"findLastIndex",t,e,void 0,arguments)},forEach(t,e){return Ze(this,"forEach",t,e,void 0,arguments)},includes(...t){return jo(this,"includes",t)},indexOf(...t){return jo(this,"indexOf",t)},join(t){return Fi(this).join(t)},lastIndexOf(...t){return jo(this,"lastIndexOf",t)},map(t,e){return Ze(this,"map",t,e,void 0,arguments)},pop(){return rn(this,"pop")},push(...t){return rn(this,"push",t)},reduce(t,...e){return nr(this,"reduce",t,e)},reduceRight(t,...e){return nr(this,"reduceRight",t,e)},shift(){return rn(this,"shift")},some(t,e){return Ze(this,"some",t,e,void 0,arguments)},splice(...t){return rn(this,"splice",t)},toReversed(){return Fi(this).toReversed()},toSorted(t){return Fi(this).toSorted(t)},toSpliced(...t){return Fi(this).toSpliced(...t)},unshift(...t){return rn(this,"unshift",t)},values(){return Ho(this,"values",t=>He(this,t))}};function Ho(t,e,i){const n=Io(t),o=n[e]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const Fc=Array.prototype;function Ze(t,e,i,n,o,s){const l=Io(t),r=l!==t&&!Be(t),a=l[e];if(a!==Fc[e]){const h=a.apply(t,s);return r?Oe(h):h}let c=i;l!==t&&(r?c=function(h,v){return i.call(this,He(t,h),v,t)}:i.length>2&&(c=function(h,v){return i.call(this,h,v,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function nr(t,e,i,n){const o=Io(t),s=o!==t&&!Be(t);let l=i,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,h){return r&&(r=!1,c=He(t,c)),i.call(this,c,He(t,u),h,t)}):i.length>3&&(l=function(c,u,h){return i.call(this,c,u,h,t)}));const a=o[e](l,...n);return r?He(t,a):a}function jo(t,e,i){const n=Pt(t);he(n,"iterate",An);const o=n[e](...i);return(o===-1||o===!1)&&Es(i[0])?(i[0]=Pt(i[0]),n[e](...i)):o}function rn(t,e,i=[]){ni(),Cs();const n=Pt(t)[e].apply(t,i);return $s(),oi(),n}const Hc=ws("__proto__,__v_isRef,__isVue"),ml=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Re));function jc(t){Re(t)||(t=String(t));const e=Pt(this);return he(e,"has",t),e.hasOwnProperty(t)}class gl{constructor(e=!1,i=!1){this._isReadonly=e,this._isShallow=i}get(e,i,n){if(i==="__v_skip")return e.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?Xc:kl:s?yl:bl).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(n)?e:void 0;const l=$t(e);if(!o){let a;if(l&&(a=Nc[i]))return a;if(i==="hasOwnProperty")return jc}const r=Reflect.get(e,i,Jt(e)?e:n);if((Re(i)?ml.has(i):Hc(i))||(o||he(e,"get",i),s))return r;if(Jt(r)){const a=l&&_s(i)?r:r.value;return o&&Ht(a)?as(a):a}return Ht(r)?o?as(r):Ao(r):r}}class vl extends gl{constructor(e=!1){super(!1,e)}set(e,i,n,o){let s=e[i];const l=$t(e)&&_s(i);if(!this._isShallow){const c=si(s);if(!Be(n)&&!si(n)&&(s=Pt(s),n=Pt(n)),!l&&Jt(s)&&!Jt(n))return c||(s.value=n),!0}const r=l?Number(i)<e.length:zt(e,i),a=Reflect.set(e,i,n,Jt(e)?e:o);return e===Pt(o)&&a&&(r?Ue(n,s)&&Xe(e,"set",i,n):Xe(e,"add",i,n)),a}deleteProperty(e,i){const n=zt(e,i);e[i];const o=Reflect.deleteProperty(e,i);return o&&n&&Xe(e,"delete",i,void 0),o}has(e,i){const n=Reflect.has(e,i);return(!Re(i)||!ml.has(i))&&he(e,"has",i),n}ownKeys(e){return he(e,"iterate",$t(e)?"length":Ei),Reflect.ownKeys(e)}}class Uc extends gl{constructor(e=!1){super(!0,e)}set(e,i){return!0}deleteProperty(e,i){return!0}}const Wc=new vl,Vc=new Uc,qc=new vl(!0);const ls=t=>t,jn=t=>Reflect.getPrototypeOf(t);function Kc(t,e,i){return function(...n){const o=this.__v_raw,s=Pt(o),l=qi(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=i?ls:e?Yi:Oe;return!e&&he(s,"iterate",a?rs:Ei),ue(Object.create(c),{next(){const{value:h,done:v}=c.next();return v?{value:h,done:v}:{value:r?[u(h[0]),u(h[1])]:u(h),done:v}}})}}function Un(t){return function(...e){return t==="delete"?!1:t==="clear"?void 0:this}}function Gc(t,e){const i={get(o){const s=this.__v_raw,l=Pt(s),r=Pt(o);t||(Ue(o,r)&&he(l,"get",o),he(l,"get",r));const{has:a}=jn(l),c=e?ls:t?Yi:Oe;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&he(Pt(o),"iterate",Ei),o.size},has(o){const s=this.__v_raw,l=Pt(s),r=Pt(o);return t||(Ue(o,r)&&he(l,"has",o),he(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Pt(r),c=e?ls:t?Yi:Oe;return!t&&he(a,"iterate",Ei),r.forEach((u,h)=>o.call(s,c(u),c(h),l))}};return ue(i,t?{add:Un("add"),set:Un("set"),delete:Un("delete"),clear:Un("clear")}:{add(o){const s=Pt(this),l=jn(s),r=Pt(o),a=!e&&!Be(o)&&!si(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Xe(s,"add",a,a)),this},set(o,s){!e&&!Be(s)&&!si(s)&&(s=Pt(s));const l=Pt(this),{has:r,get:a}=jn(l);let c=r.call(l,o);c||(o=Pt(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Xe(l,"set",o,s):Xe(l,"add",o,s),this},delete(o){const s=Pt(this),{has:l,get:r}=jn(s);let a=l.call(s,o);a||(o=Pt(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Xe(s,"delete",o,void 0),c},clear(){const o=Pt(this),s=o.size!==0,l=o.clear();return s&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=Kc(o,t,e)}),i}function Bs(t,e){const i=Gc(t,e);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(i,o)&&o in n?i:n,o,s)}const Zc={get:Bs(!1,!1)},Yc={get:Bs(!1,!0)},Jc={get:Bs(!0,!1)};const bl=new WeakMap,yl=new WeakMap,kl=new WeakMap,Xc=new WeakMap;function Qc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ao(t){return si(t)?t:Ts(t,!1,Wc,Zc,bl)}function td(t){return Ts(t,!1,qc,Yc,yl)}function as(t){return Ts(t,!0,Vc,Jc,kl)}function Ts(t,e,i,n,o){if(!Ht(t)||t.__v_raw&&!(e&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Qc(Cc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:i);return o.set(t,r),r}function Mi(t){return si(t)?Mi(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function Es(t){return t?!!t.__v_raw:!1}function Pt(t){const e=t&&t.__v_raw;return e?Pt(e):t}function ed(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&nl(t,"__v_skip",!0),t}const Oe=t=>Ht(t)?Ao(t):t,Yi=t=>Ht(t)?as(t):t;function Jt(t){return t?t.__v_isRef===!0:!1}function vt(t){return id(t,!1)}function id(t,e){return Jt(t)?t:new nd(t,e)}class nd{constructor(e,i){this.dep=new As,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?e:Pt(e),this._value=i?e:Oe(e),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(e){const i=this._rawValue,n=this.__v_isShallow||Be(e)||si(e);e=n?e:Pt(e),Ue(e,i)&&(this._rawValue=e,this._value=n?e:Oe(e),this.dep.trigger())}}function bt(t){return Jt(t)?t.value:t}const od={get:(t,e,i)=>e==="__v_raw"?t:bt(Reflect.get(t,e,i)),set:(t,e,i,n)=>{const o=t[e];return Jt(o)&&!Jt(i)?(o.value=i,!0):Reflect.set(t,e,i,n)}};function wl(t){return Mi(t)?t:new Proxy(t,od)}class sd{constructor(e,i,n){this.fn=e,this.setter=i,this._value=void 0,this.dep=new As(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=In-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Vt!==this)return cl(this,!0),!0}get value(){const e=this.dep.track();return fl(this),e&&(e.version=this.dep.version),this._value}set value(e){this.setter&&this.setter(e)}}function rd(t,e,i=!1){let n,o;return Bt(t)?n=t:(n=t.get,o=t.set),new sd(n,o,i)}const Wn={},uo=new WeakMap;let Ii;function ld(t,e=!1,i=Ii){if(i){let n=uo.get(i);n||uo.set(i,n=[]),n.push(t)}}function ad(t,e,i=Wt){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=T=>o?T:Be(T)||o===!1||o===0?Qe(T,1):Qe(T);let u,h,v,d,b=!1,m=!1;if(Jt(t)?(h=()=>t.value,b=Be(t)):Mi(t)?(h=()=>c(t),b=!0):$t(t)?(m=!0,b=t.some(T=>Mi(T)||Be(T)),h=()=>t.map(T=>{if(Jt(T))return T.value;if(Mi(T))return c(T);if(Bt(T))return a?a(T,2):T()})):Bt(t)?e?h=a?()=>a(t,2):t:h=()=>{if(v){ni();try{v()}finally{oi()}}const T=Ii;Ii=u;try{return a?a(t,3,[d]):t(d)}finally{Ii=T}}:h=qe,e&&o){const T=h,L=o===!0?1/0:o;h=()=>Qe(T(),L)}const g=Oc(),k=()=>{u.stop(),g&&g.active&&xs(g.effects,u)};if(s&&e){const T=e;e=(...L)=>{const B=T(...L);return k(),B}}let x=m?new Array(t.length).fill(Wn):Wn;const $=T=>{if(!(!(u.flags&1)||!u.dirty&&!T))if(e){const L=u.run();if(T||o||b||(m?L.some((B,w)=>Ue(B,x[w])):Ue(L,x))){v&&v();const B=Ii;Ii=u;try{const w=[L,x===Wn?void 0:m&&x[0]===Wn?[]:x,d];x=L,a?a(e,3,w):e(...w)}finally{Ii=B}}}else u.run()};return r&&r($),u=new ll(h),u.scheduler=l?()=>l($,!1):$,d=T=>ld(T,!1,u),v=u.onStop=()=>{const T=uo.get(u);if(T){if(a)a(T,4);else for(const L of T)L();uo.delete(u)}},e?n?$(!0):x=u.run():l?l($.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function Qe(t,e=1/0,i){if(e<=0||!Ht(t)||t.__v_skip||(i=i||new Map,(i.get(t)||0)>=e))return t;if(i.set(t,e),e--,Jt(t))Qe(t.value,e,i);else if($t(t))for(let n=0;n<t.length;n++)Qe(t[n],e,i);else if(tn(t)||qi(t))t.forEach(n=>{Qe(n,e,i)});else if(il(t)){for(const n in t)Qe(t[n],e,i);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],e,i)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Rn(t,e,i,n){try{return n?t(...n):t()}catch(o){Bo(o,e,i)}}function Pe(t,e,i,n){if(Bt(t)){const o=Rn(t,e,i,n);return o&&tl(o)&&o.catch(s=>{Bo(s,e,i)}),o}if($t(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Pe(t[s],e,i,n));return o}}function Bo(t,e,i,n=!0){const o=e?e.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=e&&e.appContext.config||Wt;if(e){let r=e.parent;const a=e.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let h=0;h<u.length;h++)if(u[h](t,a,c)===!1)return}r=r.parent}if(s){ni(),Rn(s,null,10,[t,a,c]),oi();return}}cd(t,i,o,n,l)}function cd(t,e,i,n=!0,o=!1){if(o)throw t;console.error(t)}const ye=[];let Fe=-1;const Ki=[];let fi=null,Hi=0;const xl=Promise.resolve();let fo=null;function _l(t){const e=fo||xl;return t?e.then(this?t.bind(this):t):e}function dd(t){let e=Fe+1,i=ye.length;for(;e<i;){const n=e+i>>>1,o=ye[n],s=Bn(o);s<t||s===t&&o.flags&2?e=n+1:i=n}return e}function Ms(t){if(!(t.flags&1)){const e=Bn(t),i=ye[ye.length-1];!i||!(t.flags&2)&&e>=Bn(i)?ye.push(t):ye.splice(dd(e),0,t),t.flags|=1,Sl()}}function Sl(){fo||(fo=xl.then($l))}function ud(t){$t(t)?Ki.push(...t):fi&&t.id===-1?fi.splice(Hi+1,0,t):t.flags&1||(Ki.push(t),t.flags|=1),Sl()}function or(t,e,i=Fe+1){for(;i<ye.length;i++){const n=ye[i];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ye.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Cl(t){if(Ki.length){const e=[...new Set(Ki)].sort((i,n)=>Bn(i)-Bn(n));if(Ki.length=0,fi){fi.push(...e);return}for(fi=e,Hi=0;Hi<fi.length;Hi++){const i=fi[Hi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}fi=null,Hi=0}}const Bn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function $l(t){try{for(Fe=0;Fe<ye.length;Fe++){const e=ye[Fe];e&&!(e.flags&8)&&(e.flags&4&&(e.flags&=-2),Rn(e,e.i,e.i?15:14),e.flags&4||(e.flags&=-2))}}finally{for(;Fe<ye.length;Fe++){const e=ye[Fe];e&&(e.flags&=-2)}Fe=-1,ye.length=0,Cl(),fo=null,(ye.length||Ki.length)&&$l()}}let de=null,Il=null;function po(t){const e=de;return de=t,Il=t&&t.type.__scopeId||null,e}function Al(t,e=de,i){if(!e||t._n)return t;const n=(...o)=>{n._d&&gr(-1);const s=po(e),l=ei.length;let r;try{r=t(...o)}finally{for(let a=ei.length;a>l;a--)zs();po(s),n._d&&gr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,e){if(de===null)return t;const i=Do(de),n=t.dirs||(t.dirs=[]);for(let o=0;o<e.length;o++){let[s,l,r,a=Wt]=e[o];s&&(Bt(s)&&(s={mounted:s,updated:s}),s.deep&&Qe(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function wi(t,e,i,n){const o=t.dirs,s=e&&e.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Pe(a,i,8,[t.el,r,t,e]),oi())}}function fd(t,e){if(me){let i=me.provides;const n=me.parent&&me.parent.provides;n===i&&(i=me.provides=Object.create(n)),i[t]=e}}function ti(t,e,i=!1){const n=du();if(n||Zi){let o=Zi?Zi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return i&&Bt(e)?e.call(n&&n.proxy):e}}const pd=Symbol.for("v-scx"),hd=()=>ti(pd);function Di(t,e,i){return Bl(t,e,i)}function Bl(t,e,i=Wt){const{immediate:n,deep:o,flush:s,once:l}=i,r=ue({},i),a=e&&n||!e&&s!=="post";let c;if(En){if(s==="sync"){const d=hd();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=me;r.call=(d,b,m)=>Pe(d,u,b,m);let h=!1;s==="post"?r.scheduler=d=>{we(d,u&&u.suspense)}:s!=="sync"&&(h=!0,r.scheduler=(d,b)=>{b?d():Ms(d)}),r.augmentJob=d=>{e&&(d.flags|=4),h&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const v=ad(t,e,r);return En&&(c?c.push(v):a&&v()),v}function md(t,e,i){const n=this.proxy,o=ee(t)?t.includes(".")?Tl(n,t):()=>n[t]:t.bind(n,n);let s;Bt(e)?s=e:(s=e.handler,i=e);const l=Pn(this),r=Bl(o,s.bind(n),i);return l(),r}function Tl(t,e){const i=e.split(".");return()=>{let n=t;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const gd=Symbol("_vte"),vd=t=>t.__isTeleport,Uo=Symbol("_leaveCb");function Ds(t,e){t.shapeFlag&6&&t.component?(t.transition=e,Ds(t.component.subTree,e)):t.shapeFlag&128?(t.ssContent.transition=e.clone(t.ssContent),t.ssFallback.transition=e.clone(t.ssFallback)):t.transition=e}function Ce(t,e){return Bt(t)?ue({name:t.name},e,{setup:t}):t}function El(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function sr(t,e){let i;return!!((i=Object.getOwnPropertyDescriptor(t,e))&&!i.configurable)}const ho=new WeakMap;function mn(t,e,i,n,o=!1){if($t(t)){t.forEach((m,g)=>mn(m,e&&($t(e)?e[g]:e),i,n,o));return}if(Gi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&mn(t,e,i,n.component.subTree);return}const s=n.shapeFlag&4?Do(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=e&&e.r,u=r.refs===Wt?r.refs={}:r.refs,h=r.setupState,v=Pt(h),d=h===Wt?Qr:m=>sr(u,m)?!1:zt(v,m),b=(m,g)=>!(g&&sr(u,g));if(c!=null&&c!==a){if(rr(e),ee(c))u[c]=null,d(c)&&(h[c]=null);else if(Jt(c)){const m=e;b(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Bt(a))Rn(a,r,12,[l,u]);else{const m=ee(a),g=Jt(a);if(m||g){const k=()=>{if(t.f){const x=m?d(a)?h[a]:u[a]:b()||!t.k?a.value:u[t.k];if(o)$t(x)&&xs(x,s);else if($t(x))x.includes(s)||x.push(s);else if(m)u[a]=[s],d(a)&&(h[a]=u[a]);else{const $=[s];b(a,t.k)&&(a.value=$),t.k&&(u[t.k]=$)}}else m?(u[a]=l,d(a)&&(h[a]=l)):g&&(b(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const x=()=>{k(),ho.delete(t)};x.id=-1,ho.set(t,x),we(x,i)}else rr(t),k()}}}function rr(t){const e=ho.get(t);e&&(e.flags|=8,ho.delete(t))}$o().requestIdleCallback;$o().cancelIdleCallback;const Gi=t=>!!t.type.__asyncLoader,Ml=t=>t.type.__isKeepAlive;function bd(t,e){Dl(t,"a",e)}function yd(t,e){Dl(t,"da",e)}function Dl(t,e,i=me){const n=t.__wdc||(t.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(To(e,n,i),i){let o=i.parent;for(;o&&o.parent;)Ml(o.parent.vnode)&&kd(n,e,i,o),o=o.parent}}function kd(t,e,i,n){const o=To(e,t,n,!0);Rs(()=>{xs(n[e],o)},i)}function To(t,e,i=me,n=!1){if(i){const o=i[t]||(i[t]=[]),s=e.__weh||(e.__weh=(...l)=>{ni();const r=Pn(i),a=Pe(e,i,t,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const li=t=>(e,i=me)=>{(!En||t==="sp")&&To(t,(...n)=>e(...n),i)},wd=li("bm"),On=li("m"),xd=li("bu"),_d=li("u"),Ls=li("bum"),Rs=li("um"),Sd=li("sp"),Cd=li("rtg"),$d=li("rtc");function Id(t,e=me){To("ec",t,e)}const Ad="components";function Bd(t,e){return Ed(Ad,t,!0,e)||t}const Td=Symbol.for("v-ndc");function Ed(t,e,i=!0,n=!1){const o=de||me;if(o){const s=o.type;{const r=mu(s,!1);if(r&&(r===e||r===ke(e)||r===So(ke(e))))return s}const l=lr(o[t]||s[t],e)||lr(o.appContext[t],e);return!l&&n?s:l}}function lr(t,e){return t&&(t[e]||t[ke(e)]||t[So(ke(e))])}function xe(t,e,i,n){let o;const s=i,l=$t(t);if(l||ee(t)){const r=l&&Mi(t);let a=!1,c=!1;r&&(a=!Be(t),c=si(t),t=Io(t)),o=new Array(t.length);for(let u=0,h=t.length;u<h;u++)o[u]=e(a?c?Yi(Oe(t[u])):Oe(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=e(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>e(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=e(t[u],u,a,s)}}else o=[];return o}function Vn(t,e,i={},n,o,s){if(de.ce||de.parent&&Gi(de.parent)&&de.parent.ce){const c=i,u=Object.keys(c).length>0;return e!=="default"&&(c.name=e),nt(),De(Kt,null,[dt("slot",c,n&&n())],u?-2:64)}let l=t[e];l&&l._c&&(l._d=!1);const r=ei.length;nt();let a;try{const c=l&&Ll(l(i)),u=i.key||s||c&&c.key;a=De(Kt,{key:(u&&!Re(u)?u:`_${e}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ei.length;u>r;u--)zs();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Ll(t){return t.some(e=>Ns(e)?!(e.type===ri||e.type===Kt&&!Ll(e.children)):!0)?t:null}const cs=t=>t?ta(t)?Do(t):cs(t.parent):null,gn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>cs(t.parent),$root:t=>cs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Ol(t),$forceUpdate:t=>t.f||(t.f=()=>{Ms(t.update)}),$nextTick:t=>t.n||(t.n=_l.bind(t.proxy)),$watch:t=>md.bind(t)}),Wo=(t,e)=>t!==Wt&&!t.__isScriptSetup&&zt(t,e),Md={get({_:t},e){if(e==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(e[0]!=="$"){const v=l[e];if(v!==void 0)switch(v){case 1:return n[e];case 2:return o[e];case 4:return i[e];case 3:return s[e]}else{if(Wo(n,e))return l[e]=1,n[e];if(o!==Wt&&zt(o,e))return l[e]=2,o[e];if(zt(s,e))return l[e]=3,s[e];if(i!==Wt&&zt(i,e))return l[e]=4,i[e];ds&&(l[e]=0)}}const c=gn[e];let u,h;if(c)return e==="$attrs"&&he(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[e]))return u;if(i!==Wt&&zt(i,e))return l[e]=4,i[e];if(h=a.config.globalProperties,zt(h,e))return h[e]},set({_:t},e,i){const{data:n,setupState:o,ctx:s}=t;return Wo(o,e)?(o[e]=i,!0):n!==Wt&&zt(n,e)?(n[e]=i,!0):zt(t.props,e)||e[0]==="$"&&e.slice(1)in t?!1:(s[e]=i,!0)},has({_:{data:t,setupState:e,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||t!==Wt&&r[0]!=="$"&&zt(t,r)||Wo(e,r)||zt(s,r)||zt(n,r)||zt(gn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,e,i){return i.get!=null?t._.accessCache[e]=0:zt(i,"value")&&this.set(t,e,i.value,null),Reflect.defineProperty(t,e,i)}};function ar(t){return $t(t)?t.reduce((e,i)=>(e[i]=null,e),{}):t}let ds=!0;function Dd(t){const e=Ol(t),i=t.proxy,n=t.ctx;ds=!1,e.beforeCreate&&cr(e.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:h,mounted:v,beforeUpdate:d,updated:b,activated:m,deactivated:g,beforeDestroy:k,beforeUnmount:x,destroyed:$,unmounted:T,render:L,renderTracked:B,renderTriggered:w,errorCaptured:U,serverPrefetch:W,expose:q,inheritAttrs:X,components:I,directives:N,filters:y}=e;if(c&&Ld(c,n,null),l)for(const E in l){const R=l[E];Bt(R)&&(n[E]=R.bind(i))}if(o){const E=o.call(i,i);Ht(E)&&(t.data=Ao(E))}if(ds=!0,s)for(const E in s){const R=s[E],j=Bt(R)?R.bind(i,i):Bt(R.get)?R.get.bind(i,i):qe,Q=!Bt(R)&&Bt(R.set)?R.set.bind(i):qe,A=St({get:j,set:Q});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>A.value,set:M=>A.value=M})}if(r)for(const E in r)Rl(r[E],n,i,E);if(a){const E=Bt(a)?a.call(i):a;Reflect.ownKeys(E).forEach(R=>{fd(R,E[R])})}u&&cr(u,t,"c");function V(E,R){$t(R)?R.forEach(j=>E(j.bind(i))):R&&E(R.bind(i))}if(V(wd,h),V(On,v),V(xd,d),V(_d,b),V(bd,m),V(yd,g),V(Id,U),V($d,B),V(Cd,w),V(Ls,x),V(Rs,T),V(Sd,W),$t(q))if(q.length){const E=t.exposed||(t.exposed={});q.forEach(R=>{Object.defineProperty(E,R,{get:()=>i[R],set:j=>i[R]=j,enumerable:!0})})}else t.exposed||(t.exposed={});L&&t.render===qe&&(t.render=L),X!=null&&(t.inheritAttrs=X),I&&(t.components=I),N&&(t.directives=N),W&&El(t)}function Ld(t,e,i=qe){$t(t)&&(t=us(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Jt(s)?Object.defineProperty(e,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):e[n]=s}}function cr(t,e,i){Pe($t(t)?t.map(n=>n.bind(e.proxy)):t.bind(e.proxy),e,i)}function Rl(t,e,i,n){let o=n.includes(".")?Tl(i,n):()=>i[n];if(ee(t)){const s=e[t];Bt(s)&&Di(o,s)}else if(Bt(t))Di(o,t.bind(i));else if(Ht(t))if($t(t))t.forEach(s=>Rl(s,e,i,n));else{const s=Bt(t.handler)?t.handler.bind(i):e[t.handler];Bt(s)&&Di(o,s,t)}}function Ol(t){const e=t.type,{mixins:i,extends:n}=e,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(e);let a;return r?a=r:!o.length&&!i&&!n?a=e:(a={},o.length&&o.forEach(c=>mo(a,c,l,!0)),mo(a,e,l)),Ht(e)&&s.set(e,a),a}function mo(t,e,i,n=!1){const{mixins:o,extends:s}=e;s&&mo(t,s,i,!0),o&&o.forEach(l=>mo(t,l,i,!0));for(const l in e)if(!(n&&l==="expose")){const r=Rd[l]||i&&i[l];t[l]=r?r(t[l],e[l]):e[l]}return t}const Rd={data:dr,props:ur,emits:ur,methods:cn,computed:cn,beforeCreate:be,created:be,beforeMount:be,mounted:be,beforeUpdate:be,updated:be,beforeDestroy:be,beforeUnmount:be,destroyed:be,unmounted:be,activated:be,deactivated:be,errorCaptured:be,serverPrefetch:be,components:cn,directives:cn,watch:Pd,provide:dr,inject:Od};function dr(t,e){return e?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(e)?e.call(this,this):e)}:e:t}function Od(t,e){return cn(us(t),us(e))}function us(t){if($t(t)){const e={};for(let i=0;i<t.length;i++)e[t[i]]=t[i];return e}return t}function be(t,e){return t?[...new Set([].concat(t,e))]:e}function cn(t,e){return t?ue(Object.create(null),t,e):e}function ur(t,e){return t?$t(t)&&$t(e)?[...new Set([...t,...e])]:ue(Object.create(null),ar(t),ar(e??{})):e}function Pd(t,e){if(!t)return e;if(!e)return t;const i=ue(Object.create(null),t);for(const n in e)i[n]=be(t[n],e[n]);return i}function Pl(){return{app:null,config:{isNativeTag:Qr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let zd=0;function Nd(t,e){return function(n,o=null){Bt(n)||(n=ue({},n)),o!=null&&!Ht(o)&&(o=null);const s=Pl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:zd++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:vu,get config(){return s.config},set config(u){},use(u,...h){return l.has(u)||(u&&Bt(u.install)?(l.add(u),u.install(c,...h)):Bt(u)&&(l.add(u),u(c,...h))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,h){return h?(s.components[u]=h,c):s.components[u]},directive(u,h){return h?(s.directives[u]=h,c):s.directives[u]},mount(u,h,v){if(!a){const d=c._ceVNode||dt(n,o);return d.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),t(d,u,v),a=!0,c._container=u,u.__vue_app__=c,Do(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Pe(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,h){return s.provides[u]=h,c},runWithContext(u){const h=Zi;Zi=c;try{return u()}finally{Zi=h}}};return c}}let Zi=null;const Fd=(t,e)=>e==="modelValue"||e==="model-value"?t.modelModifiers:t[`${e}Modifiers`]||t[`${ke(e)}Modifiers`]||t[`${bi(e)}Modifiers`];function Hd(t,e,...i){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let o=i;const s=e.startsWith("update:"),l=s&&Fd(n,e.slice(7));l&&(l.trim&&(o=i.map(u=>ee(u)?u.trim():u)),l.number&&(o=i.map(Co)));let r,a=n[r=zo(e)]||n[r=zo(ke(e))];!a&&s&&(a=n[r=zo(bi(e))]),a&&Pe(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Pe(c,t,6,o)}}const jd=new WeakMap;function zl(t,e,i=!1){const n=i?jd:e.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const u=zl(c,e,!0);u&&(r=!0,ue(l,u))};!i&&e.mixins.length&&e.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):($t(s)?s.forEach(a=>l[a]=null):ue(l,s),Ht(t)&&n.set(t,l),l)}function Eo(t,e){return!t||!wo(e)?!1:(e=e.slice(2),e=e==="Once"?e:e.replace(/Once$/,""),zt(t,e[0].toLowerCase()+e.slice(1))||zt(t,bi(e))||zt(t,e))}function fr(t){const{type:e,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:h,data:v,setupState:d,ctx:b,inheritAttrs:m}=t,g=po(t);let k,x;try{if(i.shapeFlag&4){const T=o||n,L=T;k=je(c.call(L,T,u,h,d,v,b)),x=r}else{const T=e;k=je(T.length>1?T(h,{attrs:r,slots:l,emit:a}):T(h,null)),x=e.props?r:Ud(r)}}catch(T){ei.length=0,Bo(T,t,1),k=dt(ri)}let $=k;if(x&&m!==!1){const T=Object.keys(x),{shapeFlag:L}=$;T.length&&L&7&&(s&&T.some(xo)&&(x=Wd(x,s)),$=Ji($,x,!1,!0))}return i.dirs&&($=Ji($,null,!1,!0),$.dirs=$.dirs?$.dirs.concat(i.dirs):i.dirs),i.transition&&Ds($,i.transition),k=$,po(g),k}const Ud=t=>{let e;for(const i in t)(i==="class"||i==="style"||wo(i))&&((e||(e={}))[i]=t[i]);return e},Wd=(t,e)=>{const i={};for(const n in t)(!xo(n)||!(n.slice(9)in e))&&(i[n]=t[n]);return i};function Vd(t,e,i){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=e,c=s.emitsOptions;if(e.dirs||e.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?pr(n,l,c):!!l;if(a&8){const u=e.dynamicProps;for(let h=0;h<u.length;h++){const v=u[h];if(Nl(l,n,v)&&!Eo(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?pr(n,l,c):!0:!!l;return!1}function pr(t,e,i){const n=Object.keys(e);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Nl(e,t,s)&&!Eo(i,s))return!0}return!1}function Nl(t,e,i){const n=t[i],o=e[i];return i==="style"&&Ht(n)&&Ht(o)?!en(n,o):n!==o}function qd({vnode:t,parent:e,suspense:i},n){for(;e;){const o=e.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=e.vnode).el=n,e=e.parent;else break}i&&i.activeBranch===t&&(i.vnode.el=n)}const Fl={},Hl=()=>Object.create(Fl),jl=t=>Object.getPrototypeOf(t)===Fl;function Kd(t,e,i,n=!1){const o={},s=Hl();t.propsDefaults=Object.create(null),Ul(t,e,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);i?t.props=n?o:td(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Gd(t,e,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Pt(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let h=0;h<u.length;h++){let v=u[h];if(Eo(t.emitsOptions,v))continue;const d=e[v];if(a)if(zt(s,v))d!==s[v]&&(s[v]=d,c=!0);else{const b=ke(v);o[b]=fs(a,r,b,d,t,!1)}else d!==s[v]&&(s[v]=d,c=!0)}}}else{Ul(t,e,o,s)&&(c=!0);let u;for(const h in r)(!e||!zt(e,h)&&((u=bi(h))===h||!zt(e,u)))&&(a?i&&(i[h]!==void 0||i[u]!==void 0)&&(o[h]=fs(a,r,h,void 0,t,!0)):delete o[h]);if(s!==r)for(const h in s)(!e||!zt(e,h))&&(delete s[h],c=!0)}c&&Xe(t.attrs,"set","")}function Ul(t,e,i,n){const[o,s]=t.propsOptions;let l=!1,r;if(e)for(let a in e){if(fn(a))continue;const c=e[a];let u;o&&zt(o,u=ke(a))?!s||!s.includes(u)?i[u]=c:(r||(r={}))[u]=c:Eo(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Pt(i),c=r||Wt;for(let u=0;u<s.length;u++){const h=s[u];i[h]=fs(o,a,h,c[h],t,!zt(c,h))}}return l}function fs(t,e,i,n,o,s){const l=t[i];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const u=Pn(o);n=c[i]=a.call(null,e),u()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===bi(i))&&(n=!0))}return n}const Zd=new WeakMap;function Wl(t,e,i=!1){const n=i?Zd:e.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!Bt(t)){const u=h=>{a=!0;const[v,d]=Wl(h,e,!0);ue(l,v),d&&r.push(...d)};!i&&e.mixins.length&&e.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,Vi),Vi;if($t(s))for(let u=0;u<s.length;u++){const h=ke(s[u]);hr(h)&&(l[h]=Wt)}else if(s)for(const u in s){const h=ke(u);if(hr(h)){const v=s[u],d=l[h]=$t(v)||Bt(v)?{type:v}:ue({},v),b=d.type;let m=!1,g=!0;if($t(b))for(let k=0;k<b.length;++k){const x=b[k],$=Bt(x)&&x.name;if($==="Boolean"){m=!0;break}else $==="String"&&(g=!1)}else m=Bt(b)&&b.name==="Boolean";d[0]=m,d[1]=g,(m||zt(d,"default"))&&r.push(h)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function hr(t){return t[0]!=="$"&&!fn(t)}const Os=t=>t==="_"||t==="_ctx"||t==="$stable",Ps=t=>$t(t)?t.map(je):[je(t)],Yd=(t,e,i)=>{if(e._n)return e;const n=Al((...o)=>Ps(e(...o)),i);return n._c=!1,n},Vl=(t,e,i)=>{const n=t._ctx;for(const o in t){if(Os(o))continue;const s=t[o];if(Bt(s))e[o]=Yd(o,s,n);else if(s!=null){const l=Ps(s);e[o]=()=>l}}},ql=(t,e)=>{const i=Ps(e);t.slots.default=()=>i},Kl=(t,e,i)=>{for(const n in e)(i||!Os(n))&&(t[n]=e[n])},Jd=(t,e,i)=>{const n=t.slots=Hl();if(t.vnode.shapeFlag&32){const o=e._;o?(Kl(n,e,i),i&&nl(n,"_",o,!0)):Vl(e,n)}else e&&ql(t,e)},Xd=(t,e,i)=>{const{vnode:n,slots:o}=t;let s=!0,l=Wt;if(n.shapeFlag&32){const r=e._;r?i&&r===1?s=!1:Kl(o,e,i):(s=!e.$stable,Vl(e,o)),l=e}else e&&(ql(t,e),l={default:1});if(s)for(const r in o)!Os(r)&&l[r]==null&&delete o[r]},we=nu;function Qd(t){return tu(t)}function tu(t,e){const i=$o();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:h,nextSibling:v,setScopeId:d=qe,insertStaticContent:b}=t,m=(S,P,p,z=null,F=null,_=null,C=void 0,O=null,Z=!!P.dynamicChildren)=>{if(S===P)return;S&&!ln(S,P)&&(z=pt(S),M(S,F,_,!0),S=null),P.patchFlag===-2&&(Z=!1,P.dynamicChildren=null);const{type:G,ref:K,shapeFlag:it}=P;switch(G){case Mo:g(S,P,p,z);break;case ri:k(S,P,p,z);break;case Jn:S==null&&x(P,p,z,C);break;case Kt:I(S,P,p,z,F,_,C,O,Z);break;default:it&1?L(S,P,p,z,F,_,C,O,Z):it&6?N(S,P,p,z,F,_,C,O,Z):(it&64||it&128)&&G.process(S,P,p,z,F,_,C,O,Z,at)}K!=null&&F?mn(K,S&&S.ref,_,P||S,!P):K==null&&S&&S.ref!=null&&mn(S.ref,null,_,S,!0)},g=(S,P,p,z)=>{if(S==null)n(P.el=r(P.children),p,z);else{const F=P.el=S.el;P.children!==S.children&&c(F,P.children)}},k=(S,P,p,z)=>{S==null?n(P.el=a(P.children||""),p,z):P.el=S.el},x=(S,P,p,z)=>{[S.el,S.anchor]=b(S.children,P,p,z,S.el,S.anchor)},$=({el:S,anchor:P},p,z)=>{let F;for(;S&&S!==P;)F=v(S),n(S,p,z),S=F;n(P,p,z)},T=({el:S,anchor:P})=>{let p;for(;S&&S!==P;)p=v(S),o(S),S=p;o(P)},L=(S,P,p,z,F,_,C,O,Z)=>{if(P.type==="svg"?C="svg":P.type==="math"&&(C="mathml"),S==null)B(P,p,z,F,_,C,O,Z);else{const G=S.el&&S.el._isVueCE?S.el:null;try{G&&G._beginPatch(),W(S,P,F,_,C,O,Z)}finally{G&&G._endPatch()}}},B=(S,P,p,z,F,_,C,O)=>{let Z,G;const{props:K,shapeFlag:it,transition:ct,dirs:rt}=S;if(Z=S.el=l(S.type,_,K&&K.is,K),it&8?u(Z,S.children):it&16&&U(S.children,Z,null,z,F,Vo(S,_),C,O),rt&&wi(S,null,z,"created"),w(Z,S,S.scopeId,C,z),K){for(const _t in K)_t!=="value"&&!fn(_t)&&s(Z,_t,null,K[_t],_,z);"value"in K&&s(Z,"value",null,K.value,_),(G=K.onVnodeBeforeMount)&&Ne(G,z,S)}rt&&wi(S,null,z,"beforeMount");const mt=eu(F,ct);mt&&ct.beforeEnter(Z),n(Z,P,p),((G=K&&K.onVnodeMounted)||mt||rt)&&we(()=>{try{G&&Ne(G,z,S),mt&&ct.enter(Z),rt&&wi(S,null,z,"mounted")}finally{}},F)},w=(S,P,p,z,F)=>{if(p&&d(S,p),z)for(let _=0;_<z.length;_++)d(S,z[_]);if(F){let _=F.subTree;if(P===_||Jl(_.type)&&(_.ssContent===P||_.ssFallback===P)){const C=F.vnode;w(S,C,C.scopeId,C.slotScopeIds,F.parent)}}},U=(S,P,p,z,F,_,C,O,Z=0)=>{for(let G=Z;G<S.length;G++){const K=S[G]=O?Je(S[G]):je(S[G]);m(null,K,P,p,z,F,_,C,O)}},W=(S,P,p,z,F,_,C)=>{const O=P.el=S.el;let{patchFlag:Z,dynamicChildren:G,dirs:K}=P;Z|=S.patchFlag&16;const it=S.props||Wt,ct=P.props||Wt;let rt;if(p&&xi(p,!1),(rt=ct.onVnodeBeforeUpdate)&&Ne(rt,p,P,S),K&&wi(P,S,p,"beforeUpdate"),p&&xi(p,!0),G&&(!S.dynamicChildren||S.dynamicChildren.length!==G.length)&&(Z=0,C=!1,G=null),(it.innerHTML&&ct.innerHTML==null||it.textContent&&ct.textContent==null)&&u(O,""),G?q(S.dynamicChildren,G,O,p,z,Vo(P,F),_):C||R(S,P,O,null,p,z,Vo(P,F),_,!1),Z>0){if(Z&16)X(O,it,ct,p,F);else if(Z&2&&it.class!==ct.class&&s(O,"class",null,ct.class,F),Z&4&&s(O,"style",it.style,ct.style,F),Z&8){const mt=P.dynamicProps;for(let _t=0;_t<mt.length;_t++){const wt=mt[_t],Lt=it[wt],Gt=ct[wt];(Gt!==Lt||wt==="value")&&s(O,wt,Lt,Gt,F,p)}}Z&1&&S.children!==P.children&&u(O,P.children)}else!C&&G==null&&X(O,it,ct,p,F);((rt=ct.onVnodeUpdated)||K)&&we(()=>{rt&&Ne(rt,p,P,S),K&&wi(P,S,p,"updated")},z)},q=(S,P,p,z,F,_,C)=>{for(let O=0;O<P.length;O++){const Z=S[O],G=P[O],K=Z.el&&(Z.type===Kt||!ln(Z,G)||Z.shapeFlag&198)?h(Z.el):p;m(Z,G,K,null,z,F,_,C,!0)}},X=(S,P,p,z,F)=>{if(P!==p){if(P!==Wt)for(const _ in P)!fn(_)&&!(_ in p)&&s(S,_,P[_],null,F,z);for(const _ in p){if(fn(_))continue;const C=p[_],O=P[_];C!==O&&_!=="value"&&s(S,_,O,C,F,z)}"value"in p&&s(S,"value",P.value,p.value,F)}},I=(S,P,p,z,F,_,C,O,Z)=>{const G=P.el=S?S.el:r(""),K=P.anchor=S?S.anchor:r("");let{patchFlag:it,dynamicChildren:ct,slotScopeIds:rt}=P;rt&&(O=O?O.concat(rt):rt),S==null?(n(G,p,z),n(K,p,z),U(P.children||[],p,K,F,_,C,O,Z)):it>0&&it&64&&ct&&S.dynamicChildren&&S.dynamicChildren.length===ct.length?(q(S.dynamicChildren,ct,p,F,_,C,O),(P.key!=null||F&&P===F.subTree)&&Gl(S,P,!0)):R(S,P,p,K,F,_,C,O,Z)},N=(S,P,p,z,F,_,C,O,Z)=>{P.slotScopeIds=O,S==null?P.shapeFlag&512?F.ctx.activate(P,p,z,C,Z):y(P,p,z,F,_,C,Z):D(S,P,Z)},y=(S,P,p,z,F,_,C)=>{const O=S.component=cu(S,z,F);if(Ml(S)&&(O.ctx.renderer=at),uu(O,!1,C),O.asyncDep){if(F&&F.registerDep(O,V,C),!S.el){const Z=O.subTree=dt(ri);k(null,Z,P,p),S.placeholder=Z.el}}else V(O,S,P,p,F,_,C)},D=(S,P,p)=>{const z=P.component=S.component;if(Vd(S,P,p))if(z.asyncDep&&!z.asyncResolved){E(z,P,p);return}else z.next=P,z.update();else P.el=S.el,z.vnode=P},V=(S,P,p,z,F,_,C)=>{const O=()=>{if(S.isMounted){let{next:it,bu:ct,u:rt,parent:mt,vnode:_t}=S;{const ie=Zl(S);if(ie){it&&(it.el=_t.el,E(S,it,C)),ie.asyncDep.then(()=>{we(()=>{S.isUnmounted||G()},F)});return}}let wt=it,Lt;xi(S,!1),it?(it.el=_t.el,E(S,it,C)):it=_t,ct&&Yn(ct),(Lt=it.props&&it.props.onVnodeBeforeUpdate)&&Ne(Lt,mt,it,_t),xi(S,!0);const Gt=fr(S),Yt=S.subTree;S.subTree=Gt,m(Yt,Gt,h(Yt.el),pt(Yt),S,F,_),it.el=Gt.el,wt===null&&qd(S,Gt.el),rt&&we(rt,F),(Lt=it.props&&it.props.onVnodeUpdated)&&we(()=>Ne(Lt,mt,it,_t),F)}else{let it;const{el:ct,props:rt}=P,{bm:mt,m:_t,parent:wt,root:Lt,type:Gt}=S,Yt=Gi(P);xi(S,!1),mt&&Yn(mt),!Yt&&(it=rt&&rt.onVnodeBeforeMount)&&Ne(it,wt,P),xi(S,!0);{Lt.ce&&Lt.ce._hasShadowRoot()&&Lt.ce._injectChildStyle(Gt,S.parent?S.parent.type:void 0);const ie=S.subTree=fr(S);m(null,ie,p,z,S,F,_),P.el=ie.el}if(_t&&we(_t,F),!Yt&&(it=rt&&rt.onVnodeMounted)){const ie=P;we(()=>Ne(it,wt,ie),F)}(P.shapeFlag&256||wt&&Gi(wt.vnode)&&wt.vnode.shapeFlag&256)&&S.a&&we(S.a,F),S.isMounted=!0,P=p=z=null}};S.scope.on();const Z=S.effect=new ll(O);S.scope.off();const G=S.update=Z.run.bind(Z),K=S.job=Z.runIfDirty.bind(Z);K.i=S,K.id=S.uid,Z.scheduler=()=>Ms(K),xi(S,!0),G()},E=(S,P,p)=>{P.component=S;const z=S.vnode.props;S.vnode=P,S.next=null,Gd(S,P.props,z,p),Xd(S,P.children,p),ni(),or(S),oi()},R=(S,P,p,z,F,_,C,O,Z=!1)=>{const G=S&&S.children,K=S?S.shapeFlag:0,it=P.children,{patchFlag:ct,shapeFlag:rt}=P;if(ct>0){if(ct&128){Q(G,it,p,z,F,_,C,O,Z);return}else if(ct&256){j(G,it,p,z,F,_,C,O,Z);return}}rt&8?(K&16&&et(G,F,_),it!==G&&u(p,it)):K&16?rt&16?Q(G,it,p,z,F,_,C,O,Z):et(G,F,_,!0):(K&8&&u(p,""),rt&16&&U(it,p,z,F,_,C,O,Z))},j=(S,P,p,z,F,_,C,O,Z)=>{S=S||Vi,P=P||Vi;const G=S.length,K=P.length,it=Math.min(G,K);let ct;for(ct=0;ct<it;ct++){const rt=P[ct]=Z?Je(P[ct]):je(P[ct]);m(S[ct],rt,p,null,F,_,C,O,Z)}G>K?et(S,F,_,!0,!1,it):U(P,p,z,F,_,C,O,Z,it)},Q=(S,P,p,z,F,_,C,O,Z)=>{let G=0;const K=P.length;let it=S.length-1,ct=K-1;for(;G<=it&&G<=ct;){const rt=S[G],mt=P[G]=Z?Je(P[G]):je(P[G]);if(ln(rt,mt))m(rt,mt,p,null,F,_,C,O,Z);else break;G++}for(;G<=it&&G<=ct;){const rt=S[it],mt=P[ct]=Z?Je(P[ct]):je(P[ct]);if(ln(rt,mt))m(rt,mt,p,null,F,_,C,O,Z);else break;it--,ct--}if(G>it){if(G<=ct){const rt=ct+1,mt=rt<K?P[rt].el:z;for(;G<=ct;)m(null,P[G]=Z?Je(P[G]):je(P[G]),p,mt,F,_,C,O,Z),G++}}else if(G>ct)for(;G<=it;)M(S[G],F,_,!0),G++;else{const rt=G,mt=G,_t=new Map;for(G=mt;G<=ct;G++){const se=P[G]=Z?Je(P[G]):je(P[G]);se.key!=null&&_t.set(se.key,G)}let wt,Lt=0;const Gt=ct-mt+1;let Yt=!1,ie=0;const Nt=new Array(Gt);for(G=0;G<Gt;G++)Nt[G]=0;for(G=rt;G<=it;G++){const se=S[G];if(Lt>=Gt){M(se,F,_,!0);continue}let Xt;if(se.key!=null)Xt=_t.get(se.key);else for(wt=mt;wt<=ct;wt++)if(Nt[wt-mt]===0&&ln(se,P[wt])){Xt=wt;break}Xt===void 0?M(se,F,_,!0):(Nt[Xt-mt]=G+1,Xt>=ie?ie=Xt:Yt=!0,m(se,P[Xt],p,null,F,_,C,O,Z),Lt++)}const Ge=Yt?iu(Nt):Vi;for(wt=Ge.length-1,G=Gt-1;G>=0;G--){const se=mt+G,Xt=P[se],yi=P[se+1],Pi=se+1<K?yi.el||Yl(yi):z;Nt[G]===0?m(null,Xt,p,Pi,F,_,C,O,Z):Yt&&(wt<0||G!==Ge[wt]?A(Xt,p,Pi,2):wt--)}}},A=(S,P,p,z,F=null)=>{const{el:_,type:C,transition:O,children:Z,shapeFlag:G}=S;if(G&6){A(S.component.subTree,P,p,z);return}if(G&128){S.suspense.move(P,p,z);return}if(G&64){C.move(S,P,p,at);return}if(C===Kt){n(_,P,p);for(let it=0;it<Z.length;it++)A(Z[it],P,p,z);n(S.anchor,P,p);return}if(C===Jn){$(S,P,p);return}if(z!==2&&G&1&&O)if(z===0)O.persisted&&!_[Uo]?n(_,P,p):(O.beforeEnter(_),n(_,P,p),we(()=>O.enter(_),F));else{const{leave:it,delayLeave:ct,afterLeave:rt}=O,mt=()=>{S.ctx.isUnmounted?o(_):n(_,P,p)},_t=()=>{const wt=_._isLeaving||!!_[Uo];_._isLeaving&&_[Uo](!0),O.persisted&&!wt?mt():it(_,()=>{mt(),rt&&rt()})};ct?ct(_,mt,_t):_t()}else n(_,P,p)},M=(S,P,p,z=!1,F=!1)=>{const{type:_,props:C,ref:O,children:Z,dynamicChildren:G,shapeFlag:K,patchFlag:it,dirs:ct,cacheIndex:rt,memo:mt}=S;if(it===-2&&(F=!1),O!=null&&(ni(),mn(O,null,p,S,!0),oi()),rt!=null&&(P.renderCache[rt]=void 0),K&256){P.ctx.deactivate(S);return}const _t=K&1&&ct,wt=!Gi(S);let Lt;if(wt&&(Lt=C&&C.onVnodeBeforeUnmount)&&Ne(Lt,P,S),K&6)tt(S.component,p,z);else{if(K&128){S.suspense.unmount(p,z);return}_t&&wi(S,null,P,"beforeUnmount"),K&64?S.type.remove(S,P,p,at,z):G&&!G.hasOnce&&(_!==Kt||it>0&&it&64)?et(G,P,p,!1,!0):(_===Kt&&it&384||!F&&K&16)&&et(Z,P,p),z&&J(S)}const Gt=mt!=null&&rt==null;(wt&&(Lt=C&&C.onVnodeUnmounted)||_t||Gt)&&we(()=>{Lt&&Ne(Lt,P,S),_t&&wi(S,null,P,"unmounted"),Gt&&(S.el=null)},p)},J=S=>{const{type:P,el:p,anchor:z,transition:F}=S;if(P===Kt){Y(p,z);return}if(P===Jn){T(S);return}const _=()=>{o(p),F&&!F.persisted&&F.afterLeave&&F.afterLeave()};if(S.shapeFlag&1&&F&&!F.persisted){const{leave:C,delayLeave:O}=F,Z=()=>C(p,_);O?O(S.el,_,Z):Z()}else _()},Y=(S,P)=>{let p;for(;S!==P;)p=v(S),o(S),S=p;o(P)},tt=(S,P,p)=>{const{bum:z,scope:F,job:_,subTree:C,um:O,m:Z,a:G}=S;mr(Z),mr(G),z&&Yn(z),F.stop(),_&&(_.flags|=8,M(C,S,P,p)),O&&we(O,P),we(()=>{S.isUnmounted=!0},P)},et=(S,P,p,z=!1,F=!1,_=0)=>{for(let C=_;C<S.length;C++)M(S[C],P,p,z,F)},pt=S=>{if(S.shapeFlag&6)return pt(S.component.subTree);if(S.shapeFlag&128)return S.suspense.next();const P=v(S.anchor||S.el),p=P&&P[gd];return p?v(p):P};let lt=!1;const H=(S,P,p)=>{let z;S==null?P._vnode&&(M(P._vnode,null,null,!0),z=P._vnode.component):m(P._vnode||null,S,P,null,null,null,p),P._vnode=S,lt||(lt=!0,or(z),Cl(),lt=!1)},at={p:m,um:M,m:A,r:J,mt:y,mc:U,pc:R,pbc:q,n:pt,o:t};return{render:H,hydrate:void 0,createApp:Nd(H)}}function Vo({type:t,props:e},i){return i==="svg"&&t==="foreignObject"||i==="mathml"&&t==="annotation-xml"&&e&&e.encoding&&e.encoding.includes("html")?void 0:i}function xi({effect:t,job:e},i){i?(t.flags|=32,e.flags|=4):(t.flags&=-33,e.flags&=-5)}function eu(t,e){return(!t||t&&!t.pendingBranch)&&e&&!e.persisted}function Gl(t,e,i=!1){const n=t.children,o=e.children;if($t(n)&&$t(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Je(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&Gl(l,r)),r.type===Mo&&(r.patchFlag===-1&&(r=o[s]=Je(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function iu(t){const e=t.slice(),i=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=i[i.length-1],t[o]<c){e[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,t[i[r]]<c?s=r+1:l=r;c<t[i[s]]&&(s>0&&(e[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=e[l];return i}function Zl(t){const e=t.subTree.component;if(e)return e.asyncDep&&!e.asyncResolved?e:Zl(e)}function mr(t){if(t)for(let e=0;e<t.length;e++)t[e].flags|=8}function Yl(t){if(t.placeholder)return t.placeholder;const e=t.component;return e?Yl(e.subTree):null}const Jl=t=>t.__isSuspense;function nu(t,e){e&&e.pendingBranch?$t(t)?e.effects.push(...t):e.effects.push(t):ud(t)}const Kt=Symbol.for("v-fgt"),Mo=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),Jn=Symbol.for("v-stc"),ei=[];let Ie=null;function nt(t=!1){ei.push(Ie=t?null:[])}function zs(){ei.pop(),Ie=ei[ei.length-1]||null}let Tn=1;function gr(t,e=!1){Tn+=t,t<0&&Ie&&e&&(Ie.hasOnce=!0)}function Xl(t){return t.dynamicChildren=Tn>0?Ie||Vi:null,zs(),Tn>0&&Ie&&Ie.push(t),t}function st(t,e,i,n,o,s){return Xl(f(t,e,i,n,o,s,!0))}function De(t,e,i,n,o){return Xl(dt(t,e,i,n,o,!0))}function Ns(t){return t?t.__v_isVNode===!0:!1}function ln(t,e){return t.type===e.type&&t.key===e.key}const Ql=({key:t})=>t??null,Xn=({ref:t,ref_key:e,ref_for:i})=>(typeof t=="number"&&(t=""+t),t!=null?ee(t)||Jt(t)||Bt(t)?{i:de,r:t,k:e,f:!!i}:t:null);function f(t,e=null,i=null,n=0,o=null,s=t===Kt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&Ql(e),ref:e&&Xn(e),scopeId:Il,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:de};return r?(go(a,i),s&128&&t.normalize(a)):i&&(a.shapeFlag|=ee(i)?8:16),Tn>0&&!l&&Ie&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Ie.push(a),a}const dt=ou;function ou(t,e=null,i=null,n=0,o=null,s=!1){if((!t||t===Td)&&(t=ri),Ns(t)){const r=Ji(t,e,!0);return i&&go(r,i),Tn>0&&!s&&Ie&&(r.shapeFlag&6?Ie[Ie.indexOf(t)]=r:Ie.push(r)),r.patchFlag=-2,r}if(gu(t)&&(t=t.__vccOpts),e){e=su(e);let{class:r,style:a}=e;r&&!ee(r)&&(e.class=At(r)),Ht(a)&&(Es(a)&&!$t(a)&&(a=ue({},a)),e.style=$n(a))}const l=ee(t)?1:Jl(t)?128:vd(t)?64:Ht(t)?4:Bt(t)?2:0;return f(t,e,i,n,o,l,s,!0)}function su(t){return t?Es(t)||jl(t)?ue({},t):t:null}function Ji(t,e,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=e?ru(o||{},e):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ql(c),ref:e&&e.ref?i&&s?$t(s)?s.concat(Xn(e)):[s,Xn(e)]:Xn(e):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ji(t.ssContent),ssFallback:t.ssFallback&&Ji(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&Ds(u,a.clone(u)),u}function $e(t=" ",e=0){return dt(Mo,null,t,e)}function ve(t,e){const i=dt(Jn,null,t);return i.staticCount=e,i}function Ot(t="",e=!1){return e?(nt(),De(ri,null,t)):dt(ri,null,t)}function je(t){return t==null||typeof t=="boolean"?dt(ri):$t(t)?dt(Kt,null,t.slice()):Ns(t)?Je(t):dt(Mo,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ji(t)}function go(t,e){let i=0;const{shapeFlag:n}=t;if(e==null)e=null;else if($t(e))i=16;else if(typeof e=="object")if(n&65){const o=e.default;o&&(o._c&&(o._d=!1),go(t,o()),o._c&&(o._d=!0));return}else{i=32;const o=e._;!o&&!jl(e)?e._ctx=de:o===3&&de&&(de.slots._===1?e._=1:(e._=2,t.patchFlag|=1024))}else if(Bt(e)){if(n&65){go(t,{default:e});return}e={default:e,_ctx:de},i=32}else e=String(e),n&64?(i=16,e=[$e(e)]):i=8;t.children=e,t.shapeFlag|=i}function ru(...t){const e={};for(let i=0;i<t.length;i++){const n=t[i];for(const o in n)if(o==="class")e.class!==n.class&&(e.class=At([e.class,n.class]));else if(o==="style")e.style=$n([e.style,n.style]);else if(wo(o)){const s=e[o],l=n[o];l&&s!==l&&!($t(s)&&s.includes(l))?e[o]=s?[].concat(s,l):l:l==null&&s==null&&!xo(o)&&(e[o]=l)}else o!==""&&(e[o]=n[o])}return e}function Ne(t,e,i,n=null){Pe(t,e,7,[i,n])}const lu=Pl();let au=0;function cu(t,e,i){const n=t.type,o=(e?e.appContext:t.appContext)||lu,s={uid:au++,vnode:t,type:n,parent:e,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Rc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(o.provides),ids:e?e.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Wl(n,o),emitsOptions:zl(n,o),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=e?e.root:s,s.emit=Hd.bind(null,s),t.ce&&t.ce(s),s}let me=null;const du=()=>me||de;let vo,ps;{const t=$o(),e=(i,n)=>{let o;return(o=t[i])||(o=t[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};vo=e("__VUE_INSTANCE_SETTERS__",i=>me=i),ps=e("__VUE_SSR_SETTERS__",i=>En=i)}const Pn=t=>{const e=me;return vo(t),t.scope.on(),()=>{t.scope.off(),vo(e)}},vr=()=>{me&&me.scope.off(),vo(null)};function ta(t){return t.vnode.shapeFlag&4}let En=!1;function uu(t,e=!1,i=!1){e&&ps(e);const{props:n,children:o}=t.vnode,s=ta(t);Kd(t,n,s,e),Jd(t,o,i||e);const l=s?fu(t,e):void 0;return e&&ps(!1),l}function fu(t,e){const i=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Md);const{setup:n}=i;if(n){ni();const o=t.setupContext=n.length>1?hu(t):null,s=Pn(t),l=Rn(n,t,0,[t.props,o]),r=tl(l);if(oi(),s(),(r||t.sp)&&!Gi(t)&&El(t),r){if(l.then(vr,vr),e)return l.then(a=>{br(t,a)}).catch(a=>{Bo(a,t,0)});t.asyncDep=l}else br(t,l)}else ea(t)}function br(t,e,i){Bt(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:Ht(e)&&(t.setupState=wl(e)),ea(t)}function ea(t,e,i){const n=t.type;t.render||(t.render=n.render||qe);{const o=Pn(t);ni();try{Dd(t)}finally{oi(),o()}}}const pu={get(t,e){return he(t,"get",""),t[e]}};function hu(t){const e=i=>{t.exposed=i||{}};return{attrs:new Proxy(t.attrs,pu),slots:t.slots,emit:t.emit,expose:e}}function Do(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(wl(ed(t.exposed)),{get(e,i){if(i in e)return e[i];if(i in gn)return gn[i](t)},has(e,i){return i in e||i in gn}})):t.proxy}function mu(t,e=!0){return Bt(t)?t.displayName||t.name:t.name||e&&t.__name}function gu(t){return Bt(t)&&"__vccOpts"in t}const St=(t,e)=>rd(t,e,En),vu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let hs;const yr=typeof window<"u"&&window.trustedTypes;if(yr)try{hs=yr.createPolicy("vue",{createHTML:t=>t})}catch{}const ia=hs?t=>hs.createHTML(t):t=>t,bu="http://www.w3.org/2000/svg",yu="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,kr=Ye&&Ye.createElement("template"),ku={insert:(t,e,i)=>{e.insertBefore(t,i||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,i,n)=>{const o=e==="svg"?Ye.createElementNS(bu,t):e==="mathml"?Ye.createElementNS(yu,t):i?Ye.createElement(t,{is:i}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},insertStaticContent(t,e,i,n,o,s){const l=i?i.previousSibling:e.lastChild;if(o&&(o===s||o.nextSibling))for(;e.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{kr.innerHTML=ia(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=kr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}e.insertBefore(r,i)}return[l?l.nextSibling:e.firstChild,i?i.previousSibling:e.lastChild]}},wu=Symbol("_vtc");function xu(t,e,i){const n=t[wu];n&&(e=(e?[e,...n]:[...n]).join(" ")),e==null?t.removeAttribute("class"):i?t.setAttribute("class",e):t.className=e}const bo=Symbol("_vod"),na=Symbol("_vsh"),oa={name:"show",beforeMount(t,{value:e},{transition:i}){t[bo]=t.style.display==="none"?"":t.style.display,i&&e?i.beforeEnter(t):an(t,e)},mounted(t,{value:e},{transition:i}){i&&e&&i.enter(t)},updated(t,{value:e,oldValue:i},{transition:n}){!e!=!i&&(n?e?(n.beforeEnter(t),an(t,!0),n.enter(t)):n.leave(t,()=>{an(t,!1)}):an(t,e))},beforeUnmount(t,{value:e}){an(t,e)}};function an(t,e){t.style.display=e?t[bo]:"none",t[na]=!e}const _u=Symbol(""),Su=/(?:^|;)\s*display\s*:/;function Cu(t,e,i){const n=t.style,o=ee(i);let s=!1;if(i&&!o){if(e)if(ee(e))for(const l of e.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&dn(n,r,"")}else for(const l in e)i[l]==null&&dn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?Iu(t,l,!ee(e)&&e?e[l]:void 0,r)||dn(n,l,r):dn(n,l,"")}}else if(o){if(e!==i){const l=n[_u];l&&(i+=";"+l),n.cssText=i,s=Su.test(i)}}else e&&t.removeAttribute("style");bo in t&&(t[bo]=s?n.display:"",t[na]&&(n.display="none"))}const wr=/\s*!important$/;function dn(t,e,i){if($t(i))i.forEach(n=>dn(t,e,n));else if(i==null&&(i=""),e.startsWith("--"))t.setProperty(e,i);else{const n=$u(t,e);wr.test(i)?t.setProperty(bi(n),i.replace(wr,""),"important"):t[n]=i}}const xr=["Webkit","Moz","ms"],qo={};function $u(t,e){const i=qo[e];if(i)return i;let n=ke(e);if(n!=="filter"&&n in t)return qo[e]=n;n=So(n);for(let o=0;o<xr.length;o++){const s=xr[o]+n;if(s in t)return qo[e]=s}return e}function Iu(t,e,i,n){return t.tagName==="TEXTAREA"&&(e==="width"||e==="height")&&ee(n)&&i===n}const _r="http://www.w3.org/1999/xlink";function Sr(t,e,i,n,o,s=Dc(e)){n&&e.startsWith("xlink:")?i==null?t.removeAttributeNS(_r,e.slice(6,e.length)):t.setAttributeNS(_r,e,i):i==null||s&&!ol(i)?t.removeAttribute(e):t.setAttribute(e,s?"":Re(i)?String(i):i)}function Cr(t,e,i,n,o){if(e==="innerHTML"||e==="textContent"){i!=null&&(t[e]=e==="innerHTML"?ia(i):i);return}const s=t.tagName;if(e==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=i==null?t.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in t))&&(t.value=a),i==null&&t.removeAttribute(e),t._value=i;return}let l=!1;if(i===""||i==null){const r=typeof t[e];r==="boolean"?i=ol(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{t[e]=i}catch{}l&&t.removeAttribute(o||e)}function pi(t,e,i,n){t.addEventListener(e,i,n)}function Au(t,e,i,n){t.removeEventListener(e,i,n)}const $r=Symbol("_vei");function Bu(t,e,i,n,o=null){const s=t[$r]||(t[$r]={}),l=s[e];if(n&&l)l.value=n;else{const[r,a]=Mu(e);if(n){const c=s[e]=Ru(n,o);pi(t,r,c,a)}else l&&(Au(t,r,l,a),s[e]=void 0)}}const Tu=/(Once|Passive|Capture)$/,Eu=/^on:?(?:Once|Passive|Capture)$/;function Mu(t){let e,i;for(;(i=t.match(Tu))&&!Eu.test(t);)e||(e={}),t=t.slice(0,t.length-i[1].length),e[i[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):bi(t.slice(2)),e]}let Ko=0;const Du=Promise.resolve(),Lu=()=>Ko||(Du.then(()=>Ko=0),Ko=Date.now());function Ru(t,e){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($t(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Pe(c,e,5,r)}}else Pe(o,e,5,[n])};return i.value=t,i.attached=Lu(),i}const Ir=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Ou=(t,e,i,n,o,s)=>{const l=o==="svg";e==="class"?xu(t,n,l):e==="style"?Cu(t,i,n):wo(e)?xo(e)||Bu(t,e,i,n,s):(e[0]==="."?(e=e.slice(1),!0):e[0]==="^"?(e=e.slice(1),!1):Pu(t,e,n,l))?(Cr(t,e,n),!t.tagName.includes("-")&&(e==="value"||e==="checked"||e==="selected")&&Sr(t,e,n,l,s,e!=="value")):t._isVueCE&&(zu(t,e)||t._def.__asyncLoader&&(/[A-Z]/.test(e)||!ee(n)))?Cr(t,ke(e),n,s,e):(e==="true-value"?t._trueValue=n:e==="false-value"&&(t._falseValue=n),Sr(t,e,n,l))};function Pu(t,e,i,n){if(n)return!!(e==="innerHTML"||e==="textContent"||e in t&&Ir(e)&&Bt(i));if(e==="spellcheck"||e==="draggable"||e==="translate"||e==="autocorrect"||e==="sandbox"&&t.tagName==="IFRAME"||e==="form"||e==="list"&&t.tagName==="INPUT"||e==="type"&&t.tagName==="TEXTAREA")return!1;if(e==="width"||e==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Ir(e)&&ee(i)?!1:e in t}function zu(t,e){const i=t._def.props;if(!i)return!1;const n=ke(e);return Array.isArray(i)?i.some(o=>ke(o)===n):Object.keys(i).some(o=>ke(o)===n)}const Xi=t=>{const e=t.props["onUpdate:modelValue"]||!1;return $t(e)?i=>Yn(e,i):e};function Nu(t){t.target.composing=!0}function Ar(t){const e=t.target;e.composing&&(e.composing=!1,e.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function Br(t,e,i){return e&&(t=t.trim()),i&&(t=Co(t)),t}const yo={created(t,{modifiers:{lazy:e,trim:i,number:n}},o){t[ii]=Xi(o);const s=n||o.props&&o.props.type==="number";pi(t,e?"change":"input",l=>{l.target.composing||t[ii](Br(t.value,i,s))}),(i||s)&&pi(t,"change",()=>{t.value=Br(t.value,i,s)}),e||(pi(t,"compositionstart",Nu),pi(t,"compositionend",Ar),pi(t,"change",Ar))},mounted(t,{value:e}){t.value=e??""},beforeUpdate(t,{value:e,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ii]=Xi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?Co(t.value):t.value,a=e??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&e===i||o&&t.value.trim()===a)||(t.value=a)}},qn={deep:!0,created(t,e,i){t[ii]=Xi(i),pi(t,"change",()=>{const n=t._modelValue,o=Mn(t),s=t.checked,l=t[ii];if($t(n)){const r=Ss(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(tn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(sa(t,s))})},mounted:Tr,beforeUpdate(t,e,i){t[ii]=Xi(i),Tr(t,e,i)}};function Tr(t,{value:e,oldValue:i},n){t._modelValue=e;let o;if($t(e))o=Ss(e,n.props.value)>-1;else if(tn(e))o=e.has(n.props.value);else{if(e===i)return;o=en(e,sa(t,!0))}t.checked!==o&&(t.checked=o)}const Fu={deep:!0,created(t,{value:e,modifiers:{number:i}},n){t._modelValue=e,pi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>i?Co(Mn(s)):Mn(s));t[ii](t.multiple?tn(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,_l(()=>{t._assigning=!1})}),t[ii]=Xi(n)},mounted(t,{value:e}){Er(t,e)},beforeUpdate(t,{value:e},i){t._modelValue=e,t[ii]=Xi(i)},updated(t,{value:e}){t._assigning||Er(t,e)}};function Er(t,e){const i=t.multiple,n=$t(e);if(!(i&&!n&&!tn(e))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Mn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=e.some(c=>String(c)===String(r)):l.selected=Ss(e,r)>-1}else l.selected=e.has(r);else if(en(Mn(l),e)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!i&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Mn(t){return"_value"in t?t._value:t.value}function sa(t,e){const i=e?"_trueValue":"_falseValue";return i in t?t[i]:e}const Hu=["ctrl","shift","alt","meta"],ju={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,e)=>Hu.some(i=>t[`${i}Key`]&&!e.includes(i))},Me=(t,e)=>{if(!t)return t;const i=t._withMods||(t._withMods={}),n=e.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<e.length;l++){const r=ju[e[l]];if(r&&r(o,e))return}return t(o,...s)}))},Uu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Wu=(t,e)=>{const i=t._withKeys||(t._withKeys={}),n=e.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=bi(o.key);if(e.some(l=>l===s||Uu[l]===s))return t(o)}))},Vu=ue({patchProp:Ou},ku);let Mr;function qu(){return Mr||(Mr=Qd(Vu))}const ra=((...t)=>{const e=qu().createApp(...t),{mount:i}=e;return e.mount=n=>{const o=Gu(n);if(!o)return;const s=e._component;!Bt(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,Ku(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},e});function Ku(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Gu(t){return ee(t)?document.querySelector(t):t}const Zu="slidev-config.json",Qi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=Ao({...Qi});function Yu(t){if(!t||typeof t!="object")return{...Qi};const e=t;return{enableWebServeJump:!!e.enableWebServeJump,webServeUrl:typeof e.webServeUrl=="string"&&e.webServeUrl.trim()?e.webServeUrl.trim():Qi.webServeUrl,normalizeHeadingSizes:!!e.normalizeHeadingSizes}}function Ti(t){if(!t||typeof t!="object")return{...hi};const e=t;return e.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!e.enableWebServeJump),e.webServeUrl!==void 0&&(hi.webServeUrl=String(e.webServeUrl)),e.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!e.normalizeHeadingSizes),{...hi}}function Lo(){return{...hi}}function la(t,e,i){const n=(t||Qi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",e),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${e}${l}&r=${s}`}}const _i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Ju(t){var i,n,o,s,l,r;const e=Lo();return t?{theme:((i=t[wn])==null?void 0:i.trim())||_i.theme,aspectRatio:((n=t[xn])==null?void 0:n.trim())||_i.aspectRatio,highlighter:((o=t[Gr])==null?void 0:o.trim())||_i.highlighter,defaultTransition:((s=t[_n])==null?void 0:s.trim())||_i.defaultTransition,colorSchema:((l=t[Zr])==null?void 0:l.trim())||_i.colorSchema,spacing:((r=t[ns])==null?void 0:r.trim())||_i.spacing,normalizeHeadingSizes:e.normalizeHeadingSizes}:{..._i,normalizeHeadingSizes:e.normalizeHeadingSizes}}function ko(t){var i,n,o,s,l;const e=(i=t.ial)==null?void 0:i[Ai];return!!(e&&(e==="true"||e==="page"||e==="cover"||e==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Dr(t){const e={};let i="";if(!t)return{frontmatter:e,notes:i};t[gt]&&(e.layout=t[gt].trim()),t[te]&&(e.transition=t[te].trim()),t[Ut]&&(e.background=t[Ut].trim()),t[Ee]&&(e.image=t[Ee].trim()),t[Wi]&&(e.class=t[Wi].trim()),t[un]&&(e.spacing=t[un].trim()),t[le]&&(e.layoutRatio=t[le].trim()),t[Ui]&&(i=t[Ui].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![gt,le,te,Ut,Ee,Wi,un,Ui,Ai].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{e[s]=JSON.parse(o)}catch{e[s]=o}}return{frontmatter:e,notes:i}}function Xu(t){const e={};if(!t)return e;const i=t[ne]??t["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(e.isNote=!0);const n=t[qt]??t["slidev-role"],o=t[Ut]??t["slidev-background"];(n===Yr||o==="true"||o==="1")&&(e.isBackground=!0);const s=t[gt]??t["slidev-layout"];s===ao||s===co?e.imageLayout=s:(n===ao||n===co)&&(e.imageLayout=n);const l=t[jt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(e.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?e.motion={preset:r.preset||r.type||"fade-in",...r}:e.motion={preset:String(r).trim()}}catch{e.motion={preset:t[Ve].trim()}}return t[Ri]&&(e.shikiLines=t[Ri].trim()),t[Sn]&&(e.maxHeight=t[Sn].trim()),t[Ct]&&(e.slot=t[Ct].trim()),t.style&&t.style.trim()&&(e.style=t.style.trim()),e}function vi(t,e){const i=(t||e||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function vn(t){if(!t)return"";const e=t.split(/\r?\n/);if(e.length===0)return"";const i=e[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(e.length===1)return s;const r=[s];for(let a=1;a<e.length;a++){const c=e[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),h=u?u[1].length:0;h>=l?r.push(c.slice(l)):h>o?r.push(c.slice(h)):r.push(c)}return r.join(`
`)}function Oi(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="i"||e==="nodelistitem"||e==="l"||e==="nodelist")return!0;const i=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Go(t,e=2){if(!t||typeof t!="string")return`repeat(${e}, 1fr)`;const i=t.trim();if(!i)return`repeat(${e}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${e}, 1fr)`}function bn(t){if(!t)return[];if(oe(t)&&Ke(t)&&!ai(t)){const n=nn(t),o=[];for(const s of n)o.push(...bn(s));return o}const e=(t.type||"").toLowerCase();if(e==="l"||e==="nodelist"||e==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Oi);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return Oi(t)?[t]:[]}function Fs(t){var o;if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=nn(t);if(e.length===0)return null;if(e.length===1&&oe(e[0])&&Ke(e[0])){const s=Fs(e[0]);return s?{items:s.items,nestedSuperBlocks:[e[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of e)if(oe(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(oe))||[];i.push(...l)}const n=e.map(bn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(e.length===2){const s=bn(e[0]),l=bn(e[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function Qu(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=Fs(t);if(!e)return null;const{items:i,nestedSuperBlocks:n}=e;if(i.length<2||i.length>6)return null;const o=Hs(t)||void 0,s=i.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function aa(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=nn(t);if(e.length===0)return null;const i=[];for(const n of e){const o=bn(n);if(o.length===0)return null;i.push(...o)}return i}function tf(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=aa(t);return!e||e.length===0||e.length>=2&&e.length<=6?null:{superBlockNode:t,items:e}}function ef(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=Fs(t);if(e&&e.items.length===4)return e.items;const i=aa(t);if(i&&i.length===4)return i;const n=nn(t);return n.length===4?n:null}function nf(t,e){if(!t||t.length===0)return null;const i=[];function n(r,a){if(oe(r)){const c=ef(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<t.length;r++)n(t[r],r);if(i.length===0)return null;let o=null;e&&(o=i.find(r=>{if(r.sbNode.id===e||r.items.some(c=>c.id===e))return!0;const a=c=>c.id===e?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=t.slice(0,o.topLevelIndex).slice().reverse().find(r=>ca(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function of(t,e,i){var u,h,v,d,b;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let m=0;m<e.length;m++){const g=e[m];if(ko(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(m){const g=[];for(const k of m)oe(k)&&g.push(k),k.children&&k.children.length>0&&g.push(...a(k.children));return g}function c(m,g,k){const x={blockId:m,attrs:g,previousAttrs:k};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const m of l){const g=m.pageTargetId,k=e.find(B=>B.id===g),x=s.find(B=>B.pageTargetId===g);if(m.blocks.some(B=>{var w,U;return!!(ai(B)||ms(B)&&(((w=B.ial)==null?void 0:w[gt])==="image-left"||((U=B.ial)==null?void 0:U[gt])==="image-right"))})){if(x){const B=x.headerId;if(B){c(B,{[Ct]:""});const w=e.find(U=>U.id===B);w!=null&&w.ial&&(w.ial[Ct]="")}for(const w of x.itemIds){c(w,{[Ct]:""});const U=e.find(W=>W.id===w);U!=null&&U.ial&&(U.ial[Ct]="")}}continue}let T=null,L=-1;for(let B=0;B<m.blocks.length;B++){const w=m.blocks[B],U=oe(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const W of U){const q=Qu(W);if(q){T=q,L=B;break}}if(T)break}if(T){const{superBlockNode:B,layout:w,items:U,slots:W}=T,X=m.blocks.slice(0,L).find(E=>ca(E)),I=X==null?void 0:X.id,N=((u=k==null?void 0:k.ial)==null?void 0:u[gt])||"",y=N==="clover",D=y?"clover":w;if(N!==D&&(c(g,{[gt]:D},{[gt]:N}),k&&(k.ial||(k.ial={}),k.ial[gt]=D)),X){const E=((h=X.ial)==null?void 0:h[Ct])||"";E!=="header"&&(c(X.id,{[Ct]:"header"},{[Ct]:E}),X.ial||(X.ial={}),X.ial[Ct]="header")}if(x!=null&&x.headerId&&x.headerId!==I){c(x.headerId,{[Ct]:""});const E=e.find(R=>R.id===x.headerId);E&&(E.ial||(E.ial={}),E.ial[Ct]="")}const V=[];for(let E=0;E<U.length;E++){const R=U[E],j=W[E];V.push(R.id);const Q=((v=R.ial)==null?void 0:v[Ct])||"";if(Q!==j&&(c(R.id,{[Ct]:j},{[Ct]:Q}),R.ial||(R.ial={}),R.ial[Ct]=j),R.children&&R.children.length>0)for(const A of R.children)A.ial||(A.ial={}),A.ial[Ct]!==j&&(A.ial[Ct]=j)}if(x!=null&&x.itemIds){for(const E of x.itemIds)if(!V.includes(E)){c(E,{[Ct]:""});const R=e.find(j=>j.id===E);R&&(R.ial||(R.ial={}),R.ial[Ct]="")}}o.push({superBlockId:B.id,nestedSuperBlockIds:(d=T.nestedSuperBlocks)==null?void 0:d.map(E=>E.id),pageTargetId:g,headerId:I,itemIds:V,layout:y?"clover":w})}else{let B=!1;const w=[];for(const q of m.blocks){const X=oe(q)?[q,...a(q.children||[])]:q.children?a(q.children):[];for(const I of X){const N=tf(I);if(N){B=!0;for(const y of N.items)w.push(y.id)}}}const U=((b=k==null?void 0:k.ial)==null?void 0:b[gt])||"",W=Cn(U);if(x||B&&W){c(g,{[gt]:""},{[gt]:U}),k&&(k.ial||(k.ial={}),k.ial[gt]="");const q=x==null?void 0:x.headerId;if(q){c(q,{[Ct]:""});const I=e.find(N=>N.id===q);I&&(I.ial||(I.ial={}),I.ial[Ct]="")}const X=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const I of X){c(I,{[Ct]:""});const N=e.find(y=>y.id===I);N&&(N.ial||(N.ial={}),N.ial[Ct]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const e=(t.type||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"}function Ke(t){if(!oe(t))return!1;const e=(t.subType||"").toLowerCase();if(e==="col"||e==="h"||e==="horizontal")return!0;if(e==="row"||e==="v"||e==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function ms(t){return!t||Oi(t)||oe(t)||!vi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Hs(t){var v;if(!t||!oe(t)||!Ke(t))return null;const e=nn(t);if(!e||e.length<2)return null;const i=[];let n=!1;for(const d of e){const b=(((v=d.ial)==null?void 0:v.style)||d.style||"").trim();let m=null;if(b){const g=b.match(/calc\(\s*([\d.]+)%/i);if(g)m=parseFloat(g[1]);else{const k=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(m=parseFloat(k[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const o=e.length,s=i.reduce((d,b)=>d+(b||0),0),l=i.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const h=c.map(d=>d/u*100);if(h.length===2){const[d]=h;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),m=100-b;return`${b}:${m}`}if(h.length===3){const[d,b,m]=h;if(d>=31&&d<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const g=Math.round(d),k=Math.round(b),x=100-g-k;return`${g}:${k}:${x}`}return h.map(d=>Math.round(d)).join(":")}function ai(t){if(!t||!oe(t)||!Ke(t))return null;const e=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(e.length<2)return null;const i=ms(e[0]),n=ms(e[e.length-1]),o=Hs(t)||void 0;if(i&&!n){const s=vi(e[0].markdown,e[0].content);if(s)return{imageNode:e[0],imageUrl:s,layout:ao,contentNodes:e.slice(1),ratio:o}}if(!i&&n){const s=vi(e[e.length-1].markdown,e[e.length-1].content);if(s)return{imageNode:e[e.length-1],imageUrl:s,layout:co,contentNodes:e.slice(0,e.length-1),ratio:o}}return null}function sf(t,e){const i=[];function n(o){for(const s of o){const l=ai(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[gt];if(u!==a){const v={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[gt]=a,i.push(v),e&&e(v)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),i}function nn(t){return(t.children||[]).filter(e=>{const i=e.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(e.markdown||e.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ca(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="h"||e==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const i=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Si(t,e,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof e=="string"?x.split(/\s+/).includes(e):e.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let h=1,v=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let m;for(;(m=b.exec(t))!==null;)if(m[0].startsWith("</")){if(h--,h===0){v=m.index,d=m.index+m[0].length;break}}else h++;if(v!==-1&&d!==-1){const g=t.slice(u,v);n+=i(g),o=d}else n+=t.slice(a,u),o=u}return n}function rf(t){const e=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=t.slice(n);break}i+=t.slice(n,r);const c=r+a;let u=1,h=-1,v=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(t))!==null;)if(b[0].startsWith("</")){if(u--,u===0){h=b.index,v=b.index+b[0].length;break}}else u++;if(h!==-1&&v!==-1){const m=t.slice(r,v),g=`__VUE_DIV_TOKEN_${e.length}__`;e.push(m),i+=g,n=v}else i+=t.slice(r,c),n=c}return{text:i,tokens:e}}function lf(t){const e=[];let i=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=rf(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Si(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),h=c[3].trim();return`**${u}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:r}),i=Si(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),i=Si(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let h="-";return u.includes("warn")?h="- ⚠️":u.includes("bad")?h="- ❌":u.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Si(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Si(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Si(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Si(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,v)=>Math.max(h,v.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,h)=>{const v=h.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<e.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,e[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function da(t){if(!t||typeof t!="string")return"";const e=[];let i=t.replace(/`([^`]+)`/g,n=>(e.push(n),`%%INLINE_CODE_${e.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>e[parseInt(o,10)]||""),i}function af(t){const e=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return e.length===0?"":`---
${e.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function cf(t,e){if(!e||!t.startsWith("```"))return t;const i=t.indexOf(`
`);if(i===-1)return t;const n=t.slice(0,i).trim(),o=t.slice(i);return n.includes("{")?t:`${n} {${e}}${o}`}function ua(t,e){if(e==null)return t;const i=e.trim();return i===""||i==="+1"?`<v-click>

${t}

</v-click>`:i==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${i}">

${t}

</v-click>`}function df(t){if(!t||!t.preset)return null;const e=t.preset.toLowerCase().trim();if(!e||e==="none")return null;let i={opacity:0},n={opacity:1};switch(e){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(i={...i,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Kn(t,e,i,n){const o=e!=null&&e.trim()!=="",s=df(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const b=e.trim();let m="v-click";return b==="hide"?m="v-click.hide":b!==""&&b!=="+1"&&(m=`v-click="${b}"`),`<div ${m}${a}>

${t}

</div>`}return ua(t,e)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),h=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${h}${a}>

${t}

</div>`;const v=e.trim();let d="v-click";return v==="hide"?d="v-click.hide":v!==""&&v!=="+1"&&(d=`v-click="${v}"`),`<div ${d} ${h}${a}>

${t}

</div>`}function fa(t){if(!t)return"";let e=t.trim();e=e.replace(/\{:[^}]*\}/g,"").trim(),e=e.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),e=e.replace(/\r?\n?:::\s*$/g,"");let o=e.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function uf(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const i=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function pa(t,e=2){const i=Math.max(2,e);if(!t||t.length===0)return Array.from({length:i},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:i},()=>[]),h=Math.min(i,c.length),v=Math.floor(c.length/h),d=c.length%h;let b=0;for(let m=0;m<h;m++){const g=v+(m<d?1:0);u[m]=c.slice(b,b+g),b+=g}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const h=u.match(/^col-(\d+)$/i);if(h){const v=parseInt(h[1],10);if(v>=1&&v<=i)return v}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:i},()=>[]);let b=1;for(const m of t){const g=n(m);g!==null&&(b=g),d[b-1].push(m)}return d}const u=t.filter(d=>n(d)===1),h=t.filter(d=>n(d)===null),v=i-1;if(h.length>=v){const d=Math.floor(h.length/v),b=h.length%v,m=[u];let g=0;for(let k=0;k<v;k++){const x=d+(k<b?1:0);m.push(h.slice(g,g+x)),g+=x}return m}else if(h.length>0){const d=[u];for(let b=0;b<v;b++)d.push(b<h.length?[h[b]]:[]);return d}else return[u,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const h=r[u],v=u+1<i?r[u+1]:t.length;c[u]=t.slice(h,v)}return c}if(t.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let h=0;h<i;h++){const v=i-h,d=t.length-u,b=Math.ceil(d/v);c[h]=t.slice(u,u+b),u+=b}return c}if(t.length>1&&t.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),h=u.split(/\r?\n/),v=[];for(let m=0;m<h.length;m++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(h[m])&&v.push(m);if(v.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,$=v.length-g,T=Math.ceil($/x),L=v[g],B=g+T<v.length?v[g+T]:h.length,w=h.slice(L,B).join(`
`);m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],g+=T}return m}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,$=d.length-g,T=Math.ceil($/x),L=`<ul>
${d.slice(g,g+T).join(`
`)}
</ul>`;m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:L,content:L}],g+=T}return m}const b=u.split(/\r?\n\s*\r?\n/).filter(m=>m.trim()!=="");if(b.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,$=b.length-g,T=Math.ceil($/x),L=b.slice(g,g+T).join(`

`);m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:L,content:L}],g+=T}return m}}const a=Array.from({length:i},()=>[]);return a[0]=t,a}function Lr(t,e,i,n){var u;const o=Ju(e),s=[],l=Dr(e);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),s.push(r);let a=[];for(const h of i){if(ko(h)){a=[];const d=Dr(h.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=h.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(h.id)||r.allBlockIds.push(h.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:h.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[h.id]},r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),s.push(r);continue}const v=(d,b)=>{var V,E,R,j;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const Q=A=>{for(const M of A)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&Q(M.children)};Q(d.children)}let m=wc(d),g=d.ial?{...d.ial}:{};const k=m.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(g={...xc(k[0]),...g},m=m.slice(0,k.index).trim()),d.type!=="c"&&!m.startsWith("```")&&(m=da(m));let x=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(m=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=m.trim());const $=Xu(g);if(m=_c(m,n),m=kc(m,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const Q=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],A=M=>{for(const J of M){if(J.ial)for(const[Y,tt]of Object.entries(J.ial))Q.includes(Y)&&!g[Y]&&(g[Y]=tt);J.children&&J.children.length>0&&A(J.children)}};A(d.children)}const T=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(m);if(T){const Q=g["custom-slidev-autoplay"]==="true",A=g["custom-slidev-loop"]==="true",M=g["custom-slidev-muted"]==="true"||Q,J=g["custom-slidev-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(Y,tt)=>{let et=tt;return J?et=et.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(et)||(et+=" controls"),Q&&!/autoplay/i.test(et)?et+=" autoplay playsinline":!Q&&g["custom-slidev-autoplay"]==="false"&&(et=et.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),A&&!/loop/i.test(et)?et+=" loop":!A&&g["custom-slidev-loop"]==="false"&&(et=et.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(et)?et+=" muted":!M&&g["custom-slidev-muted"]==="false"&&(et=et.replace(/\bmuted\b/gi,"").trim()),`<video ${et.trim()}>`})}if($.isBackground){const Q=vi(m,d.content);if(Q){r.frontmatter.background=Ae(Q,n);return}}const L=ai(d);if(L){r.frontmatter.layout=L.layout,r.frontmatter.image=Ae(L.imageUrl,n),!r.frontmatter.layoutRatio&&L.ratio&&(r.frontmatter.layoutRatio=L.ratio);for(const Q of L.contentNodes)v(Q);return}if($.imageLayout==="image-left"||$.imageLayout==="image-right"){const Q=vi(m,d.content);if(Q){r.frontmatter.layout=$.imageLayout,r.frontmatter.image=Ae(Q,n),!r.frontmatter.layoutRatio&&((V=d.ial)!=null&&V[le])&&(r.frontmatter.layoutRatio=d.ial[le]);return}}if(oe(d)&&d.children&&d.children.length>0){for(const Q of d.children)v(Q);return}const B=!!($.slot||b!=null&&b.defaultSlot||r.frontmatter.layout==="clover"||Cn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(Q=>{var A,M;return((A=Q.ial)==null?void 0:A[Ct])||((M=Q.ial)==null?void 0:M[jt])})||$.slot||$.clicks||B)){for(const Q of d.children)$.slot&&(!Q.ial||!Q.ial[Ct])&&(Q.ial||(Q.ial={}),Q.ial[Ct]=$.slot),v(Q,{...b,parentClicks:$.clicks||(b==null?void 0:b.parentClicks),defaultSlot:$.slot||(b==null?void 0:b.defaultSlot)});return}const w=!!(d.children&&d.children.length>=2)||!!$.clicks||!!((E=d.children)!=null&&E.some(Q=>{var A;return(A=Q.ial)==null?void 0:A[jt]}))||!d.markdown&&!!(d.children&&d.children.length>0);if(Oi(d)&&d.children&&d.children.length>0&&(B||$.clicks||d.children.some(Q=>{var A;return(A=Q.ial)==null?void 0:A[jt]}))&&w){const Q=!!(d.children&&d.children.length>=2),A=d.children.find(lt=>!!(lt.markdown||lt.content||"").trim())||d.children[0],M=((R=A==null?void 0:A.ial)==null?void 0:R[jt])||((j=A==null?void 0:A.ial)==null?void 0:j["custom-slidev-click"]),J=!!(!$.clicks&&Q&&M),Y=$.clicks||(J?M:void 0)||(b==null?void 0:b.parentClicks),tt=d.id||(b==null?void 0:b.parentContainerId),et=$.slot||(b==null?void 0:b.defaultSlot);let pt=!0;for(const lt of d.children){et&&(!lt.ial||!lt.ial[Ct])&&(lt.ial||(lt.ial={}),lt.ial[Ct]=et);const H=!!(lt.markdown||lt.content||"").trim(),at=pt&&H;at&&(lt.markdown&&(lt.markdown=vn(lt.markdown)),lt.content&&(lt.content=vn(lt.content)),pt=!1);let ut=lt;at&&Y&&Q&&(ut={...lt,ial:{...lt.ial||{}}},delete ut.ial[jt],delete ut.ial["custom-slidev-click"]),v(ut,{parentClicks:Y,parentContainerId:tt,defaultSlot:et})}return}if($.isNote){const Q=fa(m);Q&&(r.notes?r.notes+=`

`+Q:r.notes=Q),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:Q||d.content||"",rawMarkdown:m,isNote:!0,attributes:d.ial});return}$.shikiLines&&(m=cf(m,$.shikiLines)),x=m.trim();const U=(d.content||"").trim();if(x==="::right::"||U==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const q=uf(d);let X=$.slot,I=$.clicks,N=$.motion,y={...d.ial||{}};if(q!==null){for(;a.length>0&&a[a.length-1].level>=q;)a.pop();const Q=a.length>0?a[a.length-1]:void 0;!X&&(Q!=null&&Q.slot)&&(X=Q.slot),!I&&(Q!=null&&Q.clicks)&&!(b!=null&&b.parentContainerId)&&(I=Q.clicks),!N&&(Q!=null&&Q.motion)&&(N=Q.motion);const A={...(Q==null?void 0:Q.customAttrs)||{}};if(d.ial)for(const[M,J]of Object.entries(d.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(A[M]=J);b!=null&&b.parentContainerId||a.push({level:q,slot:X,clicks:I,motion:N,customAttrs:A})}else{const Q=a.length>0?a[a.length-1]:void 0;Q&&(!X&&Q.slot&&Q.slot!=="header"&&(X=Q.slot),!I&&Q.clicks&&!(b!=null&&b.parentContainerId)&&(I=Q.clicks),!N&&Q.motion&&(N=Q.motion),Q.customAttrs&&(y={...Q.customAttrs,...y}))}!X&&r.blocks.some(Q=>Q.slot==="slot-divider-right")&&(X="right"),!X&&(b!=null&&b.defaultSlot)&&(X=b.defaultSlot),X&&(y[Ct]=X),I&&!y[jt]&&(y[jt]=I),N&&!y[Ve]&&(y[Ve]=JSON.stringify(N)),(T||g["custom-slidev-autoplay"]||g["custom-slidev-muted"])&&(g["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=g["custom-slidev-autoplay"],g["custom-slidev-autoplay"]==="true"&&!g["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),g["custom-slidev-loop"]&&(y["custom-slidev-loop"]=g["custom-slidev-loop"]),g["custom-slidev-muted"]&&(y["custom-slidev-muted"]=g["custom-slidev-muted"]),g["custom-slidev-controls"]&&(y["custom-slidev-controls"]=g["custom-slidev-controls"]));const D={id:d.id,type:d.type,content:d.content||"",rawMarkdown:m,clicks:I,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:N,shikiLines:$.shikiLines,slot:X,attributes:y,rawNode:d};r.blocks.push(D)};v(h)}for(let h=0;h<s.length;h++){const v=s[h],d=[],b={...v.frontmatter};h===0&&(b.theme=o.theme,b.aspectRatio=o.aspectRatio,b.highlighter=o.highlighter,b.transition=v.frontmatter.transition||o.defaultTransition);const m=af(b);m&&d.push(m);const g=v.blocks.filter(L=>L.slot!=="slot-divider-right"),k=L=>L.filter(B=>!!(B.rawMarkdown||B.content||"").trim()).map(B=>{var w;return Kn(B.rawMarkdown,B.clicks,B.motion,(w=B.attributes)==null?void 0:w.style)}).join(`

`),x=L=>{const B=L.filter(q=>!!(q.rawMarkdown||q.content||"").trim());if(B.length===0)return;const w=B[0],U=(w.rawMarkdown||w.content||"").trim();(Oi(w)||/^(?:[-*+]|\d+\.)\s+/.test(U))&&(w.rawMarkdown=vn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},$=L=>{var q,X;if(L.length===0)return"";x(L);const B=(q=L.find(I=>I.parentClicks))==null?void 0:q.parentClicks;if(!B)return L.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var N;return Kn(I.rawMarkdown,I.clicks,I.motion,(N=I.attributes)==null?void 0:N.style)}).join(`

`);const w=[];let U=[];const W=()=>{if(U.length===0)return;const I=U.map(N=>(N.rawMarkdown||N.content||"").trim()).filter(Boolean).join(`

`);I&&w.push(ua(I,B)),U=[]};for(const I of L){if(!(I.rawMarkdown||I.content||"").trim())continue;!!(I.clicks&&I.clicks.trim()!=="")?(W(),w.push(Kn(I.rawMarkdown,I.clicks,I.motion,(X=I.attributes)==null?void 0:X.style))):U.push(I)}return W(),w.join(`

`)},T=v.frontmatter.layout||"default";if(T==="clover"||Cn(T)){let L=[];const B=g.filter(I=>I.slot==="header");if(B.length>0)L=B;else if(g.length>0){const I=g.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));I&&(L=[I])}const w=g.filter(I=>!L.includes(I));let U=2;if(T==="clover")U=4;else if(T==="three-cols-header")U=3;else if(T==="two-cols-header")U=2;else{let I=0;for(const N of w){const y=(N.slot||"").match(/^col-(\d+)$/i);y&&(I=Math.max(I,parseInt(y[1],10)))}if(I>=2)U=I;else if(v.frontmatter.layoutRatio){const N=v.frontmatter.layoutRatio.trim();if(N.includes(":")){const y=N.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);y.length>=2&&(U=y.length)}else{const y=N.split(/\s+/).filter(Boolean);y.length>=2&&(U=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(U=Math.min(6,w[0].children.length))}const W=pa(w,U);W.forEach((I,N)=>{const y=`col-${N+1}`;for(const D of I)(!D.slot||D.slot==="default")&&(D.slot=y);x(I)});const q=W.flat();if(w.length===1&&q.length>1){const I=v.blocks.findIndex(N=>N.id===w[0].id);I!==-1&&v.blocks.splice(I,1,...q)}const X=k(L);if(X&&d.push(X),T==="two-cols-header"&&U===2){const I=$(W[0]||[]),N=$(W[1]||[]);I&&d.push(`::left::

${I}`),N&&d.push(`::right::

${N}`)}else W.forEach((I,N)=>{const y=$(I);y&&d.push(`::col-${N+1}::

${y}`)})}else if(T==="two-cols"){const L=g.filter(W=>W.slot==="left"),B=g.filter(W=>W.slot==="right");x(L),x(B);const w=k(L.length>0?L:g.filter(W=>W.slot!=="right")),U=k(B);d.push(w),U&&d.push(`::right::

${U}`)}else for(const L of g)d.push(Kn(L.rawMarkdown,L.clicks,L.motion,(u=L.attributes)==null?void 0:u.style));v.notes&&d.push(`<!--
${v.notes}
-->`),v.rawMarkdown=d.join(`

`).trim()}const c=s.map(h=>h.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const gs=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function ff(t){var o,s,l,r,a,c,u,h,v,d,b,m;if(!t||typeof t!="object")return"";const e=[],i=[];if(Array.isArray(t.styles))for(const g of t.styles){if(!g||!g.id)continue;const k=`--b3-inline-style-${g.id}`;(o=g.light)!=null&&o.color&&e.push(`  ${k}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&e.push(`  ${k}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&i.push(`  ${k}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${g.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const g of t.builtin.colors){if(!g||typeof g.index!="number")continue;const k=g.index;(a=g.light)!=null&&a.color&&e.push(`  --b3-font-color${k}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&e.push(`  --b3-font-background${k}: ${g.light.backgroundColor};`),(u=g.dark)!=null&&u.color&&i.push(`  --b3-font-color${k}: ${g.dark.color};`),(h=g.dark)!=null&&h.backgroundColor&&i.push(`  --b3-font-background${k}: ${g.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const g of t.builtin.styles){if(!g||!g.id)continue;const k=g.id;(v=g.light)!=null&&v.color&&e.push(`  --b3-card-${k}-color: ${g.light.color};`),(d=g.light)!=null&&d.backgroundColor&&e.push(`  --b3-card-${k}-background: ${g.light.backgroundColor};`),(b=g.dark)!=null&&b.color&&i.push(`  --b3-card-${k}-color: ${g.dark.color};`),(m=g.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${k}-background: ${g.dark.backgroundColor};`)}if(e.length===0&&i.length===0)return"";const n=[];return e.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${e.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function yn(t){const e=ff(t);return e?`${gs}

/* Custom Workspace Inline Styles */
${e}`:gs}function Zo(t){const e={};if(!t||typeof t!="string")return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}function pf(t){const e=String((t==null?void 0:t.type)||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"||e==="l"||e==="nodelist"||e==="i"||e==="nodelistitem"||e==="b"||e==="nodeblockquote"}function hf(t,e){const i=new Map,n=[];if(!Array.isArray(e)||e.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of e)s!=null&&s.id&&o.set(s.id,s);for(const s of t||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(pf(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function mf(t){const e=String((t==null?void 0:t.type)||"").toLowerCase();return e==="h"||e==="nodeheading"}function vs(t){return oe(t)||t.type==="l"||t.type==="NodeList"||t.type==="i"||t.type==="NodeListItem"||t.type==="b"||t.type==="NodeBlockquote"}function gf(t,e,i,n=8,o){const s=new Map;for(const v of e)v!=null&&v.id&&s.set(v.id,v);const l=v=>({id:v.id,parent_id:v.parent_id,root_id:v.root_id||t,type:v.type,subType:v.subtype??v.subType??"",content:v.content||"",markdown:v.markdown||"",ial:i(v.id,v.ial),children:[]}),r=v=>{let d=v.parent_id,b=0;for(;d&&d!==t&&b++<16;){const m=s.get(d);if(!m||!mf(m))return d;d=m.parent_id}return d||t},a=new Map;for(const v of e){if(!(v!=null&&v.id)||v.id===t||o&&o.size>0&&!o.has(v.id))continue;const d=r(v),b=a.get(d);b?b.push(v):a.set(d,[v])}if(o&&o.size>0)for(const v of a.values())v.sort((d,b)=>(o.get(d.id)??Number.MAX_SAFE_INTEGER)-(o.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(v,d)=>{const b=l(v);if(c.set(b.id,b),d>=n||!vs(b))return b;const m=a.get(b.id);return m&&m.length>0&&(b.children=m.map(g=>u(g,d+1))),b};return{topLevel:(a.get(t)||[]).map(v=>u(v,0)),byId:c}}const vf={getBlockAttrs:ks,getChildBlocks:so,getDocBlocksOrders:vc,setBlockAttrs:Et,sql:kn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:bc};class bf{constructor(e){yt(this,"deps");yt(this,"attrOverrides",new Map);yt(this,"trackedListSuperBlocks",new Map);yt(this,"fallbackWarnedDocId","");this.deps={...vf,...e||{}}}setBlockAttrOverride(e,i){if(!e||!i)return;const o={...this.attrOverrides.get(e)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(e):this.attrOverrides.set(e,o)}getBlockAttrOverride(e){return this.attrOverrides.get(e)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(e){return this.trackedListSuperBlocks.get(e)||[]}clearBlockAttrOverride(e,i){if(!e)return;if(!i){this.attrOverrides.delete(e);return}const n=this.attrOverrides.get(e);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(e))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(e){try{const i=await this.deps.getBlockAttrs(e).catch(()=>({}))||{},n=this.attrOverrides.get(e);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(e).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(e).catch(()=>[])||[]:[],l=new Map;for(let D=0;D<s.length;D++)s[D]&&l.set(s[D],D);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${e}' AND id != '${e}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=hf(o,c),h=new Map;if(Array.isArray(c))for(const D of c)D.id&&D.ial&&h.set(D.id,Zo(D.ial));const v=`SELECT block_id, name, value FROM attributes WHERE root_id = '${e}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(v).catch(()=>[])||[];if(Array.isArray(d)){for(const D of d)if(D.block_id&&D.name){let V=h.get(D.block_id);V||(V={},h.set(D.block_id,V)),V[D.name]=D.value||""}}const b=(D,V)=>{const E={...h.get(D)||(V?Zo(V):{})},R=this.attrOverrides.get(D);return R&&Object.assign(E,R),E},m=Array.isArray(c)&&c.length>0?gf(e,c,b,8,l):null,g=o.map(D=>D.id).filter(Boolean),k=D=>({id:D.id,parent_id:D.parent_id,root_id:D.root_id||e,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:b(D.id,D.ial),children:D.children}),x=async(D,V=0)=>{if(!D||V>8||!vs(D))return;const E=await this.deps.getChildBlocks(D.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){D.children=E.filter(R=>R==null?void 0:R.id).map(R=>({id:R.id,parent_id:D.id,root_id:e,type:R.type,subType:R.subType,content:R.content||"",markdown:R.markdown||"",ial:b(R.id,R.ial),children:[]}));for(const R of D.children)await x(R,V+1)}},$=new Map;for(const D of c)D!=null&&D.id&&$.set(D.id,D);const T=g.every(D=>{const V=$.get(D);return!V||!!V.type});let L=[],B=!1;if(m&&u.usable&&r&&T){this.fallbackWarnedDocId="";for(const[V,E]of u.leafPatch){const R=m.byId.get(V);R&&(R.content=E.content,R.markdown=E.markdown)}const D=new Map;for(const V of o)V!=null&&V.id&&D.set(V.id,V);for(const V of u.rebuildRoots){const E=m.byId.get(V),R=D.get(V);E&&R&&(E.content=R.content||"",E.markdown=R.markdown||""),await x(E)}for(const V of o){if(!(V!=null&&V.id)||m.byId.has(V.id))continue;const E=k(V);await x(E),m.byId.set(E.id,E),m.topLevel.push(E)}L=m.topLevel.filter(V=>l.has(V.id)).sort((V,E)=>(l.get(V.id)??0)-(l.get(E.id)??0))}else g.length>0?(B=!0,this.fallbackWarnedDocId!==e&&(this.fallbackWarnedDocId=e,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${e} 实时顶层=${g.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),L=o.map(D=>k(D))):m&&(L=m.topLevel);const w=async(D,V=0)=>{if(!(!D||D.length===0||V>8))for(const E of D){if(vs(E)&&(!E.children||E.children.length===0)){let j=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!j||j.length===0){const Q=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;j=await this.deps.sql(Q).catch(()=>[])||[]}if(Array.isArray(j)&&j.length>0){const Q=new Set(L.map(M=>M.id)),A=j.filter(M=>M.id!==E.id&&!Q.has(M.id));A.length>0&&(E.children=A.map(M=>{const J=h.get(M.id)||(M.ial?Zo(M.ial):{}),Y=this.attrOverrides.get(M.id);return Y&&Object.assign(J,Y),{id:M.id,parent_id:M.parent_id||E.id,root_id:M.root_id||e,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:J}}))}}E.children&&E.children.length>0&&await w(E.children,V+1)}};B&&await w(L);const U=D=>{var V,E;for(const R of D)if(R.children&&R.children.length>0){U(R.children);for(const j of R.children)if(j.ial)for(const[Q,A]of Object.entries(j.ial))Q.startsWith("custom-slidev-")&&!((V=R.ial)!=null&&V[Q])&&(R.ial||(R.ial={}),R.ial[Q]=A);if(R.ial){for(const[j,Q]of Object.entries(R.ial))if(j.startsWith("custom-slidev-"))for(const A of R.children)(A.type==="video"||A.type==="NodeVideo"||/<video\b/i.test(A.markdown||A.content||""))&&!((E=A.ial)!=null&&E[j])&&(A.ial||(A.ial={}),A.ial[j]=Q)}}};U(L),sf(L,D=>{const V={[gt]:D.layout};this.setBlockAttrOverride(D.blockId,V),(this.deps.setBlockAttrs||Et)(D.blockId,V).catch(R=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",R)})});const W=this.trackedListSuperBlocks.get(e)||[],q=of(e,L,{tracked:W,onTagChange:D=>{this.setBlockAttrOverride(D.blockId,D.attrs),D.blockId===e&&Object.assign(i,D.attrs);const V=R=>{for(const j of R)j.id===D.blockId&&(j.ial||(j.ial={}),Object.assign(j.ial,D.attrs)),j.children&&j.children.length>0&&V(j.children)};V(L),(this.deps.setBlockAttrs||Et)(D.blockId,D.attrs).catch(R=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",R)})}});this.trackedListSuperBlocks.set(e,q.newTracked);const X=new Set;for(const D of L){const V=D.markdown||D.content||"";if(V.includes("((")){const E=yc(V);for(const R of E)X.add(R.blockId)}}const I={};if(X.size>0){const D=Array.from(X).map(E=>`'${E}'`).join(","),V=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${D})`).catch(()=>[])||[];if(Array.isArray(V))for(const E of V)E.id&&(I[E.id]=E.markdown||E.content||"")}const N=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=Lr(e,i,L,{baseUrl:N,refContentMap:I});try{const D=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=yn(D)}catch{y.customThemeCss=yn(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Lr(e,{},[],{});return n.customThemeCss=yn(null),n}}}const Mt=new bf;class js{constructor(e){yt(this,"devServerUrl","http://localhost:3030");yt(this,"isConnected",!1);yt(this,"lastSyncTime",null);e&&(this.devServerUrl=e)}getUrl(){return this.devServerUrl}setUrl(e){this.devServerUrl=e.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(e=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),e),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(e){const i=e.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=e.slides.map((r,a)=>{const c=r.frontmatter||{},u=[],h=a===0;c.layout&&c.layout!=="default"&&u.push(`layout: ${c.layout}`),c.transition&&u.push(`transition: ${c.transition}`),c.background&&u.push(`background: ${c.background}`),c.class&&u.push(`class: "${c.class}"`);let v="";u.length>0?v=h?"":`---
${u.join(`
`)}
---

`:h||(v=`---

`);let d="";if(c.layout==="two-cols"){const m=r.blocks.filter($=>$.slot!=="right"),g=r.blocks.filter($=>$.slot==="right"),k=m.map($=>$.rawMarkdown||$.content||"").join(`

`),x=g.map($=>$.rawMarkdown||$.content||"").join(`

`);d=`${k}

::right::

${x}`}else d=r.blocks.map(m=>m.rawMarkdown||m.content||"").join(`

`);let b="";return r.notes&&r.notes.trim()&&(b=`

<!--
${r.notes.trim()}
-->`),`${v}${d}${b}`}).join(`

`);let l="";return e.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(e,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(e);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(e,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(e),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function yf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Se(t){const e=yf();if(e)try{return e(t)}catch{try{const i=t.startsWith("node:")?t.slice(5):`node:${t}`;return e(i)}catch{}}}function Us(){var e;if(typeof window<"u"&&window.process)return window.process;const t=Se("process");return t&&t.versions?t:typeof process<"u"&&((e=process.versions)!=null&&e.node)?process:globalThis.process}function ha(){var e,i;const t=Us();if(t&&((e=t.versions)!=null&&e.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Se("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function kf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Dn(){const t=Us();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const e=Se("os");if(e&&typeof e.platform=="function")return e.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ma(){var n,o;const t=Us(),e={...(t==null?void 0:t.env)||{}};if(Dn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(e).find(c=>c.toLowerCase()==="path")||"PATH",a=(e[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);e[l]=a.join(";")}return e}function bs(t){var i,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let e="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(e=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),e&&t.startsWith("/data/")){const s=t.slice(6);return`${e}/${s}`.replace(/\\/g,"/")}return t}function wf(){const t=Se("os"),e=Se("path");if(t&&typeof t.tmpdir=="function"){const i=t.tmpdir();return e&&typeof e.join=="function"?e.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Ws{constructor(e){yt(this,"runner");this.runner=e||Ws.defaultRunner}static async defaultRunner(e,i){var n;try{let o=(n=Se("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Dn()==="win32",r=ma();return await new Promise(a=>{o(e,i,{timeout:5e3,shell:l,env:r},(c,u,h)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:h?String(h).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const e=ha(),i=Dn();if(!e)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:e}}}class xf{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pageChangedHandlers",[]);yt(this,"readyHandlers",[]);yt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(e,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:e,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(e){this.postMessage("navigate",{no:e})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(e){return this.pageChangedHandlers.push(e),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==e)}}onReady(e){return this.readyHandlers.push(e),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){const i=e.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class _f{constructor(e){yt(this,"childProcess",null);yt(this,"activePort",null);yt(this,"isRunning",!1);yt(this,"defaultPort");yt(this,"maxPortRetries");yt(this,"probeTimeoutMs");yt(this,"customSpawner");yt(this,"customPortChecker");this.defaultPort=(e==null?void 0:e.defaultPort)||3030,this.maxPortRetries=(e==null?void 0:e.maxPortRetries)||20,this.probeTimeoutMs=(e==null?void 0:e.probeTimeoutMs)||1e4,this.customSpawner=e==null?void 0:e.customSpawner,this.customPortChecker=e==null?void 0:e.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(e){if(this.customPortChecker)return this.customPortChecker(e);try{let i=Se("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(e,"127.0.0.1")}):!0}catch{return!0}}async allocPort(e){const i=e||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(e,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(e,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(e,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Dn()==="win32"?"npx.cmd":"npx",l=bs(e),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let h=(a=Se("child_process"))==null?void 0:a.spawn;if(!h){const b=await import("node:child_process").catch(()=>({}));h=b==null?void 0:b.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=ma();this.childProcess=h(s,r,{cwd:v,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var e;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Dn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(e=Se("child_process"))==null?void 0:e.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Vs{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pendingMessages",[]);yt(this,"slideChangedHandlers",[]);yt(this,"blockClickedHandlers",[]);yt(this,"openInEditorHandlers",[]);yt(this,"clientReadyHandlers",[]);yt(this,"openPeekDrawerHandlers",[]);yt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(e,i){var o;const n={source:"siyuan-slidev-host",action:e,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(e,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:e,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(e){this.postMessage("NAVIGATE_PAGE",{pageIndex:e})}highlightElement(e){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:e})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(e){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:e})}onSlideChanged(e){return this.slideChangedHandlers.push(e),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==e)}}onBlockClicked(e){return this.blockClickedHandlers.push(e),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==e)}}onOpenInEditor(e){return this.openInEditorHandlers.push(e),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==e)}}onOpenPeekDrawer(e){return this.openPeekDrawerHandlers.push(e),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==e)}}onRequestToggleFullscreen(e){return this.toggleFullscreenHandlers.push(e),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==e)}}onClientReady(e){return this.clientReadyHandlers.push(e),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){var n;const i=e.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const ga={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Sf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Cf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,$f=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,If=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Af=`${gs}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Bf(t){var o;const e=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!e.includes(s)&&e.push(s)}return e}class Tf{constructor(e){yt(this,"workspacePath");yt(this,"slidesFileName");yt(this,"cliBridge",new js);const i=wf();!(e!=null&&e.workspacePath)||e.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=e.workspacePath,this.slidesFileName=(e==null?void 0:e.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(e="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return e&&e!=="default"&&(i.dependencies[`@slidev/theme-${e}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(e){return this.cliBridge.buildStandardSlidevMarkdown(e)}async scaffold(e,i){const n=this.buildSlidesMarkdown(e),o=this.generatePackageJson(e.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=bs(s),a=bs(l),c=Bf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const $ of c){const T=ga[$]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${$}
// #endregion snippet
`;u.set($,T)}e.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",Sf),e.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",Cf),e.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="clover"})&&u.set("layouts/clover.vue",$f),u.set("setup/root.ts",If),u.set("styles/index.css",Af);const b=Se("fs"),m=Se("path");let g=!1;const k=m!=null&&m.dirname?m.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(b&&m&&x)try{b.existsSync(k)||b.mkdirSync(k,{recursive:!0}),b.writeFileSync(a,o,"utf-8"),b.writeFileSync(r,n,"utf-8");for(const[$,T]of u.entries()){const L=m.join(k,$),B=m.dirname(L);b.existsSync(B)||b.mkdirSync(B,{recursive:!0}),b.existsSync(L)||b.writeFileSync(L,T,"utf-8")}g=!0}catch{}if(!g&&i)try{const $=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),T=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,T),await i(s,!1,$);for(const[L,B]of u.entries()){const w=`${this.workspacePath}/${L}`,U=typeof Blob<"u"?new Blob([B],{type:"text/plain;charset=utf-8"}):Buffer.from(B,"utf-8");await i(w,!1,U).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch($){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String($)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Ef{constructor(){yt(this,"mode","web-sandbox");yt(this,"webBridge");yt(this,"cliBridge");yt(this,"nativeBridge");yt(this,"processManager");yt(this,"scaffolder");yt(this,"envDetector");this.webBridge=new Vs,this.cliBridge=new js,this.nativeBridge=new xf,this.processManager=new _f,this.scaffolder=new Tf,this.envDetector=new Ws}getMode(){return this.mode}setMode(e){this.mode=e}async startProMode(e,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(e,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Mf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Df={key:0},Lf={key:1},Rf={key:2},Of={key:3},Pf={key:4},zf={key:5},Nf={key:6},Ff={key:7},Hf={key:8},jf={key:9},Uf={key:10},Wf={key:11},Vf={key:12},qf={key:13},Kf={key:14},Gf={key:15},Zf={key:16},Yf={key:17},Jf={key:18},Xf={key:19},Qf={key:20},tp={key:21},ep={key:22},ip={key:23},np={key:24},op={key:25},sp={key:26},rp={key:27},lp={key:28},ap={key:29},cp={key:30},dp={key:31},up={key:32},fp={key:33},pp={key:34},hp={key:35},mp={key:36},gp={key:37},vp={key:38},bp={key:39},yp={key:40},kp={key:41},wp={key:42},xp={key:43},_p={key:44},Sp={key:45},Cp={key:46},$p={key:47},Ip={key:48},Ap={key:49},Bp={key:50},Tp={key:51},Ep={key:52},Mp={key:53},Dp={key:54},Lp={key:55},Rp={key:56},Op={key:57},Pp={key:58},zp={key:59},Np={key:60},Fp={key:61},Hp={key:62},jp={key:63},Up={key:64},Wp={key:65},Vp=Ce({__name:"SlidevIcon",props:{name:{}},setup(t){return(e,i)=>(nt(),st("svg",Mf,[t.name==="fullscreen"||t.name==="maximize"?(nt(),st("g",Df,[...i[0]||(i[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(nt(),st("g",Lf,[...i[1]||(i[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(nt(),st("g",Rf,[...i[2]||(i[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(nt(),st("g",Of,[...i[3]||(i[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(nt(),st("g",Pf,[...i[4]||(i[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(nt(),st("g",zf,[...i[5]||(i[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(nt(),st("g",Nf,[...i[6]||(i[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(nt(),st("g",Ff,[...i[7]||(i[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(nt(),st("g",Hf,[...i[8]||(i[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(nt(),st("g",jf,[...i[9]||(i[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(nt(),st("g",Uf,[...i[10]||(i[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(nt(),st("g",Wf,[...i[11]||(i[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(nt(),st("g",Vf,[...i[12]||(i[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(nt(),st("g",qf,[...i[13]||(i[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(nt(),st("g",Kf,[...i[14]||(i[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(nt(),st("g",Gf,[...i[15]||(i[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(nt(),st("g",Zf,[...i[16]||(i[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(nt(),st("g",Yf,[...i[17]||(i[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(nt(),st("g",Jf,[...i[18]||(i[18]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(nt(),st("g",Xf,[...i[19]||(i[19]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(nt(),st("g",Qf,[...i[20]||(i[20]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(nt(),st("g",tp,[...i[21]||(i[21]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(nt(),st("g",ep,[...i[22]||(i[22]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(nt(),st("g",ip,[...i[23]||(i[23]=[ve('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-240266bc></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-240266bc></path>',5)])])):t.name==="ratio"?(nt(),st("g",np,[...i[24]||(i[24]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(nt(),st("g",op,[...i[25]||(i[25]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(nt(),st("g",sp,[...i[26]||(i[26]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(nt(),st("g",rp,[...i[27]||(i[27]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(nt(),st("g",lp,[...i[28]||(i[28]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(nt(),st("g",ap,[...i[29]||(i[29]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="alert"||t.name==="warning"?(nt(),st("g",cp,[...i[30]||(i[30]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):t.name==="outline"?(nt(),st("g",dp,[...i[31]||(i[31]=[f("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),f("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),f("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(nt(),st("g",up,[...i[32]||(i[32]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(nt(),st("g",fp,[...i[33]||(i[33]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(nt(),st("g",pp,[...i[34]||(i[34]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(nt(),st("g",hp,[...i[35]||(i[35]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(nt(),st("g",mp,[...i[36]||(i[36]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(nt(),st("g",gp,[...i[37]||(i[37]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(nt(),st("g",vp,[...i[38]||(i[38]=[ve('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-240266bc></path><polyline points="14 2 14 8 20 8" data-v-240266bc></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-240266bc></line><line x1="16" y1="17" x2="8" y2="17" data-v-240266bc></line><line x1="10" y1="9" x2="8" y2="9" data-v-240266bc></line>',5)])])):t.name==="focus"||t.name==="target"?(nt(),st("g",bp,[...i[39]||(i[39]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(nt(),st("g",yp,[...i[40]||(i[40]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(nt(),st("g",kp,[...i[41]||(i[41]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-240266bc></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-240266bc></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-240266bc></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-240266bc></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(nt(),st("g",wp,[...i[42]||(i[42]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-240266bc></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-240266bc></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-240266bc></line><line x1="5" y1="15" x2="8" y2="15" data-v-240266bc></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-240266bc></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-240266bc></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-240266bc></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(nt(),st("g",xp,[...i[43]||(i[43]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-240266bc></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-240266bc></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-240266bc></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-240266bc></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-240266bc></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(nt(),st("g",_p,[...i[44]||(i[44]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-240266bc></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-240266bc></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-240266bc></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-240266bc></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-240266bc></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-240266bc></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-240266bc></line>',10)])])):t.name==="layout-clover"||t.name==="clover"?(nt(),st("g",Sp,[...i[45]||(i[45]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7" x2="13" y2="7" data-v-240266bc></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-240266bc></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-240266bc></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-240266bc></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-240266bc></line>',8)])])):t.name==="layout-image-right"||t.name==="image-right"?(nt(),st("g",Cp,[...i[46]||(i[46]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" data-v-240266bc></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-240266bc></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-240266bc></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-240266bc></line><circle cx="15.5" cy="8.5" r="1.2" data-v-240266bc></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-240266bc></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(nt(),st("g",$p,[...i[47]||(i[47]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" data-v-240266bc></line><circle cx="6" cy="8.5" r="1.2" data-v-240266bc></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-240266bc></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-240266bc></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-240266bc></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-240266bc></line>',7)])])):t.name==="layout-center"||t.name==="center"?(nt(),st("g",Ip,[...i[48]||(i[48]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(nt(),st("g",Ap,[...i[49]||(i[49]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><circle cx="8" cy="9" r="1.5" data-v-240266bc></circle><line x1="14" y1="8" x2="9" y2="14" data-v-240266bc></line><circle cx="15" cy="13" r="1.5" data-v-240266bc></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-240266bc></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(nt(),st("g",Bp,[...i[50]||(i[50]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><circle cx="7.5" cy="9.5" r="2" data-v-240266bc></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-240266bc></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-240266bc></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-240266bc></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-240266bc></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(nt(),st("g",Tp,[...i[51]||(i[51]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-240266bc></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-240266bc></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-240266bc></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-240266bc></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(nt(),st("g",Ep,[...i[52]||(i[52]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(nt(),st("g",Mp,[...i[53]||(i[53]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(nt(),st("g",Dp,[...i[54]||(i[54]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(nt(),st("g",Lp,[...i[55]||(i[55]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(nt(),st("g",Rp,[...i[56]||(i[56]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(nt(),st("g",Op,[...i[57]||(i[57]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(nt(),st("g",Pp,[...i[58]||(i[58]=[ve('<line x1="4" y1="21" x2="4" y2="14" data-v-240266bc></line><line x1="4" y1="10" x2="4" y2="3" data-v-240266bc></line><line x1="12" y1="21" x2="12" y2="12" data-v-240266bc></line><line x1="12" y1="8" x2="12" y2="3" data-v-240266bc></line><line x1="20" y1="21" x2="20" y2="16" data-v-240266bc></line><line x1="20" y1="12" x2="20" y2="3" data-v-240266bc></line><line x1="1" y1="14" x2="7" y2="14" data-v-240266bc></line><line x1="9" y1="8" x2="15" y2="8" data-v-240266bc></line><line x1="17" y1="16" x2="23" y2="16" data-v-240266bc></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(nt(),st("g",zp,[...i[59]||(i[59]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(nt(),st("g",Np,[...i[60]||(i[60]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(nt(),st("g",Fp,[...i[61]||(i[61]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(nt(),st("g",Hp,[...i[62]||(i[62]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(nt(),st("g",jp,[...i[63]||(i[63]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-240266bc></rect><line x1="13" y1="8" x2="19" y2="8" data-v-240266bc></line><line x1="13" y1="12" x2="19" y2="12" data-v-240266bc></line><line x1="13" y1="16" x2="17" y2="16" data-v-240266bc></line>',5)])])):t.name==="image-right"?(nt(),st("g",Up,[...i[64]||(i[64]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-240266bc></rect><line x1="5" y1="8" x2="11" y2="8" data-v-240266bc></line><line x1="5" y1="12" x2="11" y2="12" data-v-240266bc></line><line x1="5" y1="16" x2="9" y2="16" data-v-240266bc></line>',5)])])):(nt(),st("g",Wp,[...i[65]||(i[65]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,e)=>{const i=t.__vccOpts||t;for(const[n,o]of e)i[n]=o;return i},ft=ze(Vp,[["__scopeId","data-v-240266bc"]]);function Zt(t,e){var o;if(typeof document>"u"||!t)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(e))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function qp(t){if(typeof document>"u")return;const e=`.protyle-wysiwyg [${gt}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(e);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[gt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(gt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(gt,l):(n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const Kp={class:"spm-layout-picker"},Gp={class:"spm-layout-picker__grid"},Zp=["title","onClick"],Yp={class:"spm-layout-icon"},Jp={class:"spm-layout-label"},Xp=Ce({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=t,n=e,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(nt(),st("div",Kp,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",Gp,[(nt(),st(Kt,null,xe(o,c=>f("div",{key:c.name,class:At(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[f("div",Yp,[dt(ft,{name:"layout-"+c.name},null,8,["name"])]),f("span",Jp,xt(c.label),1)],10,Zp)),64))])]))}}),va=ze(Xp,[["__scopeId","data-v-3d2599ad"]]),Qp={key:0,class:"spm-transition-selector__header"},th={class:"spm-transition-list"},eh=["onClick"],ih={class:"spm-transition-meta"},nh={class:"spm-transition-label"},oh={class:"spm-transition-name"},sh={class:"spm-transition-preview-box"},rh=Ce({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=e,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(nt(),st("div",{class:At(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ot("",!0):(nt(),st("div",Qp,xt(t.title||"转场动效"),1)),f("div",th,[(nt(),st(Kt,null,xe(n,r=>f("div",{key:r.name,class:At(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[f("div",ih,[f("span",nh,xt(r.label),1),f("span",oh,"("+xt(r.name)+")",1)]),f("div",sh,[f("div",{class:At(["spm-anim-cube","anim-"+r.name])},null,2)])],10,eh)),64))])],2))}}),qs=ze(rh,[["__scopeId","data-v-b0aa61ff"]]),lh={class:"spm-divider-popover"},ah={class:"spm-divider-popover__title"},ch={class:"spm-form-item"},dh={class:"spm-popover-footer"},uh={class:"spm-save-hint"},fh=Ce({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:e}){var v,d,b;const i=t,n=e,o=vt(((v=i.initialAttrs)==null?void 0:v[gt])||"default"),s=vt(((d=i.initialAttrs)==null?void 0:d[te])||"slide-left"),l=vt(((b=i.initialAttrs)==null?void 0:b[Ut])||""),r=vt("");Di(()=>i.initialAttrs,m=>{o.value=(m==null?void 0:m[gt])||"default",s.value=(m==null?void 0:m[te])||"slide-left",l.value=(m==null?void 0:m[Ut])||""},{deep:!0});async function a(m,g){if(i.blockId){r.value="正在同步...",Mt.setBlockAttrOverride(i.blockId,{[m]:g}),Zt(i.blockId,{[m]:g});try{await Et(i.blockId,{[m]:g}),r.value="已同步至块属性",n("updated",{[m]:g}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(m){a(gt,m)}function u(m){a(te,m)}function h(){a(Ut,l.value.trim())}return(m,g)=>(nt(),st("div",lh,[f("div",ah,[g[4]||(g[4]=f("span",null,"幻灯片页面设置",-1)),f("button",{class:"spm-close-btn",onClick:g[0]||(g[0]=k=>n("close"))},"✕")]),dt(va,{modelValue:o.value,"onUpdate:modelValue":g[1]||(g[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),dt(qs,{modelValue:s.value,"onUpdate:modelValue":g[2]||(g[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),f("div",ch,[g[5]||(g[5]=f("label",{class:"spm-form-label"},"页面背景",-1)),Te(f("input",{"onUpdate:modelValue":g[3]||(g[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[yo,l.value]])]),f("div",dh,[f("span",uh,xt(r.value),1)])]))}}),ph=ze(fh,[["__scopeId","data-v-e4871368"]]),hh={class:"spm-slide-inspector"},mh={class:"spm-inspector-header"},gh={class:"spm-inspector-list"},vh=["onClick"],bh={class:"spm-card-top"},yh={class:"spm-card-badge"},kh={class:"spm-card-layout"},wh=["onClick"],xh={class:"spm-card-preview"},_h={key:0,class:"spm-card-notes",title:"演讲备忘录"},Sh={class:"spm-inspector-modal-content"},Ch=Ce({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:e}){const i=e,n=vt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[gt]=c.frontmatter.layout),c.frontmatter.transition&&(u[te]=c.frontmatter.transition),c.frontmatter.background&&(u[Ut]=c.frontmatter.background),c.notes&&(u[Ui]=c.notes),u}function l(c){n.value&&(c[gt]&&(n.value.frontmatter.layout=c[gt]),c[te]&&(n.value.frontmatter.transition=c[te]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Ui]&&(n.value.notes=c[Ui]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],h=u.content||u.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,u)=>(nt(),st("div",hh,[f("div",mh,[f("span",null,"幻灯片大纲 ("+xt(t.slides.length)+" 页)",1)]),f("div",gh,[(nt(!0),st(Kt,null,xe(t.slides,h=>(nt(),st("div",{key:h.pageIndex,class:At(["spm-card",{active:t.currentActivePage===h.pageIndex}]),onClick:v=>r(h.pageIndex)},[f("div",bh,[f("span",yh,"P"+xt(h.pageIndex),1),f("span",kh,xt(h.frontmatter.layout||"default"),1),f("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(v=>o(h),["stop"])},[dt(ft,{name:"settings"})],8,wh)]),f("div",xh,xt(a(h)),1),h.notes?(nt(),st("div",_h,[dt(ft,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),f("span",null,xt(h.notes),1)])):Ot("",!0)],10,vh))),128))]),n.value?(nt(),st("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(h=>n.value=null,["self"]))},[f("div",Sh,[dt(ph,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=h=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ot("",!0)]))}}),$h=ze(Ch,[["__scopeId","data-v-68b25edd"]]),Ih={class:"spm-immersion-header"},Ah={class:"spm-immersion-header__left"},Bh={class:"spm-immersion-title"},Th={class:"spm-immersion-header__center"},Eh={class:"spm-immersion-header__actions"},Mh=["aria-label"],Dh={class:"spm-immersion-body"},Lh=Ce({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:e}){const i=t,n=e;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((nt(),st("div",{class:At(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:s}),f("div",{class:At(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[f("div",Ih,[f("div",Ah,[Vn(a.$slots,"header-left",{},()=>[f("span",Bh,xt(t.title),1)])]),f("div",Th,[Vn(a.$slots,"header-center",{},void 0)]),f("div",Eh,[Vn(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[dt(ft,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Mh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[dt(ft,{name:"close"})])])]),f("div",Dh,[Vn(a.$slots,"default",{},void 0)])],2)],34)),[[oa,t.visible]])}}),Rh=ze(Lh,[["__scopeId","data-v-3f1665db"]]),Oh={class:"spm-protyle-drawer"},Ph={class:"spm-protyle-drawer__subbar"},zh={class:"spm-protyle-drawer__nav"},Nh=["title"],Fh={class:"spm-protyle-drawer__actions"},Hh=["aria-label"],jh=["aria-label"],Uh=Ce({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(n.blockId),s=vt(n.title||""),l=vt(!1),r=vt(!0),a=vt(!1),c=vt(""),u=hi,h=vt([]),v=vt(null);let d=null;Di(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",h.value=[],m(w))}),On(()=>{o.value&&m(o.value)}),Ls(()=>{g()});async function b(w){try{const U=await kn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(U)&&U.length>0){const W=U[0];c.value=W.root_id||"";const q=W.id===W.root_id||W.type==="d";a.value=q,r.value=!q,!s.value&&W.content&&(s.value=W.content.trim().slice(0,30));return}}catch(U){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",U)}a.value=!1,r.value=!0}async function m(w,U){if(!v.value||!w)return;g(),await b(w),typeof U=="boolean"&&(r.value=!a.value&&U);let W,q;r.value&&!a.value?(W=["cb-get-all","cb-get-hl","cb-get-focus"],q={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(W=["cb-get-context","cb-get-hl"],q={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ht.Protyle(n.plugin.app,v.value,{blockId:w,action:W,render:q}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function g(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}v.value&&(v.value.innerHTML="")}function k(){a.value||(r.value=!r.value,m(o.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function $(){if(o.value)try{ht.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function T(){var W;if(!o.value)return;const w=Lo(),U=la(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const q=Se("electron");(W=q==null?void 0:q.shell)!=null&&W.openExternal?q.shell.openExternal(U).catch(()=>{window.open(U,"_blank")}):window.open(U,"_blank")}i("external-jump",U)}function L(){if(h.value.length>0){const w=h.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,m(w.blockId,w.isFocusMode))}}function B(w){const U=w.target;if(!U)return;const W=U.closest('[data-type="block-ref"]');if(W){const X=W.getAttribute("data-id");if(X&&X!==o.value){w.preventDefault(),w.stopPropagation(),h.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=X,s.value=W.innerText.trim()||X,m(X);return}}const q=U.closest("a");if(q&&q.href&&q.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const X=q.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==o.value&&(h.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=X,s.value=q.innerText.trim()||X,m(X))}}return(w,U)=>(nt(),st("div",Oh,[f("div",Ph,[f("div",zh,[h.value.length>0?(nt(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:L},[dt(ft,{name:"arrow-left"}),U[0]||(U[0]=f("span",null,"返回",-1))])):Ot("",!0),f("span",{class:At(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xt(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:s.value||o.value},xt(s.value||o.value),9,Nh)]),f("div",Fh,[a.value?Ot("",!0):(nt(),st("button",{key:0,class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[dt(ft,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,xt(r.value?"块聚焦":"展开全文"),1)],10,Hh)),f("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[dt(ft,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,xt(l.value?"编辑中":"只读"),1)],10,jh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:$},[dt(ft,{name:"window"}),U[1]||(U[1]=f("span",null,"独立窗口",-1))]),bt(u).enableWebServeJump?(nt(),st("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[dt(ft,{name:"external-link"}),U[2]||(U[2]=f("span",null,"外跳",-1))])):Ot("",!0)])]),f("div",{ref_key:"mountEl",ref:v,class:At(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:B},null,2)]))}}),Wh=ze(Uh,[["__scopeId","data-v-7e586ef3"]]),Vh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,qh=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Rr(t){let e=t||"";try{e=decodeURIComponent(e)}catch{}e=e.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(e);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(e);return n?`/plugins/${n[1]}`:null}function ba(t){const e=(t||"").replace(/^file:\/\//i,"");let i=e;try{i=decodeURIComponent(e)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function Kh(t){const e=t.split(/[/?#]/)[0];return!e||qh.test(e)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(e)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(e)}function Gh(t){const e=t.indexOf("#"),i=e>=0?t.slice(e):"",n=e>=0?t.slice(0,e):t,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return t;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?t:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function ya(t){const e=Zh(t);return e.external||!e.url?e:{url:Gh(e.url),external:!1}}function Zh(t){const e=(t||"").trim();if(!e)return{url:"",external:!1};if(/^https?:\/\//i.test(e))return{url:e,external:!1};if(e.startsWith("//"))return{url:`https:${e}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(e))return{url:e,external:!1};if(Jr(e))return{url:`/${Xr(e)}`,external:!1};if(/^file:/i.test(e)){const n=Rr(ba(e));return n?{url:n,external:!1}:{url:e,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(e)||e.startsWith("\\\\")){const n=Rr(e);return n?{url:n,external:!1}:{url:e,external:!0}}return Vh.test(e)?{url:e,external:!0}:Kh(e)?{url:`https://${e}`,external:!1}:{url:`/${e.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Yh={class:"spm-webview-drawer"},Jh={class:"spm-webview-toolbar"},Xh={class:"spm-webview-toolbar__nav"},Qh=["disabled"],tm=["disabled"],em=["aria-label"],im={class:"spm-webview-toolbar__address"},nm=["aria-label"],om={class:"spm-webview-toolbar__actions"},sm=["aria-label"],rm={class:"spm-zoom-controller"},lm=["disabled"],am=["disabled"],cm={key:1,class:"spm-webview-fallback"},dm=["src"],um={key:2,class:"spm-load-error"},fm={class:"spm-load-error__code"},pm={class:"spm-load-error__code-num"},hm={class:"spm-load-error__url"},mm={class:"spm-load-error__hint"},gm={class:"spm-load-error__actions"},Or="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ka="siyuan-slidev-peek-view-mode";let wa="desktop";function vm(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ka);if(t==="mobile"||t==="desktop")return t}catch{}return wa}function bm(t){if(wa=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ka,t)}catch{}}function ym(t){switch((t||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const km=Ce({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(ha()&&!kf()),s=vt(n.url),l=vt(n.url),r=vt(!1),a=vt(null),c=vt(!1),u=vt(!1),h=vt(1),v=vt(!1),d=vt(vm());let b=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const m=St(()=>d.value==="mobile"?Or:b||void 0),g=vt(null),k=vt(null);let x=null,$=null,T=null;Di(()=>n.url,H=>{H&&H!==s.value&&(s.value=H,l.value=H,d.value==="mobile"&&W(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(H))}),Di(()=>n.visible,H=>{if(H)M(),d.value==="mobile"&&W(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),On(()=>{L(),k.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const H=g.value;if(H&&typeof H.invalidate=="function")try{H.invalidate()}catch{}}),x.observe(k.value)),$=H=>{var ut;const at=H.message||((ut=H.error)==null?void 0:ut.message);if(typeof at=="string"&&at.includes("Invalid guestInstanceId"))return H.preventDefault(),H.stopImmediatePropagation(),!0},window.addEventListener("error",$,!0),T=H=>{const at=H.reason,ut=typeof at=="string"?at:at==null?void 0:at.message;typeof ut=="string"&&ut.includes("Invalid guestInstanceId")&&H.preventDefault()},window.addEventListener("unhandledrejection",T)}),Ls(()=>{if(B(),x&&(x.disconnect(),x=null),$&&(window.removeEventListener("error",$,!0),$=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function L(){const H=g.value;H&&(H.addEventListener("dom-ready",w),H.addEventListener("did-start-loading",q),H.addEventListener("did-stop-loading",N),H.addEventListener("did-navigate",y),H.addEventListener("did-navigate-in-page",D),H.addEventListener("new-window",V),H.addEventListener("did-fail-load",X),H.addEventListener("did-fail-provisional-load",X))}function B(){const H=g.value;if(H)try{H.removeEventListener("dom-ready",w),H.removeEventListener("did-start-loading",q),H.removeEventListener("did-stop-loading",N),H.removeEventListener("did-navigate",y),H.removeEventListener("did-navigate-in-page",D),H.removeEventListener("new-window",V),H.removeEventListener("did-fail-load",X),H.removeEventListener("did-fail-provisional-load",X)}catch{}}function w(){const H=g.value;if(H&&typeof H.getUserAgent=="function"&&!b)try{const at=H.getUserAgent();at&&!at.includes("iPhone")&&(b=at)}catch{}d.value==="mobile"&&W(!1),M(),E()}function U(){const H=d.value==="mobile"?"desktop":"mobile";d.value=H,bm(H),W(!0)}function W(H=!1){const at=g.value;if(!at)return;const ut=d.value==="mobile"?Or:b;if(typeof at.setUserAgent=="function"&&ut)try{at.setUserAgent(ut)}catch(S){console.warn("[WebviewPeekDrawer] setUserAgent error:",S)}if(H&&typeof at.reload=="function")try{at.reload()}catch(S){console.warn("[WebviewPeekDrawer] reload error:",S)}}function q(){r.value=!0,a.value=null}function X(H){if(H&&H.isMainFrame===!1||H&&Number(H.errorCode)===-3)return;const at=String((H==null?void 0:H.errorDescription)||"ERR_FAILED");a.value={errorCode:Number((H==null?void 0:H.errorCode)??0),description:at,validatedURL:String((H==null?void 0:H.validatedURL)||s.value),hint:ym(at)},r.value=!1}function I(){a.value=null,Q()}function N(){if(r.value=!1,E(),g.value&&typeof g.value.getURL=="function"){const H=g.value.getURL();H&&H!=="about:blank"&&(s.value=H,l.value=H)}}function y(H){H!=null&&H.url&&(s.value=H.url,l.value=H.url),E()}function D(H){H!=null&&H.url&&(s.value=H.url,l.value=H.url),E()}function V(H){H&&H.url&&(H.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(H.url))}function E(){const H=g.value;H&&(typeof H.canGoBack=="function"&&(c.value=H.canGoBack()),typeof H.canGoForward=="function"&&(u.value=H.canGoForward()))}function R(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function j(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function Q(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function A(){const H=ya(l.value);if(H.url){if(H.external){s.value=H.url,lt();return}s.value=H.url,l.value=H.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(H.url)}}function M(){const H=g.value;if(H&&typeof H.setZoomFactor=="function")try{H.setZoomFactor(h.value)}catch(at){console.warn("[WebviewPeekDrawer] setZoomFactor error:",at)}}function J(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),M()}function Y(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),M()}function tt(){h.value=1,M()}function et(H){H.preventDefault(),H.deltaY<0?J():H.deltaY>0&&Y()}async function pt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),v.value=!0,setTimeout(()=>{v.value=!1},2e3)}catch(H){console.warn("Copy url failed:",H)}}function lt(){var at;const H=s.value;if(typeof window<"u"){const ut=Se("electron");(at=ut==null?void 0:ut.shell)!=null&&at.openExternal?ut.shell.openExternal(H).catch(()=>{window.open(H,"_blank")}):window.open(H,"_blank")}i("external-jump",H)}return(H,at)=>{const ut=Bd("webview");return nt(),st("div",Yh,[f("div",Jh,[f("div",Xh,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"后退",onClick:R},[dt(ft,{name:"arrow-left"})],8,Qh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"前进",onClick:j},[dt(ft,{name:"arrow-right"})],8,tm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:Q},[dt(ft,{name:"refresh"})],8,em)]),f("div",im,[Te(f("input",{"onUpdate:modelValue":at[0]||(at[0]=S=>l.value=S),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Wu(A,["enter"])},null,544),[[yo,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":v.value?"已复制地址！":"复制网址",onClick:pt},[dt(ft,{name:"copy"})],8,nm)]),f("div",om,[f("button",{class:At(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":d.value==="mobile"}]),"aria-label":d.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:U},[dt(ft,{name:d.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,sm),f("div",rm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:Y},[dt(ft,{name:"minus"})],8,lm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:tt},xt(Math.round(h.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:J},[dt(ft,{name:"plus"})],8,am)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:lt},[dt(ft,{name:"external-link"}),at[1]||(at[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:k,class:At(["spm-webview-body",{"is-mobile":d.value==="mobile"}]),onWheel:Me(et,["ctrl"])},[f("div",{class:At(["spm-webview-viewport",{"is-mobile":d.value==="mobile"}])},[o.value?(nt(),De(ut,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:s.value,useragent:m.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(nt(),st("div",cm,[f("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,dm),f("div",{class:"spm-fallback-bar"},[at[2]||(at[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:lt}," 在新标签页中打开 ↗ ")])])),a.value?(nt(),st("div",um,[dt(ft,{name:"alert",class:"spm-load-error__icon"}),at[5]||(at[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",fm,[$e(xt(a.value.description)+" ",1),f("span",pm,"("+xt(a.value.errorCode)+")",1)]),f("div",hm,xt(a.value.validatedURL),1),f("p",mm,xt(a.value.hint),1),f("div",gm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:I},[dt(ft,{name:"refresh"}),at[3]||(at[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:lt},[dt(ft,{name:"external-link"}),at[4]||(at[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Ot("",!0)],2)],34)])}}}),wm=ze(km,[["__scopeId","data-v-13be9dce"]]);class xm{constructor(){yt(this,"timers",new Map)}debounce(e,i,n=150){this.cancel(e);const o=setTimeout(()=>{this.timers.delete(e),i()},n);this.timers.set(e,o)}cancel(e){this.timers.has(e)&&(clearTimeout(this.timers.get(e)),this.timers.delete(e))}cancelAll(){for(const e of this.timers.values())clearTimeout(e);this.timers.clear()}hasPending(e){return this.timers.has(e)}}class _m{constructor(e){yt(this,"blockToPageMap",new Map);yt(this,"debounceCtrl",new xm);yt(this,"activeBlockId","");yt(this,"activePageIndex",1);yt(this,"currentDocId","");yt(this,"bridge",null);e&&(this.bridge=e)}setBridge(e){this.bridge=e}setDocId(e){this.currentDocId=e}updateSlidesIndex(e){this.blockToPageMap.clear();for(const i of e){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(e){return this.blockToPageMap.get(e)??null}onCursorFocusBlock(e){if(!e||e===this.activeBlockId)return;this.activeBlockId=e;let i=this.getPageByBlockId(e);!i&&(e===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(e))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(e){this.activeBlockId=e;const i=this.getPageByBlockId(e);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Li(t,e){var s,l;if(!t||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(e)try{return ht.openTab({app:e,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Sm(t){if(!t)return"";const e=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(e.length===0)return"";if(!e.some(l=>/^#{1,6}\s+/.test(l)))return e.map(l=>re(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>re(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of e){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${re(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Cm(t){if(t.length===0)return"";const e=[],i=t[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();e.push(`<h${o} class="slide-list-item-title">${re(s)}</h${o}>`)}else e.push(`<p class="slide-list-item-title">${re(i)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>re(a)).join("<br/>");e.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();e.push(`<h${c} class="slide-list-item-title">${re(u)}</h${c}>`)}else s.push(r)}l()}return e.join(`
`)+(e.length>0?`
`:"")}function xa(t,e,i){var v,d,b,m;const n=t.split(`
`);if(!n.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return null;const s=[],l=[];let r=!1;for(let g=0;g<n.length;g++){const k=n[g];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const B=x[1].length,w=Math.floor(B/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const $=k.match(/^(\s*)[-*+]\s+(.*)$/);if($){const B=$[1].length,w=Math.floor(B/2);l.push({type:"unordered",level:w,text:$[2],media:[]});continue}const T=k.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(r=!0);const B=T[1].length,w=Math.floor(B/2);l.push({type:"ordered",level:w,text:T[2],media:[]});continue}const L=k.trim();if(!(!L||/^\{:.*?\}$/.test(L)))if(l.length>0){const B=L.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(B){const W=/\.gif(?:\?|$)/i.test(B[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(B[1])}" src="${B[2]}" class="${W}" /></div>`);continue}if(L.match(/^<img\b[\s\S]*?\/?>$/i)){const U=L.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${U}</div>`);continue}if(/<video\b/i.test(L)){let U=L;if(!/<\/video>/i.test(U))for(;g+1<n.length&&!/<\/video>/i.test(U);)g++,U+=" "+n[g].trim();const W=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(U),q=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(U),X=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||W||/muted/i.test(U),I=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-controls"])==="false",N=U.match(/\bsrc=["']([^"']+)["']/i),y=N?N[1]:"",D=['class="slide-video-player"'];I||D.push("controls"),W&&(D.push("autoplay"),D.push("playsinline")),q&&D.push("loop"),X&&D.push("muted"),D.push('preload="metadata"'),y&&D.push(`src="${y}"`);const V=U.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=V?V[1].trim():"";!E&&y&&(E=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${W?"true":"false"}" data-muted="${X?"true":"false"}"><video ${D.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+L}else s.push(L)}if(l.length===0)return null;const a=r?"ol":"ul",c=(e==null?void 0:e.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(g=>{const k=Sm(g.text),x=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",$=g.level||0,T=$>0?` style="margin-left:${($*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${$%2===1?"circle":"square"} !important;`:""}"`:"",L=$>0?" slide-list-item--nested":"";if(g.type==="task"){const w=g.checked?' checked=""':"";return`<li class="pdf-task-item${L}"${T}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${L?` class="${L.trim()}"`:""}${T}>${k}${x}</li>`}).join(`
`);return`${Cm(s)}<${a} class="${c}">
${u}
</${a}>`}function $m(t,e,i){const n=(e==null?void 0:e.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const u=o[c],h=u.trim();if(/^#{1,6}\s+/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(!h){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(/<video\b/i.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]);let v=h;if(!/<\/video>/i.test(v))for(;c+1<o.length&&!/<\/video>/i.test(v);)c++,v+=`
`+o[c];s.push(v);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,m,g,k;const u=c.trim();if(!u)return"";const h=u.match(/^(#{1,6})\s+(.*)$/);if(h){r=!1;const x=h[1].length;return`<h${x} class="slide-list-item-title">${re(h[2].trim())}</h${x}>`}const v=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(v){const x=/\.gif(?:\?|$)/i.test(v[2]),$=(e==null?void 0:e.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(v[1])}" src="${v[2]}" class="${$}" /></div>`}if(/<video\b/i.test(u)){const x=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),$=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-loop"])==="true"||/loop/i.test(u),T=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-muted"])==="true"||x||/muted/i.test(u),L=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",B=u.match(/\bsrc=["']([^"']+)["']/i),w=B?B[1]:"",U=['class="slide-video-player"'];L||U.push("controls"),x&&U.push("autoplay playsinline"),$&&U.push("loop"),T&&U.push("muted"),U.push('preload="metadata"'),w&&U.push(`src="${w}"`);const W=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let q=W?W[1].trim():"";return!q&&w&&(q=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${T?"true":"false"}"><video ${U.join(" ")}>${q}</video></div>`}const d=xa(u,e,i);if(d)return r=!1,d;if(r){r=!1;const x=u.split(/\r?\n/).map(B=>B.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${re(x[0])}</p>`;const $=x[0],L=x.slice(1).map(B=>re(B)).join("<br/>");return`<p class="slide-list-item-title">${re($)}</p>
<p class="slide-list-item-desc">${L}</p>`}return`<p class="slide-list-item-desc">${re(u)}</p>`}).filter(Boolean).join(`
`)}function Yo(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const e=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(e)}function Im(t,e){var r,a,c,u,h,v,d,b;const i=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(Yo);if(i==="two-cols"){const m=o.some(X=>X.slot==="right");let g=[],k=[];if(m)g=o.filter(X=>X.slot!=="right"),k=o.filter(X=>X.slot==="right");else{const X=Math.ceil(o.length/2);g=o.slice(0,X),k=o.slice(X)}const x=X=>{const I=X.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(I.length>0){const N=I[0],y=(N.rawMarkdown||N.content||"").trim();(Oi(N)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(N.rawMarkdown=vn(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}};x(g),x(k);const $=g.map(X=>ui(X,e)).join(`
`),T=k.map(X=>ui(X,e)).join(`
`),L="pdf-two-cols-wrapper layout-two-cols-grid",B=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",U="pdf-col pdf-col--right",q=`style="grid-template-columns: ${Go((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${L}${B}" ${q}>
        <div class="${w}">${$}</div>
        <div class="${U}">${T}</div>
      </div>
    `}if(i==="clover"||Cn(i)){const m=i==="clover";let g=[];const k=o.filter(D=>D.slot==="header");if(k.length>0)g=k;else if(o.length>0){const D=o.find(V=>V.type==="h"&&(!V.slot||V.slot==="default"));D&&(g=[D])}const x=o.filter(D=>!g.includes(D));let $=2;if(m)$=4;else if(i==="three-cols-header")$=3;else if(i==="two-cols-header")$=2;else{let D=0;for(const V of x){const E=(V.slot||"").match(/^col-(\d+)$/i);E&&(D=Math.max(D,parseInt(E[1],10)))}if(D>=2)$=D;else if((u=t.frontmatter)!=null&&u.layoutRatio){const V=t.frontmatter.layoutRatio.trim();if(V.includes(":")){const E=V.split(":").map(R=>parseFloat(R.trim())).filter(R=>!isNaN(R)&&R>0);E.length>=2&&($=E.length)}else{const E=V.split(/\s+/).filter(Boolean);E.length>=2&&($=E.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&($=Math.min(6,x[0].children.length))}const T=pa(x,$),L=x.some(D=>D.slot&&/^(?:col-\d+|left|right)$/i.test(D.slot)),B=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Cn(i)&&L,w=D=>{const V=D.filter(R=>!!(R.rawMarkdown||R.content||"").trim());if(B&&V.length>0){const R=V[0],j=(R.rawMarkdown||R.content||"").trim();(Oi(R)||/^(?:[-*+]|\d+\.)\s+/.test(j))&&(R.rawMarkdown=vn(R.rawMarkdown||R.content||""),R.content=R.rawMarkdown),R.isColFirst=!0}const E=B?V.find(Yo):null;return V.map(R=>ui(R,{...e,extraClassName:R===E?"slidev-col-first-heading-block":""})).join(`
`)},U=g.find(Yo),W=g.map(D=>ui(D,{...e,extraClassName:D===U?"slidev-page-first-heading-block":""})).join(`
`),q=m?"repeat(2, minmax(0, 1fr))":Go((h=t.frontmatter)==null?void 0:h.layoutRatio,$),X=m?`style="grid-template-columns: ${q}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${q};"`,I=[m?"layout-clover-container":"layout-cols-header-container",$===2?"layout-two-cols-header-container":"",$===3?"layout-three-cols-header-container":"",`layout-${i}-container`,B?"has-superblock-cols":""].filter(Boolean).join(" "),N=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",$===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",$===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",B?"has-superblock-cols":""].filter(Boolean).join(" "),y=T.map((D,V)=>{const E=V+1;return`<div class="${["pdf-col",$===2&&E===1?"pdf-col--left":"",$===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(D)}</div>`}).join(`
`);return`
      <div class="${I}">
        <div class="layout-header-section">${W}</div>
        <div class="${N}" ${X}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",g=o.map(B=>ui(B,e)).join(`
`),k=((v=t.frontmatter)==null?void 0:v.image)||((d=t.frontmatter)==null?void 0:d.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,$=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,T=m?`${$}
${x}`:`${x}
${$}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Go((b=t.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${T}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(g=>ui(g,e)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(g=>ui(g,e)).join(`
`)}</div>`:o.map(m=>ui(m,{...e,extraClassName:m===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Am(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const e=new Set,i=t.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)e.add(c)}else{const s=parseInt(o,10);isNaN(s)||e.add(s)}}return e}const Bm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function re(t){if(!t)return"";const e=da(t),i=[],n=e.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Bm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ce(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,h)=>{const d=(r??a??c??u??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Tm(t,e="pdf-table"){if(t.length<2)return"";const i=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;t.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${re(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${re(c)}</td>`).join("")}</tr>`).join("");return`<table class="${e}">${l}<tbody>${r}</tbody></table>`}function Jo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Pr(t,e="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Jo(t)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${Jo(l)}</span>`),`__TOK_${i.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Jo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function Em(t,e){if(!t)return null;const i=t.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||e,title:n,level:o}):null}function Mm(t,e=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const h=Em(c,u+1);h&&s.push(h)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===e,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const h=[];for(const v of c){const d=a(v.children,u+1);u>=n?h.push({...v,children:d}):h.push(...d)}return h}return a(l,1)}function Dm(t,e=1,i={}){const n=Mm(t,e,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${u}`,v=c.map(d=>{const b=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let g=re(d.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${g}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${h}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function ui(t,e){var $,T,L,B,w,U,W,q,X,I;let i="",n="",o="";const s=[];($=t.motion)!=null&&$.preset&&t.motion.preset!=="none"&&(i=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((T=t.attributes)==null?void 0:T.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ce(s.join(";"))}"`);const r=(e==null?void 0:e.containerClassName)||"pdf-block",a=e!=null&&e.extraClassName?` ${e.extraClassName}`:"",c=`${r}${i}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const N=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(N)}</em></div></div>`}const h=u.match(/^(#{1,6})\s+(.*)$/);if(h){const N=h[1].length,y=re(h[2]),V=!!(t.isColFirst||t.type==="i"&&((L=e==null?void 0:e.extraClassName)!=null&&L.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${N}${V}>${y}</h${N}></div>`}if(u.startsWith(":::")){const N=u.split(`
`),D=N[0].replace(/^:::\s*/,"").trim()||"info",V=N.slice(1,N[N.length-1].startsWith(":::")?-1:void 0).join(`
`),E=(e==null?void 0:e.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${E} ${E}--${D}"><div class="${E}-title">${D.toUpperCase()}</div><div class="${E}-body">${re(V)}</div></div></div>`}if(u.startsWith("<<<")){const D=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((j,Q)=>`<span class="code-line shiki-focus"><span class="line-no">${Q+1}</span><span class="line-content">${Pr(j,"ts")}</span></span>`).join(`
`),V=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",E=((B=t.attrs)==null?void 0:B["custom-slidev-max-height"])||t.maxHeight||"",R=E?` style="max-height:${ce(E)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${V}"${R}><span class="lang-badge">TS</span><code>${D}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const N=u.split(`
`),y=N[0].slice(3).trim(),D=y.match(/^([^\s{\[]+)/),V=D?D[1]:"",E=y.match(/\[([^\]]+)\]/),R=E?E[1]:"",j=y.includes("twoslash"),Q=t.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",A=Am(Q),M=N.length>2?N[N.length-1]==="```"?N.slice(1,-1):N.slice(1):[u.slice(3).replace(/```$/,"")],J=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",Y=R?`${J} has-filename`:J,tt=A!=="all",et=M.map((ut,S)=>{const P=S+1,z=A==="all"||A.has(P)?"code-line shiki-focus":tt?"code-line shiki-dimmed":"code-line";let _=(e==null?void 0:e.highlight)===!0?Pr(ut,V):ce(ut);return j&&ut.includes("doubled.value = 2")?(_=_.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${z}"><span class="line-no">${P}</span><span class="line-content">${_}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${z}"><span class="line-no">${P}</span><span class="line-content">${_}</span></span>`}).join(`
`),pt=V?`<span class="lang-badge">${ce(V)}</span>`:"",lt=R?`<span class="code-filename">${ce(R)}</span>`:"",H=((U=t.attrs)==null?void 0:U["custom-slidev-max-height"])||t.maxHeight||"",at=H?` style="max-height:${ce(H)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${Y}"${at}>${lt}${pt}<code>${et}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(N=>N.trim().startsWith("|")).length>=2){const N=u.split(`
`).filter(D=>D.trim().startsWith("|")),y=Tm(N,e==null?void 0:e.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(u.startsWith("> ")){const N=(e==null?void 0:e.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${N}"><p>${re(u.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),b=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(v&&!d&&!b&&!u.includes(`
`)){const N=((W=t.attributes)==null?void 0:W["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),y=((q=t.attributes)==null?void 0:q["custom-slidev-loop"])==="true"||/loop/i.test(u),D=((X=t.attributes)==null?void 0:X["custom-slidev-muted"])==="true"||N||/muted/i.test(u),V=((I=t.attributes)==null?void 0:I["custom-slidev-controls"])==="false",E=u.match(/\bsrc=["']([^"']+)["']/i),R=E?E[1]:"",j=['class="slide-video-player"'];V||j.push("controls"),N&&(j.push("autoplay"),j.push("playsinline")),y&&j.push("loop"),D&&j.push("muted"),j.push('preload="metadata"'),R&&j.push(`src="${R}"`);const Q=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=Q?Q[1].trim():"";return!A&&R&&(A=`<source src="${R}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${D?"true":"false"}"${n}><video ${j.join(" ")}>${A}</video></div>`}const m=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(m){const N=(e==null?void 0:e.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(m[1])}" src="${m[2]}" class="${N}" /></div>`}const g=xa(u,e,t);if(g)return`<div class="${c} pdf-list-item"${n}>${g}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const N=u.match(/minDepth=["']?(\d+)["']?/i),y=u.match(/maxDepth=["']?(\d+)["']?/i),D=u.match(/columns=["']?(\d+)["']?/i),V=(e==null?void 0:e.allSlides)||[];return`<div class="${c}"${n}>${Dm(V,(e==null?void 0:e.currentPageIndex)||1,{minDepth:N?parseInt(N[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:D?parseInt(D[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||b){const N=$m(u,e,t);if(N)return`<div class="${c}"${n}>${N}</div>`}const x=!!t.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${re(u)}</p></div>`}function Lm(t){return`
    ${yn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function Rm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          const isCover = slide.frontmatter?.layout === "cover";
          const pageFirstH = !isCover ? (slide.blocks || []).find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          renderSlide(currentIndex + 1);
        } else {
          renderSlide(currentIndex - 1);
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function _a(t,e){const i="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(i)}</title>
  <style>
${Lm(e==null?void 0:e.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Rm()}
  <\/script>
</body>
</html>`}function Sa(t,e){if(typeof document>"u")return!1;const i=new Blob([e],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Om(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Pm(t){const e=Om(t==null?void 0:t.pageRatio);return`
    ${yn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${e}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function zm(t,e){const i="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",h=Im(l),v=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(i)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${h}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(i)} - 高保真讲义</title>
  <style>
    ${Pm({pageRatio:n,customInlineStyles:e==null?void 0:e.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Ca(t,e){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=zm(t,e);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Nm={class:"spm-slidev-preview-tab"},Fm={class:"spm-slidev-tab__toolbar"},Hm={class:"spm-slidev-tab__actions"},jm=["disabled"],Um={class:"spm-page-badge"},Wm=["disabled"],Vm=["aria-label"],qm=["aria-label"],Km=["src"],Gm=Ce({__name:"SlidevPreviewTab",setup(t,{expose:e}){const i=ti("plugin"),n=ti("sandboxBridge",new Vs),o=new _m(n),s=new Ef,l=vt("web-sandbox"),r=vt(3030),a=vt(null),c=vt(!1),u=vt(null),h=vt(1),v=vt(1),d=vt([]),b=vt(!1),m=vt(!1),g=vt(!1),k=vt("siyuan"),x=vt(""),$=vt(""),T=vt(""),L=vt(!1),B=vt(!1),w=vt(""),U=vt("/plugins/siyuan-slidev/slidev-client/index.html");let W=null,q=null,X=null,I=null,N=null,y=null,D=null;On(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),W=n.onSlideChanged((S,P)=>{h.value=S,v.value=P}),q=n.onBlockClicked((S,P)=>{h.value=P,o.setActiveBlockId(S),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(S,P):Li(S,i==null?void 0:i.app)}),X=n.onOpenInEditor((S,P)=>{h.value=P,o.setActiveBlockId(S),Li(S,i==null?void 0:i.app)}),I=s.nativeBridge.onPageChanged((S,P)=>{h.value=S,v.value=P}),N=n.onOpenPeekDrawer(async S=>{const P=Lo();if(S.peekType==="siyuan"&&P.enableWebServeJump){let p=!1;if(D&&D.docId===S.target)p=!0;else if(D&&D.slides&&D.slides.some(z=>{var F;return(F=z.blocks)==null?void 0:F.some(_=>_.id===S.target)}))p=!1;else try{const z=await kn(`SELECT id, root_id, type FROM blocks WHERE id = '${S.target}' LIMIT 1`);z&&z.length>0&&(p=z[0].type==="d"||z[0].id===z[0].root_id)}catch(z){console.warn("[SlidevPreviewTab] detect block type failed:",z)}k.value="web",L.value=!0,$.value=la(P.webServeUrl,S.target,{focus:!p}),T.value=S.title||`${p?"思源文档":"思源块"}: ${S.target.slice(0,8)}`,m.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=S.peekType,S.peekType==="siyuan")x.value=S.target,T.value=S.title||`块速览: ${S.target.slice(0,8)}`;else{const p=ya(S.target);if(p.external){et(S.target);return}L.value=!0,$.value=p.url,T.value=S.title||p.url}m.value=!0,n.freezeKeyboardNav(!0)}}),y=n.onRequestToggleFullscreen(()=>{lt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",pt)}),Rs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",pt),N&&N(),y&&y(),W&&W(),q&&q(),X&&X(),I&&I(),n.detach(),o.destroy(),s.destroy()});async function V(){if(l.value==="web-sandbox"){if(!D){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const S=await s.startProMode(D,is);if(!S.success){ht.showMessage(`无法启动官方 Pro 模式：${S.error}`);return}l.value="pro-cli",r.value=S.port||3030,U.value=S.url,u.value&&s.nativeBridge.attach(u.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",U.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ht.showMessage("已切回内置高保真沙箱")}function E(){B.value=!B.value,B.value?w.value=(D==null?void 0:D.docId)||"":(w.value="",J())}let R=0;function j(S){if(m.value||Math.abs(S.deltaY)<Math.abs(S.deltaX)||Math.abs(S.deltaY)<15)return;const P=Date.now();P-R<280||(R=P,S.deltaY>0?A():Q())}function Q(){if(h.value>1){const S=h.value-1;h.value=S,l.value==="pro-cli"?s.nativeBridge.navigateToPage(S):n.navigatePage(S)}}function A(){if(h.value<v.value){const S=h.value+1;h.value=S,l.value==="pro-cli"?s.nativeBridge.navigateToPage(S):n.navigatePage(S)}}function M(S){h.value=S,l.value==="pro-cli"?s.nativeBridge.navigateToPage(S):n.navigatePage(S)}function J(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function Y(){m.value=!1,n.freezeKeyboardNav(!1)}function tt(){Y()}function et(S){var F,_;const P=/^file:/i.test(S),p=P||/^[a-zA-Z]:[\\/]/.test(S),z=Se("electron");if(p&&typeof((F=z==null?void 0:z.shell)==null?void 0:F.openPath)=="function"){z.shell.openPath(P?ba(S):S),ht.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((_=z==null?void 0:z.shell)==null?void 0:_.openExternal)=="function"?z.shell.openExternal(S).catch(()=>{typeof window<"u"&&window.open(S,"_blank")}):typeof window<"u"&&window.open(S,"_blank"),ht.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function pt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function lt(){const S=a.value||u.value;S&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):S.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function H(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function at(){if(!D){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const S=_a(D);Sa("presentation.html",S)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function ut(){if(!D){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ca(D)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return e({updateDocument(S,P){B.value&&w.value&&P&&P!==w.value||(D=S,B.value&&!w.value&&(w.value=S.docId),d.value=S.slides,v.value=S.slides.length,o.setDocId(S.docId),o.updateSlidesIndex(S.slides),l.value==="pro-cli"?s.scaffolder.scaffold(S,is).catch(()=>{}):n.updateSlides(S.slides,S.config,S.fullMarkdown,S.customThemeCss))},navigateToBlock(S){o.onCursorFocusBlock(S)},isPinned:B,pinnedDocId:w,engineMode:l,toggleEngineMode:V}),(S,P)=>(nt(),st("div",Nm,[f("div",Fm,[P[4]||(P[4]=f("div",{class:"spm-slidev-tab__title"},[f("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlidev"})]),f("span",null,"Slidev 演示预览")],-1)),f("div",Hm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:Q},[dt(ft,{name:"chevron-left"})],8,jm),f("span",Um,xt(h.value)+" / "+xt(v.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=v.value,"aria-label":"下一页",onClick:A},[dt(ft,{name:"chevron-right"})],8,Wm),f("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":B.value}]),"aria-label":B.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:E},[dt(ft,{name:"pin"}),f("span",null,xt(B.value?"已锁定":"跟随"),1)],10,Vm),f("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:V},[dt(ft,{name:"rocket"}),f("span",null,xt(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,qm),P[3]||(P[3]=f("span",{class:"spm-toolbar-divider"},null,-1)),f("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":b.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:P[0]||(P[0]=p=>b.value=!b.value)},[dt(ft,{name:"outline"})],2),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:H},[dt(ft,{name:"presenter"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:at},[dt(ft,{name:"export-html"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:ut},[dt(ft,{name:"export-pdf"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:J},[dt(ft,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:lt},[dt(ft,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:j},[f("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:U.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Km),dt(Rh,{visible:m.value,"onUpdate:visible":P[1]||(P[1]=p=>m.value=p),"is-maximized":g.value,"onUpdate:isMaximized":P[2]||(P[2]=p=>g.value=p),title:T.value,onClose:Y},{default:Al(()=>[k.value==="siyuan"&&x.value?(nt(),De(Wh,{key:0,"block-id":x.value,title:T.value,plugin:bt(i),onExternalJump:tt},null,8,["block-id","title","plugin"])):Ot("",!0),L.value?Te((nt(),De(wm,{key:1,visible:m.value&&k.value==="web",url:$.value,title:T.value,onExternalJump:tt},null,8,["visible","url","title"])),[[oa,k.value==="web"]]):Ot("",!0)]),_:1},8,["visible","is-maximized","title"])],544),b.value&&d.value.length>0?(nt(),De($h,{key:0,slides:d.value,"current-active-page":h.value,onNavigate:M,onRefresh:J},null,8,["slides","current-active-page"])):Ot("",!0)]))}}),Zm=ze(Gm,[["__scopeId","data-v-dd3f9635"]]),Ym={class:"spm-section spm-section--page"},Jm={class:"spm-section-header"},Xm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Qm={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},tg={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},eg={key:1,class:"spm-card-control"},ig={class:"spm-control-header"},ng={class:"spm-control-title-group"},og={class:"spm-control-title"},sg={class:"spm-quick-chips"},rg=["onClick"],lg={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},ag=["value"],cg=["aria-label"],dg={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},ug={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},fg={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},pg={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},hg={class:"spm-card-control"},mg={class:"spm-control-header"},gg={class:"spm-control-title-group"},vg={class:"spm-control-title"},bg={class:"spm-segmented-group"},yg={class:"spm-card-control"},kg={class:"spm-control-header"},wg={class:"spm-control-title-group"},xg={class:"spm-control-title"},_g={class:"spm-quick-chips"},Sg=["onClick"],Cg=["value"],$g={key:2,class:"spm-card-control"},Ig={class:"spm-control-header"},Ag={class:"spm-control-title-group"},Bg={class:"spm-control-title"},Tg={class:"spm-quick-chips"},Eg=["onClick"],Mg=["value"],Dg={class:"spm-card-control"},Lg={class:"spm-control-header"},Rg={class:"spm-control-title-group"},Og={class:"spm-control-title"},Pg={key:0,class:"spm-note-status-box"},zg=["title"],Ng={class:"spm-action-grid",style:{"margin-top":"6px"}},Fg={key:1,class:"spm-note-empty-box"},Hg={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},jg={class:"spm-action-grid"},Ug=["disabled"],Wg=["disabled"],Vg={class:"spm-card-control"},qg={class:"spm-action-grid"},Kg=Ce({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:e}){const i=t,n=e,o=St(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),s=St(()=>{var b,m;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const v=(i.pageLayoutRatio||"").trim();if(v.includes(":")){const g=v.split(":").filter(Boolean).length;if(g>=2&&g<=6)return g}const d=(i.detectedSbRatio||"").trim();if(d.includes(":")){const g=d.split(":").filter(Boolean).length;if(g>=2&&g<=6)return g}if((b=i.detectedSbInfo)!=null&&b.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((m=i.detectedSbInfo)!=null&&m.slots&&Array.isArray(i.detectedSbInfo.slots)){const g=i.detectedSbInfo.slots.length;if(g>=2&&g<=6)return g}return 2}),l=St(()=>{const v=s.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=St(()=>i.pageLayoutRatio||"");function a(){const v=s.value||2,d=Array(v).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=St(()=>{if(!i.pageNotes)return"";const v=i.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],h=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,d)=>(nt(),st("div",Ym,[f("div",Jm,[f("span",null,"幻灯片页面设置"+xt(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),dt(va,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=b=>v.$emit("update:pageLayout",b))},null,8,["model-value"]),!o.value&&t.pageLayout!=="clover"&&t.detectedSbRatio?(nt(),st("div",Xm,[f("div",Qm,[f("div",tg,[dt(ft,{name:"sparkles"}),f("span",null,[d[22]||(d[22]=$e("检测到本页横向超级块列宽比例：",-1)),f("b",null,xt(t.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=b=>v.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[dt(ft,{name:"columns"}),d[23]||(d[23]=f("span",null,"设为分栏",-1))])])])):Ot("",!0),o.value?(nt(),st("div",eg,[f("div",ig,[f("div",ng,[f("div",og,[dt(ft,{name:"ratio"}),d[24]||(d[24]=f("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",sg,[(nt(!0),st(Kt,null,xe(l.value,b=>(nt(),st("button",{key:b.value,class:At(["spm-chip",{active:r.value===b.value}]),onClick:m=>v.$emit("update:pageLayoutRatio",b.value)},xt(b.label),11,rg))),128))]),f("div",lg,[f("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=b=>v.$emit("update:pageLayoutRatio",b.target.value)),onChange:d[3]||(d[3]=b=>v.$emit("update:pageLayoutRatio",b.target.value))},null,40,ag),t.detectedSbRatio?(nt(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=b=>v.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[dt(ft,{name:"sparkles"}),d[26]||(d[26]=f("span",null,"读取",-1))],8,cg)):(nt(),st("button",dg,[dt(ft,{name:"sparkles"}),d[27]||(d[27]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[dt(ft,{name:"reset"}),d[28]||(d[28]=f("span",null,"重置",-1))])]),t.detectedSbRatio?(nt(),st("div",ug,[dt(ft,{name:"ratio"}),d[29]||(d[29]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",fg,xt(t.detectedSbRatio),1)])):(nt(),st("div",pg,[dt(ft,{name:"ratio"}),d[30]||(d[30]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ot("",!0),dt(qs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=b=>v.$emit("update:pageTransition",b))},null,8,["model-value"]),f("div",hg,[f("div",mg,[f("div",gg,[f("div",vg,[dt(ft,{name:"ratio"}),d[31]||(d[31]=f("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",bg,[f("button",{class:At(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=b=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=b=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=b=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=b=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",yg,[f("div",kg,[f("div",wg,[f("div",xg,[dt(ft,{name:"palette"}),d[33]||(d[33]=f("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",_g,[(nt(),st(Kt,null,xe(u,b=>f("button",{key:b.value,class:At(["spm-chip",{active:t.pageBackground===b.value}]),onClick:m=>v.$emit("update:pageBackground",b.value)},xt(b.label),11,Sg)),64))]),f("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=b=>v.$emit("update:pageBackground",b.target.value)),onChange:d[11]||(d[11]=b=>v.$emit("update:pageBackground",b.target.value))},null,40,Cg)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(nt(),st("div",$g,[f("div",Ig,[f("div",Ag,[f("div",Bg,[dt(ft,{name:"image"}),d[35]||(d[35]=f("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Tg,[(nt(),st(Kt,null,xe(h,b=>f("button",{key:b.value,class:At(["spm-chip",{active:t.pageImage===b.value}]),onClick:m=>v.$emit("update:pageImage",b.value)},xt(b.label),11,Eg)),64))]),f("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=b=>v.$emit("update:pageImage",b.target.value)),onChange:d[13]||(d[13]=b=>v.$emit("update:pageImage",b.target.value))},null,40,Mg)])):Ot("",!0),f("div",Dg,[f("div",Lg,[f("div",Rg,[f("div",Og,[dt(ft,{name:"presenter"}),d[37]||(d[37]=f("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),f("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=b=>v.$emit("generateNotes"))},[dt(ft,{name:"sparkles"}),d[39]||(d[39]=f("span",null,"AI 讲稿",-1))])]),t.pageNotes?(nt(),st("div",Pg,[d[42]||(d[42]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:t.pageNotes},xt(c.value),9,zg),f("div",Ng,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=b=>v.$emit("locateNoteBlock"))},[dt(ft,{name:"search"}),d[40]||(d[40]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=b=>v.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),d[41]||(d[41]=f("span",null,"追加讲稿块",-1))])])])):(nt(),st("div",Fg,[d[44]||(d[44]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=b=>v.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),d[43]||(d[43]=f("span",null,"添加讲稿备注块",-1))])])),f("div",Hg,[f("div",jg,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=b=>v.$emit("batchAppendNotes"))},[dt(ft,{name:"insert-below"}),d[45]||(d[45]=f("span",null,"全部追加",-1))],12,Ug),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=b=>v.$emit("batchDeleteNotes"))},[dt(ft,{name:"trash"}),d[46]||(d[46]=f("span",null,"全部删除",-1))],12,Wg)])])]),f("div",Vg,[d[49]||(d[49]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",qg,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=b=>v.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),d[47]||(d[47]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=b=>v.$emit("deleteDivider"))},[dt(ft,{name:"trash"}),d[48]||(d[48]=f("span",null,"删除此页",-1))])])])]))}}),Gg=ze(Kg,[["__scopeId","data-v-9c927c7c"]]),Zg={class:"spm-section spm-section--block"},Yg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Jg={class:"spm-control-header"},Xg={class:"spm-control-title-group"},Qg={class:"spm-control-title"},tv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},ev={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},iv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},nv={key:0},ov={key:1},sv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},rv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},lv={class:"spm-action-grid"},av={class:"spm-card-control"},cv={class:"spm-control-header"},dv={class:"spm-control-title-group"},uv={class:"spm-control-title"},fv=["aria-label"],pv=["checked"],hv={key:1,class:"spm-card-control"},mv={class:"spm-control-header"},gv={class:"spm-control-title-group"},vv={class:"spm-control-title"},bv={class:"spm-quick-chips"},yv={key:2,class:"spm-card-control"},kv={class:"spm-control-header"},wv={class:"spm-control-title-group"},xv={class:"spm-control-title"},_v={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Sv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Cv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},$v=["aria-label"],Iv=["checked"],Av={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Bv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Tv=["aria-label"],Ev=["checked"],Mv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Dv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Lv=["aria-label"],Rv=["checked"],Ov={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Pv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},zv=["aria-label"],Nv=["checked"],Fv={class:"spm-card-control"},Hv={class:"spm-control-header"},jv={class:"spm-control-title-group"},Uv={class:"spm-control-title"},Wv=["aria-label"],Vv=["checked"],qv={key:0,class:"spm-quick-chips"},Kv=["onClick"],Gv={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Zv={class:"spm-card-control"},Yv={class:"spm-control-header"},Jv={class:"spm-control-title-group"},Xv={class:"spm-control-title"},Qv=["aria-label"],tb=["checked"],eb={key:0,class:"spm-quick-chips"},ib=["onClick"],nb={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},ob={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},sb={style:{display:"flex",gap:"6px"}},rb=["value"],lb=["value"],ab={key:3,class:"spm-card-control"},cb={class:"spm-control-header"},db={class:"spm-control-title-group"},ub={class:"spm-control-title"},fb={class:"spm-control-desc"},pb={class:"spm-segmented-group"},hb=["onClick"],mb={key:4,class:"spm-card-control"},gb={class:"spm-control-header"},vb={class:"spm-control-title-group"},bb={class:"spm-control-title"},yb={class:"spm-quick-chips"},kb=["onClick"],wb=["value"],xb={key:5,class:"spm-card-control"},_b={class:"spm-control-header"},Sb={class:"spm-control-title-group"},Cb={class:"spm-control-title"},$b={class:"spm-quick-chips"},Ib=["onClick"],Ab=["value"],Bb={class:"spm-card-control"},Tb={class:"spm-action-grid"},Eb=["aria-label"],Mb=Ce({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:e}){const i=t,n=St(()=>{const B=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":B}),o=St(()=>{const B=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(B)}),s=St(()=>{var w,U,W,q;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const B=(U=i.elemSlot)==null?void 0:U.match(/^col-(\d+)$/);if(B){const X=parseInt(B[1],10);if(X>=2&&X<=6)return Math.max(X,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((q=(W=i.detectedSbInfo)==null?void 0:W.ratio)!=null&&q.includes(":")){const X=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(X.length>=2)return Math.min(X.length,6)}return 3}),l=St(()=>{const B=n.value;return B==="cols-header"?"多栏插槽归属 (Slot)":B==="three-cols-header"?"三栏插槽归属 (Slot)":B==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=St(()=>{const B=n.value;return B==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:B==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":B==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":B==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=St(()=>{const B=n.value;if(B==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(B==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(B==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,U=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let W=1;W<=w;W++)U.push({value:`col-${W}`,label:`第 ${W} 栏`});return U});function c(B){const w=i.elemSlot||"";return B?w===B||B==="col-1"&&w==="left"||B==="col-2"&&w==="center"||B==="col-3"&&w==="right"&&s.value===3||B==="col-2"&&w==="right"&&s.value===2||B==="left"&&w==="col-1"||B==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=e,h=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=St(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const B=JSON.parse(i.elemMotion);if(typeof B=="object"&&B!==null)return{preset:B.preset||B.type||"slide-up",duration:typeof B.duration=="number"?B.duration:0,delay:typeof B.delay=="number"?B.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),d=St(()=>!!v.value),b=St(()=>{var B;return((B=v.value)==null?void 0:B.preset)||"slide-up"}),m=St(()=>{var B;return((B=v.value)==null?void 0:B.duration)||0}),g=St(()=>{var B;return((B=v.value)==null?void 0:B.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(B){L(B,m.value,g.value)}function $(B){L(b.value,B,g.value)}function T(B){L(b.value,m.value,B)}function L(B,w,U){if(!B||B==="none"){u("update:elemMotion","");return}if(!w&&!U){u("update:elemMotion",B);return}const W={preset:B};w>0&&(W.duration=w),U>0&&(W.delay=U),u("update:elemMotion",JSON.stringify(W))}return(B,w)=>{var U,W,q,X,I,N;return nt(),st("div",Zg,[w[62]||(w[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(U=t.detectedSbInfo)!=null&&U.hasSuperBlock?(nt(),st("div",Yg,[f("div",Jg,[f("div",Xg,[f("div",Qg,[dt(ft,{name:"ratio"}),w[24]||(w[24]=f("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",tv,[f("div",ev,[f("div",iv,[dt(ft,{name:"ratio"}),(W=t.detectedSbInfo)!=null&&W.isCustomWidth?(nt(),st("span",nv,"已识别自定义列宽比例")):(nt(),st("span",ov,"识别到 "+xt(((q=t.detectedSbInfo)==null?void 0:q.colCount)||2)+" 列超级块分栏",1))]),f("code",sv,xt(((X=t.detectedSbInfo)==null?void 0:X.ratio)||"1:1"),1)]),f("div",rv,xt((I=t.detectedSbInfo)!=null&&I.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",lv,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>B.$emit("applySuperBlockLayout",t.detectedSbInfo))},[dt(ft,{name:"sparkles"}),w[26]||(w[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var D;return B.$emit("applySuperBlockRatio",((D=t.detectedSbInfo)==null?void 0:D.ratio)||"1:1")})},[dt(ft,{name:"check"}),f("span",null,"应用比例 ("+xt(((N=t.detectedSbInfo)==null?void 0:N.ratio)||"1:1")+")",1)])])])):Ot("",!0),f("div",av,[f("div",cv,[f("div",dv,[f("div",uv,[dt(ft,{name:"presenter"}),w[27]||(w[27]=f("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=y=>B.$emit("toggleNote"))},null,40,pv),w[29]||(w[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,fv)])]),t.isImage||t.imageRole?(nt(),st("div",hv,[f("div",mv,[f("div",gv,[f("div",vv,[dt(ft,{name:"image"}),w[30]||(w[30]=f("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",bv,[f("button",{class:At(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=y=>B.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:At(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>B.$emit("update:imageRole","background"))},[dt(ft,{name:"image"}),w[32]||(w[32]=f("span",null,"背景图",-1))],2),f("button",{class:At(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>B.$emit("update:imageRole","image-left"))},[dt(ft,{name:"image-left"}),w[33]||(w[33]=f("span",null,"图左",-1))],2),f("button",{class:At(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>B.$emit("update:imageRole","image-right"))},[dt(ft,{name:"image-right"}),w[34]||(w[34]=f("span",null,"图右",-1))],2)])])):Ot("",!0),t.isVideo?(nt(),st("div",yv,[f("div",kv,[f("div",wv,[f("div",xv,[dt(ft,{name:"video"}),w[35]||(w[35]=f("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",_v,[f("div",Sv,[f("span",Cv,[dt(ft,{name:"sliders"}),w[37]||(w[37]=$e(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=y=>B.$emit("toggleVideoControls"))},null,40,Iv),w[38]||(w[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,$v)]),f("div",Av,[f("span",Bv,[dt(ft,{name:"video"}),w[39]||(w[39]=$e(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=y=>B.$emit("toggleVideoAutoplay"))},null,40,Ev),w[40]||(w[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,Tv)]),f("div",Mv,[f("span",Dv,[dt(ft,{name:"repeat"}),w[41]||(w[41]=$e(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=y=>B.$emit("toggleVideoLoop"))},null,40,Rv),w[42]||(w[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,Lv)]),f("div",Ov,[f("span",Pv,[dt(ft,{name:"volume-x"}),w[43]||(w[43]=$e(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=y=>B.$emit("toggleVideoMuted"))},null,40,Nv),w[44]||(w[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,zv)])])])):Ot("",!0),f("div",Fv,[f("div",Hv,[f("div",jv,[f("div",Uv,[dt(ft,{name:"step"}),w[45]||(w[45]=f("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=y=>B.$emit("toggleElemClick"))},null,40,Vv),w[47]||(w[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,Wv)]),t.elemClick?(nt(),st("div",qv,[(nt(),st(Kt,null,xe(["+1","1","2","hide"],y=>f("button",{key:y,class:At(["spm-chip",{active:t.elemClick===y}]),onClick:D=>B.$emit("update:elemClick",y)},xt(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,Kv)),64))])):t.parentElemClick?(nt(),st("div",Gv,[dt(ft,{name:"check"}),w[48]||(w[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ot("",!0)]),f("div",Zv,[f("div",Yv,[f("div",Jv,[f("div",Xv,[dt(ft,{name:"motion"}),w[49]||(w[49]=f("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[f("input",{type:"checkbox",checked:d.value,onChange:k},null,40,tb),w[51]||(w[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,Qv)]),d.value?(nt(),st("div",eb,[(nt(),st(Kt,null,xe(h,y=>f("button",{key:y.value,class:At(["spm-chip",{active:b.value===y.value}]),onClick:D=>x(y.value)},xt(y.label),11,ib)),64))])):Ot("",!0),d.value?(nt(),st("div",nb,[f("div",ob,[f("span",null,"时长: "+xt(m.value?m.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+xt(g.value?g.value+"ms":"0ms"),1)]),f("div",sb,[f("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:w[12]||(w[12]=y=>$(Number(y.target.value)))},[...w[52]||(w[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,rb),f("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:w[13]||(w[13]=y=>T(Number(y.target.value)))},[...w[53]||(w[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,lb)])])):Ot("",!0)]),o.value||t.elemSlot?(nt(),st("div",ab,[f("div",cb,[f("div",db,[f("div",ub,[dt(ft,{name:"columns"}),f("span",null,xt(l.value),1)]),f("span",fb,xt(r.value),1)])]),f("div",pb,[(nt(!0),st(Kt,null,xe(a.value,y=>(nt(),st("button",{key:y.value,class:At(["spm-segmented-item",{active:c(y.value)}]),onClick:D=>B.$emit("update:elemSlot",y.value)},xt(y.label),11,hb))),128))])])):Ot("",!0),t.isCodeBlock?(nt(),st("div",mb,[f("div",gb,[f("div",vb,[f("div",bb,[dt(ft,{name:"code"}),w[54]||(w[54]=f("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",yb,[(nt(),st(Kt,null,xe(["1-3","all","1|2|3","2-5"],y=>f("button",{key:y,class:At(["spm-chip",{active:t.elemShikiLines===y}]),onClick:D=>B.$emit("update:elemShikiLines",y)},xt(y),11,kb)),64)),t.elemShikiLines?(nt(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>B.$emit("update:elemShikiLines",""))}," 清空 ")):Ot("",!0)]),f("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>B.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>B.$emit("update:elemShikiLines",y.target.value))},null,40,wb)])):Ot("",!0),t.isCodeBlock?(nt(),st("div",xb,[f("div",_b,[f("div",Sb,[f("div",Cb,[dt(ft,{name:"code"}),w[56]||(w[56]=f("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",$b,[(nt(),st(Kt,null,xe(["240px","320px","400px","50vh"],y=>f("button",{key:y,class:At(["spm-chip",{active:t.elemMaxHeight===y}]),onClick:D=>B.$emit("update:elemMaxHeight",y)},xt(y),11,Ib)),64)),t.elemMaxHeight?(nt(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>B.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ot("",!0)]),f("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>B.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>B.$emit("update:elemMaxHeight",y.target.value))},null,40,Ab)])):Ot("",!0),f("div",Bb,[w[61]||(w[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",Tb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>B.$emit("insertDividerBefore"))},[dt(ft,{name:"insert-above"}),w[58]||(w[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>B.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),w[59]||(w[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>B.$emit("setTwoColsContrast"))},[dt(ft,{name:"columns"}),f("span",null,xt(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Eb),t.hasBlockAttrs?(nt(),st("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>B.$emit("clearBlockAttrs"))},[dt(ft,{name:"broom"}),w[60]||(w[60]=f("span",null,"清除属性",-1))])):Ot("",!0)])])])}}}),Db={class:"spm-section spm-section--doc"},Lb={class:"spm-card-control"},Rb={class:"spm-control-header"},Ob={class:"spm-control-title-group"},Pb={class:"spm-control-title"},zb={class:"spm-segmented-group"},Nb=["aria-label","onClick"],Fb={class:"spm-card-control"},Hb={class:"spm-control-header"},jb={class:"spm-control-title-group"},Ub={class:"spm-control-title"},Wb={class:"spm-segmented-group"},Vb={class:"spm-card-control"},qb={class:"spm-control-header"},Kb={class:"spm-control-title-group"},Gb={class:"spm-control-title"},Zb={class:"spm-segmented-group"},Yb={class:"spm-card-control"},Jb={class:"spm-control-header"},Xb={class:"spm-control-title-group"},Qb={class:"spm-control-title"},t1={class:"spm-card-control"},e1={class:"spm-control-header"},i1={class:"spm-control-title-group"},n1={class:"spm-control-title"},o1=["aria-label"],s1=["checked"],r1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},l1=["value"],a1={class:"spm-card-control"},c1={class:"spm-control-header"},d1={class:"spm-control-title-group"},u1={class:"spm-control-title"},f1=["aria-label"],p1=["checked"],h1={class:"spm-card-control"},m1={class:"spm-action-grid"},g1=Ce({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const e=ti("plugin"),i=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ti({enableWebServeJump:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ti({normalizeHeadingSizes:a}),e&&typeof e.saveGlobalSettings=="function"&&await e.saveGlobalSettings({normalizeHeadingSizes:a}),e&&typeof e.compileCurrentDocument=="function"&&e.compileCurrentDocument(e.currentDocId||((c=e.getActiveDocumentId)==null?void 0:c.call(e)))}function l(a){Ti({webServeUrl:a})}function r(a){Ti({webServeUrl:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(nt(),st("div",Db,[c[39]||(c[39]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",Lb,[f("div",Rb,[f("div",Ob,[f("div",Pb,[dt(ft,{name:"palette"}),c[18]||(c[18]=f("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=f("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),f("div",zb,[(nt(),st(Kt,null,xe(n,u=>f("button",{key:u.value,class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:h=>a.$emit("update:docTheme",u.value)},xt(u.label),11,Nb)),64))])]),f("div",Fb,[f("div",Hb,[f("div",jb,[f("div",Ub,[dt(ft,{name:"ratio"}),c[20]||(c[20]=f("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",Wb,[f("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",Vb,[f("div",qb,[f("div",Kb,[f("div",Gb,[dt(ft,{name:"ratio"}),c[22]||(c[22]=f("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",Zb,[f("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),f("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),f("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),f("div",Yb,[f("div",Jb,[f("div",Xb,[f("div",Qb,[dt(ft,{name:"transition"}),c[24]||(c[24]=f("span",null,"全局默认转场",-1))]),c[25]||(c[25]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),dt(qs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),f("div",t1,[f("div",e1,[f("div",i1,[f("div",n1,[dt(ft,{name:"external-link"}),c[26]||(c[26]=f("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:bt(i).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,s1),c[28]||(c[28]=f("span",{class:"spm-switch-slider"},null,-1))],8,o1)]),bt(i).enableWebServeJump?(nt(),st("div",r1,[f("input",{value:bt(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,l1),c[29]||(c[29]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ot("",!0)]),f("div",a1,[f("div",c1,[f("div",d1,[f("div",u1,[dt(ft,{name:"type"}),c[30]||(c[30]=f("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:bt(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,p1),c[32]||(c[32]=f("span",{class:"spm-switch-slider"},null,-1))],8,f1)])]),f("div",h1,[c[38]||(c[38]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",m1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[dt(ft,{name:"split-preview"}),c[33]||(c[33]=f("span",null,"分屏预览",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[dt(ft,{name:"presenter"}),c[34]||(c[34]=f("span",null,"演讲者视图",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[dt(ft,{name:"sparkles"}),c[35]||(c[35]=f("span",null,"AI 智能分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[dt(ft,{name:"export-html"}),c[36]||(c[36]=f("span",null,"导出 HTML",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[dt(ft,{name:"export-pdf"}),c[37]||(c[37]=f("span",null,"导出 PDF",-1))])])])]))}});var Gn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function v1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Zn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Xo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var zr;function b1(){return zr||(zr=1,(function(t,e){(function(i){t.exports=i()})(function(){return(function i(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var h=typeof Zn=="function"&&Zn;if(!u&&h)return h(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(b){var m=n[c][1][b];return l(m||b)},d,d.exports,i,n,o,s)}return o[c].exports}for(var r=typeof Zn=="function"&&Zn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,h,v,d,b,m,g=[],k=0,x=a.length,$=x,T=s.getTypeOf(a)!=="string";k<a.length;)$=x-k,h=T?(c=a[k++],u=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),u=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),v=c>>2,d=(3&c)<<4|u>>4,b=1<$?(15&u)<<2|h>>6:64,m=2<$?63&h:64,g.push(r.charAt(v)+r.charAt(d)+r.charAt(b)+r.charAt(m));return g.join("")},o.decode=function(a){var c,u,h,v,d,b,m=0,g=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,$=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&$--,a.charAt(a.length-2)===r.charAt(64)&&$--,$%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|$):new Array(0|$);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(v=r.indexOf(a.charAt(m++)))>>4,u=(15&v)<<4|(d=r.indexOf(a.charAt(m++)))>>2,h=(3&d)<<6|(b=r.indexOf(a.charAt(m++))),x[g++]=c,d!==64&&(x[g++]=u),b!==64&&(x[g++]=h);return x}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(u,h,v,d,b){this.compressedSize=u,this.uncompressedSize=h,this.crc32=v,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return u.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,h,v){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(h.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,h,v){var d=l,b=v+h;c^=-1;for(var m=v;m<b;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|a,r,r.length,0):(function(c,u,h,v){var d=l,b=v+h;c^=-1;for(var m=v;m<b;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function u(h,v){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,h.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(v){h.push({data:v,meta:h.meta})}},o.compressWorker=function(h){return new u("Deflate",h)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(d,b){var m,g="";for(m=0;m<b;m++)g+=String.fromCharCode(255&d),d>>>=8;return g}function l(d,b,m,g,k,x){var $,T,L=d.file,B=d.compression,w=x!==c.utf8encode,U=r.transformTo("string",x(L.name)),W=r.transformTo("string",c.utf8encode(L.name)),q=L.comment,X=r.transformTo("string",x(q)),I=r.transformTo("string",c.utf8encode(q)),N=W.length!==L.name.length,y=I.length!==q.length,D="",V="",E="",R=L.dir,j=L.date,Q={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(Q.crc32=d.crc32,Q.compressedSize=d.compressedSize,Q.uncompressedSize=d.uncompressedSize);var A=0;b&&(A|=8),w||!N&&!y||(A|=2048);var M=0,J=0;R&&(M|=16),k==="UNIX"?(J=798,M|=(function(tt,et){var pt=tt;return tt||(pt=et?16893:33204),(65535&pt)<<16})(L.unixPermissions,R)):(J=20,M|=(function(tt){return 63&(tt||0)})(L.dosPermissions)),$=j.getUTCHours(),$<<=6,$|=j.getUTCMinutes(),$<<=5,$|=j.getUTCSeconds()/2,T=j.getUTCFullYear()-1980,T<<=4,T|=j.getUTCMonth()+1,T<<=5,T|=j.getUTCDate(),N&&(V=s(1,1)+s(u(U),4)+W,D+="up"+s(V.length,2)+V),y&&(E=s(1,1)+s(u(X),4)+I,D+="uc"+s(E.length,2)+E);var Y="";return Y+=`
\0`,Y+=s(A,2),Y+=B.magic,Y+=s($,2),Y+=s(T,2),Y+=s(Q.crc32,4),Y+=s(Q.compressedSize,4),Y+=s(Q.uncompressedSize,4),Y+=s(U.length,2),Y+=s(D.length,2),{fileRecord:h.LOCAL_FILE_HEADER+Y+U+D,dirRecord:h.CENTRAL_FILE_HEADER+s(J,2)+Y+s(X.length,2)+"\0\0\0\0"+s(M,4)+s(g,4)+U+D+X}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),h=i("../signature");function v(d,b,m,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=g,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(d){var b=d.meta.percent||0,m=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-g-1))/m:100}}))},v.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var m=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,m=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(g){return h.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-d,g=(function(k,x,$,T,L){var B=r.transformTo("string",L(T));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s($,4)+s(B.length,2)+B})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(m){b.processChunk(m)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(m){b.error(m)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var m=0;m<b.length;m++)try{b[m].error(d)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{r.forEach(function(v,d){h++;var b=(function(x,$){var T=x||$,L=s[T];if(!L)throw new Error(T+" is not a valid compression method !");return L})(d.options.compression,a.compression),m=d.options.compressionOptions||a.compressionOptions||{},g=d.dir,k=d.date;d._compressWorker(b,m).withStreamInfo("file",{name:v,dir:g,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=h}catch(v){u.error(v)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function h(v){return new l.Promise(function(d,b){var m=v.decompressed.getContentWorker().pipe(new c);m.on("error",function(g){b(g)}).on("end",function(){m.streamInfo.crc32!==v.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(v,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,d.optimizedBinaryString,d.base64).then(function(m){var g=new a(d);return g.load(m),g}).then(function(m){var g=[l.Promise.resolve(m)],k=m.files;if(d.checkCRC32)for(var x=0;x<k.length;x++)g.push(h(k[x]));return l.Promise.all(g)}).then(function(m){for(var g=m.shift(),k=g.files,x=0;x<k.length;x++){var $=k[x],T=$.fileNameStr,L=s.resolve($.fileNameStr);b.file(L,$.decompressed,{binary:!0,optimizedBinaryString:!0,date:$.date,dir:$.dir,comment:$.fileCommentStr.length?$.fileCommentStr:null,unixPermissions:$.unixPermissions,dosPermissions:$.dosPermissions,createFolders:d.createFolders}),$.dir||(b.file(L).unsafeOriginalName=T)}return g.zipComment.length&&(b.comment=g.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(h,v){u.push(h)||u._helper.pause(),c&&c(v)}).on("error",function(h){u.emit("error",h)}).on("end",function(){u.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(L,B,w){var U,W=r.getTypeOf(B),q=r.extend(w||{},u);q.date=q.date||new Date,q.compression!==null&&(q.compression=q.compression.toUpperCase()),typeof q.unixPermissions=="string"&&(q.unixPermissions=parseInt(q.unixPermissions,8)),q.unixPermissions&&16384&q.unixPermissions&&(q.dir=!0),q.dosPermissions&&16&q.dosPermissions&&(q.dir=!0),q.dir&&(L=k(L)),q.createFolders&&(U=g(L))&&x.call(this,U,!0);var X=W==="string"&&q.binary===!1&&q.base64===!1;w&&w.binary!==void 0||(q.binary=!X),(B instanceof h&&B.uncompressedSize===0||q.dir||!B||B.length===0)&&(q.base64=!1,q.binary=!0,B="",q.compression="STORE",W="string");var I=null;I=B instanceof h||B instanceof a?B:b.isNode&&b.isStream(B)?new m(L,B):r.prepareContent(L,B,q.binary,q.optimizedBinaryString,q.base64);var N=new v(L,I,q);this.files[L]=N}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),h=i("./compressedObject"),v=i("./zipObject"),d=i("./generate"),b=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),g=function(L){L.slice(-1)==="/"&&(L=L.substring(0,L.length-1));var B=L.lastIndexOf("/");return 0<B?L.substring(0,B):""},k=function(L){return L.slice(-1)!=="/"&&(L+="/"),L},x=function(L,B){return B=B!==void 0?B:u.createFolders,L=k(L),this.files[L]||s.call(this,L,null,{dir:!0,createFolders:B}),this.files[L]};function $(L){return Object.prototype.toString.call(L)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(L){var B,w,U;for(B in this.files)U=this.files[B],(w=B.slice(this.root.length,B.length))&&B.slice(0,this.root.length)===this.root&&L(w,U)},filter:function(L){var B=[];return this.forEach(function(w,U){L(w,U)&&B.push(U)}),B},file:function(L,B,w){if(arguments.length!==1)return L=this.root+L,s.call(this,L,B,w),this;if($(L)){var U=L;return this.filter(function(q,X){return!X.dir&&U.test(q)})}var W=this.files[this.root+L];return W&&!W.dir?W:null},folder:function(L){if(!L)return this;if($(L))return this.filter(function(W,q){return q.dir&&L.test(W)});var B=this.root+L,w=x.call(this,B),U=this.clone();return U.root=w.name,U},remove:function(L){L=this.root+L;var B=this.files[L];if(B||(L.slice(-1)!=="/"&&(L+="/"),B=this.files[L]),B&&!B.dir)delete this.files[L];else for(var w=this.filter(function(W,q){return q.name.slice(0,L.length)===L}),U=0;U<w.length;U++)delete this.files[w[U].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(L){var B,w={};try{if((w=r.extend(L||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var U=w.comment||this.comment||"";B=d.generateWorker(this,w,U)}catch(W){(B=new a("error")).error(W)}return new c(B,w.type||"string",w.mimeType)},generateAsync:function(L,B){return this.generateInternalStream(L).accumulate(B)},generateNodeStream:function(L,B){return(L=L||{}).type||(L.type="nodebuffer"),this.generateInternalStream(L).toNodejsStream(B)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===u&&this.data[v+3]===h)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&u===v[2]&&h===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(h){var v=s.getTypeOf(h);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(h):l.uint8array?new u(s.transformTo("uint8array",h)):new r(s.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),u=i("../external"),h=null;if(c.nodestream)try{h=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(b,m){return new u.Promise(function(g,k){var x=[],$=b._internalType,T=b._outputType,L=b._mimeType;b.on("data",function(B,w){x.push(B),m&&m(w)}).on("error",function(B){x=[],k(B)}).on("end",function(){try{var B=(function(w,U,W){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",U),W);case"base64":return a.encode(U);default:return s.transformTo(w,U)}})(T,(function(w,U){var W,q=0,X=null,I=0;for(W=0;W<U.length;W++)I+=U[W].length;switch(w){case"string":return U.join("");case"array":return Array.prototype.concat.apply([],U);case"uint8array":for(X=new Uint8Array(I),W=0;W<U.length;W++)X.set(U[W],q),q+=U[W].length;return X;case"nodebuffer":return Buffer.concat(U);default:throw new Error("concat : unsupported type '"+w+"'")}})($,x),L);g(B)}catch(w){k(w)}x=[]}).resume()})}function d(b,m,g){var k=m;switch(m){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=m,this._mimeType=g,s.checkSupport(k),this._worker=b.pipe(new l(k)),b.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(b){return v(this,b)},on:function(b,m){var g=this;return b==="data"?this._worker.on(b,function(k){m.call(g,k.data,k.meta)}):this._worker.on(b,function(){s.delay(m,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var m,g,k,x,$,T=b.length,L=0;for(x=0;x<T;x++)(64512&(g=b.charCodeAt(x)))==55296&&x+1<T&&(64512&(k=b.charCodeAt(x+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),x++),L+=g<128?1:g<2048?2:g<65536?3:4;for(m=l.uint8array?new Uint8Array(L):new Array(L),x=$=0;$<L;x++)(64512&(g=b.charCodeAt(x)))==55296&&x+1<T&&(64512&(k=b.charCodeAt(x+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),x++),g<128?m[$++]=g:(g<2048?m[$++]=192|g>>>6:(g<65536?m[$++]=224|g>>>12:(m[$++]=240|g>>>18,m[$++]=128|g>>>12&63),m[$++]=128|g>>>6&63),m[$++]=128|63&g);return m})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var m,g,k,x,$=b.length,T=new Array(2*$);for(m=g=0;m<$;)if((k=b[m++])<128)T[g++]=k;else if(4<(x=c[k]))T[g++]=65533,m+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&m<$;)k=k<<6|63&b[m++],x--;1<x?T[g++]=65533:k<65536?T[g++]=k:(k-=65536,T[g++]=55296|k>>10&1023,T[g++]=56320|1023&k)}return T.length!==g&&(T.subarray?T=T.subarray(0,g):T.length=g),s.applyFromCharCode(T)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(h,a),h.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var g=(function(x,$){var T;for(($=$||x.length)>x.length&&($=x.length),T=$-1;0<=T&&(192&x[T])==128;)T--;return T<0||T===0?$:T+c[x[T]]>$?T:$})(b),k=b;g!==b.length&&(l.uint8array?(k=b.subarray(0,g),this.leftOver=b.subarray(g,b.length)):(k=b.slice(0,g),this.leftOver=b.slice(g,b.length))),this.push({data:o.utf8decode(k),meta:d.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=h,s.inherits(v,a),v.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(m){return m}function u(m,g){for(var k=0;k<m.length;++k)g[k]=255&m.charCodeAt(k);return g}i("setimmediate"),o.newBlob=function(m,g){o.checkSupport("blob");try{return new Blob([m],{type:g})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(m),k.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(m,g,k){var x=[],$=0,T=m.length;if(T<=k)return String.fromCharCode.apply(null,m);for(;$<T;)g==="array"||g==="nodebuffer"?x.push(String.fromCharCode.apply(null,m.slice($,Math.min($+k,T)))):x.push(String.fromCharCode.apply(null,m.subarray($,Math.min($+k,T)))),$+=k;return x.join("")},stringifyByChar:function(m){for(var g="",k=0;k<m.length;k++)g+=String.fromCharCode(m[k]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(m){var g=65536,k=o.getTypeOf(m),x=!0;if(k==="uint8array"?x=h.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=h.applyCanBeUsed.nodebuffer),x)for(;1<g;)try{return h.stringifyByChunk(m,k,g)}catch{g=Math.floor(g/2)}return h.stringifyByChar(m)}function d(m,g){for(var k=0;k<m.length;k++)g[k]=m[k];return g}o.applyFromCharCode=v;var b={};b.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},b.array={string:v,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return v(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:v,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:v,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},o.transformTo=function(m,g){if(g=g||"",!m)return g;o.checkSupport(m);var k=o.getTypeOf(g);return b[k][m](g)},o.resolve=function(m){for(var g=m.split("/"),k=[],x=0;x<g.length;x++){var $=g[x];$==="."||$===""&&x!==0&&x!==g.length-1||($===".."?k.pop():k.push($))}return k.join("/")},o.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(m){var g,k,x="";for(k=0;k<(m||"").length;k++)x+="\\x"+((g=m.charCodeAt(k))<16?"0":"")+g.toString(16).toUpperCase();return x},o.delay=function(m,g,k){setImmediate(function(){m.apply(k||null,g||[])})},o.inherits=function(m,g){function k(){}k.prototype=g.prototype,m.prototype=new k},o.extend=function(){var m,g,k={};for(m=0;m<arguments.length;m++)for(g in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],g)&&k[g]===void 0&&(k[g]=arguments[m][g]);return k},o.prepareContent=function(m,g,k,x,$){return a.Promise.resolve(g).then(function(T){return s.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(L,B){var w=new FileReader;w.onload=function(U){L(U.target.result)},w.onerror=function(U){B(U.target.error)},w.readAsArrayBuffer(T)}):T}).then(function(T){var L=o.getTypeOf(T);return L?(L==="arraybuffer"?T=o.transformTo("uint8array",T):L==="string"&&($?T=l.decode(T):k&&x!==!0&&(T=(function(B){return u(B,s.uint8array?new Uint8Array(B.length):new Array(B.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function u(h){this.files=[],this.loadOptions=h}u.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(h)+")")}},isSignature:function(h,v){var d=this.reader.index;this.reader.setIndex(h);var b=this.reader.readString(4)===v;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",d=l.transformTo(v,h);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,v,d,b=this.zip64EndOfCentralSize-44;0<b;)h=this.reader.readInt(2),v=this.reader.readInt(4),d=this.reader.readData(v),this.zip64ExtensibleData[h]={id:h,length:v,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,v;for(h=0;h<this.files.length;h++)v=this.files[h],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var v=h;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=v-d;if(0<b)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(h){this.reader=s(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),u=i("./compressions"),h=i("./support");function v(d,b){this.options=d,this.loadOptions=b}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(g){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===g)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,m,g,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)b=d.readInt(2),m=d.readInt(2),g=d.readData(m),this.extraFields[b]={id:b,length:m,value:g};d.setIndex(k)},handleUTF8:function(){var d=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(b,m,g){this.name=b,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=m,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");s.prototype={internalStream:function(b){var m=null,g="string";try{if(!b)throw new Error("No output type specified.");var k=(g=b.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),m=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(m=m.pipe(new a.Utf8EncodeWorker)),!x&&k&&(m=m.pipe(new a.Utf8DecodeWorker))}catch($){(m=new u("error")).error($)}return new l(m,g,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<h.length;d++)s.prototype[h[d]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),h=s.document.createTextNode("");u.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var v=new s.MessageChannel;v.port1.onmessage=b,l=function(){v.port2.postMessage(0)}}var d=[];function b(){var m,g;r=!0;for(var k=d.length;k;){for(g=d,d=[],m=-1;++m<k;)g[m]();k=d.length}r=!1}n.exports=function(m){d.push(m)!==1||r||l()}}).call(this,typeof Gn<"u"?Gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function h(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&m(this,k)}function v(k,x,$){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof $=="function"&&(this.onRejected=$,this.callRejected=this.otherCallRejected)}function d(k,x,$){s(function(){var T;try{T=x($)}catch(L){return r.reject(k,L)}T===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,T)})}function b(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function m(k,x){var $=!1;function T(w){$||($=!0,r.reject(k,w))}function L(w){$||($=!0,r.resolve(k,w))}var B=g(function(){x(L,T)});B.status==="error"&&T(B.value)}function g(k,x){var $={};try{$.value=k(x),$.status="success"}catch(T){$.status="error",$.value=T}return $}(n.exports=h).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function($){return x.resolve(k()).then(function(){return $})},function($){return x.resolve(k()).then(function(){throw $})})},h.prototype.catch=function(k){return this.then(null,k)},h.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var $=new this.constructor(l);return this.state!==u?d($,this.state===c?k:x,this.outcome):this.queue.push(new v($,k,x)),$},v.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},v.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},v.prototype.callRejected=function(k){r.reject(this.promise,k)},v.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,x){var $=g(b,x);if($.status==="error")return r.reject(k,$.value);var T=$.value;if(T)m(k,T);else{k.state=c,k.outcome=x;for(var L=-1,B=k.queue.length;++L<B;)k.queue[L].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var $=-1,T=k.queue.length;++$<T;)k.queue[$].callRejected(x);return k},h.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},h.reject=function(k){var x=new this(l);return r.reject(x,k)},h.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,T=!1;if(!$)return this.resolve([]);for(var L=new Array($),B=0,w=-1,U=new this(l);++w<$;)W(k[w],w);return U;function W(q,X){x.resolve(q).then(function(I){L[X]=I,++B!==$||T||(T=!0,r.resolve(U,L))},function(I){T||(T=!0,r.reject(U,I))})}},h.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,T=!1;if(!$)return this.resolve([]);for(var L=-1,B=new this(l);++L<$;)w=k[L],x.resolve(w).then(function(U){T||(T=!0,r.resolve(B,U))},function(U){T||(T=!0,r.reject(B,U))});var w;return B}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,h=0,v=-1,d=0,b=8;function m(k){if(!(this instanceof m))return new m(k);this.options=l.assign({level:v,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var $=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if($!==h)throw new Error(a[$]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var T;if(T=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,($=s.deflateSetDictionary(this.strm,T))!==h)throw new Error(a[$]);this._dict_set=!0}}function g(k,x){var $=new m(x);if($.push(k,!0),$.err)throw $.msg||a[$.err];return $.result}m.prototype.push=function(k,x){var $,T,L=this.strm,B=this.options.chunkSize;if(this.ended)return!1;T=x===~~x?x:x===!0?4:0,typeof k=="string"?L.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?L.input=new Uint8Array(k):L.input=k,L.next_in=0,L.avail_in=L.input.length;do{if(L.avail_out===0&&(L.output=new l.Buf8(B),L.next_out=0,L.avail_out=B),($=s.deflate(L,T))!==1&&$!==h)return this.onEnd($),!(this.ended=!0);L.avail_out!==0&&(L.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(L.output,L.next_out))):this.onData(l.shrinkBuf(L.output,L.next_out)))}while((0<L.avail_in||L.avail_out===0)&&$!==1);return T===4?($=s.deflateEnd(this.strm),this.onEnd($),this.ended=!0,$===h):T!==2||(this.onEnd(h),!(L.avail_out=0))},m.prototype.onData=function(k){this.chunks.push(k)},m.prototype.onEnd=function(k){k===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=m,o.deflate=g,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,g(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,g(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),h=i("./zlib/gzheader"),v=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||m&&m.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,g.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new h,s.inflateGetHeader(this.strm,this.header)}function b(m,g){var k=new d(g);if(k.push(m,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(m,g){var k,x,$,T,L,B,w=this.strm,U=this.options.chunkSize,W=this.options.dictionary,q=!1;if(this.ended)return!1;x=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?w.input=r.binstring2buf(m):v.call(m)==="[object ArrayBuffer]"?w.input=new Uint8Array(m):w.input=m,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(U),w.next_out=0,w.avail_out=U),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&W&&(B=typeof W=="string"?r.string2buf(W):v.call(W)==="[object ArrayBuffer]"?new Uint8Array(W):W,k=s.inflateSetDictionary(this.strm,B)),k===a.Z_BUF_ERROR&&q===!0&&(k=a.Z_OK,q=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?($=r.utf8border(w.output,w.next_out),T=w.next_out-$,L=r.buf2string(w.output,$),w.next_out=T,w.avail_out=U-T,T&&l.arraySet(w.output,w.output,$,T,0),this.onData(L)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(q=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},o.Inflate=d,o.inflate=b,o.inflateRaw=function(m,g){return(g=g||{}).raw=!0,b(m,g)},o.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var h in u)u.hasOwnProperty(h)&&(a[h]=u[h])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,h,v){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+h),v);else for(var d=0;d<h;d++)a[v+d]=c[u+d]},flattenChunks:function(a){var c,u,h,v,d,b;for(c=h=0,u=a.length;c<u;c++)h+=a[c].length;for(b=new Uint8Array(h),c=v=0,u=a.length;c<u;c++)d=a[c],b.set(d,v),v+=d.length;return b}},r={arraySet:function(a,c,u,h,v){for(var d=0;d<h;d++)a[v+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(h,v){if(v<65537&&(h.subarray&&r||!h.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(h,v));for(var d="",b=0;b<v;b++)d+=String.fromCharCode(h[b]);return d}a[254]=a[254]=1,o.string2buf=function(h){var v,d,b,m,g,k=h.length,x=0;for(m=0;m<k;m++)(64512&(d=h.charCodeAt(m)))==55296&&m+1<k&&(64512&(b=h.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),x+=d<128?1:d<2048?2:d<65536?3:4;for(v=new s.Buf8(x),m=g=0;g<x;m++)(64512&(d=h.charCodeAt(m)))==55296&&m+1<k&&(64512&(b=h.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),d<128?v[g++]=d:(d<2048?v[g++]=192|d>>>6:(d<65536?v[g++]=224|d>>>12:(v[g++]=240|d>>>18,v[g++]=128|d>>>12&63),v[g++]=128|d>>>6&63),v[g++]=128|63&d);return v},o.buf2binstring=function(h){return u(h,h.length)},o.binstring2buf=function(h){for(var v=new s.Buf8(h.length),d=0,b=v.length;d<b;d++)v[d]=h.charCodeAt(d);return v},o.buf2string=function(h,v){var d,b,m,g,k=v||h.length,x=new Array(2*k);for(d=b=0;d<k;)if((m=h[d++])<128)x[b++]=m;else if(4<(g=a[m]))x[b++]=65533,d+=g-1;else{for(m&=g===2?31:g===3?15:7;1<g&&d<k;)m=m<<6|63&h[d++],g--;1<g?x[b++]=65533:m<65536?x[b++]=m:(m-=65536,x[b++]=55296|m>>10&1023,x[b++]=56320|1023&m)}return u(x,b)},o.utf8border=function(h,v){var d;for((v=v||h.length)>h.length&&(v=h.length),d=v-1;0<=d&&(192&h[d])==128;)d--;return d<0||d===0?v:d+a[h[d]]>v?d:v}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,h=0;r!==0;){for(r-=h=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--h;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,h=c+a;l^=-1;for(var v=c;v<h;v++)l=l>>>8^u[255&(l^r[v])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),u=i("./messages"),h=0,v=4,d=0,b=-2,m=-1,g=4,k=2,x=8,$=9,T=286,L=30,B=19,w=2*T+1,U=15,W=3,q=258,X=q+W+1,I=42,N=113,y=1,D=2,V=3,E=4;function R(p,z){return p.msg=u[z],z}function j(p){return(p<<1)-(4<p?9:0)}function Q(p){for(var z=p.length;0<=--z;)p[z]=0}function A(p){var z=p.state,F=z.pending;F>p.avail_out&&(F=p.avail_out),F!==0&&(l.arraySet(p.output,z.pending_buf,z.pending_out,F,p.next_out),p.next_out+=F,z.pending_out+=F,p.total_out+=F,p.avail_out-=F,z.pending-=F,z.pending===0&&(z.pending_out=0))}function M(p,z){r._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,z),p.block_start=p.strstart,A(p.strm)}function J(p,z){p.pending_buf[p.pending++]=z}function Y(p,z){p.pending_buf[p.pending++]=z>>>8&255,p.pending_buf[p.pending++]=255&z}function tt(p,z){var F,_,C=p.max_chain_length,O=p.strstart,Z=p.prev_length,G=p.nice_match,K=p.strstart>p.w_size-X?p.strstart-(p.w_size-X):0,it=p.window,ct=p.w_mask,rt=p.prev,mt=p.strstart+q,_t=it[O+Z-1],wt=it[O+Z];p.prev_length>=p.good_match&&(C>>=2),G>p.lookahead&&(G=p.lookahead);do if(it[(F=z)+Z]===wt&&it[F+Z-1]===_t&&it[F]===it[O]&&it[++F]===it[O+1]){O+=2,F++;do;while(it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&it[++O]===it[++F]&&O<mt);if(_=q-(mt-O),O=mt-q,Z<_){if(p.match_start=z,G<=(Z=_))break;_t=it[O+Z-1],wt=it[O+Z]}}while((z=rt[z&ct])>K&&--C!=0);return Z<=p.lookahead?Z:p.lookahead}function et(p){var z,F,_,C,O,Z,G,K,it,ct,rt=p.w_size;do{if(C=p.window_size-p.lookahead-p.strstart,p.strstart>=rt+(rt-X)){for(l.arraySet(p.window,p.window,rt,rt,0),p.match_start-=rt,p.strstart-=rt,p.block_start-=rt,z=F=p.hash_size;_=p.head[--z],p.head[z]=rt<=_?_-rt:0,--F;);for(z=F=rt;_=p.prev[--z],p.prev[z]=rt<=_?_-rt:0,--F;);C+=rt}if(p.strm.avail_in===0)break;if(Z=p.strm,G=p.window,K=p.strstart+p.lookahead,it=C,ct=void 0,ct=Z.avail_in,it<ct&&(ct=it),F=ct===0?0:(Z.avail_in-=ct,l.arraySet(G,Z.input,Z.next_in,ct,K),Z.state.wrap===1?Z.adler=a(Z.adler,G,ct,K):Z.state.wrap===2&&(Z.adler=c(Z.adler,G,ct,K)),Z.next_in+=ct,Z.total_in+=ct,ct),p.lookahead+=F,p.lookahead+p.insert>=W)for(O=p.strstart-p.insert,p.ins_h=p.window[O],p.ins_h=(p.ins_h<<p.hash_shift^p.window[O+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[O+W-1])&p.hash_mask,p.prev[O&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=O,O++,p.insert--,!(p.lookahead+p.insert<W)););}while(p.lookahead<X&&p.strm.avail_in!==0)}function pt(p,z){for(var F,_;;){if(p.lookahead<X){if(et(p),p.lookahead<X&&z===h)return y;if(p.lookahead===0)break}if(F=0,p.lookahead>=W&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+W-1])&p.hash_mask,F=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),F!==0&&p.strstart-F<=p.w_size-X&&(p.match_length=tt(p,F)),p.match_length>=W)if(_=r._tr_tally(p,p.strstart-p.match_start,p.match_length-W),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=W){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+W-1])&p.hash_mask,F=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else _=r._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(_&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=p.strstart<W-1?p.strstart:W-1,z===v?(M(p,!0),p.strm.avail_out===0?V:E):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:D}function lt(p,z){for(var F,_,C;;){if(p.lookahead<X){if(et(p),p.lookahead<X&&z===h)return y;if(p.lookahead===0)break}if(F=0,p.lookahead>=W&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+W-1])&p.hash_mask,F=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=W-1,F!==0&&p.prev_length<p.max_lazy_match&&p.strstart-F<=p.w_size-X&&(p.match_length=tt(p,F),p.match_length<=5&&(p.strategy===1||p.match_length===W&&4096<p.strstart-p.match_start)&&(p.match_length=W-1)),p.prev_length>=W&&p.match_length<=p.prev_length){for(C=p.strstart+p.lookahead-W,_=r._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-W),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=C&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+W-1])&p.hash_mask,F=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=W-1,p.strstart++,_&&(M(p,!1),p.strm.avail_out===0))return y}else if(p.match_available){if((_=r._tr_tally(p,0,p.window[p.strstart-1]))&&M(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return y}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(_=r._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<W-1?p.strstart:W-1,z===v?(M(p,!0),p.strm.avail_out===0?V:E):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:D}function H(p,z,F,_,C){this.good_length=p,this.max_lazy=z,this.nice_length=F,this.max_chain=_,this.func=C}function at(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*L+1)),this.bl_tree=new l.Buf16(2*(2*B+1)),Q(this.dyn_ltree),Q(this.dyn_dtree),Q(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(U+1),this.heap=new l.Buf16(2*T+1),Q(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),Q(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(p){var z;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=k,(z=p.state).pending=0,z.pending_out=0,z.wrap<0&&(z.wrap=-z.wrap),z.status=z.wrap?I:N,p.adler=z.wrap===2?0:1,z.last_flush=h,r._tr_init(z),d):R(p,b)}function S(p){var z=ut(p);return z===d&&(function(F){F.window_size=2*F.w_size,Q(F.head),F.max_lazy_match=s[F.level].max_lazy,F.good_match=s[F.level].good_length,F.nice_match=s[F.level].nice_length,F.max_chain_length=s[F.level].max_chain,F.strstart=0,F.block_start=0,F.lookahead=0,F.insert=0,F.match_length=F.prev_length=W-1,F.match_available=0,F.ins_h=0})(p.state),z}function P(p,z,F,_,C,O){if(!p)return b;var Z=1;if(z===m&&(z=6),_<0?(Z=0,_=-_):15<_&&(Z=2,_-=16),C<1||$<C||F!==x||_<8||15<_||z<0||9<z||O<0||g<O)return R(p,b);_===8&&(_=9);var G=new at;return(p.state=G).strm=p,G.wrap=Z,G.gzhead=null,G.w_bits=_,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=C+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+W-1)/W),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<C+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=z,G.strategy=O,G.method=F,S(p)}s=[new H(0,0,0,0,function(p,z){var F=65535;for(F>p.pending_buf_size-5&&(F=p.pending_buf_size-5);;){if(p.lookahead<=1){if(et(p),p.lookahead===0&&z===h)return y;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var _=p.block_start+F;if((p.strstart===0||p.strstart>=_)&&(p.lookahead=p.strstart-_,p.strstart=_,M(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-X&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=0,z===v?(M(p,!0),p.strm.avail_out===0?V:E):(p.strstart>p.block_start&&(M(p,!1),p.strm.avail_out),y)}),new H(4,4,8,4,pt),new H(4,5,16,8,pt),new H(4,6,32,32,pt),new H(4,4,16,16,lt),new H(8,16,32,32,lt),new H(8,16,128,128,lt),new H(8,32,128,256,lt),new H(32,128,258,1024,lt),new H(32,258,258,4096,lt)],o.deflateInit=function(p,z){return P(p,z,x,15,8,0)},o.deflateInit2=P,o.deflateReset=S,o.deflateResetKeep=ut,o.deflateSetHeader=function(p,z){return p&&p.state?p.state.wrap!==2?b:(p.state.gzhead=z,d):b},o.deflate=function(p,z){var F,_,C,O;if(!p||!p.state||5<z||z<0)return p?R(p,b):b;if(_=p.state,!p.output||!p.input&&p.avail_in!==0||_.status===666&&z!==v)return R(p,p.avail_out===0?-5:b);if(_.strm=p,F=_.last_flush,_.last_flush=z,_.status===I)if(_.wrap===2)p.adler=0,J(_,31),J(_,139),J(_,8),_.gzhead?(J(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),J(_,255&_.gzhead.time),J(_,_.gzhead.time>>8&255),J(_,_.gzhead.time>>16&255),J(_,_.gzhead.time>>24&255),J(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),J(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(J(_,255&_.gzhead.extra.length),J(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(p.adler=c(p.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(J(_,0),J(_,0),J(_,0),J(_,0),J(_,0),J(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),J(_,3),_.status=N);else{var Z=x+(_.w_bits-8<<4)<<8;Z|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(Z|=32),Z+=31-Z%31,_.status=N,Y(_,Z),_.strstart!==0&&(Y(_,p.adler>>>16),Y(_,65535&p.adler)),p.adler=1}if(_.status===69)if(_.gzhead.extra){for(C=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),A(p),C=_.pending,_.pending!==_.pending_buf_size));)J(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){C=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),A(p),C=_.pending,_.pending===_.pending_buf_size)){O=1;break}O=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,J(_,O)}while(O!==0);_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),O===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){C=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),A(p),C=_.pending,_.pending===_.pending_buf_size)){O=1;break}O=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,J(_,O)}while(O!==0);_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),O===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&A(p),_.pending+2<=_.pending_buf_size&&(J(_,255&p.adler),J(_,p.adler>>8&255),p.adler=0,_.status=N)):_.status=N),_.pending!==0){if(A(p),p.avail_out===0)return _.last_flush=-1,d}else if(p.avail_in===0&&j(z)<=j(F)&&z!==v)return R(p,-5);if(_.status===666&&p.avail_in!==0)return R(p,-5);if(p.avail_in!==0||_.lookahead!==0||z!==h&&_.status!==666){var G=_.strategy===2?(function(K,it){for(var ct;;){if(K.lookahead===0&&(et(K),K.lookahead===0)){if(it===h)return y;break}if(K.match_length=0,ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++,ct&&(M(K,!1),K.strm.avail_out===0))return y}return K.insert=0,it===v?(M(K,!0),K.strm.avail_out===0?V:E):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?y:D})(_,z):_.strategy===3?(function(K,it){for(var ct,rt,mt,_t,wt=K.window;;){if(K.lookahead<=q){if(et(K),K.lookahead<=q&&it===h)return y;if(K.lookahead===0)break}if(K.match_length=0,K.lookahead>=W&&0<K.strstart&&(rt=wt[mt=K.strstart-1])===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]){_t=K.strstart+q;do;while(rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&mt<_t);K.match_length=q-(_t-mt),K.match_length>K.lookahead&&(K.match_length=K.lookahead)}if(K.match_length>=W?(ct=r._tr_tally(K,1,K.match_length-W),K.lookahead-=K.match_length,K.strstart+=K.match_length,K.match_length=0):(ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++),ct&&(M(K,!1),K.strm.avail_out===0))return y}return K.insert=0,it===v?(M(K,!0),K.strm.avail_out===0?V:E):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?y:D})(_,z):s[_.level].func(_,z);if(G!==V&&G!==E||(_.status=666),G===y||G===V)return p.avail_out===0&&(_.last_flush=-1),d;if(G===D&&(z===1?r._tr_align(_):z!==5&&(r._tr_stored_block(_,0,0,!1),z===3&&(Q(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),A(p),p.avail_out===0))return _.last_flush=-1,d}return z!==v?d:_.wrap<=0?1:(_.wrap===2?(J(_,255&p.adler),J(_,p.adler>>8&255),J(_,p.adler>>16&255),J(_,p.adler>>24&255),J(_,255&p.total_in),J(_,p.total_in>>8&255),J(_,p.total_in>>16&255),J(_,p.total_in>>24&255)):(Y(_,p.adler>>>16),Y(_,65535&p.adler)),A(p),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?d:1)},o.deflateEnd=function(p){var z;return p&&p.state?(z=p.state.status)!==I&&z!==69&&z!==73&&z!==91&&z!==103&&z!==N&&z!==666?R(p,b):(p.state=null,z===N?R(p,-3):d):b},o.deflateSetDictionary=function(p,z){var F,_,C,O,Z,G,K,it,ct=z.length;if(!p||!p.state||(O=(F=p.state).wrap)===2||O===1&&F.status!==I||F.lookahead)return b;for(O===1&&(p.adler=a(p.adler,z,ct,0)),F.wrap=0,ct>=F.w_size&&(O===0&&(Q(F.head),F.strstart=0,F.block_start=0,F.insert=0),it=new l.Buf8(F.w_size),l.arraySet(it,z,ct-F.w_size,F.w_size,0),z=it,ct=F.w_size),Z=p.avail_in,G=p.next_in,K=p.input,p.avail_in=ct,p.next_in=0,p.input=z,et(F);F.lookahead>=W;){for(_=F.strstart,C=F.lookahead-(W-1);F.ins_h=(F.ins_h<<F.hash_shift^F.window[_+W-1])&F.hash_mask,F.prev[_&F.w_mask]=F.head[F.ins_h],F.head[F.ins_h]=_,_++,--C;);F.strstart=_,F.lookahead=W-1,et(F)}return F.strstart+=F.lookahead,F.block_start=F.strstart,F.insert=F.lookahead,F.lookahead=0,F.match_length=F.prev_length=W-1,F.match_available=0,p.next_in=G,p.input=K,p.avail_in=Z,F.wrap=O,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,u,h,v,d,b,m,g,k,x,$,T,L,B,w,U,W,q,X,I,N,y,D;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),u=s.next_out,D=s.output,h=u-(l-s.avail_out),v=u+(s.avail_out-257),d=r.dmax,b=r.wsize,m=r.whave,g=r.wnext,k=r.window,x=r.hold,$=r.bits,T=r.lencode,L=r.distcode,B=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{$<15&&(x+=y[a++]<<$,$+=8,x+=y[a++]<<$,$+=8),U=T[x&B];e:for(;;){if(x>>>=W=U>>>24,$-=W,(W=U>>>16&255)===0)D[u++]=65535&U;else{if(!(16&W)){if((64&W)==0){U=T[(65535&U)+(x&(1<<W)-1)];continue e}if(32&W){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}q=65535&U,(W&=15)&&($<W&&(x+=y[a++]<<$,$+=8),q+=x&(1<<W)-1,x>>>=W,$-=W),$<15&&(x+=y[a++]<<$,$+=8,x+=y[a++]<<$,$+=8),U=L[x&w];i:for(;;){if(x>>>=W=U>>>24,$-=W,!(16&(W=U>>>16&255))){if((64&W)==0){U=L[(65535&U)+(x&(1<<W)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(X=65535&U,$<(W&=15)&&(x+=y[a++]<<$,($+=8)<W&&(x+=y[a++]<<$,$+=8)),d<(X+=x&(1<<W)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=W,$-=W,(W=u-h)<X){if(m<(W=X-W)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(N=k,(I=0)===g){if(I+=b-W,W<q){for(q-=W;D[u++]=k[I++],--W;);I=u-X,N=D}}else if(g<W){if(I+=b+g-W,(W-=g)<q){for(q-=W;D[u++]=k[I++],--W;);if(I=0,g<q){for(q-=W=g;D[u++]=k[I++],--W;);I=u-X,N=D}}}else if(I+=g-W,W<q){for(q-=W;D[u++]=k[I++],--W;);I=u-X,N=D}for(;2<q;)D[u++]=N[I++],D[u++]=N[I++],D[u++]=N[I++],q-=3;q&&(D[u++]=N[I++],1<q&&(D[u++]=N[I++]))}else{for(I=u-X;D[u++]=D[I++],D[u++]=D[I++],D[u++]=D[I++],2<(q-=3););q&&(D[u++]=D[I++],1<q&&(D[u++]=D[I++]))}break}}break}}while(a<c&&u<v);a-=q=$>>3,x&=(1<<($-=q<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<v?v-u+257:257-(u-v),r.hold=x,r.bits=$}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),u=1,h=2,v=0,d=-2,b=1,m=852,g=592;function k(I){return(I>>>24&255)+(I>>>8&65280)+((65280&I)<<8)+((255&I)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function $(I){var N;return I&&I.state?(N=I.state,I.total_in=I.total_out=N.total=0,I.msg="",N.wrap&&(I.adler=1&N.wrap),N.mode=b,N.last=0,N.havedict=0,N.dmax=32768,N.head=null,N.hold=0,N.bits=0,N.lencode=N.lendyn=new s.Buf32(m),N.distcode=N.distdyn=new s.Buf32(g),N.sane=1,N.back=-1,v):d}function T(I){var N;return I&&I.state?((N=I.state).wsize=0,N.whave=0,N.wnext=0,$(I)):d}function L(I,N){var y,D;return I&&I.state?(D=I.state,N<0?(y=0,N=-N):(y=1+(N>>4),N<48&&(N&=15)),N&&(N<8||15<N)?d:(D.window!==null&&D.wbits!==N&&(D.window=null),D.wrap=y,D.wbits=N,T(I))):d}function B(I,N){var y,D;return I?(D=new x,(I.state=D).window=null,(y=L(I,N))!==v&&(I.state=null),y):d}var w,U,W=!0;function q(I){if(W){var N;for(w=new s.Buf32(512),U=new s.Buf32(32),N=0;N<144;)I.lens[N++]=8;for(;N<256;)I.lens[N++]=9;for(;N<280;)I.lens[N++]=7;for(;N<288;)I.lens[N++]=8;for(c(u,I.lens,0,288,w,0,I.work,{bits:9}),N=0;N<32;)I.lens[N++]=5;c(h,I.lens,0,32,U,0,I.work,{bits:5}),W=!1}I.lencode=w,I.lenbits=9,I.distcode=U,I.distbits=5}function X(I,N,y,D){var V,E=I.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new s.Buf8(E.wsize)),D>=E.wsize?(s.arraySet(E.window,N,y-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(D<(V=E.wsize-E.wnext)&&(V=D),s.arraySet(E.window,N,y-D,V,E.wnext),(D-=V)?(s.arraySet(E.window,N,y-D,D,0),E.wnext=D,E.whave=E.wsize):(E.wnext+=V,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=V))),0}o.inflateReset=T,o.inflateReset2=L,o.inflateResetKeep=$,o.inflateInit=function(I){return B(I,15)},o.inflateInit2=B,o.inflate=function(I,N){var y,D,V,E,R,j,Q,A,M,J,Y,tt,et,pt,lt,H,at,ut,S,P,p,z,F,_,C=0,O=new s.Buf8(4),Z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!I||!I.state||!I.output||!I.input&&I.avail_in!==0)return d;(y=I.state).mode===12&&(y.mode=13),R=I.next_out,V=I.output,Q=I.avail_out,E=I.next_in,D=I.input,j=I.avail_in,A=y.hold,M=y.bits,J=j,Y=Q,z=v;t:for(;;)switch(y.mode){case b:if(y.wrap===0){y.mode=13;break}for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(2&y.wrap&&A===35615){O[y.check=0]=255&A,O[1]=A>>>8&255,y.check=r(y.check,O,2,0),M=A=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&A)<<8)+(A>>8))%31){I.msg="incorrect header check",y.mode=30;break}if((15&A)!=8){I.msg="unknown compression method",y.mode=30;break}if(M-=4,p=8+(15&(A>>>=4)),y.wbits===0)y.wbits=p;else if(p>y.wbits){I.msg="invalid window size",y.mode=30;break}y.dmax=1<<p,I.adler=y.check=1,y.mode=512&A?10:12,M=A=0;break;case 2:for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(y.flags=A,(255&y.flags)!=8){I.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){I.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=A>>8&1),512&y.flags&&(O[0]=255&A,O[1]=A>>>8&255,y.check=r(y.check,O,2,0)),M=A=0,y.mode=3;case 3:for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.head&&(y.head.time=A),512&y.flags&&(O[0]=255&A,O[1]=A>>>8&255,O[2]=A>>>16&255,O[3]=A>>>24&255,y.check=r(y.check,O,4,0)),M=A=0,y.mode=4;case 4:for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.head&&(y.head.xflags=255&A,y.head.os=A>>8),512&y.flags&&(O[0]=255&A,O[1]=A>>>8&255,y.check=r(y.check,O,2,0)),M=A=0,y.mode=5;case 5:if(1024&y.flags){for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.length=A,y.head&&(y.head.extra_len=A),512&y.flags&&(O[0]=255&A,O[1]=A>>>8&255,y.check=r(y.check,O,2,0)),M=A=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(j<(tt=y.length)&&(tt=j),tt&&(y.head&&(p=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,D,E,tt,p)),512&y.flags&&(y.check=r(y.check,D,tt,E)),j-=tt,E+=tt,y.length-=tt),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(j===0)break t;for(tt=0;p=D[E+tt++],y.head&&p&&y.length<65536&&(y.head.name+=String.fromCharCode(p)),p&&tt<j;);if(512&y.flags&&(y.check=r(y.check,D,tt,E)),j-=tt,E+=tt,p)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(j===0)break t;for(tt=0;p=D[E+tt++],y.head&&p&&y.length<65536&&(y.head.comment+=String.fromCharCode(p)),p&&tt<j;);if(512&y.flags&&(y.check=r(y.check,D,tt,E)),j-=tt,E+=tt,p)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A!==(65535&y.check)){I.msg="header crc mismatch",y.mode=30;break}M=A=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),I.adler=y.check=0,y.mode=12;break;case 10:for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}I.adler=y.check=k(A),M=A=0,y.mode=11;case 11:if(y.havedict===0)return I.next_out=R,I.avail_out=Q,I.next_in=E,I.avail_in=j,y.hold=A,y.bits=M,2;I.adler=y.check=1,y.mode=12;case 12:if(N===5||N===6)break t;case 13:if(y.last){A>>>=7&M,M-=7&M,y.mode=27;break}for(;M<3;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}switch(y.last=1&A,M-=1,3&(A>>>=1)){case 0:y.mode=14;break;case 1:if(q(y),y.mode=20,N!==6)break;A>>>=2,M-=2;break t;case 2:y.mode=17;break;case 3:I.msg="invalid block type",y.mode=30}A>>>=2,M-=2;break;case 14:for(A>>>=7&M,M-=7&M;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if((65535&A)!=(A>>>16^65535)){I.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&A,M=A=0,y.mode=15,N===6)break t;case 15:y.mode=16;case 16:if(tt=y.length){if(j<tt&&(tt=j),Q<tt&&(tt=Q),tt===0)break t;s.arraySet(V,D,E,tt,R),j-=tt,E+=tt,Q-=tt,R+=tt,y.length-=tt;break}y.mode=12;break;case 17:for(;M<14;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(y.nlen=257+(31&A),A>>>=5,M-=5,y.ndist=1+(31&A),A>>>=5,M-=5,y.ncode=4+(15&A),A>>>=4,M-=4,286<y.nlen||30<y.ndist){I.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;M<3;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.lens[Z[y.have++]]=7&A,A>>>=3,M-=3}for(;y.have<19;)y.lens[Z[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,F={bits:y.lenbits},z=c(0,y.lens,0,19,y.lencode,0,y.work,F),y.lenbits=F.bits,z){I.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;H=(C=y.lencode[A&(1<<y.lenbits)-1])>>>16&255,at=65535&C,!((lt=C>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(at<16)A>>>=lt,M-=lt,y.lens[y.have++]=at;else{if(at===16){for(_=lt+2;M<_;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A>>>=lt,M-=lt,y.have===0){I.msg="invalid bit length repeat",y.mode=30;break}p=y.lens[y.have-1],tt=3+(3&A),A>>>=2,M-=2}else if(at===17){for(_=lt+3;M<_;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}M-=lt,p=0,tt=3+(7&(A>>>=lt)),A>>>=3,M-=3}else{for(_=lt+7;M<_;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}M-=lt,p=0,tt=11+(127&(A>>>=lt)),A>>>=7,M-=7}if(y.have+tt>y.nlen+y.ndist){I.msg="invalid bit length repeat",y.mode=30;break}for(;tt--;)y.lens[y.have++]=p}}if(y.mode===30)break;if(y.lens[256]===0){I.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,F={bits:y.lenbits},z=c(u,y.lens,0,y.nlen,y.lencode,0,y.work,F),y.lenbits=F.bits,z){I.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,F={bits:y.distbits},z=c(h,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,F),y.distbits=F.bits,z){I.msg="invalid distances set",y.mode=30;break}if(y.mode=20,N===6)break t;case 20:y.mode=21;case 21:if(6<=j&&258<=Q){I.next_out=R,I.avail_out=Q,I.next_in=E,I.avail_in=j,y.hold=A,y.bits=M,a(I,Y),R=I.next_out,V=I.output,Q=I.avail_out,E=I.next_in,D=I.input,j=I.avail_in,A=y.hold,M=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;H=(C=y.lencode[A&(1<<y.lenbits)-1])>>>16&255,at=65535&C,!((lt=C>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(H&&(240&H)==0){for(ut=lt,S=H,P=at;H=(C=y.lencode[P+((A&(1<<ut+S)-1)>>ut)])>>>16&255,at=65535&C,!(ut+(lt=C>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}A>>>=ut,M-=ut,y.back+=ut}if(A>>>=lt,M-=lt,y.back+=lt,y.length=at,H===0){y.mode=26;break}if(32&H){y.back=-1,y.mode=12;break}if(64&H){I.msg="invalid literal/length code",y.mode=30;break}y.extra=15&H,y.mode=22;case 22:if(y.extra){for(_=y.extra;M<_;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.length+=A&(1<<y.extra)-1,A>>>=y.extra,M-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;H=(C=y.distcode[A&(1<<y.distbits)-1])>>>16&255,at=65535&C,!((lt=C>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if((240&H)==0){for(ut=lt,S=H,P=at;H=(C=y.distcode[P+((A&(1<<ut+S)-1)>>ut)])>>>16&255,at=65535&C,!(ut+(lt=C>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}A>>>=ut,M-=ut,y.back+=ut}if(A>>>=lt,M-=lt,y.back+=lt,64&H){I.msg="invalid distance code",y.mode=30;break}y.offset=at,y.extra=15&H,y.mode=24;case 24:if(y.extra){for(_=y.extra;M<_;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.offset+=A&(1<<y.extra)-1,A>>>=y.extra,M-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){I.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(Q===0)break t;if(tt=Y-Q,y.offset>tt){if((tt=y.offset-tt)>y.whave&&y.sane){I.msg="invalid distance too far back",y.mode=30;break}et=tt>y.wnext?(tt-=y.wnext,y.wsize-tt):y.wnext-tt,tt>y.length&&(tt=y.length),pt=y.window}else pt=V,et=R-y.offset,tt=y.length;for(Q<tt&&(tt=Q),Q-=tt,y.length-=tt;V[R++]=pt[et++],--tt;);y.length===0&&(y.mode=21);break;case 26:if(Q===0)break t;V[R++]=y.length,Q--,y.mode=21;break;case 27:if(y.wrap){for(;M<32;){if(j===0)break t;j--,A|=D[E++]<<M,M+=8}if(Y-=Q,I.total_out+=Y,y.total+=Y,Y&&(I.adler=y.check=y.flags?r(y.check,V,Y,R-Y):l(y.check,V,Y,R-Y)),Y=Q,(y.flags?A:k(A))!==y.check){I.msg="incorrect data check",y.mode=30;break}M=A=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A!==(4294967295&y.total)){I.msg="incorrect length check",y.mode=30;break}M=A=0}y.mode=29;case 29:z=1;break t;case 30:z=-3;break t;case 31:return-4;case 32:default:return d}return I.next_out=R,I.avail_out=Q,I.next_in=E,I.avail_in=j,y.hold=A,y.bits=M,(y.wsize||Y!==I.avail_out&&y.mode<30&&(y.mode<27||N!==4))&&X(I,I.output,I.next_out,Y-I.avail_out)?(y.mode=31,-4):(J-=I.avail_in,Y-=I.avail_out,I.total_in+=J,I.total_out+=Y,y.total+=Y,y.wrap&&Y&&(I.adler=y.check=y.flags?r(y.check,V,Y,I.next_out-Y):l(y.check,V,Y,I.next_out-Y)),I.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(J==0&&Y===0||N===4)&&z===v&&(z=-5),z)},o.inflateEnd=function(I){if(!I||!I.state)return d;var N=I.state;return N.window&&(N.window=null),I.state=null,v},o.inflateGetHeader=function(I,N){var y;return I&&I.state?(2&(y=I.state).wrap)==0?d:((y.head=N).done=!1,v):d},o.inflateSetDictionary=function(I,N){var y,D=N.length;return I&&I.state?(y=I.state).wrap!==0&&y.mode!==11?d:y.mode===11&&l(1,N,D,0)!==y.check?-3:X(I,N,D,D)?(y.mode=31,-4):(y.havedict=1,v):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,h,v,d,b,m,g,k){var x,$,T,L,B,w,U,W,q,X=k.bits,I=0,N=0,y=0,D=0,V=0,E=0,R=0,j=0,Q=0,A=0,M=null,J=0,Y=new s.Buf16(16),tt=new s.Buf16(16),et=null,pt=0;for(I=0;I<=15;I++)Y[I]=0;for(N=0;N<d;N++)Y[h[v+N]]++;for(V=X,D=15;1<=D&&Y[D]===0;D--);if(D<V&&(V=D),D===0)return b[m++]=20971520,b[m++]=20971520,k.bits=1,0;for(y=1;y<D&&Y[y]===0;y++);for(V<y&&(V=y),I=j=1;I<=15;I++)if(j<<=1,(j-=Y[I])<0)return-1;if(0<j&&(u===0||D!==1))return-1;for(tt[1]=0,I=1;I<15;I++)tt[I+1]=tt[I]+Y[I];for(N=0;N<d;N++)h[v+N]!==0&&(g[tt[h[v+N]]++]=N);if(w=u===0?(M=et=g,19):u===1?(M=l,J-=257,et=r,pt-=257,256):(M=a,et=c,-1),I=y,B=m,R=N=A=0,T=-1,L=(Q=1<<(E=V))-1,u===1&&852<Q||u===2&&592<Q)return 1;for(;;){for(U=I-R,q=g[N]<w?(W=0,g[N]):g[N]>w?(W=et[pt+g[N]],M[J+g[N]]):(W=96,0),x=1<<I-R,y=$=1<<E;b[B+(A>>R)+($-=x)]=U<<24|W<<16|q|0,$!==0;);for(x=1<<I-1;A&x;)x>>=1;if(x!==0?(A&=x-1,A+=x):A=0,N++,--Y[I]==0){if(I===D)break;I=h[v+g[N]]}if(V<I&&(A&L)!==T){for(R===0&&(R=V),B+=y,j=1<<(E=I-R);E+R<D&&!((j-=Y[E+R])<=0);)E++,j<<=1;if(Q+=1<<E,u===1&&852<Q||u===2&&592<Q)return 1;b[T=A&L]=V<<24|E<<16|B-m|0}}return A!==0&&(b[B+A]=I-R<<24|64<<16|0),k.bits=V,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(C){for(var O=C.length;0<=--O;)C[O]=0}var c=0,u=29,h=256,v=h+1+u,d=30,b=19,m=2*v+1,g=15,k=16,x=7,$=256,T=16,L=17,B=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],U=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],W=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(v+2));a(X);var I=new Array(2*d);a(I);var N=new Array(512);a(N);var y=new Array(256);a(y);var D=new Array(u);a(D);var V,E,R,j=new Array(d);function Q(C,O,Z,G,K){this.static_tree=C,this.extra_bits=O,this.extra_base=Z,this.elems=G,this.max_length=K,this.has_stree=C&&C.length}function A(C,O){this.dyn_tree=C,this.max_code=0,this.stat_desc=O}function M(C){return C<256?N[C]:N[256+(C>>>7)]}function J(C,O){C.pending_buf[C.pending++]=255&O,C.pending_buf[C.pending++]=O>>>8&255}function Y(C,O,Z){C.bi_valid>k-Z?(C.bi_buf|=O<<C.bi_valid&65535,J(C,C.bi_buf),C.bi_buf=O>>k-C.bi_valid,C.bi_valid+=Z-k):(C.bi_buf|=O<<C.bi_valid&65535,C.bi_valid+=Z)}function tt(C,O,Z){Y(C,Z[2*O],Z[2*O+1])}function et(C,O){for(var Z=0;Z|=1&C,C>>>=1,Z<<=1,0<--O;);return Z>>>1}function pt(C,O,Z){var G,K,it=new Array(g+1),ct=0;for(G=1;G<=g;G++)it[G]=ct=ct+Z[G-1]<<1;for(K=0;K<=O;K++){var rt=C[2*K+1];rt!==0&&(C[2*K]=et(it[rt]++,rt))}}function lt(C){var O;for(O=0;O<v;O++)C.dyn_ltree[2*O]=0;for(O=0;O<d;O++)C.dyn_dtree[2*O]=0;for(O=0;O<b;O++)C.bl_tree[2*O]=0;C.dyn_ltree[2*$]=1,C.opt_len=C.static_len=0,C.last_lit=C.matches=0}function H(C){8<C.bi_valid?J(C,C.bi_buf):0<C.bi_valid&&(C.pending_buf[C.pending++]=C.bi_buf),C.bi_buf=0,C.bi_valid=0}function at(C,O,Z,G){var K=2*O,it=2*Z;return C[K]<C[it]||C[K]===C[it]&&G[O]<=G[Z]}function ut(C,O,Z){for(var G=C.heap[Z],K=Z<<1;K<=C.heap_len&&(K<C.heap_len&&at(O,C.heap[K+1],C.heap[K],C.depth)&&K++,!at(O,G,C.heap[K],C.depth));)C.heap[Z]=C.heap[K],Z=K,K<<=1;C.heap[Z]=G}function S(C,O,Z){var G,K,it,ct,rt=0;if(C.last_lit!==0)for(;G=C.pending_buf[C.d_buf+2*rt]<<8|C.pending_buf[C.d_buf+2*rt+1],K=C.pending_buf[C.l_buf+rt],rt++,G===0?tt(C,K,O):(tt(C,(it=y[K])+h+1,O),(ct=w[it])!==0&&Y(C,K-=D[it],ct),tt(C,it=M(--G),Z),(ct=U[it])!==0&&Y(C,G-=j[it],ct)),rt<C.last_lit;);tt(C,$,O)}function P(C,O){var Z,G,K,it=O.dyn_tree,ct=O.stat_desc.static_tree,rt=O.stat_desc.has_stree,mt=O.stat_desc.elems,_t=-1;for(C.heap_len=0,C.heap_max=m,Z=0;Z<mt;Z++)it[2*Z]!==0?(C.heap[++C.heap_len]=_t=Z,C.depth[Z]=0):it[2*Z+1]=0;for(;C.heap_len<2;)it[2*(K=C.heap[++C.heap_len]=_t<2?++_t:0)]=1,C.depth[K]=0,C.opt_len--,rt&&(C.static_len-=ct[2*K+1]);for(O.max_code=_t,Z=C.heap_len>>1;1<=Z;Z--)ut(C,it,Z);for(K=mt;Z=C.heap[1],C.heap[1]=C.heap[C.heap_len--],ut(C,it,1),G=C.heap[1],C.heap[--C.heap_max]=Z,C.heap[--C.heap_max]=G,it[2*K]=it[2*Z]+it[2*G],C.depth[K]=(C.depth[Z]>=C.depth[G]?C.depth[Z]:C.depth[G])+1,it[2*Z+1]=it[2*G+1]=K,C.heap[1]=K++,ut(C,it,1),2<=C.heap_len;);C.heap[--C.heap_max]=C.heap[1],(function(wt,Lt){var Gt,Yt,ie,Nt,Ge,se,Xt=Lt.dyn_tree,yi=Lt.max_code,Pi=Lt.stat_desc.static_tree,Ro=Lt.stat_desc.has_stree,Oo=Lt.stat_desc.extra_bits,Nn=Lt.stat_desc.extra_base,ki=Lt.stat_desc.max_length,zi=0;for(Nt=0;Nt<=g;Nt++)wt.bl_count[Nt]=0;for(Xt[2*wt.heap[wt.heap_max]+1]=0,Gt=wt.heap_max+1;Gt<m;Gt++)ki<(Nt=Xt[2*Xt[2*(Yt=wt.heap[Gt])+1]+1]+1)&&(Nt=ki,zi++),Xt[2*Yt+1]=Nt,yi<Yt||(wt.bl_count[Nt]++,Ge=0,Nn<=Yt&&(Ge=Oo[Yt-Nn]),se=Xt[2*Yt],wt.opt_len+=se*(Nt+Ge),Ro&&(wt.static_len+=se*(Pi[2*Yt+1]+Ge)));if(zi!==0){do{for(Nt=ki-1;wt.bl_count[Nt]===0;)Nt--;wt.bl_count[Nt]--,wt.bl_count[Nt+1]+=2,wt.bl_count[ki]--,zi-=2}while(0<zi);for(Nt=ki;Nt!==0;Nt--)for(Yt=wt.bl_count[Nt];Yt!==0;)yi<(ie=wt.heap[--Gt])||(Xt[2*ie+1]!==Nt&&(wt.opt_len+=(Nt-Xt[2*ie+1])*Xt[2*ie],Xt[2*ie+1]=Nt),Yt--)}})(C,O),pt(it,_t,C.bl_count)}function p(C,O,Z){var G,K,it=-1,ct=O[1],rt=0,mt=7,_t=4;for(ct===0&&(mt=138,_t=3),O[2*(Z+1)+1]=65535,G=0;G<=Z;G++)K=ct,ct=O[2*(G+1)+1],++rt<mt&&K===ct||(rt<_t?C.bl_tree[2*K]+=rt:K!==0?(K!==it&&C.bl_tree[2*K]++,C.bl_tree[2*T]++):rt<=10?C.bl_tree[2*L]++:C.bl_tree[2*B]++,it=K,_t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4))}function z(C,O,Z){var G,K,it=-1,ct=O[1],rt=0,mt=7,_t=4;for(ct===0&&(mt=138,_t=3),G=0;G<=Z;G++)if(K=ct,ct=O[2*(G+1)+1],!(++rt<mt&&K===ct)){if(rt<_t)for(;tt(C,K,C.bl_tree),--rt!=0;);else K!==0?(K!==it&&(tt(C,K,C.bl_tree),rt--),tt(C,T,C.bl_tree),Y(C,rt-3,2)):rt<=10?(tt(C,L,C.bl_tree),Y(C,rt-3,3)):(tt(C,B,C.bl_tree),Y(C,rt-11,7));it=K,_t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4)}}a(j);var F=!1;function _(C,O,Z,G){Y(C,(c<<1)+(G?1:0),3),(function(K,it,ct,rt){H(K),J(K,ct),J(K,~ct),s.arraySet(K.pending_buf,K.window,it,ct,K.pending),K.pending+=ct})(C,O,Z)}o._tr_init=function(C){F||((function(){var O,Z,G,K,it,ct=new Array(g+1);for(K=G=0;K<u-1;K++)for(D[K]=G,O=0;O<1<<w[K];O++)y[G++]=K;for(y[G-1]=K,K=it=0;K<16;K++)for(j[K]=it,O=0;O<1<<U[K];O++)N[it++]=K;for(it>>=7;K<d;K++)for(j[K]=it<<7,O=0;O<1<<U[K]-7;O++)N[256+it++]=K;for(Z=0;Z<=g;Z++)ct[Z]=0;for(O=0;O<=143;)X[2*O+1]=8,O++,ct[8]++;for(;O<=255;)X[2*O+1]=9,O++,ct[9]++;for(;O<=279;)X[2*O+1]=7,O++,ct[7]++;for(;O<=287;)X[2*O+1]=8,O++,ct[8]++;for(pt(X,v+1,ct),O=0;O<d;O++)I[2*O+1]=5,I[2*O]=et(O,5);V=new Q(X,w,h+1,v,g),E=new Q(I,U,0,d,g),R=new Q(new Array(0),W,0,b,x)})(),F=!0),C.l_desc=new A(C.dyn_ltree,V),C.d_desc=new A(C.dyn_dtree,E),C.bl_desc=new A(C.bl_tree,R),C.bi_buf=0,C.bi_valid=0,lt(C)},o._tr_stored_block=_,o._tr_flush_block=function(C,O,Z,G){var K,it,ct=0;0<C.level?(C.strm.data_type===2&&(C.strm.data_type=(function(rt){var mt,_t=4093624447;for(mt=0;mt<=31;mt++,_t>>>=1)if(1&_t&&rt.dyn_ltree[2*mt]!==0)return l;if(rt.dyn_ltree[18]!==0||rt.dyn_ltree[20]!==0||rt.dyn_ltree[26]!==0)return r;for(mt=32;mt<h;mt++)if(rt.dyn_ltree[2*mt]!==0)return r;return l})(C)),P(C,C.l_desc),P(C,C.d_desc),ct=(function(rt){var mt;for(p(rt,rt.dyn_ltree,rt.l_desc.max_code),p(rt,rt.dyn_dtree,rt.d_desc.max_code),P(rt,rt.bl_desc),mt=b-1;3<=mt&&rt.bl_tree[2*q[mt]+1]===0;mt--);return rt.opt_len+=3*(mt+1)+5+5+4,mt})(C),K=C.opt_len+3+7>>>3,(it=C.static_len+3+7>>>3)<=K&&(K=it)):K=it=Z+5,Z+4<=K&&O!==-1?_(C,O,Z,G):C.strategy===4||it===K?(Y(C,2+(G?1:0),3),S(C,X,I)):(Y(C,4+(G?1:0),3),(function(rt,mt,_t,wt){var Lt;for(Y(rt,mt-257,5),Y(rt,_t-1,5),Y(rt,wt-4,4),Lt=0;Lt<wt;Lt++)Y(rt,rt.bl_tree[2*q[Lt]+1],3);z(rt,rt.dyn_ltree,mt-1),z(rt,rt.dyn_dtree,_t-1)})(C,C.l_desc.max_code+1,C.d_desc.max_code+1,ct+1),S(C,C.dyn_ltree,C.dyn_dtree)),lt(C),G&&H(C)},o._tr_tally=function(C,O,Z){return C.pending_buf[C.d_buf+2*C.last_lit]=O>>>8&255,C.pending_buf[C.d_buf+2*C.last_lit+1]=255&O,C.pending_buf[C.l_buf+C.last_lit]=255&Z,C.last_lit++,O===0?C.dyn_ltree[2*Z]++:(C.matches++,O--,C.dyn_ltree[2*(y[Z]+h+1)]++,C.dyn_dtree[2*M(O)]++),C.last_lit===C.lit_bufsize-1},o._tr_align=function(C){Y(C,2,3),tt(C,$,X),(function(O){O.bi_valid===16?(J(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})(C)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,h,v=1,d={},b=!1,m=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){x(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,L=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=L,T}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",$,!1):l.attachEvent("onmessage",$),function(T){l.postMessage(h+T,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(T){x(T.data)},function(T){u.port2.postMessage(T)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(T){var L=m.createElement("script");L.onreadystatechange=function(){x(T),L.onreadystatechange=null,c.removeChild(L),L=null},c.appendChild(L)}):function(T){setTimeout(x,0,T)},g.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var L=new Array(arguments.length-1),B=0;B<L.length;B++)L[B]=arguments[B+1];var w={callback:T,args:L};return d[v]=w,a(v),v++},g.clearImmediate=k}function k(T){delete d[T]}function x(T){if(b)setTimeout(x,0,T);else{var L=d[T];if(L){b=!0;try{(function(B){var w=B.callback,U=B.args;switch(U.length){case 0:w();break;case 1:w(U[0]);break;case 2:w(U[0],U[1]);break;case 3:w(U[0],U[1],U[2]);break;default:w.apply(r,U)}})(L)}finally{k(T),b=!1}}}}function $(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(h)===0&&x(+T.data.slice(h.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Gn<"u"?Gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Xo)),Xo.exports}var y1=b1();const k1=v1(y1),w1=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,x1=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function _1(t){const e=await k1.loadAsync(t),i={},n=[];let o="",s="";const l=[];e.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||x1.test(c)||c.includes("snippets/")){const u=await a.file.async("string");i[c]=u;const h=c.split("/");h.length>1&&(i[h.slice(1).join("/")]=u)}else if(w1.test(c)){const u=await a.file.async("uint8array"),h=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:h,data:u,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function S1(t,e){if(Object.keys(e).length===0)return t;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(e[s])return e[s];const r=s.replace(/^\.?\//,"");return e[r]?e[r]:e[l]?e[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=i(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function $a(t){try{if(typeof process<"u"&&typeof require<"u"){const e=require("fs");if(e.existsSync(t))return e.readFileSync(t,"utf-8")}}catch{}return null}function C1(t,e){const i=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(e==null?void 0:e.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,m]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(e!=null&&e.baseDir)try{const b=require("path");d.push(b.resolve(e.baseDir,r)),d.push(b.resolve(e.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const m=$a(b);if(m!==null){c=m;break}}}if(!c){const d=ga||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,g]of Object.entries(d))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=g;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+b[1].trimEnd()}}const h=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${u}
\`\`\``}function $1(t){let e=!1,i=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!i)e=!e;else if(o==='"'&&!e)i=!i;else if(o==="#"&&!e&&!i)return t.slice(0,n).trim()}return t.trim()}function Qn(t){const e={},i=t.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<i.length;){const h=i[n];if(!h.trim()){c.push(""),n++;continue}const d=h.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(h.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();e[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=$1(a),!a){let c=n+1;const u=[];let h=-1;for(;c<i.length;){const v=i[c],d=v.trim();if(!d||d.startsWith("#")){h!==-1&&u.push(""),c++;continue}const b=v.match(/^(\s+)/),m=b?b[1].length:0;if(h===-1)if(m>0)h=m;else break;if(m<h)break;u.push(v.slice(h)),c++}if(u.length>0){e[r]=Qn(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),e[r]=a}n++}return e}const I1=/^\s*```ya?ml([\s\S]*?)```/;function Nr(t){let e={},i=t.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=Qn(n[1]);if(Object.keys(s).length>0||!n[1].trim())return e=s,i=i.slice(n[0].length).trim(),{frontmatter:e,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(I1);if(o)e=Qn(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(e=Qn(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:e,content:i}}function A1(t){const e=t.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=e.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<e.length;l++){const a=e[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=e[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<e.length&&e[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let h=l+1;for(;h<e.length&&!e[h].trimStart().startsWith(u);h++);h<e.length&&(l=h)}}return n<e.length&&s(e.length),i}function to(t,e={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=e;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const h=A1(u),v={};let d="",b="",m=0;if(h.length>0){const q=h[0],X=Nr(q),I=Object.keys(X.frontmatter).length>0,N=X.content.length>0;I&&!N&&h.length>1?(m=1,g(X.frontmatter)):I&&g(X.frontmatter)}function g(q){d=q.title||"",q.theme&&(v[wn]=String(q.theme)),q.aspectRatio&&(v[xn]=String(q.aspectRatio)),q.highlighter&&(v[Gr]=String(q.highlighter)),q.transition&&(v[_n]=String(q.transition)),q.colorSchema&&(v[Zr]=String(q.colorSchema)),q.layout&&(v[gt]=String(q.layout)),q.background&&(v[Ut]=String(q.background)),q.image&&(v[Ee]=String(q.image)),q.class&&(v[Wi]=String(q.class));for(const[X,I]of Object.entries(q))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(v[`custom-slidev-${X}`]=typeof I=="object"?JSON.stringify(I):String(I))}const k=[];let x=0,$=0,T=0,L=0;const B=new Set,w={};let U=1;for(let q=m;q<h.length;q++){const X=h[q],{frontmatter:I,content:N}=Nr(X),y=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),D=I.src||(y?y[1]:void 0);if(D){const H=String(D).trim().replace(/^['"]|['"]$/g,"");let at=c[H]||c[H.replace(/^\.\//,"")]||c[`pages/${H.replace(/^.*pages\//,"")}`];if(!at){const S=H.replace(/^\.\//,""),P=[];if(e.baseDir)try{const p=require("path");P.push(p.resolve(e.baseDir,S)),P.push(p.resolve(e.baseDir,H))}catch{}try{const p=require("path");P.push(p.resolve(process.cwd(),S)),P.push(p.resolve(process.cwd(),H))}catch{}for(const p of P){const z=$a(p);if(z!==null){at=z;break}}}const ut={};I.layout&&(ut[gt]=String(I.layout)),I.transition&&(ut[te]=String(I.transition)),I.background&&(ut[Ut]=String(I.background)),I.image&&(ut[Ee]=String(I.image)),I.class&&(ut[Wi]=String(I.class));for(const[S,P]of Object.entries(I))["src","layout","transition","background","image","class"].includes(S)||(ut[`custom-slidev-${S}`]=typeof P=="object"?JSON.stringify(P):String(P));if(at){const S=to(at,{...e,virtualFiles:c});for(const P of S.slides){P.pageIndex=U++,P.pageAttrs={...ut,...P.pageAttrs},k.push(P);const p=P.pageAttrs[gt]||"default";w[p]=(w[p]||0)+1}continue}else{k.push({pageIndex:U++,pageAttrs:{...ut,"custom-slidev-src":H},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${H}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const S=ut[gt]||"default";w[S]=(w[S]||0)+1;continue}}const V={};I.layout&&(V[gt]=String(I.layout)),I.transition&&(V[te]=String(I.transition)),I.background&&(V[Ut]=String(I.background)),I.image&&(V[Ee]=String(I.image)),I.class&&(V[Wi]=String(I.class));for(const[H,at]of Object.entries(I))["layout","transition","background","image","class"].includes(H)||(V[`custom-slidev-${H}`]=typeof at=="object"?JSON.stringify(at):String(at));let E=N;const R=[];let j=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,H=>{const at=`__CODE_TOKEN_NOTE_${R.length}__`;return R.push(H),at});j=j.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,H=>{const at=`__CODE_TOKEN_NOTE_${R.length}__`;return R.push(H),at});let Q="";const A=Array.from(j.matchAll(/<!--([\s\S]*?)-->/g));if(A.length>0){const H=A[A.length-1],at=j.slice(H.index+H[0].length).trim();if(!at||!at.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const S=H[1].trim();S.startsWith("TODO:")||(Q=S,x++),i&&(j=j.slice(0,H.index).trimEnd()+j.slice(H.index+H[0].length))}}i&&(j=j.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let H=0;H<R.length;H++)j=j.replace(`__CODE_TOKEN_NOTE_${H}__`,R[H]);if(E=j,Q){for(let ut=0;ut<R.length;ut++)Q=Q.replace(`__CODE_TOKEN_NOTE_${ut}__`,R[ut]);const at=`> [!NOTE] 💡 演讲备注
${Q.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${at}`:at}let M=!1;if(/<style\b/i.test(E)){M=!0;const H=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(H){for(const at of H){const ut=at.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${ut}`:ut}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const J=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);J&&($+=J.length);const Y=E.match(/```\w+\s+\{[^}]+\}/g);Y&&(T+=Y.length);const tt=E.match(/::\w+::|<template\s+#[^>]+>/g);if(tt&&(L+=tt.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,H=>C1(H,{...e,virtualFiles:c})||H),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=lf(E)),a){let H=E.trim(),at="";const ut=H.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(at=H.slice(ut),H=H.slice(0,ut).trim()),(I.layout==="image-left"||I.layout==="image-right")&&I.image){const S=String(I.image).trim(),P=I.layout==="image-left"?"image-left":"image-right",p=`![配图](${S})
{: custom-slidev-layout="${P}" }`;I.layout==="image-left"?H=`{{{col

${p}

${H}

}}}`:H=`{{{col

${H}

${p}

}}}`}if(I.background){const P=`![背景图](${String(I.background).trim()})
{: custom-slidev-role="background" }`;H=H?`${P}

${H}`:P}E=at?`${H}

${at}`:H}const et=B1(E);V[Ut]&&et.push(V[Ut]),V[Ee]&&et.push(V[Ee]);for(const H of et)B.add(H);const pt=/<[A-Z][a-zA-Z0-9]+/.test(E),lt=V[gt]||(U===1?v[gt]||"cover":"default");w[lt]=(w[lt]||0)+1,k.push({pageIndex:U++,pageAttrs:V,notes:Q,rawMarkdown:E,hasVueComponent:pt,hasStyleTag:M,assetReferences:et})}if(!d&&k.length>0){const q=k[0].rawMarkdown.match(/^#\s+(.+)$/m);q&&(d=q[1].trim())}b&&(v["custom-slidev-custom-css"]=b);let W=k.map(q=>`---

${q.rawMarkdown}`).join(`

`);return W.trimStart().startsWith("---")||(W=`---

${W.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:v,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:$,totalShikiHighlights:T,totalSlots:L,discoveredAssets:Array.from(B),layoutDistribution:w},flattenedMarkdown:W,customCss:b}}function B1(t){const e=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&e.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&e.push(s)}return e}function Ia(t){if(!t)return!1;const e=String(t.type||"").toLowerCase(),i=String(t.markdown||"").trim(),n=String(t.content||"").trim();return e==="tb"||e==="thematic-break"||e==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function T1(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function E1(t,e,i=Et){const n=t.filter(Ia);let o=0;if(n.length>=e.length)for(let s=0;s<e.length;s++){const l=e[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<e.length;s++){const l=e[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function M1(t,e=Et){let i=!1,n=0;for(const o of t){if(Ia(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await e(o.id,{[Ct]:"right"}).catch(()=>{}),n++)}return n}async function D1(t,e,i=Vr){const n={};if(!e||e.length===0)return n;const o=[];for(const s of e){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&S1(t,n),n}async function L1(t){var T;const{presentation:e,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Vr,u=a.createDocFn||mc,h=a.setAttrsFn||Et,v=a.getChildBlocksFn||so,d=a.openTabFn||ht.openTab,b=a.showMessageFn||ht.showMessage;s&&o.length>0&&await D1(e,o,c);const m=T1(n),g=`/${m}`,k=await u(i,g,e.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((T=e.slides[0])==null?void 0:T.pageAttrs)||{};await h(k,{...x,...e.docRootAttrs});const $=await v(k).catch(()=>[]);return Array.isArray($)&&$.length>0&&(await E1($,e.slides,h),await M1($,h)),b(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function R1(t){const e=vt("file"),i=vt(!1),n=vt(!1),o=vt(""),s=vt(null),l=vt(null),r=vt(""),a=vt(0),c=vt(""),u=vt([]),h=vt(null),v=vt(""),d=vt([]),b=vt(""),m=vt(!0),g=vt(!0),k=vt(!0),x=vt(!0),$=St(()=>{const V=a.value;if(V===0)return"0 B";const E=1024,R=["B","KB","MB","GB"],j=Math.floor(Math.log(V)/Math.log(E));return`${(V/E**j).toFixed(1)} ${R[j]}`}),T=St(()=>{var V;return((V=h.value)==null?void 0:V.docRootAttrs["custom-slidev-theme"])||"default"}),L=St(()=>{var V;return u.value.length>0?u.value.length:((V=h.value)==null?void 0:V.stats.discoveredAssets.length)||0}),B=St(()=>{var E;const V=((E=h.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(V).map(([R,j])=>({name:R,count:j}))});async function w(V=hc){try{const E=await V();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(d.value=E.notebooks.filter(R=>!R.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function U(){var V;(V=s.value)==null||V.click()}function W(){l.value=null,r.value="",a.value=0,h.value=null,u.value=[],o.value=""}async function q(V){o.value="",l.value=V,r.value=V.name,a.value=V.size;try{if(V.name.toLowerCase().endsWith(".zip")){const R=await V.arrayBuffer(),j=await _1(R);if(!j.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=j.assets;const Q=to(j.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:j.virtualFiles});h.value=Q,v.value=Q.docTitle||V.name.replace(/\.zip$/i,"")}else{const R=await V.text();u.value=[];const j=V.path||"",Q=j?j.replace(/[\\/][^\\/]+$/,""):"",A=to(R,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Q||void 0});h.value=A,v.value=A.docTitle||V.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),o.value=`解析文件失败: ${E.message||String(E)}`}}function X(){if(o.value="",!c.value.trim()){h.value=null;return}try{const V=to(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});h.value=V,v.value=V.docTitle||"Slidev 演示文稿"}catch(V){o.value=`解析 Markdown 源码失败: ${V.message||String(V)}`}}async function I(){l.value?await q(l.value):c.value&&X()}async function N(V){const E=V.target;E.files&&E.files[0]&&await q(E.files[0])}async function y(V){var E;i.value=!1,(E=V.dataTransfer)!=null&&E.files&&V.dataTransfer.files[0]&&await q(V.dataTransfer.files[0])}async function D(V=t){if(h.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await L1({presentation:h.value,notebookId:b.value,docTitle:v.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:x.value,plugin:V})}catch(E){console.error("导入 Slidev 演示失败:",E),o.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:e,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:h,customDocTitle:v,notebooks:d,selectedNotebookId:b,optCleanHtml:m,optStripNotes:g,optUploadAssets:k,optAutoPreview:x,formattedFileSize:$,currentTheme:T,extractedAssetsCount:L,layoutChips:B,fetchNotebooks:w,triggerFileInput:U,clearFile:W,processFile:q,onFileSelected:N,onFileDrop:y,onTextChange:X,reprocessCurrentInput:I,handleConfirmImport:D}}const O1={class:"spm-import-dialog"},P1={class:"spm-tabs-header"},z1={class:"spm-dialog-body"},N1={key:0,class:"spm-file-section"},F1={key:0,class:"spm-dropzone-prompt"},H1={class:"spm-dropzone-icon"},j1={key:1,class:"spm-dropzone-active"},U1={class:"spm-file-badge"},W1={class:"spm-file-size"},V1={key:1,class:"spm-text-section"},q1={key:2,class:"spm-error-banner"},K1={key:3,class:"spm-preview-card"},G1={class:"spm-preview-card__header"},Z1={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Y1={class:"spm-config-grid"},J1={class:"spm-form-item"},X1={class:"spm-form-item"},Q1=["value"],ty={class:"spm-stats-grid"},ey={class:"spm-stat-box"},iy={class:"spm-stat-value"},ny={class:"spm-stat-box"},oy={class:"spm-stat-value"},sy={class:"spm-stat-box"},ry={class:"spm-stat-value"},ly={class:"spm-stat-box"},ay={class:"spm-stat-value"},cy={key:0,class:"spm-chips-row"},dy={class:"spm-options-group"},uy={class:"spm-checkbox-label"},fy={class:"spm-checkbox-label"},py={class:"spm-checkbox-label"},hy={class:"spm-checkbox-label"},my={class:"spm-dialog-footer"},gy=["disabled"],vy=["disabled"],by={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},yy={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},ky=Ce({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:e}){const i=e,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:h,parsedPresentation:v,customDocTitle:d,notebooks:b,selectedNotebookId:m,optCleanHtml:g,optStripNotes:k,optUploadAssets:x,optAutoPreview:$,formattedFileSize:T,currentTheme:L,layoutChips:B,fetchNotebooks:w,triggerFileInput:U,clearFile:W,onFileSelected:q,onFileDrop:X,onTextChange:I,reprocessCurrentInput:N,handleConfirmImport:y}=R1(n);On(async()=>{await w()});async function D(){const E=await y();E&&(i("success",{docId:E}),i("close"))}function V(){i("close")}return(E,R)=>(nt(),st("div",{class:"spm-modal-overlay",onClick:Me(V,["self"])},[f("div",O1,[f("div",{class:"spm-dialog-header"},[R[18]||(R[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlidev"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:V},"✕")]),f("div",P1,[f("button",{class:At(["spm-tab-btn",{active:bt(o)==="file"}]),onClick:R[0]||(R[0]=j=>o.value="file")},[dt(ft,{name:"package"}),R[19]||(R[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:At(["spm-tab-btn",{active:bt(o)==="text"}]),onClick:R[1]||(R[1]=j=>o.value="text")},[dt(ft,{name:"notes"}),R[20]||(R[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",z1,[bt(o)==="file"?(nt(),st("div",N1,[f("div",{class:At(["spm-dropzone",{dragover:bt(s),"has-file":!!bt(c)}]),onDragover:R[4]||(R[4]=Me(j=>s.value=!0,["prevent"])),onDragleave:R[5]||(R[5]=Me(j=>s.value=!1,["prevent"])),onDrop:R[6]||(R[6]=Me((...j)=>bt(X)&&bt(X)(...j),["prevent"])),onClick:R[7]||(R[7]=(...j)=>bt(U)&&bt(U)(...j))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:R[2]||(R[2]=(...j)=>bt(q)&&bt(q)(...j))},null,544),bt(c)?(nt(),st("div",j1,[f("span",U1,[dt(ft,{name:"notes"}),$e(" "+xt(bt(c)),1)]),f("span",W1,"("+xt(bt(T))+")",1),f("button",{class:"spm-btn-text",onClick:R[3]||(R[3]=Me((...j)=>bt(W)&&bt(W)(...j),["stop"]))},"更换文件")])):(nt(),st("div",F1,[f("span",H1,[dt(ft,{name:"folder",style:{"font-size":"32px"}})]),R[21]||(R[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),R[22]||(R[22]=f("p",{class:"spm-dropzone-hint"},[$e(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),$e("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(nt(),st("div",V1,[Te(f("textarea",{"onUpdate:modelValue":R[8]||(R[8]=j=>Jt(u)?u.value=j:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:R[9]||(R[9]=(...j)=>bt(I)&&bt(I)(...j))},null,544),[[yo,bt(u)]])])),bt(r)?(nt(),st("div",q1," ⚠️ "+xt(bt(r)),1)):Ot("",!0),bt(v)?(nt(),st("div",K1,[f("div",G1,[f("span",Z1,[dt(ft,{name:"sparkles"}),R[23]||(R[23]=$e(" 演示解析摘要",-1))]),R[24]||(R[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",Y1,[f("div",J1,[R[25]||(R[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(f("input",{"onUpdate:modelValue":R[10]||(R[10]=j=>Jt(d)?d.value=j:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[yo,bt(d)]])]),f("div",X1,[R[26]||(R[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(f("select",{"onUpdate:modelValue":R[11]||(R[11]=j=>Jt(m)?m.value=j:null),class:"spm-select"},[(nt(!0),st(Kt,null,xe(bt(b),j=>(nt(),st("option",{key:j.id,value:j.id},xt(j.name),9,Q1))),128))],512),[[Fu,bt(m)]])])]),f("div",ty,[f("div",ey,[f("span",iy,xt(bt(v).totalSlides),1),R[27]||(R[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",ny,[f("span",oy,xt(bt(L)),1),R[28]||(R[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",sy,[f("span",ry,xt(bt(v).stats.totalNotes),1),R[29]||(R[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",ly,[f("span",ay,xt(bt(h)),1),R[30]||(R[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),bt(B).length>0?(nt(),st("div",cy,[R[31]||(R[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(nt(!0),st(Kt,null,xe(bt(B),j=>(nt(),st("span",{key:j.name,class:"spm-chip-badge"},xt(j.name)+": "+xt(j.count),1))),128))])):Ot("",!0),f("div",dy,[f("label",uy,[Te(f("input",{"onUpdate:modelValue":R[12]||(R[12]=j=>Jt(g)?g.value=j:null),type:"checkbox",onChange:R[13]||(R[13]=(...j)=>bt(N)&&bt(N)(...j))},null,544),[[qn,bt(g)]]),R[32]||(R[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",fy,[Te(f("input",{"onUpdate:modelValue":R[14]||(R[14]=j=>Jt(k)?k.value=j:null),type:"checkbox",onChange:R[15]||(R[15]=(...j)=>bt(N)&&bt(N)(...j))},null,544),[[qn,bt(k)]]),R[33]||(R[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",py,[Te(f("input",{"onUpdate:modelValue":R[16]||(R[16]=j=>Jt(x)?x.value=j:null),type:"checkbox"},null,512),[[qn,bt(x)]]),R[34]||(R[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",hy,[Te(f("input",{"onUpdate:modelValue":R[17]||(R[17]=j=>Jt($)?$.value=j:null),type:"checkbox"},null,512),[[qn,bt($)]]),R[35]||(R[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ot("",!0)]),f("div",my,[f("button",{class:"spm-btn-secondary",disabled:bt(l),onClick:V}," 取消 ",8,gy),f("button",{class:"spm-btn-primary",disabled:!bt(v)||bt(l),onClick:D},[bt(l)?(nt(),st("span",by,[dt(ft,{name:"refresh"}),R[36]||(R[36]=$e(" 正在导入生成中...",-1))])):(nt(),st("span",yy,[dt(ft,{name:"rocket"}),R[37]||(R[37]=$e(" 确认导入思源笔记",-1))]))],8,vy)])])]))}}),wy=ze(ky,[["__scopeId","data-v-ce8dffdc"]]);function Aa(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function xy(t,e){var r;if(!t||t.length===0)return null;const i=e.activeBlockId||"",n=e.currentTopBlockId||i,o=e.currentPageDividerId||"",s=e.activeBlockType||"";if(Aa(s)&&i){let a=t.find(c=>c.startBlockId===i);if(a||(a=t.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===i}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===o}),a))return a}if(i){let a=t.find(u=>u.startBlockId===i);if(a||(a=t.find(u=>{var h,v;return((h=u.blocks)==null?void 0:h.some(d=>d.id===i))||((v=u.allBlockIds)==null?void 0:v.includes(i))}),a)||n&&n!==i&&(a=t.find(u=>{var h,v;return((h=u.blocks)==null?void 0:h.some(d=>d.id===n))||((v=u.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=t.find(u=>{var h;return(h=u.noteBlocks)==null?void 0:h.some(v=>v.id===i||v.id===n)}),a))return a;const c=(r=e.activeBlockAttrs)==null?void 0:r[Ct];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var h,v;return((h=u.frontmatter)==null?void 0:h.layout)==="three-cols-header"||((v=u.blocks)==null?void 0:v.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Fr(t,e){const i=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Ba(t,e){const i=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(e&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await e(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Fr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Fr(t),isAiGenerated:!1}}async function _y(t,e){return(await Ba(t,e)).notes}function Hr(t,e){if(!e)return!1;if(t===e||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function Sy(t){const e=vt(!1);let i=null;function n(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function o(A){var tt;const M=t.activeBlockId.value||t.currentDocId.value;if(!M)return;for(const[et,pt]of Object.entries(A))t.activeBlockAttrs.value[et]=pt;Mt.setBlockAttrOverride(M,A),Zt(M,A);const J=(tt=t.parentContainerId)==null?void 0:tt.value,Y=!!(J&&Hr(M,J));if(jt in A&&Y&&J){const et=A[jt];t.parentContainerClicks&&(t.parentContainerClicks.value=et),Mt.setBlockAttrOverride(J,{[jt]:et}),Zt(J,{[jt]:et}),Et(J,{[jt]:et}).catch(()=>{})}if(gt in A){const et=A[gt];t.currentPageDividerLayout.value=et,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=et)}if(le in A){const et=A[le];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=et)}n("保存中...");try{await Et(M,A),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(A,M){var et;const J=t.activeBlockId.value||t.currentDocId.value;if(!J)return;t.activeBlockAttrs.value[A]=M,Mt.setBlockAttrOverride(J,{[A]:M}),Zt(J,{[A]:M});const Y=(et=t.parentContainerId)==null?void 0:et.value,tt=!!(Y&&Hr(J,Y));A===jt&&tt&&Y&&(t.parentContainerClicks&&(t.parentContainerClicks.value=M),Mt.setBlockAttrOverride(Y,{[jt]:M}),Zt(Y,{[jt]:M}),Et(Y,{[jt]:M}).catch(()=>{})),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(J,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const A=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(A?t.activeBlockId.value:"")||t.currentDocId.value}async function r(A,M){const J=l();if(J){J===t.activeBlockId.value&&(t.activeBlockAttrs.value[A]=M),Mt.setBlockAttrOverride(J,{[A]:M}),Zt(J,{[A]:M}),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(J,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(A,M){const J=l();if(!J)return;const Y={[gt]:A,[le]:M};J===t.activeBlockId.value&&(t.activeBlockAttrs.value[gt]=A,t.activeBlockAttrs.value[le]=M),t.currentPageDividerLayout.value=A,Mt.setBlockAttrOverride(J,Y),Zt(J,Y),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=A,t.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await Et(J,Y),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(A,M){var Y;const J=t.currentDocId.value||t.activeBlockId.value;if(J){t.activeBlockAttrs.value[A]=M,Mt.setBlockAttrOverride(J,{[A]:M}),Zt(J,{[A]:M}),(Y=t.latestDoc.value)!=null&&Y.config&&(A===wn&&(t.latestDoc.value.config.theme=M),A===xn&&(t.latestDoc.value.config.aspectRatio=M),A===_n&&(t.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await Et(J,{[A]:M}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(J)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Bi]:"true",[ji]:"true"}),t.activeBlockAttrs.value[Bi]="true",t.activeBlockAttrs.value[ji]="true"):(await s(Bi,"false"),t.activeBlockAttrs.value[Bi]="false")}async function h(){const A=t.videoLoop.value?"false":"true";await s(ro,A)}async function v(){const A=t.videoMuted.value?"false":"true";await s(ji,A)}async function d(){const A=t.videoControls.value?"false":"true";await s(lo,A)}async function b(A){var et;const M=t.activeBlockId.value;if(!M)return;const J=t.rawSnippet.value||"",Y=vi(J)||"",tt=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const pt={[qt]:"background",[gt]:""};tt&&Y&&(t.pageBackground.value=Y,await Et(tt,{[Ut]:Y}).catch(()=>{}),Mt.setBlockAttrOverride(tt,{[Ut]:Y}),Zt(tt,{[Ut]:Y}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=Y)),await o(pt)}else(A===ao||A===co)&&await o({[gt]:A,[qt]:""});else{const pt={[qt]:"",[gt]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(pt[Ut]=""),tt&&Y&&t.pageBackground.value===Y&&(t.pageBackground.value="",await Et(tt,{[Ut]:""}).catch(()=>{}),Mt.setBlockAttrOverride(tt,{[Ut]:""}),Zt(tt,{[Ut]:""}),(et=t.targetSlide.value)!=null&&et.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(pt),typeof document<"u"){const lt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),H=lt==null?void 0:lt.closest('[data-type="NodeListItem"]'),at=H==null?void 0:H.getAttribute("data-node-id");if(at&&at!==M){const ut={[gt]:"",[qt]:""};Zt(at,ut),Mt.setBlockAttrOverride(at,ut),await Et(at,ut).catch(()=>{})}}}}async function m(A){var at,ut,S,P,p,z,F,_;const Y=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map(C=>`> ${C}`).join(`
`)}
{: custom-slidev-note="true"}`,tt=((at=t.latestDoc.value)==null?void 0:at.slides)||[],et=t.targetSlide.value,pt=et?tt.findIndex(C=>C===et):-1;let lt=null;if(pt!==-1&&pt<tt.length-1){const C=tt[pt+1];lt=await $i("markdown",Y,C.startBlockId)}else{const C=((ut=et==null?void 0:et.noteBlocks)==null?void 0:ut.slice(-1)[0])||((S=et==null?void 0:et.blocks)==null?void 0:S.slice(-1)[0]),O=(C==null?void 0:C.id)||(et==null?void 0:et.startBlockId);O?lt=await $i("markdown",Y,void 0,O):lt=await es("markdown",Y,t.currentDocId.value)}const H=((z=(p=(P=lt==null?void 0:lt[0])==null?void 0:P.doOperations)==null?void 0:p[0])==null?void 0:z.id)||((F=lt==null?void 0:lt[0])==null?void 0:F.id);return H&&(await Et(H,{[ne]:"true"}),Mt.setBlockAttrOverride(H,{[ne]:"true"}),Li(H,(_=t.plugin)==null?void 0:_.app)),t.plugin&&await t.plugin.compileCurrentDocument(),H}async function g(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){n("取消中...");try{await Et(A,{[ne]:"","slidev-note":""}),Mt.setBlockAttrOverride(A,{[ne]:"","slidev-note":""}),Zt(A,{[ne]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=t.rawSnippet.value;try{const et=await gc(A);et!=null&&et.kramdown&&(M=et.kramdown)}catch{}const tt=`> [!NOTE] 💡 演讲备注
${(fa(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(et=>`> ${et}`).join(`
`)}
{: custom-slidev-note="true"}`;await Xs("markdown",tt,A),await Et(A,{[ne]:"true"}),Mt.setBlockAttrOverride(A,{[ne]:"true"}),Zt(A,{[ne]:"true"}),t.activeBlockAttrs.value[ne]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await m(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){ht.showMessage("插入讲稿备注块失败"),console.error(A)}}function x(){var J;const A=t.currentSlideNoteBlockId.value;if(!A){ht.showMessage("未找到本页关联的讲稿备注块");return}Li(A,(J=t.plugin)==null?void 0:J.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function $(){var J;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await Ba(A,qr);if(M.notes){const Y=t.currentSlideNoteBlockId.value;if(Y){const tt=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(et=>`> ${et}`).join(`
`)}
{: custom-slidev-note="true"}`;await Xs("markdown",tt,Y),await Et(Y,{[ne]:"true"}),Mt.setBlockAttrOverride(Y,{[ne]:"true"}),Li(Y,(J=t.plugin)==null?void 0:J.app)}else await m(M.notes);M.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function T(){var Y;if(e.value)return;const A=((Y=t.latestDoc.value)==null?void 0:Y.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=A.map((tt,et)=>({slide:tt,idx:et})).filter(({slide:tt})=>{var lt;const et=Array.isArray(tt.noteBlocks)&&tt.noteBlocks.length>0,pt=!!((lt=tt.notes)!=null&&lt.trim());return!et&&!pt});if(M.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const J=M.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${J} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var et,pt,lt,H,at,ut;if(e.value)return;e.value=!0,ht.showMessage("正在批量追加讲稿块...");let tt=0;try{const p=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(z=>`> ${z}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:z,idx:F}of M)try{let _=null;if(F<A.length-1){const O=A[F+1];_=await $i("markdown",p,O.startBlockId)}else{const O=((et=z==null?void 0:z.noteBlocks)==null?void 0:et.slice(-1)[0])||((pt=z==null?void 0:z.blocks)==null?void 0:pt.slice(-1)[0]),Z=(O==null?void 0:O.id)||(z==null?void 0:z.startBlockId);Z?_=await $i("markdown",p,void 0,Z):_=await es("markdown",p,t.currentDocId.value)}const C=((at=(H=(lt=_==null?void 0:_[0])==null?void 0:lt.doOperations)==null?void 0:H[0])==null?void 0:at.id)||((ut=_==null?void 0:_[0])==null?void 0:ut.id);C&&(await Et(C,{[ne]:"true"}),Mt.setBlockAttrOverride(C,{[ne]:"true"})),tt++}catch(_){console.error(`[SiYuanSlidev] 为第 ${F+1} 页追加讲稿块失败:`,_)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${tt} 页追加讲稿备注块`)}catch(S){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",S),ht.showMessage("批量追加讲稿块时出现异常")}finally{e.value=!1}})}async function L(){var tt;if(e.value)return;const A=((tt=t.latestDoc.value)==null?void 0:tt.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=[];for(const et of A)if(et.noteBlocks&&et.noteBlocks.length>0)for(const pt of et.noteBlocks)pt.id&&M.push({id:pt.id,pageIndex:et.pageIndex});if(M.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const J=new Set(M.map(et=>et.pageIndex)).size,Y=M.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${Y} 个讲稿备注块（涉及 ${J} 页），删除后无法撤销。是否确认继续？`,async()=>{if(e.value)return;e.value=!0,ht.showMessage("正在批量删除讲稿块...");let et=0;try{for(const pt of M)try{await Qs(pt.id),Mt.clearBlockAttrOverride(pt.id),et++}catch(lt){console.error(`[SiYuanSlidev] 删除讲稿块 ${pt.id} 失败:`,lt)}t.activeBlockId.value&&M.some(pt=>pt.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${et} 个讲稿备注块`)}catch(pt){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",pt),ht.showMessage("批量删除讲稿块时出现异常")}finally{e.value=!1}})}function B(){t.elemClick.value?s(jt,""):s(jt,"+1")}function w(A){s(jt,A)}function U(A){s(Ve,A)}function W(A){(t.activeBlockAttrs.value[Ct]||"")===A?s(Ct,""):s(Ct,A)}function q(A){t.elemShikiLines.value=A,s(Ri,A)}function X(A){t.elemMaxHeight.value=A,s(Sn,A)}async function I(){const A=t.currentSlideLayout.value==="three-cols-header";await s(Ct,A?"col-1":"left"),ht.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function N(){const A=t.activeBlockId.value;if(!A)return;const M={[jt]:"",[Ve]:"",[Ct]:"",[Ri]:"",[Sn]:"",[ne]:"","slidev-note":"",[gt]:"",[le]:"",[qt]:"",[te]:"",[Ut]:"",[Ee]:"",[Bi]:"",[ro]:"",[ji]:"",[lo]:""};if(Zt(A,M),await Et(A,M),Mt.clearBlockAttrOverride(A),typeof document<"u"){const J=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),Y=J==null?void 0:J.closest('[data-type="NodeListItem"]'),tt=Y==null?void 0:Y.getAttribute("data-node-id");tt&&tt!==A&&(Zt(tt,M),await Et(tt,M).catch(()=>{}),Mt.clearBlockAttrOverride(tt))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function y(){if(t.activeBlockId.value)try{await $i("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function D(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await $i("markdown","---",void 0,A),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function V(){if(t.activeBlockId.value)try{await Qs(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function E(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const A=_a(t.latestDoc.value);Sa("presentation.html",A)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function R(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ca(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function j(){var A,M;try{let J=null;if(typeof document<"u"){const tt=t.activeBlockId.value;if(tt){const et=document.querySelector(`.protyle-wysiwyg [data-node-id="${tt}"]`);et&&(J=et.getAttribute("data-type")==="NodeSuperBlock"?et:et.closest('[data-type="NodeSuperBlock"]'))}if(!J){const et=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(et){const pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${et}"]`);if(pt){let lt=pt.nextElementSibling;for(;lt&&!(lt.getAttribute("data-type")==="NodeThematicBreak"||(A=lt.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));){const H=lt.getAttribute("data-type")==="NodeSuperBlock"?lt:lt.querySelector('[data-type="NodeSuperBlock"]');if(H){J=H;break}lt=lt.nextElementSibling}}}else{const pt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),lt=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const H of lt)if(!pt||H.compareDocumentPosition(pt)&Node.DOCUMENT_POSITION_FOLLOWING){J=H;break}}}}const Y=[];if(J){const tt=Array.from(J.querySelectorAll(":scope > [data-node-id]"));for(const et of tt){const pt=et.getAttribute("data-node-id");pt&&(Y.push(pt),et.removeAttribute("style"))}}else if((M=t.targetSlide.value)!=null&&M.blocks){for(const tt of t.targetSlide.value.blocks)if(tt.children&&tt.children.length>=2){for(const et of tt.children)et.id&&Y.push(et.id);break}}if(Y.length>0)for(const tt of Y)await Et(tt,{style:""}).catch(()=>{});await r(le,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(J){console.error("[useInspectorActions] resetSuperBlockWidth error:",J),ht.showMessage("重置超级块比例失败")}}async function Q(){var A,M,J;try{let Y=null;if(typeof document<"u"){const et=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:""),pt=t.activeBlockId.value;let lt=[];if(et){const ut=document.querySelector(`.protyle-wysiwyg [data-node-id="${et}"]`);if(ut){let S=ut.nextElementSibling;for(;S&&!(S.getAttribute("data-type")==="NodeThematicBreak"||(A=S.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));)lt.push(S),S=S.nextElementSibling}}else{const ut=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),S=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const P of S)if(!ut||P.compareDocumentPosition(ut)&Node.DOCUMENT_POSITION_FOLLOWING)lt.push(P);else break}const H=[];let at;for(const ut of lt){const S=ut.getAttribute("data-type");S==="NodeHeading"&&(at=ut.getAttribute("data-node-id")||void 0);const P=[];S==="NodeSuperBlock"?P.push(ut):P.push(...Array.from(ut.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const p of P){if((p.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const F=p.getAttribute("data-node-id")||"";let _=[];const C=Array.from(p.querySelectorAll('[data-type="NodeListItem"]'));if(C.length===4&&(_=C.map(O=>O.getAttribute("data-node-id")).filter(Boolean)),_.length!==4){const O=Array.from(p.querySelectorAll(":scope > [data-node-id]"));O.length===4&&(_=O.map(Z=>Z.getAttribute("data-node-id")).filter(Boolean))}_.length===4&&H.push({sbId:F,itemIds:_,headerId:at})}}H.length>0&&(pt&&(Y=H.find(ut=>{if(ut.sbId===pt||ut.itemIds.includes(pt))return!0;const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${ut.sbId}"]`),P=document.querySelector(`.protyle-wysiwyg [data-node-id="${pt}"]`);return!!(S&&P&&S.contains(P))})||null),Y||(Y=H[0]))}if(!Y&&((M=t.targetSlide.value)!=null&&M.blocks)){const et=t.targetSlide.value,pt=[];for(const H of et.blocks)H.rawNode?pt.push(H.rawNode):pt.push({id:H.id,type:H.type,content:H.content,markdown:H.rawMarkdown,children:H.children,ial:H.attributes||H.ial||{}});const lt=nf(pt,t.activeBlockId.value);lt&&lt.items.length===4&&(Y={sbId:lt.superBlockNode.id,itemIds:lt.items.map(H=>H.id),headerId:(J=lt.headerNode)==null?void 0:J.id})}if(!Y||Y.itemIds.length!==4)return ht.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const tt=t.currentPageDividerId.value||t.currentDocId.value;tt&&(t.currentPageDividerLayout.value="clover",t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout="clover"),Mt.setBlockAttrOverride(tt,{[gt]:"clover"}),Zt(tt,{[gt]:"clover"}),await Et(tt,{[gt]:"clover"}).catch(()=>{})),Y.headerId&&(Mt.setBlockAttrOverride(Y.headerId,{[Ct]:"header"}),Zt(Y.headerId,{[Ct]:"header"}),await Et(Y.headerId,{[Ct]:"header"}).catch(()=>{}));for(let et=0;et<4;et++){const pt=Y.itemIds[et],lt=`col-${et+1}`;Mt.setBlockAttrOverride(pt,{[Ct]:lt}),Zt(pt,{[Ct]:lt}),await Et(pt,{[Ct]:lt}).catch(()=>{})}return ht.showMessage("已将本页版式设为四叶草（田字型）布局"),t.plugin&&await t.plugin.compileCurrentDocument(),!0}catch(Y){return console.error("[useInspectorActions] applyCloverLayout error:",Y),ht.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:Q,resetSuperBlockWidth:j,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:h,onToggleVideoMuted:v,onToggleVideoControls:d,onImageRoleChange:b,onToggleNoteBlock:g,createNoteBlockOnCurrentSlide:m,onAddNoteBlock:k,onLocateNoteBlock:x,onGenerateNotesWithAI:$,isBatchProcessing:e,onBatchAppendNotes:T,onBatchDeleteNotes:L,toggleElemClick:B,onElemClickStepChange:w,onElemMotionChange:U,onElemSlotChange:W,onElemShikiLinesChange:q,onElemMaxHeightChange:X,onSetTwoColsContrast:I,onClearBlockAttrs:N,onInsertDividerBefore:y,onInsertDividerAfter:D,onDeleteCurrentBlock:V,onExportHtml:E,onExportPdf:R}}const Cy={class:"spm-slidev-inspector"},$y={class:"spm-inspector-topbar"},Iy={class:"spm-inspector-title"},Ay={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},By={class:"spm-inspector-topbar-actions"},Ty={class:"spm-target-banner"},Ey={class:"spm-target-info"},My=["aria-label"],Dy={key:0,class:"spm-save-status"},Ly=["title"],Ry={class:"spm-inspector-body"},Oy=Ce({__name:"SlidevInspectorDockView",setup(t,{expose:e}){const i=ti("plugin"),n=vt(!1);function o(ot){n.value=!1,c.value=ot.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(ot.docId)}const s=vt(""),l=vt(""),r=vt({}),a=vt(""),c=vt(""),u=vt(""),h=vt(""),v=vt(""),d=vt(""),b=vt(""),m=vt(""),g=vt(null),k=vt(""),x=vt("");function $(){var kt;const ot=s.value||c.value;ot&&typeof navigator<"u"&&(kt=navigator==null?void 0:navigator.clipboard)!=null&&kt.writeText&&navigator.clipboard.writeText(ot).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const T=St(()=>Aa(l.value)),L=St(()=>l.value==="NodeCodeBlock"),B=vt(!1),w=St(()=>{if(B.value||rt.value)return!0;const ot=a.value||"";return!!vi(ot)}),U=St(()=>{const ot=l.value||"";if(ot==="NodeVideo"||ot==="video")return!0;const kt=a.value||"";return!!(/<video\b/i.test(kt)||/\.mp4\b/i.test(kt))}),W=St(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),q=St(()=>{const ot=s.value||c.value||"";return ot.length>8?ot.slice(-8):ot||"无"}),X=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),I=St(()=>{if(T.value)return"分页符 (---)";if(W.value)return"全局文档";if(U.value)return"视频块";let ot="内容块";switch(l.value){case"NodeHeading":ot="标题块";break;case"NodeParagraph":ot="段落块";break;case"NodeCodeBlock":ot="代码块";break;case"NodeVideo":ot="视频块";break;case"NodeList":case"NodeListItem":ot="列表项";break;case"NodeBlockquote":ot="引述块";break;case"NodeTable":ot="表格块";break;case"NodeSuperBlock":case"s":case"sb":ot="超级块";break;default:ot="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ot}`:`分栏容器 › ${ot}`:ot}),N=St(()=>T.value?"tag-divider":W.value?"tag-doc":"tag-block"),y=St(()=>r.value[gt]||"default"),D=St(()=>r.value[te]||"slide-left"),V=vt(""),E=vt(""),R=St(()=>r.value[un]||"inherit"),j=St(()=>{var ot;return xy((ot=g.value)==null?void 0:ot.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:h.value,activeBlockAttrs:r.value})}),Q=St(()=>{var ot;return((ot=j.value)==null?void 0:ot.notes)||""}),A=St(()=>{var ot,kt,It;return((It=(kt=(ot=j.value)==null?void 0:ot.noteBlocks)==null?void 0:kt[0])==null?void 0:It.id)||""}),M=St(()=>{var Dt,Ft,Rt,fe,Fn,ci;if(T.value){const Qt=r.value[gt]||r.value["custom-slidev-layout"];if(Qt)return Qt}const ot=r.value[Ct]||r.value["custom-slidev-slot"];if(ot&&(["col-1","col-2","col-3"].includes(ot)||/^col-\d+$/.test(ot)))return"cols-header";if(v.value)return v.value;const kt=h.value||(T.value?s.value:"");if(kt){const Qt=Mt.getBlockAttrOverride(kt);if(Qt!=null&&Qt[gt])return Qt[gt]}if(kt&&((Dt=g.value)!=null&&Dt.slides)){const Qt=g.value.slides.find(Ni=>Ni.startBlockId===kt);if((Ft=Qt==null?void 0:Qt.frontmatter)!=null&&Ft.layout)return Qt.frontmatter.layout}if((fe=(Rt=j.value)==null?void 0:Rt.frontmatter)!=null&&fe.layout)return j.value.frontmatter.layout;if((ci=(Fn=j.value)==null?void 0:Fn.blocks)!=null&&ci.some(Qt=>Qt.slot&&(["col-1","col-2","col-3"].includes(Qt.slot)||/^col-\d+$/.test(Qt.slot))))return"cols-header";const It=Mt.getBlockAttrOverride(c.value);return It!=null&&It[gt]?It[gt]:"default"}),J=St(()=>{var kt,It;if(T.value){const Dt=r.value[le]||r.value["custom-slidev-layout-ratio"];if(Dt)return Dt}const ot=h.value||(T.value?s.value:"");if(ot){const Dt=Mt.getBlockAttrOverride(ot);if(Dt!=null&&Dt[le])return Dt[le]}return((It=(kt=j.value)==null?void 0:kt.frontmatter)==null?void 0:It.layoutRatio)||""});function Y(ot){if(!ot||(ot.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const It=Array.from(ot.querySelectorAll(":scope > [data-node-id]"));if(It.length<2)return null;const Dt=It.length,Ft=It.map(ci=>{const Qt=ci.getAttribute("style")||"",Ni=Qt.match(/calc\(\s*([\d.]+)%/);if(Ni)return parseFloat(Ni[1]);const on=Qt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return on?parseFloat(on[1]):null});let Rt="",fe=!1;if(Ft.some(ci=>ci!==null)){fe=!0;const ci=Ft.reduce((Tt,pe)=>Tt+(pe||0),0),Qt=Ft.filter(Tt=>Tt===null).length,Ni=Qt>0?Math.max(0,100-ci)/Qt:100/It.length,on=Ft.map(Tt=>Tt!==null?Tt:Ni),rc=on.reduce((Tt,pe)=>Tt+pe,0)||1,sn=on.map(Tt=>Tt/rc*100);if(sn.length===2){const[Tt]=sn;if(Tt>=48&&Tt<=52)Rt="1:1";else if(Tt>=31&&Tt<=35)Rt="1:2";else if(Tt>=65&&Tt<=69)Rt="2:1";else if(Tt>=28&&Tt<=32)Rt="3:7";else if(Tt>=68&&Tt<=72)Rt="7:3";else if(Tt>=38&&Tt<=42)Rt="4:6";else if(Tt>=58&&Tt<=62)Rt="6:4";else{const pe=Math.round(Tt);Rt=`${pe}:${100-pe}`}}else if(sn.length===3){const[Tt,pe,di]=sn;if(Tt>=31&&Tt<=35&&pe>=31&&pe<=35&&di>=31&&di<=35)Rt="1:1:1";else if(Tt>=23&&Tt<=27&&pe>=48&&pe<=52&&di>=23&&di<=27)Rt="1:2:1";else if(Tt>=48&&Tt<=52&&pe>=23&&pe<=27&&di>=23&&di<=27)Rt="2:1:1";else if(Tt>=23&&Tt<=27&&pe>=23&&pe<=27&&di>=48&&di<=52)Rt="1:1:2";else{const Ys=Math.round(Tt),Js=Math.round(pe);Rt=`${Ys}:${Js}:${100-Ys-Js}`}}else Rt=sn.map(Tt=>Math.round(Tt)).join(":")}else fe=!1,Rt=Array.from({length:Dt},()=>1).join(":");const Fn=Dt>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Dt,ratio:Rt,isCustomWidth:fe,recommendedLayout:Fn}}function tt(ot){if(!(ot!=null&&ot.blocks))return null;for(const kt of ot.blocks){const It=kt.rawNode;if(It&&oe(It)&&Ke(It)){const Ft=nn(It).length,Rt=Hs(It);return{hasSuperBlock:!0,colCount:Ft,ratio:Rt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Rt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const et=St(()=>{var ot;if(typeof document<"u"){const kt=s.value;if(kt){const Dt=document.querySelector(`.protyle-wysiwyg [data-node-id="${kt}"]`);if(Dt){const Ft=Dt.getAttribute("data-type")==="NodeSuperBlock"?Dt:Dt.closest('[data-type="NodeSuperBlock"]');if(Ft){const Rt=Y(Ft);if(Rt)return Rt}}}const It=h.value||(T.value?s.value:"");if(It){const Dt=document.querySelector(`.protyle-wysiwyg [data-node-id="${It}"]`);if(Dt){let Ft=Dt.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(ot=Ft.classList)!=null&&ot.contains("protyle-wysiwyg__block--hr"));){const Rt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Rt){const fe=Y(Rt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const Dt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Rt of Ft)if(!Dt||Rt.compareDocumentPosition(Dt)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=Y(Rt);if(fe)return fe}}}return tt(j.value)}),pt=St(()=>{var ot;return((ot=et.value)==null?void 0:ot.ratio)||""}),lt=St(()=>{const ot=l.value||"";if(ot==="NodeSuperBlock"||ot==="s"||ot==="sb")return!0;if(typeof document<"u"&&s.value){const kt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(kt!=null&&kt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),H=St(()=>{var ot;return((ot=j.value)==null?void 0:ot.pageIndex)||1}),at=St(()=>!!(r.value[ne]||r.value["slidev-note"]));function ut(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const ot=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!ot)return!1;const kt=ot.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(kt==null?void 0:kt.getAttribute("data-node-id"))===s.value}const S=St(()=>{var kt;if(r.value[jt]!==void 0)return r.value[jt]||"";if(d.value&&ut())return m.value||"";if(d.value)return"";const ot=s.value;if(ot&&((kt=j.value)!=null&&kt.blocks)){const It=j.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.clicks)return It.clicks}return""}),P=St(()=>{var kt;if(r.value[Ve])return r.value[Ve];const ot=s.value;if(ot&&((kt=j.value)!=null&&kt.blocks)){const It=j.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.motion)return typeof It.motion=="string"?It.motion:JSON.stringify(It.motion)}return""}),p=St(()=>{var kt;if(r.value[Ct])return r.value[Ct];const ot=s.value;if(ot&&((kt=j.value)!=null&&kt.blocks)){const It=j.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.slot)return It.slot}return""}),z=vt(""),F=vt(""),_=St(()=>r.value[Bi]==="true"),C=St(()=>r.value[ro]==="true"),O=St(()=>r.value[ji]==="true"),Z=St(()=>r.value[lo]!=="false"),G=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.theme)||r.value[wn]||"default"}),K=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.aspectRatio)||r.value[xn]||"16/9"}),it=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.defaultTransition)||r.value[_n]||"slide-left"}),ct=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.spacing)||r.value[ns]||"normal"}),rt=St(()=>{var Ft,Rt;if((r.value[qt]||r.value["slidev-role"])===Yr||r.value[Ut]==="true")return"background";const kt=r.value[gt]||r.value["slidev-layout"];if(kt==="image-left"||kt==="image-right")return kt;const It=a.value||"",Dt=vi(It);if(Dt&&((Rt=(Ft=j.value)==null?void 0:Ft.frontmatter)!=null&&Rt.background)){const fe=j.value.frontmatter.background;if(fe===Dt||fe.endsWith(Dt)||Dt.endsWith(fe))return"background"}return""}),mt=St(()=>!!(r.value[jt]||r.value[Ve]||r.value[Ct]||r.value[Ri]||r.value[ne]||r.value["slidev-note"]||r.value[qt]||r.value[gt]||r.value[Bi]||r.value[ro]||r.value[ji]||r.value[lo])),{saveAttr:_t,savePageAttr:wt,applyPageLayoutAndRatio:Lt,applyCloverLayout:Gt,resetSuperBlockWidth:Yt,saveDocAttr:ie,onToggleVideoAutoplay:Nt,onToggleVideoLoop:Ge,onToggleVideoMuted:se,onToggleVideoControls:Xt,onImageRoleChange:yi,onToggleNoteBlock:Pi,onAddNoteBlock:Ro,onLocateNoteBlock:Oo,onGenerateNotesWithAI:Nn,isBatchProcessing:ki,onBatchAppendNotes:zi,onBatchDeleteNotes:Da,toggleElemClick:La,onElemClickStepChange:Ra,onElemMotionChange:Oa,onElemSlotChange:Pa,onElemShikiLinesChange:za,onElemMaxHeightChange:Na,onSetTwoColsContrast:Fa,onClearBlockAttrs:Ha,onInsertDividerBefore:ja,onInsertDividerAfter:Ks,onDeleteCurrentBlock:Ua,onExportHtml:Wa,onExportPdf:Va}=Sy({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:h,currentPageDividerLayout:v,parentContainerId:d,parentContainerClicks:m,latestDoc:g,targetSlide:j,currentSlideNoteBlockId:A,currentSlideLayout:M,isNoteBlock:at,elemClick:S,videoAutoplay:_,videoLoop:C,videoMuted:O,videoControls:Z,pageBackground:V,pageImage:E,elemShikiLines:z,elemMaxHeight:F,saveStatus:k,plugin:i});async function qa(ot){if(ot==="clover"){if(!await Gt())return}else _t(gt,ot)}function Ka(ot){wt(le,ot)}function Gs(ot){if(!ot)return;const kt=ot.recommendedLayout||(ot.colCount&&ot.colCount>=2?"cols-header":"two-cols"),It=ot.ratio||(ot.colCount?Array(ot.colCount).fill(1).join(":"):"1:1");Lt(kt,It)}function Ga(ot){wt(le,ot)}async function Za(){await Yt()}function Ya(ot){_t(te,ot)}function Ja(ot){V.value=ot,_t(Ut,ot)}function Xa(ot){E.value=ot,_t(Ee,ot)}function Qa(ot){_t(un,ot==="inherit"?"":ot)}function tc(ot){ie(wn,ot)}function ec(ot){ie(xn,ot)}function ic(ot){ie(_n,ot)}function nc(ot){ie(ns,ot)}function Zs(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function oc(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function sc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return e({setActiveBlock(ot){s.value=ot.id,l.value=ot.type,r.value={...ot.attrs},a.value=ot.content||ot.markdown||"",u.value=ot.topBlockId||ot.id,h.value=ot.pageDividerId||"",v.value=ot.pageDividerLayout||"",d.value=ot.parentContainerId||"",b.value=ot.parentContainerSlot||"",m.value=ot.parentContainerClicks||"",ot.rootId?c.value=ot.rootId:(ot.type==="doc"||ot.type==="NodeDocument")&&ot.id&&(c.value=ot.id),V.value=ot.attrs[Ut]||"",E.value=ot.attrs[Ee]||"",z.value=ot.attrs[Ri]||"",F.value=ot.attrs[Sn]||"",B.value=!!ot.isImage},updateDocument(ot){g.value=ot,c.value=ot.docId},openImportDialog(){n.value=!0},setCurrentDocId(ot){c.value=ot}}),(ot,kt)=>(nt(),st("div",Cy,[f("div",$y,[f("div",Iy,[(nt(),st("svg",Ay,[...kt[2]||(kt[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),kt[3]||(kt[3]=f("span",null,"演示配置",-1))]),f("div",By,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:kt[0]||(kt[0]=It=>n.value=!0)},[dt(ft,{name:"import"}),kt[4]||(kt[4]=f("span",null,"导入",-1))]),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Zs},[dt(ft,{name:"split-preview"}),kt[5]||(kt[5]=f("span",null,"分屏预览",-1))])])]),f("div",Ty,[f("div",Ey,[f("span",{class:At(["spm-target-tag",N.value])},xt(I.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:$},[dt(ft,{name:"copy"}),f("span",null,"#"+xt(q.value),1)],8,My)]),k.value?(nt(),st("span",Dy,"● "+xt(k.value),1)):Ot("",!0)]),X.value?(nt(),st("div",{key:0,class:"spm-context-quote",title:a.value},xt(X.value),9,Ly)):Ot("",!0),f("div",Ry,[T.value?(nt(),De(Gg,{key:0,"page-layout":y.value,"page-layout-ratio":J.value,"detected-sb-ratio":pt.value,"detected-sb-info":et.value,"page-transition":D.value,"page-background":V.value,"page-spacing":R.value,"page-image":E.value,"page-notes":Q.value,"page-index":H.value,"onUpdate:pageLayout":qa,"onUpdate:pageLayoutRatio":Ka,onApplySuperBlockLayout:Gs,onResetSuperblockRatio:Za,"onUpdate:pageTransition":Ya,"onUpdate:pageBackground":Ja,"onUpdate:pageSpacing":Qa,"onUpdate:pageImage":Xa,onAddNoteBlock:bt(Ro),onLocateNoteBlock:bt(Oo),onGenerateNotes:bt(Nn),onBatchAppendNotes:bt(zi),onBatchDeleteNotes:bt(Da),"is-batch-processing":bt(ki),onInsertDividerAfter:bt(Ks),onDeleteDivider:bt(Ua)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!W.value?(nt(),De(Mb,{key:1,"elem-click":S.value,"elem-motion":P.value,"elem-slot":p.value,"elem-shiki-lines":z.value,"elem-max-height":F.value,"is-code-block":L.value,"is-image":w.value,"is-video":U.value,"is-super-block":lt.value,"detected-sb-info":et.value,"video-autoplay":_.value,"video-loop":C.value,"video-muted":O.value,"video-controls":Z.value,"has-block-attrs":mt.value,"is-note":at.value,"image-role":rt.value,"current-slide-layout":M.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":d.value,onToggleNote:bt(Pi),onToggleElemClick:bt(La),onToggleVideoAutoplay:bt(Nt),onToggleVideoLoop:bt(Ge),onToggleVideoMuted:bt(se),onToggleVideoControls:bt(Xt),"onUpdate:imageRole":bt(yi),"onUpdate:elemClick":bt(Ra),"onUpdate:elemMotion":bt(Oa),"onUpdate:elemSlot":bt(Pa),"onUpdate:elemShikiLines":bt(za),"onUpdate:elemMaxHeight":bt(Na),onApplySuperBlockLayout:Gs,onApplySuperBlockRatio:Ga,onInsertDividerBefore:bt(ja),onInsertDividerAfter:bt(Ks),onSetTwoColsContrast:bt(Fa),onClearBlockAttrs:bt(Ha)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(nt(),De(g1,{key:2,"doc-theme":G.value,"doc-aspect-ratio":K.value,"doc-default-transition":it.value,"doc-spacing":ct.value,"onUpdate:docTheme":tc,"onUpdate:docAspectRatio":ec,"onUpdate:docDefaultTransition":ic,"onUpdate:docSpacing":nc,onOpenBottomPreview:Zs,onOpenPresenter:oc,onAiAutoSplit:sc,onExportHtml:bt(Wa),onExportPdf:bt(Va)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(nt(),De(wy,{key:1,onClose:kt[1]||(kt[1]=It=>n.value=!1),onSuccess:o})):Ot("",!0)]))}}),Py=2e3,zy=600;function Ny(t){return!t||typeof t.closest!="function"?!1:!!t.closest(".fn__none")}function Qo(t){if(!t||typeof t.isConnected=="boolean"&&!t.isConnected)return!1;if(jr(t))return!0;const e=t.firstElementChild;return!!(e&&jr(e))}function jr(t){return typeof t.getClientRects=="function"&&t.getClientRects().length>0?!0:typeof t.offsetWidth=="number"&&t.offsetWidth>0&&t.offsetHeight>0}function Fy(){const t=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof t=="function"?t:void 0}class Hy{constructor(){yt(this,"consumers",new Map);yt(this,"seq",0);yt(this,"verifyTimer",null)}register(e,i,n){if(!i)return()=>{};const o=++this.seq,s=Fy(),l={kind:e,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(i)):l.visible=Qo(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var e;for(const i of this.consumers.values())(e=i.observer)==null||e.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const e of this.consumers.values())if(e.measureOnDemand?Qo(e.element):this.isRecordVisible(e))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(e){return e.visible?!0:!Ny(e.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let e=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){e=!0;break}e&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&Qo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Py))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const eo=new Hy,zn=new Vs;function Ta(t,e,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=eo.register(t,e,n);return n(),o}let mi=null,We=null,io=null;function jy(t,e){mi&&Ea(),mi=ra(Zm),mi.provide("plugin",e),mi.provide("sandboxBridge",zn);const i=mi.mount(t);return We=i,io=Ta("preview",t,e),i}function Ea(t){io&&(io(),io=null),mi&&(mi.unmount(),mi=null,We=null)}let gi=null,_e=null,no=null;function Uy(t,e){gi&&Ma(),gi=ra(Oy),gi.provide("plugin",e),gi.provide("sandboxBridge",zn);const i=gi.mount(t);return _e=i,no=Ta("dock",t,e),i}function Ma(t){no&&(no(),no=null),gi&&(gi.unmount(),gi=null,_e=null)}function Wy(t,e){_e!=null&&_e.updateDocument&&_e.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,e):zn.updateSlides(t.slides,t.config,t.fullMarkdown)}function ys(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):zn.highlightElement(t)}function oo(t){_e!=null&&_e.setActiveBlock&&_e.setActiveBlock(t)}function Vy(){return _e!=null&&_e.openImportDialog?(_e.openImportDialog(),!0):!1}function qy(t,e){const i=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(ko(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];ko(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const Ky=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"cover"},{key:te,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"two-cols"},{key:te,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"fact"},{key:te,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"intro"},{key:te,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"quote"},{key:te,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:jt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:jt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ct,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ri,value:"1-3"}]}];class ts{getPresetTemplates(){return Ky}buildScanSlidevBlocksSql(e="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${e}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${te}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${te}' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[te]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const e=this.getPresetTemplates();return JSON.stringify({templates:e,counter:e.length},null,2)}formatTransitionSummary(e){return!e||e.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${e.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Gy(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Vy()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Et(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const e=await so(t.currentDocId).catch(()=>[]);if(!e||e.length===0){ht.showMessage("当前文档无内容，无需断页");return}const i=e.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=qy(i);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await $i("markdown","---",void 0,s.blockId),await Et(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,h;if(!t.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const e=await so(t.currentDocId).catch(()=>[]),i={startBlockId:t.currentDocId,blocks:e.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await _y(i,qr)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await es("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((h=l==null?void 0:l[0])==null?void 0:h.id);r&&(await Et(r,{"custom-slidev-note":"true"}),Mt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Li(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new ts,i=e.buildTransitionStatsSql(),n=await kn(i).catch(()=>[]),o=e.formatTransitionSummary(n||[]);ht.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new ts().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new ts().batchUpdateTransitions("fade","slide-left",n=>kn(n).catch(()=>[]),(n,o)=>Et(n,o));ht.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const e=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",is);e.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${e.path}`):ht.showMessage(`同步失败：${e.error}`)}})}class Zy{constructor(e=400){yt(this,"entries",new Map);this.ttlMs=e}get(e,i=Date.now()){if(!e)return;const n=this.entries.get(e);if(n){if(i-n.at>this.ttlMs){this.entries.delete(e);return}return n.attrs}}set(e,i,n=Date.now()){!e||!i||this.entries.set(e,{attrs:i,at:n})}invalidate(e){e?this.entries.delete(e):this.entries.clear()}get size(){return this.entries.size}}function Yy(t){const e=new Map;if(!(t!=null&&t.slides))return e;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&e.set(o.id,o.ial)};for(const n of t.slides)i(n.blocks),i(n.noteBlocks);return e}class Jy{constructor(e=150){yt(this,"lastBlockId","");yt(this,"lastAt",0);this.windowMs=e}shouldSkip(e,i=Date.now()){return e&&e===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=e,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class Xy{constructor(){yt(this,"attrCache",new Zy);yt(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(e,i){if(!e)return{};const n=Mt.getBlockAttrOverride(e),o=this.getCompiledIal(i,e);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(e);if(s)return s;const l=await ks(e).catch(()=>({}))||{};return this.attrCache.set(e,l),l}getCompiledIal(e,i){if(e)return this.compiledIalIndex.doc!==e&&(this.compiledIalIndex={doc:e,map:Yy(e)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(e){this.attrCache.invalidate(e)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=e==null?void 0:e.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(e,i=""){const n=e.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=e.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(e,i){var s;if(!e)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(e,null);oo({id:e,rootId:e,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),ys(e)}handleBlockClickedFromSlide(e,i,n,o){var a;if(!e)return!1;const s=Li(e,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,e,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const h=o.slides.find(v=>{var d,b,m;return v.startBlockId===e||((d=v.blocks)==null?void 0:d.some(g=>g.id===e))||((b=v.allBlockIds)==null?void 0:b.includes(e))||((m=v.noteBlocks)==null?void 0:m.some(g=>g.id===e))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(u=h.frontmatter.layout)}this.resolveBlockAttrs(e,o).then(async h=>{if(c&&!u){const v=Mt.getBlockAttrOverride(c);if(v!=null&&v[gt]||v!=null&&v["custom-slidev-layout"])u=v[gt]||v["custom-slidev-layout"]||"";else{const d=await this.resolveBlockAttrs(c,o);u=d[gt]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Mt.setBlockAttrOverride(c,d)}}oo({id:e,rootId:n,type:r||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(e,i,n,o,s){var D,V,E,R,j,Q,A,M;let l=e,r=i,a=n;const c=e.closest('[data-type="NodeCallout"]');if(c&&c!==e){const J=c.getAttribute("data-node-id");if(J){const Y=await this.resolveBlockAttrs(J,s),tt=Mt.getBlockAttrOverride(J)||{},et={...Y,...tt};(et[ne]||et["slidev-note"])&&(l=c,r=J,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,h=(u==null?void 0:u.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((D=u==null?void 0:u.classList)!=null&&D.contains("hr")),d=a==="NodeCodeBlock",b=((V=l.innerText)==null?void 0:V.trim())||"",m=await this.resolveBlockAttrs(r,s),g=Mt.getBlockAttrOverride(r)||{},k={...m,...g};let x="",$="";if(v)x=r,$=k[gt]||k["custom-slidev-layout"]||"";else{let J=u.previousElementSibling;for(;J;){const Y=J.getAttribute("data-type");if(Y==="NodeThematicBreak"||Y==="tb"||(E=J.classList)!=null&&E.contains("hr")){x=J.getAttribute("data-node-id")||"";break}J=J.previousElementSibling}}if(s!=null&&s.slides){const J=[r,h];let Y=l.parentElement;for(;Y&&!Y.classList.contains("protyle-wysiwyg");){const et=Y.getAttribute("data-node-id");et&&!J.includes(et)&&J.push(et),Y=Y.parentElement}const tt=s.slides.find(et=>{var pt,lt,H;return J.includes(et.startBlockId)||((pt=et.blocks)==null?void 0:pt.some(at=>J.includes(at.id)))||((lt=et.allBlockIds)==null?void 0:lt.some(at=>J.includes(at)))||((H=et.noteBlocks)==null?void 0:H.some(at=>J.includes(at.id)))});tt&&(!x&&tt.startBlockId&&(x=tt.startBlockId),!$&&((R=tt.frontmatter)!=null&&R.layout)&&($=tt.frontmatter.layout))}if(x){const J=Mt.getBlockAttrOverride(x);if(J&&(gt in J||"custom-slidev-layout"in J)&&($=J[gt]||J["custom-slidev-layout"]||""),!$&&(s!=null&&s.slides)){const Y=s.slides.find(tt=>tt.startBlockId===x);(j=Y==null?void 0:Y.frontmatter)!=null&&j.layout&&($=Y.frontmatter.layout)}if(!$){const Y=await this.resolveBlockAttrs(x,s);$=Y[gt]||Y["custom-slidev-layout"]||"",Y&&Object.keys(Y).length>0&&Mt.setBlockAttrOverride(x,Y)}Zt(x,{[gt]:$||""})}else if(o){const J=Mt.getBlockAttrOverride(o);J&&(gt in J||"custom-slidev-layout"in J)?$=J[gt]||J["custom-slidev-layout"]||"":!$&&((M=(A=(Q=s==null?void 0:s.slides)==null?void 0:Q[0])==null?void 0:A.frontmatter)!=null&&M.layout)&&($=s.slides[0].frontmatter.layout)}const T=l.getAttribute(gt)||l.getAttribute("custom-slidev-layout"),L=k[gt]||k["custom-slidev-layout"]||"";T&&T!==L&&Zt(r,{[gt]:L});const B=l.getAttribute(qt)||l.getAttribute("custom-slidev-role"),w=k[qt]||k["custom-slidev-role"]||"";B&&B!==w&&Zt(r,{[qt]:w});let U="",W="",q="";const X=l.closest('[data-type="NodeListItem"]');if(X&&X!==l){const J=X.getAttribute("data-node-id");if(J){U=J;const Y=await this.resolveBlockAttrs(J,s),tt=Mt.getBlockAttrOverride(J)||{},et={...Y,...tt};W=et[Ct]||"",q=et[jt]||"";const pt=et[gt]||et["custom-slidev-layout"]||"",lt=X.getAttribute(gt)||X.getAttribute("custom-slidev-layout");lt&&lt!==pt&&Zt(J,{[gt]:pt});const H=et[qt]||et["custom-slidev-role"]||"",at=X.getAttribute(qt)||X.getAttribute("custom-slidev-role");at&&at!==H&&Zt(J,{[qt]:H})}}const I=!!l.querySelector("img, span[data-type='img']"),N=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=I&&N.length<=50;oo({id:r,rootId:o,type:a,content:b,attrs:k,isDivider:v,isCode:d,isImage:y,topBlockId:h,pageDividerId:x,pageDividerLayout:$,parentContainerId:U,parentContainerSlot:W,parentContainerClicks:q})}patchThematicBreakTransactions(e){if((e==null?void 0:e.cmd)==="transactions"&&Array.isArray(e.data)){for(const i of e.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");Zt(n.id,l),Mt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(e){var o,s,l;if(typeof document>"u"||!e)return;const i=new Map;if(Array.isArray(e.slides))for(const r of e.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[gt]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[gt]&&(c[gt]=a.ial[gt]),(l=a.ial)!=null&&l[qt]&&(c[qt]=a.ial[qt]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Mt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[gt]!==void 0&&(c[gt]=a[gt]),a[qt]!==void 0&&(c[qt]=a[qt]),i.set(r,c)}qp(i)}}const Ci=new Xy;class Qy{constructor(){yt(this,"inFlightDocId",null);yt(this,"pendingDocId",null);yt(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(e){return this.inFlightDocId!==null?(this.pendingDocId=e,null):(this.inFlightDocId=e,++this.generation)}isStale(e){return e!==this.generation}finish(){this.inFlightDocId=null;const e=this.pendingDocId;return this.pendingDocId=null,e}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const t0=150,e0=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,i0="slidev-dock",Ur="slidev-preview-tab",Wr=Zu;class n0 extends ht.Plugin{constructor(){super(...arguments);yt(this,"isMobile",!1);yt(this,"currentDocId","");yt(this,"latestCompiledDoc",null);yt(this,"cliBridge",new js);yt(this,"debounceTimer",null);yt(this,"activeCursorBlockId","");yt(this,"compileScheduler",new Qy);yt(this,"dirtyDocId",null);yt(this,"inspectorSyncThrottle",new Jy);yt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));yt(this,"onWsMainBound",this.onWsMain.bind(this));yt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));yt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));yt(this,"onEditorClickBound",this.onEditorClick.bind(this));yt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));yt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));yt(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ht.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(e0),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Gy(this);const n=this;if(this.addTab({type:Ur,init(){jy(this.element,n)},destroy(){Ea(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:i0,init(){Uy(this.element,n)},destroy(){Ma(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Wr),n=Yu(i);return Ti(n),n}catch{return Ti(Qi),Qi}}async saveGlobalSettings(i){const n=Lo(),o=Ti({...n,...i||{}});try{await this.saveData(Wr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,eo.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),zn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ht.openTab({app:this.app,custom:{id:this.name+Ur,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(i){var l;const n=i.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Et(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Et(s,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Et(s,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Et(s,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(i){var s,l;const n=(s=i.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await ks(o).catch(()=>({}));oo({id:o,rootId:o,type:"doc",attrs:r}),this.markCompileDirty(o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return Ci.getActiveDocumentId()}resolveDocIdFromElement(i){return Ci.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ci.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ci.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=t0){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=eo.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,zy);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ci.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const h=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=h==null?void 0:h.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ys(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const h=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=h==null?void 0:h.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ys(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ci.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&eo.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Mt.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Wy(r,s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ci.purgeStaleDomSlidevAttrs(i)}}module.exports=n0;
