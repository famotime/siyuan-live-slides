"use strict";var lc=Object.create;var Oo=Object.defineProperty;var ac=Object.getOwnPropertyDescriptor;var cc=Object.getOwnPropertyNames;var dc=Object.getPrototypeOf,uc=Object.prototype.hasOwnProperty;var fc=(t,e,i)=>e in t?Oo(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var pc=(t,e,i,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let o of cc(e))!uc.call(t,o)&&o!==i&&Oo(t,o,{get:()=>e[o],enumerable:!(n=ac(e,o))||n.enumerable});return t};var Hn=(t,e,i)=>(i=t!=null?lc(dc(t)):{},pc(e||!t||!t.__esModule?Oo(i,"default",{value:t,enumerable:!0}):i,t));var yt=(t,e,i)=>fc(t,typeof e!="symbol"?e+"":e,i);const ht=require("siyuan");async function ke(t,e){const i=await ht.fetchSyncPost(t,e);return i.code===0?i.data:null}async function hc(){return ke("/api/notebook/lsNotebooks","")}async function mc(t,e,i){return ke("/api/filetree/createDocWithMd",{notebook:t,path:e,markdown:i})}async function Wr(t,e){const i=new FormData;i.append("assetsDirPath",t);for(const o of e)i.append("file[]",o);return ke("/api/asset/upload",i)}async function $i(t,e,i,n,o){return ke("/api/block/insertBlock",{dataType:t,data:e,nextID:i,previousID:n,parentID:o})}async function es(t,e,i){return ke("/api/block/appendBlock",{dataType:t,data:e,parentID:i})}async function Js(t,e,i){return ke("/api/block/updateBlock",{dataType:t,data:e,id:i})}async function Xs(t){return ke("/api/block/deleteBlock",{id:t})}async function gc(t){return ke("/api/block/getBlockKramdown",{id:t})}async function so(t){return ke("/api/block/getChildBlocks",{id:t})}async function Et(t,e){return ke("/api/attr/setBlockAttrs",{id:t,attrs:e})}async function ys(t){return ke("/api/attr/getBlockAttrs",{id:t})}async function kn(t){return ke("/api/query/sql",{stmt:t})}async function is(t,e,i){const n=new FormData;return n.append("path",t),n.append("isDir",e.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),ke("/api/file/putFile",n)}async function Vr(t){const e="/api/ai/chatGPT";try{const i=await ke(e,{msg:t});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function vc(){return ke("/api/storage/getInlineStyles","")}const qr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function bc(t){const e=[];if(!t)return e;const i=new RegExp(qr.source,"g");let n;for(;(n=i.exec(t))!==null;){const o=n[2]??n[3]??n[4];e.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return e}function yc(t,e){if(!t)return"";const i=new RegExp(qr.source,"g");return t.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(e&&e[o]){const u=e[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const wn="custom-slidev-theme",xn="custom-slidev-aspect-ratio",Kr="custom-slidev-highlighter",_n="custom-slidev-default-transition",Gr="custom-slidev-color-schema",ns="custom-slidev-spacing",Ai="custom-slidev-slide",gt="custom-slidev-layout",te="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Ui="custom-slidev-notes",Wi="custom-slidev-class",un="custom-slidev-spacing",le="custom-slidev-layout-ratio",jt="custom-slidev-click",Ve="custom-slidev-motion",Ri="custom-slidev-shiki-lines",Ct="custom-slidev-slot",ne="custom-slidev-note",qt="custom-slidev-role",Sn="custom-slidev-max-height",Bi="custom-slidev-autoplay",ro="custom-slidev-loop",ji="custom-slidev-muted",lo="custom-slidev-controls",Zr="background",ao="image-left",co="image-right";function Cn(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function kc(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function wc(t){const e={};if(!t)return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}function Yr(t){if(!t)return!1;const e=t.trim();return e.startsWith("assets/")||e.startsWith("./assets/")||e.startsWith("/assets/")}function Jr(t){const e=t.trim();return e.startsWith("./assets/")?e.slice(2):e.startsWith("/assets/")?e.slice(1):e}function Ae(t,e){if(!Yr(t))return t;const i=Jr(t);return e!=null&&e.base64Map&&e.base64Map[i]?e.base64Map[i]:e!=null&&e.baseUrl?`${e.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function xc(t,e){if(!t)return"";let i=t;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ae(s,e);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ae(s,e);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ae(s,e);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function ks(t){const e=Object.create(null);for(const i of t.split(","))e[i]=1;return i=>i in e}const Wt={},Vi=[],qe=()=>{},Xr=()=>!1,wo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),xo=t=>t.startsWith("onUpdate:"),ue=Object.assign,ws=(t,e)=>{const i=t.indexOf(e);i>-1&&t.splice(i,1)},_c=Object.prototype.hasOwnProperty,zt=(t,e)=>_c.call(t,e),$t=Array.isArray,qi=t=>Ln(t)==="[object Map]",tn=t=>Ln(t)==="[object Set]",Qs=t=>Ln(t)==="[object Date]",Bt=t=>typeof t=="function",ee=t=>typeof t=="string",Re=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",Qr=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),tl=Object.prototype.toString,Ln=t=>tl.call(t),Sc=t=>Ln(t).slice(8,-1),el=t=>Ln(t)==="[object Object]",xs=t=>ee(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=ks(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),_o=t=>{const e=Object.create(null);return(i=>e[i]||(e[i]=t(i)))},Cc=/-\w/g,ye=_o(t=>t.replace(Cc,e=>e.slice(1).toUpperCase())),$c=/\B([A-Z])/g,bi=_o(t=>t.replace($c,"-$1").toLowerCase()),So=_o(t=>t.charAt(0).toUpperCase()+t.slice(1)),zo=_o(t=>t?`on${So(t)}`:""),Ue=(t,e)=>!Object.is(t,e),Yn=(t,...e)=>{for(let i=0;i<t.length;i++)t[i](...e)},il=(t,e,i,n=!1)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,writable:n,value:i})},Co=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let tr;const $o=()=>tr||(tr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function $n(t){if($t(t)){const e={};for(let i=0;i<t.length;i++){const n=t[i],o=ee(n)?Tc(n):$n(n);if(o)for(const s in o)e[s]=o[s]}return e}else if(ee(t)||Ht(t))return t}const Ic=/;(?![^(]*\))/g,Ac=/:([^]+)/,Bc=/\/\*[^]*?\*\//g;function Tc(t){const e={};return t.replace(Bc,"").split(Ic).forEach(i=>{if(i){const n=i.split(Ac);n.length>1&&(e[n[0].trim()]=n[1].trim())}}),e}function At(t){let e="";if(ee(t))e=t;else if($t(t))for(let i=0;i<t.length;i++){const n=At(t[i]);n&&(e+=n+" ")}else if(Ht(t))for(const i in t)t[i]&&(e+=i+" ");return e.trim()}const Ec="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Mc=ks(Ec);function nl(t){return!!t||t===""}function Dc(t,e){if(t.length!==e.length)return!1;let i=!0;for(let n=0;i&&n<t.length;n++)i=en(t[n],e[n]);return i}function en(t,e){if(t===e)return!0;let i=Qs(t),n=Qs(e);if(i||n)return i&&n?t.getTime()===e.getTime():!1;if(i=Re(t),n=Re(e),i||n)return t===e;if(i=$t(t),n=$t(e),i||n)return i&&n?Dc(t,e):!1;if(i=Ht(t),n=Ht(e),i||n){if(!i||!n)return!1;const o=Object.keys(t).length,s=Object.keys(e).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=e.hasOwnProperty(l);if(r&&!a||!r&&a||!en(t[l],e[l]))return!1}}return String(t)===String(e)}function _s(t,e){return t.findIndex(i=>en(i,e))}const ol=t=>!!(t&&t.__v_isRef===!0),xt=t=>ee(t)?t:t==null?"":$t(t)||Ht(t)&&(t.toString===tl||!Bt(t.toString))?ol(t)?xt(t.value):JSON.stringify(t,sl,2):String(t),sl=(t,e)=>ol(e)?sl(t,e.value):qi(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((i,[n,o],s)=>(i[No(n,s)+" =>"]=o,i),{})}:tn(e)?{[`Set(${e.size})`]:[...e.values()].map(i=>No(i))}:Re(e)?No(e):Ht(e)&&!$t(e)&&!el(e)?String(e):e,No=(t,e="")=>{var i;return Re(t)?`Symbol(${(i=t.description)!=null?i:e})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class Lc{constructor(e=!1){this.detached=e,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!e&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let e,i;if(this.scopes){const n=this.scopes.slice();for(e=0,i=n.length;e<i;e++)n[e].pause()}for(e=0,i=this.effects.length;e<i;e++)this.effects[e].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let e,i;if(this.scopes){const o=this.scopes.slice();for(e=0,i=o.length;e<i;e++)o[e].resume()}const n=this.effects.slice();for(e=0,i=n.length;e<i;e++)n[e].resume()}}run(e){if(this._active){const i=ae;try{return ae=this,e()}finally{ae=i}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let e=ae;for(;e;){if(e.prevScope===this){e.prevScope=this.prevScope;break}e=e.prevScope}}this.prevScope=void 0}}stop(e){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!e){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Rc(){return ae}let Vt;const Fo=new WeakSet;class rl{constructor(e){this.fn=e,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Fo.has(this)&&(Fo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||al(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,er(this),cl(this);const e=Vt,i=Le;Vt=this,Le=!0;try{return this.fn()}finally{dl(this),Vt=e,Le=i,this.flags&=-3}}stop(){if(this.flags&1){for(let e=this.deps;e;e=e.nextDep)$s(e);this.deps=this.depsTail=void 0,er(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Fo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){os(this)&&this.run()}get dirty(){return os(this)}}let ll=0,pn,hn;function al(t,e=!1){if(t.flags|=8,e){t.next=hn,hn=t;return}t.next=pn,pn=t}function Ss(){ll++}function Cs(){if(--ll>0)return;if(hn){let e=hn;for(hn=void 0;e;){const i=e.next;e.next=void 0,e.flags&=-9,e=i}}let t;for(;pn;){let e=pn;for(pn=void 0;e;){const i=e.next;if(e.next=void 0,e.flags&=-9,e.flags&1)try{e.trigger()}catch(n){t||(t=n)}e=i}}if(t)throw t}function cl(t){for(let e=t.deps;e;e=e.nextDep)e.version=-1,e.prevActiveLink=e.dep.activeLink,e.dep.activeLink=e}function dl(t){let e,i=t.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),$s(n),Pc(n)):e=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=e,t.depsTail=i}function os(t){for(let e=t.deps;e;e=e.nextDep)if(e.dep.version!==e.version||e.dep.computed&&(ul(e.dep.computed)||e.dep.version!==e.version))return!0;return!!t._dirty}function ul(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===In)||(t.globalVersion=In,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!os(t))))return;t.flags|=2;const e=t.dep,i=Vt,n=Le;Vt=t,Le=!0;try{cl(t);const o=t.fn(t._value);(e.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,e.version++)}catch(o){throw e.version++,o}finally{Vt=i,Le=n,dl(t),t.flags&=-3}}function $s(t,e=!1){const{dep:i,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),i.subs===t&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)$s(s,!0)}!e&&!--i.sc&&i.map&&i.map.delete(i.key)}function Pc(t){const{prevDep:e,nextDep:i}=t;e&&(e.nextDep=i,t.prevDep=void 0),i&&(i.prevDep=e,t.nextDep=void 0)}let Le=!0;const fl=[];function ni(){fl.push(Le),Le=!1}function oi(){const t=fl.pop();Le=t===void 0?!0:t}function er(t){const{cleanup:e}=t;if(t.cleanup=void 0,e){const i=Vt;Vt=void 0;try{e()}finally{Vt=i}}}let In=0;class Oc{constructor(e,i){this.sub=e,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Is{constructor(e){this.computed=e,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(e){if(!Vt||!Le||Vt===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Vt)i=this.activeLink=new Oc(Vt,this),Vt.deps?(i.prevDep=Vt.depsTail,Vt.depsTail.nextDep=i,Vt.depsTail=i):Vt.deps=Vt.depsTail=i,pl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Vt.depsTail,i.nextDep=void 0,Vt.depsTail.nextDep=i,Vt.depsTail=i,Vt.deps===i&&(Vt.deps=n)}return i}trigger(e){this.version++,In++,this.notify(e)}notify(e){Ss();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Cs()}}}function pl(t){if(t.dep.sc++,t.sub.flags&4){const e=t.dep.computed;if(e&&!t.dep.subs){e.flags|=20;for(let n=e.deps;n;n=n.nextDep)pl(n)}const i=t.dep.subs;i!==t&&(t.prevSub=i,i&&(i.nextSub=t)),t.dep.subs=t}}const ss=new WeakMap,Ei=Symbol(""),rs=Symbol(""),An=Symbol("");function he(t,e,i){if(Le&&Vt){let n=ss.get(t);n||ss.set(t,n=new Map);let o=n.get(i);o||(n.set(i,o=new Is),o.map=n,o.key=i),o.track()}}function Xe(t,e,i,n,o,s){const l=ss.get(t);if(!l){In++;return}const r=a=>{a&&a.trigger()};if(Ss(),e==="clear")l.forEach(r);else{const a=$t(t),c=a&&xs(i);if(a&&i==="length"){const u=Number(n);l.forEach((f,v)=>{(v==="length"||v===An||!Re(v)&&v>=u)&&r(f)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(An)),e){case"add":a?c&&r(l.get("length")):(r(l.get(Ei)),qi(t)&&r(l.get(rs)));break;case"delete":a||(r(l.get(Ei)),qi(t)&&r(l.get(rs)));break;case"set":qi(t)&&r(l.get(Ei));break}}Cs()}function Fi(t){const e=Ot(t);return e===t?e:(he(e,"iterate",An),Be(t)?e:e.map(Pe))}function Io(t){return he(t=Ot(t),"iterate",An),t}function He(t,e){return si(t)?Yi(Mi(t)?Pe(e):e):Pe(e)}const zc={__proto__:null,[Symbol.iterator](){return Ho(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Fi(this).concat(...t.map(e=>$t(e)?Fi(e):e))},entries(){return Ho(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,e){return Ze(this,"every",t,e,void 0,arguments)},filter(t,e){return Ze(this,"filter",t,e,i=>i.map(n=>He(this,n)),arguments)},find(t,e){return Ze(this,"find",t,e,i=>He(this,i),arguments)},findIndex(t,e){return Ze(this,"findIndex",t,e,void 0,arguments)},findLast(t,e){return Ze(this,"findLast",t,e,i=>He(this,i),arguments)},findLastIndex(t,e){return Ze(this,"findLastIndex",t,e,void 0,arguments)},forEach(t,e){return Ze(this,"forEach",t,e,void 0,arguments)},includes(...t){return jo(this,"includes",t)},indexOf(...t){return jo(this,"indexOf",t)},join(t){return Fi(this).join(t)},lastIndexOf(...t){return jo(this,"lastIndexOf",t)},map(t,e){return Ze(this,"map",t,e,void 0,arguments)},pop(){return rn(this,"pop")},push(...t){return rn(this,"push",t)},reduce(t,...e){return ir(this,"reduce",t,e)},reduceRight(t,...e){return ir(this,"reduceRight",t,e)},shift(){return rn(this,"shift")},some(t,e){return Ze(this,"some",t,e,void 0,arguments)},splice(...t){return rn(this,"splice",t)},toReversed(){return Fi(this).toReversed()},toSorted(t){return Fi(this).toSorted(t)},toSpliced(...t){return Fi(this).toSpliced(...t)},unshift(...t){return rn(this,"unshift",t)},values(){return Ho(this,"values",t=>He(this,t))}};function Ho(t,e,i){const n=Io(t),o=n[e]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const Nc=Array.prototype;function Ze(t,e,i,n,o,s){const l=Io(t),r=l!==t&&!Be(t),a=l[e];if(a!==Nc[e]){const f=a.apply(t,s);return r?Pe(f):f}let c=i;l!==t&&(r?c=function(f,v){return i.call(this,He(t,f),v,t)}:i.length>2&&(c=function(f,v){return i.call(this,f,v,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function ir(t,e,i,n){const o=Io(t),s=o!==t&&!Be(t);let l=i,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,f){return r&&(r=!1,c=He(t,c)),i.call(this,c,He(t,u),f,t)}):i.length>3&&(l=function(c,u,f){return i.call(this,c,u,f,t)}));const a=o[e](l,...n);return r?He(t,a):a}function jo(t,e,i){const n=Ot(t);he(n,"iterate",An);const o=n[e](...i);return(o===-1||o===!1)&&Ts(i[0])?(i[0]=Ot(i[0]),n[e](...i)):o}function rn(t,e,i=[]){ni(),Ss();const n=Ot(t)[e].apply(t,i);return Cs(),oi(),n}const Fc=ks("__proto__,__v_isRef,__isVue"),hl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Re));function Hc(t){Re(t)||(t=String(t));const e=Ot(this);return he(e,"has",t),e.hasOwnProperty(t)}class ml{constructor(e=!1,i=!1){this._isReadonly=e,this._isShallow=i}get(e,i,n){if(i==="__v_skip")return e.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?Jc:yl:s?bl:vl).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(n)?e:void 0;const l=$t(e);if(!o){let a;if(l&&(a=zc[i]))return a;if(i==="hasOwnProperty")return Hc}const r=Reflect.get(e,i,Jt(e)?e:n);if((Re(i)?hl.has(i):Fc(i))||(o||he(e,"get",i),s))return r;if(Jt(r)){const a=l&&xs(i)?r:r.value;return o&&Ht(a)?as(a):a}return Ht(r)?o?as(r):Ao(r):r}}class gl extends ml{constructor(e=!1){super(!1,e)}set(e,i,n,o){let s=e[i];const l=$t(e)&&xs(i);if(!this._isShallow){const c=si(s);if(!Be(n)&&!si(n)&&(s=Ot(s),n=Ot(n)),!l&&Jt(s)&&!Jt(n))return c||(s.value=n),!0}const r=l?Number(i)<e.length:zt(e,i),a=Reflect.set(e,i,n,Jt(e)?e:o);return e===Ot(o)&&a&&(r?Ue(n,s)&&Xe(e,"set",i,n):Xe(e,"add",i,n)),a}deleteProperty(e,i){const n=zt(e,i);e[i];const o=Reflect.deleteProperty(e,i);return o&&n&&Xe(e,"delete",i,void 0),o}has(e,i){const n=Reflect.has(e,i);return(!Re(i)||!hl.has(i))&&he(e,"has",i),n}ownKeys(e){return he(e,"iterate",$t(e)?"length":Ei),Reflect.ownKeys(e)}}class jc extends ml{constructor(e=!1){super(!0,e)}set(e,i){return!0}deleteProperty(e,i){return!0}}const Uc=new gl,Wc=new jc,Vc=new gl(!0);const ls=t=>t,jn=t=>Reflect.getPrototypeOf(t);function qc(t,e,i){return function(...n){const o=this.__v_raw,s=Ot(o),l=qi(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=i?ls:e?Yi:Pe;return!e&&he(s,"iterate",a?rs:Ei),ue(Object.create(c),{next(){const{value:f,done:v}=c.next();return v?{value:f,done:v}:{value:r?[u(f[0]),u(f[1])]:u(f),done:v}}})}}function Un(t){return function(...e){return t==="delete"?!1:t==="clear"?void 0:this}}function Kc(t,e){const i={get(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);t||(Ue(o,r)&&he(l,"get",o),he(l,"get",r));const{has:a}=jn(l),c=e?ls:t?Yi:Pe;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&he(Ot(o),"iterate",Ei),o.size},has(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);return t||(Ue(o,r)&&he(l,"has",o),he(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Ot(r),c=e?ls:t?Yi:Pe;return!t&&he(a,"iterate",Ei),r.forEach((u,f)=>o.call(s,c(u),c(f),l))}};return ue(i,t?{add:Un("add"),set:Un("set"),delete:Un("delete"),clear:Un("clear")}:{add(o){const s=Ot(this),l=jn(s),r=Ot(o),a=!e&&!Be(o)&&!si(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Xe(s,"add",a,a)),this},set(o,s){!e&&!Be(s)&&!si(s)&&(s=Ot(s));const l=Ot(this),{has:r,get:a}=jn(l);let c=r.call(l,o);c||(o=Ot(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Xe(l,"set",o,s):Xe(l,"add",o,s),this},delete(o){const s=Ot(this),{has:l,get:r}=jn(s);let a=l.call(s,o);a||(o=Ot(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Xe(s,"delete",o,void 0),c},clear(){const o=Ot(this),s=o.size!==0,l=o.clear();return s&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=qc(o,t,e)}),i}function As(t,e){const i=Kc(t,e);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(i,o)&&o in n?i:n,o,s)}const Gc={get:As(!1,!1)},Zc={get:As(!1,!0)},Yc={get:As(!0,!1)};const vl=new WeakMap,bl=new WeakMap,yl=new WeakMap,Jc=new WeakMap;function Xc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ao(t){return si(t)?t:Bs(t,!1,Uc,Gc,vl)}function Qc(t){return Bs(t,!1,Vc,Zc,bl)}function as(t){return Bs(t,!0,Wc,Yc,yl)}function Bs(t,e,i,n,o){if(!Ht(t)||t.__v_raw&&!(e&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Xc(Sc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:i);return o.set(t,r),r}function Mi(t){return si(t)?Mi(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function Ts(t){return t?!!t.__v_raw:!1}function Ot(t){const e=t&&t.__v_raw;return e?Ot(e):t}function td(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&il(t,"__v_skip",!0),t}const Pe=t=>Ht(t)?Ao(t):t,Yi=t=>Ht(t)?as(t):t;function Jt(t){return t?t.__v_isRef===!0:!1}function vt(t){return ed(t,!1)}function ed(t,e){return Jt(t)?t:new id(t,e)}class id{constructor(e,i){this.dep=new Is,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?e:Ot(e),this._value=i?e:Pe(e),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(e){const i=this._rawValue,n=this.__v_isShallow||Be(e)||si(e);e=n?e:Ot(e),Ue(e,i)&&(this._rawValue=e,this._value=n?e:Pe(e),this.dep.trigger())}}function bt(t){return Jt(t)?t.value:t}const nd={get:(t,e,i)=>e==="__v_raw"?t:bt(Reflect.get(t,e,i)),set:(t,e,i,n)=>{const o=t[e];return Jt(o)&&!Jt(i)?(o.value=i,!0):Reflect.set(t,e,i,n)}};function kl(t){return Mi(t)?t:new Proxy(t,nd)}class od{constructor(e,i,n){this.fn=e,this.setter=i,this._value=void 0,this.dep=new Is(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=In-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Vt!==this)return al(this,!0),!0}get value(){const e=this.dep.track();return ul(this),e&&(e.version=this.dep.version),this._value}set value(e){this.setter&&this.setter(e)}}function sd(t,e,i=!1){let n,o;return Bt(t)?n=t:(n=t.get,o=t.set),new od(n,o,i)}const Wn={},uo=new WeakMap;let Ii;function rd(t,e=!1,i=Ii){if(i){let n=uo.get(i);n||uo.set(i,n=[]),n.push(t)}}function ld(t,e,i=Wt){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=T=>o?T:Be(T)||o===!1||o===0?Qe(T,1):Qe(T);let u,f,v,d,y=!1,m=!1;if(Jt(t)?(f=()=>t.value,y=Be(t)):Mi(t)?(f=()=>c(t),y=!0):$t(t)?(m=!0,y=t.some(T=>Mi(T)||Be(T)),f=()=>t.map(T=>{if(Jt(T))return T.value;if(Mi(T))return c(T);if(Bt(T))return a?a(T,2):T()})):Bt(t)?e?f=a?()=>a(t,2):t:f=()=>{if(v){ni();try{v()}finally{oi()}}const T=Ii;Ii=u;try{return a?a(t,3,[d]):t(d)}finally{Ii=T}}:f=qe,e&&o){const T=f,E=o===!0?1/0:o;f=()=>Qe(T(),E)}const g=Rc(),k=()=>{u.stop(),g&&g.active&&ws(g.effects,u)};if(s&&e){const T=e;e=(...E)=>{const B=T(...E);return k(),B}}let x=m?new Array(t.length).fill(Wn):Wn;const I=T=>{if(!(!(u.flags&1)||!u.dirty&&!T))if(e){const E=u.run();if(T||o||y||(m?E.some((B,w)=>Ue(B,x[w])):Ue(E,x))){v&&v();const B=Ii;Ii=u;try{const w=[E,x===Wn?void 0:m&&x[0]===Wn?[]:x,d];x=E,a?a(e,3,w):e(...w)}finally{Ii=B}}}else u.run()};return r&&r(I),u=new rl(f),u.scheduler=l?()=>l(I,!1):I,d=T=>rd(T,!1,u),v=u.onStop=()=>{const T=uo.get(u);if(T){if(a)a(T,4);else for(const E of T)E();uo.delete(u)}},e?n?I(!0):x=u.run():l?l(I.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function Qe(t,e=1/0,i){if(e<=0||!Ht(t)||t.__v_skip||(i=i||new Map,(i.get(t)||0)>=e))return t;if(i.set(t,e),e--,Jt(t))Qe(t.value,e,i);else if($t(t))for(let n=0;n<t.length;n++)Qe(t[n],e,i);else if(tn(t)||qi(t))t.forEach(n=>{Qe(n,e,i)});else if(el(t)){for(const n in t)Qe(t[n],e,i);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],e,i)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Rn(t,e,i,n){try{return n?t(...n):t()}catch(o){Bo(o,e,i)}}function Oe(t,e,i,n){if(Bt(t)){const o=Rn(t,e,i,n);return o&&Qr(o)&&o.catch(s=>{Bo(s,e,i)}),o}if($t(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Oe(t[s],e,i,n));return o}}function Bo(t,e,i,n=!0){const o=e?e.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=e&&e.appContext.config||Wt;if(e){let r=e.parent;const a=e.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](t,a,c)===!1)return}r=r.parent}if(s){ni(),Rn(s,null,10,[t,a,c]),oi();return}}ad(t,i,o,n,l)}function ad(t,e,i,n=!0,o=!1){if(o)throw t;console.error(t)}const be=[];let Fe=-1;const Ki=[];let fi=null,Hi=0;const wl=Promise.resolve();let fo=null;function xl(t){const e=fo||wl;return t?e.then(this?t.bind(this):t):e}function cd(t){let e=Fe+1,i=be.length;for(;e<i;){const n=e+i>>>1,o=be[n],s=Bn(o);s<t||s===t&&o.flags&2?e=n+1:i=n}return e}function Es(t){if(!(t.flags&1)){const e=Bn(t),i=be[be.length-1];!i||!(t.flags&2)&&e>=Bn(i)?be.push(t):be.splice(cd(e),0,t),t.flags|=1,_l()}}function _l(){fo||(fo=wl.then(Cl))}function dd(t){$t(t)?Ki.push(...t):fi&&t.id===-1?fi.splice(Hi+1,0,t):t.flags&1||(Ki.push(t),t.flags|=1),_l()}function nr(t,e,i=Fe+1){for(;i<be.length;i++){const n=be[i];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;be.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Sl(t){if(Ki.length){const e=[...new Set(Ki)].sort((i,n)=>Bn(i)-Bn(n));if(Ki.length=0,fi){fi.push(...e);return}for(fi=e,Hi=0;Hi<fi.length;Hi++){const i=fi[Hi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}fi=null,Hi=0}}const Bn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function Cl(t){try{for(Fe=0;Fe<be.length;Fe++){const e=be[Fe];e&&!(e.flags&8)&&(e.flags&4&&(e.flags&=-2),Rn(e,e.i,e.i?15:14),e.flags&4||(e.flags&=-2))}}finally{for(;Fe<be.length;Fe++){const e=be[Fe];e&&(e.flags&=-2)}Fe=-1,be.length=0,Sl(),fo=null,(be.length||Ki.length)&&Cl()}}let de=null,$l=null;function po(t){const e=de;return de=t,$l=t&&t.type.__scopeId||null,e}function Il(t,e=de,i){if(!e||t._n)return t;const n=(...o)=>{n._d&&mr(-1);const s=po(e),l=ei.length;let r;try{r=t(...o)}finally{for(let a=ei.length;a>l;a--)Os();po(s),n._d&&mr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,e){if(de===null)return t;const i=Do(de),n=t.dirs||(t.dirs=[]);for(let o=0;o<e.length;o++){let[s,l,r,a=Wt]=e[o];s&&(Bt(s)&&(s={mounted:s,updated:s}),s.deep&&Qe(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function wi(t,e,i,n){const o=t.dirs,s=e&&e.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Oe(a,i,8,[t.el,r,t,e]),oi())}}function ud(t,e){if(me){let i=me.provides;const n=me.parent&&me.parent.provides;n===i&&(i=me.provides=Object.create(n)),i[t]=e}}function ti(t,e,i=!1){const n=cu();if(n||Zi){let o=Zi?Zi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return i&&Bt(e)?e.call(n&&n.proxy):e}}const fd=Symbol.for("v-scx"),pd=()=>ti(fd);function Di(t,e,i){return Al(t,e,i)}function Al(t,e,i=Wt){const{immediate:n,deep:o,flush:s,once:l}=i,r=ue({},i),a=e&&n||!e&&s!=="post";let c;if(En){if(s==="sync"){const d=pd();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=me;r.call=(d,y,m)=>Oe(d,u,y,m);let f=!1;s==="post"?r.scheduler=d=>{we(d,u&&u.suspense)}:s!=="sync"&&(f=!0,r.scheduler=(d,y)=>{y?d():Es(d)}),r.augmentJob=d=>{e&&(d.flags|=4),f&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const v=ld(t,e,r);return En&&(c?c.push(v):a&&v()),v}function hd(t,e,i){const n=this.proxy,o=ee(t)?t.includes(".")?Bl(n,t):()=>n[t]:t.bind(n,n);let s;Bt(e)?s=e:(s=e.handler,i=e);const l=On(this),r=Al(o,s.bind(n),i);return l(),r}function Bl(t,e){const i=e.split(".");return()=>{let n=t;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const md=Symbol("_vte"),gd=t=>t.__isTeleport,Uo=Symbol("_leaveCb");function Ms(t,e){t.shapeFlag&6&&t.component?(t.transition=e,Ms(t.component.subTree,e)):t.shapeFlag&128?(t.ssContent.transition=e.clone(t.ssContent),t.ssFallback.transition=e.clone(t.ssFallback)):t.transition=e}function Ce(t,e){return Bt(t)?ue({name:t.name},e,{setup:t}):t}function Tl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function or(t,e){let i;return!!((i=Object.getOwnPropertyDescriptor(t,e))&&!i.configurable)}const ho=new WeakMap;function mn(t,e,i,n,o=!1){if($t(t)){t.forEach((m,g)=>mn(m,e&&($t(e)?e[g]:e),i,n,o));return}if(Gi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&mn(t,e,i,n.component.subTree);return}const s=n.shapeFlag&4?Do(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=e&&e.r,u=r.refs===Wt?r.refs={}:r.refs,f=r.setupState,v=Ot(f),d=f===Wt?Xr:m=>or(u,m)?!1:zt(v,m),y=(m,g)=>!(g&&or(u,g));if(c!=null&&c!==a){if(sr(e),ee(c))u[c]=null,d(c)&&(f[c]=null);else if(Jt(c)){const m=e;y(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Bt(a))Rn(a,r,12,[l,u]);else{const m=ee(a),g=Jt(a);if(m||g){const k=()=>{if(t.f){const x=m?d(a)?f[a]:u[a]:y()||!t.k?a.value:u[t.k];if(o)$t(x)&&ws(x,s);else if($t(x))x.includes(s)||x.push(s);else if(m)u[a]=[s],d(a)&&(f[a]=u[a]);else{const I=[s];y(a,t.k)&&(a.value=I),t.k&&(u[t.k]=I)}}else m?(u[a]=l,d(a)&&(f[a]=l)):g&&(y(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const x=()=>{k(),ho.delete(t)};x.id=-1,ho.set(t,x),we(x,i)}else sr(t),k()}}}function sr(t){const e=ho.get(t);e&&(e.flags|=8,ho.delete(t))}$o().requestIdleCallback;$o().cancelIdleCallback;const Gi=t=>!!t.type.__asyncLoader,El=t=>t.type.__isKeepAlive;function vd(t,e){Ml(t,"a",e)}function bd(t,e){Ml(t,"da",e)}function Ml(t,e,i=me){const n=t.__wdc||(t.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(To(e,n,i),i){let o=i.parent;for(;o&&o.parent;)El(o.parent.vnode)&&yd(n,e,i,o),o=o.parent}}function yd(t,e,i,n){const o=To(e,t,n,!0);Ls(()=>{ws(n[e],o)},i)}function To(t,e,i=me,n=!1){if(i){const o=i[t]||(i[t]=[]),s=e.__weh||(e.__weh=(...l)=>{ni();const r=On(i),a=Oe(e,i,t,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const li=t=>(e,i=me)=>{(!En||t==="sp")&&To(t,(...n)=>e(...n),i)},kd=li("bm"),Pn=li("m"),wd=li("bu"),xd=li("u"),Ds=li("bum"),Ls=li("um"),_d=li("sp"),Sd=li("rtg"),Cd=li("rtc");function $d(t,e=me){To("ec",t,e)}const Id="components";function Ad(t,e){return Td(Id,t,!0,e)||t}const Bd=Symbol.for("v-ndc");function Td(t,e,i=!0,n=!1){const o=de||me;if(o){const s=o.type;{const r=hu(s,!1);if(r&&(r===e||r===ye(e)||r===So(ye(e))))return s}const l=rr(o[t]||s[t],e)||rr(o.appContext[t],e);return!l&&n?s:l}}function rr(t,e){return t&&(t[e]||t[ye(e)]||t[So(ye(e))])}function xe(t,e,i,n){let o;const s=i,l=$t(t);if(l||ee(t)){const r=l&&Mi(t);let a=!1,c=!1;r&&(a=!Be(t),c=si(t),t=Io(t)),o=new Array(t.length);for(let u=0,f=t.length;u<f;u++)o[u]=e(a?c?Yi(Pe(t[u])):Pe(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=e(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>e(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=e(t[u],u,a,s)}}else o=[];return o}function Vn(t,e,i={},n,o,s){if(de.ce||de.parent&&Gi(de.parent)&&de.parent.ce){const c=i,u=Object.keys(c).length>0;return e!=="default"&&(c.name=e),nt(),De(Kt,null,[dt("slot",c,n&&n())],u?-2:64)}let l=t[e];l&&l._c&&(l._d=!1);const r=ei.length;nt();let a;try{const c=l&&Dl(l(i)),u=i.key||s||c&&c.key;a=De(Kt,{key:(u&&!Re(u)?u:`_${e}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ei.length;u>r;u--)Os();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Dl(t){return t.some(e=>zs(e)?!(e.type===ri||e.type===Kt&&!Dl(e.children)):!0)?t:null}const cs=t=>t?Ql(t)?Do(t):cs(t.parent):null,gn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>cs(t.parent),$root:t=>cs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Rl(t),$forceUpdate:t=>t.f||(t.f=()=>{Es(t.update)}),$nextTick:t=>t.n||(t.n=xl.bind(t.proxy)),$watch:t=>hd.bind(t)}),Wo=(t,e)=>t!==Wt&&!t.__isScriptSetup&&zt(t,e),Ed={get({_:t},e){if(e==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(e[0]!=="$"){const v=l[e];if(v!==void 0)switch(v){case 1:return n[e];case 2:return o[e];case 4:return i[e];case 3:return s[e]}else{if(Wo(n,e))return l[e]=1,n[e];if(o!==Wt&&zt(o,e))return l[e]=2,o[e];if(zt(s,e))return l[e]=3,s[e];if(i!==Wt&&zt(i,e))return l[e]=4,i[e];ds&&(l[e]=0)}}const c=gn[e];let u,f;if(c)return e==="$attrs"&&he(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[e]))return u;if(i!==Wt&&zt(i,e))return l[e]=4,i[e];if(f=a.config.globalProperties,zt(f,e))return f[e]},set({_:t},e,i){const{data:n,setupState:o,ctx:s}=t;return Wo(o,e)?(o[e]=i,!0):n!==Wt&&zt(n,e)?(n[e]=i,!0):zt(t.props,e)||e[0]==="$"&&e.slice(1)in t?!1:(s[e]=i,!0)},has({_:{data:t,setupState:e,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||t!==Wt&&r[0]!=="$"&&zt(t,r)||Wo(e,r)||zt(s,r)||zt(n,r)||zt(gn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,e,i){return i.get!=null?t._.accessCache[e]=0:zt(i,"value")&&this.set(t,e,i.value,null),Reflect.defineProperty(t,e,i)}};function lr(t){return $t(t)?t.reduce((e,i)=>(e[i]=null,e),{}):t}let ds=!0;function Md(t){const e=Rl(t),i=t.proxy,n=t.ctx;ds=!1,e.beforeCreate&&ar(e.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:f,mounted:v,beforeUpdate:d,updated:y,activated:m,deactivated:g,beforeDestroy:k,beforeUnmount:x,destroyed:I,unmounted:T,render:E,renderTracked:B,renderTriggered:w,errorCaptured:H,serverPrefetch:j,expose:O,inheritAttrs:q,components:S,directives:D,filters:b}=e;if(c&&Dd(c,n,null),l)for(const L in l){const U=l[L];Bt(U)&&(n[L]=U.bind(i))}if(o){const L=o.call(i,i);Ht(L)&&(t.data=Ao(L))}if(ds=!0,s)for(const L in s){const U=s[L],V=Bt(U)?U.bind(i,i):Bt(U.get)?U.get.bind(i,i):qe,et=!Bt(U)&&Bt(U.set)?U.set.bind(i):qe,A=St({get:V,set:et});Object.defineProperty(n,L,{enumerable:!0,configurable:!0,get:()=>A.value,set:M=>A.value=M})}if(r)for(const L in r)Ll(r[L],n,i,L);if(a){const L=Bt(a)?a.call(i):a;Reflect.ownKeys(L).forEach(U=>{ud(U,L[U])})}u&&ar(u,t,"c");function Y(L,U){$t(U)?U.forEach(V=>L(V.bind(i))):U&&L(U.bind(i))}if(Y(kd,f),Y(Pn,v),Y(wd,d),Y(xd,y),Y(vd,m),Y(bd,g),Y($d,H),Y(Cd,B),Y(Sd,w),Y(Ds,x),Y(Ls,T),Y(_d,j),$t(O))if(O.length){const L=t.exposed||(t.exposed={});O.forEach(U=>{Object.defineProperty(L,U,{get:()=>i[U],set:V=>i[U]=V,enumerable:!0})})}else t.exposed||(t.exposed={});E&&t.render===qe&&(t.render=E),q!=null&&(t.inheritAttrs=q),S&&(t.components=S),D&&(t.directives=D),j&&Tl(t)}function Dd(t,e,i=qe){$t(t)&&(t=us(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Jt(s)?Object.defineProperty(e,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):e[n]=s}}function ar(t,e,i){Oe($t(t)?t.map(n=>n.bind(e.proxy)):t.bind(e.proxy),e,i)}function Ll(t,e,i,n){let o=n.includes(".")?Bl(i,n):()=>i[n];if(ee(t)){const s=e[t];Bt(s)&&Di(o,s)}else if(Bt(t))Di(o,t.bind(i));else if(Ht(t))if($t(t))t.forEach(s=>Ll(s,e,i,n));else{const s=Bt(t.handler)?t.handler.bind(i):e[t.handler];Bt(s)&&Di(o,s,t)}}function Rl(t){const e=t.type,{mixins:i,extends:n}=e,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(e);let a;return r?a=r:!o.length&&!i&&!n?a=e:(a={},o.length&&o.forEach(c=>mo(a,c,l,!0)),mo(a,e,l)),Ht(e)&&s.set(e,a),a}function mo(t,e,i,n=!1){const{mixins:o,extends:s}=e;s&&mo(t,s,i,!0),o&&o.forEach(l=>mo(t,l,i,!0));for(const l in e)if(!(n&&l==="expose")){const r=Ld[l]||i&&i[l];t[l]=r?r(t[l],e[l]):e[l]}return t}const Ld={data:cr,props:dr,emits:dr,methods:cn,computed:cn,beforeCreate:ve,created:ve,beforeMount:ve,mounted:ve,beforeUpdate:ve,updated:ve,beforeDestroy:ve,beforeUnmount:ve,destroyed:ve,unmounted:ve,activated:ve,deactivated:ve,errorCaptured:ve,serverPrefetch:ve,components:cn,directives:cn,watch:Pd,provide:cr,inject:Rd};function cr(t,e){return e?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(e)?e.call(this,this):e)}:e:t}function Rd(t,e){return cn(us(t),us(e))}function us(t){if($t(t)){const e={};for(let i=0;i<t.length;i++)e[t[i]]=t[i];return e}return t}function ve(t,e){return t?[...new Set([].concat(t,e))]:e}function cn(t,e){return t?ue(Object.create(null),t,e):e}function dr(t,e){return t?$t(t)&&$t(e)?[...new Set([...t,...e])]:ue(Object.create(null),lr(t),lr(e??{})):e}function Pd(t,e){if(!t)return e;if(!e)return t;const i=ue(Object.create(null),t);for(const n in e)i[n]=ve(t[n],e[n]);return i}function Pl(){return{app:null,config:{isNativeTag:Xr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Od=0;function zd(t,e){return function(n,o=null){Bt(n)||(n=ue({},n)),o!=null&&!Ht(o)&&(o=null);const s=Pl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Od++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:gu,get config(){return s.config},set config(u){},use(u,...f){return l.has(u)||(u&&Bt(u.install)?(l.add(u),u.install(c,...f)):Bt(u)&&(l.add(u),u(c,...f))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,f){return f?(s.components[u]=f,c):s.components[u]},directive(u,f){return f?(s.directives[u]=f,c):s.directives[u]},mount(u,f,v){if(!a){const d=c._ceVNode||dt(n,o);return d.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),t(d,u,v),a=!0,c._container=u,u.__vue_app__=c,Do(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Oe(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,f){return s.provides[u]=f,c},runWithContext(u){const f=Zi;Zi=c;try{return u()}finally{Zi=f}}};return c}}let Zi=null;const Nd=(t,e)=>e==="modelValue"||e==="model-value"?t.modelModifiers:t[`${e}Modifiers`]||t[`${ye(e)}Modifiers`]||t[`${bi(e)}Modifiers`];function Fd(t,e,...i){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let o=i;const s=e.startsWith("update:"),l=s&&Nd(n,e.slice(7));l&&(l.trim&&(o=i.map(u=>ee(u)?u.trim():u)),l.number&&(o=i.map(Co)));let r,a=n[r=zo(e)]||n[r=zo(ye(e))];!a&&s&&(a=n[r=zo(bi(e))]),a&&Oe(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Oe(c,t,6,o)}}const Hd=new WeakMap;function Ol(t,e,i=!1){const n=i?Hd:e.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const u=Ol(c,e,!0);u&&(r=!0,ue(l,u))};!i&&e.mixins.length&&e.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):($t(s)?s.forEach(a=>l[a]=null):ue(l,s),Ht(t)&&n.set(t,l),l)}function Eo(t,e){return!t||!wo(e)?!1:(e=e.slice(2),e=e==="Once"?e:e.replace(/Once$/,""),zt(t,e[0].toLowerCase()+e.slice(1))||zt(t,bi(e))||zt(t,e))}function ur(t){const{type:e,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:f,data:v,setupState:d,ctx:y,inheritAttrs:m}=t,g=po(t);let k,x;try{if(i.shapeFlag&4){const T=o||n,E=T;k=je(c.call(E,T,u,f,d,v,y)),x=r}else{const T=e;k=je(T.length>1?T(f,{attrs:r,slots:l,emit:a}):T(f,null)),x=e.props?r:jd(r)}}catch(T){ei.length=0,Bo(T,t,1),k=dt(ri)}let I=k;if(x&&m!==!1){const T=Object.keys(x),{shapeFlag:E}=I;T.length&&E&7&&(s&&T.some(xo)&&(x=Ud(x,s)),I=Ji(I,x,!1,!0))}return i.dirs&&(I=Ji(I,null,!1,!0),I.dirs=I.dirs?I.dirs.concat(i.dirs):i.dirs),i.transition&&Ms(I,i.transition),k=I,po(g),k}const jd=t=>{let e;for(const i in t)(i==="class"||i==="style"||wo(i))&&((e||(e={}))[i]=t[i]);return e},Ud=(t,e)=>{const i={};for(const n in t)(!xo(n)||!(n.slice(9)in e))&&(i[n]=t[n]);return i};function Wd(t,e,i){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=e,c=s.emitsOptions;if(e.dirs||e.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?fr(n,l,c):!!l;if(a&8){const u=e.dynamicProps;for(let f=0;f<u.length;f++){const v=u[f];if(zl(l,n,v)&&!Eo(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?fr(n,l,c):!0:!!l;return!1}function fr(t,e,i){const n=Object.keys(e);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(zl(e,t,s)&&!Eo(i,s))return!0}return!1}function zl(t,e,i){const n=t[i],o=e[i];return i==="style"&&Ht(n)&&Ht(o)?!en(n,o):n!==o}function Vd({vnode:t,parent:e,suspense:i},n){for(;e;){const o=e.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=e.vnode).el=n,e=e.parent;else break}i&&i.activeBranch===t&&(i.vnode.el=n)}const Nl={},Fl=()=>Object.create(Nl),Hl=t=>Object.getPrototypeOf(t)===Nl;function qd(t,e,i,n=!1){const o={},s=Fl();t.propsDefaults=Object.create(null),jl(t,e,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);i?t.props=n?o:Qc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Kd(t,e,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Ot(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let f=0;f<u.length;f++){let v=u[f];if(Eo(t.emitsOptions,v))continue;const d=e[v];if(a)if(zt(s,v))d!==s[v]&&(s[v]=d,c=!0);else{const y=ye(v);o[y]=fs(a,r,y,d,t,!1)}else d!==s[v]&&(s[v]=d,c=!0)}}}else{jl(t,e,o,s)&&(c=!0);let u;for(const f in r)(!e||!zt(e,f)&&((u=bi(f))===f||!zt(e,u)))&&(a?i&&(i[f]!==void 0||i[u]!==void 0)&&(o[f]=fs(a,r,f,void 0,t,!0)):delete o[f]);if(s!==r)for(const f in s)(!e||!zt(e,f))&&(delete s[f],c=!0)}c&&Xe(t.attrs,"set","")}function jl(t,e,i,n){const[o,s]=t.propsOptions;let l=!1,r;if(e)for(let a in e){if(fn(a))continue;const c=e[a];let u;o&&zt(o,u=ye(a))?!s||!s.includes(u)?i[u]=c:(r||(r={}))[u]=c:Eo(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Ot(i),c=r||Wt;for(let u=0;u<s.length;u++){const f=s[u];i[f]=fs(o,a,f,c[f],t,!zt(c,f))}}return l}function fs(t,e,i,n,o,s){const l=t[i];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const u=On(o);n=c[i]=a.call(null,e),u()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===bi(i))&&(n=!0))}return n}const Gd=new WeakMap;function Ul(t,e,i=!1){const n=i?Gd:e.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!Bt(t)){const u=f=>{a=!0;const[v,d]=Ul(f,e,!0);ue(l,v),d&&r.push(...d)};!i&&e.mixins.length&&e.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,Vi),Vi;if($t(s))for(let u=0;u<s.length;u++){const f=ye(s[u]);pr(f)&&(l[f]=Wt)}else if(s)for(const u in s){const f=ye(u);if(pr(f)){const v=s[u],d=l[f]=$t(v)||Bt(v)?{type:v}:ue({},v),y=d.type;let m=!1,g=!0;if($t(y))for(let k=0;k<y.length;++k){const x=y[k],I=Bt(x)&&x.name;if(I==="Boolean"){m=!0;break}else I==="String"&&(g=!1)}else m=Bt(y)&&y.name==="Boolean";d[0]=m,d[1]=g,(m||zt(d,"default"))&&r.push(f)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function pr(t){return t[0]!=="$"&&!fn(t)}const Rs=t=>t==="_"||t==="_ctx"||t==="$stable",Ps=t=>$t(t)?t.map(je):[je(t)],Zd=(t,e,i)=>{if(e._n)return e;const n=Il((...o)=>Ps(e(...o)),i);return n._c=!1,n},Wl=(t,e,i)=>{const n=t._ctx;for(const o in t){if(Rs(o))continue;const s=t[o];if(Bt(s))e[o]=Zd(o,s,n);else if(s!=null){const l=Ps(s);e[o]=()=>l}}},Vl=(t,e)=>{const i=Ps(e);t.slots.default=()=>i},ql=(t,e,i)=>{for(const n in e)(i||!Rs(n))&&(t[n]=e[n])},Yd=(t,e,i)=>{const n=t.slots=Fl();if(t.vnode.shapeFlag&32){const o=e._;o?(ql(n,e,i),i&&il(n,"_",o,!0)):Wl(e,n)}else e&&Vl(t,e)},Jd=(t,e,i)=>{const{vnode:n,slots:o}=t;let s=!0,l=Wt;if(n.shapeFlag&32){const r=e._;r?i&&r===1?s=!1:ql(o,e,i):(s=!e.$stable,Wl(e,o)),l=e}else e&&(Vl(t,e),l={default:1});if(s)for(const r in o)!Rs(r)&&l[r]==null&&delete o[r]},we=iu;function Xd(t){return Qd(t)}function Qd(t,e){const i=$o();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:f,nextSibling:v,setScopeId:d=qe,insertStaticContent:y}=t,m=(C,P,h,z=null,N=null,_=null,$=void 0,R=null,Z=!!P.dynamicChildren)=>{if(C===P)return;C&&!ln(C,P)&&(z=pt(C),M(C,N,_,!0),C=null),P.patchFlag===-2&&(Z=!1,P.dynamicChildren=null);const{type:G,ref:K,shapeFlag:it}=P;switch(G){case Mo:g(C,P,h,z);break;case ri:k(C,P,h,z);break;case Jn:C==null&&x(P,h,z,$);break;case Kt:S(C,P,h,z,N,_,$,R,Z);break;default:it&1?E(C,P,h,z,N,_,$,R,Z):it&6?D(C,P,h,z,N,_,$,R,Z):(it&64||it&128)&&G.process(C,P,h,z,N,_,$,R,Z,at)}K!=null&&N?mn(K,C&&C.ref,_,P||C,!P):K==null&&C&&C.ref!=null&&mn(C.ref,null,_,C,!0)},g=(C,P,h,z)=>{if(C==null)n(P.el=r(P.children),h,z);else{const N=P.el=C.el;P.children!==C.children&&c(N,P.children)}},k=(C,P,h,z)=>{C==null?n(P.el=a(P.children||""),h,z):P.el=C.el},x=(C,P,h,z)=>{[C.el,C.anchor]=y(C.children,P,h,z,C.el,C.anchor)},I=({el:C,anchor:P},h,z)=>{let N;for(;C&&C!==P;)N=v(C),n(C,h,z),C=N;n(P,h,z)},T=({el:C,anchor:P})=>{let h;for(;C&&C!==P;)h=v(C),o(C),C=h;o(P)},E=(C,P,h,z,N,_,$,R,Z)=>{if(P.type==="svg"?$="svg":P.type==="math"&&($="mathml"),C==null)B(P,h,z,N,_,$,R,Z);else{const G=C.el&&C.el._isVueCE?C.el:null;try{G&&G._beginPatch(),j(C,P,N,_,$,R,Z)}finally{G&&G._endPatch()}}},B=(C,P,h,z,N,_,$,R)=>{let Z,G;const{props:K,shapeFlag:it,transition:ct,dirs:rt}=C;if(Z=C.el=l(C.type,_,K&&K.is,K),it&8?u(Z,C.children):it&16&&H(C.children,Z,null,z,N,Vo(C,_),$,R),rt&&wi(C,null,z,"created"),w(Z,C,C.scopeId,$,z),K){for(const _t in K)_t!=="value"&&!fn(_t)&&s(Z,_t,null,K[_t],_,z);"value"in K&&s(Z,"value",null,K.value,_),(G=K.onVnodeBeforeMount)&&Ne(G,z,C)}rt&&wi(C,null,z,"beforeMount");const mt=tu(N,ct);mt&&ct.beforeEnter(Z),n(Z,P,h),((G=K&&K.onVnodeMounted)||mt||rt)&&we(()=>{try{G&&Ne(G,z,C),mt&&ct.enter(Z),rt&&wi(C,null,z,"mounted")}finally{}},N)},w=(C,P,h,z,N)=>{if(h&&d(C,h),z)for(let _=0;_<z.length;_++)d(C,z[_]);if(N){let _=N.subTree;if(P===_||Yl(_.type)&&(_.ssContent===P||_.ssFallback===P)){const $=N.vnode;w(C,$,$.scopeId,$.slotScopeIds,N.parent)}}},H=(C,P,h,z,N,_,$,R,Z=0)=>{for(let G=Z;G<C.length;G++){const K=C[G]=R?Je(C[G]):je(C[G]);m(null,K,P,h,z,N,_,$,R)}},j=(C,P,h,z,N,_,$)=>{const R=P.el=C.el;let{patchFlag:Z,dynamicChildren:G,dirs:K}=P;Z|=C.patchFlag&16;const it=C.props||Wt,ct=P.props||Wt;let rt;if(h&&xi(h,!1),(rt=ct.onVnodeBeforeUpdate)&&Ne(rt,h,P,C),K&&wi(P,C,h,"beforeUpdate"),h&&xi(h,!0),G&&(!C.dynamicChildren||C.dynamicChildren.length!==G.length)&&(Z=0,$=!1,G=null),(it.innerHTML&&ct.innerHTML==null||it.textContent&&ct.textContent==null)&&u(R,""),G?O(C.dynamicChildren,G,R,h,z,Vo(P,N),_):$||U(C,P,R,null,h,z,Vo(P,N),_,!1),Z>0){if(Z&16)q(R,it,ct,h,N);else if(Z&2&&it.class!==ct.class&&s(R,"class",null,ct.class,N),Z&4&&s(R,"style",it.style,ct.style,N),Z&8){const mt=P.dynamicProps;for(let _t=0;_t<mt.length;_t++){const wt=mt[_t],Lt=it[wt],Gt=ct[wt];(Gt!==Lt||wt==="value")&&s(R,wt,Lt,Gt,N,h)}}Z&1&&C.children!==P.children&&u(R,P.children)}else!$&&G==null&&q(R,it,ct,h,N);((rt=ct.onVnodeUpdated)||K)&&we(()=>{rt&&Ne(rt,h,P,C),K&&wi(P,C,h,"updated")},z)},O=(C,P,h,z,N,_,$)=>{for(let R=0;R<P.length;R++){const Z=C[R],G=P[R],K=Z.el&&(Z.type===Kt||!ln(Z,G)||Z.shapeFlag&198)?f(Z.el):h;m(Z,G,K,null,z,N,_,$,!0)}},q=(C,P,h,z,N)=>{if(P!==h){if(P!==Wt)for(const _ in P)!fn(_)&&!(_ in h)&&s(C,_,P[_],null,N,z);for(const _ in h){if(fn(_))continue;const $=h[_],R=P[_];$!==R&&_!=="value"&&s(C,_,R,$,N,z)}"value"in h&&s(C,"value",P.value,h.value,N)}},S=(C,P,h,z,N,_,$,R,Z)=>{const G=P.el=C?C.el:r(""),K=P.anchor=C?C.anchor:r("");let{patchFlag:it,dynamicChildren:ct,slotScopeIds:rt}=P;rt&&(R=R?R.concat(rt):rt),C==null?(n(G,h,z),n(K,h,z),H(P.children||[],h,K,N,_,$,R,Z)):it>0&&it&64&&ct&&C.dynamicChildren&&C.dynamicChildren.length===ct.length?(O(C.dynamicChildren,ct,h,N,_,$,R),(P.key!=null||N&&P===N.subTree)&&Kl(C,P,!0)):U(C,P,h,K,N,_,$,R,Z)},D=(C,P,h,z,N,_,$,R,Z)=>{P.slotScopeIds=R,C==null?P.shapeFlag&512?N.ctx.activate(P,h,z,$,Z):b(P,h,z,N,_,$,Z):W(C,P,Z)},b=(C,P,h,z,N,_,$)=>{const R=C.component=au(C,z,N);if(El(C)&&(R.ctx.renderer=at),du(R,!1,$),R.asyncDep){if(N&&N.registerDep(R,Y,$),!C.el){const Z=R.subTree=dt(ri);k(null,Z,P,h),C.placeholder=Z.el}}else Y(R,C,P,h,N,_,$)},W=(C,P,h)=>{const z=P.component=C.component;if(Wd(C,P,h))if(z.asyncDep&&!z.asyncResolved){L(z,P,h);return}else z.next=P,z.update();else P.el=C.el,z.vnode=P},Y=(C,P,h,z,N,_,$)=>{const R=()=>{if(C.isMounted){let{next:it,bu:ct,u:rt,parent:mt,vnode:_t}=C;{const ie=Gl(C);if(ie){it&&(it.el=_t.el,L(C,it,$)),ie.asyncDep.then(()=>{we(()=>{C.isUnmounted||G()},N)});return}}let wt=it,Lt;xi(C,!1),it?(it.el=_t.el,L(C,it,$)):it=_t,ct&&Yn(ct),(Lt=it.props&&it.props.onVnodeBeforeUpdate)&&Ne(Lt,mt,it,_t),xi(C,!0);const Gt=ur(C),Yt=C.subTree;C.subTree=Gt,m(Yt,Gt,f(Yt.el),pt(Yt),C,N,_),it.el=Gt.el,wt===null&&Vd(C,Gt.el),rt&&we(rt,N),(Lt=it.props&&it.props.onVnodeUpdated)&&we(()=>Ne(Lt,mt,it,_t),N)}else{let it;const{el:ct,props:rt}=P,{bm:mt,m:_t,parent:wt,root:Lt,type:Gt}=C,Yt=Gi(P);xi(C,!1),mt&&Yn(mt),!Yt&&(it=rt&&rt.onVnodeBeforeMount)&&Ne(it,wt,P),xi(C,!0);{Lt.ce&&Lt.ce._hasShadowRoot()&&Lt.ce._injectChildStyle(Gt,C.parent?C.parent.type:void 0);const ie=C.subTree=ur(C);m(null,ie,h,z,C,N,_),P.el=ie.el}if(_t&&we(_t,N),!Yt&&(it=rt&&rt.onVnodeMounted)){const ie=P;we(()=>Ne(it,wt,ie),N)}(P.shapeFlag&256||wt&&Gi(wt.vnode)&&wt.vnode.shapeFlag&256)&&C.a&&we(C.a,N),C.isMounted=!0,P=h=z=null}};C.scope.on();const Z=C.effect=new rl(R);C.scope.off();const G=C.update=Z.run.bind(Z),K=C.job=Z.runIfDirty.bind(Z);K.i=C,K.id=C.uid,Z.scheduler=()=>Es(K),xi(C,!0),G()},L=(C,P,h)=>{P.component=C;const z=C.vnode.props;C.vnode=P,C.next=null,Kd(C,P.props,z,h),Jd(C,P.children,h),ni(),nr(C),oi()},U=(C,P,h,z,N,_,$,R,Z=!1)=>{const G=C&&C.children,K=C?C.shapeFlag:0,it=P.children,{patchFlag:ct,shapeFlag:rt}=P;if(ct>0){if(ct&128){et(G,it,h,z,N,_,$,R,Z);return}else if(ct&256){V(G,it,h,z,N,_,$,R,Z);return}}rt&8?(K&16&&tt(G,N,_),it!==G&&u(h,it)):K&16?rt&16?et(G,it,h,z,N,_,$,R,Z):tt(G,N,_,!0):(K&8&&u(h,""),rt&16&&H(it,h,z,N,_,$,R,Z))},V=(C,P,h,z,N,_,$,R,Z)=>{C=C||Vi,P=P||Vi;const G=C.length,K=P.length,it=Math.min(G,K);let ct;for(ct=0;ct<it;ct++){const rt=P[ct]=Z?Je(P[ct]):je(P[ct]);m(C[ct],rt,h,null,N,_,$,R,Z)}G>K?tt(C,N,_,!0,!1,it):H(P,h,z,N,_,$,R,Z,it)},et=(C,P,h,z,N,_,$,R,Z)=>{let G=0;const K=P.length;let it=C.length-1,ct=K-1;for(;G<=it&&G<=ct;){const rt=C[G],mt=P[G]=Z?Je(P[G]):je(P[G]);if(ln(rt,mt))m(rt,mt,h,null,N,_,$,R,Z);else break;G++}for(;G<=it&&G<=ct;){const rt=C[it],mt=P[ct]=Z?Je(P[ct]):je(P[ct]);if(ln(rt,mt))m(rt,mt,h,null,N,_,$,R,Z);else break;it--,ct--}if(G>it){if(G<=ct){const rt=ct+1,mt=rt<K?P[rt].el:z;for(;G<=ct;)m(null,P[G]=Z?Je(P[G]):je(P[G]),h,mt,N,_,$,R,Z),G++}}else if(G>ct)for(;G<=it;)M(C[G],N,_,!0),G++;else{const rt=G,mt=G,_t=new Map;for(G=mt;G<=ct;G++){const se=P[G]=Z?Je(P[G]):je(P[G]);se.key!=null&&_t.set(se.key,G)}let wt,Lt=0;const Gt=ct-mt+1;let Yt=!1,ie=0;const Nt=new Array(Gt);for(G=0;G<Gt;G++)Nt[G]=0;for(G=rt;G<=it;G++){const se=C[G];if(Lt>=Gt){M(se,N,_,!0);continue}let Xt;if(se.key!=null)Xt=_t.get(se.key);else for(wt=mt;wt<=ct;wt++)if(Nt[wt-mt]===0&&ln(se,P[wt])){Xt=wt;break}Xt===void 0?M(se,N,_,!0):(Nt[Xt-mt]=G+1,Xt>=ie?ie=Xt:Yt=!0,m(se,P[Xt],h,null,N,_,$,R,Z),Lt++)}const Ge=Yt?eu(Nt):Vi;for(wt=Ge.length-1,G=Gt-1;G>=0;G--){const se=mt+G,Xt=P[se],yi=P[se+1],Oi=se+1<K?yi.el||Zl(yi):z;Nt[G]===0?m(null,Xt,h,Oi,N,_,$,R,Z):Yt&&(wt<0||G!==Ge[wt]?A(Xt,h,Oi,2):wt--)}}},A=(C,P,h,z,N=null)=>{const{el:_,type:$,transition:R,children:Z,shapeFlag:G}=C;if(G&6){A(C.component.subTree,P,h,z);return}if(G&128){C.suspense.move(P,h,z);return}if(G&64){$.move(C,P,h,at);return}if($===Kt){n(_,P,h);for(let it=0;it<Z.length;it++)A(Z[it],P,h,z);n(C.anchor,P,h);return}if($===Jn){I(C,P,h);return}if(z!==2&&G&1&&R)if(z===0)R.persisted&&!_[Uo]?n(_,P,h):(R.beforeEnter(_),n(_,P,h),we(()=>R.enter(_),N));else{const{leave:it,delayLeave:ct,afterLeave:rt}=R,mt=()=>{C.ctx.isUnmounted?o(_):n(_,P,h)},_t=()=>{const wt=_._isLeaving||!!_[Uo];_._isLeaving&&_[Uo](!0),R.persisted&&!wt?mt():it(_,()=>{mt(),rt&&rt()})};ct?ct(_,mt,_t):_t()}else n(_,P,h)},M=(C,P,h,z=!1,N=!1)=>{const{type:_,props:$,ref:R,children:Z,dynamicChildren:G,shapeFlag:K,patchFlag:it,dirs:ct,cacheIndex:rt,memo:mt}=C;if(it===-2&&(N=!1),R!=null&&(ni(),mn(R,null,h,C,!0),oi()),rt!=null&&(P.renderCache[rt]=void 0),K&256){P.ctx.deactivate(C);return}const _t=K&1&&ct,wt=!Gi(C);let Lt;if(wt&&(Lt=$&&$.onVnodeBeforeUnmount)&&Ne(Lt,P,C),K&6)Q(C.component,h,z);else{if(K&128){C.suspense.unmount(h,z);return}_t&&wi(C,null,P,"beforeUnmount"),K&64?C.type.remove(C,P,h,at,z):G&&!G.hasOnce&&(_!==Kt||it>0&&it&64)?tt(G,P,h,!1,!0):(_===Kt&&it&384||!N&&K&16)&&tt(Z,P,h),z&&X(C)}const Gt=mt!=null&&rt==null;(wt&&(Lt=$&&$.onVnodeUnmounted)||_t||Gt)&&we(()=>{Lt&&Ne(Lt,P,C),_t&&wi(C,null,P,"unmounted"),Gt&&(C.el=null)},h)},X=C=>{const{type:P,el:h,anchor:z,transition:N}=C;if(P===Kt){J(h,z);return}if(P===Jn){T(C);return}const _=()=>{o(h),N&&!N.persisted&&N.afterLeave&&N.afterLeave()};if(C.shapeFlag&1&&N&&!N.persisted){const{leave:$,delayLeave:R}=N,Z=()=>$(h,_);R?R(C.el,_,Z):Z()}else _()},J=(C,P)=>{let h;for(;C!==P;)h=v(C),o(C),C=h;o(P)},Q=(C,P,h)=>{const{bum:z,scope:N,job:_,subTree:$,um:R,m:Z,a:G}=C;hr(Z),hr(G),z&&Yn(z),N.stop(),_&&(_.flags|=8,M($,C,P,h)),R&&we(R,P),we(()=>{C.isUnmounted=!0},P)},tt=(C,P,h,z=!1,N=!1,_=0)=>{for(let $=_;$<C.length;$++)M(C[$],P,h,z,N)},pt=C=>{if(C.shapeFlag&6)return pt(C.component.subTree);if(C.shapeFlag&128)return C.suspense.next();const P=v(C.anchor||C.el),h=P&&P[md];return h?v(h):P};let lt=!1;const F=(C,P,h)=>{let z;C==null?P._vnode&&(M(P._vnode,null,null,!0),z=P._vnode.component):m(P._vnode||null,C,P,null,null,null,h),P._vnode=C,lt||(lt=!0,nr(z),Sl(),lt=!1)},at={p:m,um:M,m:A,r:X,mt:b,mc:H,pc:U,pbc:O,n:pt,o:t};return{render:F,hydrate:void 0,createApp:zd(F)}}function Vo({type:t,props:e},i){return i==="svg"&&t==="foreignObject"||i==="mathml"&&t==="annotation-xml"&&e&&e.encoding&&e.encoding.includes("html")?void 0:i}function xi({effect:t,job:e},i){i?(t.flags|=32,e.flags|=4):(t.flags&=-33,e.flags&=-5)}function tu(t,e){return(!t||t&&!t.pendingBranch)&&e&&!e.persisted}function Kl(t,e,i=!1){const n=t.children,o=e.children;if($t(n)&&$t(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Je(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&Kl(l,r)),r.type===Mo&&(r.patchFlag===-1&&(r=o[s]=Je(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function eu(t){const e=t.slice(),i=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=i[i.length-1],t[o]<c){e[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,t[i[r]]<c?s=r+1:l=r;c<t[i[s]]&&(s>0&&(e[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=e[l];return i}function Gl(t){const e=t.subTree.component;if(e)return e.asyncDep&&!e.asyncResolved?e:Gl(e)}function hr(t){if(t)for(let e=0;e<t.length;e++)t[e].flags|=8}function Zl(t){if(t.placeholder)return t.placeholder;const e=t.component;return e?Zl(e.subTree):null}const Yl=t=>t.__isSuspense;function iu(t,e){e&&e.pendingBranch?$t(t)?e.effects.push(...t):e.effects.push(t):dd(t)}const Kt=Symbol.for("v-fgt"),Mo=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),Jn=Symbol.for("v-stc"),ei=[];let Ie=null;function nt(t=!1){ei.push(Ie=t?null:[])}function Os(){ei.pop(),Ie=ei[ei.length-1]||null}let Tn=1;function mr(t,e=!1){Tn+=t,t<0&&Ie&&e&&(Ie.hasOnce=!0)}function Jl(t){return t.dynamicChildren=Tn>0?Ie||Vi:null,Os(),Tn>0&&Ie&&Ie.push(t),t}function st(t,e,i,n,o,s){return Jl(p(t,e,i,n,o,s,!0))}function De(t,e,i,n,o){return Jl(dt(t,e,i,n,o,!0))}function zs(t){return t?t.__v_isVNode===!0:!1}function ln(t,e){return t.type===e.type&&t.key===e.key}const Xl=({key:t})=>t??null,Xn=({ref:t,ref_key:e,ref_for:i})=>(typeof t=="number"&&(t=""+t),t!=null?ee(t)||Jt(t)||Bt(t)?{i:de,r:t,k:e,f:!!i}:t:null);function p(t,e=null,i=null,n=0,o=null,s=t===Kt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&Xl(e),ref:e&&Xn(e),scopeId:$l,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:de};return r?(go(a,i),s&128&&t.normalize(a)):i&&(a.shapeFlag|=ee(i)?8:16),Tn>0&&!l&&Ie&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Ie.push(a),a}const dt=nu;function nu(t,e=null,i=null,n=0,o=null,s=!1){if((!t||t===Bd)&&(t=ri),zs(t)){const r=Ji(t,e,!0);return i&&go(r,i),Tn>0&&!s&&Ie&&(r.shapeFlag&6?Ie[Ie.indexOf(t)]=r:Ie.push(r)),r.patchFlag=-2,r}if(mu(t)&&(t=t.__vccOpts),e){e=ou(e);let{class:r,style:a}=e;r&&!ee(r)&&(e.class=At(r)),Ht(a)&&(Ts(a)&&!$t(a)&&(a=ue({},a)),e.style=$n(a))}const l=ee(t)?1:Yl(t)?128:gd(t)?64:Ht(t)?4:Bt(t)?2:0;return p(t,e,i,n,o,l,s,!0)}function ou(t){return t?Ts(t)||Hl(t)?ue({},t):t:null}function Ji(t,e,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=e?su(o||{},e):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Xl(c),ref:e&&e.ref?i&&s?$t(s)?s.concat(Xn(e)):[s,Xn(e)]:Xn(e):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ji(t.ssContent),ssFallback:t.ssFallback&&Ji(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&Ms(u,a.clone(u)),u}function $e(t=" ",e=0){return dt(Mo,null,t,e)}function ge(t,e){const i=dt(Jn,null,t);return i.staticCount=e,i}function Pt(t="",e=!1){return e?(nt(),De(ri,null,t)):dt(ri,null,t)}function je(t){return t==null||typeof t=="boolean"?dt(ri):$t(t)?dt(Kt,null,t.slice()):zs(t)?Je(t):dt(Mo,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ji(t)}function go(t,e){let i=0;const{shapeFlag:n}=t;if(e==null)e=null;else if($t(e))i=16;else if(typeof e=="object")if(n&65){const o=e.default;o&&(o._c&&(o._d=!1),go(t,o()),o._c&&(o._d=!0));return}else{i=32;const o=e._;!o&&!Hl(e)?e._ctx=de:o===3&&de&&(de.slots._===1?e._=1:(e._=2,t.patchFlag|=1024))}else if(Bt(e)){if(n&65){go(t,{default:e});return}e={default:e,_ctx:de},i=32}else e=String(e),n&64?(i=16,e=[$e(e)]):i=8;t.children=e,t.shapeFlag|=i}function su(...t){const e={};for(let i=0;i<t.length;i++){const n=t[i];for(const o in n)if(o==="class")e.class!==n.class&&(e.class=At([e.class,n.class]));else if(o==="style")e.style=$n([e.style,n.style]);else if(wo(o)){const s=e[o],l=n[o];l&&s!==l&&!($t(s)&&s.includes(l))?e[o]=s?[].concat(s,l):l:l==null&&s==null&&!xo(o)&&(e[o]=l)}else o!==""&&(e[o]=n[o])}return e}function Ne(t,e,i,n=null){Oe(t,e,7,[i,n])}const ru=Pl();let lu=0;function au(t,e,i){const n=t.type,o=(e?e.appContext:t.appContext)||ru,s={uid:lu++,vnode:t,type:n,parent:e,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Lc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(o.provides),ids:e?e.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ul(n,o),emitsOptions:Ol(n,o),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=e?e.root:s,s.emit=Fd.bind(null,s),t.ce&&t.ce(s),s}let me=null;const cu=()=>me||de;let vo,ps;{const t=$o(),e=(i,n)=>{let o;return(o=t[i])||(o=t[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};vo=e("__VUE_INSTANCE_SETTERS__",i=>me=i),ps=e("__VUE_SSR_SETTERS__",i=>En=i)}const On=t=>{const e=me;return vo(t),t.scope.on(),()=>{t.scope.off(),vo(e)}},gr=()=>{me&&me.scope.off(),vo(null)};function Ql(t){return t.vnode.shapeFlag&4}let En=!1;function du(t,e=!1,i=!1){e&&ps(e);const{props:n,children:o}=t.vnode,s=Ql(t);qd(t,n,s,e),Yd(t,o,i||e);const l=s?uu(t,e):void 0;return e&&ps(!1),l}function uu(t,e){const i=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Ed);const{setup:n}=i;if(n){ni();const o=t.setupContext=n.length>1?pu(t):null,s=On(t),l=Rn(n,t,0,[t.props,o]),r=Qr(l);if(oi(),s(),(r||t.sp)&&!Gi(t)&&Tl(t),r){if(l.then(gr,gr),e)return l.then(a=>{vr(t,a)}).catch(a=>{Bo(a,t,0)});t.asyncDep=l}else vr(t,l)}else ta(t)}function vr(t,e,i){Bt(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:Ht(e)&&(t.setupState=kl(e)),ta(t)}function ta(t,e,i){const n=t.type;t.render||(t.render=n.render||qe);{const o=On(t);ni();try{Md(t)}finally{oi(),o()}}}const fu={get(t,e){return he(t,"get",""),t[e]}};function pu(t){const e=i=>{t.exposed=i||{}};return{attrs:new Proxy(t.attrs,fu),slots:t.slots,emit:t.emit,expose:e}}function Do(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(kl(td(t.exposed)),{get(e,i){if(i in e)return e[i];if(i in gn)return gn[i](t)},has(e,i){return i in e||i in gn}})):t.proxy}function hu(t,e=!0){return Bt(t)?t.displayName||t.name:t.name||e&&t.__name}function mu(t){return Bt(t)&&"__vccOpts"in t}const St=(t,e)=>sd(t,e,En),gu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let hs;const br=typeof window<"u"&&window.trustedTypes;if(br)try{hs=br.createPolicy("vue",{createHTML:t=>t})}catch{}const ea=hs?t=>hs.createHTML(t):t=>t,vu="http://www.w3.org/2000/svg",bu="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,yr=Ye&&Ye.createElement("template"),yu={insert:(t,e,i)=>{e.insertBefore(t,i||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,i,n)=>{const o=e==="svg"?Ye.createElementNS(vu,t):e==="mathml"?Ye.createElementNS(bu,t):i?Ye.createElement(t,{is:i}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},insertStaticContent(t,e,i,n,o,s){const l=i?i.previousSibling:e.lastChild;if(o&&(o===s||o.nextSibling))for(;e.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{yr.innerHTML=ea(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=yr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}e.insertBefore(r,i)}return[l?l.nextSibling:e.firstChild,i?i.previousSibling:e.lastChild]}},ku=Symbol("_vtc");function wu(t,e,i){const n=t[ku];n&&(e=(e?[e,...n]:[...n]).join(" ")),e==null?t.removeAttribute("class"):i?t.setAttribute("class",e):t.className=e}const bo=Symbol("_vod"),ia=Symbol("_vsh"),na={name:"show",beforeMount(t,{value:e},{transition:i}){t[bo]=t.style.display==="none"?"":t.style.display,i&&e?i.beforeEnter(t):an(t,e)},mounted(t,{value:e},{transition:i}){i&&e&&i.enter(t)},updated(t,{value:e,oldValue:i},{transition:n}){!e!=!i&&(n?e?(n.beforeEnter(t),an(t,!0),n.enter(t)):n.leave(t,()=>{an(t,!1)}):an(t,e))},beforeUnmount(t,{value:e}){an(t,e)}};function an(t,e){t.style.display=e?t[bo]:"none",t[ia]=!e}const xu=Symbol(""),_u=/(?:^|;)\s*display\s*:/;function Su(t,e,i){const n=t.style,o=ee(i);let s=!1;if(i&&!o){if(e)if(ee(e))for(const l of e.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&dn(n,r,"")}else for(const l in e)i[l]==null&&dn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?$u(t,l,!ee(e)&&e?e[l]:void 0,r)||dn(n,l,r):dn(n,l,"")}}else if(o){if(e!==i){const l=n[xu];l&&(i+=";"+l),n.cssText=i,s=_u.test(i)}}else e&&t.removeAttribute("style");bo in t&&(t[bo]=s?n.display:"",t[ia]&&(n.display="none"))}const kr=/\s*!important$/;function dn(t,e,i){if($t(i))i.forEach(n=>dn(t,e,n));else if(i==null&&(i=""),e.startsWith("--"))t.setProperty(e,i);else{const n=Cu(t,e);kr.test(i)?t.setProperty(bi(n),i.replace(kr,""),"important"):t[n]=i}}const wr=["Webkit","Moz","ms"],qo={};function Cu(t,e){const i=qo[e];if(i)return i;let n=ye(e);if(n!=="filter"&&n in t)return qo[e]=n;n=So(n);for(let o=0;o<wr.length;o++){const s=wr[o]+n;if(s in t)return qo[e]=s}return e}function $u(t,e,i,n){return t.tagName==="TEXTAREA"&&(e==="width"||e==="height")&&ee(n)&&i===n}const xr="http://www.w3.org/1999/xlink";function _r(t,e,i,n,o,s=Mc(e)){n&&e.startsWith("xlink:")?i==null?t.removeAttributeNS(xr,e.slice(6,e.length)):t.setAttributeNS(xr,e,i):i==null||s&&!nl(i)?t.removeAttribute(e):t.setAttribute(e,s?"":Re(i)?String(i):i)}function Sr(t,e,i,n,o){if(e==="innerHTML"||e==="textContent"){i!=null&&(t[e]=e==="innerHTML"?ea(i):i);return}const s=t.tagName;if(e==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=i==null?t.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in t))&&(t.value=a),i==null&&t.removeAttribute(e),t._value=i;return}let l=!1;if(i===""||i==null){const r=typeof t[e];r==="boolean"?i=nl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{t[e]=i}catch{}l&&t.removeAttribute(o||e)}function pi(t,e,i,n){t.addEventListener(e,i,n)}function Iu(t,e,i,n){t.removeEventListener(e,i,n)}const Cr=Symbol("_vei");function Au(t,e,i,n,o=null){const s=t[Cr]||(t[Cr]={}),l=s[e];if(n&&l)l.value=n;else{const[r,a]=Eu(e);if(n){const c=s[e]=Lu(n,o);pi(t,r,c,a)}else l&&(Iu(t,r,l,a),s[e]=void 0)}}const Bu=/(Once|Passive|Capture)$/,Tu=/^on:?(?:Once|Passive|Capture)$/;function Eu(t){let e,i;for(;(i=t.match(Bu))&&!Tu.test(t);)e||(e={}),t=t.slice(0,t.length-i[1].length),e[i[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):bi(t.slice(2)),e]}let Ko=0;const Mu=Promise.resolve(),Du=()=>Ko||(Mu.then(()=>Ko=0),Ko=Date.now());function Lu(t,e){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($t(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Oe(c,e,5,r)}}else Oe(o,e,5,[n])};return i.value=t,i.attached=Du(),i}const $r=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Ru=(t,e,i,n,o,s)=>{const l=o==="svg";e==="class"?wu(t,n,l):e==="style"?Su(t,i,n):wo(e)?xo(e)||Au(t,e,i,n,s):(e[0]==="."?(e=e.slice(1),!0):e[0]==="^"?(e=e.slice(1),!1):Pu(t,e,n,l))?(Sr(t,e,n),!t.tagName.includes("-")&&(e==="value"||e==="checked"||e==="selected")&&_r(t,e,n,l,s,e!=="value")):t._isVueCE&&(Ou(t,e)||t._def.__asyncLoader&&(/[A-Z]/.test(e)||!ee(n)))?Sr(t,ye(e),n,s,e):(e==="true-value"?t._trueValue=n:e==="false-value"&&(t._falseValue=n),_r(t,e,n,l))};function Pu(t,e,i,n){if(n)return!!(e==="innerHTML"||e==="textContent"||e in t&&$r(e)&&Bt(i));if(e==="spellcheck"||e==="draggable"||e==="translate"||e==="autocorrect"||e==="sandbox"&&t.tagName==="IFRAME"||e==="form"||e==="list"&&t.tagName==="INPUT"||e==="type"&&t.tagName==="TEXTAREA")return!1;if(e==="width"||e==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return $r(e)&&ee(i)?!1:e in t}function Ou(t,e){const i=t._def.props;if(!i)return!1;const n=ye(e);return Array.isArray(i)?i.some(o=>ye(o)===n):Object.keys(i).some(o=>ye(o)===n)}const Xi=t=>{const e=t.props["onUpdate:modelValue"]||!1;return $t(e)?i=>Yn(e,i):e};function zu(t){t.target.composing=!0}function Ir(t){const e=t.target;e.composing&&(e.composing=!1,e.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function Ar(t,e,i){return e&&(t=t.trim()),i&&(t=Co(t)),t}const yo={created(t,{modifiers:{lazy:e,trim:i,number:n}},o){t[ii]=Xi(o);const s=n||o.props&&o.props.type==="number";pi(t,e?"change":"input",l=>{l.target.composing||t[ii](Ar(t.value,i,s))}),(i||s)&&pi(t,"change",()=>{t.value=Ar(t.value,i,s)}),e||(pi(t,"compositionstart",zu),pi(t,"compositionend",Ir),pi(t,"change",Ir))},mounted(t,{value:e}){t.value=e??""},beforeUpdate(t,{value:e,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ii]=Xi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?Co(t.value):t.value,a=e??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&e===i||o&&t.value.trim()===a)||(t.value=a)}},qn={deep:!0,created(t,e,i){t[ii]=Xi(i),pi(t,"change",()=>{const n=t._modelValue,o=Mn(t),s=t.checked,l=t[ii];if($t(n)){const r=_s(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(tn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(oa(t,s))})},mounted:Br,beforeUpdate(t,e,i){t[ii]=Xi(i),Br(t,e,i)}};function Br(t,{value:e,oldValue:i},n){t._modelValue=e;let o;if($t(e))o=_s(e,n.props.value)>-1;else if(tn(e))o=e.has(n.props.value);else{if(e===i)return;o=en(e,oa(t,!0))}t.checked!==o&&(t.checked=o)}const Nu={deep:!0,created(t,{value:e,modifiers:{number:i}},n){t._modelValue=e,pi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>i?Co(Mn(s)):Mn(s));t[ii](t.multiple?tn(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,xl(()=>{t._assigning=!1})}),t[ii]=Xi(n)},mounted(t,{value:e}){Tr(t,e)},beforeUpdate(t,{value:e},i){t._modelValue=e,t[ii]=Xi(i)},updated(t,{value:e}){t._assigning||Tr(t,e)}};function Tr(t,e){const i=t.multiple,n=$t(e);if(!(i&&!n&&!tn(e))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Mn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=e.some(c=>String(c)===String(r)):l.selected=_s(e,r)>-1}else l.selected=e.has(r);else if(en(Mn(l),e)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!i&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Mn(t){return"_value"in t?t._value:t.value}function oa(t,e){const i=e?"_trueValue":"_falseValue";return i in t?t[i]:e}const Fu=["ctrl","shift","alt","meta"],Hu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,e)=>Fu.some(i=>t[`${i}Key`]&&!e.includes(i))},Me=(t,e)=>{if(!t)return t;const i=t._withMods||(t._withMods={}),n=e.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<e.length;l++){const r=Hu[e[l]];if(r&&r(o,e))return}return t(o,...s)}))},ju={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Uu=(t,e)=>{const i=t._withKeys||(t._withKeys={}),n=e.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=bi(o.key);if(e.some(l=>l===s||ju[l]===s))return t(o)}))},Wu=ue({patchProp:Ru},yu);let Er;function Vu(){return Er||(Er=Xd(Wu))}const sa=((...t)=>{const e=Vu().createApp(...t),{mount:i}=e;return e.mount=n=>{const o=Ku(n);if(!o)return;const s=e._component;!Bt(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,qu(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},e});function qu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Ku(t){return ee(t)?document.querySelector(t):t}const Gu="slidev-config.json",Qi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=Ao({...Qi});function Zu(t){if(!t||typeof t!="object")return{...Qi};const e=t;return{enableWebServeJump:!!e.enableWebServeJump,webServeUrl:typeof e.webServeUrl=="string"&&e.webServeUrl.trim()?e.webServeUrl.trim():Qi.webServeUrl,normalizeHeadingSizes:!!e.normalizeHeadingSizes}}function Ti(t){if(!t||typeof t!="object")return{...hi};const e=t;return e.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!e.enableWebServeJump),e.webServeUrl!==void 0&&(hi.webServeUrl=String(e.webServeUrl)),e.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!e.normalizeHeadingSizes),{...hi}}function Lo(){return{...hi}}function ra(t,e,i){const n=(t||Qi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",e),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${e}${l}&r=${s}`}}const _i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Yu(t){var i,n,o,s,l,r;const e=Lo();return t?{theme:((i=t[wn])==null?void 0:i.trim())||_i.theme,aspectRatio:((n=t[xn])==null?void 0:n.trim())||_i.aspectRatio,highlighter:((o=t[Kr])==null?void 0:o.trim())||_i.highlighter,defaultTransition:((s=t[_n])==null?void 0:s.trim())||_i.defaultTransition,colorSchema:((l=t[Gr])==null?void 0:l.trim())||_i.colorSchema,spacing:((r=t[ns])==null?void 0:r.trim())||_i.spacing,normalizeHeadingSizes:e.normalizeHeadingSizes}:{..._i,normalizeHeadingSizes:e.normalizeHeadingSizes}}function ko(t){var i,n,o,s,l;const e=(i=t.ial)==null?void 0:i[Ai];return!!(e&&(e==="true"||e==="page"||e==="cover"||e==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Mr(t){const e={};let i="";if(!t)return{frontmatter:e,notes:i};t[gt]&&(e.layout=t[gt].trim()),t[te]&&(e.transition=t[te].trim()),t[Ut]&&(e.background=t[Ut].trim()),t[Ee]&&(e.image=t[Ee].trim()),t[Wi]&&(e.class=t[Wi].trim()),t[un]&&(e.spacing=t[un].trim()),t[le]&&(e.layoutRatio=t[le].trim()),t[Ui]&&(i=t[Ui].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![gt,le,te,Ut,Ee,Wi,un,Ui,Ai].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{e[s]=JSON.parse(o)}catch{e[s]=o}}return{frontmatter:e,notes:i}}function Ju(t){const e={};if(!t)return e;const i=t[ne]??t["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(e.isNote=!0);const n=t[qt]??t["slidev-role"],o=t[Ut]??t["slidev-background"];(n===Zr||o==="true"||o==="1")&&(e.isBackground=!0);const s=t[gt]??t["slidev-layout"];s===ao||s===co?e.imageLayout=s:(n===ao||n===co)&&(e.imageLayout=n);const l=t[jt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(e.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?e.motion={preset:r.preset||r.type||"fade-in",...r}:e.motion={preset:String(r).trim()}}catch{e.motion={preset:t[Ve].trim()}}return t[Ri]&&(e.shikiLines=t[Ri].trim()),t[Sn]&&(e.maxHeight=t[Sn].trim()),t[Ct]&&(e.slot=t[Ct].trim()),t.style&&t.style.trim()&&(e.style=t.style.trim()),e}function vi(t,e){const i=(t||e||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function vn(t){if(!t)return"";const e=t.split(/\r?\n/);if(e.length===0)return"";const i=e[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(e.length===1)return s;const r=[s];for(let a=1;a<e.length;a++){const c=e[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=l?r.push(c.slice(l)):f>o?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function Pi(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="i"||e==="nodelistitem"||e==="l"||e==="nodelist")return!0;const i=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Go(t,e=2){if(!t||typeof t!="string")return`repeat(${e}, 1fr)`;const i=t.trim();if(!i)return`repeat(${e}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${e}, 1fr)`}function bn(t){if(!t)return[];if(oe(t)&&Ke(t)&&!ai(t)){const n=nn(t),o=[];for(const s of n)o.push(...bn(s));return o}const e=(t.type||"").toLowerCase();if(e==="l"||e==="nodelist"||e==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Pi);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return Pi(t)?[t]:[]}function Ns(t){var o;if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=nn(t);if(e.length===0)return null;if(e.length===1&&oe(e[0])&&Ke(e[0])){const s=Ns(e[0]);return s?{items:s.items,nestedSuperBlocks:[e[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of e)if(oe(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(oe))||[];i.push(...l)}const n=e.map(bn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(e.length===2){const s=bn(e[0]),l=bn(e[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function Xu(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=Ns(t);if(!e)return null;const{items:i,nestedSuperBlocks:n}=e;if(i.length<2||i.length>6)return null;const o=Fs(t)||void 0,s=i.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function la(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=nn(t);if(e.length===0)return null;const i=[];for(const n of e){const o=bn(n);if(o.length===0)return null;i.push(...o)}return i}function Qu(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=la(t);return!e||e.length===0||e.length>=2&&e.length<=6?null:{superBlockNode:t,items:e}}function tf(t){if(!t||!oe(t)||!Ke(t)||ai(t))return null;const e=Ns(t);if(e&&e.items.length===4)return e.items;const i=la(t);if(i&&i.length===4)return i;const n=nn(t);return n.length===4?n:null}function ef(t,e){if(!t||t.length===0)return null;const i=[];function n(r,a){if(oe(r)){const c=tf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<t.length;r++)n(t[r],r);if(i.length===0)return null;let o=null;e&&(o=i.find(r=>{if(r.sbNode.id===e||r.items.some(c=>c.id===e))return!0;const a=c=>c.id===e?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=t.slice(0,o.topLevelIndex).slice().reverse().find(r=>aa(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function nf(t,e,i){var u,f,v,d,y;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let m=0;m<e.length;m++){const g=e[m];if(ko(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(m){const g=[];for(const k of m)oe(k)&&g.push(k),k.children&&k.children.length>0&&g.push(...a(k.children));return g}function c(m,g,k){const x={blockId:m,attrs:g,previousAttrs:k};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const m of l){const g=m.pageTargetId,k=e.find(B=>B.id===g),x=s.find(B=>B.pageTargetId===g);if(m.blocks.some(B=>{var w,H;return!!(ai(B)||ms(B)&&(((w=B.ial)==null?void 0:w[gt])==="image-left"||((H=B.ial)==null?void 0:H[gt])==="image-right"))})){if(x){const B=x.headerId;if(B){c(B,{[Ct]:""});const w=e.find(H=>H.id===B);w!=null&&w.ial&&(w.ial[Ct]="")}for(const w of x.itemIds){c(w,{[Ct]:""});const H=e.find(j=>j.id===w);H!=null&&H.ial&&(H.ial[Ct]="")}}continue}let T=null,E=-1;for(let B=0;B<m.blocks.length;B++){const w=m.blocks[B],H=oe(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const j of H){const O=Xu(j);if(O){T=O,E=B;break}}if(T)break}if(T){const{superBlockNode:B,layout:w,items:H,slots:j}=T,q=m.blocks.slice(0,E).find(L=>aa(L)),S=q==null?void 0:q.id,D=((u=k==null?void 0:k.ial)==null?void 0:u[gt])||"",b=D==="clover",W=b?"clover":w;if(D!==W&&(c(g,{[gt]:W},{[gt]:D}),k&&(k.ial||(k.ial={}),k.ial[gt]=W)),q){const L=((f=q.ial)==null?void 0:f[Ct])||"";L!=="header"&&(c(q.id,{[Ct]:"header"},{[Ct]:L}),q.ial||(q.ial={}),q.ial[Ct]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[Ct]:""});const L=e.find(U=>U.id===x.headerId);L&&(L.ial||(L.ial={}),L.ial[Ct]="")}const Y=[];for(let L=0;L<H.length;L++){const U=H[L],V=j[L];Y.push(U.id);const et=((v=U.ial)==null?void 0:v[Ct])||"";if(et!==V&&(c(U.id,{[Ct]:V},{[Ct]:et}),U.ial||(U.ial={}),U.ial[Ct]=V),U.children&&U.children.length>0)for(const A of U.children)A.ial||(A.ial={}),A.ial[Ct]!==V&&(A.ial[Ct]=V)}if(x!=null&&x.itemIds){for(const L of x.itemIds)if(!Y.includes(L)){c(L,{[Ct]:""});const U=e.find(V=>V.id===L);U&&(U.ial||(U.ial={}),U.ial[Ct]="")}}o.push({superBlockId:B.id,nestedSuperBlockIds:(d=T.nestedSuperBlocks)==null?void 0:d.map(L=>L.id),pageTargetId:g,headerId:S,itemIds:Y,layout:b?"clover":w})}else{let B=!1;const w=[];for(const O of m.blocks){const q=oe(O)?[O,...a(O.children||[])]:O.children?a(O.children):[];for(const S of q){const D=Qu(S);if(D){B=!0;for(const b of D.items)w.push(b.id)}}}const H=((y=k==null?void 0:k.ial)==null?void 0:y[gt])||"",j=Cn(H);if(x||B&&j){c(g,{[gt]:""},{[gt]:H}),k&&(k.ial||(k.ial={}),k.ial[gt]="");const O=x==null?void 0:x.headerId;if(O){c(O,{[Ct]:""});const S=e.find(D=>D.id===O);S&&(S.ial||(S.ial={}),S.ial[Ct]="")}const q=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of q){c(S,{[Ct]:""});const D=e.find(b=>b.id===S);D&&(D.ial||(D.ial={}),D.ial[Ct]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const e=(t.type||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"}function Ke(t){if(!oe(t))return!1;const e=(t.subType||"").toLowerCase();if(e==="col"||e==="h"||e==="horizontal")return!0;if(e==="row"||e==="v"||e==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function ms(t){return!t||Pi(t)||oe(t)||!vi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Fs(t){var v;if(!t||!oe(t)||!Ke(t))return null;const e=nn(t);if(!e||e.length<2)return null;const i=[];let n=!1;for(const d of e){const y=(((v=d.ial)==null?void 0:v.style)||d.style||"").trim();let m=null;if(y){const g=y.match(/calc\(\s*([\d.]+)%/i);if(g)m=parseFloat(g[1]);else{const k=y.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(m=parseFloat(k[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const o=e.length,s=i.reduce((d,y)=>d+(y||0),0),l=i.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(d=>d!==null?d:a),u=c.reduce((d,y)=>d+y,0);if(u<=0)return null;const f=c.map(d=>d/u*100);if(f.length===2){const[d]=f;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const y=Math.round(d),m=100-y;return`${y}:${m}`}if(f.length===3){const[d,y,m]=f;if(d>=31&&d<=35&&y>=31&&y<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&y>=48&&y<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&y>=23&&y<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&y>=23&&y<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&y>=58&&y<=62&&m>=18&&m<=22)return"1:3:1";const g=Math.round(d),k=Math.round(y),x=100-g-k;return`${g}:${k}:${x}`}return f.map(d=>Math.round(d)).join(":")}function ai(t){if(!t||!oe(t)||!Ke(t))return null;const e=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(e.length<2)return null;const i=ms(e[0]),n=ms(e[e.length-1]),o=Fs(t)||void 0;if(i&&!n){const s=vi(e[0].markdown,e[0].content);if(s)return{imageNode:e[0],imageUrl:s,layout:ao,contentNodes:e.slice(1),ratio:o}}if(!i&&n){const s=vi(e[e.length-1].markdown,e[e.length-1].content);if(s)return{imageNode:e[e.length-1],imageUrl:s,layout:co,contentNodes:e.slice(0,e.length-1),ratio:o}}return null}function of(t,e){const i=[];function n(o){for(const s of o){const l=ai(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[gt];if(u!==a){const v={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[gt]=a,i.push(v),e&&e(v)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),i}function nn(t){return(t.children||[]).filter(e=>{const i=e.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(e.markdown||e.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function aa(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="h"||e==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const i=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Si(t,e,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof e=="string"?x.split(/\s+/).includes(e):e.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let f=1,v=-1,d=-1;const y=/<\/?div\b[^>]*>/gi;y.lastIndex=u;let m;for(;(m=y.exec(t))!==null;)if(m[0].startsWith("</")){if(f--,f===0){v=m.index,d=m.index+m[0].length;break}}else f++;if(v!==-1&&d!==-1){const g=t.slice(u,v);n+=i(g),o=d}else n+=t.slice(a,u),o=u}return n}function sf(t){const e=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=t.slice(n);break}i+=t.slice(n,r);const c=r+a;let u=1,f=-1,v=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let y;for(;(y=d.exec(t))!==null;)if(y[0].startsWith("</")){if(u--,u===0){f=y.index,v=y.index+y[0].length;break}}else u++;if(f!==-1&&v!==-1){const m=t.slice(r,v),g=`__VUE_DIV_TOKEN_${e.length}__`;e.push(m),i+=g,n=v}else i+=t.slice(r,c),n=c}return{text:i,tokens:e}}function rf(t){const e=[];let i=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=sf(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Si(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=Si(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),i=Si(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Si(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Si(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Si(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Si(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,v)=>Math.max(f,v.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,f)=>{const v=f.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<e.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,e[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ca(t){if(!t||typeof t!="string")return"";const e=[];let i=t.replace(/`([^`]+)`/g,n=>(e.push(n),`%%INLINE_CODE_${e.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>e[parseInt(o,10)]||""),i}function lf(t){const e=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return e.length===0?"":`---
${e.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function af(t,e){if(!e||!t.startsWith("```"))return t;const i=t.indexOf(`
`);if(i===-1)return t;const n=t.slice(0,i).trim(),o=t.slice(i);return n.includes("{")?t:`${n} {${e}}${o}`}function da(t,e){if(e==null)return t;const i=e.trim();return i===""||i==="+1"?`<v-click>

${t}

</v-click>`:i==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${i}">

${t}

</v-click>`}function cf(t){if(!t||!t.preset)return null;const e=t.preset.toLowerCase().trim();if(!e||e==="none")return null;let i={opacity:0},n={opacity:1};switch(e){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(i={...i,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Kn(t,e,i,n){const o=e!=null&&e.trim()!=="",s=cf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const y=e.trim();let m="v-click";return y==="hide"?m="v-click.hide":y!==""&&y!=="+1"&&(m=`v-click="${y}"`),`<div ${m}${a}>

${t}

</div>`}return da(t,e)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),f=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${f}${a}>

${t}

</div>`;const v=e.trim();let d="v-click";return v==="hide"?d="v-click.hide":v!==""&&v!=="+1"&&(d=`v-click="${v}"`),`<div ${d} ${f}${a}>

${t}

</div>`}function ua(t){if(!t)return"";let e=t.trim();e=e.replace(/\{:[^}]*\}/g,"").trim(),e=e.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),e=e.replace(/\r?\n?:::\s*$/g,"");let o=e.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function df(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const i=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function fa(t,e=2){const i=Math.max(2,e);if(!t||t.length===0)return Array.from({length:i},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:i},()=>[]),f=Math.min(i,c.length),v=Math.floor(c.length/f),d=c.length%f;let y=0;for(let m=0;m<f;m++){const g=v+(m<d?1:0);u[m]=c.slice(y,y+g),y+=g}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const f=u.match(/^col-(\d+)$/i);if(f){const v=parseInt(f[1],10);if(v>=1&&v<=i)return v}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:i},()=>[]);let y=1;for(const m of t){const g=n(m);g!==null&&(y=g),d[y-1].push(m)}return d}const u=t.filter(d=>n(d)===1),f=t.filter(d=>n(d)===null),v=i-1;if(f.length>=v){const d=Math.floor(f.length/v),y=f.length%v,m=[u];let g=0;for(let k=0;k<v;k++){const x=d+(k<y?1:0);m.push(f.slice(g,g+x)),g+=x}return m}else if(f.length>0){const d=[u];for(let y=0;y<v;y++)d.push(y<f.length?[f[y]]:[]);return d}else return[u,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const f=r[u],v=u+1<i?r[u+1]:t.length;c[u]=t.slice(f,v)}return c}if(t.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let f=0;f<i;f++){const v=i-f,d=t.length-u,y=Math.ceil(d/v);c[f]=t.slice(u,u+y),u+=y}return c}if(t.length>1&&t.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),f=u.split(/\r?\n/),v=[];for(let m=0;m<f.length;m++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(f[m])&&v.push(m);if(v.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,I=v.length-g,T=Math.ceil(I/x),E=v[g],B=g+T<v.length?v[g+T]:f.length,w=f.slice(E,B).join(`
`);m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],g+=T}return m}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,I=d.length-g,T=Math.ceil(I/x),E=`<ul>
${d.slice(g,g+T).join(`
`)}
</ul>`;m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:E,content:E}],g+=T}return m}const y=u.split(/\r?\n\s*\r?\n/).filter(m=>m.trim()!=="");if(y.length>=i){const m=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const x=i-k,I=y.length-g,T=Math.ceil(I/x),E=y.slice(g,g+T).join(`

`);m[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:E,content:E}],g+=T}return m}}const a=Array.from({length:i},()=>[]);return a[0]=t,a}function Dr(t,e,i,n){var u;const o=Yu(e),s=[],l=Mr(e);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),s.push(r);let a=[];for(const f of i){if(ko(f)){a=[];const d=Mr(f.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=f.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(f.id)||r.allBlockIds.push(f.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:f.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[f.id]},r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),s.push(r);continue}const v=(d,y)=>{var Y,L,U,V;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const et=A=>{for(const M of A)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&et(M.children)};et(d.children)}let m=kc(d),g=d.ial?{...d.ial}:{};const k=m.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(g={...wc(k[0]),...g},m=m.slice(0,k.index).trim()),d.type!=="c"&&!m.startsWith("```")&&(m=ca(m));let x=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(m=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=m.trim());const I=Ju(g);if(m=xc(m,n),m=yc(m,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const et=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],A=M=>{for(const X of M){if(X.ial)for(const[J,Q]of Object.entries(X.ial))et.includes(J)&&!g[J]&&(g[J]=Q);X.children&&X.children.length>0&&A(X.children)}};A(d.children)}const T=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(m);if(T){const et=g["custom-slidev-autoplay"]==="true",A=g["custom-slidev-loop"]==="true",M=g["custom-slidev-muted"]==="true"||et,X=g["custom-slidev-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(J,Q)=>{let tt=Q;return X?tt=tt.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(tt)||(tt+=" controls"),et&&!/autoplay/i.test(tt)?tt+=" autoplay playsinline":!et&&g["custom-slidev-autoplay"]==="false"&&(tt=tt.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),A&&!/loop/i.test(tt)?tt+=" loop":!A&&g["custom-slidev-loop"]==="false"&&(tt=tt.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(tt)?tt+=" muted":!M&&g["custom-slidev-muted"]==="false"&&(tt=tt.replace(/\bmuted\b/gi,"").trim()),`<video ${tt.trim()}>`})}if(I.isBackground){const et=vi(m,d.content);if(et){r.frontmatter.background=Ae(et,n);return}}const E=ai(d);if(E){r.frontmatter.layout=E.layout,r.frontmatter.image=Ae(E.imageUrl,n),!r.frontmatter.layoutRatio&&E.ratio&&(r.frontmatter.layoutRatio=E.ratio);for(const et of E.contentNodes)v(et);return}if(I.imageLayout==="image-left"||I.imageLayout==="image-right"){const et=vi(m,d.content);if(et){r.frontmatter.layout=I.imageLayout,r.frontmatter.image=Ae(et,n),!r.frontmatter.layoutRatio&&((Y=d.ial)!=null&&Y[le])&&(r.frontmatter.layoutRatio=d.ial[le]);return}}if(oe(d)&&d.children&&d.children.length>0){for(const et of d.children)v(et);return}const B=!!(I.slot||y!=null&&y.defaultSlot||r.frontmatter.layout==="clover"||Cn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(et=>{var A,M;return((A=et.ial)==null?void 0:A[Ct])||((M=et.ial)==null?void 0:M[jt])})||I.slot||I.clicks||B)){for(const et of d.children)I.slot&&(!et.ial||!et.ial[Ct])&&(et.ial||(et.ial={}),et.ial[Ct]=I.slot),v(et,{...y,parentClicks:I.clicks||(y==null?void 0:y.parentClicks),defaultSlot:I.slot||(y==null?void 0:y.defaultSlot)});return}const w=!!(d.children&&d.children.length>=2)||!!I.clicks||!!((L=d.children)!=null&&L.some(et=>{var A;return(A=et.ial)==null?void 0:A[jt]}))||!d.markdown&&!!(d.children&&d.children.length>0);if(Pi(d)&&d.children&&d.children.length>0&&(B||I.clicks||d.children.some(et=>{var A;return(A=et.ial)==null?void 0:A[jt]}))&&w){const et=!!(d.children&&d.children.length>=2),A=d.children.find(lt=>!!(lt.markdown||lt.content||"").trim())||d.children[0],M=((U=A==null?void 0:A.ial)==null?void 0:U[jt])||((V=A==null?void 0:A.ial)==null?void 0:V["custom-slidev-click"]),X=!!(!I.clicks&&et&&M),J=I.clicks||(X?M:void 0)||(y==null?void 0:y.parentClicks),Q=d.id||(y==null?void 0:y.parentContainerId),tt=I.slot||(y==null?void 0:y.defaultSlot);let pt=!0;for(const lt of d.children){tt&&(!lt.ial||!lt.ial[Ct])&&(lt.ial||(lt.ial={}),lt.ial[Ct]=tt);const F=!!(lt.markdown||lt.content||"").trim(),at=pt&&F;at&&(lt.markdown&&(lt.markdown=vn(lt.markdown)),lt.content&&(lt.content=vn(lt.content)),pt=!1);let ut=lt;at&&J&&et&&(ut={...lt,ial:{...lt.ial||{}}},delete ut.ial[jt],delete ut.ial["custom-slidev-click"]),v(ut,{parentClicks:J,parentContainerId:Q,defaultSlot:tt})}return}if(I.isNote){const et=ua(m);et&&(r.notes?r.notes+=`

`+et:r.notes=et),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:et||d.content||"",rawMarkdown:m,isNote:!0,attributes:d.ial});return}I.shikiLines&&(m=af(m,I.shikiLines)),x=m.trim();const H=(d.content||"").trim();if(x==="::right::"||H==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const O=df(d);let q=I.slot,S=I.clicks,D=I.motion,b={...d.ial||{}};if(O!==null){for(;a.length>0&&a[a.length-1].level>=O;)a.pop();const et=a.length>0?a[a.length-1]:void 0;!q&&(et!=null&&et.slot)&&(q=et.slot),!S&&(et!=null&&et.clicks)&&!(y!=null&&y.parentContainerId)&&(S=et.clicks),!D&&(et!=null&&et.motion)&&(D=et.motion);const A={...(et==null?void 0:et.customAttrs)||{}};if(d.ial)for(const[M,X]of Object.entries(d.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(A[M]=X);y!=null&&y.parentContainerId||a.push({level:O,slot:q,clicks:S,motion:D,customAttrs:A})}else{const et=a.length>0?a[a.length-1]:void 0;et&&(!q&&et.slot&&et.slot!=="header"&&(q=et.slot),!S&&et.clicks&&!(y!=null&&y.parentContainerId)&&(S=et.clicks),!D&&et.motion&&(D=et.motion),et.customAttrs&&(b={...et.customAttrs,...b}))}!q&&r.blocks.some(et=>et.slot==="slot-divider-right")&&(q="right"),!q&&(y!=null&&y.defaultSlot)&&(q=y.defaultSlot),q&&(b[Ct]=q),S&&!b[jt]&&(b[jt]=S),D&&!b[Ve]&&(b[Ve]=JSON.stringify(D)),(T||g["custom-slidev-autoplay"]||g["custom-slidev-muted"])&&(g["custom-slidev-autoplay"]&&(b["custom-slidev-autoplay"]=g["custom-slidev-autoplay"],g["custom-slidev-autoplay"]==="true"&&!g["custom-slidev-muted"]&&(b["custom-slidev-muted"]="true")),g["custom-slidev-loop"]&&(b["custom-slidev-loop"]=g["custom-slidev-loop"]),g["custom-slidev-muted"]&&(b["custom-slidev-muted"]=g["custom-slidev-muted"]),g["custom-slidev-controls"]&&(b["custom-slidev-controls"]=g["custom-slidev-controls"]));const W={id:d.id,type:d.type,content:d.content||"",rawMarkdown:m,clicks:S,parentClicks:y==null?void 0:y.parentClicks,parentContainerId:y==null?void 0:y.parentContainerId,motion:D,shikiLines:I.shikiLines,slot:q,attributes:b,rawNode:d};r.blocks.push(W)};v(f)}for(let f=0;f<s.length;f++){const v=s[f],d=[],y={...v.frontmatter};f===0&&(y.theme=o.theme,y.aspectRatio=o.aspectRatio,y.highlighter=o.highlighter,y.transition=v.frontmatter.transition||o.defaultTransition);const m=lf(y);m&&d.push(m);const g=v.blocks.filter(E=>E.slot!=="slot-divider-right"),k=E=>E.filter(B=>!!(B.rawMarkdown||B.content||"").trim()).map(B=>{var w;return Kn(B.rawMarkdown,B.clicks,B.motion,(w=B.attributes)==null?void 0:w.style)}).join(`

`),x=E=>{const B=E.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if(B.length===0)return;const w=B[0],H=(w.rawMarkdown||w.content||"").trim();(Pi(w)||/^(?:[-*+]|\d+\.)\s+/.test(H))&&(w.rawMarkdown=vn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},I=E=>{var O,q;if(E.length===0)return"";x(E);const B=(O=E.find(S=>S.parentClicks))==null?void 0:O.parentClicks;if(!B)return E.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var D;return Kn(S.rawMarkdown,S.clicks,S.motion,(D=S.attributes)==null?void 0:D.style)}).join(`

`);const w=[];let H=[];const j=()=>{if(H.length===0)return;const S=H.map(D=>(D.rawMarkdown||D.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(da(S,B)),H=[]};for(const S of E){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(j(),w.push(Kn(S.rawMarkdown,S.clicks,S.motion,(q=S.attributes)==null?void 0:q.style))):H.push(S)}return j(),w.join(`

`)},T=v.frontmatter.layout||"default";if(T==="clover"||Cn(T)){let E=[];const B=g.filter(S=>S.slot==="header");if(B.length>0)E=B;else if(g.length>0){const S=g.find(D=>D.type==="h"&&(!D.slot||D.slot==="default"));S&&(E=[S])}const w=g.filter(S=>!E.includes(S));let H=2;if(T==="clover")H=4;else if(T==="three-cols-header")H=3;else if(T==="two-cols-header")H=2;else{let S=0;for(const D of w){const b=(D.slot||"").match(/^col-(\d+)$/i);b&&(S=Math.max(S,parseInt(b[1],10)))}if(S>=2)H=S;else if(v.frontmatter.layoutRatio){const D=v.frontmatter.layoutRatio.trim();if(D.includes(":")){const b=D.split(":").map(W=>parseFloat(W.trim())).filter(W=>!isNaN(W)&&W>0);b.length>=2&&(H=b.length)}else{const b=D.split(/\s+/).filter(Boolean);b.length>=2&&(H=b.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(H=Math.min(6,w[0].children.length))}const j=fa(w,H);j.forEach((S,D)=>{const b=`col-${D+1}`;for(const W of S)(!W.slot||W.slot==="default")&&(W.slot=b);x(S)});const O=j.flat();if(w.length===1&&O.length>1){const S=v.blocks.findIndex(D=>D.id===w[0].id);S!==-1&&v.blocks.splice(S,1,...O)}const q=k(E);if(q&&d.push(q),T==="two-cols-header"&&H===2){const S=I(j[0]||[]),D=I(j[1]||[]);S&&d.push(`::left::

${S}`),D&&d.push(`::right::

${D}`)}else j.forEach((S,D)=>{const b=I(S);b&&d.push(`::col-${D+1}::

${b}`)})}else if(T==="two-cols"){const E=g.filter(j=>j.slot==="left"),B=g.filter(j=>j.slot==="right");x(E),x(B);const w=k(E.length>0?E:g.filter(j=>j.slot!=="right")),H=k(B);d.push(w),H&&d.push(`::right::

${H}`)}else for(const E of g)d.push(Kn(E.rawMarkdown,E.clicks,E.motion,(u=E.attributes)==null?void 0:u.style));v.notes&&d.push(`<!--
${v.notes}
-->`),v.rawMarkdown=d.join(`

`).trim()}const c=s.map(f=>f.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const gs=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function uf(t){var o,s,l,r,a,c,u,f,v,d,y,m;if(!t||typeof t!="object")return"";const e=[],i=[];if(Array.isArray(t.styles))for(const g of t.styles){if(!g||!g.id)continue;const k=`--b3-inline-style-${g.id}`;(o=g.light)!=null&&o.color&&e.push(`  ${k}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&e.push(`  ${k}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&i.push(`  ${k}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${g.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const g of t.builtin.colors){if(!g||typeof g.index!="number")continue;const k=g.index;(a=g.light)!=null&&a.color&&e.push(`  --b3-font-color${k}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&e.push(`  --b3-font-background${k}: ${g.light.backgroundColor};`),(u=g.dark)!=null&&u.color&&i.push(`  --b3-font-color${k}: ${g.dark.color};`),(f=g.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${k}: ${g.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const g of t.builtin.styles){if(!g||!g.id)continue;const k=g.id;(v=g.light)!=null&&v.color&&e.push(`  --b3-card-${k}-color: ${g.light.color};`),(d=g.light)!=null&&d.backgroundColor&&e.push(`  --b3-card-${k}-background: ${g.light.backgroundColor};`),(y=g.dark)!=null&&y.color&&i.push(`  --b3-card-${k}-color: ${g.dark.color};`),(m=g.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${k}-background: ${g.dark.backgroundColor};`)}if(e.length===0&&i.length===0)return"";const n=[];return e.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${e.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function yn(t){const e=uf(t);return e?`${gs}

/* Custom Workspace Inline Styles */
${e}`:gs}function Zo(t){const e={};if(!t||typeof t!="string")return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}function ff(t){const e=String((t==null?void 0:t.type)||"").toLowerCase();return e==="h"||e==="nodeheading"}function pa(t){return oe(t)||t.type==="l"||t.type==="NodeList"||t.type==="i"||t.type==="NodeListItem"||t.type==="b"||t.type==="NodeBlockquote"}function pf(t,e,i,n=8){const o=new Map;for(const f of e)f!=null&&f.id&&o.set(f.id,f);const s=f=>({id:f.id,parent_id:f.parent_id,root_id:f.root_id||t,type:f.type,subType:f.subtype??f.subType??"",content:f.content||"",markdown:f.markdown||"",ial:i(f.id,f.ial),children:[]}),l=f=>{let v=f.parent_id,d=0;for(;v&&v!==t&&d++<16;){const y=o.get(v);if(!y||!ff(y))return v;v=y.parent_id}return v||t},r=new Map;for(const f of e){if(!(f!=null&&f.id)||f.id===t)continue;const v=l(f),d=r.get(v);d?d.push(f):r.set(v,[f])}const a=new Map,c=(f,v)=>{const d=s(f);if(a.set(d.id,d),v>=n||!pa(d))return d;const y=r.get(d.id);return y&&y.length>0&&(d.children=y.map(m=>c(m,v+1))),d};return{topLevel:(r.get(t)||[]).map(f=>c(f,0)),byId:a}}const hf={getBlockAttrs:ys,getChildBlocks:so,setBlockAttrs:Et,sql:kn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:vc};class mf{constructor(e){yt(this,"deps");yt(this,"attrOverrides",new Map);yt(this,"trackedListSuperBlocks",new Map);this.deps={...hf,...e||{}}}setBlockAttrOverride(e,i){if(!e||!i)return;const o={...this.attrOverrides.get(e)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(e):this.attrOverrides.set(e,o)}getBlockAttrOverride(e){return this.attrOverrides.get(e)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(e){return this.trackedListSuperBlocks.get(e)||[]}clearBlockAttrOverride(e,i){if(!e)return;if(!i){this.attrOverrides.delete(e);return}const n=this.attrOverrides.get(e);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(e))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(e){try{const i=await this.deps.getBlockAttrs(e).catch(()=>({}))||{},n=this.attrOverrides.get(e);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(e).catch(()=>[])||[],s=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${e}' AND id != '${e}' ORDER BY sort ASC, created ASC LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const O of l)O.id&&O.ial&&r.set(O.id,Zo(O.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${e}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const O of c)if(O.block_id&&O.name){let q=r.get(O.block_id);q||(q={},r.set(O.block_id,q)),q[O.name]=O.value||""}}const u=(O,q)=>{const S={...r.get(O)||(q?Zo(q):{})},D=this.attrOverrides.get(O);return D&&Object.assign(S,D),S},f=Array.isArray(l)&&l.length>0?pf(e,l,u):null,v=o.map(O=>O.id).filter(Boolean),d=new Set(((f==null?void 0:f.topLevel)||[]).map(O=>O.id)),y=new Map;for(const O of l)O!=null&&O.id&&y.set(O.id,O);const m=!!(f&&v.length>0&&v.length===d.size&&v.every(O=>{const q=y.get(O);return d.has(O)&&!!(q&&q.type)}));let g=[],k=!1;f&&m?g=v.map(O=>f.byId.get(O)).filter(O=>!!O):v.length>0?(k=!0,g=o.map(q=>({id:q.id,parent_id:q.parent_id,root_id:q.root_id||e,type:q.type,subType:q.subType,content:q.content||"",markdown:q.markdown||"",ial:u(q.id,q.ial),children:q.children}))):f&&(g=f.topLevel);const x=async(O,q=0)=>{if(!(!O||O.length===0||q>8))for(const S of O){if(pa(S)&&(!S.children||S.children.length===0)){let b=await this.deps.getChildBlocks(S.id).catch(()=>[]);if(!b||b.length===0){const W=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${S.id}' ORDER BY sort ASC, created ASC`;b=await this.deps.sql(W).catch(()=>[])||[]}if(Array.isArray(b)&&b.length>0){const W=new Set(g.map(L=>L.id)),Y=b.filter(L=>L.id!==S.id&&!W.has(L.id));Y.length>0&&(S.children=Y.map(L=>{const U=r.get(L.id)||(L.ial?Zo(L.ial):{}),V=this.attrOverrides.get(L.id);return V&&Object.assign(U,V),{id:L.id,parent_id:L.parent_id||S.id,root_id:L.root_id||e,type:L.type,subType:L.subType,content:L.content||"",markdown:L.markdown||"",ial:U}}))}}S.children&&S.children.length>0&&await x(S.children,q+1)}};k&&await x(g);const I=O=>{var q,S;for(const D of O)if(D.children&&D.children.length>0){I(D.children);for(const b of D.children)if(b.ial)for(const[W,Y]of Object.entries(b.ial))W.startsWith("custom-slidev-")&&!((q=D.ial)!=null&&q[W])&&(D.ial||(D.ial={}),D.ial[W]=Y);if(D.ial){for(const[b,W]of Object.entries(D.ial))if(b.startsWith("custom-slidev-"))for(const Y of D.children)(Y.type==="video"||Y.type==="NodeVideo"||/<video\b/i.test(Y.markdown||Y.content||""))&&!((S=Y.ial)!=null&&S[b])&&(Y.ial||(Y.ial={}),Y.ial[b]=W)}}};I(g),of(g,O=>{const q={[gt]:O.layout};this.setBlockAttrOverride(O.blockId,q),(this.deps.setBlockAttrs||Et)(O.blockId,q).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const T=this.trackedListSuperBlocks.get(e)||[],E=nf(e,g,{tracked:T,onTagChange:O=>{this.setBlockAttrOverride(O.blockId,O.attrs),O.blockId===e&&Object.assign(i,O.attrs);const q=D=>{for(const b of D)b.id===O.blockId&&(b.ial||(b.ial={}),Object.assign(b.ial,O.attrs)),b.children&&b.children.length>0&&q(b.children)};q(g),(this.deps.setBlockAttrs||Et)(O.blockId,O.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(e,E.newTracked);const B=new Set;for(const O of g){const q=O.markdown||O.content||"";if(q.includes("((")){const S=bc(q);for(const D of S)B.add(D.blockId)}}const w={};if(B.size>0){const O=Array.from(B).map(S=>`'${S}'`).join(","),q=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${O})`).catch(()=>[])||[];if(Array.isArray(q))for(const S of q)S.id&&(w[S.id]=S.markdown||S.content||"")}const H=this.deps.getBaseUrl?this.deps.getBaseUrl():"",j=Dr(e,i,g,{baseUrl:H,refContentMap:w});try{const O=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;j.customThemeCss=yn(O)}catch{j.customThemeCss=yn(null)}return j}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Dr(e,{},[],{});return n.customThemeCss=yn(null),n}}}const Mt=new mf;class Hs{constructor(e){yt(this,"devServerUrl","http://localhost:3030");yt(this,"isConnected",!1);yt(this,"lastSyncTime",null);e&&(this.devServerUrl=e)}getUrl(){return this.devServerUrl}setUrl(e){this.devServerUrl=e.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(e=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),e),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(e){const i=e.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=e.slides.map((r,a)=>{const c=r.frontmatter||{},u=[],f=a===0;c.layout&&c.layout!=="default"&&u.push(`layout: ${c.layout}`),c.transition&&u.push(`transition: ${c.transition}`),c.background&&u.push(`background: ${c.background}`),c.class&&u.push(`class: "${c.class}"`);let v="";u.length>0?v=f?"":`---
${u.join(`
`)}
---

`:f||(v=`---

`);let d="";if(c.layout==="two-cols"){const m=r.blocks.filter(I=>I.slot!=="right"),g=r.blocks.filter(I=>I.slot==="right"),k=m.map(I=>I.rawMarkdown||I.content||"").join(`

`),x=g.map(I=>I.rawMarkdown||I.content||"").join(`

`);d=`${k}

::right::

${x}`}else d=r.blocks.map(m=>m.rawMarkdown||m.content||"").join(`

`);let y="";return r.notes&&r.notes.trim()&&(y=`

<!--
${r.notes.trim()}
-->`),`${v}${d}${y}`}).join(`

`);let l="";return e.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(e,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(e);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(e,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(e),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function gf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Se(t){const e=gf();if(e)try{return e(t)}catch{try{const i=t.startsWith("node:")?t.slice(5):`node:${t}`;return e(i)}catch{}}}function js(){var e;if(typeof window<"u"&&window.process)return window.process;const t=Se("process");return t&&t.versions?t:typeof process<"u"&&((e=process.versions)!=null&&e.node)?process:globalThis.process}function ha(){var e,i;const t=js();if(t&&((e=t.versions)!=null&&e.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Se("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function vf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Dn(){const t=js();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const e=Se("os");if(e&&typeof e.platform=="function")return e.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ma(){var n,o;const t=js(),e={...(t==null?void 0:t.env)||{}};if(Dn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(e).find(c=>c.toLowerCase()==="path")||"PATH",a=(e[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);e[l]=a.join(";")}return e}function vs(t){var i,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let e="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(e=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),e&&t.startsWith("/data/")){const s=t.slice(6);return`${e}/${s}`.replace(/\\/g,"/")}return t}function bf(){const t=Se("os"),e=Se("path");if(t&&typeof t.tmpdir=="function"){const i=t.tmpdir();return e&&typeof e.join=="function"?e.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Us{constructor(e){yt(this,"runner");this.runner=e||Us.defaultRunner}static async defaultRunner(e,i){var n;try{let o=(n=Se("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Dn()==="win32",r=ma();return await new Promise(a=>{o(e,i,{timeout:5e3,shell:l,env:r},(c,u,f)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:f?String(f).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const e=ha(),i=Dn();if(!e)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:e}}}class yf{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pageChangedHandlers",[]);yt(this,"readyHandlers",[]);yt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(e,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:e,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(e){this.postMessage("navigate",{no:e})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(e){return this.pageChangedHandlers.push(e),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==e)}}onReady(e){return this.readyHandlers.push(e),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){const i=e.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class kf{constructor(e){yt(this,"childProcess",null);yt(this,"activePort",null);yt(this,"isRunning",!1);yt(this,"defaultPort");yt(this,"maxPortRetries");yt(this,"probeTimeoutMs");yt(this,"customSpawner");yt(this,"customPortChecker");this.defaultPort=(e==null?void 0:e.defaultPort)||3030,this.maxPortRetries=(e==null?void 0:e.maxPortRetries)||20,this.probeTimeoutMs=(e==null?void 0:e.probeTimeoutMs)||1e4,this.customSpawner=e==null?void 0:e.customSpawner,this.customPortChecker=e==null?void 0:e.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(e){if(this.customPortChecker)return this.customPortChecker(e);try{let i=Se("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(e,"127.0.0.1")}):!0}catch{return!0}}async allocPort(e){const i=e||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(e,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(e,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(e,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Dn()==="win32"?"npx.cmd":"npx",l=vs(e),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let f=(a=Se("child_process"))==null?void 0:a.spawn;if(!f){const y=await import("node:child_process").catch(()=>({}));f=y==null?void 0:y.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=ma();this.childProcess=f(s,r,{cwd:v,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var e;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Dn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(e=Se("child_process"))==null?void 0:e.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ws{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pendingMessages",[]);yt(this,"slideChangedHandlers",[]);yt(this,"blockClickedHandlers",[]);yt(this,"openInEditorHandlers",[]);yt(this,"clientReadyHandlers",[]);yt(this,"openPeekDrawerHandlers",[]);yt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(e,i){var o;const n={source:"siyuan-slidev-host",action:e,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(e,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:e,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(e){this.postMessage("NAVIGATE_PAGE",{pageIndex:e})}highlightElement(e){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:e})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(e){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:e})}onSlideChanged(e){return this.slideChangedHandlers.push(e),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==e)}}onBlockClicked(e){return this.blockClickedHandlers.push(e),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==e)}}onOpenInEditor(e){return this.openInEditorHandlers.push(e),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==e)}}onOpenPeekDrawer(e){return this.openPeekDrawerHandlers.push(e),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==e)}}onRequestToggleFullscreen(e){return this.toggleFullscreenHandlers.push(e),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==e)}}onClientReady(e){return this.clientReadyHandlers.push(e),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){var n;const i=e.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const ga={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},wf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,xf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,_f=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Sf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Cf=`${gs}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function $f(t){var o;const e=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!e.includes(s)&&e.push(s)}return e}class If{constructor(e){yt(this,"workspacePath");yt(this,"slidesFileName");yt(this,"cliBridge",new Hs);const i=bf();!(e!=null&&e.workspacePath)||e.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=e.workspacePath,this.slidesFileName=(e==null?void 0:e.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(e="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return e&&e!=="default"&&(i.dependencies[`@slidev/theme-${e}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(e){return this.cliBridge.buildStandardSlidevMarkdown(e)}async scaffold(e,i){const n=this.buildSlidesMarkdown(e),o=this.generatePackageJson(e.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=vs(s),a=vs(l),c=$f(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const I of c){const T=ga[I]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${I}
// #endregion snippet
`;u.set(I,T)}e.slides.some(I=>{var T;return((T=I.frontmatter)==null?void 0:T.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",wf),e.slides.some(I=>{var T;return((T=I.frontmatter)==null?void 0:T.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",xf),e.slides.some(I=>{var T;return((T=I.frontmatter)==null?void 0:T.layout)==="clover"})&&u.set("layouts/clover.vue",_f),u.set("setup/root.ts",Sf),u.set("styles/index.css",Cf);const y=Se("fs"),m=Se("path");let g=!1;const k=m!=null&&m.dirname?m.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(y&&m&&x)try{y.existsSync(k)||y.mkdirSync(k,{recursive:!0}),y.writeFileSync(a,o,"utf-8"),y.writeFileSync(r,n,"utf-8");for(const[I,T]of u.entries()){const E=m.join(k,I),B=m.dirname(E);y.existsSync(B)||y.mkdirSync(B,{recursive:!0}),y.existsSync(E)||y.writeFileSync(E,T,"utf-8")}g=!0}catch{}if(!g&&i)try{const I=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),T=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,T),await i(s,!1,I);for(const[E,B]of u.entries()){const w=`${this.workspacePath}/${E}`,H=typeof Blob<"u"?new Blob([B],{type:"text/plain;charset=utf-8"}):Buffer.from(B,"utf-8");await i(w,!1,H).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(I){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(I)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Af{constructor(){yt(this,"mode","web-sandbox");yt(this,"webBridge");yt(this,"cliBridge");yt(this,"nativeBridge");yt(this,"processManager");yt(this,"scaffolder");yt(this,"envDetector");this.webBridge=new Ws,this.cliBridge=new Hs,this.nativeBridge=new yf,this.processManager=new kf,this.scaffolder=new If,this.envDetector=new Us}getMode(){return this.mode}setMode(e){this.mode=e}async startProMode(e,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(e,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Bf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Tf={key:0},Ef={key:1},Mf={key:2},Df={key:3},Lf={key:4},Rf={key:5},Pf={key:6},Of={key:7},zf={key:8},Nf={key:9},Ff={key:10},Hf={key:11},jf={key:12},Uf={key:13},Wf={key:14},Vf={key:15},qf={key:16},Kf={key:17},Gf={key:18},Zf={key:19},Yf={key:20},Jf={key:21},Xf={key:22},Qf={key:23},tp={key:24},ep={key:25},ip={key:26},np={key:27},op={key:28},sp={key:29},rp={key:30},lp={key:31},ap={key:32},cp={key:33},dp={key:34},up={key:35},fp={key:36},pp={key:37},hp={key:38},mp={key:39},gp={key:40},vp={key:41},bp={key:42},yp={key:43},kp={key:44},wp={key:45},xp={key:46},_p={key:47},Sp={key:48},Cp={key:49},$p={key:50},Ip={key:51},Ap={key:52},Bp={key:53},Tp={key:54},Ep={key:55},Mp={key:56},Dp={key:57},Lp={key:58},Rp={key:59},Pp={key:60},Op={key:61},zp={key:62},Np={key:63},Fp={key:64},Hp={key:65},jp=Ce({__name:"SlidevIcon",props:{name:{}},setup(t){return(e,i)=>(nt(),st("svg",Bf,[t.name==="fullscreen"||t.name==="maximize"?(nt(),st("g",Tf,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(nt(),st("g",Ef,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(nt(),st("g",Mf,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(nt(),st("g",Df,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(nt(),st("g",Lf,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(nt(),st("g",Rf,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(nt(),st("g",Pf,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(nt(),st("g",Of,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(nt(),st("g",zf,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(nt(),st("g",Nf,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(nt(),st("g",Ff,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(nt(),st("g",Hf,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(nt(),st("g",jf,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(nt(),st("g",Uf,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(nt(),st("g",Wf,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(nt(),st("g",Vf,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(nt(),st("g",qf,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(nt(),st("g",Kf,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(nt(),st("g",Gf,[...i[18]||(i[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(nt(),st("g",Zf,[...i[19]||(i[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(nt(),st("g",Yf,[...i[20]||(i[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(nt(),st("g",Jf,[...i[21]||(i[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(nt(),st("g",Xf,[...i[22]||(i[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(nt(),st("g",Qf,[...i[23]||(i[23]=[ge('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-240266bc></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-240266bc></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-240266bc></path>',5)])])):t.name==="ratio"?(nt(),st("g",tp,[...i[24]||(i[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(nt(),st("g",ep,[...i[25]||(i[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(nt(),st("g",ip,[...i[26]||(i[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(nt(),st("g",np,[...i[27]||(i[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(nt(),st("g",op,[...i[28]||(i[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(nt(),st("g",sp,[...i[29]||(i[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="alert"||t.name==="warning"?(nt(),st("g",rp,[...i[30]||(i[30]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):t.name==="outline"?(nt(),st("g",lp,[...i[31]||(i[31]=[p("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),p("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),p("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(nt(),st("g",ap,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(nt(),st("g",cp,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(nt(),st("g",dp,[...i[34]||(i[34]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(nt(),st("g",up,[...i[35]||(i[35]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(nt(),st("g",fp,[...i[36]||(i[36]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(nt(),st("g",pp,[...i[37]||(i[37]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(nt(),st("g",hp,[...i[38]||(i[38]=[ge('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-240266bc></path><polyline points="14 2 14 8 20 8" data-v-240266bc></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-240266bc></line><line x1="16" y1="17" x2="8" y2="17" data-v-240266bc></line><line x1="10" y1="9" x2="8" y2="9" data-v-240266bc></line>',5)])])):t.name==="focus"||t.name==="target"?(nt(),st("g",mp,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(nt(),st("g",gp,[...i[40]||(i[40]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(nt(),st("g",vp,[...i[41]||(i[41]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-240266bc></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-240266bc></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-240266bc></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-240266bc></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(nt(),st("g",bp,[...i[42]||(i[42]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-240266bc></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-240266bc></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-240266bc></line><line x1="5" y1="15" x2="8" y2="15" data-v-240266bc></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-240266bc></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-240266bc></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-240266bc></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(nt(),st("g",yp,[...i[43]||(i[43]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-240266bc></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-240266bc></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-240266bc></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-240266bc></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-240266bc></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(nt(),st("g",kp,[...i[44]||(i[44]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-240266bc></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-240266bc></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-240266bc></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-240266bc></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-240266bc></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-240266bc></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-240266bc></line>',10)])])):t.name==="layout-clover"||t.name==="clover"?(nt(),st("g",wp,[...i[45]||(i[45]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="5" y1="7" x2="13" y2="7" data-v-240266bc></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-240266bc></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-240266bc></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-240266bc></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-240266bc></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-240266bc></line>',8)])])):t.name==="layout-image-right"||t.name==="image-right"?(nt(),st("g",xp,[...i[46]||(i[46]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" data-v-240266bc></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-240266bc></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-240266bc></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-240266bc></line><circle cx="15.5" cy="8.5" r="1.2" data-v-240266bc></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-240266bc></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(nt(),st("g",_p,[...i[47]||(i[47]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><line x1="12" y1="4" x2="12" y2="20" data-v-240266bc></line><circle cx="6" cy="8.5" r="1.2" data-v-240266bc></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-240266bc></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-240266bc></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-240266bc></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-240266bc></line>',7)])])):t.name==="layout-center"||t.name==="center"?(nt(),st("g",Sp,[...i[48]||(i[48]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(nt(),st("g",Cp,[...i[49]||(i[49]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><circle cx="8" cy="9" r="1.5" data-v-240266bc></circle><line x1="14" y1="8" x2="9" y2="14" data-v-240266bc></line><circle cx="15" cy="13" r="1.5" data-v-240266bc></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-240266bc></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(nt(),st("g",$p,[...i[50]||(i[50]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><circle cx="7.5" cy="9.5" r="2" data-v-240266bc></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-240266bc></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-240266bc></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-240266bc></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-240266bc></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(nt(),st("g",Ip,[...i[51]||(i[51]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-240266bc></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-240266bc></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-240266bc></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-240266bc></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(nt(),st("g",Ap,[...i[52]||(i[52]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(nt(),st("g",Bp,[...i[53]||(i[53]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(nt(),st("g",Tp,[...i[54]||(i[54]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(nt(),st("g",Ep,[...i[55]||(i[55]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(nt(),st("g",Mp,[...i[56]||(i[56]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(nt(),st("g",Dp,[...i[57]||(i[57]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(nt(),st("g",Lp,[...i[58]||(i[58]=[ge('<line x1="4" y1="21" x2="4" y2="14" data-v-240266bc></line><line x1="4" y1="10" x2="4" y2="3" data-v-240266bc></line><line x1="12" y1="21" x2="12" y2="12" data-v-240266bc></line><line x1="12" y1="8" x2="12" y2="3" data-v-240266bc></line><line x1="20" y1="21" x2="20" y2="16" data-v-240266bc></line><line x1="20" y1="12" x2="20" y2="3" data-v-240266bc></line><line x1="1" y1="14" x2="7" y2="14" data-v-240266bc></line><line x1="9" y1="8" x2="15" y2="8" data-v-240266bc></line><line x1="17" y1="16" x2="23" y2="16" data-v-240266bc></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(nt(),st("g",Rp,[...i[59]||(i[59]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(nt(),st("g",Pp,[...i[60]||(i[60]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(nt(),st("g",Op,[...i[61]||(i[61]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(nt(),st("g",zp,[...i[62]||(i[62]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(nt(),st("g",Np,[...i[63]||(i[63]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-240266bc></rect><line x1="13" y1="8" x2="19" y2="8" data-v-240266bc></line><line x1="13" y1="12" x2="19" y2="12" data-v-240266bc></line><line x1="13" y1="16" x2="17" y2="16" data-v-240266bc></line>',5)])])):t.name==="image-right"?(nt(),st("g",Fp,[...i[64]||(i[64]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-240266bc></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-240266bc></rect><line x1="5" y1="8" x2="11" y2="8" data-v-240266bc></line><line x1="5" y1="12" x2="11" y2="12" data-v-240266bc></line><line x1="5" y1="16" x2="9" y2="16" data-v-240266bc></line>',5)])])):(nt(),st("g",Hp,[...i[65]||(i[65]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,e)=>{const i=t.__vccOpts||t;for(const[n,o]of e)i[n]=o;return i},ft=ze(jp,[["__scopeId","data-v-240266bc"]]);function Zt(t,e){var o;if(typeof document>"u"||!t)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(e))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Up(t){if(typeof document>"u")return;const e=`.protyle-wysiwyg [${gt}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(e);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[gt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(gt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(gt,l):(n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const Wp={class:"spm-layout-picker"},Vp={class:"spm-layout-picker__grid"},qp=["title","onClick"],Kp={class:"spm-layout-icon"},Gp={class:"spm-layout-label"},Zp=Ce({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=t,n=e,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(nt(),st("div",Wp,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",Vp,[(nt(),st(Kt,null,xe(o,c=>p("div",{key:c.name,class:At(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[p("div",Kp,[dt(ft,{name:"layout-"+c.name},null,8,["name"])]),p("span",Gp,xt(c.label),1)],10,qp)),64))])]))}}),va=ze(Zp,[["__scopeId","data-v-3d2599ad"]]),Yp={key:0,class:"spm-transition-selector__header"},Jp={class:"spm-transition-list"},Xp=["onClick"],Qp={class:"spm-transition-meta"},th={class:"spm-transition-label"},eh={class:"spm-transition-name"},ih={class:"spm-transition-preview-box"},nh=Ce({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=e,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(nt(),st("div",{class:At(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Pt("",!0):(nt(),st("div",Yp,xt(t.title||"转场动效"),1)),p("div",Jp,[(nt(),st(Kt,null,xe(n,r=>p("div",{key:r.name,class:At(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[p("div",Qp,[p("span",th,xt(r.label),1),p("span",eh,"("+xt(r.name)+")",1)]),p("div",ih,[p("div",{class:At(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Xp)),64))])],2))}}),Vs=ze(nh,[["__scopeId","data-v-b0aa61ff"]]),oh={class:"spm-divider-popover"},sh={class:"spm-divider-popover__title"},rh={class:"spm-form-item"},lh={class:"spm-popover-footer"},ah={class:"spm-save-hint"},ch=Ce({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:e}){var v,d,y;const i=t,n=e,o=vt(((v=i.initialAttrs)==null?void 0:v[gt])||"default"),s=vt(((d=i.initialAttrs)==null?void 0:d[te])||"slide-left"),l=vt(((y=i.initialAttrs)==null?void 0:y[Ut])||""),r=vt("");Di(()=>i.initialAttrs,m=>{o.value=(m==null?void 0:m[gt])||"default",s.value=(m==null?void 0:m[te])||"slide-left",l.value=(m==null?void 0:m[Ut])||""},{deep:!0});async function a(m,g){if(i.blockId){r.value="正在同步...",Mt.setBlockAttrOverride(i.blockId,{[m]:g}),Zt(i.blockId,{[m]:g});try{await Et(i.blockId,{[m]:g}),r.value="已同步至块属性",n("updated",{[m]:g}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(m){a(gt,m)}function u(m){a(te,m)}function f(){a(Ut,l.value.trim())}return(m,g)=>(nt(),st("div",oh,[p("div",sh,[g[4]||(g[4]=p("span",null,"幻灯片页面设置",-1)),p("button",{class:"spm-close-btn",onClick:g[0]||(g[0]=k=>n("close"))},"✕")]),dt(va,{modelValue:o.value,"onUpdate:modelValue":g[1]||(g[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),dt(Vs,{modelValue:s.value,"onUpdate:modelValue":g[2]||(g[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),p("div",rh,[g[5]||(g[5]=p("label",{class:"spm-form-label"},"页面背景",-1)),Te(p("input",{"onUpdate:modelValue":g[3]||(g[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:f},null,544),[[yo,l.value]])]),p("div",lh,[p("span",ah,xt(r.value),1)])]))}}),dh=ze(ch,[["__scopeId","data-v-e4871368"]]),uh={class:"spm-slide-inspector"},fh={class:"spm-inspector-header"},ph={class:"spm-inspector-list"},hh=["onClick"],mh={class:"spm-card-top"},gh={class:"spm-card-badge"},vh={class:"spm-card-layout"},bh=["onClick"],yh={class:"spm-card-preview"},kh={key:0,class:"spm-card-notes",title:"演讲备忘录"},wh={class:"spm-inspector-modal-content"},xh=Ce({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:e}){const i=e,n=vt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[gt]=c.frontmatter.layout),c.frontmatter.transition&&(u[te]=c.frontmatter.transition),c.frontmatter.background&&(u[Ut]=c.frontmatter.background),c.notes&&(u[Ui]=c.notes),u}function l(c){n.value&&(c[gt]&&(n.value.frontmatter.layout=c[gt]),c[te]&&(n.value.frontmatter.transition=c[te]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Ui]&&(n.value.notes=c[Ui]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],f=u.content||u.rawMarkdown||"";return f.slice(0,40)+(f.length>40?"...":"")}return(c,u)=>(nt(),st("div",uh,[p("div",fh,[p("span",null,"幻灯片大纲 ("+xt(t.slides.length)+" 页)",1)]),p("div",ph,[(nt(!0),st(Kt,null,xe(t.slides,f=>(nt(),st("div",{key:f.pageIndex,class:At(["spm-card",{active:t.currentActivePage===f.pageIndex}]),onClick:v=>r(f.pageIndex)},[p("div",mh,[p("span",gh,"P"+xt(f.pageIndex),1),p("span",vh,xt(f.frontmatter.layout||"default"),1),p("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(v=>o(f),["stop"])},[dt(ft,{name:"settings"})],8,bh)]),p("div",yh,xt(a(f)),1),f.notes?(nt(),st("div",kh,[dt(ft,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),p("span",null,xt(f.notes),1)])):Pt("",!0)],10,hh))),128))]),n.value?(nt(),st("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(f=>n.value=null,["self"]))},[p("div",wh,[dt(dh,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=f=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Pt("",!0)]))}}),_h=ze(xh,[["__scopeId","data-v-68b25edd"]]),Sh={class:"spm-immersion-header"},Ch={class:"spm-immersion-header__left"},$h={class:"spm-immersion-title"},Ih={class:"spm-immersion-header__center"},Ah={class:"spm-immersion-header__actions"},Bh=["aria-label"],Th={class:"spm-immersion-body"},Eh=Ce({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:e}){const i=t,n=e;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((nt(),st("div",{class:At(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:s}),p("div",{class:At(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[p("div",Sh,[p("div",Ch,[Vn(a.$slots,"header-left",{},()=>[p("span",$h,xt(t.title),1)])]),p("div",Ih,[Vn(a.$slots,"header-center",{},void 0)]),p("div",Ah,[Vn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[dt(ft,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Bh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[dt(ft,{name:"close"})])])]),p("div",Th,[Vn(a.$slots,"default",{},void 0)])],2)],34)),[[na,t.visible]])}}),Mh=ze(Eh,[["__scopeId","data-v-3f1665db"]]),Dh={class:"spm-protyle-drawer"},Lh={class:"spm-protyle-drawer__subbar"},Rh={class:"spm-protyle-drawer__nav"},Ph=["title"],Oh={class:"spm-protyle-drawer__actions"},zh=["aria-label"],Nh=["aria-label"],Fh=Ce({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(n.blockId),s=vt(n.title||""),l=vt(!1),r=vt(!0),a=vt(!1),c=vt(""),u=hi,f=vt([]),v=vt(null);let d=null;Di(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",f.value=[],m(w))}),Pn(()=>{o.value&&m(o.value)}),Ds(()=>{g()});async function y(w){try{const H=await kn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(H)&&H.length>0){const j=H[0];c.value=j.root_id||"";const O=j.id===j.root_id||j.type==="d";a.value=O,r.value=!O,!s.value&&j.content&&(s.value=j.content.trim().slice(0,30));return}}catch(H){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",H)}a.value=!1,r.value=!0}async function m(w,H){if(!v.value||!w)return;g(),await y(w),typeof H=="boolean"&&(r.value=!a.value&&H);let j,O;r.value&&!a.value?(j=["cb-get-all","cb-get-hl","cb-get-focus"],O={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(j=["cb-get-context","cb-get-hl"],O={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ht.Protyle(n.plugin.app,v.value,{blockId:w,action:j,render:O}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(q){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",q)}}function g(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}v.value&&(v.value.innerHTML="")}function k(){a.value||(r.value=!r.value,m(o.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function I(){if(o.value)try{ht.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function T(){var j;if(!o.value)return;const w=Lo(),H=ra(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const O=Se("electron");(j=O==null?void 0:O.shell)!=null&&j.openExternal?O.shell.openExternal(H).catch(()=>{window.open(H,"_blank")}):window.open(H,"_blank")}i("external-jump",H)}function E(){if(f.value.length>0){const w=f.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,m(w.blockId,w.isFocusMode))}}function B(w){const H=w.target;if(!H)return;const j=H.closest('[data-type="block-ref"]');if(j){const q=j.getAttribute("data-id");if(q&&q!==o.value){w.preventDefault(),w.stopPropagation(),f.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=q,s.value=j.innerText.trim()||q,m(q);return}}const O=H.closest("a");if(O&&O.href&&O.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const q=O.href.replace("siyuan://blocks/","").split("?")[0];q&&q!==o.value&&(f.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=q,s.value=O.innerText.trim()||q,m(q))}}return(w,H)=>(nt(),st("div",Dh,[p("div",Lh,[p("div",Rh,[f.value.length>0?(nt(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:E},[dt(ft,{name:"arrow-left"}),H[0]||(H[0]=p("span",null,"返回",-1))])):Pt("",!0),p("span",{class:At(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xt(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:s.value||o.value},xt(s.value||o.value),9,Ph)]),p("div",Oh,[a.value?Pt("",!0):(nt(),st("button",{key:0,class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[dt(ft,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,xt(r.value?"块聚焦":"展开全文"),1)],10,zh)),p("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[dt(ft,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,xt(l.value?"编辑中":"只读"),1)],10,Nh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:I},[dt(ft,{name:"window"}),H[1]||(H[1]=p("span",null,"独立窗口",-1))]),bt(u).enableWebServeJump?(nt(),st("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[dt(ft,{name:"external-link"}),H[2]||(H[2]=p("span",null,"外跳",-1))])):Pt("",!0)])]),p("div",{ref_key:"mountEl",ref:v,class:At(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:B},null,2)]))}}),Hh=ze(Fh,[["__scopeId","data-v-7e586ef3"]]),jh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Uh=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Lr(t){let e=t||"";try{e=decodeURIComponent(e)}catch{}e=e.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(e);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(e);return n?`/plugins/${n[1]}`:null}function ba(t){const e=(t||"").replace(/^file:\/\//i,"");let i=e;try{i=decodeURIComponent(e)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function Wh(t){const e=t.split(/[/?#]/)[0];return!e||Uh.test(e)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(e)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(e)}function Vh(t){const e=t.indexOf("#"),i=e>=0?t.slice(e):"",n=e>=0?t.slice(0,e):t,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return t;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?t:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function ya(t){const e=qh(t);return e.external||!e.url?e:{url:Vh(e.url),external:!1}}function qh(t){const e=(t||"").trim();if(!e)return{url:"",external:!1};if(/^https?:\/\//i.test(e))return{url:e,external:!1};if(e.startsWith("//"))return{url:`https:${e}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(e))return{url:e,external:!1};if(Yr(e))return{url:`/${Jr(e)}`,external:!1};if(/^file:/i.test(e)){const n=Lr(ba(e));return n?{url:n,external:!1}:{url:e,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(e)||e.startsWith("\\\\")){const n=Lr(e);return n?{url:n,external:!1}:{url:e,external:!0}}return jh.test(e)?{url:e,external:!0}:Wh(e)?{url:`https://${e}`,external:!1}:{url:`/${e.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Kh={class:"spm-webview-drawer"},Gh={class:"spm-webview-toolbar"},Zh={class:"spm-webview-toolbar__nav"},Yh=["disabled"],Jh=["disabled"],Xh=["aria-label"],Qh={class:"spm-webview-toolbar__address"},tm=["aria-label"],em={class:"spm-webview-toolbar__actions"},im=["aria-label"],nm={class:"spm-zoom-controller"},om=["disabled"],sm=["disabled"],rm={key:1,class:"spm-webview-fallback"},lm=["src"],am={key:2,class:"spm-load-error"},cm={class:"spm-load-error__code"},dm={class:"spm-load-error__code-num"},um={class:"spm-load-error__url"},fm={class:"spm-load-error__hint"},pm={class:"spm-load-error__actions"},Rr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ka="siyuan-slidev-peek-view-mode";let wa="desktop";function hm(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ka);if(t==="mobile"||t==="desktop")return t}catch{}return wa}function mm(t){if(wa=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ka,t)}catch{}}function gm(t){switch((t||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const vm=Ce({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(ha()&&!vf()),s=vt(n.url),l=vt(n.url),r=vt(!1),a=vt(null),c=vt(!1),u=vt(!1),f=vt(1),v=vt(!1),d=vt(hm());let y=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const m=St(()=>d.value==="mobile"?Rr:y||void 0),g=vt(null),k=vt(null);let x=null,I=null,T=null;Di(()=>n.url,F=>{F&&F!==s.value&&(s.value=F,l.value=F,d.value==="mobile"&&j(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(F))}),Di(()=>n.visible,F=>{if(F)M(),d.value==="mobile"&&j(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),Pn(()=>{E(),k.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const F=g.value;if(F&&typeof F.invalidate=="function")try{F.invalidate()}catch{}}),x.observe(k.value)),I=F=>{var ut;const at=F.message||((ut=F.error)==null?void 0:ut.message);if(typeof at=="string"&&at.includes("Invalid guestInstanceId"))return F.preventDefault(),F.stopImmediatePropagation(),!0},window.addEventListener("error",I,!0),T=F=>{const at=F.reason,ut=typeof at=="string"?at:at==null?void 0:at.message;typeof ut=="string"&&ut.includes("Invalid guestInstanceId")&&F.preventDefault()},window.addEventListener("unhandledrejection",T)}),Ds(()=>{if(B(),x&&(x.disconnect(),x=null),I&&(window.removeEventListener("error",I,!0),I=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function E(){const F=g.value;F&&(F.addEventListener("dom-ready",w),F.addEventListener("did-start-loading",O),F.addEventListener("did-stop-loading",D),F.addEventListener("did-navigate",b),F.addEventListener("did-navigate-in-page",W),F.addEventListener("new-window",Y),F.addEventListener("did-fail-load",q),F.addEventListener("did-fail-provisional-load",q))}function B(){const F=g.value;if(F)try{F.removeEventListener("dom-ready",w),F.removeEventListener("did-start-loading",O),F.removeEventListener("did-stop-loading",D),F.removeEventListener("did-navigate",b),F.removeEventListener("did-navigate-in-page",W),F.removeEventListener("new-window",Y),F.removeEventListener("did-fail-load",q),F.removeEventListener("did-fail-provisional-load",q)}catch{}}function w(){const F=g.value;if(F&&typeof F.getUserAgent=="function"&&!y)try{const at=F.getUserAgent();at&&!at.includes("iPhone")&&(y=at)}catch{}d.value==="mobile"&&j(!1),M(),L()}function H(){const F=d.value==="mobile"?"desktop":"mobile";d.value=F,mm(F),j(!0)}function j(F=!1){const at=g.value;if(!at)return;const ut=d.value==="mobile"?Rr:y;if(typeof at.setUserAgent=="function"&&ut)try{at.setUserAgent(ut)}catch(C){console.warn("[WebviewPeekDrawer] setUserAgent error:",C)}if(F&&typeof at.reload=="function")try{at.reload()}catch(C){console.warn("[WebviewPeekDrawer] reload error:",C)}}function O(){r.value=!0,a.value=null}function q(F){if(F&&F.isMainFrame===!1||F&&Number(F.errorCode)===-3)return;const at=String((F==null?void 0:F.errorDescription)||"ERR_FAILED");a.value={errorCode:Number((F==null?void 0:F.errorCode)??0),description:at,validatedURL:String((F==null?void 0:F.validatedURL)||s.value),hint:gm(at)},r.value=!1}function S(){a.value=null,et()}function D(){if(r.value=!1,L(),g.value&&typeof g.value.getURL=="function"){const F=g.value.getURL();F&&F!=="about:blank"&&(s.value=F,l.value=F)}}function b(F){F!=null&&F.url&&(s.value=F.url,l.value=F.url),L()}function W(F){F!=null&&F.url&&(s.value=F.url,l.value=F.url),L()}function Y(F){F&&F.url&&(F.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(F.url))}function L(){const F=g.value;F&&(typeof F.canGoBack=="function"&&(c.value=F.canGoBack()),typeof F.canGoForward=="function"&&(u.value=F.canGoForward()))}function U(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function V(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function et(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function A(){const F=ya(l.value);if(F.url){if(F.external){s.value=F.url,lt();return}s.value=F.url,l.value=F.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(F.url)}}function M(){const F=g.value;if(F&&typeof F.setZoomFactor=="function")try{F.setZoomFactor(f.value)}catch(at){console.warn("[WebviewPeekDrawer] setZoomFactor error:",at)}}function X(){f.value=Math.min(2.5,Math.round((f.value+.1)*10)/10),M()}function J(){f.value=Math.max(.5,Math.round((f.value-.1)*10)/10),M()}function Q(){f.value=1,M()}function tt(F){F.preventDefault(),F.deltaY<0?X():F.deltaY>0&&J()}async function pt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),v.value=!0,setTimeout(()=>{v.value=!1},2e3)}catch(F){console.warn("Copy url failed:",F)}}function lt(){var at;const F=s.value;if(typeof window<"u"){const ut=Se("electron");(at=ut==null?void 0:ut.shell)!=null&&at.openExternal?ut.shell.openExternal(F).catch(()=>{window.open(F,"_blank")}):window.open(F,"_blank")}i("external-jump",F)}return(F,at)=>{const ut=Ad("webview");return nt(),st("div",Kh,[p("div",Gh,[p("div",Zh,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"后退",onClick:U},[dt(ft,{name:"arrow-left"})],8,Yh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"前进",onClick:V},[dt(ft,{name:"arrow-right"})],8,Jh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:et},[dt(ft,{name:"refresh"})],8,Xh)]),p("div",Qh,[Te(p("input",{"onUpdate:modelValue":at[0]||(at[0]=C=>l.value=C),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Uu(A,["enter"])},null,544),[[yo,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":v.value?"已复制地址！":"复制网址",onClick:pt},[dt(ft,{name:"copy"})],8,tm)]),p("div",em,[p("button",{class:At(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":d.value==="mobile"}]),"aria-label":d.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:H},[dt(ft,{name:d.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,im),p("div",nm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:f.value<=.5,onClick:J},[dt(ft,{name:"minus"})],8,om),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Q},xt(Math.round(f.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:f.value>=2.5,onClick:X},[dt(ft,{name:"plus"})],8,sm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:lt},[dt(ft,{name:"external-link"}),at[1]||(at[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:k,class:At(["spm-webview-body",{"is-mobile":d.value==="mobile"}]),onWheel:Me(tt,["ctrl"])},[p("div",{class:At(["spm-webview-viewport",{"is-mobile":d.value==="mobile"}])},[o.value?(nt(),De(ut,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:s.value,useragent:m.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(nt(),st("div",rm,[p("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,lm),p("div",{class:"spm-fallback-bar"},[at[2]||(at[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:lt}," 在新标签页中打开 ↗ ")])])),a.value?(nt(),st("div",am,[dt(ft,{name:"alert",class:"spm-load-error__icon"}),at[5]||(at[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",cm,[$e(xt(a.value.description)+" ",1),p("span",dm,"("+xt(a.value.errorCode)+")",1)]),p("div",um,xt(a.value.validatedURL),1),p("p",fm,xt(a.value.hint),1),p("div",pm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:S},[dt(ft,{name:"refresh"}),at[3]||(at[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:lt},[dt(ft,{name:"external-link"}),at[4]||(at[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Pt("",!0)],2)],34)])}}}),bm=ze(vm,[["__scopeId","data-v-13be9dce"]]);class ym{constructor(){yt(this,"timers",new Map)}debounce(e,i,n=150){this.cancel(e);const o=setTimeout(()=>{this.timers.delete(e),i()},n);this.timers.set(e,o)}cancel(e){this.timers.has(e)&&(clearTimeout(this.timers.get(e)),this.timers.delete(e))}cancelAll(){for(const e of this.timers.values())clearTimeout(e);this.timers.clear()}hasPending(e){return this.timers.has(e)}}class km{constructor(e){yt(this,"blockToPageMap",new Map);yt(this,"debounceCtrl",new ym);yt(this,"activeBlockId","");yt(this,"activePageIndex",1);yt(this,"currentDocId","");yt(this,"bridge",null);e&&(this.bridge=e)}setBridge(e){this.bridge=e}setDocId(e){this.currentDocId=e}updateSlidesIndex(e){this.blockToPageMap.clear();for(const i of e){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(e){return this.blockToPageMap.get(e)??null}onCursorFocusBlock(e){if(!e||e===this.activeBlockId)return;this.activeBlockId=e;let i=this.getPageByBlockId(e);!i&&(e===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(e))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(e){this.activeBlockId=e;const i=this.getPageByBlockId(e);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Li(t,e){var s,l;if(!t||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(e)try{return ht.openTab({app:e,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function wm(t){if(!t)return"";const e=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(e.length===0)return"";if(!e.some(l=>/^#{1,6}\s+/.test(l)))return e.map(l=>re(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>re(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of e){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${re(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function xm(t){if(t.length===0)return"";const e=[],i=t[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();e.push(`<h${o} class="slide-list-item-title">${re(s)}</h${o}>`)}else e.push(`<p class="slide-list-item-title">${re(i)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>re(a)).join("<br/>");e.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();e.push(`<h${c} class="slide-list-item-title">${re(u)}</h${c}>`)}else s.push(r)}l()}return e.join(`
`)+(e.length>0?`
`:"")}function xa(t,e,i){var v,d,y,m;const n=t.split(`
`);if(!n.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return null;const s=[],l=[];let r=!1;for(let g=0;g<n.length;g++){const k=n[g];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const B=x[1].length,w=Math.floor(B/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const I=k.match(/^(\s*)[-*+]\s+(.*)$/);if(I){const B=I[1].length,w=Math.floor(B/2);l.push({type:"unordered",level:w,text:I[2],media:[]});continue}const T=k.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(r=!0);const B=T[1].length,w=Math.floor(B/2);l.push({type:"ordered",level:w,text:T[2],media:[]});continue}const E=k.trim();if(!(!E||/^\{:.*?\}$/.test(E)))if(l.length>0){const B=E.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(B){const j=/\.gif(?:\?|$)/i.test(B[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(B[1])}" src="${B[2]}" class="${j}" /></div>`);continue}if(E.match(/^<img\b[\s\S]*?\/?>$/i)){const H=E.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${H}</div>`);continue}if(/<video\b/i.test(E)){let H=E;if(!/<\/video>/i.test(H))for(;g+1<n.length&&!/<\/video>/i.test(H);)g++,H+=" "+n[g].trim();const j=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(H),O=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(H),q=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-muted"])==="true"||j||/muted/i.test(H),S=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-controls"])==="false",D=H.match(/\bsrc=["']([^"']+)["']/i),b=D?D[1]:"",W=['class="slide-video-player"'];S||W.push("controls"),j&&(W.push("autoplay"),W.push("playsinline")),O&&W.push("loop"),q&&W.push("muted"),W.push('preload="metadata"'),b&&W.push(`src="${b}"`);const Y=H.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let L=Y?Y[1].trim():"";!L&&b&&(L=`<source src="${b}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${j?"true":"false"}" data-muted="${q?"true":"false"}"><video ${W.join(" ")}>${L}</video></div>`);continue}l[l.length-1].text+=`
`+E}else s.push(E)}if(l.length===0)return null;const a=r?"ol":"ul",c=(e==null?void 0:e.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(g=>{const k=wm(g.text),x=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",I=g.level||0,T=I>0?` style="margin-left:${(I*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${I%2===1?"circle":"square"} !important;`:""}"`:"",E=I>0?" slide-list-item--nested":"";if(g.type==="task"){const w=g.checked?' checked=""':"";return`<li class="pdf-task-item${E}"${T}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${E?` class="${E.trim()}"`:""}${T}>${k}${x}</li>`}).join(`
`);return`${xm(s)}<${a} class="${c}">
${u}
</${a}>`}function _m(t,e,i){const n=(e==null?void 0:e.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const u=o[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(!f){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(/<video\b/i.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]);let v=f;if(!/<\/video>/i.test(v))for(;c+1<o.length&&!/<\/video>/i.test(v);)c++,v+=`
`+o[c];s.push(v);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var y,m,g,k;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const x=f[1].length;return`<h${x} class="slide-list-item-title">${re(f[2].trim())}</h${x}>`}const v=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(v){const x=/\.gif(?:\?|$)/i.test(v[2]),I=(e==null?void 0:e.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(v[1])}" src="${v[2]}" class="${I}" /></div>`}if(/<video\b/i.test(u)){const x=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),I=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-loop"])==="true"||/loop/i.test(u),T=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-muted"])==="true"||x||/muted/i.test(u),E=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",B=u.match(/\bsrc=["']([^"']+)["']/i),w=B?B[1]:"",H=['class="slide-video-player"'];E||H.push("controls"),x&&H.push("autoplay playsinline"),I&&H.push("loop"),T&&H.push("muted"),H.push('preload="metadata"'),w&&H.push(`src="${w}"`);const j=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let O=j?j[1].trim():"";return!O&&w&&(O=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${T?"true":"false"}"><video ${H.join(" ")}>${O}</video></div>`}const d=xa(u,e,i);if(d)return r=!1,d;if(r){r=!1;const x=u.split(/\r?\n/).map(B=>B.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${re(x[0])}</p>`;const I=x[0],E=x.slice(1).map(B=>re(B)).join("<br/>");return`<p class="slide-list-item-title">${re(I)}</p>
<p class="slide-list-item-desc">${E}</p>`}return`<p class="slide-list-item-desc">${re(u)}</p>`}).filter(Boolean).join(`
`)}function Yo(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const e=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(e)}function Sm(t,e){var r,a,c,u,f,v,d,y;const i=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(Yo);if(i==="two-cols"){const m=o.some(q=>q.slot==="right");let g=[],k=[];if(m)g=o.filter(q=>q.slot!=="right"),k=o.filter(q=>q.slot==="right");else{const q=Math.ceil(o.length/2);g=o.slice(0,q),k=o.slice(q)}const x=q=>{const S=q.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(S.length>0){const D=S[0],b=(D.rawMarkdown||D.content||"").trim();(Pi(D)||/^(?:[-*+]|\d+\.)\s+/.test(b))&&(D.rawMarkdown=vn(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown)}};x(g),x(k);const I=g.map(q=>ui(q,e)).join(`
`),T=k.map(q=>ui(q,e)).join(`
`),E="pdf-two-cols-wrapper layout-two-cols-grid",B=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",H="pdf-col pdf-col--right",O=`style="grid-template-columns: ${Go((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${E}${B}" ${O}>
        <div class="${w}">${I}</div>
        <div class="${H}">${T}</div>
      </div>
    `}if(i==="clover"||Cn(i)){const m=i==="clover";let g=[];const k=o.filter(W=>W.slot==="header");if(k.length>0)g=k;else if(o.length>0){const W=o.find(Y=>Y.type==="h"&&(!Y.slot||Y.slot==="default"));W&&(g=[W])}const x=o.filter(W=>!g.includes(W));let I=2;if(m)I=4;else if(i==="three-cols-header")I=3;else if(i==="two-cols-header")I=2;else{let W=0;for(const Y of x){const L=(Y.slot||"").match(/^col-(\d+)$/i);L&&(W=Math.max(W,parseInt(L[1],10)))}if(W>=2)I=W;else if((u=t.frontmatter)!=null&&u.layoutRatio){const Y=t.frontmatter.layoutRatio.trim();if(Y.includes(":")){const L=Y.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);L.length>=2&&(I=L.length)}else{const L=Y.split(/\s+/).filter(Boolean);L.length>=2&&(I=L.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(I=Math.min(6,x[0].children.length))}const T=fa(x,I),E=x.some(W=>W.slot&&/^(?:col-\d+|left|right)$/i.test(W.slot)),B=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Cn(i)&&E,w=W=>{const Y=W.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(B&&Y.length>0){const U=Y[0],V=(U.rawMarkdown||U.content||"").trim();(Pi(U)||/^(?:[-*+]|\d+\.)\s+/.test(V))&&(U.rawMarkdown=vn(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown),U.isColFirst=!0}const L=B?Y.find(Yo):null;return Y.map(U=>ui(U,{...e,extraClassName:U===L?"slidev-col-first-heading-block":""})).join(`
`)},H=g.find(Yo),j=g.map(W=>ui(W,{...e,extraClassName:W===H?"slidev-page-first-heading-block":""})).join(`
`),O=m?"repeat(2, minmax(0, 1fr))":Go((f=t.frontmatter)==null?void 0:f.layoutRatio,I),q=m?`style="grid-template-columns: ${O}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${O};"`,S=[m?"layout-clover-container":"layout-cols-header-container",I===2?"layout-two-cols-header-container":"",I===3?"layout-three-cols-header-container":"",`layout-${i}-container`,B?"has-superblock-cols":""].filter(Boolean).join(" "),D=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",I===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",I===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",B?"has-superblock-cols":""].filter(Boolean).join(" "),b=T.map((W,Y)=>{const L=Y+1;return`<div class="${["pdf-col",I===2&&L===1?"pdf-col--left":"",I===2&&L===2?"pdf-col--right":"",`pdf-col--${L}`,`col-${L}`].filter(Boolean).join(" ")}">${w(W)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${j}</div>
        <div class="${D}" ${q}>
          ${b}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",g=o.map(B=>ui(B,e)).join(`
`),k=((v=t.frontmatter)==null?void 0:v.image)||((d=t.frontmatter)==null?void 0:d.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,I=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,T=m?`${I}
${x}`:`${x}
${I}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Go((y=t.frontmatter)==null?void 0:y.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${T}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(g=>ui(g,e)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(g=>ui(g,e)).join(`
`)}</div>`:o.map(m=>ui(m,{...e,extraClassName:m===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Cm(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const e=new Set,i=t.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)e.add(c)}else{const s=parseInt(o,10);isNaN(s)||e.add(s)}}return e}const $m=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function re(t){if(!t)return"";const e=ca(t),i=[],n=e.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!$m.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ce(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,f)=>{const d=(r??a??c??u??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Im(t,e="pdf-table"){if(t.length<2)return"";const i=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;t.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${re(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${re(c)}</td>`).join("")}</tr>`).join("");return`<table class="${e}">${l}<tbody>${r}</tbody></table>`}function Jo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Pr(t,e="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Jo(t)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${Jo(l)}</span>`),`__TOK_${i.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Jo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function Am(t,e){if(!t)return null;const i=t.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||e,title:n,level:o}):null}function Bm(t,e=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const f=Am(c,u+1);f&&s.push(f)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===e,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const f=[];for(const v of c){const d=a(v.children,u+1);u>=n?f.push({...v,children:d}):f.push(...d)}return f}return a(l,1)}function Tm(t,e=1,i={}){const n=Bm(t,e,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slidev-toc-list slidev-toc-list-level-${u}`,v=c.map(d=>{const y=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let g=re(d.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${y}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${g}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function ui(t,e){var I,T,E,B,w,H,j,O,q,S;let i="",n="",o="";const s=[];(I=t.motion)!=null&&I.preset&&t.motion.preset!=="none"&&(i=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((T=t.attributes)==null?void 0:T.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ce(s.join(";"))}"`);const r=(e==null?void 0:e.containerClassName)||"pdf-block",a=e!=null&&e.extraClassName?` ${e.extraClassName}`:"",c=`${r}${i}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const D=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(D)}</em></div></div>`}const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){const D=f[1].length,b=re(f[2]),Y=!!(t.isColFirst||t.type==="i"&&((E=e==null?void 0:e.extraClassName)!=null&&E.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${D}${Y}>${b}</h${D}></div>`}if(u.startsWith(":::")){const D=u.split(`
`),W=D[0].replace(/^:::\s*/,"").trim()||"info",Y=D.slice(1,D[D.length-1].startsWith(":::")?-1:void 0).join(`
`),L=(e==null?void 0:e.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${L} ${L}--${W}"><div class="${L}-title">${W.toUpperCase()}</div><div class="${L}-body">${re(Y)}</div></div></div>`}if(u.startsWith("<<<")){const W=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((V,et)=>`<span class="code-line shiki-focus"><span class="line-no">${et+1}</span><span class="line-content">${Pr(V,"ts")}</span></span>`).join(`
`),Y=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",L=((B=t.attrs)==null?void 0:B["custom-slidev-max-height"])||t.maxHeight||"",U=L?` style="max-height:${ce(L)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${Y}"${U}><span class="lang-badge">TS</span><code>${W}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const D=u.split(`
`),b=D[0].slice(3).trim(),W=b.match(/^([^\s{\[]+)/),Y=W?W[1]:"",L=b.match(/\[([^\]]+)\]/),U=L?L[1]:"",V=b.includes("twoslash"),et=t.shikiLines||((w=b.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",A=Cm(et),M=D.length>2?D[D.length-1]==="```"?D.slice(1,-1):D.slice(1):[u.slice(3).replace(/```$/,"")],X=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",J=U?`${X} has-filename`:X,Q=A!=="all",tt=M.map((ut,C)=>{const P=C+1,z=A==="all"||A.has(P)?"code-line shiki-focus":Q?"code-line shiki-dimmed":"code-line";let _=(e==null?void 0:e.highlight)===!0?Pr(ut,Y):ce(ut);return V&&ut.includes("doubled.value = 2")?(_=_.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${z}"><span class="line-no">${P}</span><span class="line-content">${_}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${z}"><span class="line-no">${P}</span><span class="line-content">${_}</span></span>`}).join(`
`),pt=Y?`<span class="lang-badge">${ce(Y)}</span>`:"",lt=U?`<span class="code-filename">${ce(U)}</span>`:"",F=((H=t.attrs)==null?void 0:H["custom-slidev-max-height"])||t.maxHeight||"",at=F?` style="max-height:${ce(F)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${J}"${at}>${lt}${pt}<code>${tt}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(D=>D.trim().startsWith("|")).length>=2){const D=u.split(`
`).filter(W=>W.trim().startsWith("|")),b=Im(D,e==null?void 0:e.tableClassName);return`<div class="${c}"${n}>${b}</div>`}if(u.startsWith("> ")){const D=(e==null?void 0:e.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${D}"><p>${re(u.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),y=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(v&&!d&&!y&&!u.includes(`
`)){const D=((j=t.attributes)==null?void 0:j["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),b=((O=t.attributes)==null?void 0:O["custom-slidev-loop"])==="true"||/loop/i.test(u),W=((q=t.attributes)==null?void 0:q["custom-slidev-muted"])==="true"||D||/muted/i.test(u),Y=((S=t.attributes)==null?void 0:S["custom-slidev-controls"])==="false",L=u.match(/\bsrc=["']([^"']+)["']/i),U=L?L[1]:"",V=['class="slide-video-player"'];Y||V.push("controls"),D&&(V.push("autoplay"),V.push("playsinline")),b&&V.push("loop"),W&&V.push("muted"),V.push('preload="metadata"'),U&&V.push(`src="${U}"`);const et=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=et?et[1].trim():"";return!A&&U&&(A=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${D?"true":"false"}" data-muted="${W?"true":"false"}"${n}><video ${V.join(" ")}>${A}</video></div>`}const m=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(m){const D=(e==null?void 0:e.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(m[1])}" src="${m[2]}" class="${D}" /></div>`}const g=xa(u,e,t);if(g)return`<div class="${c} pdf-list-item"${n}>${g}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const D=u.match(/minDepth=["']?(\d+)["']?/i),b=u.match(/maxDepth=["']?(\d+)["']?/i),W=u.match(/columns=["']?(\d+)["']?/i),Y=(e==null?void 0:e.allSlides)||[];return`<div class="${c}"${n}>${Tm(Y,(e==null?void 0:e.currentPageIndex)||1,{minDepth:D?parseInt(D[1],10):1,maxDepth:b?parseInt(b[1],10):1/0,columns:W?parseInt(W[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||y){const D=_m(u,e,t);if(D)return`<div class="${c}"${n}>${D}</div>`}const x=!!t.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${re(u)}</p></div>`}function Em(t){return`
    ${yn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function Mm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          const isCover = slide.frontmatter?.layout === "cover";
          const pageFirstH = !isCover ? (slide.blocks || []).find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          renderSlide(currentIndex + 1);
        } else {
          renderSlide(currentIndex - 1);
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function _a(t,e){const i="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(i)}</title>
  <style>
${Em(e==null?void 0:e.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Mm()}
  <\/script>
</body>
</html>`}function Sa(t,e){if(typeof document>"u")return!1;const i=new Blob([e],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Dm(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Lm(t){const e=Dm(t==null?void 0:t.pageRatio);return`
    ${yn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${e}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function Rm(t,e){const i="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",f=Sm(l),v=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(i)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${f}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(i)} - 高保真讲义</title>
  <style>
    ${Lm({pageRatio:n,customInlineStyles:e==null?void 0:e.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Ca(t,e){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=Rm(t,e);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Pm={class:"spm-slidev-preview-tab"},Om={class:"spm-slidev-tab__toolbar"},zm={class:"spm-slidev-tab__actions"},Nm=["disabled"],Fm={class:"spm-page-badge"},Hm=["disabled"],jm=["aria-label"],Um=["aria-label"],Wm=["src"],Vm=Ce({__name:"SlidevPreviewTab",setup(t,{expose:e}){const i=ti("plugin"),n=ti("sandboxBridge",new Ws),o=new km(n),s=new Af,l=vt("web-sandbox"),r=vt(3030),a=vt(null),c=vt(!1),u=vt(null),f=vt(1),v=vt(1),d=vt([]),y=vt(!1),m=vt(!1),g=vt(!1),k=vt("siyuan"),x=vt(""),I=vt(""),T=vt(""),E=vt(!1),B=vt(!1),w=vt(""),H=vt("/plugins/siyuan-slidev/slidev-client/index.html");let j=null,O=null,q=null,S=null,D=null,b=null,W=null;Pn(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),j=n.onSlideChanged((C,P)=>{f.value=C,v.value=P}),O=n.onBlockClicked((C,P)=>{f.value=P,o.setActiveBlockId(C),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(C,P):Li(C,i==null?void 0:i.app)}),q=n.onOpenInEditor((C,P)=>{f.value=P,o.setActiveBlockId(C),Li(C,i==null?void 0:i.app)}),S=s.nativeBridge.onPageChanged((C,P)=>{f.value=C,v.value=P}),D=n.onOpenPeekDrawer(async C=>{const P=Lo();if(C.peekType==="siyuan"&&P.enableWebServeJump){let h=!1;if(W&&W.docId===C.target)h=!0;else if(W&&W.slides&&W.slides.some(z=>{var N;return(N=z.blocks)==null?void 0:N.some(_=>_.id===C.target)}))h=!1;else try{const z=await kn(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);z&&z.length>0&&(h=z[0].type==="d"||z[0].id===z[0].root_id)}catch(z){console.warn("[SlidevPreviewTab] detect block type failed:",z)}k.value="web",E.value=!0,I.value=ra(P.webServeUrl,C.target,{focus:!h}),T.value=C.title||`${h?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,m.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=C.peekType,C.peekType==="siyuan")x.value=C.target,T.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const h=ya(C.target);if(h.external){tt(C.target);return}E.value=!0,I.value=h.url,T.value=C.title||h.url}m.value=!0,n.freezeKeyboardNav(!0)}}),b=n.onRequestToggleFullscreen(()=>{lt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",pt)}),Ls(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",pt),D&&D(),b&&b(),j&&j(),O&&O(),q&&q(),S&&S(),n.detach(),o.destroy(),s.destroy()});async function Y(){if(l.value==="web-sandbox"){if(!W){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const C=await s.startProMode(W,is);if(!C.success){ht.showMessage(`无法启动官方 Pro 模式：${C.error}`);return}l.value="pro-cli",r.value=C.port||3030,H.value=C.url,u.value&&s.nativeBridge.attach(u.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",H.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ht.showMessage("已切回内置高保真沙箱")}function L(){B.value=!B.value,B.value?w.value=(W==null?void 0:W.docId)||"":(w.value="",X())}let U=0;function V(C){if(m.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const P=Date.now();P-U<280||(U=P,C.deltaY>0?A():et())}function et(){if(f.value>1){const C=f.value-1;f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function A(){if(f.value<v.value){const C=f.value+1;f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function M(C){f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}function X(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function J(){m.value=!1,n.freezeKeyboardNav(!1)}function Q(){J()}function tt(C){var N,_;const P=/^file:/i.test(C),h=P||/^[a-zA-Z]:[\\/]/.test(C),z=Se("electron");if(h&&typeof((N=z==null?void 0:z.shell)==null?void 0:N.openPath)=="function"){z.shell.openPath(P?ba(C):C),ht.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((_=z==null?void 0:z.shell)==null?void 0:_.openExternal)=="function"?z.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),ht.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function pt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function lt(){const C=a.value||u.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function F(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function at(){if(!W){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const C=_a(W);Sa("presentation.html",C)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function ut(){if(!W){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ca(W)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return e({updateDocument(C,P){B.value&&w.value&&P&&P!==w.value||(W=C,B.value&&!w.value&&(w.value=C.docId),d.value=C.slides,v.value=C.slides.length,o.setDocId(C.docId),o.updateSlidesIndex(C.slides),l.value==="pro-cli"?s.scaffolder.scaffold(C,is).catch(()=>{}):n.updateSlides(C.slides,C.config,C.fullMarkdown,C.customThemeCss))},navigateToBlock(C){o.onCursorFocusBlock(C)},isPinned:B,pinnedDocId:w,engineMode:l,toggleEngineMode:Y}),(C,P)=>(nt(),st("div",Pm,[p("div",Om,[P[4]||(P[4]=p("div",{class:"spm-slidev-tab__title"},[p("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"Slidev 演示预览")],-1)),p("div",zm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:et},[dt(ft,{name:"chevron-left"})],8,Nm),p("span",Fm,xt(f.value)+" / "+xt(v.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=v.value,"aria-label":"下一页",onClick:A},[dt(ft,{name:"chevron-right"})],8,Hm),p("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":B.value}]),"aria-label":B.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:L},[dt(ft,{name:"pin"}),p("span",null,xt(B.value?"已锁定":"跟随"),1)],10,jm),p("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[dt(ft,{name:"rocket"}),p("span",null,xt(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Um),P[3]||(P[3]=p("span",{class:"spm-toolbar-divider"},null,-1)),p("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":y.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:P[0]||(P[0]=h=>y.value=!y.value)},[dt(ft,{name:"outline"})],2),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:F},[dt(ft,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:at},[dt(ft,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:ut},[dt(ft,{name:"export-pdf"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:X},[dt(ft,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:lt},[dt(ft,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:V},[p("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:H.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Wm),dt(Mh,{visible:m.value,"onUpdate:visible":P[1]||(P[1]=h=>m.value=h),"is-maximized":g.value,"onUpdate:isMaximized":P[2]||(P[2]=h=>g.value=h),title:T.value,onClose:J},{default:Il(()=>[k.value==="siyuan"&&x.value?(nt(),De(Hh,{key:0,"block-id":x.value,title:T.value,plugin:bt(i),onExternalJump:Q},null,8,["block-id","title","plugin"])):Pt("",!0),E.value?Te((nt(),De(bm,{key:1,visible:m.value&&k.value==="web",url:I.value,title:T.value,onExternalJump:Q},null,8,["visible","url","title"])),[[na,k.value==="web"]]):Pt("",!0)]),_:1},8,["visible","is-maximized","title"])],544),y.value&&d.value.length>0?(nt(),De(_h,{key:0,slides:d.value,"current-active-page":f.value,onNavigate:M,onRefresh:X},null,8,["slides","current-active-page"])):Pt("",!0)]))}}),qm=ze(Vm,[["__scopeId","data-v-dd3f9635"]]),Km={class:"spm-section spm-section--page"},Gm={class:"spm-section-header"},Zm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Ym={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Jm={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Xm={key:1,class:"spm-card-control"},Qm={class:"spm-control-header"},tg={class:"spm-control-title-group"},eg={class:"spm-control-title"},ig={class:"spm-quick-chips"},ng=["onClick"],og={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},sg=["value"],rg=["aria-label"],lg={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},ag={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},cg={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},dg={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},ug={class:"spm-card-control"},fg={class:"spm-control-header"},pg={class:"spm-control-title-group"},hg={class:"spm-control-title"},mg={class:"spm-segmented-group"},gg={class:"spm-card-control"},vg={class:"spm-control-header"},bg={class:"spm-control-title-group"},yg={class:"spm-control-title"},kg={class:"spm-quick-chips"},wg=["onClick"],xg=["value"],_g={key:2,class:"spm-card-control"},Sg={class:"spm-control-header"},Cg={class:"spm-control-title-group"},$g={class:"spm-control-title"},Ig={class:"spm-quick-chips"},Ag=["onClick"],Bg=["value"],Tg={class:"spm-card-control"},Eg={class:"spm-control-header"},Mg={class:"spm-control-title-group"},Dg={class:"spm-control-title"},Lg={key:0,class:"spm-note-status-box"},Rg=["title"],Pg={class:"spm-action-grid",style:{"margin-top":"6px"}},Og={key:1,class:"spm-note-empty-box"},zg={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Ng={class:"spm-action-grid"},Fg=["disabled"],Hg=["disabled"],jg={class:"spm-card-control"},Ug={class:"spm-action-grid"},Wg=Ce({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:e}){const i=t,n=e,o=St(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),s=St(()=>{var y,m;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const v=(i.pageLayoutRatio||"").trim();if(v.includes(":")){const g=v.split(":").filter(Boolean).length;if(g>=2&&g<=6)return g}const d=(i.detectedSbRatio||"").trim();if(d.includes(":")){const g=d.split(":").filter(Boolean).length;if(g>=2&&g<=6)return g}if((y=i.detectedSbInfo)!=null&&y.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((m=i.detectedSbInfo)!=null&&m.slots&&Array.isArray(i.detectedSbInfo.slots)){const g=i.detectedSbInfo.slots.length;if(g>=2&&g<=6)return g}return 2}),l=St(()=>{const v=s.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=St(()=>i.pageLayoutRatio||"");function a(){const v=s.value||2,d=Array(v).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=St(()=>{if(!i.pageNotes)return"";const v=i.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],f=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,d)=>(nt(),st("div",Km,[p("div",Gm,[p("span",null,"幻灯片页面设置"+xt(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),dt(va,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=y=>v.$emit("update:pageLayout",y))},null,8,["model-value"]),!o.value&&t.pageLayout!=="clover"&&t.detectedSbRatio?(nt(),st("div",Zm,[p("div",Ym,[p("div",Jm,[dt(ft,{name:"sparkles"}),p("span",null,[d[22]||(d[22]=$e("检测到本页横向超级块列宽比例：",-1)),p("b",null,xt(t.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=y=>v.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[dt(ft,{name:"columns"}),d[23]||(d[23]=p("span",null,"设为分栏",-1))])])])):Pt("",!0),o.value?(nt(),st("div",Xm,[p("div",Qm,[p("div",tg,[p("div",eg,[dt(ft,{name:"ratio"}),d[24]||(d[24]=p("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",ig,[(nt(!0),st(Kt,null,xe(l.value,y=>(nt(),st("button",{key:y.value,class:At(["spm-chip",{active:r.value===y.value}]),onClick:m=>v.$emit("update:pageLayoutRatio",y.value)},xt(y.label),11,ng))),128))]),p("div",og,[p("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=y=>v.$emit("update:pageLayoutRatio",y.target.value)),onChange:d[3]||(d[3]=y=>v.$emit("update:pageLayoutRatio",y.target.value))},null,40,sg),t.detectedSbRatio?(nt(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=y=>v.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[dt(ft,{name:"sparkles"}),d[26]||(d[26]=p("span",null,"读取",-1))],8,rg)):(nt(),st("button",lg,[dt(ft,{name:"sparkles"}),d[27]||(d[27]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[dt(ft,{name:"reset"}),d[28]||(d[28]=p("span",null,"重置",-1))])]),t.detectedSbRatio?(nt(),st("div",ag,[dt(ft,{name:"ratio"}),d[29]||(d[29]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",cg,xt(t.detectedSbRatio),1)])):(nt(),st("div",dg,[dt(ft,{name:"ratio"}),d[30]||(d[30]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Pt("",!0),dt(Vs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=y=>v.$emit("update:pageTransition",y))},null,8,["model-value"]),p("div",ug,[p("div",fg,[p("div",pg,[p("div",hg,[dt(ft,{name:"ratio"}),d[31]||(d[31]=p("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",mg,[p("button",{class:At(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=y=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=y=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=y=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=y=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",gg,[p("div",vg,[p("div",bg,[p("div",yg,[dt(ft,{name:"palette"}),d[33]||(d[33]=p("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",kg,[(nt(),st(Kt,null,xe(u,y=>p("button",{key:y.value,class:At(["spm-chip",{active:t.pageBackground===y.value}]),onClick:m=>v.$emit("update:pageBackground",y.value)},xt(y.label),11,wg)),64))]),p("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=y=>v.$emit("update:pageBackground",y.target.value)),onChange:d[11]||(d[11]=y=>v.$emit("update:pageBackground",y.target.value))},null,40,xg)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(nt(),st("div",_g,[p("div",Sg,[p("div",Cg,[p("div",$g,[dt(ft,{name:"image"}),d[35]||(d[35]=p("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",Ig,[(nt(),st(Kt,null,xe(f,y=>p("button",{key:y.value,class:At(["spm-chip",{active:t.pageImage===y.value}]),onClick:m=>v.$emit("update:pageImage",y.value)},xt(y.label),11,Ag)),64))]),p("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=y=>v.$emit("update:pageImage",y.target.value)),onChange:d[13]||(d[13]=y=>v.$emit("update:pageImage",y.target.value))},null,40,Bg)])):Pt("",!0),p("div",Tg,[p("div",Eg,[p("div",Mg,[p("div",Dg,[dt(ft,{name:"presenter"}),d[37]||(d[37]=p("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=y=>v.$emit("generateNotes"))},[dt(ft,{name:"sparkles"}),d[39]||(d[39]=p("span",null,"AI 讲稿",-1))])]),t.pageNotes?(nt(),st("div",Lg,[d[42]||(d[42]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:t.pageNotes},xt(c.value),9,Rg),p("div",Pg,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=y=>v.$emit("locateNoteBlock"))},[dt(ft,{name:"search"}),d[40]||(d[40]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=y=>v.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),d[41]||(d[41]=p("span",null,"追加讲稿块",-1))])])])):(nt(),st("div",Og,[d[44]||(d[44]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=y=>v.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),d[43]||(d[43]=p("span",null,"添加讲稿备注块",-1))])])),p("div",zg,[p("div",Ng,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=y=>v.$emit("batchAppendNotes"))},[dt(ft,{name:"insert-below"}),d[45]||(d[45]=p("span",null,"全部追加",-1))],12,Fg),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=y=>v.$emit("batchDeleteNotes"))},[dt(ft,{name:"trash"}),d[46]||(d[46]=p("span",null,"全部删除",-1))],12,Hg)])])]),p("div",jg,[d[49]||(d[49]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",Ug,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=y=>v.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),d[47]||(d[47]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=y=>v.$emit("deleteDivider"))},[dt(ft,{name:"trash"}),d[48]||(d[48]=p("span",null,"删除此页",-1))])])])]))}}),Vg=ze(Wg,[["__scopeId","data-v-9c927c7c"]]),qg={class:"spm-section spm-section--block"},Kg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Gg={class:"spm-control-header"},Zg={class:"spm-control-title-group"},Yg={class:"spm-control-title"},Jg={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Xg={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Qg={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},tv={key:0},ev={key:1},iv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},nv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},ov={class:"spm-action-grid"},sv={class:"spm-card-control"},rv={class:"spm-control-header"},lv={class:"spm-control-title-group"},av={class:"spm-control-title"},cv=["aria-label"],dv=["checked"],uv={key:1,class:"spm-card-control"},fv={class:"spm-control-header"},pv={class:"spm-control-title-group"},hv={class:"spm-control-title"},mv={class:"spm-quick-chips"},gv={key:2,class:"spm-card-control"},vv={class:"spm-control-header"},bv={class:"spm-control-title-group"},yv={class:"spm-control-title"},kv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},wv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},xv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},_v=["aria-label"],Sv=["checked"],Cv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},$v={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Iv=["aria-label"],Av=["checked"],Bv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Tv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Ev=["aria-label"],Mv=["checked"],Dv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Lv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Rv=["aria-label"],Pv=["checked"],Ov={class:"spm-card-control"},zv={class:"spm-control-header"},Nv={class:"spm-control-title-group"},Fv={class:"spm-control-title"},Hv=["aria-label"],jv=["checked"],Uv={key:0,class:"spm-quick-chips"},Wv=["onClick"],Vv={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},qv={class:"spm-card-control"},Kv={class:"spm-control-header"},Gv={class:"spm-control-title-group"},Zv={class:"spm-control-title"},Yv=["aria-label"],Jv=["checked"],Xv={key:0,class:"spm-quick-chips"},Qv=["onClick"],tb={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},eb={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},ib={style:{display:"flex",gap:"6px"}},nb=["value"],ob=["value"],sb={key:3,class:"spm-card-control"},rb={class:"spm-control-header"},lb={class:"spm-control-title-group"},ab={class:"spm-control-title"},cb={class:"spm-control-desc"},db={class:"spm-segmented-group"},ub=["onClick"],fb={key:4,class:"spm-card-control"},pb={class:"spm-control-header"},hb={class:"spm-control-title-group"},mb={class:"spm-control-title"},gb={class:"spm-quick-chips"},vb=["onClick"],bb=["value"],yb={key:5,class:"spm-card-control"},kb={class:"spm-control-header"},wb={class:"spm-control-title-group"},xb={class:"spm-control-title"},_b={class:"spm-quick-chips"},Sb=["onClick"],Cb=["value"],$b={class:"spm-card-control"},Ib={class:"spm-action-grid"},Ab=["aria-label"],Bb=Ce({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:e}){const i=t,n=St(()=>{const B=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":B}),o=St(()=>{const B=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(B)}),s=St(()=>{var w,H,j,O;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const B=(H=i.elemSlot)==null?void 0:H.match(/^col-(\d+)$/);if(B){const q=parseInt(B[1],10);if(q>=2&&q<=6)return Math.max(q,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((O=(j=i.detectedSbInfo)==null?void 0:j.ratio)!=null&&O.includes(":")){const q=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(q.length>=2)return Math.min(q.length,6)}return 3}),l=St(()=>{const B=n.value;return B==="cols-header"?"多栏插槽归属 (Slot)":B==="three-cols-header"?"三栏插槽归属 (Slot)":B==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=St(()=>{const B=n.value;return B==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:B==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":B==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":B==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=St(()=>{const B=n.value;if(B==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(B==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(B==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,H=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let j=1;j<=w;j++)H.push({value:`col-${j}`,label:`第 ${j} 栏`});return H});function c(B){const w=i.elemSlot||"";return B?w===B||B==="col-1"&&w==="left"||B==="col-2"&&w==="center"||B==="col-3"&&w==="right"&&s.value===3||B==="col-2"&&w==="right"&&s.value===2||B==="left"&&w==="col-1"||B==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=e,f=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=St(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const B=JSON.parse(i.elemMotion);if(typeof B=="object"&&B!==null)return{preset:B.preset||B.type||"slide-up",duration:typeof B.duration=="number"?B.duration:0,delay:typeof B.delay=="number"?B.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),d=St(()=>!!v.value),y=St(()=>{var B;return((B=v.value)==null?void 0:B.preset)||"slide-up"}),m=St(()=>{var B;return((B=v.value)==null?void 0:B.duration)||0}),g=St(()=>{var B;return((B=v.value)==null?void 0:B.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(B){E(B,m.value,g.value)}function I(B){E(y.value,B,g.value)}function T(B){E(y.value,m.value,B)}function E(B,w,H){if(!B||B==="none"){u("update:elemMotion","");return}if(!w&&!H){u("update:elemMotion",B);return}const j={preset:B};w>0&&(j.duration=w),H>0&&(j.delay=H),u("update:elemMotion",JSON.stringify(j))}return(B,w)=>{var H,j,O,q,S,D;return nt(),st("div",qg,[w[62]||(w[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(H=t.detectedSbInfo)!=null&&H.hasSuperBlock?(nt(),st("div",Kg,[p("div",Gg,[p("div",Zg,[p("div",Yg,[dt(ft,{name:"ratio"}),w[24]||(w[24]=p("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",Jg,[p("div",Xg,[p("div",Qg,[dt(ft,{name:"ratio"}),(j=t.detectedSbInfo)!=null&&j.isCustomWidth?(nt(),st("span",tv,"已识别自定义列宽比例")):(nt(),st("span",ev,"识别到 "+xt(((O=t.detectedSbInfo)==null?void 0:O.colCount)||2)+" 列超级块分栏",1))]),p("code",iv,xt(((q=t.detectedSbInfo)==null?void 0:q.ratio)||"1:1"),1)]),p("div",nv,xt((S=t.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",ov,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=b=>B.$emit("applySuperBlockLayout",t.detectedSbInfo))},[dt(ft,{name:"sparkles"}),w[26]||(w[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=b=>{var W;return B.$emit("applySuperBlockRatio",((W=t.detectedSbInfo)==null?void 0:W.ratio)||"1:1")})},[dt(ft,{name:"check"}),p("span",null,"应用比例 ("+xt(((D=t.detectedSbInfo)==null?void 0:D.ratio)||"1:1")+")",1)])])])):Pt("",!0),p("div",sv,[p("div",rv,[p("div",lv,[p("div",av,[dt(ft,{name:"presenter"}),w[27]||(w[27]=p("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=b=>B.$emit("toggleNote"))},null,40,dv),w[29]||(w[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,cv)])]),t.isImage||t.imageRole?(nt(),st("div",uv,[p("div",fv,[p("div",pv,[p("div",hv,[dt(ft,{name:"image"}),w[30]||(w[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",mv,[p("button",{class:At(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=b=>B.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:At(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=b=>B.$emit("update:imageRole","background"))},[dt(ft,{name:"image"}),w[32]||(w[32]=p("span",null,"背景图",-1))],2),p("button",{class:At(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=b=>B.$emit("update:imageRole","image-left"))},[dt(ft,{name:"image-left"}),w[33]||(w[33]=p("span",null,"图左",-1))],2),p("button",{class:At(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=b=>B.$emit("update:imageRole","image-right"))},[dt(ft,{name:"image-right"}),w[34]||(w[34]=p("span",null,"图右",-1))],2)])])):Pt("",!0),t.isVideo?(nt(),st("div",gv,[p("div",vv,[p("div",bv,[p("div",yv,[dt(ft,{name:"video"}),w[35]||(w[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",kv,[p("div",wv,[p("span",xv,[dt(ft,{name:"sliders"}),w[37]||(w[37]=$e(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=b=>B.$emit("toggleVideoControls"))},null,40,Sv),w[38]||(w[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,_v)]),p("div",Cv,[p("span",$v,[dt(ft,{name:"video"}),w[39]||(w[39]=$e(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=b=>B.$emit("toggleVideoAutoplay"))},null,40,Av),w[40]||(w[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,Iv)]),p("div",Bv,[p("span",Tv,[dt(ft,{name:"repeat"}),w[41]||(w[41]=$e(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=b=>B.$emit("toggleVideoLoop"))},null,40,Mv),w[42]||(w[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ev)]),p("div",Dv,[p("span",Lv,[dt(ft,{name:"volume-x"}),w[43]||(w[43]=$e(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=b=>B.$emit("toggleVideoMuted"))},null,40,Pv),w[44]||(w[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,Rv)])])])):Pt("",!0),p("div",Ov,[p("div",zv,[p("div",Nv,[p("div",Fv,[dt(ft,{name:"step"}),w[45]||(w[45]=p("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=b=>B.$emit("toggleElemClick"))},null,40,jv),w[47]||(w[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,Hv)]),t.elemClick?(nt(),st("div",Uv,[(nt(),st(Kt,null,xe(["+1","1","2","hide"],b=>p("button",{key:b,class:At(["spm-chip",{active:t.elemClick===b}]),onClick:W=>B.$emit("update:elemClick",b)},xt(b==="+1"?"顺延 (+1)":b==="hide"?"隐藏 (hide)":"第 "+b+" 步"),11,Wv)),64))])):t.parentElemClick?(nt(),st("div",Vv,[dt(ft,{name:"check"}),w[48]||(w[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Pt("",!0)]),p("div",qv,[p("div",Kv,[p("div",Gv,[p("div",Zv,[dt(ft,{name:"motion"}),w[49]||(w[49]=p("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:d.value,onChange:k},null,40,Jv),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,Yv)]),d.value?(nt(),st("div",Xv,[(nt(),st(Kt,null,xe(f,b=>p("button",{key:b.value,class:At(["spm-chip",{active:y.value===b.value}]),onClick:W=>x(b.value)},xt(b.label),11,Qv)),64))])):Pt("",!0),d.value?(nt(),st("div",tb,[p("div",eb,[p("span",null,"时长: "+xt(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+xt(g.value?g.value+"ms":"0ms"),1)]),p("div",ib,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:w[12]||(w[12]=b=>I(Number(b.target.value)))},[...w[52]||(w[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,nb),p("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:w[13]||(w[13]=b=>T(Number(b.target.value)))},[...w[53]||(w[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,ob)])])):Pt("",!0)]),o.value||t.elemSlot?(nt(),st("div",sb,[p("div",rb,[p("div",lb,[p("div",ab,[dt(ft,{name:"columns"}),p("span",null,xt(l.value),1)]),p("span",cb,xt(r.value),1)])]),p("div",db,[(nt(!0),st(Kt,null,xe(a.value,b=>(nt(),st("button",{key:b.value,class:At(["spm-segmented-item",{active:c(b.value)}]),onClick:W=>B.$emit("update:elemSlot",b.value)},xt(b.label),11,ub))),128))])])):Pt("",!0),t.isCodeBlock?(nt(),st("div",fb,[p("div",pb,[p("div",hb,[p("div",mb,[dt(ft,{name:"code"}),w[54]||(w[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",gb,[(nt(),st(Kt,null,xe(["1-3","all","1|2|3","2-5"],b=>p("button",{key:b,class:At(["spm-chip",{active:t.elemShikiLines===b}]),onClick:W=>B.$emit("update:elemShikiLines",b)},xt(b),11,vb)),64)),t.elemShikiLines?(nt(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=b=>B.$emit("update:elemShikiLines",""))}," 清空 ")):Pt("",!0)]),p("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=b=>B.$emit("update:elemShikiLines",b.target.value)),onChange:w[16]||(w[16]=b=>B.$emit("update:elemShikiLines",b.target.value))},null,40,bb)])):Pt("",!0),t.isCodeBlock?(nt(),st("div",yb,[p("div",kb,[p("div",wb,[p("div",xb,[dt(ft,{name:"code"}),w[56]||(w[56]=p("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",_b,[(nt(),st(Kt,null,xe(["240px","320px","400px","50vh"],b=>p("button",{key:b,class:At(["spm-chip",{active:t.elemMaxHeight===b}]),onClick:W=>B.$emit("update:elemMaxHeight",b)},xt(b),11,Sb)),64)),t.elemMaxHeight?(nt(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=b=>B.$emit("update:elemMaxHeight",""))}," 自适应 ")):Pt("",!0)]),p("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=b=>B.$emit("update:elemMaxHeight",b.target.value)),onChange:w[19]||(w[19]=b=>B.$emit("update:elemMaxHeight",b.target.value))},null,40,Cb)])):Pt("",!0),p("div",$b,[w[61]||(w[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",Ib,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=b=>B.$emit("insertDividerBefore"))},[dt(ft,{name:"insert-above"}),w[58]||(w[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=b=>B.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),w[59]||(w[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=b=>B.$emit("setTwoColsContrast"))},[dt(ft,{name:"columns"}),p("span",null,xt(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Ab),t.hasBlockAttrs?(nt(),st("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=b=>B.$emit("clearBlockAttrs"))},[dt(ft,{name:"broom"}),w[60]||(w[60]=p("span",null,"清除属性",-1))])):Pt("",!0)])])])}}}),Tb={class:"spm-section spm-section--doc"},Eb={class:"spm-card-control"},Mb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Rb={class:"spm-segmented-group"},Pb=["aria-label","onClick"],Ob={class:"spm-card-control"},zb={class:"spm-control-header"},Nb={class:"spm-control-title-group"},Fb={class:"spm-control-title"},Hb={class:"spm-segmented-group"},jb={class:"spm-card-control"},Ub={class:"spm-control-header"},Wb={class:"spm-control-title-group"},Vb={class:"spm-control-title"},qb={class:"spm-segmented-group"},Kb={class:"spm-card-control"},Gb={class:"spm-control-header"},Zb={class:"spm-control-title-group"},Yb={class:"spm-control-title"},Jb={class:"spm-card-control"},Xb={class:"spm-control-header"},Qb={class:"spm-control-title-group"},t1={class:"spm-control-title"},e1=["aria-label"],i1=["checked"],n1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},o1=["value"],s1={class:"spm-card-control"},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title"},c1=["aria-label"],d1=["checked"],u1={class:"spm-card-control"},f1={class:"spm-action-grid"},p1=Ce({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const e=ti("plugin"),i=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ti({enableWebServeJump:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ti({normalizeHeadingSizes:a}),e&&typeof e.saveGlobalSettings=="function"&&await e.saveGlobalSettings({normalizeHeadingSizes:a}),e&&typeof e.compileCurrentDocument=="function"&&e.compileCurrentDocument(e.currentDocId||((c=e.getActiveDocumentId)==null?void 0:c.call(e)))}function l(a){Ti({webServeUrl:a})}function r(a){Ti({webServeUrl:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(nt(),st("div",Tb,[c[39]||(c[39]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",Eb,[p("div",Mb,[p("div",Db,[p("div",Lb,[dt(ft,{name:"palette"}),c[18]||(c[18]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",Rb,[(nt(),st(Kt,null,xe(n,u=>p("button",{key:u.value,class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:f=>a.$emit("update:docTheme",u.value)},xt(u.label),11,Pb)),64))])]),p("div",Ob,[p("div",zb,[p("div",Nb,[p("div",Fb,[dt(ft,{name:"ratio"}),c[20]||(c[20]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",Hb,[p("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",jb,[p("div",Ub,[p("div",Wb,[p("div",Vb,[dt(ft,{name:"ratio"}),c[22]||(c[22]=p("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",qb,[p("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",Kb,[p("div",Gb,[p("div",Zb,[p("div",Yb,[dt(ft,{name:"transition"}),c[24]||(c[24]=p("span",null,"全局默认转场",-1))]),c[25]||(c[25]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),dt(Vs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),p("div",Jb,[p("div",Xb,[p("div",Qb,[p("div",t1,[dt(ft,{name:"external-link"}),c[26]||(c[26]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:bt(i).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,i1),c[28]||(c[28]=p("span",{class:"spm-switch-slider"},null,-1))],8,e1)]),bt(i).enableWebServeJump?(nt(),st("div",n1,[p("input",{value:bt(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,o1),c[29]||(c[29]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Pt("",!0)]),p("div",s1,[p("div",r1,[p("div",l1,[p("div",a1,[dt(ft,{name:"type"}),c[30]||(c[30]=p("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:bt(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,d1),c[32]||(c[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,c1)])]),p("div",u1,[c[38]||(c[38]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",f1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[dt(ft,{name:"split-preview"}),c[33]||(c[33]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[dt(ft,{name:"presenter"}),c[34]||(c[34]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[dt(ft,{name:"sparkles"}),c[35]||(c[35]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[dt(ft,{name:"export-html"}),c[36]||(c[36]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[dt(ft,{name:"export-pdf"}),c[37]||(c[37]=p("span",null,"导出 PDF",-1))])])])]))}});var Gn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function h1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Zn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Xo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Or;function m1(){return Or||(Or=1,(function(t,e){(function(i){t.exports=i()})(function(){return(function i(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var f=typeof Zn=="function"&&Zn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(y){var m=n[c][1][y];return l(m||y)},d,d.exports,i,n,o,s)}return o[c].exports}for(var r=typeof Zn=="function"&&Zn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,f,v,d,y,m,g=[],k=0,x=a.length,I=x,T=s.getTypeOf(a)!=="string";k<a.length;)I=x-k,f=T?(c=a[k++],u=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),u=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),v=c>>2,d=(3&c)<<4|u>>4,y=1<I?(15&u)<<2|f>>6:64,m=2<I?63&f:64,g.push(r.charAt(v)+r.charAt(d)+r.charAt(y)+r.charAt(m));return g.join("")},o.decode=function(a){var c,u,f,v,d,y,m=0,g=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,I=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&I--,a.charAt(a.length-2)===r.charAt(64)&&I--,I%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|I):new Array(0|I);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(v=r.indexOf(a.charAt(m++)))>>4,u=(15&v)<<4|(d=r.indexOf(a.charAt(m++)))>>2,f=(3&d)<<6|(y=r.indexOf(a.charAt(m++))),x[g++]=c,d!==64&&(x[g++]=u),y!==64&&(x[g++]=f);return x}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(u,f,v,d,y){this.compressedSize=u,this.uncompressedSize=f,this.crc32=v,this.compression=d,this.compressedContent=y}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,v){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(f.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,f,v){var d=l,y=v+f;c^=-1;for(var m=v;m<y;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|a,r,r.length,0):(function(c,u,f,v){var d=l,y=v+f;c^=-1;for(var m=v;m<y;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function u(f,v){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(v){f.push({data:v,meta:f.meta})}},o.compressWorker=function(f){return new u("Deflate",f)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(d,y){var m,g="";for(m=0;m<y;m++)g+=String.fromCharCode(255&d),d>>>=8;return g}function l(d,y,m,g,k,x){var I,T,E=d.file,B=d.compression,w=x!==c.utf8encode,H=r.transformTo("string",x(E.name)),j=r.transformTo("string",c.utf8encode(E.name)),O=E.comment,q=r.transformTo("string",x(O)),S=r.transformTo("string",c.utf8encode(O)),D=j.length!==E.name.length,b=S.length!==O.length,W="",Y="",L="",U=E.dir,V=E.date,et={crc32:0,compressedSize:0,uncompressedSize:0};y&&!m||(et.crc32=d.crc32,et.compressedSize=d.compressedSize,et.uncompressedSize=d.uncompressedSize);var A=0;y&&(A|=8),w||!D&&!b||(A|=2048);var M=0,X=0;U&&(M|=16),k==="UNIX"?(X=798,M|=(function(Q,tt){var pt=Q;return Q||(pt=tt?16893:33204),(65535&pt)<<16})(E.unixPermissions,U)):(X=20,M|=(function(Q){return 63&(Q||0)})(E.dosPermissions)),I=V.getUTCHours(),I<<=6,I|=V.getUTCMinutes(),I<<=5,I|=V.getUTCSeconds()/2,T=V.getUTCFullYear()-1980,T<<=4,T|=V.getUTCMonth()+1,T<<=5,T|=V.getUTCDate(),D&&(Y=s(1,1)+s(u(H),4)+j,W+="up"+s(Y.length,2)+Y),b&&(L=s(1,1)+s(u(q),4)+S,W+="uc"+s(L.length,2)+L);var J="";return J+=`
\0`,J+=s(A,2),J+=B.magic,J+=s(I,2),J+=s(T,2),J+=s(et.crc32,4),J+=s(et.compressedSize,4),J+=s(et.uncompressedSize,4),J+=s(H.length,2),J+=s(W.length,2),{fileRecord:f.LOCAL_FILE_HEADER+J+H+W,dirRecord:f.CENTRAL_FILE_HEADER+s(X,2)+J+s(q.length,2)+"\0\0\0\0"+s(M,4)+s(g,4)+H+W+q}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),f=i("../signature");function v(d,y,m,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=y,this.zipPlatform=m,this.encodeFileName=g,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(d){var y=d.meta.percent||0,m=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(y+100*(m-g-1))/m:100}}))},v.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var y=this.streamFiles&&!d.file.dir;if(y){var m=l(d,y,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(d){this.accumulate=!1;var y=this.streamFiles&&!d.file.dir,m=l(d,y,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),y)this.push({data:(function(g){return f.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var d=this.bytesWritten,y=0;y<this.dirRecords.length;y++)this.push({data:this.dirRecords[y],meta:{percent:100}});var m=this.bytesWritten-d,g=(function(k,x,I,T,E){var B=r.transformTo("string",E(T));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s(I,4)+s(B.length,2)+B})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(d){this._sources.push(d);var y=this;return d.on("data",function(m){y.processChunk(m)}),d.on("end",function(){y.closedSource(y.previous.streamInfo),y._sources.length?y.prepareNextSource():y.end()}),d.on("error",function(m){y.error(m)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(d){var y=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var m=0;m<y.length;m++)try{y[m].error(d)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,y=0;y<d.length;y++)d[y].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{r.forEach(function(v,d){f++;var y=(function(x,I){var T=x||I,E=s[T];if(!E)throw new Error(T+" is not a valid compression method !");return E})(d.options.compression,a.compression),m=d.options.compressionOptions||a.compressionOptions||{},g=d.dir,k=d.date;d._compressWorker(y,m).withStreamInfo("file",{name:v,dir:g,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(v){u.error(v)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function f(v){return new l.Promise(function(d,y){var m=v.decompressed.getContentWorker().pipe(new c);m.on("error",function(g){y(g)}).on("end",function(){m.streamInfo.crc32!==v.decompressed.crc32?y(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(v,d){var y=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,d.optimizedBinaryString,d.base64).then(function(m){var g=new a(d);return g.load(m),g}).then(function(m){var g=[l.Promise.resolve(m)],k=m.files;if(d.checkCRC32)for(var x=0;x<k.length;x++)g.push(f(k[x]));return l.Promise.all(g)}).then(function(m){for(var g=m.shift(),k=g.files,x=0;x<k.length;x++){var I=k[x],T=I.fileNameStr,E=s.resolve(I.fileNameStr);y.file(E,I.decompressed,{binary:!0,optimizedBinaryString:!0,date:I.date,dir:I.dir,comment:I.fileCommentStr.length?I.fileCommentStr:null,unixPermissions:I.unixPermissions,dosPermissions:I.dosPermissions,createFolders:d.createFolders}),I.dir||(y.file(E).unsafeOriginalName=T)}return g.zipComment.length&&(y.comment=g.zipComment),y})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(f,v){u.push(f)||u._helper.pause(),c&&c(v)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(E,B,w){var H,j=r.getTypeOf(B),O=r.extend(w||{},u);O.date=O.date||new Date,O.compression!==null&&(O.compression=O.compression.toUpperCase()),typeof O.unixPermissions=="string"&&(O.unixPermissions=parseInt(O.unixPermissions,8)),O.unixPermissions&&16384&O.unixPermissions&&(O.dir=!0),O.dosPermissions&&16&O.dosPermissions&&(O.dir=!0),O.dir&&(E=k(E)),O.createFolders&&(H=g(E))&&x.call(this,H,!0);var q=j==="string"&&O.binary===!1&&O.base64===!1;w&&w.binary!==void 0||(O.binary=!q),(B instanceof f&&B.uncompressedSize===0||O.dir||!B||B.length===0)&&(O.base64=!1,O.binary=!0,B="",O.compression="STORE",j="string");var S=null;S=B instanceof f||B instanceof a?B:y.isNode&&y.isStream(B)?new m(E,B):r.prepareContent(E,B,O.binary,O.optimizedBinaryString,O.base64);var D=new v(E,S,O);this.files[E]=D}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),f=i("./compressedObject"),v=i("./zipObject"),d=i("./generate"),y=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),g=function(E){E.slice(-1)==="/"&&(E=E.substring(0,E.length-1));var B=E.lastIndexOf("/");return 0<B?E.substring(0,B):""},k=function(E){return E.slice(-1)!=="/"&&(E+="/"),E},x=function(E,B){return B=B!==void 0?B:u.createFolders,E=k(E),this.files[E]||s.call(this,E,null,{dir:!0,createFolders:B}),this.files[E]};function I(E){return Object.prototype.toString.call(E)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(E){var B,w,H;for(B in this.files)H=this.files[B],(w=B.slice(this.root.length,B.length))&&B.slice(0,this.root.length)===this.root&&E(w,H)},filter:function(E){var B=[];return this.forEach(function(w,H){E(w,H)&&B.push(H)}),B},file:function(E,B,w){if(arguments.length!==1)return E=this.root+E,s.call(this,E,B,w),this;if(I(E)){var H=E;return this.filter(function(O,q){return!q.dir&&H.test(O)})}var j=this.files[this.root+E];return j&&!j.dir?j:null},folder:function(E){if(!E)return this;if(I(E))return this.filter(function(j,O){return O.dir&&E.test(j)});var B=this.root+E,w=x.call(this,B),H=this.clone();return H.root=w.name,H},remove:function(E){E=this.root+E;var B=this.files[E];if(B||(E.slice(-1)!=="/"&&(E+="/"),B=this.files[E]),B&&!B.dir)delete this.files[E];else for(var w=this.filter(function(j,O){return O.name.slice(0,E.length)===E}),H=0;H<w.length;H++)delete this.files[w[H].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(E){var B,w={};try{if((w=r.extend(E||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var H=w.comment||this.comment||"";B=d.generateWorker(this,w,H)}catch(j){(B=new a("error")).error(j)}return new c(B,w.type||"string",w.mimeType)},generateAsync:function(E,B){return this.generateInternalStream(E).accumulate(B)},generateNodeStream:function(E,B){return(E=E||{}).type||(E.type="nodebuffer"),this.generateInternalStream(E).toNodejsStream(B)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===u&&this.data[v+3]===f)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&u===v[2]&&f===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(f){var v=s.getTypeOf(f);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(f):l.uint8array?new u(s.transformTo("uint8array",f)):new r(s.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),u=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(y,m){return new u.Promise(function(g,k){var x=[],I=y._internalType,T=y._outputType,E=y._mimeType;y.on("data",function(B,w){x.push(B),m&&m(w)}).on("error",function(B){x=[],k(B)}).on("end",function(){try{var B=(function(w,H,j){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",H),j);case"base64":return a.encode(H);default:return s.transformTo(w,H)}})(T,(function(w,H){var j,O=0,q=null,S=0;for(j=0;j<H.length;j++)S+=H[j].length;switch(w){case"string":return H.join("");case"array":return Array.prototype.concat.apply([],H);case"uint8array":for(q=new Uint8Array(S),j=0;j<H.length;j++)q.set(H[j],O),O+=H[j].length;return q;case"nodebuffer":return Buffer.concat(H);default:throw new Error("concat : unsupported type '"+w+"'")}})(I,x),E);g(B)}catch(w){k(w)}x=[]}).resume()})}function d(y,m,g){var k=m;switch(m){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=m,this._mimeType=g,s.checkSupport(k),this._worker=y.pipe(new l(k)),y.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(y){return v(this,y)},on:function(y,m){var g=this;return y==="data"?this._worker.on(y,function(k){m.call(g,k.data,k.meta)}):this._worker.on(y,function(){s.delay(m,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(y){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},y)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(y){var m,g,k,x,I,T=y.length,E=0;for(x=0;x<T;x++)(64512&(g=y.charCodeAt(x)))==55296&&x+1<T&&(64512&(k=y.charCodeAt(x+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),x++),E+=g<128?1:g<2048?2:g<65536?3:4;for(m=l.uint8array?new Uint8Array(E):new Array(E),x=I=0;I<E;x++)(64512&(g=y.charCodeAt(x)))==55296&&x+1<T&&(64512&(k=y.charCodeAt(x+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),x++),g<128?m[I++]=g:(g<2048?m[I++]=192|g>>>6:(g<65536?m[I++]=224|g>>>12:(m[I++]=240|g>>>18,m[I++]=128|g>>>12&63),m[I++]=128|g>>>6&63),m[I++]=128|63&g);return m})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(y){var m,g,k,x,I=y.length,T=new Array(2*I);for(m=g=0;m<I;)if((k=y[m++])<128)T[g++]=k;else if(4<(x=c[k]))T[g++]=65533,m+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&m<I;)k=k<<6|63&y[m++],x--;1<x?T[g++]=65533:k<65536?T[g++]=k:(k-=65536,T[g++]=55296|k>>10&1023,T[g++]=56320|1023&k)}return T.length!==g&&(T.subarray?T=T.subarray(0,g):T.length=g),s.applyFromCharCode(T)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(f,a),f.prototype.processChunk=function(d){var y=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=y;(y=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),y.set(m,this.leftOver.length)}else y=this.leftOver.concat(y);this.leftOver=null}var g=(function(x,I){var T;for((I=I||x.length)>x.length&&(I=x.length),T=I-1;0<=T&&(192&x[T])==128;)T--;return T<0||T===0?I:T+c[x[T]]>I?T:I})(y),k=y;g!==y.length&&(l.uint8array?(k=y.subarray(0,g),this.leftOver=y.subarray(g,y.length)):(k=y.slice(0,g),this.leftOver=y.slice(g,y.length))),this.push({data:o.utf8decode(k),meta:d.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=f,s.inherits(v,a),v.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(m){return m}function u(m,g){for(var k=0;k<m.length;++k)g[k]=255&m.charCodeAt(k);return g}i("setimmediate"),o.newBlob=function(m,g){o.checkSupport("blob");try{return new Blob([m],{type:g})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(m),k.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,g,k){var x=[],I=0,T=m.length;if(T<=k)return String.fromCharCode.apply(null,m);for(;I<T;)g==="array"||g==="nodebuffer"?x.push(String.fromCharCode.apply(null,m.slice(I,Math.min(I+k,T)))):x.push(String.fromCharCode.apply(null,m.subarray(I,Math.min(I+k,T)))),I+=k;return x.join("")},stringifyByChar:function(m){for(var g="",k=0;k<m.length;k++)g+=String.fromCharCode(m[k]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(m){var g=65536,k=o.getTypeOf(m),x=!0;if(k==="uint8array"?x=f.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=f.applyCanBeUsed.nodebuffer),x)for(;1<g;)try{return f.stringifyByChunk(m,k,g)}catch{g=Math.floor(g/2)}return f.stringifyByChar(m)}function d(m,g){for(var k=0;k<m.length;k++)g[k]=m[k];return g}o.applyFromCharCode=v;var y={};y.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return y.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},y.array={string:v,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},y.arraybuffer={string:function(m){return v(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},y.uint8array={string:v,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},y.nodebuffer={string:v,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return y.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},o.transformTo=function(m,g){if(g=g||"",!m)return g;o.checkSupport(m);var k=o.getTypeOf(g);return y[k][m](g)},o.resolve=function(m){for(var g=m.split("/"),k=[],x=0;x<g.length;x++){var I=g[x];I==="."||I===""&&x!==0&&x!==g.length-1||(I===".."?k.pop():k.push(I))}return k.join("/")},o.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(m){var g,k,x="";for(k=0;k<(m||"").length;k++)x+="\\x"+((g=m.charCodeAt(k))<16?"0":"")+g.toString(16).toUpperCase();return x},o.delay=function(m,g,k){setImmediate(function(){m.apply(k||null,g||[])})},o.inherits=function(m,g){function k(){}k.prototype=g.prototype,m.prototype=new k},o.extend=function(){var m,g,k={};for(m=0;m<arguments.length;m++)for(g in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],g)&&k[g]===void 0&&(k[g]=arguments[m][g]);return k},o.prepareContent=function(m,g,k,x,I){return a.Promise.resolve(g).then(function(T){return s.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(E,B){var w=new FileReader;w.onload=function(H){E(H.target.result)},w.onerror=function(H){B(H.target.error)},w.readAsArrayBuffer(T)}):T}).then(function(T){var E=o.getTypeOf(T);return E?(E==="arraybuffer"?T=o.transformTo("uint8array",T):E==="string"&&(I?T=l.decode(T):k&&x!==!0&&(T=(function(B){return u(B,s.uint8array?new Uint8Array(B.length):new Array(B.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(f)+")")}},isSignature:function(f,v){var d=this.reader.index;this.reader.setIndex(f);var y=this.reader.readString(4)===v;return this.reader.setIndex(d),y},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",d=l.transformTo(v,f);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,v,d,y=this.zip64EndOfCentralSize-44;0<y;)f=this.reader.readInt(2),v=this.reader.readInt(4),d=this.reader.readData(v),this.zip64ExtensibleData[f]={id:f,length:v,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,v;for(f=0;f<this.files.length;f++)v=this.files[f],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var v=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var y=v-d;if(0<y)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=y);else if(y<0)throw new Error("Corrupted zip: missing "+Math.abs(y)+" bytes.")},prepareReader:function(f){this.reader=s(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),u=i("./compressions"),f=i("./support");function v(d,y){this.options=d,this.loadOptions=y}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var y,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((y=(function(g){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===g)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,y,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var y=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(y),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var y,m,g,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)y=d.readInt(2),m=d.readInt(2),g=d.readData(m),this.extraFields[y]={id:y,length:m,value:g};d.setIndex(k)},handleUTF8:function(){var d=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var y=this.findExtraFieldUnicodePath();if(y!==null)this.fileNameStr=y;else{var m=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var y=s(d.value);return y.readInt(1)!==1||a(this.fileName)!==y.readInt(4)?null:c.utf8decode(y.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var y=s(d.value);return y.readInt(1)!==1||a(this.fileComment)!==y.readInt(4)?null:c.utf8decode(y.readData(d.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(y,m,g){this.name=y,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=m,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");s.prototype={internalStream:function(y){var m=null,g="string";try{if(!y)throw new Error("No output type specified.");var k=(g=y.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),m=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(m=m.pipe(new a.Utf8EncodeWorker)),!x&&k&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(I){(m=new u("error")).error(I)}return new l(m,g,"")},async:function(y,m){return this.internalStream(y).accumulate(m)},nodeStream:function(y,m){return this.internalStream(y||"nodebuffer").toNodejsStream(m)},_compressWorker:function(y,m){if(this._data instanceof c&&this._data.compression.magic===y.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,y,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<f.length;d++)s.prototype[f[d]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(y),f=s.document.createTextNode("");u.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){y(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(y,0)};else{var v=new s.MessageChannel;v.port1.onmessage=y,l=function(){v.port2.postMessage(0)}}var d=[];function y(){var m,g;r=!0;for(var k=d.length;k;){for(g=d,d=[],m=-1;++m<k;)g[m]();k=d.length}r=!1}n.exports=function(m){d.push(m)!==1||r||l()}}).call(this,typeof Gn<"u"?Gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&m(this,k)}function v(k,x,I){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof I=="function"&&(this.onRejected=I,this.callRejected=this.otherCallRejected)}function d(k,x,I){s(function(){var T;try{T=x(I)}catch(E){return r.reject(k,E)}T===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,T)})}function y(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function m(k,x){var I=!1;function T(w){I||(I=!0,r.reject(k,w))}function E(w){I||(I=!0,r.resolve(k,w))}var B=g(function(){x(E,T)});B.status==="error"&&T(B.value)}function g(k,x){var I={};try{I.value=k(x),I.status="success"}catch(T){I.status="error",I.value=T}return I}(n.exports=f).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function(I){return x.resolve(k()).then(function(){return I})},function(I){return x.resolve(k()).then(function(){throw I})})},f.prototype.catch=function(k){return this.then(null,k)},f.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var I=new this.constructor(l);return this.state!==u?d(I,this.state===c?k:x,this.outcome):this.queue.push(new v(I,k,x)),I},v.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},v.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},v.prototype.callRejected=function(k){r.reject(this.promise,k)},v.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,x){var I=g(y,x);if(I.status==="error")return r.reject(k,I.value);var T=I.value;if(T)m(k,T);else{k.state=c,k.outcome=x;for(var E=-1,B=k.queue.length;++E<B;)k.queue[E].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var I=-1,T=k.queue.length;++I<T;)k.queue[I].callRejected(x);return k},f.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},f.reject=function(k){var x=new this(l);return r.reject(x,k)},f.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var I=k.length,T=!1;if(!I)return this.resolve([]);for(var E=new Array(I),B=0,w=-1,H=new this(l);++w<I;)j(k[w],w);return H;function j(O,q){x.resolve(O).then(function(S){E[q]=S,++B!==I||T||(T=!0,r.resolve(H,E))},function(S){T||(T=!0,r.reject(H,S))})}},f.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var I=k.length,T=!1;if(!I)return this.resolve([]);for(var E=-1,B=new this(l);++E<I;)w=k[E],x.resolve(w).then(function(H){T||(T=!0,r.resolve(B,H))},function(H){T||(T=!0,r.reject(B,H))});var w;return B}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,f=0,v=-1,d=0,y=8;function m(k){if(!(this instanceof m))return new m(k);this.options=l.assign({level:v,method:y,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var I=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(I!==f)throw new Error(a[I]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var T;if(T=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(I=s.deflateSetDictionary(this.strm,T))!==f)throw new Error(a[I]);this._dict_set=!0}}function g(k,x){var I=new m(x);if(I.push(k,!0),I.err)throw I.msg||a[I.err];return I.result}m.prototype.push=function(k,x){var I,T,E=this.strm,B=this.options.chunkSize;if(this.ended)return!1;T=x===~~x?x:x===!0?4:0,typeof k=="string"?E.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?E.input=new Uint8Array(k):E.input=k,E.next_in=0,E.avail_in=E.input.length;do{if(E.avail_out===0&&(E.output=new l.Buf8(B),E.next_out=0,E.avail_out=B),(I=s.deflate(E,T))!==1&&I!==f)return this.onEnd(I),!(this.ended=!0);E.avail_out!==0&&(E.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(E.output,E.next_out))):this.onData(l.shrinkBuf(E.output,E.next_out)))}while((0<E.avail_in||E.avail_out===0)&&I!==1);return T===4?(I=s.deflateEnd(this.strm),this.onEnd(I),this.ended=!0,I===f):T!==2||(this.onEnd(f),!(E.avail_out=0))},m.prototype.onData=function(k){this.chunks.push(k)},m.prototype.onEnd=function(k){k===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=m,o.deflate=g,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,g(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,g(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),f=i("./zlib/gzheader"),v=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||m&&m.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,g.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new f,s.inflateGetHeader(this.strm,this.header)}function y(m,g){var k=new d(g);if(k.push(m,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(m,g){var k,x,I,T,E,B,w=this.strm,H=this.options.chunkSize,j=this.options.dictionary,O=!1;if(this.ended)return!1;x=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?w.input=r.binstring2buf(m):v.call(m)==="[object ArrayBuffer]"?w.input=new Uint8Array(m):w.input=m,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(H),w.next_out=0,w.avail_out=H),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&j&&(B=typeof j=="string"?r.string2buf(j):v.call(j)==="[object ArrayBuffer]"?new Uint8Array(j):j,k=s.inflateSetDictionary(this.strm,B)),k===a.Z_BUF_ERROR&&O===!0&&(k=a.Z_OK,O=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(I=r.utf8border(w.output,w.next_out),T=w.next_out-I,E=r.buf2string(w.output,I),w.next_out=T,w.avail_out=H-T,T&&l.arraySet(w.output,w.output,I,T,0),this.onData(E)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(O=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},o.Inflate=d,o.inflate=y,o.inflateRaw=function(m,g){return(g=g||{}).raw=!0,y(m,g)},o.ungzip=y},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(a[f]=u[f])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,f,v){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+f),v);else for(var d=0;d<f;d++)a[v+d]=c[u+d]},flattenChunks:function(a){var c,u,f,v,d,y;for(c=f=0,u=a.length;c<u;c++)f+=a[c].length;for(y=new Uint8Array(f),c=v=0,u=a.length;c<u;c++)d=a[c],y.set(d,v),v+=d.length;return y}},r={arraySet:function(a,c,u,f,v){for(var d=0;d<f;d++)a[v+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,v){if(v<65537&&(f.subarray&&r||!f.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(f,v));for(var d="",y=0;y<v;y++)d+=String.fromCharCode(f[y]);return d}a[254]=a[254]=1,o.string2buf=function(f){var v,d,y,m,g,k=f.length,x=0;for(m=0;m<k;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<k&&(64512&(y=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(y-56320),m++),x+=d<128?1:d<2048?2:d<65536?3:4;for(v=new s.Buf8(x),m=g=0;g<x;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<k&&(64512&(y=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(y-56320),m++),d<128?v[g++]=d:(d<2048?v[g++]=192|d>>>6:(d<65536?v[g++]=224|d>>>12:(v[g++]=240|d>>>18,v[g++]=128|d>>>12&63),v[g++]=128|d>>>6&63),v[g++]=128|63&d);return v},o.buf2binstring=function(f){return u(f,f.length)},o.binstring2buf=function(f){for(var v=new s.Buf8(f.length),d=0,y=v.length;d<y;d++)v[d]=f.charCodeAt(d);return v},o.buf2string=function(f,v){var d,y,m,g,k=v||f.length,x=new Array(2*k);for(d=y=0;d<k;)if((m=f[d++])<128)x[y++]=m;else if(4<(g=a[m]))x[y++]=65533,d+=g-1;else{for(m&=g===2?31:g===3?15:7;1<g&&d<k;)m=m<<6|63&f[d++],g--;1<g?x[y++]=65533:m<65536?x[y++]=m:(m-=65536,x[y++]=55296|m>>10&1023,x[y++]=56320|1023&m)}return u(x,y)},o.utf8border=function(f,v){var d;for((v=v||f.length)>f.length&&(v=f.length),d=v-1;0<=d&&(192&f[d])==128;)d--;return d<0||d===0?v:d+a[f[d]]>v?d:v}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,f=c+a;l^=-1;for(var v=c;v<f;v++)l=l>>>8^u[255&(l^r[v])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),u=i("./messages"),f=0,v=4,d=0,y=-2,m=-1,g=4,k=2,x=8,I=9,T=286,E=30,B=19,w=2*T+1,H=15,j=3,O=258,q=O+j+1,S=42,D=113,b=1,W=2,Y=3,L=4;function U(h,z){return h.msg=u[z],z}function V(h){return(h<<1)-(4<h?9:0)}function et(h){for(var z=h.length;0<=--z;)h[z]=0}function A(h){var z=h.state,N=z.pending;N>h.avail_out&&(N=h.avail_out),N!==0&&(l.arraySet(h.output,z.pending_buf,z.pending_out,N,h.next_out),h.next_out+=N,z.pending_out+=N,h.total_out+=N,h.avail_out-=N,z.pending-=N,z.pending===0&&(z.pending_out=0))}function M(h,z){r._tr_flush_block(h,0<=h.block_start?h.block_start:-1,h.strstart-h.block_start,z),h.block_start=h.strstart,A(h.strm)}function X(h,z){h.pending_buf[h.pending++]=z}function J(h,z){h.pending_buf[h.pending++]=z>>>8&255,h.pending_buf[h.pending++]=255&z}function Q(h,z){var N,_,$=h.max_chain_length,R=h.strstart,Z=h.prev_length,G=h.nice_match,K=h.strstart>h.w_size-q?h.strstart-(h.w_size-q):0,it=h.window,ct=h.w_mask,rt=h.prev,mt=h.strstart+O,_t=it[R+Z-1],wt=it[R+Z];h.prev_length>=h.good_match&&($>>=2),G>h.lookahead&&(G=h.lookahead);do if(it[(N=z)+Z]===wt&&it[N+Z-1]===_t&&it[N]===it[R]&&it[++N]===it[R+1]){R+=2,N++;do;while(it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&it[++R]===it[++N]&&R<mt);if(_=O-(mt-R),R=mt-O,Z<_){if(h.match_start=z,G<=(Z=_))break;_t=it[R+Z-1],wt=it[R+Z]}}while((z=rt[z&ct])>K&&--$!=0);return Z<=h.lookahead?Z:h.lookahead}function tt(h){var z,N,_,$,R,Z,G,K,it,ct,rt=h.w_size;do{if($=h.window_size-h.lookahead-h.strstart,h.strstart>=rt+(rt-q)){for(l.arraySet(h.window,h.window,rt,rt,0),h.match_start-=rt,h.strstart-=rt,h.block_start-=rt,z=N=h.hash_size;_=h.head[--z],h.head[z]=rt<=_?_-rt:0,--N;);for(z=N=rt;_=h.prev[--z],h.prev[z]=rt<=_?_-rt:0,--N;);$+=rt}if(h.strm.avail_in===0)break;if(Z=h.strm,G=h.window,K=h.strstart+h.lookahead,it=$,ct=void 0,ct=Z.avail_in,it<ct&&(ct=it),N=ct===0?0:(Z.avail_in-=ct,l.arraySet(G,Z.input,Z.next_in,ct,K),Z.state.wrap===1?Z.adler=a(Z.adler,G,ct,K):Z.state.wrap===2&&(Z.adler=c(Z.adler,G,ct,K)),Z.next_in+=ct,Z.total_in+=ct,ct),h.lookahead+=N,h.lookahead+h.insert>=j)for(R=h.strstart-h.insert,h.ins_h=h.window[R],h.ins_h=(h.ins_h<<h.hash_shift^h.window[R+1])&h.hash_mask;h.insert&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[R+j-1])&h.hash_mask,h.prev[R&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=R,R++,h.insert--,!(h.lookahead+h.insert<j)););}while(h.lookahead<q&&h.strm.avail_in!==0)}function pt(h,z){for(var N,_;;){if(h.lookahead<q){if(tt(h),h.lookahead<q&&z===f)return b;if(h.lookahead===0)break}if(N=0,h.lookahead>=j&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+j-1])&h.hash_mask,N=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),N!==0&&h.strstart-N<=h.w_size-q&&(h.match_length=Q(h,N)),h.match_length>=j)if(_=r._tr_tally(h,h.strstart-h.match_start,h.match_length-j),h.lookahead-=h.match_length,h.match_length<=h.max_lazy_match&&h.lookahead>=j){for(h.match_length--;h.strstart++,h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+j-1])&h.hash_mask,N=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart,--h.match_length!=0;);h.strstart++}else h.strstart+=h.match_length,h.match_length=0,h.ins_h=h.window[h.strstart],h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+1])&h.hash_mask;else _=r._tr_tally(h,0,h.window[h.strstart]),h.lookahead--,h.strstart++;if(_&&(M(h,!1),h.strm.avail_out===0))return b}return h.insert=h.strstart<j-1?h.strstart:j-1,z===v?(M(h,!0),h.strm.avail_out===0?Y:L):h.last_lit&&(M(h,!1),h.strm.avail_out===0)?b:W}function lt(h,z){for(var N,_,$;;){if(h.lookahead<q){if(tt(h),h.lookahead<q&&z===f)return b;if(h.lookahead===0)break}if(N=0,h.lookahead>=j&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+j-1])&h.hash_mask,N=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),h.prev_length=h.match_length,h.prev_match=h.match_start,h.match_length=j-1,N!==0&&h.prev_length<h.max_lazy_match&&h.strstart-N<=h.w_size-q&&(h.match_length=Q(h,N),h.match_length<=5&&(h.strategy===1||h.match_length===j&&4096<h.strstart-h.match_start)&&(h.match_length=j-1)),h.prev_length>=j&&h.match_length<=h.prev_length){for($=h.strstart+h.lookahead-j,_=r._tr_tally(h,h.strstart-1-h.prev_match,h.prev_length-j),h.lookahead-=h.prev_length-1,h.prev_length-=2;++h.strstart<=$&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+j-1])&h.hash_mask,N=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),--h.prev_length!=0;);if(h.match_available=0,h.match_length=j-1,h.strstart++,_&&(M(h,!1),h.strm.avail_out===0))return b}else if(h.match_available){if((_=r._tr_tally(h,0,h.window[h.strstart-1]))&&M(h,!1),h.strstart++,h.lookahead--,h.strm.avail_out===0)return b}else h.match_available=1,h.strstart++,h.lookahead--}return h.match_available&&(_=r._tr_tally(h,0,h.window[h.strstart-1]),h.match_available=0),h.insert=h.strstart<j-1?h.strstart:j-1,z===v?(M(h,!0),h.strm.avail_out===0?Y:L):h.last_lit&&(M(h,!1),h.strm.avail_out===0)?b:W}function F(h,z,N,_,$){this.good_length=h,this.max_lazy=z,this.nice_length=N,this.max_chain=_,this.func=$}function at(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*E+1)),this.bl_tree=new l.Buf16(2*(2*B+1)),et(this.dyn_ltree),et(this.dyn_dtree),et(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(H+1),this.heap=new l.Buf16(2*T+1),et(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),et(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(h){var z;return h&&h.state?(h.total_in=h.total_out=0,h.data_type=k,(z=h.state).pending=0,z.pending_out=0,z.wrap<0&&(z.wrap=-z.wrap),z.status=z.wrap?S:D,h.adler=z.wrap===2?0:1,z.last_flush=f,r._tr_init(z),d):U(h,y)}function C(h){var z=ut(h);return z===d&&(function(N){N.window_size=2*N.w_size,et(N.head),N.max_lazy_match=s[N.level].max_lazy,N.good_match=s[N.level].good_length,N.nice_match=s[N.level].nice_length,N.max_chain_length=s[N.level].max_chain,N.strstart=0,N.block_start=0,N.lookahead=0,N.insert=0,N.match_length=N.prev_length=j-1,N.match_available=0,N.ins_h=0})(h.state),z}function P(h,z,N,_,$,R){if(!h)return y;var Z=1;if(z===m&&(z=6),_<0?(Z=0,_=-_):15<_&&(Z=2,_-=16),$<1||I<$||N!==x||_<8||15<_||z<0||9<z||R<0||g<R)return U(h,y);_===8&&(_=9);var G=new at;return(h.state=G).strm=h,G.wrap=Z,G.gzhead=null,G.w_bits=_,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=$+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+j-1)/j),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<$+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=z,G.strategy=R,G.method=N,C(h)}s=[new F(0,0,0,0,function(h,z){var N=65535;for(N>h.pending_buf_size-5&&(N=h.pending_buf_size-5);;){if(h.lookahead<=1){if(tt(h),h.lookahead===0&&z===f)return b;if(h.lookahead===0)break}h.strstart+=h.lookahead,h.lookahead=0;var _=h.block_start+N;if((h.strstart===0||h.strstart>=_)&&(h.lookahead=h.strstart-_,h.strstart=_,M(h,!1),h.strm.avail_out===0)||h.strstart-h.block_start>=h.w_size-q&&(M(h,!1),h.strm.avail_out===0))return b}return h.insert=0,z===v?(M(h,!0),h.strm.avail_out===0?Y:L):(h.strstart>h.block_start&&(M(h,!1),h.strm.avail_out),b)}),new F(4,4,8,4,pt),new F(4,5,16,8,pt),new F(4,6,32,32,pt),new F(4,4,16,16,lt),new F(8,16,32,32,lt),new F(8,16,128,128,lt),new F(8,32,128,256,lt),new F(32,128,258,1024,lt),new F(32,258,258,4096,lt)],o.deflateInit=function(h,z){return P(h,z,x,15,8,0)},o.deflateInit2=P,o.deflateReset=C,o.deflateResetKeep=ut,o.deflateSetHeader=function(h,z){return h&&h.state?h.state.wrap!==2?y:(h.state.gzhead=z,d):y},o.deflate=function(h,z){var N,_,$,R;if(!h||!h.state||5<z||z<0)return h?U(h,y):y;if(_=h.state,!h.output||!h.input&&h.avail_in!==0||_.status===666&&z!==v)return U(h,h.avail_out===0?-5:y);if(_.strm=h,N=_.last_flush,_.last_flush=z,_.status===S)if(_.wrap===2)h.adler=0,X(_,31),X(_,139),X(_,8),_.gzhead?(X(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),X(_,255&_.gzhead.time),X(_,_.gzhead.time>>8&255),X(_,_.gzhead.time>>16&255),X(_,_.gzhead.time>>24&255),X(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),X(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(X(_,255&_.gzhead.extra.length),X(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(h.adler=c(h.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(X(_,0),X(_,0),X(_,0),X(_,0),X(_,0),X(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),X(_,3),_.status=D);else{var Z=x+(_.w_bits-8<<4)<<8;Z|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(Z|=32),Z+=31-Z%31,_.status=D,J(_,Z),_.strstart!==0&&(J(_,h.adler>>>16),J(_,65535&h.adler)),h.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),A(h),$=_.pending,_.pending!==_.pending_buf_size));)X(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),A(h),$=_.pending,_.pending===_.pending_buf_size)){R=1;break}R=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,X(_,R)}while(R!==0);_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),R===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),A(h),$=_.pending,_.pending===_.pending_buf_size)){R=1;break}R=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,X(_,R)}while(R!==0);_.gzhead.hcrc&&_.pending>$&&(h.adler=c(h.adler,_.pending_buf,_.pending-$,$)),R===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&A(h),_.pending+2<=_.pending_buf_size&&(X(_,255&h.adler),X(_,h.adler>>8&255),h.adler=0,_.status=D)):_.status=D),_.pending!==0){if(A(h),h.avail_out===0)return _.last_flush=-1,d}else if(h.avail_in===0&&V(z)<=V(N)&&z!==v)return U(h,-5);if(_.status===666&&h.avail_in!==0)return U(h,-5);if(h.avail_in!==0||_.lookahead!==0||z!==f&&_.status!==666){var G=_.strategy===2?(function(K,it){for(var ct;;){if(K.lookahead===0&&(tt(K),K.lookahead===0)){if(it===f)return b;break}if(K.match_length=0,ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++,ct&&(M(K,!1),K.strm.avail_out===0))return b}return K.insert=0,it===v?(M(K,!0),K.strm.avail_out===0?Y:L):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?b:W})(_,z):_.strategy===3?(function(K,it){for(var ct,rt,mt,_t,wt=K.window;;){if(K.lookahead<=O){if(tt(K),K.lookahead<=O&&it===f)return b;if(K.lookahead===0)break}if(K.match_length=0,K.lookahead>=j&&0<K.strstart&&(rt=wt[mt=K.strstart-1])===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]){_t=K.strstart+O;do;while(rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&rt===wt[++mt]&&mt<_t);K.match_length=O-(_t-mt),K.match_length>K.lookahead&&(K.match_length=K.lookahead)}if(K.match_length>=j?(ct=r._tr_tally(K,1,K.match_length-j),K.lookahead-=K.match_length,K.strstart+=K.match_length,K.match_length=0):(ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++),ct&&(M(K,!1),K.strm.avail_out===0))return b}return K.insert=0,it===v?(M(K,!0),K.strm.avail_out===0?Y:L):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?b:W})(_,z):s[_.level].func(_,z);if(G!==Y&&G!==L||(_.status=666),G===b||G===Y)return h.avail_out===0&&(_.last_flush=-1),d;if(G===W&&(z===1?r._tr_align(_):z!==5&&(r._tr_stored_block(_,0,0,!1),z===3&&(et(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),A(h),h.avail_out===0))return _.last_flush=-1,d}return z!==v?d:_.wrap<=0?1:(_.wrap===2?(X(_,255&h.adler),X(_,h.adler>>8&255),X(_,h.adler>>16&255),X(_,h.adler>>24&255),X(_,255&h.total_in),X(_,h.total_in>>8&255),X(_,h.total_in>>16&255),X(_,h.total_in>>24&255)):(J(_,h.adler>>>16),J(_,65535&h.adler)),A(h),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?d:1)},o.deflateEnd=function(h){var z;return h&&h.state?(z=h.state.status)!==S&&z!==69&&z!==73&&z!==91&&z!==103&&z!==D&&z!==666?U(h,y):(h.state=null,z===D?U(h,-3):d):y},o.deflateSetDictionary=function(h,z){var N,_,$,R,Z,G,K,it,ct=z.length;if(!h||!h.state||(R=(N=h.state).wrap)===2||R===1&&N.status!==S||N.lookahead)return y;for(R===1&&(h.adler=a(h.adler,z,ct,0)),N.wrap=0,ct>=N.w_size&&(R===0&&(et(N.head),N.strstart=0,N.block_start=0,N.insert=0),it=new l.Buf8(N.w_size),l.arraySet(it,z,ct-N.w_size,N.w_size,0),z=it,ct=N.w_size),Z=h.avail_in,G=h.next_in,K=h.input,h.avail_in=ct,h.next_in=0,h.input=z,tt(N);N.lookahead>=j;){for(_=N.strstart,$=N.lookahead-(j-1);N.ins_h=(N.ins_h<<N.hash_shift^N.window[_+j-1])&N.hash_mask,N.prev[_&N.w_mask]=N.head[N.ins_h],N.head[N.ins_h]=_,_++,--$;);N.strstart=_,N.lookahead=j-1,tt(N)}return N.strstart+=N.lookahead,N.block_start=N.strstart,N.insert=N.lookahead,N.lookahead=0,N.match_length=N.prev_length=j-1,N.match_available=0,h.next_in=G,h.input=K,h.avail_in=Z,N.wrap=R,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,u,f,v,d,y,m,g,k,x,I,T,E,B,w,H,j,O,q,S,D,b,W;r=s.state,a=s.next_in,b=s.input,c=a+(s.avail_in-5),u=s.next_out,W=s.output,f=u-(l-s.avail_out),v=u+(s.avail_out-257),d=r.dmax,y=r.wsize,m=r.whave,g=r.wnext,k=r.window,x=r.hold,I=r.bits,T=r.lencode,E=r.distcode,B=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{I<15&&(x+=b[a++]<<I,I+=8,x+=b[a++]<<I,I+=8),H=T[x&B];e:for(;;){if(x>>>=j=H>>>24,I-=j,(j=H>>>16&255)===0)W[u++]=65535&H;else{if(!(16&j)){if((64&j)==0){H=T[(65535&H)+(x&(1<<j)-1)];continue e}if(32&j){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}O=65535&H,(j&=15)&&(I<j&&(x+=b[a++]<<I,I+=8),O+=x&(1<<j)-1,x>>>=j,I-=j),I<15&&(x+=b[a++]<<I,I+=8,x+=b[a++]<<I,I+=8),H=E[x&w];i:for(;;){if(x>>>=j=H>>>24,I-=j,!(16&(j=H>>>16&255))){if((64&j)==0){H=E[(65535&H)+(x&(1<<j)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(q=65535&H,I<(j&=15)&&(x+=b[a++]<<I,(I+=8)<j&&(x+=b[a++]<<I,I+=8)),d<(q+=x&(1<<j)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=j,I-=j,(j=u-f)<q){if(m<(j=q-j)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(D=k,(S=0)===g){if(S+=y-j,j<O){for(O-=j;W[u++]=k[S++],--j;);S=u-q,D=W}}else if(g<j){if(S+=y+g-j,(j-=g)<O){for(O-=j;W[u++]=k[S++],--j;);if(S=0,g<O){for(O-=j=g;W[u++]=k[S++],--j;);S=u-q,D=W}}}else if(S+=g-j,j<O){for(O-=j;W[u++]=k[S++],--j;);S=u-q,D=W}for(;2<O;)W[u++]=D[S++],W[u++]=D[S++],W[u++]=D[S++],O-=3;O&&(W[u++]=D[S++],1<O&&(W[u++]=D[S++]))}else{for(S=u-q;W[u++]=W[S++],W[u++]=W[S++],W[u++]=W[S++],2<(O-=3););O&&(W[u++]=W[S++],1<O&&(W[u++]=W[S++]))}break}}break}}while(a<c&&u<v);a-=O=I>>3,x&=(1<<(I-=O<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<v?v-u+257:257-(u-v),r.hold=x,r.bits=I}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),u=1,f=2,v=0,d=-2,y=1,m=852,g=592;function k(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function I(S){var D;return S&&S.state?(D=S.state,S.total_in=S.total_out=D.total=0,S.msg="",D.wrap&&(S.adler=1&D.wrap),D.mode=y,D.last=0,D.havedict=0,D.dmax=32768,D.head=null,D.hold=0,D.bits=0,D.lencode=D.lendyn=new s.Buf32(m),D.distcode=D.distdyn=new s.Buf32(g),D.sane=1,D.back=-1,v):d}function T(S){var D;return S&&S.state?((D=S.state).wsize=0,D.whave=0,D.wnext=0,I(S)):d}function E(S,D){var b,W;return S&&S.state?(W=S.state,D<0?(b=0,D=-D):(b=1+(D>>4),D<48&&(D&=15)),D&&(D<8||15<D)?d:(W.window!==null&&W.wbits!==D&&(W.window=null),W.wrap=b,W.wbits=D,T(S))):d}function B(S,D){var b,W;return S?(W=new x,(S.state=W).window=null,(b=E(S,D))!==v&&(S.state=null),b):d}var w,H,j=!0;function O(S){if(j){var D;for(w=new s.Buf32(512),H=new s.Buf32(32),D=0;D<144;)S.lens[D++]=8;for(;D<256;)S.lens[D++]=9;for(;D<280;)S.lens[D++]=7;for(;D<288;)S.lens[D++]=8;for(c(u,S.lens,0,288,w,0,S.work,{bits:9}),D=0;D<32;)S.lens[D++]=5;c(f,S.lens,0,32,H,0,S.work,{bits:5}),j=!1}S.lencode=w,S.lenbits=9,S.distcode=H,S.distbits=5}function q(S,D,b,W){var Y,L=S.state;return L.window===null&&(L.wsize=1<<L.wbits,L.wnext=0,L.whave=0,L.window=new s.Buf8(L.wsize)),W>=L.wsize?(s.arraySet(L.window,D,b-L.wsize,L.wsize,0),L.wnext=0,L.whave=L.wsize):(W<(Y=L.wsize-L.wnext)&&(Y=W),s.arraySet(L.window,D,b-W,Y,L.wnext),(W-=Y)?(s.arraySet(L.window,D,b-W,W,0),L.wnext=W,L.whave=L.wsize):(L.wnext+=Y,L.wnext===L.wsize&&(L.wnext=0),L.whave<L.wsize&&(L.whave+=Y))),0}o.inflateReset=T,o.inflateReset2=E,o.inflateResetKeep=I,o.inflateInit=function(S){return B(S,15)},o.inflateInit2=B,o.inflate=function(S,D){var b,W,Y,L,U,V,et,A,M,X,J,Q,tt,pt,lt,F,at,ut,C,P,h,z,N,_,$=0,R=new s.Buf8(4),Z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return d;(b=S.state).mode===12&&(b.mode=13),U=S.next_out,Y=S.output,et=S.avail_out,L=S.next_in,W=S.input,V=S.avail_in,A=b.hold,M=b.bits,X=V,J=et,z=v;t:for(;;)switch(b.mode){case y:if(b.wrap===0){b.mode=13;break}for(;M<16;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(2&b.wrap&&A===35615){R[b.check=0]=255&A,R[1]=A>>>8&255,b.check=r(b.check,R,2,0),M=A=0,b.mode=2;break}if(b.flags=0,b.head&&(b.head.done=!1),!(1&b.wrap)||(((255&A)<<8)+(A>>8))%31){S.msg="incorrect header check",b.mode=30;break}if((15&A)!=8){S.msg="unknown compression method",b.mode=30;break}if(M-=4,h=8+(15&(A>>>=4)),b.wbits===0)b.wbits=h;else if(h>b.wbits){S.msg="invalid window size",b.mode=30;break}b.dmax=1<<h,S.adler=b.check=1,b.mode=512&A?10:12,M=A=0;break;case 2:for(;M<16;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(b.flags=A,(255&b.flags)!=8){S.msg="unknown compression method",b.mode=30;break}if(57344&b.flags){S.msg="unknown header flags set",b.mode=30;break}b.head&&(b.head.text=A>>8&1),512&b.flags&&(R[0]=255&A,R[1]=A>>>8&255,b.check=r(b.check,R,2,0)),M=A=0,b.mode=3;case 3:for(;M<32;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.head&&(b.head.time=A),512&b.flags&&(R[0]=255&A,R[1]=A>>>8&255,R[2]=A>>>16&255,R[3]=A>>>24&255,b.check=r(b.check,R,4,0)),M=A=0,b.mode=4;case 4:for(;M<16;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.head&&(b.head.xflags=255&A,b.head.os=A>>8),512&b.flags&&(R[0]=255&A,R[1]=A>>>8&255,b.check=r(b.check,R,2,0)),M=A=0,b.mode=5;case 5:if(1024&b.flags){for(;M<16;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.length=A,b.head&&(b.head.extra_len=A),512&b.flags&&(R[0]=255&A,R[1]=A>>>8&255,b.check=r(b.check,R,2,0)),M=A=0}else b.head&&(b.head.extra=null);b.mode=6;case 6:if(1024&b.flags&&(V<(Q=b.length)&&(Q=V),Q&&(b.head&&(h=b.head.extra_len-b.length,b.head.extra||(b.head.extra=new Array(b.head.extra_len)),s.arraySet(b.head.extra,W,L,Q,h)),512&b.flags&&(b.check=r(b.check,W,Q,L)),V-=Q,L+=Q,b.length-=Q),b.length))break t;b.length=0,b.mode=7;case 7:if(2048&b.flags){if(V===0)break t;for(Q=0;h=W[L+Q++],b.head&&h&&b.length<65536&&(b.head.name+=String.fromCharCode(h)),h&&Q<V;);if(512&b.flags&&(b.check=r(b.check,W,Q,L)),V-=Q,L+=Q,h)break t}else b.head&&(b.head.name=null);b.length=0,b.mode=8;case 8:if(4096&b.flags){if(V===0)break t;for(Q=0;h=W[L+Q++],b.head&&h&&b.length<65536&&(b.head.comment+=String.fromCharCode(h)),h&&Q<V;);if(512&b.flags&&(b.check=r(b.check,W,Q,L)),V-=Q,L+=Q,h)break t}else b.head&&(b.head.comment=null);b.mode=9;case 9:if(512&b.flags){for(;M<16;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(A!==(65535&b.check)){S.msg="header crc mismatch",b.mode=30;break}M=A=0}b.head&&(b.head.hcrc=b.flags>>9&1,b.head.done=!0),S.adler=b.check=0,b.mode=12;break;case 10:for(;M<32;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}S.adler=b.check=k(A),M=A=0,b.mode=11;case 11:if(b.havedict===0)return S.next_out=U,S.avail_out=et,S.next_in=L,S.avail_in=V,b.hold=A,b.bits=M,2;S.adler=b.check=1,b.mode=12;case 12:if(D===5||D===6)break t;case 13:if(b.last){A>>>=7&M,M-=7&M,b.mode=27;break}for(;M<3;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}switch(b.last=1&A,M-=1,3&(A>>>=1)){case 0:b.mode=14;break;case 1:if(O(b),b.mode=20,D!==6)break;A>>>=2,M-=2;break t;case 2:b.mode=17;break;case 3:S.msg="invalid block type",b.mode=30}A>>>=2,M-=2;break;case 14:for(A>>>=7&M,M-=7&M;M<32;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if((65535&A)!=(A>>>16^65535)){S.msg="invalid stored block lengths",b.mode=30;break}if(b.length=65535&A,M=A=0,b.mode=15,D===6)break t;case 15:b.mode=16;case 16:if(Q=b.length){if(V<Q&&(Q=V),et<Q&&(Q=et),Q===0)break t;s.arraySet(Y,W,L,Q,U),V-=Q,L+=Q,et-=Q,U+=Q,b.length-=Q;break}b.mode=12;break;case 17:for(;M<14;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(b.nlen=257+(31&A),A>>>=5,M-=5,b.ndist=1+(31&A),A>>>=5,M-=5,b.ncode=4+(15&A),A>>>=4,M-=4,286<b.nlen||30<b.ndist){S.msg="too many length or distance symbols",b.mode=30;break}b.have=0,b.mode=18;case 18:for(;b.have<b.ncode;){for(;M<3;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.lens[Z[b.have++]]=7&A,A>>>=3,M-=3}for(;b.have<19;)b.lens[Z[b.have++]]=0;if(b.lencode=b.lendyn,b.lenbits=7,N={bits:b.lenbits},z=c(0,b.lens,0,19,b.lencode,0,b.work,N),b.lenbits=N.bits,z){S.msg="invalid code lengths set",b.mode=30;break}b.have=0,b.mode=19;case 19:for(;b.have<b.nlen+b.ndist;){for(;F=($=b.lencode[A&(1<<b.lenbits)-1])>>>16&255,at=65535&$,!((lt=$>>>24)<=M);){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(at<16)A>>>=lt,M-=lt,b.lens[b.have++]=at;else{if(at===16){for(_=lt+2;M<_;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(A>>>=lt,M-=lt,b.have===0){S.msg="invalid bit length repeat",b.mode=30;break}h=b.lens[b.have-1],Q=3+(3&A),A>>>=2,M-=2}else if(at===17){for(_=lt+3;M<_;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}M-=lt,h=0,Q=3+(7&(A>>>=lt)),A>>>=3,M-=3}else{for(_=lt+7;M<_;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}M-=lt,h=0,Q=11+(127&(A>>>=lt)),A>>>=7,M-=7}if(b.have+Q>b.nlen+b.ndist){S.msg="invalid bit length repeat",b.mode=30;break}for(;Q--;)b.lens[b.have++]=h}}if(b.mode===30)break;if(b.lens[256]===0){S.msg="invalid code -- missing end-of-block",b.mode=30;break}if(b.lenbits=9,N={bits:b.lenbits},z=c(u,b.lens,0,b.nlen,b.lencode,0,b.work,N),b.lenbits=N.bits,z){S.msg="invalid literal/lengths set",b.mode=30;break}if(b.distbits=6,b.distcode=b.distdyn,N={bits:b.distbits},z=c(f,b.lens,b.nlen,b.ndist,b.distcode,0,b.work,N),b.distbits=N.bits,z){S.msg="invalid distances set",b.mode=30;break}if(b.mode=20,D===6)break t;case 20:b.mode=21;case 21:if(6<=V&&258<=et){S.next_out=U,S.avail_out=et,S.next_in=L,S.avail_in=V,b.hold=A,b.bits=M,a(S,J),U=S.next_out,Y=S.output,et=S.avail_out,L=S.next_in,W=S.input,V=S.avail_in,A=b.hold,M=b.bits,b.mode===12&&(b.back=-1);break}for(b.back=0;F=($=b.lencode[A&(1<<b.lenbits)-1])>>>16&255,at=65535&$,!((lt=$>>>24)<=M);){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(F&&(240&F)==0){for(ut=lt,C=F,P=at;F=($=b.lencode[P+((A&(1<<ut+C)-1)>>ut)])>>>16&255,at=65535&$,!(ut+(lt=$>>>24)<=M);){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}A>>>=ut,M-=ut,b.back+=ut}if(A>>>=lt,M-=lt,b.back+=lt,b.length=at,F===0){b.mode=26;break}if(32&F){b.back=-1,b.mode=12;break}if(64&F){S.msg="invalid literal/length code",b.mode=30;break}b.extra=15&F,b.mode=22;case 22:if(b.extra){for(_=b.extra;M<_;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.length+=A&(1<<b.extra)-1,A>>>=b.extra,M-=b.extra,b.back+=b.extra}b.was=b.length,b.mode=23;case 23:for(;F=($=b.distcode[A&(1<<b.distbits)-1])>>>16&255,at=65535&$,!((lt=$>>>24)<=M);){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if((240&F)==0){for(ut=lt,C=F,P=at;F=($=b.distcode[P+((A&(1<<ut+C)-1)>>ut)])>>>16&255,at=65535&$,!(ut+(lt=$>>>24)<=M);){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}A>>>=ut,M-=ut,b.back+=ut}if(A>>>=lt,M-=lt,b.back+=lt,64&F){S.msg="invalid distance code",b.mode=30;break}b.offset=at,b.extra=15&F,b.mode=24;case 24:if(b.extra){for(_=b.extra;M<_;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}b.offset+=A&(1<<b.extra)-1,A>>>=b.extra,M-=b.extra,b.back+=b.extra}if(b.offset>b.dmax){S.msg="invalid distance too far back",b.mode=30;break}b.mode=25;case 25:if(et===0)break t;if(Q=J-et,b.offset>Q){if((Q=b.offset-Q)>b.whave&&b.sane){S.msg="invalid distance too far back",b.mode=30;break}tt=Q>b.wnext?(Q-=b.wnext,b.wsize-Q):b.wnext-Q,Q>b.length&&(Q=b.length),pt=b.window}else pt=Y,tt=U-b.offset,Q=b.length;for(et<Q&&(Q=et),et-=Q,b.length-=Q;Y[U++]=pt[tt++],--Q;);b.length===0&&(b.mode=21);break;case 26:if(et===0)break t;Y[U++]=b.length,et--,b.mode=21;break;case 27:if(b.wrap){for(;M<32;){if(V===0)break t;V--,A|=W[L++]<<M,M+=8}if(J-=et,S.total_out+=J,b.total+=J,J&&(S.adler=b.check=b.flags?r(b.check,Y,J,U-J):l(b.check,Y,J,U-J)),J=et,(b.flags?A:k(A))!==b.check){S.msg="incorrect data check",b.mode=30;break}M=A=0}b.mode=28;case 28:if(b.wrap&&b.flags){for(;M<32;){if(V===0)break t;V--,A+=W[L++]<<M,M+=8}if(A!==(4294967295&b.total)){S.msg="incorrect length check",b.mode=30;break}M=A=0}b.mode=29;case 29:z=1;break t;case 30:z=-3;break t;case 31:return-4;case 32:default:return d}return S.next_out=U,S.avail_out=et,S.next_in=L,S.avail_in=V,b.hold=A,b.bits=M,(b.wsize||J!==S.avail_out&&b.mode<30&&(b.mode<27||D!==4))&&q(S,S.output,S.next_out,J-S.avail_out)?(b.mode=31,-4):(X-=S.avail_in,J-=S.avail_out,S.total_in+=X,S.total_out+=J,b.total+=J,b.wrap&&J&&(S.adler=b.check=b.flags?r(b.check,Y,J,S.next_out-J):l(b.check,Y,J,S.next_out-J)),S.data_type=b.bits+(b.last?64:0)+(b.mode===12?128:0)+(b.mode===20||b.mode===15?256:0),(X==0&&J===0||D===4)&&z===v&&(z=-5),z)},o.inflateEnd=function(S){if(!S||!S.state)return d;var D=S.state;return D.window&&(D.window=null),S.state=null,v},o.inflateGetHeader=function(S,D){var b;return S&&S.state?(2&(b=S.state).wrap)==0?d:((b.head=D).done=!1,v):d},o.inflateSetDictionary=function(S,D){var b,W=D.length;return S&&S.state?(b=S.state).wrap!==0&&b.mode!==11?d:b.mode===11&&l(1,D,W,0)!==b.check?-3:q(S,D,W,W)?(b.mode=31,-4):(b.havedict=1,v):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,f,v,d,y,m,g,k){var x,I,T,E,B,w,H,j,O,q=k.bits,S=0,D=0,b=0,W=0,Y=0,L=0,U=0,V=0,et=0,A=0,M=null,X=0,J=new s.Buf16(16),Q=new s.Buf16(16),tt=null,pt=0;for(S=0;S<=15;S++)J[S]=0;for(D=0;D<d;D++)J[f[v+D]]++;for(Y=q,W=15;1<=W&&J[W]===0;W--);if(W<Y&&(Y=W),W===0)return y[m++]=20971520,y[m++]=20971520,k.bits=1,0;for(b=1;b<W&&J[b]===0;b++);for(Y<b&&(Y=b),S=V=1;S<=15;S++)if(V<<=1,(V-=J[S])<0)return-1;if(0<V&&(u===0||W!==1))return-1;for(Q[1]=0,S=1;S<15;S++)Q[S+1]=Q[S]+J[S];for(D=0;D<d;D++)f[v+D]!==0&&(g[Q[f[v+D]]++]=D);if(w=u===0?(M=tt=g,19):u===1?(M=l,X-=257,tt=r,pt-=257,256):(M=a,tt=c,-1),S=b,B=m,U=D=A=0,T=-1,E=(et=1<<(L=Y))-1,u===1&&852<et||u===2&&592<et)return 1;for(;;){for(H=S-U,O=g[D]<w?(j=0,g[D]):g[D]>w?(j=tt[pt+g[D]],M[X+g[D]]):(j=96,0),x=1<<S-U,b=I=1<<L;y[B+(A>>U)+(I-=x)]=H<<24|j<<16|O|0,I!==0;);for(x=1<<S-1;A&x;)x>>=1;if(x!==0?(A&=x-1,A+=x):A=0,D++,--J[S]==0){if(S===W)break;S=f[v+g[D]]}if(Y<S&&(A&E)!==T){for(U===0&&(U=Y),B+=b,V=1<<(L=S-U);L+U<W&&!((V-=J[L+U])<=0);)L++,V<<=1;if(et+=1<<L,u===1&&852<et||u===2&&592<et)return 1;y[T=A&E]=Y<<24|L<<16|B-m|0}}return A!==0&&(y[B+A]=S-U<<24|64<<16|0),k.bits=Y,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a($){for(var R=$.length;0<=--R;)$[R]=0}var c=0,u=29,f=256,v=f+1+u,d=30,y=19,m=2*v+1,g=15,k=16,x=7,I=256,T=16,E=17,B=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],H=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],j=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],O=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],q=new Array(2*(v+2));a(q);var S=new Array(2*d);a(S);var D=new Array(512);a(D);var b=new Array(256);a(b);var W=new Array(u);a(W);var Y,L,U,V=new Array(d);function et($,R,Z,G,K){this.static_tree=$,this.extra_bits=R,this.extra_base=Z,this.elems=G,this.max_length=K,this.has_stree=$&&$.length}function A($,R){this.dyn_tree=$,this.max_code=0,this.stat_desc=R}function M($){return $<256?D[$]:D[256+($>>>7)]}function X($,R){$.pending_buf[$.pending++]=255&R,$.pending_buf[$.pending++]=R>>>8&255}function J($,R,Z){$.bi_valid>k-Z?($.bi_buf|=R<<$.bi_valid&65535,X($,$.bi_buf),$.bi_buf=R>>k-$.bi_valid,$.bi_valid+=Z-k):($.bi_buf|=R<<$.bi_valid&65535,$.bi_valid+=Z)}function Q($,R,Z){J($,Z[2*R],Z[2*R+1])}function tt($,R){for(var Z=0;Z|=1&$,$>>>=1,Z<<=1,0<--R;);return Z>>>1}function pt($,R,Z){var G,K,it=new Array(g+1),ct=0;for(G=1;G<=g;G++)it[G]=ct=ct+Z[G-1]<<1;for(K=0;K<=R;K++){var rt=$[2*K+1];rt!==0&&($[2*K]=tt(it[rt]++,rt))}}function lt($){var R;for(R=0;R<v;R++)$.dyn_ltree[2*R]=0;for(R=0;R<d;R++)$.dyn_dtree[2*R]=0;for(R=0;R<y;R++)$.bl_tree[2*R]=0;$.dyn_ltree[2*I]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function F($){8<$.bi_valid?X($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function at($,R,Z,G){var K=2*R,it=2*Z;return $[K]<$[it]||$[K]===$[it]&&G[R]<=G[Z]}function ut($,R,Z){for(var G=$.heap[Z],K=Z<<1;K<=$.heap_len&&(K<$.heap_len&&at(R,$.heap[K+1],$.heap[K],$.depth)&&K++,!at(R,G,$.heap[K],$.depth));)$.heap[Z]=$.heap[K],Z=K,K<<=1;$.heap[Z]=G}function C($,R,Z){var G,K,it,ct,rt=0;if($.last_lit!==0)for(;G=$.pending_buf[$.d_buf+2*rt]<<8|$.pending_buf[$.d_buf+2*rt+1],K=$.pending_buf[$.l_buf+rt],rt++,G===0?Q($,K,R):(Q($,(it=b[K])+f+1,R),(ct=w[it])!==0&&J($,K-=W[it],ct),Q($,it=M(--G),Z),(ct=H[it])!==0&&J($,G-=V[it],ct)),rt<$.last_lit;);Q($,I,R)}function P($,R){var Z,G,K,it=R.dyn_tree,ct=R.stat_desc.static_tree,rt=R.stat_desc.has_stree,mt=R.stat_desc.elems,_t=-1;for($.heap_len=0,$.heap_max=m,Z=0;Z<mt;Z++)it[2*Z]!==0?($.heap[++$.heap_len]=_t=Z,$.depth[Z]=0):it[2*Z+1]=0;for(;$.heap_len<2;)it[2*(K=$.heap[++$.heap_len]=_t<2?++_t:0)]=1,$.depth[K]=0,$.opt_len--,rt&&($.static_len-=ct[2*K+1]);for(R.max_code=_t,Z=$.heap_len>>1;1<=Z;Z--)ut($,it,Z);for(K=mt;Z=$.heap[1],$.heap[1]=$.heap[$.heap_len--],ut($,it,1),G=$.heap[1],$.heap[--$.heap_max]=Z,$.heap[--$.heap_max]=G,it[2*K]=it[2*Z]+it[2*G],$.depth[K]=($.depth[Z]>=$.depth[G]?$.depth[Z]:$.depth[G])+1,it[2*Z+1]=it[2*G+1]=K,$.heap[1]=K++,ut($,it,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(wt,Lt){var Gt,Yt,ie,Nt,Ge,se,Xt=Lt.dyn_tree,yi=Lt.max_code,Oi=Lt.stat_desc.static_tree,Ro=Lt.stat_desc.has_stree,Po=Lt.stat_desc.extra_bits,Nn=Lt.stat_desc.extra_base,ki=Lt.stat_desc.max_length,zi=0;for(Nt=0;Nt<=g;Nt++)wt.bl_count[Nt]=0;for(Xt[2*wt.heap[wt.heap_max]+1]=0,Gt=wt.heap_max+1;Gt<m;Gt++)ki<(Nt=Xt[2*Xt[2*(Yt=wt.heap[Gt])+1]+1]+1)&&(Nt=ki,zi++),Xt[2*Yt+1]=Nt,yi<Yt||(wt.bl_count[Nt]++,Ge=0,Nn<=Yt&&(Ge=Po[Yt-Nn]),se=Xt[2*Yt],wt.opt_len+=se*(Nt+Ge),Ro&&(wt.static_len+=se*(Oi[2*Yt+1]+Ge)));if(zi!==0){do{for(Nt=ki-1;wt.bl_count[Nt]===0;)Nt--;wt.bl_count[Nt]--,wt.bl_count[Nt+1]+=2,wt.bl_count[ki]--,zi-=2}while(0<zi);for(Nt=ki;Nt!==0;Nt--)for(Yt=wt.bl_count[Nt];Yt!==0;)yi<(ie=wt.heap[--Gt])||(Xt[2*ie+1]!==Nt&&(wt.opt_len+=(Nt-Xt[2*ie+1])*Xt[2*ie],Xt[2*ie+1]=Nt),Yt--)}})($,R),pt(it,_t,$.bl_count)}function h($,R,Z){var G,K,it=-1,ct=R[1],rt=0,mt=7,_t=4;for(ct===0&&(mt=138,_t=3),R[2*(Z+1)+1]=65535,G=0;G<=Z;G++)K=ct,ct=R[2*(G+1)+1],++rt<mt&&K===ct||(rt<_t?$.bl_tree[2*K]+=rt:K!==0?(K!==it&&$.bl_tree[2*K]++,$.bl_tree[2*T]++):rt<=10?$.bl_tree[2*E]++:$.bl_tree[2*B]++,it=K,_t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4))}function z($,R,Z){var G,K,it=-1,ct=R[1],rt=0,mt=7,_t=4;for(ct===0&&(mt=138,_t=3),G=0;G<=Z;G++)if(K=ct,ct=R[2*(G+1)+1],!(++rt<mt&&K===ct)){if(rt<_t)for(;Q($,K,$.bl_tree),--rt!=0;);else K!==0?(K!==it&&(Q($,K,$.bl_tree),rt--),Q($,T,$.bl_tree),J($,rt-3,2)):rt<=10?(Q($,E,$.bl_tree),J($,rt-3,3)):(Q($,B,$.bl_tree),J($,rt-11,7));it=K,_t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4)}}a(V);var N=!1;function _($,R,Z,G){J($,(c<<1)+(G?1:0),3),(function(K,it,ct,rt){F(K),X(K,ct),X(K,~ct),s.arraySet(K.pending_buf,K.window,it,ct,K.pending),K.pending+=ct})($,R,Z)}o._tr_init=function($){N||((function(){var R,Z,G,K,it,ct=new Array(g+1);for(K=G=0;K<u-1;K++)for(W[K]=G,R=0;R<1<<w[K];R++)b[G++]=K;for(b[G-1]=K,K=it=0;K<16;K++)for(V[K]=it,R=0;R<1<<H[K];R++)D[it++]=K;for(it>>=7;K<d;K++)for(V[K]=it<<7,R=0;R<1<<H[K]-7;R++)D[256+it++]=K;for(Z=0;Z<=g;Z++)ct[Z]=0;for(R=0;R<=143;)q[2*R+1]=8,R++,ct[8]++;for(;R<=255;)q[2*R+1]=9,R++,ct[9]++;for(;R<=279;)q[2*R+1]=7,R++,ct[7]++;for(;R<=287;)q[2*R+1]=8,R++,ct[8]++;for(pt(q,v+1,ct),R=0;R<d;R++)S[2*R+1]=5,S[2*R]=tt(R,5);Y=new et(q,w,f+1,v,g),L=new et(S,H,0,d,g),U=new et(new Array(0),j,0,y,x)})(),N=!0),$.l_desc=new A($.dyn_ltree,Y),$.d_desc=new A($.dyn_dtree,L),$.bl_desc=new A($.bl_tree,U),$.bi_buf=0,$.bi_valid=0,lt($)},o._tr_stored_block=_,o._tr_flush_block=function($,R,Z,G){var K,it,ct=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(rt){var mt,_t=4093624447;for(mt=0;mt<=31;mt++,_t>>>=1)if(1&_t&&rt.dyn_ltree[2*mt]!==0)return l;if(rt.dyn_ltree[18]!==0||rt.dyn_ltree[20]!==0||rt.dyn_ltree[26]!==0)return r;for(mt=32;mt<f;mt++)if(rt.dyn_ltree[2*mt]!==0)return r;return l})($)),P($,$.l_desc),P($,$.d_desc),ct=(function(rt){var mt;for(h(rt,rt.dyn_ltree,rt.l_desc.max_code),h(rt,rt.dyn_dtree,rt.d_desc.max_code),P(rt,rt.bl_desc),mt=y-1;3<=mt&&rt.bl_tree[2*O[mt]+1]===0;mt--);return rt.opt_len+=3*(mt+1)+5+5+4,mt})($),K=$.opt_len+3+7>>>3,(it=$.static_len+3+7>>>3)<=K&&(K=it)):K=it=Z+5,Z+4<=K&&R!==-1?_($,R,Z,G):$.strategy===4||it===K?(J($,2+(G?1:0),3),C($,q,S)):(J($,4+(G?1:0),3),(function(rt,mt,_t,wt){var Lt;for(J(rt,mt-257,5),J(rt,_t-1,5),J(rt,wt-4,4),Lt=0;Lt<wt;Lt++)J(rt,rt.bl_tree[2*O[Lt]+1],3);z(rt,rt.dyn_ltree,mt-1),z(rt,rt.dyn_dtree,_t-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,ct+1),C($,$.dyn_ltree,$.dyn_dtree)),lt($),G&&F($)},o._tr_tally=function($,R,Z){return $.pending_buf[$.d_buf+2*$.last_lit]=R>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&R,$.pending_buf[$.l_buf+$.last_lit]=255&Z,$.last_lit++,R===0?$.dyn_ltree[2*Z]++:($.matches++,R--,$.dyn_ltree[2*(b[Z]+f+1)]++,$.dyn_dtree[2*M(R)]++),$.last_lit===$.lit_bufsize-1},o._tr_align=function($){J($,2,3),Q($,I,q),(function(R){R.bi_valid===16?(X(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,f,v=1,d={},y=!1,m=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){x(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,E=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=E,T}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",I,!1):l.attachEvent("onmessage",I),function(T){l.postMessage(f+T,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(T){x(T.data)},function(T){u.port2.postMessage(T)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(T){var E=m.createElement("script");E.onreadystatechange=function(){x(T),E.onreadystatechange=null,c.removeChild(E),E=null},c.appendChild(E)}):function(T){setTimeout(x,0,T)},g.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var E=new Array(arguments.length-1),B=0;B<E.length;B++)E[B]=arguments[B+1];var w={callback:T,args:E};return d[v]=w,a(v),v++},g.clearImmediate=k}function k(T){delete d[T]}function x(T){if(y)setTimeout(x,0,T);else{var E=d[T];if(E){y=!0;try{(function(B){var w=B.callback,H=B.args;switch(H.length){case 0:w();break;case 1:w(H[0]);break;case 2:w(H[0],H[1]);break;case 3:w(H[0],H[1],H[2]);break;default:w.apply(r,H)}})(E)}finally{k(T),y=!1}}}}function I(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(f)===0&&x(+T.data.slice(f.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Gn<"u"?Gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Xo)),Xo.exports}var g1=m1();const v1=h1(g1),b1=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,y1=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function k1(t){const e=await v1.loadAsync(t),i={},n=[];let o="",s="";const l=[];e.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||y1.test(c)||c.includes("snippets/")){const u=await a.file.async("string");i[c]=u;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=u)}else if(b1.test(c)){const u=await a.file.async("uint8array"),f=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:f,data:u,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function w1(t,e){if(Object.keys(e).length===0)return t;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(e[s])return e[s];const r=s.replace(/^\.?\//,"");return e[r]?e[r]:e[l]?e[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=i(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function $a(t){try{if(typeof process<"u"&&typeof require<"u"){const e=require("fs");if(e.existsSync(t))return e.readFileSync(t,"utf-8")}}catch{}return null}function x1(t,e){const i=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(e==null?void 0:e.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[y,m]of Object.entries(a))if(y.endsWith(`/${r}`)||d&&y.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(e!=null&&e.baseDir)try{const y=require("path");d.push(y.resolve(e.baseDir,r)),d.push(y.resolve(e.baseDir,s))}catch{}try{const y=require("path");d.push(y.resolve(process.cwd(),r))}catch{}for(const y of d){const m=$a(y);if(m!==null){c=m;break}}}if(!c){const d=ga||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const y=r.split("/").pop();for(const[m,g]of Object.entries(d))if(m.endsWith(`/${r}`)||y&&m.endsWith(`/${y}`)){c=g;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),y=c.match(d);if(y){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+y[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function _1(t){let e=!1,i=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!i)e=!e;else if(o==='"'&&!e)i=!i;else if(o==="#"&&!e&&!i)return t.slice(0,n).trim()}return t.trim()}function Qn(t){const e={},i=t.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<i.length;){const f=i[n];if(!f.trim()){c.push(""),n++;continue}const d=f.match(/^(\s+)/),y=d?d[1].length:0;if(u===-1&&(u=y),y<u)break;c.push(f.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();e[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=_1(a),!a){let c=n+1;const u=[];let f=-1;for(;c<i.length;){const v=i[c],d=v.trim();if(!d||d.startsWith("#")){f!==-1&&u.push(""),c++;continue}const y=v.match(/^(\s+)/),m=y?y[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(v.slice(f)),c++}if(u.length>0){e[r]=Qn(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),e[r]=a}n++}return e}const S1=/^\s*```ya?ml([\s\S]*?)```/;function zr(t){let e={},i=t.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=Qn(n[1]);if(Object.keys(s).length>0||!n[1].trim())return e=s,i=i.slice(n[0].length).trim(),{frontmatter:e,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(S1);if(o)e=Qn(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(e=Qn(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:e,content:i}}function C1(t){const e=t.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=e.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<e.length;l++){const a=e[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=e[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<e.length&&e[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let f=l+1;for(;f<e.length&&!e[f].trimStart().startsWith(u);f++);f<e.length&&(l=f)}}return n<e.length&&s(e.length),i}function to(t,e={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=e;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=C1(u),v={};let d="",y="",m=0;if(f.length>0){const O=f[0],q=zr(O),S=Object.keys(q.frontmatter).length>0,D=q.content.length>0;S&&!D&&f.length>1?(m=1,g(q.frontmatter)):S&&g(q.frontmatter)}function g(O){d=O.title||"",O.theme&&(v[wn]=String(O.theme)),O.aspectRatio&&(v[xn]=String(O.aspectRatio)),O.highlighter&&(v[Kr]=String(O.highlighter)),O.transition&&(v[_n]=String(O.transition)),O.colorSchema&&(v[Gr]=String(O.colorSchema)),O.layout&&(v[gt]=String(O.layout)),O.background&&(v[Ut]=String(O.background)),O.image&&(v[Ee]=String(O.image)),O.class&&(v[Wi]=String(O.class));for(const[q,S]of Object.entries(O))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(q)||(v[`custom-slidev-${q}`]=typeof S=="object"?JSON.stringify(S):String(S))}const k=[];let x=0,I=0,T=0,E=0;const B=new Set,w={};let H=1;for(let O=m;O<f.length;O++){const q=f[O],{frontmatter:S,content:D}=zr(q),b=q.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),W=S.src||(b?b[1]:void 0);if(W){const F=String(W).trim().replace(/^['"]|['"]$/g,"");let at=c[F]||c[F.replace(/^\.\//,"")]||c[`pages/${F.replace(/^.*pages\//,"")}`];if(!at){const C=F.replace(/^\.\//,""),P=[];if(e.baseDir)try{const h=require("path");P.push(h.resolve(e.baseDir,C)),P.push(h.resolve(e.baseDir,F))}catch{}try{const h=require("path");P.push(h.resolve(process.cwd(),C)),P.push(h.resolve(process.cwd(),F))}catch{}for(const h of P){const z=$a(h);if(z!==null){at=z;break}}}const ut={};S.layout&&(ut[gt]=String(S.layout)),S.transition&&(ut[te]=String(S.transition)),S.background&&(ut[Ut]=String(S.background)),S.image&&(ut[Ee]=String(S.image)),S.class&&(ut[Wi]=String(S.class));for(const[C,P]of Object.entries(S))["src","layout","transition","background","image","class"].includes(C)||(ut[`custom-slidev-${C}`]=typeof P=="object"?JSON.stringify(P):String(P));if(at){const C=to(at,{...e,virtualFiles:c});for(const P of C.slides){P.pageIndex=H++,P.pageAttrs={...ut,...P.pageAttrs},k.push(P);const h=P.pageAttrs[gt]||"default";w[h]=(w[h]||0)+1}continue}else{k.push({pageIndex:H++,pageAttrs:{...ut,"custom-slidev-src":F},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${F}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const C=ut[gt]||"default";w[C]=(w[C]||0)+1;continue}}const Y={};S.layout&&(Y[gt]=String(S.layout)),S.transition&&(Y[te]=String(S.transition)),S.background&&(Y[Ut]=String(S.background)),S.image&&(Y[Ee]=String(S.image)),S.class&&(Y[Wi]=String(S.class));for(const[F,at]of Object.entries(S))["layout","transition","background","image","class"].includes(F)||(Y[`custom-slidev-${F}`]=typeof at=="object"?JSON.stringify(at):String(at));let L=D;const U=[];let V=L.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,F=>{const at=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(F),at});V=V.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,F=>{const at=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(F),at});let et="";const A=Array.from(V.matchAll(/<!--([\s\S]*?)-->/g));if(A.length>0){const F=A[A.length-1],at=V.slice(F.index+F[0].length).trim();if(!at||!at.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const C=F[1].trim();C.startsWith("TODO:")||(et=C,x++),i&&(V=V.slice(0,F.index).trimEnd()+V.slice(F.index+F[0].length))}}i&&(V=V.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let F=0;F<U.length;F++)V=V.replace(`__CODE_TOKEN_NOTE_${F}__`,U[F]);if(L=V,et){for(let ut=0;ut<U.length;ut++)et=et.replace(`__CODE_TOKEN_NOTE_${ut}__`,U[ut]);const at=`> [!NOTE] 💡 演讲备注
${et.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;L=L?`${L}

${at}`:at}let M=!1;if(/<style\b/i.test(L)){M=!0;const F=L.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(F){for(const at of F){const ut=at.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();y=y?`${y}

${ut}`:ut}l&&(L=L.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const X=L.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);X&&(I+=X.length);const J=L.match(/```\w+\s+\{[^}]+\}/g);J&&(T+=J.length);const Q=L.match(/::\w+::|<template\s+#[^>]+>/g);if(Q&&(E+=Q.length),L=L.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,F=>x1(F,{...e,virtualFiles:c})||F),n&&(L=L.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(L=L.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),L=L.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(L=L.replace(/^::\w+::\s*$/gm,"")),r&&(L=rf(L)),a){let F=L.trim(),at="";const ut=F.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(at=F.slice(ut),F=F.slice(0,ut).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const C=String(S.image).trim(),P=S.layout==="image-left"?"image-left":"image-right",h=`![配图](${C})
{: custom-slidev-layout="${P}" }`;S.layout==="image-left"?F=`{{{col

${h}

${F}

}}}`:F=`{{{col

${F}

${h}

}}}`}if(S.background){const P=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;F=F?`${P}

${F}`:P}L=at?`${F}

${at}`:F}const tt=$1(L);Y[Ut]&&tt.push(Y[Ut]),Y[Ee]&&tt.push(Y[Ee]);for(const F of tt)B.add(F);const pt=/<[A-Z][a-zA-Z0-9]+/.test(L),lt=Y[gt]||(H===1?v[gt]||"cover":"default");w[lt]=(w[lt]||0)+1,k.push({pageIndex:H++,pageAttrs:Y,notes:et,rawMarkdown:L,hasVueComponent:pt,hasStyleTag:M,assetReferences:tt})}if(!d&&k.length>0){const O=k[0].rawMarkdown.match(/^#\s+(.+)$/m);O&&(d=O[1].trim())}y&&(v["custom-slidev-custom-css"]=y);let j=k.map(O=>`---

${O.rawMarkdown}`).join(`

`);return j.trimStart().startsWith("---")||(j=`---

${j.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:v,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:I,totalShikiHighlights:T,totalSlots:E,discoveredAssets:Array.from(B),layoutDistribution:w},flattenedMarkdown:j,customCss:y}}function $1(t){const e=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&e.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&e.push(s)}return e}function Ia(t){if(!t)return!1;const e=String(t.type||"").toLowerCase(),i=String(t.markdown||"").trim(),n=String(t.content||"").trim();return e==="tb"||e==="thematic-break"||e==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function I1(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function A1(t,e,i=Et){const n=t.filter(Ia);let o=0;if(n.length>=e.length)for(let s=0;s<e.length;s++){const l=e[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<e.length;s++){const l=e[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function B1(t,e=Et){let i=!1,n=0;for(const o of t){if(Ia(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await e(o.id,{[Ct]:"right"}).catch(()=>{}),n++)}return n}async function T1(t,e,i=Wr){const n={};if(!e||e.length===0)return n;const o=[];for(const s of e){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&w1(t,n),n}async function E1(t){var T;const{presentation:e,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Wr,u=a.createDocFn||mc,f=a.setAttrsFn||Et,v=a.getChildBlocksFn||so,d=a.openTabFn||ht.openTab,y=a.showMessageFn||ht.showMessage;s&&o.length>0&&await T1(e,o,c);const m=I1(n),g=`/${m}`,k=await u(i,g,e.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((T=e.slides[0])==null?void 0:T.pageAttrs)||{};await f(k,{...x,...e.docRootAttrs});const I=await v(k).catch(()=>[]);return Array.isArray(I)&&I.length>0&&(await A1(I,e.slides,f),await B1(I,f)),y(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function M1(t){const e=vt("file"),i=vt(!1),n=vt(!1),o=vt(""),s=vt(null),l=vt(null),r=vt(""),a=vt(0),c=vt(""),u=vt([]),f=vt(null),v=vt(""),d=vt([]),y=vt(""),m=vt(!0),g=vt(!0),k=vt(!0),x=vt(!0),I=St(()=>{const Y=a.value;if(Y===0)return"0 B";const L=1024,U=["B","KB","MB","GB"],V=Math.floor(Math.log(Y)/Math.log(L));return`${(Y/L**V).toFixed(1)} ${U[V]}`}),T=St(()=>{var Y;return((Y=f.value)==null?void 0:Y.docRootAttrs["custom-slidev-theme"])||"default"}),E=St(()=>{var Y;return u.value.length>0?u.value.length:((Y=f.value)==null?void 0:Y.stats.discoveredAssets.length)||0}),B=St(()=>{var L;const Y=((L=f.value)==null?void 0:L.stats.layoutDistribution)||{};return Object.entries(Y).map(([U,V])=>({name:U,count:V}))});async function w(Y=hc){try{const L=await Y();L!=null&&L.notebooks&&Array.isArray(L.notebooks)&&(d.value=L.notebooks.filter(U=>!U.closed),d.value.length>0&&!y.value&&(y.value=d.value[0].id))}catch(L){console.warn("获取笔记本列表失败:",L)}}function H(){var Y;(Y=s.value)==null||Y.click()}function j(){l.value=null,r.value="",a.value=0,f.value=null,u.value=[],o.value=""}async function O(Y){o.value="",l.value=Y,r.value=Y.name,a.value=Y.size;try{if(Y.name.toLowerCase().endsWith(".zip")){const U=await Y.arrayBuffer(),V=await k1(U);if(!V.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const et=to(V.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:V.virtualFiles});f.value=et,v.value=et.docTitle||Y.name.replace(/\.zip$/i,"")}else{const U=await Y.text();u.value=[];const V=Y.path||"",et=V?V.replace(/[\\/][^\\/]+$/,""):"",A=to(U,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:et||void 0});f.value=A,v.value=A.docTitle||Y.name.replace(/\.md$/i,"")}}catch(L){console.error("解析文件失败:",L),o.value=`解析文件失败: ${L.message||String(L)}`}}function q(){if(o.value="",!c.value.trim()){f.value=null;return}try{const Y=to(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=Y,v.value=Y.docTitle||"Slidev 演示文稿"}catch(Y){o.value=`解析 Markdown 源码失败: ${Y.message||String(Y)}`}}async function S(){l.value?await O(l.value):c.value&&q()}async function D(Y){const L=Y.target;L.files&&L.files[0]&&await O(L.files[0])}async function b(Y){var L;i.value=!1,(L=Y.dataTransfer)!=null&&L.files&&Y.dataTransfer.files[0]&&await O(Y.dataTransfer.files[0])}async function W(Y=t){if(f.value){if(!y.value&&d.value.length>0&&(y.value=d.value[0].id),!y.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await E1({presentation:f.value,notebookId:y.value,docTitle:v.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:x.value,plugin:Y})}catch(L){console.error("导入 Slidev 演示失败:",L),o.value=`导入执行失败: ${L.message||String(L)}`}finally{n.value=!1}}}return{inputMode:e,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:v,notebooks:d,selectedNotebookId:y,optCleanHtml:m,optStripNotes:g,optUploadAssets:k,optAutoPreview:x,formattedFileSize:I,currentTheme:T,extractedAssetsCount:E,layoutChips:B,fetchNotebooks:w,triggerFileInput:H,clearFile:j,processFile:O,onFileSelected:D,onFileDrop:b,onTextChange:q,reprocessCurrentInput:S,handleConfirmImport:W}}const D1={class:"spm-import-dialog"},L1={class:"spm-tabs-header"},R1={class:"spm-dialog-body"},P1={key:0,class:"spm-file-section"},O1={key:0,class:"spm-dropzone-prompt"},z1={class:"spm-dropzone-icon"},N1={key:1,class:"spm-dropzone-active"},F1={class:"spm-file-badge"},H1={class:"spm-file-size"},j1={key:1,class:"spm-text-section"},U1={key:2,class:"spm-error-banner"},W1={key:3,class:"spm-preview-card"},V1={class:"spm-preview-card__header"},q1={style:{display:"inline-flex","align-items":"center",gap:"4px"}},K1={class:"spm-config-grid"},G1={class:"spm-form-item"},Z1={class:"spm-form-item"},Y1=["value"],J1={class:"spm-stats-grid"},X1={class:"spm-stat-box"},Q1={class:"spm-stat-value"},ty={class:"spm-stat-box"},ey={class:"spm-stat-value"},iy={class:"spm-stat-box"},ny={class:"spm-stat-value"},oy={class:"spm-stat-box"},sy={class:"spm-stat-value"},ry={key:0,class:"spm-chips-row"},ly={class:"spm-options-group"},ay={class:"spm-checkbox-label"},cy={class:"spm-checkbox-label"},dy={class:"spm-checkbox-label"},uy={class:"spm-checkbox-label"},fy={class:"spm-dialog-footer"},py=["disabled"],hy=["disabled"],my={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},gy={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},vy=Ce({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:e}){const i=e,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:v,customDocTitle:d,notebooks:y,selectedNotebookId:m,optCleanHtml:g,optStripNotes:k,optUploadAssets:x,optAutoPreview:I,formattedFileSize:T,currentTheme:E,layoutChips:B,fetchNotebooks:w,triggerFileInput:H,clearFile:j,onFileSelected:O,onFileDrop:q,onTextChange:S,reprocessCurrentInput:D,handleConfirmImport:b}=M1(n);Pn(async()=>{await w()});async function W(){const L=await b();L&&(i("success",{docId:L}),i("close"))}function Y(){i("close")}return(L,U)=>(nt(),st("div",{class:"spm-modal-overlay",onClick:Me(Y,["self"])},[p("div",D1,[p("div",{class:"spm-dialog-header"},[U[18]||(U[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:Y},"✕")]),p("div",L1,[p("button",{class:At(["spm-tab-btn",{active:bt(o)==="file"}]),onClick:U[0]||(U[0]=V=>o.value="file")},[dt(ft,{name:"package"}),U[19]||(U[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:At(["spm-tab-btn",{active:bt(o)==="text"}]),onClick:U[1]||(U[1]=V=>o.value="text")},[dt(ft,{name:"notes"}),U[20]||(U[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",R1,[bt(o)==="file"?(nt(),st("div",P1,[p("div",{class:At(["spm-dropzone",{dragover:bt(s),"has-file":!!bt(c)}]),onDragover:U[4]||(U[4]=Me(V=>s.value=!0,["prevent"])),onDragleave:U[5]||(U[5]=Me(V=>s.value=!1,["prevent"])),onDrop:U[6]||(U[6]=Me((...V)=>bt(q)&&bt(q)(...V),["prevent"])),onClick:U[7]||(U[7]=(...V)=>bt(H)&&bt(H)(...V))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:U[2]||(U[2]=(...V)=>bt(O)&&bt(O)(...V))},null,544),bt(c)?(nt(),st("div",N1,[p("span",F1,[dt(ft,{name:"notes"}),$e(" "+xt(bt(c)),1)]),p("span",H1,"("+xt(bt(T))+")",1),p("button",{class:"spm-btn-text",onClick:U[3]||(U[3]=Me((...V)=>bt(j)&&bt(j)(...V),["stop"]))},"更换文件")])):(nt(),st("div",O1,[p("span",z1,[dt(ft,{name:"folder",style:{"font-size":"32px"}})]),U[21]||(U[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),U[22]||(U[22]=p("p",{class:"spm-dropzone-hint"},[$e(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),$e("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(nt(),st("div",j1,[Te(p("textarea",{"onUpdate:modelValue":U[8]||(U[8]=V=>Jt(u)?u.value=V:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:U[9]||(U[9]=(...V)=>bt(S)&&bt(S)(...V))},null,544),[[yo,bt(u)]])])),bt(r)?(nt(),st("div",U1," ⚠️ "+xt(bt(r)),1)):Pt("",!0),bt(v)?(nt(),st("div",W1,[p("div",V1,[p("span",q1,[dt(ft,{name:"sparkles"}),U[23]||(U[23]=$e(" 演示解析摘要",-1))]),U[24]||(U[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",K1,[p("div",G1,[U[25]||(U[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(p("input",{"onUpdate:modelValue":U[10]||(U[10]=V=>Jt(d)?d.value=V:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[yo,bt(d)]])]),p("div",Z1,[U[26]||(U[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(p("select",{"onUpdate:modelValue":U[11]||(U[11]=V=>Jt(m)?m.value=V:null),class:"spm-select"},[(nt(!0),st(Kt,null,xe(bt(y),V=>(nt(),st("option",{key:V.id,value:V.id},xt(V.name),9,Y1))),128))],512),[[Nu,bt(m)]])])]),p("div",J1,[p("div",X1,[p("span",Q1,xt(bt(v).totalSlides),1),U[27]||(U[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",ty,[p("span",ey,xt(bt(E)),1),U[28]||(U[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",iy,[p("span",ny,xt(bt(v).stats.totalNotes),1),U[29]||(U[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",oy,[p("span",sy,xt(bt(f)),1),U[30]||(U[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),bt(B).length>0?(nt(),st("div",ry,[U[31]||(U[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(nt(!0),st(Kt,null,xe(bt(B),V=>(nt(),st("span",{key:V.name,class:"spm-chip-badge"},xt(V.name)+": "+xt(V.count),1))),128))])):Pt("",!0),p("div",ly,[p("label",ay,[Te(p("input",{"onUpdate:modelValue":U[12]||(U[12]=V=>Jt(g)?g.value=V:null),type:"checkbox",onChange:U[13]||(U[13]=(...V)=>bt(D)&&bt(D)(...V))},null,544),[[qn,bt(g)]]),U[32]||(U[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",cy,[Te(p("input",{"onUpdate:modelValue":U[14]||(U[14]=V=>Jt(k)?k.value=V:null),type:"checkbox",onChange:U[15]||(U[15]=(...V)=>bt(D)&&bt(D)(...V))},null,544),[[qn,bt(k)]]),U[33]||(U[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",dy,[Te(p("input",{"onUpdate:modelValue":U[16]||(U[16]=V=>Jt(x)?x.value=V:null),type:"checkbox"},null,512),[[qn,bt(x)]]),U[34]||(U[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",uy,[Te(p("input",{"onUpdate:modelValue":U[17]||(U[17]=V=>Jt(I)?I.value=V:null),type:"checkbox"},null,512),[[qn,bt(I)]]),U[35]||(U[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Pt("",!0)]),p("div",fy,[p("button",{class:"spm-btn-secondary",disabled:bt(l),onClick:Y}," 取消 ",8,py),p("button",{class:"spm-btn-primary",disabled:!bt(v)||bt(l),onClick:W},[bt(l)?(nt(),st("span",my,[dt(ft,{name:"refresh"}),U[36]||(U[36]=$e(" 正在导入生成中...",-1))])):(nt(),st("span",gy,[dt(ft,{name:"rocket"}),U[37]||(U[37]=$e(" 确认导入思源笔记",-1))]))],8,hy)])])]))}}),by=ze(vy,[["__scopeId","data-v-ce8dffdc"]]);function Aa(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function yy(t,e){var r;if(!t||t.length===0)return null;const i=e.activeBlockId||"",n=e.currentTopBlockId||i,o=e.currentPageDividerId||"",s=e.activeBlockType||"";if(Aa(s)&&i){let a=t.find(c=>c.startBlockId===i);if(a||(a=t.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===i}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===o}),a))return a}if(i){let a=t.find(u=>u.startBlockId===i);if(a||(a=t.find(u=>{var f,v;return((f=u.blocks)==null?void 0:f.some(d=>d.id===i))||((v=u.allBlockIds)==null?void 0:v.includes(i))}),a)||n&&n!==i&&(a=t.find(u=>{var f,v;return((f=u.blocks)==null?void 0:f.some(d=>d.id===n))||((v=u.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=t.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(v=>v.id===i||v.id===n)}),a))return a;const c=(r=e.activeBlockAttrs)==null?void 0:r[Ct];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var f,v;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((v=u.blocks)==null?void 0:v.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Nr(t,e){const i=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Ba(t,e){const i=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(e&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await e(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Nr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Nr(t),isAiGenerated:!1}}async function ky(t,e){return(await Ba(t,e)).notes}function Fr(t,e){if(!e)return!1;if(t===e||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function wy(t){const e=vt(!1);let i=null;function n(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function o(A){var Q;const M=t.activeBlockId.value||t.currentDocId.value;if(!M)return;for(const[tt,pt]of Object.entries(A))t.activeBlockAttrs.value[tt]=pt;Mt.setBlockAttrOverride(M,A),Zt(M,A);const X=(Q=t.parentContainerId)==null?void 0:Q.value,J=!!(X&&Fr(M,X));if(jt in A&&J&&X){const tt=A[jt];t.parentContainerClicks&&(t.parentContainerClicks.value=tt),Mt.setBlockAttrOverride(X,{[jt]:tt}),Zt(X,{[jt]:tt}),Et(X,{[jt]:tt}).catch(()=>{})}if(gt in A){const tt=A[gt];t.currentPageDividerLayout.value=tt,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=tt)}if(le in A){const tt=A[le];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=tt)}n("保存中...");try{await Et(M,A),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(A,M){var tt;const X=t.activeBlockId.value||t.currentDocId.value;if(!X)return;t.activeBlockAttrs.value[A]=M,Mt.setBlockAttrOverride(X,{[A]:M}),Zt(X,{[A]:M});const J=(tt=t.parentContainerId)==null?void 0:tt.value,Q=!!(J&&Fr(X,J));A===jt&&Q&&J&&(t.parentContainerClicks&&(t.parentContainerClicks.value=M),Mt.setBlockAttrOverride(J,{[jt]:M}),Zt(J,{[jt]:M}),Et(J,{[jt]:M}).catch(()=>{})),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(X,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const A=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(A?t.activeBlockId.value:"")||t.currentDocId.value}async function r(A,M){const X=l();if(X){X===t.activeBlockId.value&&(t.activeBlockAttrs.value[A]=M),Mt.setBlockAttrOverride(X,{[A]:M}),Zt(X,{[A]:M}),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(X,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(A,M){const X=l();if(!X)return;const J={[gt]:A,[le]:M};X===t.activeBlockId.value&&(t.activeBlockAttrs.value[gt]=A,t.activeBlockAttrs.value[le]=M),t.currentPageDividerLayout.value=A,Mt.setBlockAttrOverride(X,J),Zt(X,J),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=A,t.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await Et(X,J),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(A,M){var J;const X=t.currentDocId.value||t.activeBlockId.value;if(X){t.activeBlockAttrs.value[A]=M,Mt.setBlockAttrOverride(X,{[A]:M}),Zt(X,{[A]:M}),(J=t.latestDoc.value)!=null&&J.config&&(A===wn&&(t.latestDoc.value.config.theme=M),A===xn&&(t.latestDoc.value.config.aspectRatio=M),A===_n&&(t.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await Et(X,{[A]:M}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(X)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Bi]:"true",[ji]:"true"}),t.activeBlockAttrs.value[Bi]="true",t.activeBlockAttrs.value[ji]="true"):(await s(Bi,"false"),t.activeBlockAttrs.value[Bi]="false")}async function f(){const A=t.videoLoop.value?"false":"true";await s(ro,A)}async function v(){const A=t.videoMuted.value?"false":"true";await s(ji,A)}async function d(){const A=t.videoControls.value?"false":"true";await s(lo,A)}async function y(A){var tt;const M=t.activeBlockId.value;if(!M)return;const X=t.rawSnippet.value||"",J=vi(X)||"",Q=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const pt={[qt]:"background",[gt]:""};Q&&J&&(t.pageBackground.value=J,await Et(Q,{[Ut]:J}).catch(()=>{}),Mt.setBlockAttrOverride(Q,{[Ut]:J}),Zt(Q,{[Ut]:J}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=J)),await o(pt)}else(A===ao||A===co)&&await o({[gt]:A,[qt]:""});else{const pt={[qt]:"",[gt]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(pt[Ut]=""),Q&&J&&t.pageBackground.value===J&&(t.pageBackground.value="",await Et(Q,{[Ut]:""}).catch(()=>{}),Mt.setBlockAttrOverride(Q,{[Ut]:""}),Zt(Q,{[Ut]:""}),(tt=t.targetSlide.value)!=null&&tt.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(pt),typeof document<"u"){const lt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),F=lt==null?void 0:lt.closest('[data-type="NodeListItem"]'),at=F==null?void 0:F.getAttribute("data-node-id");if(at&&at!==M){const ut={[gt]:"",[qt]:""};Zt(at,ut),Mt.setBlockAttrOverride(at,ut),await Et(at,ut).catch(()=>{})}}}}async function m(A){var at,ut,C,P,h,z,N,_;const J=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map($=>`> ${$}`).join(`
`)}
{: custom-slidev-note="true"}`,Q=((at=t.latestDoc.value)==null?void 0:at.slides)||[],tt=t.targetSlide.value,pt=tt?Q.findIndex($=>$===tt):-1;let lt=null;if(pt!==-1&&pt<Q.length-1){const $=Q[pt+1];lt=await $i("markdown",J,$.startBlockId)}else{const $=((ut=tt==null?void 0:tt.noteBlocks)==null?void 0:ut.slice(-1)[0])||((C=tt==null?void 0:tt.blocks)==null?void 0:C.slice(-1)[0]),R=($==null?void 0:$.id)||(tt==null?void 0:tt.startBlockId);R?lt=await $i("markdown",J,void 0,R):lt=await es("markdown",J,t.currentDocId.value)}const F=((z=(h=(P=lt==null?void 0:lt[0])==null?void 0:P.doOperations)==null?void 0:h[0])==null?void 0:z.id)||((N=lt==null?void 0:lt[0])==null?void 0:N.id);return F&&(await Et(F,{[ne]:"true"}),Mt.setBlockAttrOverride(F,{[ne]:"true"}),Li(F,(_=t.plugin)==null?void 0:_.app)),t.plugin&&await t.plugin.compileCurrentDocument(),F}async function g(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){n("取消中...");try{await Et(A,{[ne]:"","slidev-note":""}),Mt.setBlockAttrOverride(A,{[ne]:"","slidev-note":""}),Zt(A,{[ne]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=t.rawSnippet.value;try{const tt=await gc(A);tt!=null&&tt.kramdown&&(M=tt.kramdown)}catch{}const Q=`> [!NOTE] 💡 演讲备注
${(ua(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(tt=>`> ${tt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Js("markdown",Q,A),await Et(A,{[ne]:"true"}),Mt.setBlockAttrOverride(A,{[ne]:"true"}),Zt(A,{[ne]:"true"}),t.activeBlockAttrs.value[ne]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await m(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){ht.showMessage("插入讲稿备注块失败"),console.error(A)}}function x(){var X;const A=t.currentSlideNoteBlockId.value;if(!A){ht.showMessage("未找到本页关联的讲稿备注块");return}Li(A,(X=t.plugin)==null?void 0:X.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function I(){var X;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await Ba(A,Vr);if(M.notes){const J=t.currentSlideNoteBlockId.value;if(J){const Q=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(tt=>`> ${tt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Js("markdown",Q,J),await Et(J,{[ne]:"true"}),Mt.setBlockAttrOverride(J,{[ne]:"true"}),Li(J,(X=t.plugin)==null?void 0:X.app)}else await m(M.notes);M.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function T(){var J;if(e.value)return;const A=((J=t.latestDoc.value)==null?void 0:J.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=A.map((Q,tt)=>({slide:Q,idx:tt})).filter(({slide:Q})=>{var lt;const tt=Array.isArray(Q.noteBlocks)&&Q.noteBlocks.length>0,pt=!!((lt=Q.notes)!=null&&lt.trim());return!tt&&!pt});if(M.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const X=M.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${X} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var tt,pt,lt,F,at,ut;if(e.value)return;e.value=!0,ht.showMessage("正在批量追加讲稿块...");let Q=0;try{const h=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(z=>`> ${z}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:z,idx:N}of M)try{let _=null;if(N<A.length-1){const R=A[N+1];_=await $i("markdown",h,R.startBlockId)}else{const R=((tt=z==null?void 0:z.noteBlocks)==null?void 0:tt.slice(-1)[0])||((pt=z==null?void 0:z.blocks)==null?void 0:pt.slice(-1)[0]),Z=(R==null?void 0:R.id)||(z==null?void 0:z.startBlockId);Z?_=await $i("markdown",h,void 0,Z):_=await es("markdown",h,t.currentDocId.value)}const $=((at=(F=(lt=_==null?void 0:_[0])==null?void 0:lt.doOperations)==null?void 0:F[0])==null?void 0:at.id)||((ut=_==null?void 0:_[0])==null?void 0:ut.id);$&&(await Et($,{[ne]:"true"}),Mt.setBlockAttrOverride($,{[ne]:"true"})),Q++}catch(_){console.error(`[SiYuanSlidev] 为第 ${N+1} 页追加讲稿块失败:`,_)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${Q} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",C),ht.showMessage("批量追加讲稿块时出现异常")}finally{e.value=!1}})}async function E(){var Q;if(e.value)return;const A=((Q=t.latestDoc.value)==null?void 0:Q.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=[];for(const tt of A)if(tt.noteBlocks&&tt.noteBlocks.length>0)for(const pt of tt.noteBlocks)pt.id&&M.push({id:pt.id,pageIndex:tt.pageIndex});if(M.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const X=new Set(M.map(tt=>tt.pageIndex)).size,J=M.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${J} 个讲稿备注块（涉及 ${X} 页），删除后无法撤销。是否确认继续？`,async()=>{if(e.value)return;e.value=!0,ht.showMessage("正在批量删除讲稿块...");let tt=0;try{for(const pt of M)try{await Xs(pt.id),Mt.clearBlockAttrOverride(pt.id),tt++}catch(lt){console.error(`[SiYuanSlidev] 删除讲稿块 ${pt.id} 失败:`,lt)}t.activeBlockId.value&&M.some(pt=>pt.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${tt} 个讲稿备注块`)}catch(pt){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",pt),ht.showMessage("批量删除讲稿块时出现异常")}finally{e.value=!1}})}function B(){t.elemClick.value?s(jt,""):s(jt,"+1")}function w(A){s(jt,A)}function H(A){s(Ve,A)}function j(A){(t.activeBlockAttrs.value[Ct]||"")===A?s(Ct,""):s(Ct,A)}function O(A){t.elemShikiLines.value=A,s(Ri,A)}function q(A){t.elemMaxHeight.value=A,s(Sn,A)}async function S(){const A=t.currentSlideLayout.value==="three-cols-header";await s(Ct,A?"col-1":"left"),ht.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function D(){const A=t.activeBlockId.value;if(!A)return;const M={[jt]:"",[Ve]:"",[Ct]:"",[Ri]:"",[Sn]:"",[ne]:"","slidev-note":"",[gt]:"",[le]:"",[qt]:"",[te]:"",[Ut]:"",[Ee]:"",[Bi]:"",[ro]:"",[ji]:"",[lo]:""};if(Zt(A,M),await Et(A,M),Mt.clearBlockAttrOverride(A),typeof document<"u"){const X=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),J=X==null?void 0:X.closest('[data-type="NodeListItem"]'),Q=J==null?void 0:J.getAttribute("data-node-id");Q&&Q!==A&&(Zt(Q,M),await Et(Q,M).catch(()=>{}),Mt.clearBlockAttrOverride(Q))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function b(){if(t.activeBlockId.value)try{await $i("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function W(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await $i("markdown","---",void 0,A),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function Y(){if(t.activeBlockId.value)try{await Xs(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function L(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const A=_a(t.latestDoc.value);Sa("presentation.html",A)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function U(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ca(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function V(){var A,M;try{let X=null;if(typeof document<"u"){const Q=t.activeBlockId.value;if(Q){const tt=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q}"]`);tt&&(X=tt.getAttribute("data-type")==="NodeSuperBlock"?tt:tt.closest('[data-type="NodeSuperBlock"]'))}if(!X){const tt=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(tt){const pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${tt}"]`);if(pt){let lt=pt.nextElementSibling;for(;lt&&!(lt.getAttribute("data-type")==="NodeThematicBreak"||(A=lt.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));){const F=lt.getAttribute("data-type")==="NodeSuperBlock"?lt:lt.querySelector('[data-type="NodeSuperBlock"]');if(F){X=F;break}lt=lt.nextElementSibling}}}else{const pt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),lt=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const F of lt)if(!pt||F.compareDocumentPosition(pt)&Node.DOCUMENT_POSITION_FOLLOWING){X=F;break}}}}const J=[];if(X){const Q=Array.from(X.querySelectorAll(":scope > [data-node-id]"));for(const tt of Q){const pt=tt.getAttribute("data-node-id");pt&&(J.push(pt),tt.removeAttribute("style"))}}else if((M=t.targetSlide.value)!=null&&M.blocks){for(const Q of t.targetSlide.value.blocks)if(Q.children&&Q.children.length>=2){for(const tt of Q.children)tt.id&&J.push(tt.id);break}}if(J.length>0)for(const Q of J)await Et(Q,{style:""}).catch(()=>{});await r(le,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(X){console.error("[useInspectorActions] resetSuperBlockWidth error:",X),ht.showMessage("重置超级块比例失败")}}async function et(){var A,M,X;try{let J=null;if(typeof document<"u"){const tt=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:""),pt=t.activeBlockId.value;let lt=[];if(tt){const ut=document.querySelector(`.protyle-wysiwyg [data-node-id="${tt}"]`);if(ut){let C=ut.nextElementSibling;for(;C&&!(C.getAttribute("data-type")==="NodeThematicBreak"||(A=C.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));)lt.push(C),C=C.nextElementSibling}}else{const ut=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),C=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const P of C)if(!ut||P.compareDocumentPosition(ut)&Node.DOCUMENT_POSITION_FOLLOWING)lt.push(P);else break}const F=[];let at;for(const ut of lt){const C=ut.getAttribute("data-type");C==="NodeHeading"&&(at=ut.getAttribute("data-node-id")||void 0);const P=[];C==="NodeSuperBlock"?P.push(ut):P.push(...Array.from(ut.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const h of P){if((h.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const N=h.getAttribute("data-node-id")||"";let _=[];const $=Array.from(h.querySelectorAll('[data-type="NodeListItem"]'));if($.length===4&&(_=$.map(R=>R.getAttribute("data-node-id")).filter(Boolean)),_.length!==4){const R=Array.from(h.querySelectorAll(":scope > [data-node-id]"));R.length===4&&(_=R.map(Z=>Z.getAttribute("data-node-id")).filter(Boolean))}_.length===4&&F.push({sbId:N,itemIds:_,headerId:at})}}F.length>0&&(pt&&(J=F.find(ut=>{if(ut.sbId===pt||ut.itemIds.includes(pt))return!0;const C=document.querySelector(`.protyle-wysiwyg [data-node-id="${ut.sbId}"]`),P=document.querySelector(`.protyle-wysiwyg [data-node-id="${pt}"]`);return!!(C&&P&&C.contains(P))})||null),J||(J=F[0]))}if(!J&&((M=t.targetSlide.value)!=null&&M.blocks)){const tt=t.targetSlide.value,pt=[];for(const F of tt.blocks)F.rawNode?pt.push(F.rawNode):pt.push({id:F.id,type:F.type,content:F.content,markdown:F.rawMarkdown,children:F.children,ial:F.attributes||F.ial||{}});const lt=ef(pt,t.activeBlockId.value);lt&&lt.items.length===4&&(J={sbId:lt.superBlockNode.id,itemIds:lt.items.map(F=>F.id),headerId:(X=lt.headerNode)==null?void 0:X.id})}if(!J||J.itemIds.length!==4)return ht.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const Q=t.currentPageDividerId.value||t.currentDocId.value;Q&&(t.currentPageDividerLayout.value="clover",t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout="clover"),Mt.setBlockAttrOverride(Q,{[gt]:"clover"}),Zt(Q,{[gt]:"clover"}),await Et(Q,{[gt]:"clover"}).catch(()=>{})),J.headerId&&(Mt.setBlockAttrOverride(J.headerId,{[Ct]:"header"}),Zt(J.headerId,{[Ct]:"header"}),await Et(J.headerId,{[Ct]:"header"}).catch(()=>{}));for(let tt=0;tt<4;tt++){const pt=J.itemIds[tt],lt=`col-${tt+1}`;Mt.setBlockAttrOverride(pt,{[Ct]:lt}),Zt(pt,{[Ct]:lt}),await Et(pt,{[Ct]:lt}).catch(()=>{})}return ht.showMessage("已将本页版式设为四叶草（田字型）布局"),t.plugin&&await t.plugin.compileCurrentDocument(),!0}catch(J){return console.error("[useInspectorActions] applyCloverLayout error:",J),ht.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:et,resetSuperBlockWidth:V,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:f,onToggleVideoMuted:v,onToggleVideoControls:d,onImageRoleChange:y,onToggleNoteBlock:g,createNoteBlockOnCurrentSlide:m,onAddNoteBlock:k,onLocateNoteBlock:x,onGenerateNotesWithAI:I,isBatchProcessing:e,onBatchAppendNotes:T,onBatchDeleteNotes:E,toggleElemClick:B,onElemClickStepChange:w,onElemMotionChange:H,onElemSlotChange:j,onElemShikiLinesChange:O,onElemMaxHeightChange:q,onSetTwoColsContrast:S,onClearBlockAttrs:D,onInsertDividerBefore:b,onInsertDividerAfter:W,onDeleteCurrentBlock:Y,onExportHtml:L,onExportPdf:U}}const xy={class:"spm-slidev-inspector"},_y={class:"spm-inspector-topbar"},Sy={class:"spm-inspector-title"},Cy={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},$y={class:"spm-inspector-topbar-actions"},Iy={class:"spm-target-banner"},Ay={class:"spm-target-info"},By=["aria-label"],Ty={key:0,class:"spm-save-status"},Ey=["title"],My={class:"spm-inspector-body"},Dy=Ce({__name:"SlidevInspectorDockView",setup(t,{expose:e}){const i=ti("plugin"),n=vt(!1);function o(ot){n.value=!1,c.value=ot.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(ot.docId)}const s=vt(""),l=vt(""),r=vt({}),a=vt(""),c=vt(""),u=vt(""),f=vt(""),v=vt(""),d=vt(""),y=vt(""),m=vt(""),g=vt(null),k=vt(""),x=vt("");function I(){var kt;const ot=s.value||c.value;ot&&typeof navigator<"u"&&(kt=navigator==null?void 0:navigator.clipboard)!=null&&kt.writeText&&navigator.clipboard.writeText(ot).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const T=St(()=>Aa(l.value)),E=St(()=>l.value==="NodeCodeBlock"),B=vt(!1),w=St(()=>{if(B.value||rt.value)return!0;const ot=a.value||"";return!!vi(ot)}),H=St(()=>{const ot=l.value||"";if(ot==="NodeVideo"||ot==="video")return!0;const kt=a.value||"";return!!(/<video\b/i.test(kt)||/\.mp4\b/i.test(kt))}),j=St(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),O=St(()=>{const ot=s.value||c.value||"";return ot.length>8?ot.slice(-8):ot||"无"}),q=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=St(()=>{if(T.value)return"分页符 (---)";if(j.value)return"全局文档";if(H.value)return"视频块";let ot="内容块";switch(l.value){case"NodeHeading":ot="标题块";break;case"NodeParagraph":ot="段落块";break;case"NodeCodeBlock":ot="代码块";break;case"NodeVideo":ot="视频块";break;case"NodeList":case"NodeListItem":ot="列表项";break;case"NodeBlockquote":ot="引述块";break;case"NodeTable":ot="表格块";break;case"NodeSuperBlock":case"s":case"sb":ot="超级块";break;default:ot="内容块";break}return d.value?y.value?`${y.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ot}`:`分栏容器 › ${ot}`:ot}),D=St(()=>T.value?"tag-divider":j.value?"tag-doc":"tag-block"),b=St(()=>r.value[gt]||"default"),W=St(()=>r.value[te]||"slide-left"),Y=vt(""),L=vt(""),U=St(()=>r.value[un]||"inherit"),V=St(()=>{var ot;return yy((ot=g.value)==null?void 0:ot.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),et=St(()=>{var ot;return((ot=V.value)==null?void 0:ot.notes)||""}),A=St(()=>{var ot,kt,It;return((It=(kt=(ot=V.value)==null?void 0:ot.noteBlocks)==null?void 0:kt[0])==null?void 0:It.id)||""}),M=St(()=>{var Dt,Ft,Rt,fe,Fn,ci;if(T.value){const Qt=r.value[gt]||r.value["custom-slidev-layout"];if(Qt)return Qt}const ot=r.value[Ct]||r.value["custom-slidev-slot"];if(ot&&(["col-1","col-2","col-3"].includes(ot)||/^col-\d+$/.test(ot)))return"cols-header";if(v.value)return v.value;const kt=f.value||(T.value?s.value:"");if(kt){const Qt=Mt.getBlockAttrOverride(kt);if(Qt!=null&&Qt[gt])return Qt[gt]}if(kt&&((Dt=g.value)!=null&&Dt.slides)){const Qt=g.value.slides.find(Ni=>Ni.startBlockId===kt);if((Ft=Qt==null?void 0:Qt.frontmatter)!=null&&Ft.layout)return Qt.frontmatter.layout}if((fe=(Rt=V.value)==null?void 0:Rt.frontmatter)!=null&&fe.layout)return V.value.frontmatter.layout;if((ci=(Fn=V.value)==null?void 0:Fn.blocks)!=null&&ci.some(Qt=>Qt.slot&&(["col-1","col-2","col-3"].includes(Qt.slot)||/^col-\d+$/.test(Qt.slot))))return"cols-header";const It=Mt.getBlockAttrOverride(c.value);return It!=null&&It[gt]?It[gt]:"default"}),X=St(()=>{var kt,It;if(T.value){const Dt=r.value[le]||r.value["custom-slidev-layout-ratio"];if(Dt)return Dt}const ot=f.value||(T.value?s.value:"");if(ot){const Dt=Mt.getBlockAttrOverride(ot);if(Dt!=null&&Dt[le])return Dt[le]}return((It=(kt=V.value)==null?void 0:kt.frontmatter)==null?void 0:It.layoutRatio)||""});function J(ot){if(!ot||(ot.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const It=Array.from(ot.querySelectorAll(":scope > [data-node-id]"));if(It.length<2)return null;const Dt=It.length,Ft=It.map(ci=>{const Qt=ci.getAttribute("style")||"",Ni=Qt.match(/calc\(\s*([\d.]+)%/);if(Ni)return parseFloat(Ni[1]);const on=Qt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return on?parseFloat(on[1]):null});let Rt="",fe=!1;if(Ft.some(ci=>ci!==null)){fe=!0;const ci=Ft.reduce((Tt,pe)=>Tt+(pe||0),0),Qt=Ft.filter(Tt=>Tt===null).length,Ni=Qt>0?Math.max(0,100-ci)/Qt:100/It.length,on=Ft.map(Tt=>Tt!==null?Tt:Ni),rc=on.reduce((Tt,pe)=>Tt+pe,0)||1,sn=on.map(Tt=>Tt/rc*100);if(sn.length===2){const[Tt]=sn;if(Tt>=48&&Tt<=52)Rt="1:1";else if(Tt>=31&&Tt<=35)Rt="1:2";else if(Tt>=65&&Tt<=69)Rt="2:1";else if(Tt>=28&&Tt<=32)Rt="3:7";else if(Tt>=68&&Tt<=72)Rt="7:3";else if(Tt>=38&&Tt<=42)Rt="4:6";else if(Tt>=58&&Tt<=62)Rt="6:4";else{const pe=Math.round(Tt);Rt=`${pe}:${100-pe}`}}else if(sn.length===3){const[Tt,pe,di]=sn;if(Tt>=31&&Tt<=35&&pe>=31&&pe<=35&&di>=31&&di<=35)Rt="1:1:1";else if(Tt>=23&&Tt<=27&&pe>=48&&pe<=52&&di>=23&&di<=27)Rt="1:2:1";else if(Tt>=48&&Tt<=52&&pe>=23&&pe<=27&&di>=23&&di<=27)Rt="2:1:1";else if(Tt>=23&&Tt<=27&&pe>=23&&pe<=27&&di>=48&&di<=52)Rt="1:1:2";else{const Zs=Math.round(Tt),Ys=Math.round(pe);Rt=`${Zs}:${Ys}:${100-Zs-Ys}`}}else Rt=sn.map(Tt=>Math.round(Tt)).join(":")}else fe=!1,Rt=Array.from({length:Dt},()=>1).join(":");const Fn=Dt>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Dt,ratio:Rt,isCustomWidth:fe,recommendedLayout:Fn}}function Q(ot){if(!(ot!=null&&ot.blocks))return null;for(const kt of ot.blocks){const It=kt.rawNode;if(It&&oe(It)&&Ke(It)){const Ft=nn(It).length,Rt=Fs(It);return{hasSuperBlock:!0,colCount:Ft,ratio:Rt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Rt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const tt=St(()=>{var ot;if(typeof document<"u"){const kt=s.value;if(kt){const Dt=document.querySelector(`.protyle-wysiwyg [data-node-id="${kt}"]`);if(Dt){const Ft=Dt.getAttribute("data-type")==="NodeSuperBlock"?Dt:Dt.closest('[data-type="NodeSuperBlock"]');if(Ft){const Rt=J(Ft);if(Rt)return Rt}}}const It=f.value||(T.value?s.value:"");if(It){const Dt=document.querySelector(`.protyle-wysiwyg [data-node-id="${It}"]`);if(Dt){let Ft=Dt.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(ot=Ft.classList)!=null&&ot.contains("protyle-wysiwyg__block--hr"));){const Rt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Rt){const fe=J(Rt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const Dt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Rt of Ft)if(!Dt||Rt.compareDocumentPosition(Dt)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=J(Rt);if(fe)return fe}}}return Q(V.value)}),pt=St(()=>{var ot;return((ot=tt.value)==null?void 0:ot.ratio)||""}),lt=St(()=>{const ot=l.value||"";if(ot==="NodeSuperBlock"||ot==="s"||ot==="sb")return!0;if(typeof document<"u"&&s.value){const kt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(kt!=null&&kt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),F=St(()=>{var ot;return((ot=V.value)==null?void 0:ot.pageIndex)||1}),at=St(()=>!!(r.value[ne]||r.value["slidev-note"]));function ut(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const ot=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!ot)return!1;const kt=ot.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(kt==null?void 0:kt.getAttribute("data-node-id"))===s.value}const C=St(()=>{var kt;if(r.value[jt]!==void 0)return r.value[jt]||"";if(d.value&&ut())return m.value||"";if(d.value)return"";const ot=s.value;if(ot&&((kt=V.value)!=null&&kt.blocks)){const It=V.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.clicks)return It.clicks}return""}),P=St(()=>{var kt;if(r.value[Ve])return r.value[Ve];const ot=s.value;if(ot&&((kt=V.value)!=null&&kt.blocks)){const It=V.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.motion)return typeof It.motion=="string"?It.motion:JSON.stringify(It.motion)}return""}),h=St(()=>{var kt;if(r.value[Ct])return r.value[Ct];const ot=s.value;if(ot&&((kt=V.value)!=null&&kt.blocks)){const It=V.value.blocks.find(Dt=>Dt.id===ot);if(It!=null&&It.slot)return It.slot}return""}),z=vt(""),N=vt(""),_=St(()=>r.value[Bi]==="true"),$=St(()=>r.value[ro]==="true"),R=St(()=>r.value[ji]==="true"),Z=St(()=>r.value[lo]!=="false"),G=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.theme)||r.value[wn]||"default"}),K=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.aspectRatio)||r.value[xn]||"16/9"}),it=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.defaultTransition)||r.value[_n]||"slide-left"}),ct=St(()=>{var ot,kt;return((kt=(ot=g.value)==null?void 0:ot.config)==null?void 0:kt.spacing)||r.value[ns]||"normal"}),rt=St(()=>{var Ft,Rt;if((r.value[qt]||r.value["slidev-role"])===Zr||r.value[Ut]==="true")return"background";const kt=r.value[gt]||r.value["slidev-layout"];if(kt==="image-left"||kt==="image-right")return kt;const It=a.value||"",Dt=vi(It);if(Dt&&((Rt=(Ft=V.value)==null?void 0:Ft.frontmatter)!=null&&Rt.background)){const fe=V.value.frontmatter.background;if(fe===Dt||fe.endsWith(Dt)||Dt.endsWith(fe))return"background"}return""}),mt=St(()=>!!(r.value[jt]||r.value[Ve]||r.value[Ct]||r.value[Ri]||r.value[ne]||r.value["slidev-note"]||r.value[qt]||r.value[gt]||r.value[Bi]||r.value[ro]||r.value[ji]||r.value[lo])),{saveAttr:_t,savePageAttr:wt,applyPageLayoutAndRatio:Lt,applyCloverLayout:Gt,resetSuperBlockWidth:Yt,saveDocAttr:ie,onToggleVideoAutoplay:Nt,onToggleVideoLoop:Ge,onToggleVideoMuted:se,onToggleVideoControls:Xt,onImageRoleChange:yi,onToggleNoteBlock:Oi,onAddNoteBlock:Ro,onLocateNoteBlock:Po,onGenerateNotesWithAI:Nn,isBatchProcessing:ki,onBatchAppendNotes:zi,onBatchDeleteNotes:Da,toggleElemClick:La,onElemClickStepChange:Ra,onElemMotionChange:Pa,onElemSlotChange:Oa,onElemShikiLinesChange:za,onElemMaxHeightChange:Na,onSetTwoColsContrast:Fa,onClearBlockAttrs:Ha,onInsertDividerBefore:ja,onInsertDividerAfter:qs,onDeleteCurrentBlock:Ua,onExportHtml:Wa,onExportPdf:Va}=wy({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:v,parentContainerId:d,parentContainerClicks:m,latestDoc:g,targetSlide:V,currentSlideNoteBlockId:A,currentSlideLayout:M,isNoteBlock:at,elemClick:C,videoAutoplay:_,videoLoop:$,videoMuted:R,videoControls:Z,pageBackground:Y,pageImage:L,elemShikiLines:z,elemMaxHeight:N,saveStatus:k,plugin:i});async function qa(ot){if(ot==="clover"){if(!await Gt())return}else _t(gt,ot)}function Ka(ot){wt(le,ot)}function Ks(ot){if(!ot)return;const kt=ot.recommendedLayout||(ot.colCount&&ot.colCount>=2?"cols-header":"two-cols"),It=ot.ratio||(ot.colCount?Array(ot.colCount).fill(1).join(":"):"1:1");Lt(kt,It)}function Ga(ot){wt(le,ot)}async function Za(){await Yt()}function Ya(ot){_t(te,ot)}function Ja(ot){Y.value=ot,_t(Ut,ot)}function Xa(ot){L.value=ot,_t(Ee,ot)}function Qa(ot){_t(un,ot==="inherit"?"":ot)}function tc(ot){ie(wn,ot)}function ec(ot){ie(xn,ot)}function ic(ot){ie(_n,ot)}function nc(ot){ie(ns,ot)}function Gs(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function oc(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function sc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return e({setActiveBlock(ot){s.value=ot.id,l.value=ot.type,r.value={...ot.attrs},a.value=ot.content||ot.markdown||"",u.value=ot.topBlockId||ot.id,f.value=ot.pageDividerId||"",v.value=ot.pageDividerLayout||"",d.value=ot.parentContainerId||"",y.value=ot.parentContainerSlot||"",m.value=ot.parentContainerClicks||"",ot.rootId?c.value=ot.rootId:(ot.type==="doc"||ot.type==="NodeDocument")&&ot.id&&(c.value=ot.id),Y.value=ot.attrs[Ut]||"",L.value=ot.attrs[Ee]||"",z.value=ot.attrs[Ri]||"",N.value=ot.attrs[Sn]||"",B.value=!!ot.isImage},updateDocument(ot){g.value=ot,c.value=ot.docId},openImportDialog(){n.value=!0},setCurrentDocId(ot){c.value=ot}}),(ot,kt)=>(nt(),st("div",xy,[p("div",_y,[p("div",Sy,[(nt(),st("svg",Cy,[...kt[2]||(kt[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),kt[3]||(kt[3]=p("span",null,"演示配置",-1))]),p("div",$y,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:kt[0]||(kt[0]=It=>n.value=!0)},[dt(ft,{name:"import"}),kt[4]||(kt[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Gs},[dt(ft,{name:"split-preview"}),kt[5]||(kt[5]=p("span",null,"分屏预览",-1))])])]),p("div",Iy,[p("div",Ay,[p("span",{class:At(["spm-target-tag",D.value])},xt(S.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:I},[dt(ft,{name:"copy"}),p("span",null,"#"+xt(O.value),1)],8,By)]),k.value?(nt(),st("span",Ty,"● "+xt(k.value),1)):Pt("",!0)]),q.value?(nt(),st("div",{key:0,class:"spm-context-quote",title:a.value},xt(q.value),9,Ey)):Pt("",!0),p("div",My,[T.value?(nt(),De(Vg,{key:0,"page-layout":b.value,"page-layout-ratio":X.value,"detected-sb-ratio":pt.value,"detected-sb-info":tt.value,"page-transition":W.value,"page-background":Y.value,"page-spacing":U.value,"page-image":L.value,"page-notes":et.value,"page-index":F.value,"onUpdate:pageLayout":qa,"onUpdate:pageLayoutRatio":Ka,onApplySuperBlockLayout:Ks,onResetSuperblockRatio:Za,"onUpdate:pageTransition":Ya,"onUpdate:pageBackground":Ja,"onUpdate:pageSpacing":Qa,"onUpdate:pageImage":Xa,onAddNoteBlock:bt(Ro),onLocateNoteBlock:bt(Po),onGenerateNotes:bt(Nn),onBatchAppendNotes:bt(zi),onBatchDeleteNotes:bt(Da),"is-batch-processing":bt(ki),onInsertDividerAfter:bt(qs),onDeleteDivider:bt(Ua)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!j.value?(nt(),De(Bb,{key:1,"elem-click":C.value,"elem-motion":P.value,"elem-slot":h.value,"elem-shiki-lines":z.value,"elem-max-height":N.value,"is-code-block":E.value,"is-image":w.value,"is-video":H.value,"is-super-block":lt.value,"detected-sb-info":tt.value,"video-autoplay":_.value,"video-loop":$.value,"video-muted":R.value,"video-controls":Z.value,"has-block-attrs":mt.value,"is-note":at.value,"image-role":rt.value,"current-slide-layout":M.value,"parent-elem-click":m.value,"parent-container-slot":y.value,"parent-container-id":d.value,onToggleNote:bt(Oi),onToggleElemClick:bt(La),onToggleVideoAutoplay:bt(Nt),onToggleVideoLoop:bt(Ge),onToggleVideoMuted:bt(se),onToggleVideoControls:bt(Xt),"onUpdate:imageRole":bt(yi),"onUpdate:elemClick":bt(Ra),"onUpdate:elemMotion":bt(Pa),"onUpdate:elemSlot":bt(Oa),"onUpdate:elemShikiLines":bt(za),"onUpdate:elemMaxHeight":bt(Na),onApplySuperBlockLayout:Ks,onApplySuperBlockRatio:Ga,onInsertDividerBefore:bt(ja),onInsertDividerAfter:bt(qs),onSetTwoColsContrast:bt(Fa),onClearBlockAttrs:bt(Ha)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(nt(),De(p1,{key:2,"doc-theme":G.value,"doc-aspect-ratio":K.value,"doc-default-transition":it.value,"doc-spacing":ct.value,"onUpdate:docTheme":tc,"onUpdate:docAspectRatio":ec,"onUpdate:docDefaultTransition":ic,"onUpdate:docSpacing":nc,onOpenBottomPreview:Gs,onOpenPresenter:oc,onAiAutoSplit:sc,onExportHtml:bt(Wa),onExportPdf:bt(Va)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(nt(),De(by,{key:1,onClose:kt[1]||(kt[1]=It=>n.value=!1),onSuccess:o})):Pt("",!0)]))}}),Ly=2e3;function Qo(t){if(!t||typeof t.isConnected=="boolean"&&!t.isConnected)return!1;if(Hr(t))return!0;const e=t.firstElementChild;return!!(e&&Hr(e))}function Hr(t){return typeof t.getClientRects=="function"&&t.getClientRects().length>0?!0:typeof t.offsetWidth=="number"&&t.offsetWidth>0&&t.offsetHeight>0}function Ry(){const t=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof t=="function"?t:void 0}class Py{constructor(){yt(this,"consumers",new Map);yt(this,"seq",0);yt(this,"verifyTimer",null)}register(e,i,n){if(!i)return()=>{};const o=++this.seq,s=Ry(),l={kind:e,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(i)):l.visible=Qo(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var e;for(const i of this.consumers.values())(e=i.observer)==null||e.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}hasVisibleConsumer(){if(this.consumers.size===0||typeof document<"u"&&document.visibilityState==="hidden")return!1;for(const e of this.consumers.values())if(e.measureOnDemand?Qo(e.element):e.visible)return!0;return this.ensureVerifyTimer(),!1}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let e=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){e=!0;break}e&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&Qo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Ly))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const eo=new Py,zn=new Ws;function Ta(t,e,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=eo.register(t,e,n);return n(),o}let mi=null,We=null,io=null;function Oy(t,e){mi&&Ea(),mi=sa(qm),mi.provide("plugin",e),mi.provide("sandboxBridge",zn);const i=mi.mount(t);return We=i,io=Ta("preview",t,e),i}function Ea(t){io&&(io(),io=null),mi&&(mi.unmount(),mi=null,We=null)}let gi=null,_e=null,no=null;function zy(t,e){gi&&Ma(),gi=sa(Dy),gi.provide("plugin",e),gi.provide("sandboxBridge",zn);const i=gi.mount(t);return _e=i,no=Ta("dock",t,e),i}function Ma(t){no&&(no(),no=null),gi&&(gi.unmount(),gi=null,_e=null)}function Ny(t,e){_e!=null&&_e.updateDocument&&_e.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,e):zn.updateSlides(t.slides,t.config,t.fullMarkdown)}function bs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):zn.highlightElement(t)}function oo(t){_e!=null&&_e.setActiveBlock&&_e.setActiveBlock(t)}function Fy(){return _e!=null&&_e.openImportDialog?(_e.openImportDialog(),!0):!1}function Hy(t,e){const i=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(ko(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];ko(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const jy=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"cover"},{key:te,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"two-cols"},{key:te,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"fact"},{key:te,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"intro"},{key:te,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ai,value:"true"},{key:gt,value:"quote"},{key:te,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:jt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:jt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ct,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ri,value:"1-3"}]}];class ts{getPresetTemplates(){return jy}buildScanSlidevBlocksSql(e="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${e}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${te}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${te}' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[te]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const e=this.getPresetTemplates();return JSON.stringify({templates:e,counter:e.length},null,2)}formatTransitionSummary(e){return!e||e.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${e.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Uy(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Fy()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Et(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const e=await so(t.currentDocId).catch(()=>[]);if(!e||e.length===0){ht.showMessage("当前文档无内容，无需断页");return}const i=e.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=Hy(i);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await $i("markdown","---",void 0,s.blockId),await Et(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,f;if(!t.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const e=await so(t.currentDocId).catch(()=>[]),i={startBlockId:t.currentDocId,blocks:e.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await ky(i,Vr)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await es("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((f=l==null?void 0:l[0])==null?void 0:f.id);r&&(await Et(r,{"custom-slidev-note":"true"}),Mt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Li(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new ts,i=e.buildTransitionStatsSql(),n=await kn(i).catch(()=>[]),o=e.formatTransitionSummary(n||[]);ht.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new ts().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new ts().batchUpdateTransitions("fade","slide-left",n=>kn(n).catch(()=>[]),(n,o)=>Et(n,o));ht.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const e=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",is);e.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${e.path}`):ht.showMessage(`同步失败：${e.error}`)}})}class Wy{constructor(e=400){yt(this,"entries",new Map);this.ttlMs=e}get(e,i=Date.now()){if(!e)return;const n=this.entries.get(e);if(n){if(i-n.at>this.ttlMs){this.entries.delete(e);return}return n.attrs}}set(e,i,n=Date.now()){!e||!i||this.entries.set(e,{attrs:i,at:n})}invalidate(e){e?this.entries.delete(e):this.entries.clear()}get size(){return this.entries.size}}function Vy(t){const e=new Map;if(!(t!=null&&t.slides))return e;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&e.set(o.id,o.ial)};for(const n of t.slides)i(n.blocks),i(n.noteBlocks);return e}class qy{constructor(e=150){yt(this,"lastBlockId","");yt(this,"lastAt",0);this.windowMs=e}shouldSkip(e,i=Date.now()){return e&&e===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=e,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class Ky{constructor(){yt(this,"attrCache",new Wy);yt(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(e,i){if(!e)return{};const n=Mt.getBlockAttrOverride(e),o=this.getCompiledIal(i,e);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(e);if(s)return s;const l=await ys(e).catch(()=>({}))||{};return this.attrCache.set(e,l),l}getCompiledIal(e,i){if(e)return this.compiledIalIndex.doc!==e&&(this.compiledIalIndex={doc:e,map:Vy(e)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(e){this.attrCache.invalidate(e)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=e==null?void 0:e.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(e,i=""){const n=e.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=e.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(e,i){var s;if(!e)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(e,null);oo({id:e,rootId:e,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),bs(e)}handleBlockClickedFromSlide(e,i,n,o){var a;if(!e)return!1;const s=Li(e,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,e,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const f=o.slides.find(v=>{var d,y,m;return v.startBlockId===e||((d=v.blocks)==null?void 0:d.some(g=>g.id===e))||((y=v.allBlockIds)==null?void 0:y.includes(e))||((m=v.noteBlocks)==null?void 0:m.some(g=>g.id===e))});f!=null&&f.startBlockId&&(c=f.startBlockId),(a=f==null?void 0:f.frontmatter)!=null&&a.layout&&(u=f.frontmatter.layout)}this.resolveBlockAttrs(e,o).then(async f=>{if(c&&!u){const v=Mt.getBlockAttrOverride(c);if(v!=null&&v[gt]||v!=null&&v["custom-slidev-layout"])u=v[gt]||v["custom-slidev-layout"]||"";else{const d=await this.resolveBlockAttrs(c,o);u=d[gt]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Mt.setBlockAttrOverride(c,d)}}oo({id:e,rootId:n,type:r||"NodeParagraph",attrs:f||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(e,i,n,o,s){var W,Y,L,U,V,et,A,M;let l=e,r=i,a=n;const c=e.closest('[data-type="NodeCallout"]');if(c&&c!==e){const X=c.getAttribute("data-node-id");if(X){const J=await this.resolveBlockAttrs(X,s),Q=Mt.getBlockAttrOverride(X)||{},tt={...J,...Q};(tt[ne]||tt["slidev-note"])&&(l=c,r=X,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((W=u==null?void 0:u.classList)!=null&&W.contains("hr")),d=a==="NodeCodeBlock",y=((Y=l.innerText)==null?void 0:Y.trim())||"",m=await this.resolveBlockAttrs(r,s),g=Mt.getBlockAttrOverride(r)||{},k={...m,...g};let x="",I="";if(v)x=r,I=k[gt]||k["custom-slidev-layout"]||"";else{let X=u.previousElementSibling;for(;X;){const J=X.getAttribute("data-type");if(J==="NodeThematicBreak"||J==="tb"||(L=X.classList)!=null&&L.contains("hr")){x=X.getAttribute("data-node-id")||"";break}X=X.previousElementSibling}}if(s!=null&&s.slides){const X=[r,f];let J=l.parentElement;for(;J&&!J.classList.contains("protyle-wysiwyg");){const tt=J.getAttribute("data-node-id");tt&&!X.includes(tt)&&X.push(tt),J=J.parentElement}const Q=s.slides.find(tt=>{var pt,lt,F;return X.includes(tt.startBlockId)||((pt=tt.blocks)==null?void 0:pt.some(at=>X.includes(at.id)))||((lt=tt.allBlockIds)==null?void 0:lt.some(at=>X.includes(at)))||((F=tt.noteBlocks)==null?void 0:F.some(at=>X.includes(at.id)))});Q&&(!x&&Q.startBlockId&&(x=Q.startBlockId),!I&&((U=Q.frontmatter)!=null&&U.layout)&&(I=Q.frontmatter.layout))}if(x){const X=Mt.getBlockAttrOverride(x);if(X&&(gt in X||"custom-slidev-layout"in X)&&(I=X[gt]||X["custom-slidev-layout"]||""),!I&&(s!=null&&s.slides)){const J=s.slides.find(Q=>Q.startBlockId===x);(V=J==null?void 0:J.frontmatter)!=null&&V.layout&&(I=J.frontmatter.layout)}if(!I){const J=await this.resolveBlockAttrs(x,s);I=J[gt]||J["custom-slidev-layout"]||"",J&&Object.keys(J).length>0&&Mt.setBlockAttrOverride(x,J)}Zt(x,{[gt]:I||""})}else if(o){const X=Mt.getBlockAttrOverride(o);X&&(gt in X||"custom-slidev-layout"in X)?I=X[gt]||X["custom-slidev-layout"]||"":!I&&((M=(A=(et=s==null?void 0:s.slides)==null?void 0:et[0])==null?void 0:A.frontmatter)!=null&&M.layout)&&(I=s.slides[0].frontmatter.layout)}const T=l.getAttribute(gt)||l.getAttribute("custom-slidev-layout"),E=k[gt]||k["custom-slidev-layout"]||"";T&&T!==E&&Zt(r,{[gt]:E});const B=l.getAttribute(qt)||l.getAttribute("custom-slidev-role"),w=k[qt]||k["custom-slidev-role"]||"";B&&B!==w&&Zt(r,{[qt]:w});let H="",j="",O="";const q=l.closest('[data-type="NodeListItem"]');if(q&&q!==l){const X=q.getAttribute("data-node-id");if(X){H=X;const J=await this.resolveBlockAttrs(X,s),Q=Mt.getBlockAttrOverride(X)||{},tt={...J,...Q};j=tt[Ct]||"",O=tt[jt]||"";const pt=tt[gt]||tt["custom-slidev-layout"]||"",lt=q.getAttribute(gt)||q.getAttribute("custom-slidev-layout");lt&&lt!==pt&&Zt(X,{[gt]:pt});const F=tt[qt]||tt["custom-slidev-role"]||"",at=q.getAttribute(qt)||q.getAttribute("custom-slidev-role");at&&at!==F&&Zt(X,{[qt]:F})}}const S=!!l.querySelector("img, span[data-type='img']"),D=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),b=S&&D.length<=50;oo({id:r,rootId:o,type:a,content:y,attrs:k,isDivider:v,isCode:d,isImage:b,topBlockId:f,pageDividerId:x,pageDividerLayout:I,parentContainerId:H,parentContainerSlot:j,parentContainerClicks:O})}patchThematicBreakTransactions(e){if((e==null?void 0:e.cmd)==="transactions"&&Array.isArray(e.data)){for(const i of e.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");Zt(n.id,l),Mt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(e){var o,s,l;if(typeof document>"u"||!e)return;const i=new Map;if(Array.isArray(e.slides))for(const r of e.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[gt]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[gt]&&(c[gt]=a.ial[gt]),(l=a.ial)!=null&&l[qt]&&(c[qt]=a.ial[qt]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Mt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[gt]!==void 0&&(c[gt]=a[gt]),a[qt]!==void 0&&(c[qt]=a[qt]),i.set(r,c)}Up(i)}}const Ci=new Ky;class Gy{constructor(){yt(this,"inFlightDocId",null);yt(this,"pendingDocId",null);yt(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(e){return this.inFlightDocId!==null?(this.pendingDocId=e,null):(this.inFlightDocId=e,++this.generation)}isStale(e){return e!==this.generation}finish(){this.inFlightDocId=null;const e=this.pendingDocId;return this.pendingDocId=null,e}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const Zy=150,Yy=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Jy="slidev-dock",jr="slidev-preview-tab",Ur=Gu;class Xy extends ht.Plugin{constructor(){super(...arguments);yt(this,"isMobile",!1);yt(this,"currentDocId","");yt(this,"latestCompiledDoc",null);yt(this,"cliBridge",new Hs);yt(this,"debounceTimer",null);yt(this,"activeCursorBlockId","");yt(this,"compileScheduler",new Gy);yt(this,"dirtyDocId",null);yt(this,"inspectorSyncThrottle",new qy);yt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));yt(this,"onWsMainBound",this.onWsMain.bind(this));yt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));yt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));yt(this,"onEditorClickBound",this.onEditorClick.bind(this));yt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));yt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));yt(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ht.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Yy),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Uy(this);const n=this;if(this.addTab({type:jr,init(){Oy(this.element,n)},destroy(){Ea(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Jy,init(){zy(this.element,n)},destroy(){Ma(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Ur),n=Zu(i);return Ti(n),n}catch{return Ti(Qi),Qi}}async saveGlobalSettings(i){const n=Lo(),o=Ti({...n,...i||{}});try{await this.saveData(Ur,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,eo.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),zn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ht.openTab({app:this.app,custom:{id:this.name+jr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(i){var l;const n=i.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Et(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Et(s,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Et(s,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Et(s,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(i){var s,l;const n=(s=i.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await ys(o).catch(()=>({}));oo({id:o,rootId:o,type:"doc",attrs:r}),this.markCompileDirty(o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return Ci.getActiveDocumentId()}resolveDocIdFromElement(i){return Ci.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ci.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ci.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=Zy){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.dirtyDocId&&eo.hasVisibleConsumer()&&(this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const n=this.dirtyDocId;this.dirtyDocId=null,n&&this.compileCurrentDocument(n,{reason:"auto"})},i))}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ci.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const f=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=f==null?void 0:f.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,bs(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const f=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=f==null?void 0:f.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,bs(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ci.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&!eo.hasVisibleConsumer()){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Mt.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Ny(r,s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ci.purgeStaleDomSlidevAttrs(i)}}module.exports=Xy;
