"use strict";var qc=Object.create;var Js=Object.defineProperty;var Yc=Object.getOwnPropertyDescriptor;var Zc=Object.getOwnPropertyNames;var Jc=Object.getPrototypeOf,Xc=Object.prototype.hasOwnProperty;var Qc=(e,t,i)=>t in e?Js(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var ed=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Zc(t))!Xc.call(e,s)&&s!==i&&Js(e,s,{get:()=>t[s],enumerable:!(n=Yc(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?qc(Jc(e)):{},ed(t||!e||!e.__esModule?Js(i,"default",{value:e,enumerable:!0}):i,e));var ke=(e,t,i)=>Qc(e,typeof t!="symbol"?t+"":t,i);const ce=require("siyuan");async function mt(e,t){const i=await ce.fetchSyncPost(e,t);return i.code===0?i.data:null}async function td(){return mt("/api/notebook/lsNotebooks","")}async function id(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function hl(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return mt("/api/asset/upload",i)}async function Li(e,t,i,n,s){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function bo(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function yo(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ml(e){return mt("/api/block/deleteBlock",{id:e})}async function nd(e){return mt("/api/block/getBlockKramdown",{id:e})}async function Yn(e){return mt("/api/block/getChildBlocks",{id:e})}async function sd(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function Fe(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function jo(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function an(e){return mt("/api/query/sql",{stmt:e})}async function ko(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function gl(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function od(){return mt("/api/storage/getInlineStyles","")}const vl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function rd(e){const t=[];if(!e)return t;const i=new RegExp(vl.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function ld(e,t){if(!e)return"";const i=new RegExp(vl.source,"g");return e.replace(i,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(t&&t[s]){const d=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const On="custom-slides-theme",Rn="custom-slides-aspect-ratio",bl="custom-slides-highlighter",Nn="custom-slides-default-transition",yl="custom-slides-color-schema",wo="custom-slides-spacing",Bi="custom-slides-slide",we="custom-slides-layout",pt="custom-slides-transition",it="custom-slides-background",Lt="custom-slides-image",Xs="custom-slides-notes",Xi="custom-slides-class",$n="custom-slides-spacing",yt="custom-slides-layout-ratio",Qi="custom-slides-mask",Ri="custom-slides-mask-ratio",en="custom-slides-mask-style",tn="custom-slides-mask-initial",Ze="custom-slides-click",Yt="custom-slides-motion",Wi="custom-slides-shiki-lines",$e="custom-slides-slot",Ke="custom-slides-note",Ye="custom-slides-role",zn="custom-slides-max-height",Di="custom-slides-autoplay",ws="custom-slides-loop",Ji="custom-slides-muted",xs="custom-slides-controls",kl="background",Ss="image-left",Cs="image-right";function Hn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function ad(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const l=o.every((h,u)=>u===0||h>o[u-1]),r=o[o.length-1];if(l&&(r===100||o.some(h=>h>10))){const h=o.map(u=>Math.min(100,Math.round(u*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,u)=>h+u,0);if(c<=0)return{steps:n,breakpoints:i};let d=0;const p=[];for(let h=0;h<o.length;h++)d+=o[h],h===o.length-1?p.push(100):p.push(Math.round(d/c*1e4)/100);return{steps:p.length,breakpoints:p}}function cd(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function dd(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function wl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function xl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Mt(e,t){if(!wl(e))return e;const i=xl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function ud(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Mt(o,t);return`![${s}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Mt(o,t);return`${s}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Mt(o,t);return`${s}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ve={},nn=[],Zt=()=>{},Sl=()=>!1,Ls=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ps=e=>e.startsWith("onUpdate:"),ct=Object.assign,Uo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},fd=Object.prototype.hasOwnProperty,He=(e,t)=>fd.call(e,t),Te=Array.isArray,sn=e=>Zn(e)==="[object Map]",pn=e=>Zn(e)==="[object Set]",wr=e=>Zn(e)==="[object Date]",Ae=e=>typeof e=="function",tt=e=>typeof e=="string",Rt=e=>typeof e=="symbol",Ue=e=>e!==null&&typeof e=="object",Cl=e=>(Ue(e)||Ae(e))&&Ae(e.then)&&Ae(e.catch),_l=Object.prototype.toString,Zn=e=>_l.call(e),pd=e=>Zn(e).slice(8,-1),$l=e=>Zn(e)==="[object Object]",Vo=e=>tt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,In=Wo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Os=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},hd=/-\w/g,wt=Os(e=>e.replace(hd,t=>t.slice(1).toUpperCase())),md=/\B([A-Z])/g,Ci=Os(e=>e.replace(md,"-$1").toLowerCase()),Rs=Os(e=>e.charAt(0).toUpperCase()+e.slice(1)),Qs=Os(e=>e?`on${Rs(e)}`:""),Vt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Il=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Ns=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let xr;const zs=()=>xr||(xr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Gt(e){if(Te(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=tt(n)?yd(n):Gt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(tt(e)||Ue(e))return e}const gd=/;(?![^(]*\))/g,vd=/:([^]+)/,bd=/\/\*[^]*?\*\//g;function yd(e){const t={};return e.replace(bd,"").split(gd).forEach(i=>{if(i){const n=i.split(vd);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Ce(e){let t="";if(tt(e))t=e;else if(Te(e))for(let i=0;i<e.length;i++){const n=Ce(e[i]);n&&(t+=n+" ")}else if(Ue(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const kd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",wd=Wo(kd);function Tl(e){return!!e||e===""}function xd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=hn(e[n],t[n]);return i}function hn(e,t){if(e===t)return!0;let i=wr(e),n=wr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Rt(e),n=Rt(t),i||n)return e===t;if(i=Te(e),n=Te(t),i||n)return i&&n?xd(e,t):!1;if(i=Ue(e),n=Ue(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!hn(e[l],t[l]))return!1}}return String(e)===String(t)}function Go(e,t){return e.findIndex(i=>hn(i,t))}const El=e=>!!(e&&e.__v_isRef===!0),xe=e=>tt(e)?e:e==null?"":Te(e)||Ue(e)&&(e.toString===_l||!Ae(e.toString))?El(e)?xe(e.value):JSON.stringify(e,Ml,2):String(e),Ml=(e,t)=>El(t)?Ml(e,t.value):sn(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[eo(n,o)+" =>"]=s,i),{})}:pn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>eo(i))}:Rt(t)?eo(t):Ue(t)&&!Te(t)&&!$l(t)?String(t):t,eo=(e,t="")=>{var i;return Rt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class Sd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Cd(){return lt}let qe;const to=new WeakSet;class Al{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,to.has(this)&&(to.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Dl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Sr(this),Ll(this);const t=qe,i=Pt;qe=this,Pt=!0;try{return this.fn()}finally{Pl(this),qe=t,Pt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Yo(t);this.deps=this.depsTail=void 0,Sr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?to.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){xo(this)&&this.run()}get dirty(){return xo(this)}}let Bl=0,Tn,En;function Dl(e,t=!1){if(e.flags|=8,t){e.next=En,En=e;return}e.next=Tn,Tn=e}function Ko(){Bl++}function qo(){if(--Bl>0)return;if(En){let t=En;for(En=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Tn;){let t=Tn;for(Tn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Ll(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Pl(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Yo(n),_d(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function xo(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Ol(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Ol(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Fn)||(e.globalVersion=Fn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!xo(e))))return;e.flags|=2;const t=e.dep,i=qe,n=Pt;qe=e,Pt=!0;try{Ll(e);const s=e.fn(e._value);(t.version===0||Vt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{qe=i,Pt=n,Pl(e),e.flags&=-3}}function Yo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Yo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function _d(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Pt=!0;const Rl=[];function ai(){Rl.push(Pt),Pt=!1}function ci(){const e=Rl.pop();Pt=e===void 0?!0:e}function Sr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=qe;qe=void 0;try{t()}finally{qe=i}}}let Fn=0;class $d{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Zo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!qe||!Pt||qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==qe)i=this.activeLink=new $d(qe,this),qe.deps?(i.prevDep=qe.depsTail,qe.depsTail.nextDep=i,qe.depsTail=i):qe.deps=qe.depsTail=i,Nl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=qe.depsTail,i.nextDep=void 0,qe.depsTail.nextDep=i,qe.depsTail=i,qe.deps===i&&(qe.deps=n)}return i}trigger(t){this.version++,Fn++,this.notify(t)}notify(t){Ko();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{qo()}}}function Nl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Nl(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const So=new WeakMap,Ni=Symbol(""),Co=Symbol(""),jn=Symbol("");function ft(e,t,i){if(Pt&&qe){let n=So.get(e);n||So.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Zo),s.map=n,s.key=i),s.track()}}function si(e,t,i,n,s,o){const l=So.get(e);if(!l){Fn++;return}const r=a=>{a&&a.trigger()};if(Ko(),t==="clear")l.forEach(r);else{const a=Te(e),c=a&&Vo(i);if(a&&i==="length"){const d=Number(n);l.forEach((p,h)=>{(h==="length"||h===jn||!Rt(h)&&h>=d)&&r(p)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(jn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Ni)),sn(e)&&r(l.get(Co)));break;case"delete":a||(r(l.get(Ni)),sn(e)&&r(l.get(Co)));break;case"set":sn(e)&&r(l.get(Ni));break}}qo()}function qi(e){const t=ze(e);return t===e?t:(ft(t,"iterate",jn),Bt(e)?t:t.map(Nt))}function Hs(e){return ft(e=ze(e),"iterate",jn),e}function Wt(e,t){return di(e)?cn(zi(e)?Nt(t):t):Nt(t)}const Id={__proto__:null,[Symbol.iterator](){return io(this,Symbol.iterator,e=>Wt(this,e))},concat(...e){return qi(this).concat(...e.map(t=>Te(t)?qi(t):t))},entries(){return io(this,"entries",e=>(e[1]=Wt(this,e[1]),e))},every(e,t){return ei(this,"every",e,t,void 0,arguments)},filter(e,t){return ei(this,"filter",e,t,i=>i.map(n=>Wt(this,n)),arguments)},find(e,t){return ei(this,"find",e,t,i=>Wt(this,i),arguments)},findIndex(e,t){return ei(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ei(this,"findLast",e,t,i=>Wt(this,i),arguments)},findLastIndex(e,t){return ei(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ei(this,"forEach",e,t,void 0,arguments)},includes(...e){return no(this,"includes",e)},indexOf(...e){return no(this,"indexOf",e)},join(e){return qi(this).join(e)},lastIndexOf(...e){return no(this,"lastIndexOf",e)},map(e,t){return ei(this,"map",e,t,void 0,arguments)},pop(){return kn(this,"pop")},push(...e){return kn(this,"push",e)},reduce(e,...t){return Cr(this,"reduce",e,t)},reduceRight(e,...t){return Cr(this,"reduceRight",e,t)},shift(){return kn(this,"shift")},some(e,t){return ei(this,"some",e,t,void 0,arguments)},splice(...e){return kn(this,"splice",e)},toReversed(){return qi(this).toReversed()},toSorted(e){return qi(this).toSorted(e)},toSpliced(...e){return qi(this).toSpliced(...e)},unshift(...e){return kn(this,"unshift",e)},values(){return io(this,"values",e=>Wt(this,e))}};function io(e,t,i){const n=Hs(e),s=n[t]();return n!==e&&!Bt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Td=Array.prototype;function ei(e,t,i,n,s,o){const l=Hs(e),r=l!==e&&!Bt(e),a=l[t];if(a!==Td[t]){const p=a.apply(e,o);return r?Nt(p):p}let c=i;l!==e&&(r?c=function(p,h){return i.call(this,Wt(e,p),h,e)}:i.length>2&&(c=function(p,h){return i.call(this,p,h,e)}));const d=a.call(l,c,n);return r&&s?s(d):d}function Cr(e,t,i,n){const s=Hs(e),o=s!==e&&!Bt(e);let l=i,r=!1;s!==e&&(o?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=Wt(e,c)),i.call(this,c,Wt(e,d),p,e)}):i.length>3&&(l=function(c,d,p){return i.call(this,c,d,p,e)}));const a=s[t](l,...n);return r?Wt(e,a):a}function no(e,t,i){const n=ze(e);ft(n,"iterate",jn);const s=n[t](...i);return(s===-1||s===!1)&&Qo(i[0])?(i[0]=ze(i[0]),n[t](...i)):s}function kn(e,t,i=[]){ai(),Ko();const n=ze(e)[t].apply(e,i);return qo(),ci(),n}const Ed=Wo("__proto__,__v_isRef,__isVue"),zl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Rt));function Md(e){Rt(e)||(e=String(e));const t=ze(this);return ft(t,"has",e),t.hasOwnProperty(e)}class Hl{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Hd:Ul:o?Wl:jl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Te(t);if(!s){let a;if(l&&(a=Id[i]))return a;if(i==="hasOwnProperty")return Md}const r=Reflect.get(t,i,Je(t)?t:n);if((Rt(i)?zl.has(i):Ed(i))||(s||ft(t,"get",i),o))return r;if(Je(r)){const a=l&&Vo(i)?r:r.value;return s&&Ue(a)?$o(a):a}return Ue(r)?s?$o(r):Fs(r):r}}class Fl extends Hl{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const l=Te(t)&&Vo(i);if(!this._isShallow){const c=di(o);if(!Bt(n)&&!di(n)&&(o=ze(o),n=ze(n)),!l&&Je(o)&&!Je(n))return c||(o.value=n),!0}const r=l?Number(i)<t.length:He(t,i),a=Reflect.set(t,i,n,Je(t)?t:s);return t===ze(s)&&a&&(r?Vt(n,o)&&si(t,"set",i,n):si(t,"add",i,n)),a}deleteProperty(t,i){const n=He(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&si(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Rt(i)||!zl.has(i))&&ft(t,"has",i),n}ownKeys(t){return ft(t,"iterate",Te(t)?"length":Ni),Reflect.ownKeys(t)}}class Ad extends Hl{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Bd=new Fl,Dd=new Ad,Ld=new Fl(!0);const _o=e=>e,ns=e=>Reflect.getPrototypeOf(e);function Pd(e,t,i){return function(...n){const s=this.__v_raw,o=ze(s),l=sn(o),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=s[e](...n),d=i?_o:t?cn:Nt;return!t&&ft(o,"iterate",a?Co:Ni),ct(Object.create(c),{next(){const{value:p,done:h}=c.next();return h?{value:p,done:h}:{value:r?[d(p[0]),d(p[1])]:d(p),done:h}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Od(e,t){const i={get(s){const o=this.__v_raw,l=ze(o),r=ze(s);e||(Vt(s,r)&&ft(l,"get",s),ft(l,"get",r));const{has:a}=ns(l),c=t?_o:e?cn:Nt;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!e&&ft(ze(s),"iterate",Ni),s.size},has(s){const o=this.__v_raw,l=ze(o),r=ze(s);return e||(Vt(s,r)&&ft(l,"has",s),ft(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=ze(r),c=t?_o:e?cn:Nt;return!e&&ft(a,"iterate",Ni),r.forEach((d,p)=>s.call(o,c(d),c(p),l))}};return ct(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=ze(this),l=ns(o),r=ze(s),a=!t&&!Bt(s)&&!di(s)?r:s;return l.has.call(o,a)||Vt(s,a)&&l.has.call(o,s)||Vt(r,a)&&l.has.call(o,r)||(o.add(a),si(o,"add",a,a)),this},set(s,o){!t&&!Bt(o)&&!di(o)&&(o=ze(o));const l=ze(this),{has:r,get:a}=ns(l);let c=r.call(l,s);c||(s=ze(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Vt(o,d)&&si(l,"set",s,o):si(l,"add",s,o),this},delete(s){const o=ze(this),{has:l,get:r}=ns(o);let a=l.call(o,s);a||(s=ze(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&si(o,"delete",s,void 0),c},clear(){const s=ze(this),o=s.size!==0,l=s.clear();return o&&si(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=Pd(s,e,t)}),i}function Jo(e,t){const i=Od(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(He(i,s)&&s in n?i:n,s,o)}const Rd={get:Jo(!1,!1)},Nd={get:Jo(!1,!0)},zd={get:Jo(!0,!1)};const jl=new WeakMap,Wl=new WeakMap,Ul=new WeakMap,Hd=new WeakMap;function Fd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Fs(e){return di(e)?e:Xo(e,!1,Bd,Rd,jl)}function jd(e){return Xo(e,!1,Ld,Nd,Wl)}function $o(e){return Xo(e,!0,Dd,zd,Ul)}function Xo(e,t,i,n,s){if(!Ue(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const l=Fd(pd(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return s.set(e,r),r}function zi(e){return di(e)?zi(e.__v_raw):!!(e&&e.__v_isReactive)}function di(e){return!!(e&&e.__v_isReadonly)}function Bt(e){return!!(e&&e.__v_isShallow)}function Qo(e){return e?!!e.__v_raw:!1}function ze(e){const t=e&&e.__v_raw;return t?ze(t):e}function Wd(e){return!He(e,"__v_skip")&&Object.isExtensible(e)&&Il(e,"__v_skip",!0),e}const Nt=e=>Ue(e)?Fs(e):e,cn=e=>Ue(e)?$o(e):e;function Je(e){return e?e.__v_isRef===!0:!1}function ge(e){return Ud(e,!1)}function Ud(e,t){return Je(e)?e:new Vd(e,t)}class Vd{constructor(t,i){this.dep=new Zo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:ze(t),this._value=i?t:Nt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Bt(t)||di(t);t=n?t:ze(t),Vt(t,i)&&(this._rawValue=t,this._value=n?t:Nt(t),this.dep.trigger())}}function he(e){return Je(e)?e.value:e}const Gd={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return Je(s)&&!Je(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Vl(e){return zi(e)?e:new Proxy(e,Gd)}class Kd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Zo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Fn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&qe!==this)return Dl(this,!0),!0}get value(){const t=this.dep.track();return Ol(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function qd(e,t,i=!1){let n,s;return Ae(e)?n=e:(n=e.get,s=e.set),new Kd(n,s,i)}const os={},_s=new WeakMap;let Ai;function Yd(e,t=!1,i=Ai){if(i){let n=_s.get(i);n||_s.set(i,n=[]),n.push(e)}}function Zd(e,t,i=Ve){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=i,c=x=>s?x:Bt(x)||s===!1||s===0?oi(x,1):oi(x);let d,p,h,u,v=!1,m=!1;if(Je(e)?(p=()=>e.value,v=Bt(e)):zi(e)?(p=()=>c(e),v=!0):Te(e)?(m=!0,v=e.some(x=>zi(x)||Bt(x)),p=()=>e.map(x=>{if(Je(x))return x.value;if(zi(x))return c(x);if(Ae(x))return a?a(x,2):x()})):Ae(e)?t?p=a?()=>a(e,2):e:p=()=>{if(h){ai();try{h()}finally{ci()}}const x=Ai;Ai=d;try{return a?a(e,3,[u]):e(u)}finally{Ai=x}}:p=Zt,t&&s){const x=p,$=s===!0?1/0:s;p=()=>oi(x(),$)}const b=Cd(),y=()=>{d.stop(),b&&b.active&&Uo(b.effects,d)};if(o&&t){const x=t;t=(...$)=>{const T=x(...$);return y(),T}}let C=m?new Array(e.length).fill(os):os;const S=x=>{if(!(!(d.flags&1)||!d.dirty&&!x))if(t){const $=d.run();if(x||s||v||(m?$.some((T,w)=>Vt(T,C[w])):Vt($,C))){h&&h();const T=Ai;Ai=d;try{const w=[$,C===os?void 0:m&&C[0]===os?[]:C,u];C=$,a?a(t,3,w):t(...w)}finally{Ai=T}}}else d.run()};return r&&r(S),d=new Al(p),d.scheduler=l?()=>l(S,!1):S,u=x=>Yd(x,!1,d),h=d.onStop=()=>{const x=_s.get(d);if(x){if(a)a(x,4);else for(const $ of x)$();_s.delete(d)}},t?n?S(!0):C=d.run():l?l(S.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function oi(e,t=1/0,i){if(t<=0||!Ue(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Je(e))oi(e.value,t,i);else if(Te(e))for(let n=0;n<e.length;n++)oi(e[n],t,i);else if(pn(e)||sn(e))e.forEach(n=>{oi(n,t,i)});else if($l(e)){for(const n in e)oi(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&oi(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){js(s,t,i)}}function zt(e,t,i,n){if(Ae(e)){const s=Jn(e,t,i,n);return s&&Cl(s)&&s.catch(o=>{js(o,t,i)}),s}if(Te(e)){const s=[];for(let o=0;o<e.length;o++)s.push(zt(e[o],t,i,n));return s}}function js(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ve;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(o){ai(),Jn(o,null,10,[e,a,c]),ci();return}}Jd(e,i,s,n,l)}function Jd(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const bt=[];let jt=-1;const on=[];let vi=null,Yi=0;const Gl=Promise.resolve();let $s=null;function Is(e){const t=$s||Gl;return e?t.then(this?e.bind(this):e):t}function Xd(e){let t=jt+1,i=bt.length;for(;t<i;){const n=t+i>>>1,s=bt[n],o=Wn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function er(e){if(!(e.flags&1)){const t=Wn(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Wn(i)?bt.push(e):bt.splice(Xd(t),0,e),e.flags|=1,Kl()}}function Kl(){$s||($s=Gl.then(Yl))}function Qd(e){Te(e)?on.push(...e):vi&&e.id===-1?vi.splice(Yi+1,0,e):e.flags&1||(on.push(e),e.flags|=1),Kl()}function _r(e,t,i=jt+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function ql(e){if(on.length){const t=[...new Set(on)].sort((i,n)=>Wn(i)-Wn(n));if(on.length=0,vi){vi.push(...t);return}for(vi=t,Yi=0;Yi<vi.length;Yi++){const i=vi[Yi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}vi=null,Yi=0}}const Wn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Yl(e){try{for(jt=0;jt<bt.length;jt++){const t=bt[jt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;jt<bt.length;jt++){const t=bt[jt];t&&(t.flags&=-2)}jt=-1,bt.length=0,ql(),$s=null,(bt.length||on.length)&&Yl()}}let at=null,Zl=null;function Ts(e){const t=at;return at=e,Zl=e&&e.type.__scopeId||null,t}function Jl(e,t=at,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Rr(-1);const o=Ts(t),l=ri.length;let r;try{r=e(...s)}finally{for(let a=ri.length;a>l;a--)or();Ts(o),n._d&&Rr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Dt(e,t){if(at===null)return e;const i=Ks(at),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,l,r,a=Ve]=t[s];o&&(Ae(o)&&(o={mounted:o,updated:o}),o.deep&&oi(l),n.push({dir:o,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function $i(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(ai(),zt(a,i,8,[e.el,r,e,t]),ci())}}function eu(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function Ot(e,t,i=!1){const n=Xu();if(n||ln){let s=ln?ln._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Ae(t)?t.call(n&&n.proxy):t}}const tu=Symbol.for("v-scx"),iu=()=>Ot(tu);function Hi(e,t,i){return Xl(e,t,i)}function Xl(e,t,i=Ve){const{immediate:n,deep:s,flush:o,once:l}=i,r=ct({},i),a=t&&n||!t&&o!=="post";let c;if(Vn){if(o==="sync"){const u=iu();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Zt,u.resume=Zt,u.pause=Zt,u}}const d=ht;r.call=(u,v,m)=>zt(u,d,v,m);let p=!1;o==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:o!=="sync"&&(p=!0,r.scheduler=(u,v)=>{v?u():er(u)}),r.augmentJob=u=>{t&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const h=Zd(e,t,r);return Vn&&(c?c.push(h):a&&h()),h}function nu(e,t,i){const n=this.proxy,s=tt(e)?e.includes(".")?Ql(n,e):()=>n[e]:e.bind(n,n);let o;Ae(t)?o=t:(o=t.handler,i=t);const l=Xn(this),r=Xl(s,o.bind(n),i);return l(),r}function Ql(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const su=Symbol("_vte"),ou=e=>e.__isTeleport,so=Symbol("_leaveCb");function tr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,tr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Et(e,t){return Ae(e)?ct({name:e.name},t,{setup:e}):e}function ea(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function $r(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Es=new WeakMap;function Mn(e,t,i,n,s=!1){if(Te(e)){e.forEach((m,b)=>Mn(m,t&&(Te(t)?t[b]:t),i,n,s));return}if(rn(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Mn(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Ks(n.component):n.el,l=s?null:o,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ve?r.refs={}:r.refs,p=r.setupState,h=ze(p),u=p===Ve?Sl:m=>$r(d,m)?!1:He(h,m),v=(m,b)=>!(b&&$r(d,b));if(c!=null&&c!==a){if(Ir(t),tt(c))d[c]=null,u(c)&&(p[c]=null);else if(Je(c)){const m=t;v(c,m.k)&&(c.value=null),m.k&&(d[m.k]=null)}}if(Ae(a))Jn(a,r,12,[l,d]);else{const m=tt(a),b=Je(a);if(m||b){const y=()=>{if(e.f){const C=m?u(a)?p[a]:d[a]:v()||!e.k?a.value:d[e.k];if(s)Te(C)&&Uo(C,o);else if(Te(C))C.includes(o)||C.push(o);else if(m)d[a]=[o],u(a)&&(p[a]=d[a]);else{const S=[o];v(a,e.k)&&(a.value=S),e.k&&(d[e.k]=S)}}else m?(d[a]=l,u(a)&&(p[a]=l)):b&&(v(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const C=()=>{y(),Es.delete(e)};C.id=-1,Es.set(e,C),xt(C,i)}else Ir(e),y()}}}function Ir(e){const t=Es.get(e);t&&(t.flags|=8,Es.delete(e))}zs().requestIdleCallback;zs().cancelIdleCallback;const rn=e=>!!e.type.__asyncLoader,ta=e=>e.type.__isKeepAlive;function ru(e,t){ia(e,"a",t)}function lu(e,t){ia(e,"da",t)}function ia(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ws(t,n,i),i){let s=i.parent;for(;s&&s.parent;)ta(s.parent.vnode)&&au(n,t,i,s),s=s.parent}}function au(e,t,i,n){const s=Ws(t,e,n,!0);Us(()=>{Uo(n[t],s)},i)}function Ws(e,t,i=ht,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...l)=>{ai();const r=Xn(i),a=zt(t,i,e,l);return r(),ci(),a});return n?s.unshift(o):s.push(o),o}}const fi=e=>(t,i=ht)=>{(!Vn||e==="sp")&&Ws(e,(...n)=>t(...n),i)},cu=fi("bm"),mn=fi("m"),du=fi("bu"),uu=fi("u"),ir=fi("bum"),Us=fi("um"),fu=fi("sp"),pu=fi("rtg"),hu=fi("rtc");function mu(e,t=ht){Ws("ec",e,t)}const gu="components";function vu(e,t){return yu(gu,e,!0,t)||e}const bu=Symbol.for("v-ndc");function yu(e,t,i=!0,n=!1){const s=at||ht;if(s){const o=s.type;{const r=sf(o,!1);if(r&&(r===t||r===wt(t)||r===Rs(wt(t))))return o}const l=Tr(s[e]||o[e],t)||Tr(s.appContext[e],t);return!l&&n?o:l}}function Tr(e,t){return e&&(e[t]||e[wt(t)]||e[Rs(wt(t))])}function kt(e,t,i,n){let s;const o=i,l=Te(e);if(l||tt(e)){const r=l&&zi(e);let a=!1,c=!1;r&&(a=!Bt(e),c=di(e),e=Hs(e)),s=new Array(e.length);for(let d=0,p=e.length;d<p;d++)s[d]=t(a?c?cn(Nt(e[d])):Nt(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ue(e))if(e[Symbol.iterator])s=Array.from(e,(r,a)=>t(r,a,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=t(e[d],d,a,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(at.ce||at.parent&&rn(at.parent)&&at.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),X(),qt(Ge,null,[le("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ri.length;X();let a;try{const c=l&&na(l(i)),d=i.key||o||c&&c.key;a=qt(Ge,{key:(d&&!Rt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ri.length;d>r;d--)or();throw c}finally{l&&l._c&&(l._d=!0)}return a}function na(e){return e.some(t=>rr(t)?!(t.type===ui||t.type===Ge&&!na(t.children)):!0)?e:null}const Io=e=>e?Sa(e)?Ks(e):Io(e.parent):null,An=ct(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Io(e.parent),$root:e=>Io(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>oa(e),$forceUpdate:e=>e.f||(e.f=()=>{er(e.update)}),$nextTick:e=>e.n||(e.n=Is.bind(e.proxy)),$watch:e=>nu.bind(e)}),oo=(e,t)=>e!==Ve&&!e.__isScriptSetup&&He(e,t),ku={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const h=l[t];if(h!==void 0)switch(h){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(oo(n,t))return l[t]=1,n[t];if(s!==Ve&&He(s,t))return l[t]=2,s[t];if(He(o,t))return l[t]=3,o[t];if(i!==Ve&&He(i,t))return l[t]=4,i[t];To&&(l[t]=0)}}const c=An[t];let d,p;if(c)return t==="$attrs"&&ft(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ve&&He(i,t))return l[t]=4,i[t];if(p=a.config.globalProperties,He(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return oo(s,t)?(s[t]=i,!0):n!==Ve&&He(n,t)?(n[t]=i,!0):He(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(i[r]||e!==Ve&&r[0]!=="$"&&He(e,r)||oo(t,r)||He(o,r)||He(n,r)||He(An,r)||He(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:He(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Er(e){return Te(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let To=!0;function wu(e){const t=oa(e),i=e.proxy,n=e.ctx;To=!1,t.beforeCreate&&Mr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:h,beforeUpdate:u,updated:v,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:C,destroyed:S,unmounted:x,render:$,renderTracked:T,renderTriggered:w,errorCaptured:R,serverPrefetch:F,expose:P,inheritAttrs:q,components:_,directives:H,filters:k}=t;if(c&&xu(c,n,null),l)for(const A in l){const D=l[A];Ae(D)&&(n[A]=D.bind(i))}if(s){const A=s.call(i,i);Ue(A)&&(e.data=Fs(A))}if(To=!0,o)for(const A in o){const D=o[A],N=Ae(D)?D.bind(i,i):Ae(D.get)?D.get.bind(i,i):Zt,ee=!Ae(D)&&Ae(D.set)?D.set.bind(i):Zt,W=ye({get:N,set:ee});Object.defineProperty(n,A,{enumerable:!0,configurable:!0,get:()=>W.value,set:K=>W.value=K})}if(r)for(const A in r)sa(r[A],n,i,A);if(a){const A=Ae(a)?a.call(i):a;Reflect.ownKeys(A).forEach(D=>{eu(D,A[D])})}d&&Mr(d,e,"c");function j(A,D){Te(D)?D.forEach(N=>A(N.bind(i))):D&&A(D.bind(i))}if(j(cu,p),j(mn,h),j(du,u),j(uu,v),j(ru,m),j(lu,b),j(mu,R),j(hu,T),j(pu,w),j(ir,C),j(Us,x),j(fu,F),Te(P))if(P.length){const A=e.exposed||(e.exposed={});P.forEach(D=>{Object.defineProperty(A,D,{get:()=>i[D],set:N=>i[D]=N,enumerable:!0})})}else e.exposed||(e.exposed={});$&&e.render===Zt&&(e.render=$),q!=null&&(e.inheritAttrs=q),_&&(e.components=_),H&&(e.directives=H),F&&ea(e)}function xu(e,t,i=Zt){Te(e)&&(e=Eo(e));for(const n in e){const s=e[n];let o;Ue(s)?"default"in s?o=Ot(s.from||n,s.default,!0):o=Ot(s.from||n):o=Ot(s),Je(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):t[n]=o}}function Mr(e,t,i){zt(Te(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function sa(e,t,i,n){let s=n.includes(".")?Ql(i,n):()=>i[n];if(tt(e)){const o=t[e];Ae(o)&&Hi(s,o)}else if(Ae(e))Hi(s,e.bind(i));else if(Ue(e))if(Te(e))e.forEach(o=>sa(o,t,i,n));else{const o=Ae(e.handler)?e.handler.bind(i):t[e.handler];Ae(o)&&Hi(s,o,e)}}function oa(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=e.appContext,r=o.get(t);let a;return r?a=r:!s.length&&!i&&!n?a=t:(a={},s.length&&s.forEach(c=>Ms(a,c,l,!0)),Ms(a,t,l)),Ue(t)&&o.set(t,a),a}function Ms(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&Ms(e,o,i,!0),s&&s.forEach(l=>Ms(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=Su[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Su={data:Ar,props:Br,emits:Br,methods:Sn,computed:Sn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:Sn,directives:Sn,watch:_u,provide:Ar,inject:Cu};function Ar(e,t){return t?e?function(){return ct(Ae(e)?e.call(this,this):e,Ae(t)?t.call(this,this):t)}:t:e}function Cu(e,t){return Sn(Eo(e),Eo(t))}function Eo(e){if(Te(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function Sn(e,t){return e?ct(Object.create(null),e,t):t}function Br(e,t){return e?Te(e)&&Te(t)?[...new Set([...e,...t])]:ct(Object.create(null),Er(e),Er(t??{})):t}function _u(e,t){if(!e)return t;if(!t)return e;const i=ct(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function ra(){return{app:null,config:{isNativeTag:Sl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let $u=0;function Iu(e,t){return function(n,s=null){Ae(n)||(n=ct({},n)),s!=null&&!Ue(s)&&(s=null);const o=ra(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:$u++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:rf,get config(){return o.config},set config(d){},use(d,...p){return l.has(d)||(d&&Ae(d.install)?(l.add(d),d.install(c,...p)):Ae(d)&&(l.add(d),d(c,...p))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,p){return p?(o.components[d]=p,c):o.components[d]},directive(d,p){return p?(o.directives[d]=p,c):o.directives[d]},mount(d,p,h){if(!a){const u=c._ceVNode||le(n,s);return u.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(u,d,h),a=!0,c._container=d,d.__vue_app__=c,Ks(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(zt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return o.provides[d]=p,c},runWithContext(d){const p=ln;ln=c;try{return d()}finally{ln=p}}};return c}}let ln=null;const Tu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${Ci(t)}Modifiers`];function Eu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ve;let s=i;const o=t.startsWith("update:"),l=o&&Tu(n,t.slice(7));l&&(l.trim&&(s=i.map(d=>tt(d)?d.trim():d)),l.number&&(s=i.map(Ns)));let r,a=n[r=Qs(t)]||n[r=Qs(wt(t))];!a&&o&&(a=n[r=Qs(Ci(t))]),a&&zt(a,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,zt(c,e,6,s)}}const Mu=new WeakMap;function la(e,t,i=!1){const n=i?Mu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let l={},r=!1;if(!Ae(e)){const a=c=>{const d=la(c,t,!0);d&&(r=!0,ct(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!o&&!r?(Ue(e)&&n.set(e,null),null):(Te(o)?o.forEach(a=>l[a]=null):ct(l,o),Ue(e)&&n.set(e,l),l)}function Vs(e,t){return!e||!Ls(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),He(e,t[0].toLowerCase()+t.slice(1))||He(e,Ci(t))||He(e,t))}function Dr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:h,setupState:u,ctx:v,inheritAttrs:m}=e,b=Ts(e);let y,C;try{if(i.shapeFlag&4){const x=s||n,$=x;y=Ut(c.call($,x,d,p,u,h,v)),C=r}else{const x=t;y=Ut(x.length>1?x(p,{attrs:r,slots:l,emit:a}):x(p,null)),C=t.props?r:Au(r)}}catch(x){ri.length=0,js(x,e,1),y=le(ui)}let S=y;if(C&&m!==!1){const x=Object.keys(C),{shapeFlag:$}=S;x.length&&$&7&&(o&&x.some(Ps)&&(C=Bu(C,o)),S=dn(S,C,!1,!0))}return i.dirs&&(S=dn(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(i.dirs):i.dirs),i.transition&&tr(S,i.transition),y=S,Ts(b),y}const Au=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ls(i))&&((t||(t={}))[i]=e[i]);return t},Bu=(e,t)=>{const i={};for(const n in e)(!Ps(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Du(e,t,i){const{props:n,children:s,component:o}=e,{props:l,children:r,patchFlag:a}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?Lr(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const h=d[p];if(aa(l,n,h)&&!Vs(c,h))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?Lr(n,l,c):!0:!!l;return!1}function Lr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(aa(t,e,o)&&!Vs(i,o))return!0}return!1}function aa(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ue(n)&&Ue(s)?!hn(n,s):n!==s}function Lu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const ca={},da=()=>Object.create(ca),ua=e=>Object.getPrototypeOf(e)===ca;function Pu(e,t,i,n=!1){const s={},o=da();e.propsDefaults=Object.create(null),fa(e,t,s,o);for(const l in e.propsOptions[0])l in s||(s[l]=void 0);i?e.props=n?s:jd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Ou(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=e,r=ze(s),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let h=d[p];if(Vs(e.emitsOptions,h))continue;const u=t[h];if(a)if(He(o,h))u!==o[h]&&(o[h]=u,c=!0);else{const v=wt(h);s[v]=Mo(a,r,v,u,e,!1)}else u!==o[h]&&(o[h]=u,c=!0)}}}else{fa(e,t,s,o)&&(c=!0);let d;for(const p in r)(!t||!He(t,p)&&((d=Ci(p))===p||!He(t,d)))&&(a?i&&(i[p]!==void 0||i[d]!==void 0)&&(s[p]=Mo(a,r,p,void 0,e,!0)):delete s[p]);if(o!==r)for(const p in o)(!t||!He(t,p))&&(delete o[p],c=!0)}c&&si(e.attrs,"set","")}function fa(e,t,i,n){const[s,o]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(In(a))continue;const c=t[a];let d;s&&He(s,d=wt(a))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Vs(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=ze(i),c=r||Ve;for(let d=0;d<o.length;d++){const p=o[d];i[p]=Mo(s,a,p,c[p],e,!He(c,p))}}return l}function Mo(e,t,i,n,s,o){const l=e[i];if(l!=null){const r=He(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ae(a)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Xn(s);n=c[i]=a.call(null,t),d()}}else n=a;s.ce&&s.ce._setProp(i,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===Ci(i))&&(n=!0))}return n}const Ru=new WeakMap;function pa(e,t,i=!1){const n=i?Ru:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,l={},r=[];let a=!1;if(!Ae(e)){const d=p=>{a=!0;const[h,u]=pa(p,t,!0);ct(l,h),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!a)return Ue(e)&&n.set(e,nn),nn;if(Te(o))for(let d=0;d<o.length;d++){const p=wt(o[d]);Pr(p)&&(l[p]=Ve)}else if(o)for(const d in o){const p=wt(d);if(Pr(p)){const h=o[d],u=l[p]=Te(h)||Ae(h)?{type:h}:ct({},h),v=u.type;let m=!1,b=!0;if(Te(v))for(let y=0;y<v.length;++y){const C=v[y],S=Ae(C)&&C.name;if(S==="Boolean"){m=!0;break}else S==="String"&&(b=!1)}else m=Ae(v)&&v.name==="Boolean";u[0]=m,u[1]=b,(m||He(u,"default"))&&r.push(p)}}const c=[l,r];return Ue(e)&&n.set(e,c),c}function Pr(e){return e[0]!=="$"&&!In(e)}const nr=e=>e==="_"||e==="_ctx"||e==="$stable",sr=e=>Te(e)?e.map(Ut):[Ut(e)],Nu=(e,t,i)=>{if(t._n)return t;const n=Jl((...s)=>sr(t(...s)),i);return n._c=!1,n},ha=(e,t,i)=>{const n=e._ctx;for(const s in e){if(nr(s))continue;const o=e[s];if(Ae(o))t[s]=Nu(s,o,n);else if(o!=null){const l=sr(o);t[s]=()=>l}}},ma=(e,t)=>{const i=sr(t);e.slots.default=()=>i},ga=(e,t,i)=>{for(const n in t)(i||!nr(n))&&(e[n]=t[n])},zu=(e,t,i)=>{const n=e.slots=da();if(e.vnode.shapeFlag&32){const s=t._;s?(ga(n,t,i),i&&Il(n,"_",s,!0)):ha(t,n)}else t&&ma(e,t)},Hu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,l=Ve;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:ga(s,t,i):(o=!t.$stable,ha(t,s)),l=t}else t&&(ma(e,t),l={default:1});if(o)for(const r in s)!nr(r)&&l[r]==null&&delete s[r]},xt=Vu;function Fu(e){return ju(e)}function ju(e,t){const i=zs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:h,setScopeId:u=Zt,insertStaticContent:v}=e,m=(L,V,g,G=null,U=null,I=null,E=void 0,O=null,Y=!!V.dynamicChildren)=>{if(L===V)return;L&&!wn(L,V)&&(G=Ee(L),K(L,U,I,!0),L=null),V.patchFlag===-2&&(Y=!1,V.dynamicChildren=null);const{type:B,ref:z,shapeFlag:J}=V;switch(B){case Gs:b(L,V,g,G);break;case ui:y(L,V,g,G);break;case fs:L==null&&C(V,g,G,E);break;case Ge:_(L,V,g,G,U,I,E,O,Y);break;default:J&1?$(L,V,g,G,U,I,E,O,Y):J&6?H(L,V,g,G,U,I,E,O,Y):(J&64||J&128)&&B.process(L,V,g,G,U,I,E,O,Y,Z)}z!=null&&U?Mn(z,L&&L.ref,I,V||L,!V):z==null&&L&&L.ref!=null&&Mn(L.ref,null,I,L,!0)},b=(L,V,g,G)=>{if(L==null)n(V.el=r(V.children),g,G);else{const U=V.el=L.el;V.children!==L.children&&c(U,V.children)}},y=(L,V,g,G)=>{L==null?n(V.el=a(V.children||""),g,G):V.el=L.el},C=(L,V,g,G)=>{[L.el,L.anchor]=v(L.children,V,g,G,L.el,L.anchor)},S=({el:L,anchor:V},g,G)=>{let U;for(;L&&L!==V;)U=h(L),n(L,g,G),L=U;n(V,g,G)},x=({el:L,anchor:V})=>{let g;for(;L&&L!==V;)g=h(L),s(L),L=g;s(V)},$=(L,V,g,G,U,I,E,O,Y)=>{if(V.type==="svg"?E="svg":V.type==="math"&&(E="mathml"),L==null)T(V,g,G,U,I,E,O,Y);else{const B=L.el&&L.el._isVueCE?L.el:null;try{B&&B._beginPatch(),F(L,V,U,I,E,O,Y)}finally{B&&B._endPatch()}}},T=(L,V,g,G,U,I,E,O)=>{let Y,B;const{props:z,shapeFlag:J,transition:ne,dirs:oe}=L;if(Y=L.el=l(L.type,I,z&&z.is,z),J&8?d(Y,L.children):J&16&&R(L.children,Y,null,G,U,ro(L,I),E,O),oe&&$i(L,null,G,"created"),w(Y,L,L.scopeId,E,G),z){for(const ie in z)ie!=="value"&&!In(ie)&&o(Y,ie,null,z[ie],I,G);"value"in z&&o(Y,"value",null,z.value,I),(B=z.onVnodeBeforeMount)&&Ft(B,G,L)}oe&&$i(L,null,G,"beforeMount");const me=Wu(U,ne);me&&ne.beforeEnter(Y),n(Y,V,g),((B=z&&z.onVnodeMounted)||me||oe)&&xt(()=>{try{B&&Ft(B,G,L),me&&ne.enter(Y),oe&&$i(L,null,G,"mounted")}finally{}},U)},w=(L,V,g,G,U)=>{if(g&&u(L,g),G)for(let I=0;I<G.length;I++)u(L,G[I]);if(U){let I=U.subTree;if(V===I||ka(I.type)&&(I.ssContent===V||I.ssFallback===V)){const E=U.vnode;w(L,E,E.scopeId,E.slotScopeIds,U.parent)}}},R=(L,V,g,G,U,I,E,O,Y=0)=>{for(let B=Y;B<L.length;B++){const z=L[B]=O?ii(L[B]):Ut(L[B]);m(null,z,V,g,G,U,I,E,O)}},F=(L,V,g,G,U,I,E)=>{const O=V.el=L.el;let{patchFlag:Y,dynamicChildren:B,dirs:z}=V;Y|=L.patchFlag&16;const J=L.props||Ve,ne=V.props||Ve;let oe;if(g&&Ii(g,!1),(oe=ne.onVnodeBeforeUpdate)&&Ft(oe,g,V,L),z&&$i(V,L,g,"beforeUpdate"),g&&Ii(g,!0),B&&(!L.dynamicChildren||L.dynamicChildren.length!==B.length)&&(Y=0,E=!1,B=null),(J.innerHTML&&ne.innerHTML==null||J.textContent&&ne.textContent==null)&&d(O,""),B?P(L.dynamicChildren,B,O,g,G,ro(V,U),I):E||D(L,V,O,null,g,G,ro(V,U),I,!1),Y>0){if(Y&16)q(O,J,ne,g,U);else if(Y&2&&J.class!==ne.class&&o(O,"class",null,ne.class,U),Y&4&&o(O,"style",J.style,ne.style,U),Y&8){const me=V.dynamicProps;for(let ie=0;ie<me.length;ie++){const se=me[ie],_e=J[se],Be=ne[se];(Be!==_e||se==="value")&&o(O,se,_e,Be,U,g)}}Y&1&&L.children!==V.children&&d(O,V.children)}else!E&&B==null&&q(O,J,ne,g,U);((oe=ne.onVnodeUpdated)||z)&&xt(()=>{oe&&Ft(oe,g,V,L),z&&$i(V,L,g,"updated")},G)},P=(L,V,g,G,U,I,E)=>{for(let O=0;O<V.length;O++){const Y=L[O],B=V[O],z=Y.el&&(Y.type===Ge||!wn(Y,B)||Y.shapeFlag&198)?p(Y.el):g;m(Y,B,z,null,G,U,I,E,!0)}},q=(L,V,g,G,U)=>{if(V!==g){if(V!==Ve)for(const I in V)!In(I)&&!(I in g)&&o(L,I,V[I],null,U,G);for(const I in g){if(In(I))continue;const E=g[I],O=V[I];E!==O&&I!=="value"&&o(L,I,O,E,U,G)}"value"in g&&o(L,"value",V.value,g.value,U)}},_=(L,V,g,G,U,I,E,O,Y)=>{const B=V.el=L?L.el:r(""),z=V.anchor=L?L.anchor:r("");let{patchFlag:J,dynamicChildren:ne,slotScopeIds:oe}=V;oe&&(O=O?O.concat(oe):oe),L==null?(n(B,g,G),n(z,g,G),R(V.children||[],g,z,U,I,E,O,Y)):J>0&&J&64&&ne&&L.dynamicChildren&&L.dynamicChildren.length===ne.length?(P(L.dynamicChildren,ne,g,U,I,E,O),(V.key!=null||U&&V===U.subTree)&&va(L,V,!0)):D(L,V,g,z,U,I,E,O,Y)},H=(L,V,g,G,U,I,E,O,Y)=>{V.slotScopeIds=O,L==null?V.shapeFlag&512?U.ctx.activate(V,g,G,E,Y):k(V,g,G,U,I,E,Y):M(L,V,Y)},k=(L,V,g,G,U,I,E)=>{const O=L.component=Ju(L,G,U);if(ta(L)&&(O.ctx.renderer=Z),Qu(O,!1,E),O.asyncDep){if(U&&U.registerDep(O,j,E),!L.el){const Y=O.subTree=le(ui);y(null,Y,V,g),L.placeholder=Y.el}}else j(O,L,V,g,U,I,E)},M=(L,V,g)=>{const G=V.component=L.component;if(Du(L,V,g))if(G.asyncDep&&!G.asyncResolved){A(G,V,g);return}else G.next=V,G.update();else V.el=L.el,G.vnode=V},j=(L,V,g,G,U,I,E)=>{const O=()=>{if(L.isMounted){let{next:J,bu:ne,u:oe,parent:me,vnode:ie}=L;{const Re=ba(L);if(Re){J&&(J.el=ie.el,A(L,J,E)),Re.asyncDep.then(()=>{xt(()=>{L.isUnmounted||B()},U)});return}}let se=J,_e;Ii(L,!1),J?(J.el=ie.el,A(L,J,E)):J=ie,ne&&us(ne),(_e=J.props&&J.props.onVnodeBeforeUpdate)&&Ft(_e,me,J,ie),Ii(L,!0);const Be=Dr(L),Ne=L.subTree;L.subTree=Be,m(Ne,Be,p(Ne.el),Ee(Ne),L,U,I),J.el=Be.el,se===null&&Lu(L,Be.el),oe&&xt(oe,U),(_e=J.props&&J.props.onVnodeUpdated)&&xt(()=>Ft(_e,me,J,ie),U)}else{let J;const{el:ne,props:oe}=V,{bm:me,m:ie,parent:se,root:_e,type:Be}=L,Ne=rn(V);Ii(L,!1),me&&us(me),!Ne&&(J=oe&&oe.onVnodeBeforeMount)&&Ft(J,se,V),Ii(L,!0);{_e.ce&&_e.ce._hasShadowRoot()&&_e.ce._injectChildStyle(Be,L.parent?L.parent.type:void 0);const Re=L.subTree=Dr(L);m(null,Re,g,G,L,U,I),V.el=Re.el}if(ie&&xt(ie,U),!Ne&&(J=oe&&oe.onVnodeMounted)){const Re=V;xt(()=>Ft(J,se,Re),U)}(V.shapeFlag&256||se&&rn(se.vnode)&&se.vnode.shapeFlag&256)&&L.a&&xt(L.a,U),L.isMounted=!0,V=g=G=null}};L.scope.on();const Y=L.effect=new Al(O);L.scope.off();const B=L.update=Y.run.bind(Y),z=L.job=Y.runIfDirty.bind(Y);z.i=L,z.id=L.uid,Y.scheduler=()=>er(z),Ii(L,!0),B()},A=(L,V,g)=>{V.component=L;const G=L.vnode.props;L.vnode=V,L.next=null,Ou(L,V.props,G,g),Hu(L,V.children,g),ai(),_r(L),ci()},D=(L,V,g,G,U,I,E,O,Y=!1)=>{const B=L&&L.children,z=L?L.shapeFlag:0,J=V.children,{patchFlag:ne,shapeFlag:oe}=V;if(ne>0){if(ne&128){ee(B,J,g,G,U,I,E,O,Y);return}else if(ne&256){N(B,J,g,G,U,I,E,O,Y);return}}oe&8?(z&16&&ve(B,U,I),J!==B&&d(g,J)):z&16?oe&16?ee(B,J,g,G,U,I,E,O,Y):ve(B,U,I,!0):(z&8&&d(g,""),oe&16&&R(J,g,G,U,I,E,O,Y))},N=(L,V,g,G,U,I,E,O,Y)=>{L=L||nn,V=V||nn;const B=L.length,z=V.length,J=Math.min(B,z);let ne;for(ne=0;ne<J;ne++){const oe=V[ne]=Y?ii(V[ne]):Ut(V[ne]);m(L[ne],oe,g,null,U,I,E,O,Y)}B>z?ve(L,U,I,!0,!1,J):R(V,g,G,U,I,E,O,Y,J)},ee=(L,V,g,G,U,I,E,O,Y)=>{let B=0;const z=V.length;let J=L.length-1,ne=z-1;for(;B<=J&&B<=ne;){const oe=L[B],me=V[B]=Y?ii(V[B]):Ut(V[B]);if(wn(oe,me))m(oe,me,g,null,U,I,E,O,Y);else break;B++}for(;B<=J&&B<=ne;){const oe=L[J],me=V[ne]=Y?ii(V[ne]):Ut(V[ne]);if(wn(oe,me))m(oe,me,g,null,U,I,E,O,Y);else break;J--,ne--}if(B>J){if(B<=ne){const oe=ne+1,me=oe<z?V[oe].el:G;for(;B<=ne;)m(null,V[B]=Y?ii(V[B]):Ut(V[B]),g,me,U,I,E,O,Y),B++}}else if(B>ne)for(;B<=J;)K(L[B],U,I,!0),B++;else{const oe=B,me=B,ie=new Map;for(B=me;B<=ne;B++){const ot=V[B]=Y?ii(V[B]):Ut(V[B]);ot.key!=null&&ie.set(ot.key,B)}let se,_e=0;const Be=ne-me+1;let Ne=!1,Re=0;const De=new Array(Be);for(B=0;B<Be;B++)De[B]=0;for(B=oe;B<=J;B++){const ot=L[B];if(_e>=Be){K(ot,U,I,!0);continue}let Xe;if(ot.key!=null)Xe=ie.get(ot.key);else for(se=me;se<=ne;se++)if(De[se-me]===0&&wn(ot,V[se])){Xe=se;break}Xe===void 0?K(ot,U,I,!0):(De[Xe-me]=B+1,Xe>=Re?Re=Xe:Ne=!0,m(ot,V[Xe],g,null,U,I,E,O,Y),_e++)}const Qt=Ne?Uu(De):nn;for(se=Qt.length-1,B=Be-1;B>=0;B--){const ot=me+B,Xe=V[ot],Ht=V[ot+1],Vi=ot+1<z?Ht.el||ya(Ht):G;De[B]===0?m(null,Xe,g,Vi,U,I,E,O,Y):Ne&&(se<0||B!==Qt[se]?W(Xe,g,Vi,2):se--)}}},W=(L,V,g,G,U=null)=>{const{el:I,type:E,transition:O,children:Y,shapeFlag:B}=L;if(B&6){W(L.component.subTree,V,g,G);return}if(B&128){L.suspense.move(V,g,G);return}if(B&64){E.move(L,V,g,Z);return}if(E===Ge){n(I,V,g);for(let J=0;J<Y.length;J++)W(Y[J],V,g,G);n(L.anchor,V,g);return}if(E===fs){S(L,V,g);return}if(G!==2&&B&1&&O)if(G===0)O.persisted&&!I[so]?n(I,V,g):(O.beforeEnter(I),n(I,V,g),xt(()=>O.enter(I),U));else{const{leave:J,delayLeave:ne,afterLeave:oe}=O,me=()=>{L.ctx.isUnmounted?s(I):n(I,V,g)},ie=()=>{const se=I._isLeaving||!!I[so];I._isLeaving&&I[so](!0),O.persisted&&!se?me():J(I,()=>{me(),oe&&oe()})};ne?ne(I,me,ie):ie()}else n(I,V,g)},K=(L,V,g,G=!1,U=!1)=>{const{type:I,props:E,ref:O,children:Y,dynamicChildren:B,shapeFlag:z,patchFlag:J,dirs:ne,cacheIndex:oe,memo:me}=L;if(J===-2&&(U=!1),O!=null&&(ai(),Mn(O,null,g,L,!0),ci()),oe!=null&&(V.renderCache[oe]=void 0),z&256){V.ctx.deactivate(L);return}const ie=z&1&&ne,se=!rn(L);let _e;if(se&&(_e=E&&E.onVnodeBeforeUnmount)&&Ft(_e,V,L),z&6)de(L.component,g,G);else{if(z&128){L.suspense.unmount(g,G);return}ie&&$i(L,null,V,"beforeUnmount"),z&64?L.type.remove(L,V,g,Z,G):B&&!B.hasOnce&&(I!==Ge||J>0&&J&64)?ve(B,V,g,!1,!0):(I===Ge&&J&384||!U&&z&16)&&ve(Y,V,g),G&&re(L)}const Be=me!=null&&oe==null;(se&&(_e=E&&E.onVnodeUnmounted)||ie||Be)&&xt(()=>{_e&&Ft(_e,V,L),ie&&$i(L,null,V,"unmounted"),Be&&(L.el=null)},g)},re=L=>{const{type:V,el:g,anchor:G,transition:U}=L;if(V===Ge){ae(g,G);return}if(V===fs){x(L);return}const I=()=>{s(g),U&&!U.persisted&&U.afterLeave&&U.afterLeave()};if(L.shapeFlag&1&&U&&!U.persisted){const{leave:E,delayLeave:O}=U,Y=()=>E(g,I);O?O(L.el,I,Y):Y()}else I()},ae=(L,V)=>{let g;for(;L!==V;)g=h(L),s(L),L=g;s(V)},de=(L,V,g)=>{const{bum:G,scope:U,job:I,subTree:E,um:O,m:Y,a:B}=L;Or(Y),Or(B),G&&us(G),U.stop(),I&&(I.flags|=8,K(E,L,V,g)),O&&xt(O,V),xt(()=>{L.isUnmounted=!0},V)},ve=(L,V,g,G=!1,U=!1,I=0)=>{for(let E=I;E<L.length;E++)K(L[E],V,g,G,U)},Ee=L=>{if(L.shapeFlag&6)return Ee(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const V=h(L.anchor||L.el),g=V&&V[su];return g?h(g):V};let Se=!1;const fe=(L,V,g)=>{let G;L==null?V._vnode&&(K(V._vnode,null,null,!0),G=V._vnode.component):m(V._vnode||null,L,V,null,null,null,g),V._vnode=L,Se||(Se=!0,_r(G),ql(),Se=!1)},Z={p:m,um:K,m:W,r:re,mt:k,mc:R,pc:D,pbc:P,n:Ee,o:e};return{render:fe,hydrate:void 0,createApp:Iu(fe)}}function ro({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Ii({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Wu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function va(e,t,i=!1){const n=e.children,s=t.children;if(Te(n)&&Te(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=ii(s[o]),r.el=l.el),!i&&r.patchFlag!==-2&&va(l,r)),r.type===Gs&&(r.patchFlag===-1&&(r=s[o]=ii(r)),r.el=l.el),r.type===ui&&!r.el&&(r.el=l.el)}}function Uu(e){const t=e.slice(),i=[0];let n,s,o,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,l=i.length-1;o<l;)r=o+l>>1,e[i[r]]<c?o=r+1:l=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,l=i[o-1];o-- >0;)i[o]=l,l=t[l];return i}function ba(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:ba(t)}function Or(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ya(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ya(t.subTree):null}const ka=e=>e.__isSuspense;function Vu(e,t){t&&t.pendingBranch?Te(e)?t.effects.push(...e):t.effects.push(e):Qd(e)}const Ge=Symbol.for("v-fgt"),Gs=Symbol.for("v-txt"),ui=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),ri=[];let Tt=null;function X(e=!1){ri.push(Tt=e?null:[])}function or(){ri.pop(),Tt=ri[ri.length-1]||null}let Un=1;function Rr(e,t=!1){Un+=e,e<0&&Tt&&t&&(Tt.hasOnce=!0)}function wa(e){return e.dynamicChildren=Un>0?Tt||nn:null,or(),Un>0&&Tt&&Tt.push(e),e}function te(e,t,i,n,s,o){return wa(f(e,t,i,n,s,o,!0))}function qt(e,t,i,n,s){return wa(le(e,t,i,n,s,!0))}function rr(e){return e?e.__v_isVNode===!0:!1}function wn(e,t){return e.type===t.type&&e.key===t.key}const xa=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?tt(e)||Je(e)||Ae(e)?{i:at,r:e,k:t,f:!!i}:e:null);function f(e,t=null,i=null,n=0,s=null,o=e===Ge?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&xa(t),ref:t&&ps(t),scopeId:Zl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:at};return r?(As(a,i),o&128&&e.normalize(a)):i&&(a.shapeFlag|=tt(i)?8:16),Un>0&&!l&&Tt&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&Tt.push(a),a}const le=Gu;function Gu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===bu)&&(e=ui),rr(e)){const r=dn(e,t,!0);return i&&As(r,i),Un>0&&!o&&Tt&&(r.shapeFlag&6?Tt[Tt.indexOf(e)]=r:Tt.push(r)),r.patchFlag=-2,r}if(of(e)&&(e=e.__vccOpts),t){t=Ku(t);let{class:r,style:a}=t;r&&!tt(r)&&(t.class=Ce(r)),Ue(a)&&(Qo(a)&&!Te(a)&&(a=ct({},a)),t.style=Gt(a))}const l=tt(e)?1:ka(e)?128:ou(e)?64:Ue(e)?4:Ae(e)?2:0;return f(e,t,i,n,s,l,o,!0)}function Ku(e){return e?Qo(e)||ua(e)?ct({},e):e:null}function dn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=e,c=t?qu(s||{},t):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&xa(c),ref:t&&t.ref?i&&o?Te(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ge?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&dn(e.ssContent),ssFallback:e.ssFallback&&dn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&tr(d,a.clone(d)),d}function St(e=" ",t=0){return le(Gs,null,e,t)}function gt(e,t){const i=le(fs,null,e);return i.staticCount=t,i}function Ie(e="",t=!1){return t?(X(),qt(ui,null,e)):le(ui,null,e)}function Ut(e){return e==null||typeof e=="boolean"?le(ui):Te(e)?le(Ge,null,e.slice()):rr(e)?ii(e):le(Gs,null,String(e))}function ii(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:dn(e)}function As(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Te(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),As(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!ua(t)?t._ctx=at:s===3&&at&&(at.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ae(t)){if(n&65){As(e,{default:t});return}t={default:t,_ctx:at},i=32}else t=String(t),n&64?(i=16,t=[St(t)]):i=8;e.children=t,e.shapeFlag|=i}function qu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=Ce([t.class,n.class]));else if(s==="style")t.style=Gt([t.style,n.style]);else if(Ls(s)){const o=t[s],l=n[s];l&&o!==l&&!(Te(o)&&o.includes(l))?t[s]=o?[].concat(o,l):l:l==null&&o==null&&!Ps(s)&&(t[s]=l)}else s!==""&&(t[s]=n[s])}return t}function Ft(e,t,i,n=null){zt(e,t,7,[i,n])}const Yu=ra();let Zu=0;function Ju(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Yu,o={uid:Zu++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Sd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:pa(n,s),emitsOptions:la(n,s),emit:null,emitted:null,propsDefaults:Ve,inheritAttrs:n.inheritAttrs,ctx:Ve,data:Ve,props:Ve,attrs:Ve,slots:Ve,refs:Ve,setupState:Ve,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Eu.bind(null,o),e.ce&&e.ce(o),o}let ht=null;const Xu=()=>ht||at;let Bs,Ao;{const e=zs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};Bs=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),Ao=t("__VUE_SSR_SETTERS__",i=>Vn=i)}const Xn=e=>{const t=ht;return Bs(e),e.scope.on(),()=>{e.scope.off(),Bs(t)}},Nr=()=>{ht&&ht.scope.off(),Bs(null)};function Sa(e){return e.vnode.shapeFlag&4}let Vn=!1;function Qu(e,t=!1,i=!1){t&&Ao(t);const{props:n,children:s}=e.vnode,o=Sa(e);Pu(e,n,o,t),zu(e,s,i||t);const l=o?ef(e,t):void 0;return t&&Ao(!1),l}function ef(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,ku);const{setup:n}=i;if(n){ai();const s=e.setupContext=n.length>1?nf(e):null,o=Xn(e),l=Jn(n,e,0,[e.props,s]),r=Cl(l);if(ci(),o(),(r||e.sp)&&!rn(e)&&ea(e),r){if(l.then(Nr,Nr),t)return l.then(a=>{zr(e,a)}).catch(a=>{js(a,e,0)});e.asyncDep=l}else zr(e,l)}else Ca(e)}function zr(e,t,i){Ae(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ue(t)&&(e.setupState=Vl(t)),Ca(e)}function Ca(e,t,i){const n=e.type;e.render||(e.render=n.render||Zt);{const s=Xn(e);ai();try{wu(e)}finally{ci(),s()}}}const tf={get(e,t){return ft(e,"get",""),e[t]}};function nf(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,tf),slots:e.slots,emit:e.emit,expose:t}}function Ks(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Vl(Wd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in An)return An[i](e)},has(t,i){return i in t||i in An}})):e.proxy}function sf(e,t=!0){return Ae(e)?e.displayName||e.name:e.name||t&&e.__name}function of(e){return Ae(e)&&"__vccOpts"in e}const ye=(e,t)=>qd(e,t,Vn),rf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Bo;const Hr=typeof window<"u"&&window.trustedTypes;if(Hr)try{Bo=Hr.createPolicy("vue",{createHTML:e=>e})}catch{}const _a=Bo?e=>Bo.createHTML(e):e=>e,lf="http://www.w3.org/2000/svg",af="http://www.w3.org/1998/Math/MathML",ti=typeof document<"u"?document:null,Fr=ti&&ti.createElement("template"),cf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?ti.createElementNS(lf,e):t==="mathml"?ti.createElementNS(af,e):i?ti.createElement(e,{is:i}):ti.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>ti.createTextNode(e),createComment:e=>ti.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ti.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const l=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Fr.innerHTML=_a(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Fr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},df=Symbol("_vtc");function uf(e,t,i){const n=e[df];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ds=Symbol("_vod"),$a=Symbol("_vsh"),Do={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ds]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):xn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),xn(e,!0),n.enter(e)):n.leave(e,()=>{xn(e,!1)}):xn(e,t))},beforeUnmount(e,{value:t}){xn(e,t)}};function xn(e,t){e.style.display=t?e[Ds]:"none",e[$a]=!t}const ff=Symbol(""),pf=/(?:^|;)\s*display\s*:/;function hf(e,t,i){const n=e.style,s=tt(i);let o=!1;if(i&&!s){if(t)if(tt(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&Cn(n,r,"")}else for(const l in t)i[l]==null&&Cn(n,l,"");for(const l in i){l==="display"&&(o=!0);const r=i[l];r!=null?gf(e,l,!tt(t)&&t?t[l]:void 0,r)||Cn(n,l,r):Cn(n,l,"")}}else if(s){if(t!==i){const l=n[ff];l&&(i+=";"+l),n.cssText=i,o=pf.test(i)}}else t&&e.removeAttribute("style");Ds in e&&(e[Ds]=o?n.display:"",e[$a]&&(n.display="none"))}const jr=/\s*!important$/;function Cn(e,t,i){if(Te(i))i.forEach(n=>Cn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=mf(e,t);jr.test(i)?e.setProperty(Ci(n),i.replace(jr,""),"important"):e[n]=i}}const Wr=["Webkit","Moz","ms"],lo={};function mf(e,t){const i=lo[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return lo[t]=n;n=Rs(n);for(let s=0;s<Wr.length;s++){const o=Wr[s]+n;if(o in e)return lo[t]=o}return t}function gf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&tt(n)&&i===n}const Ur="http://www.w3.org/1999/xlink";function Vr(e,t,i,n,s,o=wd(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Ur,t.slice(6,t.length)):e.setAttributeNS(Ur,t,i):i==null||o&&!Tl(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Rt(i)?String(i):i)}function Gr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?_a(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Tl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(s||t)}function bi(e,t,i,n){e.addEventListener(t,i,n)}function vf(e,t,i,n){e.removeEventListener(t,i,n)}const Kr=Symbol("_vei");function bf(e,t,i,n,s=null){const o=e[Kr]||(e[Kr]={}),l=o[t];if(n&&l)l.value=n;else{const[r,a]=wf(t);if(n){const c=o[t]=Cf(n,s);bi(e,r,c,a)}else l&&(vf(e,r,l,a),o[t]=void 0)}}const yf=/(Once|Passive|Capture)$/,kf=/^on:?(?:Once|Passive|Capture)$/;function wf(e){let t,i;for(;(i=e.match(yf))&&!kf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ci(e.slice(2)),t]}let ao=0;const xf=Promise.resolve(),Sf=()=>ao||(xf.then(()=>ao=0),ao=Date.now());function Cf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Te(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&zt(c,t,5,r)}}else zt(s,t,5,[n])};return i.value=e,i.attached=Sf(),i}const qr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,_f=(e,t,i,n,s,o)=>{const l=s==="svg";t==="class"?uf(e,n,l):t==="style"?hf(e,i,n):Ls(t)?Ps(t)||bf(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):$f(e,t,n,l))?(Gr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Vr(e,t,n,l,o,t!=="value")):e._isVueCE&&(If(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!tt(n)))?Gr(e,wt(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Vr(e,t,n,l))};function $f(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&qr(t)&&Ae(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return qr(t)&&tt(i)?!1:t in e}function If(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(s=>wt(s)===n):Object.keys(i).some(s=>wt(s)===n)}const un=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Te(t)?i=>us(t,i):t};function Tf(e){e.target.composing=!0}function Yr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const li=Symbol("_assign");function Zr(e,t,i){return t&&(e=e.trim()),i&&(e=Ns(e)),e}const Lo={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[li]=un(s);const o=n||s.props&&s.props.type==="number";bi(e,t?"change":"input",l=>{l.target.composing||e[li](Zr(e.value,i,o))}),(i||o)&&bi(e,"change",()=>{e.value=Zr(e.value,i,o)}),t||(bi(e,"compositionstart",Tf),bi(e,"compositionend",Yr),bi(e,"change",Yr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},l){if(e[li]=un(l),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Ns(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===a)||(e.value=a)}},ls={deep:!0,created(e,t,i){e[li]=un(i),bi(e,"change",()=>{const n=e._modelValue,s=Gn(e),o=e.checked,l=e[li];if(Te(n)){const r=Go(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(pn(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(Ia(e,o))})},mounted:Jr,beforeUpdate(e,t,i){e[li]=un(i),Jr(e,t,i)}};function Jr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Te(t))s=Go(t,n.props.value)>-1;else if(pn(t))s=t.has(n.props.value);else{if(t===i)return;s=hn(t,Ia(e,!0))}e.checked!==s&&(e.checked=s)}const Ef={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,bi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Ns(Gn(o)):Gn(o));e[li](e.multiple?pn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Is(()=>{e._assigning=!1})}),e[li]=un(n)},mounted(e,{value:t}){Xr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[li]=un(i)},updated(e,{value:t}){e._assigning||Xr(e,t)}};function Xr(e,t){const i=e.multiple,n=Te(t);if(!(i&&!n&&!pn(t))){for(let s=0,o=e.options.length;s<o;s++){const l=e.options[s],r=Gn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Go(t,r)>-1}else l.selected=t.has(r);else if(hn(Gn(l),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Gn(e){return"_value"in e?e._value:e.value}function Ia(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Mf=["ctrl","shift","alt","meta"],Af={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Mf.some(i=>e[`${i}Key`]&&!t.includes(i))},Kt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let l=0;l<t.length;l++){const r=Af[t[l]];if(r&&r(s,t))return}return e(s,...o)}))},Bf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Df=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=Ci(s.key);if(t.some(l=>l===o||Bf[l]===o))return e(s)}))},Lf=ct({patchProp:_f},cf);let Qr;function Pf(){return Qr||(Qr=Fu(Lf))}const lr=((...e)=>{const t=Pf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Rf(n);if(!s)return;const o=t._component;!Ae(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=i(s,!1,Of(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},t});function Of(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Rf(e){return tt(e)?document.querySelector(e):e}const Nf="slides-config.json",fn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},yi=Fs({...fn});function zf(e){if(!e||typeof e!="object")return{...fn};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():fn.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Pi(e){if(!e||typeof e!="object")return{...yi};const t=e;return t.enableWebServeJump!==void 0&&(yi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(yi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(yi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...yi}}function qs(){return{...yi}}function Ta(e,t,i){const n=(e||fn.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${o}`}}const Ti={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Hf(e){var i,n,s,o,l,r;const t=qs();return e?{theme:((i=e[On])==null?void 0:i.trim())||Ti.theme,aspectRatio:((n=e[Rn])==null?void 0:n.trim())||Ti.aspectRatio,highlighter:((s=e[bl])==null?void 0:s.trim())||Ti.highlighter,defaultTransition:((o=e[Nn])==null?void 0:o.trim())||Ti.defaultTransition,colorSchema:((l=e[yl])==null?void 0:l.trim())||Ti.colorSchema,spacing:((r=e[wo])==null?void 0:r.trim())||Ti.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Ti,normalizeHeadingSizes:t.normalizeHeadingSizes}}function Kn(e){var i,n,s,o,l;const t=(i=e.ial)==null?void 0:i[Bi];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function el(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[we]&&(t.layout=e[we].trim()),e[pt]&&(t.transition=e[pt].trim()),e[it]&&(t.background=e[it].trim()),e[Lt]&&(t.image=e[Lt].trim()),e[Xi]&&(t.class=e[Xi].trim()),e[$n]&&(t.spacing=e[$n].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[Qi]&&(t.mask=e[Qi].trim()),e[Ri]&&(t.maskRatio=e[Ri].trim()),e[en]&&(t.maskStyle=e[en].trim()),e[tn]&&(t.maskInitial=e[tn].trim()),e[Xs]&&(i=e[Xs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![we,yt,Qi,Ri,en,tn,pt,it,Lt,Xi,$n,Xs,Bi].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function Ff(e){const t={};if(!e)return t;const i=e[Ke]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ye]??e["slides-role"],s=e[it]??e["slides-background"];(n===kl||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[we]??e["slides-layout"];o===Ss||o===Cs?t.imageLayout=o:(n===Ss||n===Cs)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Yt])try{const r=JSON.parse(e[Yt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Yt].trim()}}return e[Wi]&&(t.shikiLines=e[Wi].trim()),e[zn]&&(t.maxHeight=e[zn].trim()),e[$e]&&(t.slot=e[$e].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function Si(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Bn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>s?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function Ui(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function co(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Dn(e){if(!e)return[];if(st(e)&&Jt(e)&&!pi(e)){const n=gn(e),s=[];for(const o of n)s.push(...Dn(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Ui);if(l.length>0)return l}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return Ui(e)?[e]:[]}function ar(e){var s;if(!e||!st(e)||!Jt(e)||pi(e))return null;const t=gn(e);if(t.length===0)return null;if(t.length===1&&st(t[0])&&Jt(t[0])){const o=ar(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(st(o)){i.push(o);const l=((s=o.children)==null?void 0:s.filter(st))||[];i.push(...l)}const n=t.map(Dn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Dn(t[0]),l=Dn(t[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:i}}return null}function jf(e){if(!e||!st(e)||!Jt(e)||pi(e))return null;const t=ar(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=cr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:s}}function Ea(e){if(!e||!st(e)||!Jt(e)||pi(e))return null;const t=gn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Dn(n);if(s.length===0)return null;i.push(...s)}return i}function Wf(e){if(!e||!st(e)||!Jt(e)||pi(e))return null;const t=Ea(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function Uf(e){if(!e||!st(e)||!Jt(e)||pi(e))return null;const t=ar(e);if(t&&t.items.length===4)return t.items;const i=Ea(e);if(i&&i.length===4)return i;const n=gn(e);return n.length===4?n:null}function Vf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(st(r)){const c=Uf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=i[0]);const l=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>Ma(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function Gf(e,t,i){var d,p,h,u,v;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(Kn(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(m){const b=[];for(const y of m)st(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...a(y.children));return b}function c(m,b,y){const C={blockId:m,attrs:b,previousAttrs:y};n.push(C),i!=null&&i.onTagChange&&i.onTagChange(C)}for(const m of l){const b=m.pageTargetId,y=t.find(T=>T.id===b),C=o.find(T=>T.pageTargetId===b);if(m.blocks.some(T=>{var w,R;return!!(pi(T)||Po(T)&&(((w=T.ial)==null?void 0:w[we])==="image-left"||((R=T.ial)==null?void 0:R[we])==="image-right"))})){if(C){const T=C.headerId;if(T){c(T,{[$e]:""});const w=t.find(R=>R.id===T);w!=null&&w.ial&&(w.ial[$e]="")}for(const w of C.itemIds){c(w,{[$e]:""});const R=t.find(F=>F.id===w);R!=null&&R.ial&&(R.ial[$e]="")}}continue}let x=null,$=-1;for(let T=0;T<m.blocks.length;T++){const w=m.blocks[T],R=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const F of R){const P=jf(F);if(P){x=P,$=T;break}}if(x)break}if(x){const{superBlockNode:T,layout:w,items:R,slots:F}=x,q=m.blocks.slice(0,$).find(A=>Ma(A)),_=q==null?void 0:q.id,H=((d=y==null?void 0:y.ial)==null?void 0:d[we])||"",k=H==="clover",M=k?"clover":w;if(H!==M&&(c(b,{[we]:M},{[we]:H}),y&&(y.ial||(y.ial={}),y.ial[we]=M)),q){const A=((p=q.ial)==null?void 0:p[$e])||"";A!=="header"&&(c(q.id,{[$e]:"header"},{[$e]:A}),q.ial||(q.ial={}),q.ial[$e]="header")}if(C!=null&&C.headerId&&C.headerId!==_){c(C.headerId,{[$e]:""});const A=t.find(D=>D.id===C.headerId);A&&(A.ial||(A.ial={}),A.ial[$e]="")}const j=[];for(let A=0;A<R.length;A++){const D=R[A],N=F[A];j.push(D.id);const ee=((h=D.ial)==null?void 0:h[$e])||"";if(ee!==N&&(c(D.id,{[$e]:N},{[$e]:ee}),D.ial||(D.ial={}),D.ial[$e]=N),D.children&&D.children.length>0)for(const W of D.children)W.ial||(W.ial={}),W.ial[$e]!==N&&(W.ial[$e]=N)}if(C!=null&&C.itemIds){for(const A of C.itemIds)if(!j.includes(A)){c(A,{[$e]:""});const D=t.find(N=>N.id===A);D&&(D.ial||(D.ial={}),D.ial[$e]="")}}s.push({superBlockId:T.id,nestedSuperBlockIds:(u=x.nestedSuperBlocks)==null?void 0:u.map(A=>A.id),pageTargetId:b,headerId:_,itemIds:j,layout:k?"clover":w})}else{let T=!1;const w=[];for(const P of m.blocks){const q=st(P)?[P,...a(P.children||[])]:P.children?a(P.children):[];for(const _ of q){const H=Wf(_);if(H){T=!0;for(const k of H.items)w.push(k.id)}}}const R=((v=y==null?void 0:y.ial)==null?void 0:v[we])||"",F=Hn(R);if(C||T&&F){c(b,{[we]:""},{[we]:R}),y&&(y.ial||(y.ial={}),y.ial[we]="");const P=C==null?void 0:C.headerId;if(P){c(P,{[$e]:""});const _=t.find(H=>H.id===P);_&&(_.ial||(_.ial={}),_.ial[$e]="")}const q=new Set([...(C==null?void 0:C.itemIds)||[],...w]);for(const _ of q){c(_,{[$e]:""});const H=t.find(k=>k.id===_);H&&(H.ial||(H.ial={}),H.ial[$e]="")}}}}return{changes:n,newTracked:s}}function st(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Jt(e){if(!st(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Po(e){return!e||Ui(e)||st(e)||!Si(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function cr(e){var h;if(!e||!st(e)||!Jt(e))return null;const t=gn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const v=(((h=u.ial)==null?void 0:h.style)||u.style||"").trim();let m=null;if(v){const b=v.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=v.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((u,v)=>u+(v||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=i.map(u=>u!==null?u:a),d=c.reduce((u,v)=>u+v,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const v=Math.round(u),m=100-v;return`${v}:${m}`}if(p.length===3){const[u,v,m]=p;if(u>=31&&u<=35&&v>=31&&v<=35&&m>=31&&m<=35)return"1:1:1";if(u>=23&&u<=27&&v>=48&&v<=52&&m>=23&&m<=27)return"1:2:1";if(u>=48&&u<=52&&v>=23&&v<=27&&m>=23&&m<=27)return"2:1:1";if(u>=23&&u<=27&&v>=23&&v<=27&&m>=48&&m<=52)return"1:1:2";if(u>=18&&u<=22&&v>=58&&v<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(u),y=Math.round(v),C=100-b-y;return`${b}:${y}:${C}`}return p.map(u=>Math.round(u)).join(":")}function pi(e){if(!e||!st(e)||!Jt(e))return null;const t=(e.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Po(t[0]),n=Po(t[t.length-1]),s=cr(e)||void 0;if(i&&!n){const o=Si(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Ss,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=Si(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:Cs,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Kf(e,t){const i=[];function n(s){for(const o of s){const l=pi(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[we];if(d!==a){const h={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[we]=a,i.push(h),t&&t(h)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function gn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Ma(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ei(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const C=y[1];if(typeof t=="string"?C.split(/\s+/).includes(t):t.test(C)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,a);const d=a+c;let p=1,h=-1,u=-1;const v=/<\/?div\b[^>]*>/gi;v.lastIndex=d;let m;for(;(m=v.exec(e))!==null;)if(m[0].startsWith("</")){if(p--,p===0){h=m.index,u=m.index+m[0].length;break}}else p++;if(h!==-1&&u!==-1){const b=e.slice(d,h);n+=i(b),s=u}else n+=e.slice(a,d),s=d}return n}function qf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=o.index,a=o[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,p=-1,h=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let v;for(;(v=u.exec(e))!==null;)if(v[0].startsWith("</")){if(d--,d===0){p=v.index,h=v.index+v[0].length;break}}else d++;if(p!==-1&&h!==-1){const m=e.slice(r,h),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,n=h}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Yf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=qf(i);i=s;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ei(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=Ei(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ei(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ei(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ei(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ei(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ei(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,h)=>Math.max(p,h.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const h=p.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Aa(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function Zf(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Jf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Ba(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Xf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function as(e,t,i,n){const s=t!=null&&t.trim()!=="",o=Xf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${e}

</div>`:e;if(s&&!o){if(r){const v=t.trim();let m="v-click";return v==="hide"?m="v-click.hide":v!==""&&v!=="+1"&&(m=`v-click="${v}"`),`<div ${m}${a}>

${e}

</div>`}return Ba(e,t)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${p}${a}>

${e}

</div>`;const h=t.trim();let u="v-click";return h==="hide"?u="v-click.hide":h!==""&&h!=="+1"&&(u=`v-click="${h}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function dr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Qf(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Da(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),h=Math.floor(c.length/p),u=c.length%p;let v=0;for(let m=0;m<p;m++){const b=h+(m<u?1:0);d[m]=c.slice(v,v+b),v+=b}return d}if(e.length===1){const c=e[0],p=(c.slot||"").trim().match(/^col-(\d+)$/i),h=p?parseInt(p[1],10):null,u=(c.rawMarkdown||c.content||"").trim(),v=u.split(/\r?\n/),m=[];for(let C=0;C<v.length;C++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(v[C])&&m.push(C);if(m.length>=i){const C=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const $=i-x,T=m.length-S,w=Math.ceil(T/$),R=m[S],F=S+w<m.length?m[S+w]:v.length,P=v.slice(R,F).join(`
`);C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:P,content:P}],S+=w}return C}const b=u.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const C=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const $=i-x,T=b.length-S,w=Math.ceil(T/$),R=`<ul>
${b.slice(S,S+w).join(`
`)}
</ul>`;C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:R,content:R}],S+=w}return C}const y=u.split(/\r?\n\s*\r?\n/).filter(C=>C.trim()!=="");if(y.length>=i){const C=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const $=i-x,T=y.length-S,w=Math.ceil(T/$),R=y.slice(S,S+w).join(`

`);C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:R,content:R}],S+=w}return C}if(h&&h>=1&&h<=i){const C=Array.from({length:i},()=>[]);return C[h-1]=[c],C}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const h=parseInt(p[1],10);if(h>=1&&h<=i)return h}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let v=1;for(const b of e){const y=n(b);y!==null&&(v=y),u[v-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&u[0].length===0){const b=u.filter(y=>y.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),h=i-1;if(p.length>=h){const u=Math.floor(p.length/h),v=p.length%h,m=[d];let b=0;for(let y=0;y<h;y++){const C=u+(y<v?1:0);m.push(p.slice(b,b+C)),b+=C}return m}else if(p.length>0){const u=[d];for(let v=0;v<h;v++)u.push(v<p.length?[p[v]]:[]);return u}else return[d,...Array.from({length:h},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],h=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,h)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const h=i-p,u=e.length-d,v=Math.ceil(u/h);c[p]=e.slice(d,d+v),d+=v}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function tl(e,t,i,n){var d;const s=Hf(t),o=[],l=el(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Mt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Mt(r.frontmatter.image,n)),o.push(r);let a=[];for(const p of i){if(Kn(p)){a=[];const u=el(p.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Mt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Mt(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Mt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Mt(r.frontmatter.image,n)),o.push(r);continue}const h=(u,v)=>{var j,A,D,N;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const ee=W=>{for(const K of W)K.id&&!r.allBlockIds.includes(K.id)&&r.allBlockIds.push(K.id),K.children&&K.children.length>0&&ee(K.children)};ee(u.children)}let m=cd(u),b=u.ial?{...u.ial}:{};const y=m.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...dd(y[0]),...b},m=m.slice(0,y.index).trim()),u.type!=="c"&&!m.startsWith("```")&&(m=Aa(m));let C=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(m=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=m.trim());const S=Ff(b);if(m=ud(m,n),m=ld(m,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const ee=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],W=K=>{for(const re of K){if(re.ial)for(const[ae,de]of Object.entries(re.ial))ee.includes(ae)&&!b[ae]&&(b[ae]=de);re.children&&re.children.length>0&&W(re.children)}};W(u.children)}const x=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(m);if(x){const ee=b["custom-slides-autoplay"]==="true",W=b["custom-slides-loop"]==="true",K=b["custom-slides-muted"]==="true"||ee,re=b["custom-slides-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(ae,de)=>{let ve=de;return re?ve=ve.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ve)||(ve+=" controls"),ee&&!/autoplay/i.test(ve)?ve+=" autoplay playsinline":!ee&&b["custom-slides-autoplay"]==="false"&&(ve=ve.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),W&&!/loop/i.test(ve)?ve+=" loop":!W&&b["custom-slides-loop"]==="false"&&(ve=ve.replace(/\bloop\b/gi,"").trim()),K&&!/muted/i.test(ve)?ve+=" muted":!K&&b["custom-slides-muted"]==="false"&&(ve=ve.replace(/\bmuted\b/gi,"").trim()),`<video ${ve.trim()}>`})}if(S.isBackground){const ee=Si(m,u.content);if(ee){r.frontmatter.background=Mt(ee,n);return}}const $=pi(u);if($){r.frontmatter.layout=$.layout,r.frontmatter.image=Mt($.imageUrl,n),!r.frontmatter.layoutRatio&&$.ratio&&(r.frontmatter.layoutRatio=$.ratio);for(const ee of $.contentNodes)h(ee);return}if(S.imageLayout==="image-left"||S.imageLayout==="image-right"){const ee=Si(m,u.content);if(ee){r.frontmatter.layout=S.imageLayout,r.frontmatter.image=Mt(ee,n),!r.frontmatter.layoutRatio&&((j=u.ial)!=null&&j[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const ee of u.children)h(ee);return}const T=!!(S.slot||v!=null&&v.defaultSlot||r.frontmatter.layout==="clover"||Hn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(ee=>{var W,K;return((W=ee.ial)==null?void 0:W[$e])||((K=ee.ial)==null?void 0:K[Ze])})||S.slot||S.clicks||T)){for(const ee of u.children)S.slot&&(!ee.ial||!ee.ial[$e])&&(ee.ial||(ee.ial={}),ee.ial[$e]=S.slot),h(ee,{...v,parentClicks:S.clicks||(v==null?void 0:v.parentClicks),defaultSlot:S.slot||(v==null?void 0:v.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!S.clicks||!!((A=u.children)!=null&&A.some(ee=>{var W;return(W=ee.ial)==null?void 0:W[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(Ui(u)&&u.children&&u.children.length>0&&(T||S.clicks||u.children.some(ee=>{var W;return(W=ee.ial)==null?void 0:W[Ze]}))&&w){const ee=!!(u.children&&u.children.length>=2),W=u.children.find(Se=>!!(Se.markdown||Se.content||"").trim())||u.children[0],K=((D=W==null?void 0:W.ial)==null?void 0:D[Ze])||((N=W==null?void 0:W.ial)==null?void 0:N["custom-slides-click"]),re=!!(!S.clicks&&ee&&K),ae=S.clicks||(re?K:void 0)||(v==null?void 0:v.parentClicks),de=u.id||(v==null?void 0:v.parentContainerId),ve=S.slot||(v==null?void 0:v.defaultSlot);let Ee=!0;for(const Se of u.children){ve&&(!Se.ial||!Se.ial[$e])&&(Se.ial||(Se.ial={}),Se.ial[$e]=ve);const fe=!!(Se.markdown||Se.content||"").trim(),Z=Ee&&fe;Z&&(Se.markdown&&(Se.markdown=Bn(Se.markdown)),Se.content&&(Se.content=Bn(Se.content)),Ee=!1);let pe=Se;Z&&ae&&ee&&(pe={...Se,ial:{...Se.ial||{}}},delete pe.ial[Ze],delete pe.ial["custom-slides-click"]),h(pe,{parentClicks:ae,parentContainerId:de,defaultSlot:ve})}return}if(S.isNote){const ee=dr(m);ee&&(r.notes?r.notes+=`

`+ee:r.notes=ee),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:ee||u.content||"",rawMarkdown:m,isNote:!0,attributes:u.ial});return}S.shikiLines&&(m=Jf(m,S.shikiLines)),C=m.trim();const R=(u.content||"").trim();if(C==="::right::"||R==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const P=Qf(u);let q=S.slot,_=S.clicks,H=S.motion,k={...u.ial||{}};if(P!==null){for(;a.length>0&&a[a.length-1].level>=P;)a.pop();const ee=a.length>0?a[a.length-1]:void 0;!q&&(ee!=null&&ee.slot)&&(q=ee.slot),!_&&(ee!=null&&ee.clicks)&&!(v!=null&&v.parentContainerId)&&(_=ee.clicks),!H&&(ee!=null&&ee.motion)&&(H=ee.motion);const W={...(ee==null?void 0:ee.customAttrs)||{}};if(u.ial)for(const[K,re]of Object.entries(u.ial))K.startsWith("custom-slides-")&&!K.startsWith("custom-slides-slide")&&(W[K]=re);v!=null&&v.parentContainerId||a.push({level:P,slot:q,clicks:_,motion:H,customAttrs:W})}else{const ee=a.length>0?a[a.length-1]:void 0;ee&&(!q&&ee.slot&&ee.slot!=="header"&&(q=ee.slot),!_&&ee.clicks&&!(v!=null&&v.parentContainerId)&&(_=ee.clicks),!H&&ee.motion&&(H=ee.motion),ee.customAttrs&&(k={...ee.customAttrs,...k}))}!q&&r.blocks.some(ee=>ee.slot==="slot-divider-right")&&(q="right"),!q&&(v!=null&&v.defaultSlot)&&(q=v.defaultSlot),q&&(k[$e]=q),_&&!k[Ze]&&(k[Ze]=_),H&&!k[Yt]&&(k[Yt]=JSON.stringify(H)),(x||b["custom-slides-autoplay"]||b["custom-slides-muted"])&&(b["custom-slides-autoplay"]&&(k["custom-slides-autoplay"]=b["custom-slides-autoplay"],b["custom-slides-autoplay"]==="true"&&!b["custom-slides-muted"]&&(k["custom-slides-muted"]="true")),b["custom-slides-loop"]&&(k["custom-slides-loop"]=b["custom-slides-loop"]),b["custom-slides-muted"]&&(k["custom-slides-muted"]=b["custom-slides-muted"]),b["custom-slides-controls"]&&(k["custom-slides-controls"]=b["custom-slides-controls"]));const M={id:u.id,type:u.type,content:u.content||"",rawMarkdown:m,clicks:_,parentClicks:v==null?void 0:v.parentClicks,parentContainerId:v==null?void 0:v.parentContainerId,motion:H,shikiLines:S.shikiLines,slot:q,attributes:k,rawNode:u};r.blocks.push(M)};h(p)}for(let p=0;p<o.length;p++){const h=o[p],u=[],v={...h.frontmatter};p===0&&(v.theme=s.theme,v.aspectRatio=s.aspectRatio,v.highlighter=s.highlighter,v.transition=h.frontmatter.transition||s.defaultTransition);const m=Zf(v);m&&u.push(m);const b=h.blocks.filter($=>$.slot!=="slot-divider-right"),y=$=>$.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return as(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),C=$=>{const T=$.filter(P=>!!(P.rawMarkdown||P.content||"").trim());if(T.length===0)return;const w=T[0],R=(w.rawMarkdown||w.content||"").trim();(Ui(w)||/^(?:[-*+]|\d+\.)\s+/.test(R))&&(w.rawMarkdown=Bn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},S=$=>{var P,q;if($.length===0)return"";C($);const T=(P=$.find(_=>_.parentClicks))==null?void 0:P.parentClicks;if(!T)return $.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var H;return as(_.rawMarkdown,_.clicks,_.motion,(H=_.attributes)==null?void 0:H.style)}).join(`

`);const w=[];let R=[];const F=()=>{if(R.length===0)return;const _=R.map(H=>(H.rawMarkdown||H.content||"").trim()).filter(Boolean).join(`

`);_&&w.push(Ba(_,T)),R=[]};for(const _ of $){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(F(),w.push(as(_.rawMarkdown,_.clicks,_.motion,(q=_.attributes)==null?void 0:q.style))):R.push(_)}return F(),w.join(`

`)},x=h.frontmatter.layout||"default";if(x==="clover"||Hn(x)){let $=[];const T=b.filter(_=>_.slot==="header");if(T.length>0)$=T;else if(b.length>0){const _=b.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));_&&($=[_])}const w=b.filter(_=>!$.includes(_));let R=2;if(x==="clover")R=4;else if(x==="three-cols-header")R=3;else if(x==="two-cols-header")R=2;else{let _=0;for(const H of w){const k=(H.slot||"").match(/^col-(\d+)$/i);k&&(_=Math.max(_,parseInt(k[1],10)))}if(_>=2)R=_;else if(h.frontmatter.layoutRatio){const H=h.frontmatter.layoutRatio.trim();if(H.includes(":")){const k=H.split(":").map(M=>parseFloat(M.trim())).filter(M=>!isNaN(M)&&M>0);k.length>=2&&(R=k.length)}else{const k=H.split(/\s+/).filter(Boolean);k.length>=2&&(R=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(R=Math.min(6,w[0].children.length))}const F=Da(w,R);F.forEach((_,H)=>{const k=`col-${H+1}`;for(const M of _)(!M.slot||M.slot==="default")&&(M.slot=k);C(_)});const P=F.flat();if(w.length===1&&P.length>1){const _=h.blocks.findIndex(H=>H.id===w[0].id);_!==-1&&h.blocks.splice(_,1,...P)}const q=y($);if(q&&u.push(q),x==="two-cols-header"&&R===2){const _=S(F[0]||[]),H=S(F[1]||[]);_&&u.push(`::left::

${_}`),H&&u.push(`::right::

${H}`)}else F.forEach((_,H)=>{const k=S(_);k&&u.push(`::col-${H+1}::

${k}`)})}else if(x==="two-cols"){const $=b.filter(F=>F.slot==="left"),T=b.filter(F=>F.slot==="right");C($),C(T);const w=y($.length>0?$:b.filter(F=>F.slot!=="right")),R=y(T);u.push(w),R&&u.push(`::right::

${R}`)}else for(const $ of b)u.push(as($.rawMarkdown,$.clicks,$.motion,(d=$.attributes)==null?void 0:d.style));h.notes&&u.push(`<!--
${h.notes}
-->`),h.rawMarkdown=u.join(`

`).trim()}const c=o.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Oo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function ep(e){var s,o,l,r,a,c,d,p,h,u,v,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(h=b.light)!=null&&h.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(v=b.dark)!=null&&v.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Ln(e){const t=ep(e);return t?`${Oo}

/* Custom Workspace Inline Styles */
${t}`:Oo}function uo(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function tp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function ip(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(tp(l)?n.push(o.id):i.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function np(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ro(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function sp(e,t,i,n=8,s){const o=new Map;for(const h of t)h!=null&&h.id&&o.set(h.id,h);const l=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:i(h.id,h.ial),children:[]}),r=h=>{let u=h.parent_id,v=0;for(;u&&u!==e&&v++<16;){const m=o.get(u);if(!m||!np(m))return u;u=m.parent_id}return u||e},a=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||s&&s.size>0&&!s.has(h.id))continue;const u=r(h),v=a.get(u);v?v.push(h):a.set(u,[h])}if(s&&s.size>0)for(const h of a.values())h.sort((u,v)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(v.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(h,u)=>{const v=l(h);if(c.set(v.id,v),u>=n||!Ro(v))return v;const m=a.get(v.id);return m&&m.length>0&&(v.children=m.map(b=>d(b,u+1))),v};return{topLevel:(a.get(e)||[]).map(h=>d(h,0)),byId:c}}const op={getBlockAttrs:jo,getChildBlocks:Yn,getDocBlocksOrders:sd,setBlockAttrs:Fe,sql:an,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:od};class rp{constructor(t){ke(this,"deps");ke(this,"attrOverrides",new Map);ke(this,"trackedListSuperBlocks",new Map);ke(this,"fallbackWarnedDocId","");this.deps={...op,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,l]of Object.entries(i))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let M=0;M<o.length;M++)o[M]&&l.set(o[M],M);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=ip(s,c),p=new Map;if(Array.isArray(c))for(const M of c)M.id&&M.ial&&p.set(M.id,uo(M.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(u)){for(const M of u)if(M.block_id&&M.name){let j=p.get(M.block_id);j||(j={},p.set(M.block_id,j)),j[M.name]=M.value||""}}const v=(M,j)=>{const A={...p.get(M)||(j?uo(j):{})},D=this.attrOverrides.get(M);return D&&Object.assign(A,D),A},m=Array.isArray(c)&&c.length>0?sp(t,c,v,8,l):null,b=s.map(M=>M.id).filter(Boolean),y=M=>({id:M.id,parent_id:M.parent_id,root_id:M.root_id||t,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:v(M.id,M.ial),children:M.children}),C=async(M,j=0)=>{if(!M||j>8||!Ro(M))return;const A=await this.deps.getChildBlocks(M.id).catch(()=>[])||[];if(!(!Array.isArray(A)||A.length===0)){M.children=A.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:M.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:v(D.id,D.ial),children:[]}));for(const D of M.children)await C(D,j+1)}},S=new Map;for(const M of c)M!=null&&M.id&&S.set(M.id,M);const x=b.every(M=>{const j=S.get(M);return!j||!!j.type});let $=[],T=!1;if(m&&d.usable&&r&&x){this.fallbackWarnedDocId="";for(const[j,A]of d.leafPatch){const D=m.byId.get(j);D&&(D.content=A.content,D.markdown=A.markdown)}const M=new Map;for(const j of s)j!=null&&j.id&&M.set(j.id,j);for(const j of d.rebuildRoots){const A=m.byId.get(j),D=M.get(j);A&&D&&(A.content=D.content||"",A.markdown=D.markdown||""),await C(A)}for(const j of s){if(!(j!=null&&j.id)||m.byId.has(j.id))continue;const A=y(j);await C(A),m.byId.set(A.id,A),m.topLevel.push(A)}$=m.topLevel.filter(j=>l.has(j.id)).sort((j,A)=>(l.get(j.id)??0)-(l.get(A.id)??0))}else b.length>0?(T=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),$=s.map(M=>y(M))):m&&($=m.topLevel);const w=async(M,j=0)=>{if(!(!M||M.length===0||j>8))for(const A of M){if(Ro(A)&&(!A.children||A.children.length===0)){let N=await this.deps.getChildBlocks(A.id).catch(()=>[]);if(!N||N.length===0){const ee=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${A.id}' ORDER BY sort ASC, created ASC`;N=await this.deps.sql(ee).catch(()=>[])||[]}if(Array.isArray(N)&&N.length>0){const ee=new Set($.map(K=>K.id)),W=N.filter(K=>K.id!==A.id&&!ee.has(K.id));W.length>0&&(A.children=W.map(K=>{const re=p.get(K.id)||(K.ial?uo(K.ial):{}),ae=this.attrOverrides.get(K.id);return ae&&Object.assign(re,ae),{id:K.id,parent_id:K.parent_id||A.id,root_id:K.root_id||t,type:K.type,subType:K.subType,content:K.content||"",markdown:K.markdown||"",ial:re}}))}}A.children&&A.children.length>0&&await w(A.children,j+1)}};T&&await w($);const R=M=>{var j,A;for(const D of M)if(D.children&&D.children.length>0){R(D.children);for(const N of D.children)if(N.ial)for(const[ee,W]of Object.entries(N.ial))ee.startsWith("custom-slides-")&&!((j=D.ial)!=null&&j[ee])&&(D.ial||(D.ial={}),D.ial[ee]=W);if(D.ial){for(const[N,ee]of Object.entries(D.ial))if(N.startsWith("custom-slides-"))for(const W of D.children)(W.type==="video"||W.type==="NodeVideo"||/<video\b/i.test(W.markdown||W.content||""))&&!((A=W.ial)!=null&&A[N])&&(W.ial||(W.ial={}),W.ial[N]=ee)}}};R($),Kf($,M=>{const j={[we]:M.layout};this.setBlockAttrOverride(M.blockId,j),(this.deps.setBlockAttrs||Fe)(M.blockId,j).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const F=this.trackedListSuperBlocks.get(t)||[],P=Gf(t,$,{tracked:F,onTagChange:M=>{this.setBlockAttrOverride(M.blockId,M.attrs),M.blockId===t&&Object.assign(i,M.attrs);const j=D=>{for(const N of D)N.id===M.blockId&&(N.ial||(N.ial={}),Object.assign(N.ial,M.attrs)),N.children&&N.children.length>0&&j(N.children)};j($),(this.deps.setBlockAttrs||Fe)(M.blockId,M.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,P.newTracked);const q=new Set;for(const M of $){const j=M.markdown||M.content||"";if(j.includes("((")){const A=rd(j);for(const D of A)q.add(D.blockId)}}const _={};if(q.size>0){const M=Array.from(q).map(A=>`'${A}'`).join(","),j=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${M})`).catch(()=>[])||[];if(Array.isArray(j))for(const A of j)A.id&&(_[A.id]=A.markdown||A.content||"")}const H=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=tl(t,i,$,{baseUrl:H,refContentMap:_});try{const M=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=Ln(M)}catch{k.customThemeCss=Ln(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=tl(t,{},[],{});return n.customThemeCss=Ln(null),n}}}const Pe=new rp;class ur{constructor(t){ke(this,"devServerUrl","http://localhost:3030");ke(this,"isConnected",!1);ke(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let h="";d.length>0?h=p?"":`---
${d.join(`
`)}
---

`:p||(h=`---

`);let u="";if(c.layout==="two-cols"){const m=r.blocks.filter(S=>S.slot!=="right"),b=r.blocks.filter(S=>S.slot==="right"),y=m.map(S=>S.rawMarkdown||S.content||"").join(`

`),C=b.map(S=>S.rawMarkdown||S.content||"").join(`

`);u=`${y}

::right::

${C}`}else u=r.blocks.map(m=>m.rawMarkdown||m.content||"").join(`

`);let v="";return r.notes&&r.notes.trim()&&(v=`

<!--
${r.notes.trim()}
-->`),`${h}${u}${v}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}const lp={proMode:!0,presenterMode:!0,exportHtml:!0,exportPdf:!0,exportImage:!0,import:!0,aiScript:!0};function ni(e){return lp[e]===!1}function Ct(e){return!ni(e)}function ap(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function $t(e){const t=ap();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function fr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=$t("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function La(){var t,i;const e=fr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=$t("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function cp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qn(){const e=fr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=$t("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Pa(){var n,s;const e=fr(),t={...(e==null?void 0:e.env)||{}};if(qn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function No(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function dp(){const e=$t("os"),t=$t("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class pr{constructor(t){ke(this,"runner");this.runner=t||pr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=$t("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=qn()==="win32",r=Pa();return await new Promise(a=>{s(t,i,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=La(),i=qn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:i,isDesktop:t}}}class up{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pageChangedHandlers",[]);ke(this,"readyHandlers",[]);ke(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class fp{constructor(t){ke(this,"childProcess",null);ke(this,"activePort",null);ke(this,"isRunning",!1);ke(this,"defaultPort");ke(this,"maxPortRetries");ke(this,"probeTimeoutMs");ke(this,"customSpawner");ke(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=$t("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=qn()==="win32"?"npx.cmd":"npx",l=No(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let p=(a=$t("child_process"))==null?void 0:a.spawn;if(!p){const v=await import("node:child_process").catch(()=>({}));p=v==null?void 0:v.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const h=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Pa();this.childProcess=p(o,r,{cwd:h,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),qn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=$t("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pendingMessages",[]);ke(this,"slideChangedHandlers",[]);ke(this,"blockClickedHandlers",[]);ke(this,"openInEditorHandlers",[]);ke(this,"clientReadyHandlers",[]);ke(this,"openPeekDrawerHandlers",[]);ke(this,"toggleFullscreenHandlers",[]);ke(this,"openPresenterHandlers",[]);ke(this,"captureProgressHandlers",[]);ke(this,"capturePageDoneHandlers",[]);ke(this,"captureCompleteHandlers",[]);ke(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",l={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const Oa={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},pp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,hp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,mp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,gp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,vp=`${Oo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function bp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class yp{constructor(t){ke(this,"workspacePath");ke(this,"slidesFileName");ke(this,"cliBridge",new ur);const i=dp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=No(o),a=No(l),c=bp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const S of c){const x=Oa[S]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${S}
// #endregion snippet
`;d.set(S,x)}t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",pp),t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",hp),t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="clover"})&&d.set("layouts/clover.vue",mp),d.set("setup/root.ts",gp),d.set("styles/index.css",vp);const v=$t("fs"),m=$t("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",C=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(v&&m&&C)try{v.existsSync(y)||v.mkdirSync(y,{recursive:!0}),v.writeFileSync(a,s,"utf-8"),v.writeFileSync(r,n,"utf-8");for(const[S,x]of d.entries()){const $=m.join(y,S),T=m.dirname($);v.existsSync(T)||v.mkdirSync(T,{recursive:!0}),v.existsSync($)||v.writeFileSync($,x,"utf-8")}b=!0}catch{}if(!b&&i)try{const S=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),x=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(l,!1,x),await i(o,!1,S);for(const[$,T]of d.entries()){const w=`${this.workspacePath}/${$}`,R=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(w,!1,R).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch(S){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String(S)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class kp{constructor(){ke(this,"mode","web-sandbox");ke(this,"webBridge");ke(this,"cliBridge");ke(this,"nativeBridge");ke(this,"processManager");ke(this,"scaffolder");ke(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new ur,this.nativeBridge=new up,this.processManager=new fp,this.scaffolder=new yp,this.envDetector=new pr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const wp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},xp={key:0},Sp={key:1},Cp={key:2},_p={key:3},$p={key:4},Ip={key:5},Tp={key:6},Ep={key:7},Mp={key:8},Ap={key:9},Bp={key:10},Dp={key:11},Lp={key:12},Pp={key:13},Op={key:14},Rp={key:15},Np={key:16},zp={key:17},Hp={key:18},Fp={key:19},jp={key:20},Wp={key:21},Up={key:22},Vp={key:23},Gp={key:24},Kp={key:25},qp={key:26},Yp={key:27},Zp={key:28},Jp={key:29},Xp={key:30},Qp={key:31},eh={key:32},th={key:33},ih={key:34},nh={key:35},sh={key:36},oh={key:37},rh={key:38},lh={key:39},ah={key:40},ch={key:41},dh={key:42},uh={key:43},fh={key:44},ph={key:45},hh={key:46},mh={key:47},gh={key:48},vh={key:49},bh={key:50},yh={key:51},kh={key:52},wh={key:53},xh={key:54},Sh={key:55},Ch={key:56},_h={key:57},$h={key:58},Ih={key:59},Th={key:60},Eh={key:61},Mh={key:62},Ah={key:63},Bh={key:64},Dh={key:65},Lh={key:66},Ph={key:67},Oh={key:68},Rh={key:69},Nh={key:70},zh={key:71},Hh=Et({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(X(),te("svg",wp,[e.name==="fullscreen"||e.name==="maximize"?(X(),te("g",xp,[...i[0]||(i[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(X(),te("g",Sp,[...i[1]||(i[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(X(),te("g",Cp,[...i[2]||(i[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(X(),te("g",_p,[...i[3]||(i[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(X(),te("g",$p,[...i[4]||(i[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(X(),te("g",Ip,[...i[5]||(i[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(X(),te("g",Tp,[...i[6]||(i[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(X(),te("g",Ep,[...i[7]||(i[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(X(),te("g",Mp,[...i[8]||(i[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(X(),te("g",Ap,[...i[9]||(i[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(X(),te("g",Bp,[...i[10]||(i[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(X(),te("g",Dp,[...i[11]||(i[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(X(),te("g",Lp,[...i[12]||(i[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(X(),te("g",Pp,[...i[13]||(i[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(X(),te("g",Op,[...i[14]||(i[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(X(),te("g",Rp,[...i[15]||(i[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(X(),te("g",Np,[...i[16]||(i[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(X(),te("g",zp,[...i[17]||(i[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(X(),te("g",Hp,[...i[18]||(i[18]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(X(),te("g",Fp,[...i[19]||(i[19]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(X(),te("g",jp,[...i[20]||(i[20]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(X(),te("g",Wp,[...i[21]||(i[21]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(X(),te("g",Up,[...i[22]||(i[22]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(X(),te("g",Vp,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-e1c698ec></path>',5)])])):e.name==="ratio"?(X(),te("g",Gp,[...i[24]||(i[24]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(X(),te("g",Kp,[...i[25]||(i[25]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(X(),te("g",qp,[...i[26]||(i[26]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(X(),te("g",Yp,[...i[27]||(i[27]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(X(),te("g",Zp,[...i[28]||(i[28]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(X(),te("g",Jp,[...i[29]||(i[29]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(X(),te("g",Xp,[...i[30]||(i[30]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(X(),te("g",Qp,[...i[31]||(i[31]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(X(),te("g",eh,[...i[32]||(i[32]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(X(),te("g",th,[...i[33]||(i[33]=[f("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(X(),te("g",ih,[...i[34]||(i[34]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(X(),te("g",nh,[...i[35]||(i[35]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(X(),te("g",sh,[...i[36]||(i[36]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(X(),te("g",oh,[...i[37]||(i[37]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(X(),te("g",rh,[...i[38]||(i[38]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(X(),te("g",lh,[...i[39]||(i[39]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(X(),te("g",ah,[...i[40]||(i[40]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(X(),te("g",ch,[...i[41]||(i[41]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(X(),te("g",dh,[...i[42]||(i[42]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(X(),te("g",uh,[...i[43]||(i[43]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-e1c698ec></path><polyline points="14 2 14 8 20 8" data-v-e1c698ec></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-e1c698ec></line><line x1="16" y1="17" x2="8" y2="17" data-v-e1c698ec></line><line x1="10" y1="9" x2="8" y2="9" data-v-e1c698ec></line>',5)])])):e.name==="focus"||e.name==="target"?(X(),te("g",fh,[...i[44]||(i[44]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(X(),te("g",ph,[...i[45]||(i[45]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(X(),te("g",hh,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-e1c698ec></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-e1c698ec></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-e1c698ec></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-e1c698ec></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(X(),te("g",mh,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-e1c698ec></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-e1c698ec></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-e1c698ec></line><line x1="5" y1="15" x2="8" y2="15" data-v-e1c698ec></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-e1c698ec></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-e1c698ec></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-e1c698ec></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(X(),te("g",gh,[...i[48]||(i[48]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-e1c698ec></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-e1c698ec></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-e1c698ec></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-e1c698ec></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-e1c698ec></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(X(),te("g",vh,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-e1c698ec></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-e1c698ec></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-e1c698ec></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-e1c698ec></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-e1c698ec></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-e1c698ec></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-e1c698ec></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(X(),te("g",bh,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7" x2="13" y2="7" data-v-e1c698ec></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-e1c698ec></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-e1c698ec></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-e1c698ec></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-e1c698ec></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(X(),te("g",yh,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" data-v-e1c698ec></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-e1c698ec></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-e1c698ec></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-e1c698ec></line><circle cx="15.5" cy="8.5" r="1.2" data-v-e1c698ec></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-e1c698ec></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(X(),te("g",kh,[...i[52]||(i[52]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" data-v-e1c698ec></line><circle cx="6" cy="8.5" r="1.2" data-v-e1c698ec></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-e1c698ec></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-e1c698ec></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-e1c698ec></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-e1c698ec></line>',7)])])):e.name==="layout-center"||e.name==="center"?(X(),te("g",wh,[...i[53]||(i[53]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(X(),te("g",xh,[...i[54]||(i[54]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><circle cx="8" cy="9" r="1.5" data-v-e1c698ec></circle><line x1="14" y1="8" x2="9" y2="14" data-v-e1c698ec></line><circle cx="15" cy="13" r="1.5" data-v-e1c698ec></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-e1c698ec></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(X(),te("g",Sh,[...i[55]||(i[55]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><circle cx="7.5" cy="9.5" r="2" data-v-e1c698ec></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-e1c698ec></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-e1c698ec></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-e1c698ec></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-e1c698ec></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(X(),te("g",Ch,[...i[56]||(i[56]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-e1c698ec></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-e1c698ec></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-e1c698ec></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-e1c698ec></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(X(),te("g",_h,[...i[57]||(i[57]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(X(),te("g",$h,[...i[58]||(i[58]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(X(),te("g",Ih,[...i[59]||(i[59]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(X(),te("g",Th,[...i[60]||(i[60]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(X(),te("g",Eh,[...i[61]||(i[61]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(X(),te("g",Mh,[...i[62]||(i[62]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(X(),te("g",Ah,[...i[63]||(i[63]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-e1c698ec></line><line x1="4" y1="10" x2="4" y2="3" data-v-e1c698ec></line><line x1="12" y1="21" x2="12" y2="12" data-v-e1c698ec></line><line x1="12" y1="8" x2="12" y2="3" data-v-e1c698ec></line><line x1="20" y1="21" x2="20" y2="16" data-v-e1c698ec></line><line x1="20" y1="12" x2="20" y2="3" data-v-e1c698ec></line><line x1="1" y1="14" x2="7" y2="14" data-v-e1c698ec></line><line x1="9" y1="8" x2="15" y2="8" data-v-e1c698ec></line><line x1="17" y1="16" x2="23" y2="16" data-v-e1c698ec></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(X(),te("g",Bh,[...i[64]||(i[64]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(X(),te("g",Dh,[...i[65]||(i[65]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(X(),te("g",Lh,[...i[66]||(i[66]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(X(),te("g",Ph,[...i[67]||(i[67]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(X(),te("g",Oh,[...i[68]||(i[68]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-e1c698ec></rect><line x1="13" y1="8" x2="19" y2="8" data-v-e1c698ec></line><line x1="13" y1="12" x2="19" y2="12" data-v-e1c698ec></line><line x1="13" y1="16" x2="17" y2="16" data-v-e1c698ec></line>',5)])])):e.name==="image-right"?(X(),te("g",Rh,[...i[69]||(i[69]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-e1c698ec></rect><line x1="5" y1="8" x2="11" y2="8" data-v-e1c698ec></line><line x1="5" y1="12" x2="11" y2="12" data-v-e1c698ec></line><line x1="5" y1="16" x2="9" y2="16" data-v-e1c698ec></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(X(),te("g",Nh,[...i[70]||(i[70]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(X(),te("g",zh,[...i[71]||(i[71]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Xt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},ue=Xt(Hh,[["__scopeId","data-v-e1c698ec"]]),Fh={class:"spm-immersion-header"},jh={class:"spm-immersion-header__left"},Wh={class:"spm-immersion-title"},Uh={class:"spm-immersion-header__center"},Vh={class:"spm-immersion-header__actions"},Gh=["aria-label"],Kh={class:"spm-immersion-body"},qh=Et({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Dt((X(),te("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Kt(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:o}),f("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",Fh,[f("div",jh,[rs(a.$slots,"header-left",{},()=>[f("span",Wh,xe(e.title),1)])]),f("div",Uh,[rs(a.$slots,"header-center",{},void 0)]),f("div",Vh,[rs(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(ue,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Gh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[le(ue,{name:"close"})])])]),f("div",Kh,[rs(a.$slots,"default",{},void 0)])],2)],34)),[[Do,e.visible]])}}),Yh=Xt(qh,[["__scopeId","data-v-1359fecb"]]),Zh={class:"spm-protyle-drawer"},Jh={class:"spm-protyle-drawer__subbar"},Xh={class:"spm-protyle-drawer__nav"},Qh=["title"],em={class:"spm-protyle-drawer__actions"},tm=["aria-label"],im=["aria-label"],nm=Et({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(n.blockId),o=ge(n.title||""),l=ge(!1),r=ge(!0),a=ge(!1),c=ge(""),d=yi,p=ge([]),h=ge(null);let u=null;Hi(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",p.value=[],m(w))}),mn(()=>{s.value&&m(s.value)}),ir(()=>{b()});async function v(w){try{const R=await an(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(R)&&R.length>0){const F=R[0];c.value=F.root_id||"";const P=F.id===F.root_id||F.type==="d";a.value=P,r.value=!P,!o.value&&F.content&&(o.value=F.content.trim().slice(0,30));return}}catch(R){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",R)}a.value=!1,r.value=!0}async function m(w,R){if(!h.value||!w)return;b(),await v(w),typeof R=="boolean"&&(r.value=!a.value&&R);let F,P;r.value&&!a.value?(F=["cb-get-all","cb-get-hl","cb-get-focus"],P={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(F=["cb-get-context","cb-get-hl"],P={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new ce.Protyle(n.plugin.app,h.value,{blockId:w,action:F,render:P}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(q){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",q)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}h.value&&(h.value.innerHTML="")}function y(){a.value||(r.value=!r.value,m(s.value,r.value))}function C(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(s.value)try{ce.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function x(){var F;if(!s.value)return;const w=qs(),R=Ta(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const P=$t("electron");(F=P==null?void 0:P.shell)!=null&&F.openExternal?P.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}i("external-jump",R)}function $(){if(p.value.length>0){const w=p.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,m(w.blockId,w.isFocusMode))}}function T(w){const R=w.target;if(!R)return;const F=R.closest('[data-type="block-ref"]');if(F){const q=F.getAttribute("data-id");if(q&&q!==s.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=q,o.value=F.innerText.trim()||q,m(q);return}}const P=R.closest("a");if(P&&P.href&&P.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const q=P.href.replace("siyuan://blocks/","").split("?")[0];q&&q!==s.value&&(p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=q,o.value=P.innerText.trim()||q,m(q))}}return(w,R)=>(X(),te("div",Zh,[f("div",Jh,[f("div",Xh,[p.value.length>0?(X(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:$},[le(ue,{name:"arrow-left"}),R[0]||(R[0]=f("span",null,"返回",-1))])):Ie("",!0),f("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xe(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:o.value||s.value},xe(o.value||s.value),9,Qh)]),f("div",em,[a.value?Ie("",!0):(X(),te("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[le(ue,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,xe(r.value?"块聚焦":"展开全文"),1)],10,tm)),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:C},[le(ue,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,xe(l.value?"编辑中":"只读"),1)],10,im),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[le(ue,{name:"window"}),R[1]||(R[1]=f("span",null,"独立窗口",-1))]),he(d).enableWebServeJump?(X(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:x},[le(ue,{name:"external-link"}),R[2]||(R[2]=f("span",null,"外跳",-1))])):Ie("",!0)])]),f("div",{ref_key:"mountEl",ref:h,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),sm=Xt(nm,[["__scopeId","data-v-0d6e2df3"]]),om=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,rm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function il(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Ra(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function lm(e){const t=e.split(/[/?#]/)[0];return!t||rm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function am(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Na(e){const t=cm(e);return t.external||!t.url?t:{url:am(t.url),external:!1}}function cm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(wl(t))return{url:`/${xl(t)}`,external:!1};if(/^file:/i.test(t)){const n=il(Ra(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=il(t);return n?{url:n,external:!1}:{url:t,external:!0}}return om.test(t)?{url:t,external:!0}:lm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const dm={class:"spm-webview-drawer"},um={class:"spm-webview-toolbar"},fm={class:"spm-webview-toolbar__nav"},pm=["disabled"],hm=["disabled"],mm=["aria-label"],gm={class:"spm-webview-toolbar__address"},vm=["aria-label"],bm={class:"spm-webview-toolbar__actions"},ym=["aria-label"],km={class:"spm-zoom-controller"},wm=["disabled"],xm=["disabled"],Sm={key:1,class:"spm-webview-fallback"},Cm=["src"],_m={key:2,class:"spm-load-error"},$m={class:"spm-load-error__code"},Im={class:"spm-load-error__code-num"},Tm={class:"spm-load-error__url"},Em={class:"spm-load-error__hint"},Mm={class:"spm-load-error__actions"},nl="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",za="siyuan-slides-peek-view-mode";let Ha="desktop";function Am(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(za);if(e==="mobile"||e==="desktop")return e}catch{}return Ha}function Bm(e){if(Ha=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(za,e)}catch{}}function Dm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Lm=Et({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(La()&&!cp()),o=ge(n.url),l=ge(n.url),r=n.url,a=ge(!1),c=ge(null),d=ge(!1),p=ge(!1),h=ge(1),u=ge(!1),v=ge(Am());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ye(()=>v.value==="mobile"?nl:m||void 0),y=ge(null),C=ge(null);let S=null,x=null,$=null;Hi(()=>n.url,Z=>{Z&&Z!==o.value&&(o.value=Z,l.value=Z,v.value==="mobile"&&P(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z))}),Hi(()=>n.visible,Z=>{if(Z)re(),v.value==="mobile"&&P(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),mn(()=>{T(),C.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const Z=y.value;if(Z&&typeof Z.invalidate=="function")try{Z.invalidate()}catch{}}),S.observe(C.value)),x=Z=>{var L;const pe=Z.message||((L=Z.error)==null?void 0:L.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return Z.preventDefault(),Z.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),$=Z=>{const pe=Z.reason,L=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&Z.preventDefault()},window.addEventListener("unhandledrejection",$)}),ir(()=>{if(w(),S&&(S.disconnect(),S=null),x&&(window.removeEventListener("error",x,!0),x=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function T(){const Z=y.value;Z&&(Z.addEventListener("dom-ready",R),Z.addEventListener("did-start-loading",q),Z.addEventListener("did-stop-loading",k),Z.addEventListener("did-navigate",M),Z.addEventListener("did-navigate-in-page",j),Z.addEventListener("new-window",A),Z.addEventListener("did-fail-load",_),Z.addEventListener("did-fail-provisional-load",_))}function w(){const Z=y.value;if(Z)try{Z.removeEventListener("dom-ready",R),Z.removeEventListener("did-start-loading",q),Z.removeEventListener("did-stop-loading",k),Z.removeEventListener("did-navigate",M),Z.removeEventListener("did-navigate-in-page",j),Z.removeEventListener("new-window",A),Z.removeEventListener("did-fail-load",_),Z.removeEventListener("did-fail-provisional-load",_)}catch{}}function R(){const Z=y.value;if(Z&&typeof Z.getUserAgent=="function"&&!m)try{const pe=Z.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}v.value==="mobile"&&P(!1),re(),D()}function F(){const Z=v.value==="mobile"?"desktop":"mobile";v.value=Z,Bm(Z),P(!0)}function P(Z=!1){const pe=y.value;if(!pe)return;const L=v.value==="mobile"?nl:m;if(typeof pe.setUserAgent=="function"&&L)try{pe.setUserAgent(L)}catch(V){console.warn("[WebviewPeekDrawer] setUserAgent error:",V)}if(Z&&typeof pe.reload=="function")try{pe.reload()}catch(V){console.warn("[WebviewPeekDrawer] reload error:",V)}}function q(){a.value=!0,c.value=null}function _(Z){if(Z&&Z.isMainFrame===!1||Z&&Number(Z.errorCode)===-3)return;const pe=String((Z==null?void 0:Z.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Z==null?void 0:Z.errorCode)??0),description:pe,validatedURL:String((Z==null?void 0:Z.validatedURL)||o.value),hint:Dm(pe)},a.value=!1}function H(){c.value=null,W()}function k(){if(a.value=!1,D(),y.value&&typeof y.value.getURL=="function"){const Z=y.value.getURL();Z&&Z!=="about:blank"&&(o.value=Z,l.value=Z)}}function M(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),D()}function j(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),D()}function A(Z){Z&&Z.url&&(Z.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url))}function D(){const Z=y.value;Z&&(typeof Z.canGoBack=="function"&&(d.value=Z.canGoBack()),typeof Z.canGoForward=="function"&&(p.value=Z.canGoForward()))}function N(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function ee(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function W(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function K(){const Z=Na(l.value);if(Z.url){if(Z.external){o.value=Z.url,fe();return}o.value=Z.url,l.value=Z.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url)}}function re(){const Z=y.value;if(Z&&typeof Z.setZoomFactor=="function")try{Z.setZoomFactor(h.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ae(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),re()}function de(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),re()}function ve(){h.value=1,re()}function Ee(Z){Z.preventDefault(),Z.deltaY<0?ae():Z.deltaY>0&&de()}async function Se(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Z){console.warn("Copy url failed:",Z)}}function fe(){var pe;const Z=o.value;if(typeof window<"u"){const L=$t("electron");(pe=L==null?void 0:L.shell)!=null&&pe.openExternal?L.shell.openExternal(Z).catch(()=>{window.open(Z,"_blank")}):window.open(Z,"_blank")}i("external-jump",Z)}return(Z,pe)=>{const L=vu("webview");return X(),te("div",dm,[f("div",um,[f("div",fm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:N},[le(ue,{name:"arrow-left"})],8,pm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:ee},[le(ue,{name:"arrow-right"})],8,hm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:W},[le(ue,{name:"refresh"})],8,mm)]),f("div",gm,[Dt(f("input",{"onUpdate:modelValue":pe[0]||(pe[0]=V=>l.value=V),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Df(K,["enter"])},null,544),[[Lo,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:Se},[le(ue,{name:"copy"})],8,vm)]),f("div",bm,[f("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":v.value==="mobile"}]),"aria-label":v.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:F},[le(ue,{name:v.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,ym),f("div",km,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:de},[le(ue,{name:"minus"})],8,wm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ve},xe(Math.round(h.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:ae},[le(ue,{name:"plus"})],8,xm)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[le(ue,{name:"external-link"}),pe[1]||(pe[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:C,class:Ce(["spm-webview-body",{"is-mobile":v.value==="mobile"}]),onWheel:Kt(Ee,["ctrl"])},[f("div",{class:Ce(["spm-webview-viewport",{"is-mobile":v.value==="mobile"}])},[s.value?(X(),qt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:he(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(X(),te("div",Sm,[f("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Cm),f("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(X(),te("div",_m,[le(ue,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",$m,[St(xe(c.value.description)+" ",1),f("span",Im,"("+xe(c.value.errorCode)+")",1)]),f("div",Tm,xe(c.value.validatedURL),1),f("p",Em,xe(c.value.hint),1),f("div",Mm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:H},[le(ue,{name:"refresh"}),pe[3]||(pe[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[le(ue,{name:"external-link"}),pe[4]||(pe[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Ie("",!0)],2)],34)])}}}),Pm=Xt(Lm,[["__scopeId","data-v-6e363f73"]]);class Om{constructor(){ke(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Rm{constructor(t){ke(this,"blockToPageMap",new Map);ke(this,"debounceCtrl",new Om);ke(this,"activeBlockId","");ke(this,"activePageIndex",1);ke(this,"currentDocId","");ke(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let It=null,hs=null,ms="";function Pn(){var e,t;if(hs&&(clearTimeout(hs),hs=null),It){try{It.classList.remove("protyle-wysiwyg--select"),ms?It.style.outline=ms:typeof((e=It.style)==null?void 0:e.removeProperty)=="function"?It.style.removeProperty("outline"):It.style&&(It.style.outline=""),typeof((t=It.style)==null?void 0:t.removeProperty)=="function"?It.style.removeProperty("transition"):It.style&&(It.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}It=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,l;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((l=n.style)==null?void 0:l.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function Fi(e,t){var l,r,a,c;if(!e||typeof document>"u")return Pn(),!1;Pn();const i=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ce.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(d){console.warn("[SelectionMirror] openTab fallback failed:",d)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(a=n.focus)==null||a.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),It=n,hs=setTimeout(()=>{Pn()},500),!0}function Nm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function zm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else o.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Fa(e,t,i){var h,u,v,m;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const C=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(C){const T=C[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:C[2].toLowerCase()==="x",text:C[3],media:[]});continue}const S=y.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const T=S[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:S[2],media:[]});continue}const x=y.match(/^(\s*)\d+\.\s+(.*)$/);if(x){l.length===0&&(r=!0);const T=x[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:x[2],media:[]});continue}const $=y.trim();if(!(!$||/^\{:.*?\}$/.test($)))if(l.length>0){const T=$.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const F=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(T[1])}" src="${T[2]}" class="${F}" /></div>`);continue}if($.match(/^<img\b[\s\S]*?\/?>$/i)){const R=$.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${R}</div>`);continue}if(/<video\b/i.test($)){let R=$;if(!/<\/video>/i.test(R))for(;b+1<n.length&&!/<\/video>/i.test(R);)b++,R+=" "+n[b].trim();const F=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(R),P=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slides-loop"])==="true"||/loop/i.test(R),q=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-muted"])==="true"||F||/muted/i.test(R),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",H=R.match(/\bsrc=["']([^"']+)["']/i),k=H?H[1]:"",M=['class="slide-video-player"'];_||M.push("controls"),F&&(M.push("autoplay"),M.push("playsinline")),P&&M.push("loop"),q&&M.push("muted"),M.push('preload="metadata"'),k&&M.push(`src="${k}"`);const j=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=j?j[1].trim():"";!A&&k&&(A=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${F?"true":"false"}" data-muted="${q?"true":"false"}"><video ${M.join(" ")}>${A}</video></div>`);continue}l[l.length-1].text+=`
`+$}else o.push($)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const y=Nm(b.text),C=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",S=b.level||0,x=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",$=S>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${$}"${x}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${C}</li>`}return`<li${$?` class="${$.trim()}"`:""}${x}>${y}${C}</li>`}).join(`
`);return`${zm(o)}<${a} class="${c}">
${d}
</${a}>`}function Hm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(!p){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]);let h=p;if(!/<\/video>/i.test(h))for(;c+1<s.length&&!/<\/video>/i.test(h);)c++,h+=`
`+s[c];o.push(h);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var v,m,b,y;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const C=p[1].length;return`<h${C} class="slide-list-item-title">${rt(p[2].trim())}</h${C}>`}const h=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const C=/\.gif(?:\?|$)/i.test(h[2]),S=(t==null?void 0:t.imageClassName)||(C?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(h[1])}" src="${h[2]}" class="${S}" /></div>`}if(/<video\b/i.test(d)){const C=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-autoplay"])==="true"||/autoplay/i.test(d),S=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(d),x=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||C||/muted/i.test(d),$=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",R=['class="slide-video-player"'];$||R.push("controls"),C&&R.push("autoplay playsinline"),S&&R.push("loop"),x&&R.push("muted"),R.push('preload="metadata"'),w&&R.push(`src="${w}"`);const F=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=F?F[1].trim():"";return!P&&w&&(P=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${C?"true":"false"}" data-muted="${x?"true":"false"}"><video ${R.join(" ")}>${P}</video></div>`}const u=Fa(d,t,i);if(u)return r=!1,u;if(r){r=!1;const C=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(C.length===1)return`<p class="slide-list-item-title">${rt(C[0])}</p>`;const S=C[0],$=C.slice(1).map(T=>rt(T)).join("<br/>");return`<p class="slide-list-item-title">${rt(S)}</p>
<p class="slide-list-item-desc">${$}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function fo(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function ja(e,t){var r,a,c,d,p,h,u,v;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=i==="cover"?null:s.find(fo);if(i==="two-cols"){const m=s.some(q=>q.slot==="right");let b=[],y=[];if(m)b=s.filter(q=>q.slot!=="right"),y=s.filter(q=>q.slot==="right");else{const q=Math.ceil(s.length/2);b=s.slice(0,q),y=s.slice(q)}const C=q=>{const _=q.filter(H=>!!(H.rawMarkdown||H.content||"").trim());if(_.length>0){const H=_[0],k=(H.rawMarkdown||H.content||"").trim();(Ui(H)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(H.rawMarkdown=Bn(H.rawMarkdown||H.content||""),H.content=H.rawMarkdown)}};C(b),C(y);const S=b.map(q=>gi(q,t)).join(`
`),x=y.map(q=>gi(q,t)).join(`
`),$=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",R=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",P=`style="grid-template-columns: ${co((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${$}${T}" ${P}>
        <div class="${w}">${S}</div>
        <div class="${R}">${x}</div>
      </div>
    `}if(i==="clover"||Hn(i)){const m=i==="clover";let b=[];const y=s.filter(M=>M.slot==="header");if(y.length>0)b=y;else if(s.length>0){const M=s.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));M&&(b=[M])}const C=s.filter(M=>!b.includes(M));let S=2;if(m)S=4;else if(i==="three-cols-header")S=3;else if(i==="two-cols-header")S=2;else{let M=0;for(const j of C){const A=(j.slot||"").match(/^col-(\d+)$/i);A&&(M=Math.max(M,parseInt(A[1],10)))}if(M>=2)S=M;else if((d=e.frontmatter)!=null&&d.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const A=j.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);A.length>=2&&(S=A.length)}else{const A=j.split(/\s+/).filter(Boolean);A.length>=2&&(S=A.length)}}else C.length===1&&C[0].children&&C[0].children.length>=2&&(S=Math.min(6,C[0].children.length))}const x=Da(C,S),$=C.some(M=>M.slot&&/^(?:col-\d+|left|right)$/i.test(M.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Hn(i)&&$,w=M=>{const j=M.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(T&&j.length>0){const D=j[0],N=(D.rawMarkdown||D.content||"").trim();(Ui(D)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(D.rawMarkdown=Bn(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const A=T?j.find(fo):null;return j.map(D=>gi(D,{...t,extraClassName:D===A?"slides-col-first-heading-block":""})).join(`
`)},R=b.find(fo),F=b.map(M=>gi(M,{...t,extraClassName:M===R?"slides-page-first-heading-block":""})).join(`
`),P=m?"repeat(2, minmax(0, 1fr))":co((p=e.frontmatter)==null?void 0:p.layoutRatio,S),q=m?`style="grid-template-columns: ${P}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${P};"`,_=[m?"layout-clover-container":"layout-cols-header-container",S===2?"layout-two-cols-header-container":"",S===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),H=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",S===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",S===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),k=x.map((M,j)=>{const A=j+1;return`<div class="${["pdf-col",S===2&&A===1?"pdf-col--left":"",S===2&&A===2?"pdf-col--right":"",`pdf-col--${A}`,`col-${A}`].filter(Boolean).join(" ")}">${w(M)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${F}</div>
        <div class="${H}" ${q}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=s.map(T=>gi(T,t)).join(`
`),y=((h=e.frontmatter)==null?void 0:h.image)||((u=e.frontmatter)==null?void 0:u.background)||"",C=`<div class="pdf-image-col" style="background-image:url('${nt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,S=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,x=m?`${S}
${C}`:`${C}
${S}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${co((v=e.frontmatter)==null?void 0:v.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${x}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>gi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>gi(b,t)).join(`
`)}</div>`:s.map(m=>gi(m,{...t,extraClassName:m===l?"slides-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Fm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const jm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=Aa(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!jm.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=nt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return i[r]||""}),s}function Wm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(s=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function po(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function sl(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${po(e)}</span>`;const i=[];function n(o,l){return i.push(`<span class="${o}">${po(l)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=po(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>i[parseInt(l,10)]||""),s}function Um(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Vm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=Um(c,d+1);p&&o.push(p)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const p=[];for(const h of c){const u=a(h.children,d+1);d>=n?p.push({...h,children:u}):p.push(...u)}return p}return a(l,1)}function Gm(e,t=1,i={}){const n=Vm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slides-toc-list slides-toc-list-level-${d}`,h=c.map(u=>{const v=u.active?" slides-toc-item-active":u.hasActiveChild?" slides-toc-item-parent-active":"",m=u.children&&u.children.length>0?r(u.children,d+1):"";let b=rt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${v}" data-page="${u.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${p}">${h}</ol>`}const a=r(n,1);return`<div class="slides-toc${l}"${o}>${a}</div>`}function gi(e,t){var $,T,w,R,F,P,q,_,H,k;let i="",n="",s="";const o=[];($=e.motion)!=null&&$.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${nt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",p=`${r}${i}${s}${a}${d}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${p}"${n}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${p}"${n}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const M=h.slice(2,-2).trim();return`<div class="${p} katex-display-container"${n}><div class="katex-display font-math"><em>${nt(M)}</em></div></div>`}const u=h.match(/^(#{1,6})\s+(.*)$/);if(u){const M=u[1].length,j=rt(u[2]),D=!!(e.isColFirst||e.type==="i"&&((w=t==null?void 0:t.extraClassName)!=null&&w.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><h${M}${D}>${j}</h${M}></div>`}if(h.startsWith(":::")){const M=h.split(`
`),A=M[0].replace(/^:::\s*/,"").trim()||"info",D=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),N=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${p}"${n}><div class="${N} ${N}--${A}"><div class="${N}-title">${A.toUpperCase()}</div><div class="${N}-body">${rt(D)}</div></div></div>`}if(h.startsWith("<<<")){const A=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((W,K)=>`<span class="code-line shiki-focus"><span class="line-no">${K+1}</span><span class="line-content">${sl(W,"ts")}</span></span>`).join(`
`),D=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",N=((R=e.attrs)==null?void 0:R["custom-slides-max-height"])||e.maxHeight||"",ee=N?` style="max-height:${nt(N)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${D}"${ee}><span class="lang-badge">TS</span><code>${A}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const M=h.split(`
`),j=M[0].slice(3).trim(),A=j.match(/^([^\s{\[]+)/),D=A?A[1]:"",N=j.match(/\[([^\]]+)\]/),ee=N?N[1]:"",W=j.includes("twoslash"),K=e.shikiLines||((F=j.match(/\{([^}]+)\}/))==null?void 0:F[1])||"",re=Fm(K),ae=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[h.slice(3).replace(/```$/,"")],de=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ve=ee?`${de} has-filename`:de,Ee=re!=="all",Se=ae.map((V,g)=>{const G=g+1,I=re==="all"||re.has(G)?"code-line shiki-focus":Ee?"code-line shiki-dimmed":"code-line";let O=(t==null?void 0:t.highlight)===!0?sl(V,D):nt(V);return W&&V.includes("doubled.value = 2")?(O=O.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${O}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${O}</span></span>`}).join(`
`),fe=D?`<span class="lang-badge">${nt(D)}</span>`:"",Z=ee?`<span class="code-filename">${nt(ee)}</span>`:"",pe=((P=e.attrs)==null?void 0:P["custom-slides-max-height"])||e.maxHeight||"",L=pe?` style="max-height:${nt(pe)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${ve}"${L}>${Z}${fe}<code>${Se}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=h.split(`
`).filter(A=>A.trim().startsWith("|")),j=Wm(M,t==null?void 0:t.tableClassName);return`<div class="${p}"${n}>${j}</div>`}if(h.startsWith("> ")){const M=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${p}"${n}><blockquote class="${M}"><p>${rt(h.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),b=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(v&&!m&&!b&&!h.includes(`
`)){const M=((q=e.attributes)==null?void 0:q["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),j=((_=e.attributes)==null?void 0:_["custom-slides-loop"])==="true"||/loop/i.test(h),A=((H=e.attributes)==null?void 0:H["custom-slides-muted"])==="true"||M||/muted/i.test(h),D=((k=e.attributes)==null?void 0:k["custom-slides-controls"])==="false",N=h.match(/\bsrc=["']([^"']+)["']/i),ee=N?N[1]:"",W=['class="slide-video-player"'];D||W.push("controls"),M&&(W.push("autoplay"),W.push("playsinline")),j&&W.push("loop"),A&&W.push("muted"),W.push('preload="auto"'),ee&&W.push(`src="${ee}"`);const K=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=K?K[1].trim():"";return!re&&ee&&(re=`<source src="${ee}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${A?"true":"false"}"${n}><video ${W.join(" ")}>${re}</video></div>`}const y=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const M=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${n}><img alt="${nt(y[1])}" src="${y[2]}" class="${M}" /></div>`}const C=Fa(h,t,e);if(C)return`<div class="${p} pdf-list-item"${n}>${C}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const M=h.match(/minDepth=["']?(\d+)["']?/i),j=h.match(/maxDepth=["']?(\d+)["']?/i),A=h.match(/columns=["']?(\d+)["']?/i),D=(t==null?void 0:t.allSlides)||[];return`<div class="${p}"${n}>${Gm(D,(t==null?void 0:t.currentPageIndex)||1,{minDepth:M?parseInt(M[1],10):1,maxDepth:j?parseInt(j[1],10):1/0,columns:A?parseInt(A[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||b){const M=Hm(h,t,e);if(M)return`<div class="${p}"${n}>${M}</div>`}const x=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><p${x}>${rt(h)}</p></div>`}function Km(e){return`
    ${Ln(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function qm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Ym(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Zm(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function Jm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function Xm(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function Qm(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function eg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function tg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ig(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function ng(){return[qm(),Ym(),Zm(),Jm(),Xm(),Qm(),eg(),tg(),ig()].join("")}function Wa(e,t){const i="即现演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(i)}</title>
  <style>
${Km(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${ng()}
  <\/script>
</body>
</html>`}function Ua(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function sg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function og(e){const t=sg(e==null?void 0:e.pageRatio);return`
    ${Ln(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function rg(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=ja(l),h=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(i)} - 高保真讲义</title>
  <style>
    ${og({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function Va(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=rg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function lg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ho={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var ol;function ag(){return ol||(ol=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var p=typeof ds=="function"&&ds;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(v){var m=n[c][1][v];return l(m||v)},u,u.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(i,n,s){var o=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,p,h,u,v,m,b=[],y=0,C=a.length,S=C,x=o.getTypeOf(a)!=="string";y<a.length;)S=C-y,p=x?(c=a[y++],d=y<C?a[y++]:0,y<C?a[y++]:0):(c=a.charCodeAt(y++),d=y<C?a.charCodeAt(y++):0,y<C?a.charCodeAt(y++):0),h=c>>2,u=(3&c)<<4|d>>4,v=1<S?(15&d)<<2|p>>6:64,m=2<S?63&p:64,b.push(r.charAt(h)+r.charAt(u)+r.charAt(v)+r.charAt(m));return b.join("")},s.decode=function(a){var c,d,p,h,u,v,m=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var C,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&S--,a.charAt(a.length-2)===r.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(C=l.uint8array?new Uint8Array(0|S):new Array(0|S);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(h=r.indexOf(a.charAt(m++)))>>4,d=(15&h)<<4|(u=r.indexOf(a.charAt(m++)))>>2,p=(3&u)<<6|(v=r.indexOf(a.charAt(m++))),C[b++]=c,u!==64&&(C[b++]=d),v!==64&&(C[b++]=p);return C}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,p,h,u,v){this.compressedSize=d,this.uncompressedSize=p,this.crc32=h,this.compression=u,this.compressedContent=v}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,h){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(h)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,p,h){var u=l,v=h+p;c^=-1;for(var m=h;m<v;m++)c=c>>>8^u[255&(c^d[m])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,h){var u=l,v=h+p;c^=-1;for(var m=h;m<v;m++)c=c>>>8^u[255&(c^d.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(p,h){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=h,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(h){p.push({data:h,meta:p.meta})}},s.compressWorker=function(p){return new d("Deflate",p)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(u,v){var m,b="";for(m=0;m<v;m++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,v,m,b,y,C){var S,x,$=u.file,T=u.compression,w=C!==c.utf8encode,R=r.transformTo("string",C($.name)),F=r.transformTo("string",c.utf8encode($.name)),P=$.comment,q=r.transformTo("string",C(P)),_=r.transformTo("string",c.utf8encode(P)),H=F.length!==$.name.length,k=_.length!==P.length,M="",j="",A="",D=$.dir,N=$.date,ee={crc32:0,compressedSize:0,uncompressedSize:0};v&&!m||(ee.crc32=u.crc32,ee.compressedSize=u.compressedSize,ee.uncompressedSize=u.uncompressedSize);var W=0;v&&(W|=8),w||!H&&!k||(W|=2048);var K=0,re=0;D&&(K|=16),y==="UNIX"?(re=798,K|=(function(de,ve){var Ee=de;return de||(Ee=ve?16893:33204),(65535&Ee)<<16})($.unixPermissions,D)):(re=20,K|=(function(de){return 63&(de||0)})($.dosPermissions)),S=N.getUTCHours(),S<<=6,S|=N.getUTCMinutes(),S<<=5,S|=N.getUTCSeconds()/2,x=N.getUTCFullYear()-1980,x<<=4,x|=N.getUTCMonth()+1,x<<=5,x|=N.getUTCDate(),H&&(j=o(1,1)+o(d(R),4)+F,M+="up"+o(j.length,2)+j),k&&(A=o(1,1)+o(d(q),4)+_,M+="uc"+o(A.length,2)+A);var ae="";return ae+=`
\0`,ae+=o(W,2),ae+=T.magic,ae+=o(S,2),ae+=o(x,2),ae+=o(ee.crc32,4),ae+=o(ee.compressedSize,4),ae+=o(ee.uncompressedSize,4),ae+=o(R.length,2),ae+=o(M.length,2),{fileRecord:p.LOCAL_FILE_HEADER+ae+R+M,dirRecord:p.CENTRAL_FILE_HEADER+o(re,2)+ae+o(q.length,2)+"\0\0\0\0"+o(K,4)+o(b,4)+R+M+q}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function h(u,v,m,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=v,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,a),h.prototype.push=function(u){var v=u.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:m?(v+100*(m-b-1))/m:100}}))},h.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var v=this.streamFiles&&!u.file.dir;if(v){var m=l(u,v,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(u){this.accumulate=!1;var v=this.streamFiles&&!u.file.dir,m=l(u,v,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),v)this.push({data:(function(b){return p.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var u=this.bytesWritten,v=0;v<this.dirRecords.length;v++)this.push({data:this.dirRecords[v],meta:{percent:100}});var m=this.bytesWritten-u,b=(function(y,C,S,x,$){var T=r.transformTo("string",$(x));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(C,4)+o(S,4)+o(T.length,2)+T})(this.dirRecords.length,m,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(u){this._sources.push(u);var v=this;return u.on("data",function(m){v.processChunk(m)}),u.on("end",function(){v.closedSource(v.previous.streamInfo),v._sources.length?v.prepareNextSource():v.end()}),u.on("error",function(m){v.error(m)}),this},h.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(u){var v=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var m=0;m<v.length;m++)try{v[m].error(u)}catch{}return!0},h.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,v=0;v<u.length;v++)u[v].lock()},n.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),l=i("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(h,u){p++;var v=(function(C,S){var x=C||S,$=o[x];if(!$)throw new Error(x+" is not a valid compression method !");return $})(u.options.compression,a.compression),m=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,y=u.date;u._compressWorker(v,m).withStreamInfo("file",{name:h,dir:b,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(h){d.error(h)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(h){return new l.Promise(function(u,v){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){v(b)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?v(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(h,u){var v=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(h)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,u.optimizedBinaryString,u.base64).then(function(m){var b=new a(u);return b.load(m),b}).then(function(m){var b=[l.Promise.resolve(m)],y=m.files;if(u.checkCRC32)for(var C=0;C<y.length;C++)b.push(p(y[C]));return l.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,C=0;C<y.length;C++){var S=y[C],x=S.fileNameStr,$=o.resolve(S.fileNameStr);v.file($,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(v.file($).unsafeOriginalName=x)}return b.zipComment.length&&(v.comment=b.zipComment),v})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(p,h){d.push(p)||d._helper.pause(),c&&c(h)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o($,T,w){var R,F=r.getTypeOf(T),P=r.extend(w||{},d);P.date=P.date||new Date,P.compression!==null&&(P.compression=P.compression.toUpperCase()),typeof P.unixPermissions=="string"&&(P.unixPermissions=parseInt(P.unixPermissions,8)),P.unixPermissions&&16384&P.unixPermissions&&(P.dir=!0),P.dosPermissions&&16&P.dosPermissions&&(P.dir=!0),P.dir&&($=y($)),P.createFolders&&(R=b($))&&C.call(this,R,!0);var q=F==="string"&&P.binary===!1&&P.base64===!1;w&&w.binary!==void 0||(P.binary=!q),(T instanceof p&&T.uncompressedSize===0||P.dir||!T||T.length===0)&&(P.base64=!1,P.binary=!0,T="",P.compression="STORE",F="string");var _=null;_=T instanceof p||T instanceof a?T:v.isNode&&v.isStream(T)?new m($,T):r.prepareContent($,T,P.binary,P.optimizedBinaryString,P.base64);var H=new h($,_,P);this.files[$]=H}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),h=i("./zipObject"),u=i("./generate"),v=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function($){$.slice(-1)==="/"&&($=$.substring(0,$.length-1));var T=$.lastIndexOf("/");return 0<T?$.substring(0,T):""},y=function($){return $.slice(-1)!=="/"&&($+="/"),$},C=function($,T){return T=T!==void 0?T:d.createFolders,$=y($),this.files[$]||o.call(this,$,null,{dir:!0,createFolders:T}),this.files[$]};function S($){return Object.prototype.toString.call($)==="[object RegExp]"}var x={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function($){var T,w,R;for(T in this.files)R=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&$(w,R)},filter:function($){var T=[];return this.forEach(function(w,R){$(w,R)&&T.push(R)}),T},file:function($,T,w){if(arguments.length!==1)return $=this.root+$,o.call(this,$,T,w),this;if(S($)){var R=$;return this.filter(function(P,q){return!q.dir&&R.test(P)})}var F=this.files[this.root+$];return F&&!F.dir?F:null},folder:function($){if(!$)return this;if(S($))return this.filter(function(F,P){return P.dir&&$.test(F)});var T=this.root+$,w=C.call(this,T),R=this.clone();return R.root=w.name,R},remove:function($){$=this.root+$;var T=this.files[$];if(T||($.slice(-1)!=="/"&&($+="/"),T=this.files[$]),T&&!T.dir)delete this.files[$];else for(var w=this.filter(function(F,P){return P.name.slice(0,$.length)===$}),R=0;R<w.length;R++)delete this.files[w[R].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function($){var T,w={};try{if((w=r.extend($||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var R=w.comment||this.comment||"";T=u.generateWorker(this,w,R)}catch(F){(T=new a("error")).error(F)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function($,T){return this.generateInternalStream($).accumulate(T)},generateNodeStream:function($,T){return($=$||{}).type||($.type="nodebuffer"),this.generateInternalStream($).toNodejsStream(T)}};n.exports=x},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===a&&this.data[h+1]===c&&this.data[h+2]===d&&this.data[h+3]===p)return h-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),h=this.readData(4);return a===h[0]&&c===h[1]&&d===h[2]&&p===h[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var h=o.getTypeOf(p);return o.checkSupport(h),h!=="string"||l.uint8array?h==="nodebuffer"?new c(p):l.uint8array?new d(o.transformTo("uint8array",p)):new r(o.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),l=i("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),l=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(v,m){return new d.Promise(function(b,y){var C=[],S=v._internalType,x=v._outputType,$=v._mimeType;v.on("data",function(T,w){C.push(T),m&&m(w)}).on("error",function(T){C=[],y(T)}).on("end",function(){try{var T=(function(w,R,F){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",R),F);case"base64":return a.encode(R);default:return o.transformTo(w,R)}})(x,(function(w,R){var F,P=0,q=null,_=0;for(F=0;F<R.length;F++)_+=R[F].length;switch(w){case"string":return R.join("");case"array":return Array.prototype.concat.apply([],R);case"uint8array":for(q=new Uint8Array(_),F=0;F<R.length;F++)q.set(R[F],P),P+=R[F].length;return q;case"nodebuffer":return Buffer.concat(R);default:throw new Error("concat : unsupported type '"+w+"'")}})(S,C),$);b(T)}catch(w){y(w)}C=[]}).resume()})}function u(v,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=v.pipe(new l(y)),v.lock()}catch(C){this._worker=new r("error"),this._worker.error(C)}}u.prototype={accumulate:function(v){return h(this,v)},on:function(v,m){var b=this;return v==="data"?this._worker.on(v,function(y){m.call(b,y.data,y.meta)}):this._worker.on(v,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(v){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},v)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function h(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(v){var m,b,y,C,S,x=v.length,$=0;for(C=0;C<x;C++)(64512&(b=v.charCodeAt(C)))==55296&&C+1<x&&(64512&(y=v.charCodeAt(C+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),C++),$+=b<128?1:b<2048?2:b<65536?3:4;for(m=l.uint8array?new Uint8Array($):new Array($),C=S=0;S<$;C++)(64512&(b=v.charCodeAt(C)))==55296&&C+1<x&&(64512&(y=v.charCodeAt(C+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),C++),b<128?m[S++]=b:(b<2048?m[S++]=192|b>>>6:(b<65536?m[S++]=224|b>>>12:(m[S++]=240|b>>>18,m[S++]=128|b>>>12&63),m[S++]=128|b>>>6&63),m[S++]=128|63&b);return m})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(v){var m,b,y,C,S=v.length,x=new Array(2*S);for(m=b=0;m<S;)if((y=v[m++])<128)x[b++]=y;else if(4<(C=c[y]))x[b++]=65533,m+=C-1;else{for(y&=C===2?31:C===3?15:7;1<C&&m<S;)y=y<<6|63&v[m++],C--;1<C?x[b++]=65533:y<65536?x[b++]=y:(y-=65536,x[b++]=55296|y>>10&1023,x[b++]=56320|1023&y)}return x.length!==b&&(x.subarray?x=x.subarray(0,b):x.length=b),o.applyFromCharCode(x)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(p,a),p.prototype.processChunk=function(u){var v=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=v;(v=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),v.set(m,this.leftOver.length)}else v=this.leftOver.concat(v);this.leftOver=null}var b=(function(C,S){var x;for((S=S||C.length)>C.length&&(S=C.length),x=S-1;0<=x&&(192&C[x])==128;)x--;return x<0||x===0?S:x+c[C[x]]>S?x:S})(v),y=v;b!==v.length&&(l.uint8array?(y=v.subarray(0,b),this.leftOver=v.subarray(b,v.length)):(y=v.slice(0,b),this.leftOver=v.slice(b,v.length))),this.push({data:s.utf8decode(y),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=p,o.inherits(h,a),h.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(m){return m}function d(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(m,b){s.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(m,b,y){var C=[],S=0,x=m.length;if(x<=y)return String.fromCharCode.apply(null,m);for(;S<x;)b==="array"||b==="nodebuffer"?C.push(String.fromCharCode.apply(null,m.slice(S,Math.min(S+y,x)))):C.push(String.fromCharCode.apply(null,m.subarray(S,Math.min(S+y,x)))),S+=y;return C.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var b=65536,y=s.getTypeOf(m),C=!0;if(y==="uint8array"?C=p.applyCanBeUsed.uint8array:y==="nodebuffer"&&(C=p.applyCanBeUsed.nodebuffer),C)for(;1<b;)try{return p.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(m)}function u(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}s.applyFromCharCode=h;var v={};v.string={string:c,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return v.string.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:function(m){return d(m,r.allocBuffer(m.length))}},v.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},v.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return u(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},v.uint8array={string:h,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},v.nodebuffer={string:h,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return v.nodebuffer.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,b){if(b=b||"",!m)return b;s.checkSupport(m);var y=s.getTypeOf(b);return v[y][m](b)},s.resolve=function(m){for(var b=m.split("/"),y=[],C=0;C<b.length;C++){var S=b[C];S==="."||S===""&&C!==0&&C!==b.length-1||(S===".."?y.pop():y.push(S))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var b,y,C="";for(y=0;y<(m||"").length;y++)C+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return C},s.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},s.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},s.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},s.prepareContent=function(m,b,y,C,S){return a.Promise.resolve(b).then(function(x){return o.blob&&(x instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(x))!==-1)&&typeof FileReader<"u"?new a.Promise(function($,T){var w=new FileReader;w.onload=function(R){$(R.target.result)},w.onerror=function(R){T(R.target.error)},w.readAsArrayBuffer(x)}):x}).then(function(x){var $=s.getTypeOf(x);return $?($==="arraybuffer"?x=s.transformTo("uint8array",x):$==="string"&&(S?x=l.decode(x):y&&C!==!0&&(x=(function(T){return d(T,o.uint8array?new Uint8Array(T.length):new Array(T.length))})(x))),x):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(h)+", expected "+l.pretty(p)+")")}},isSignature:function(p,h){var u=this.reader.index;this.reader.setIndex(p);var v=this.reader.readString(4)===h;return this.reader.setIndex(u),v},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",u=l.transformTo(h,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,h,u,v=this.zip64EndOfCentralSize-44;0<v;)p=this.reader.readInt(2),h=this.reader.readInt(4),u=this.reader.readData(h),this.zip64ExtensibleData[p]={id:p,length:h,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,h;for(p=0;p<this.files.length;p++)h=this.files[p],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var h=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var v=h-u;if(0<v)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=v);else if(v<0)throw new Error("Corrupted zip: missing "+Math.abs(v)+" bytes.")},prepareReader:function(p){this.reader=o(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function h(u,v){this.options=u,this.loadOptions=v}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var v,m;if(u.skip(22),this.fileNameLength=u.readInt(2),m=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((v=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,v,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var v=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(v),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var v,m,b,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)v=u.readInt(2),m=u.readInt(2),b=u.readData(m),this.extraFields[v]={id:v,length:m,value:b};u.setIndex(y)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var v=this.findExtraFieldUnicodePath();if(v!==null)this.fileNameStr=v;else{var m=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var v=o(u.value);return v.readInt(1)!==1||a(this.fileName)!==v.readInt(4)?null:c.utf8decode(v.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var v=o(u.value);return v.readInt(1)!==1||a(this.fileComment)!==v.readInt(4)?null:c.utf8decode(v.readData(u.length-5))}return null}},n.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(v,m,b){this.name=v,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(v){var m=null,b="string";try{if(!v)throw new Error("No output type specified.");var y=(b=v.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var C=!this._dataBinary;C&&!y&&(m=m.pipe(new a.Utf8EncodeWorker)),!C&&y&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(S){(m=new d("error")).error(S)}return new l(m,b,"")},async:function(v,m){return this.internalStream(v).accumulate(m)},nodeStream:function(v,m){return this.internalStream(v||"nodebuffer").toNodejsStream(m)},_compressWorker:function(v,m){if(this._data instanceof c&&this._data.compression.magic===v.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,v,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)o.prototype[p[u]]=h;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(v),p=o.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){v(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(v,0)};else{var h=new o.MessageChannel;h.port1.onmessage=v,l=function(){h.port2.postMessage(0)}}var u=[];function v(){var m,b;r=!0;for(var y=u.length;y;){for(b=u,u=[],m=-1;++m<y;)b[m]();y=u.length}r=!1}n.exports=function(m){u.push(m)!==1||r||l()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&m(this,y)}function h(y,C,S){this.promise=y,typeof C=="function"&&(this.onFulfilled=C,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(y,C,S){o(function(){var x;try{x=C(S)}catch($){return r.reject(y,$)}x===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,x)})}function v(y){var C=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof C=="function")return function(){C.apply(y,arguments)}}function m(y,C){var S=!1;function x(w){S||(S=!0,r.reject(y,w))}function $(w){S||(S=!0,r.resolve(y,w))}var T=b(function(){C($,x)});T.status==="error"&&x(T.value)}function b(y,C){var S={};try{S.value=y(C),S.status="success"}catch(x){S.status="error",S.value=x}return S}(n.exports=p).prototype.finally=function(y){if(typeof y!="function")return this;var C=this.constructor;return this.then(function(S){return C.resolve(y()).then(function(){return S})},function(S){return C.resolve(y()).then(function(){throw S})})},p.prototype.catch=function(y){return this.then(null,y)},p.prototype.then=function(y,C){if(typeof y!="function"&&this.state===c||typeof C!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?y:C,this.outcome):this.queue.push(new h(S,y,C)),S},h.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},h.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},h.prototype.callRejected=function(y){r.reject(this.promise,y)},h.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,C){var S=b(v,C);if(S.status==="error")return r.reject(y,S.value);var x=S.value;if(x)m(y,x);else{y.state=c,y.outcome=C;for(var $=-1,T=y.queue.length;++$<T;)y.queue[$].callFulfilled(C)}return y},r.reject=function(y,C){y.state=a,y.outcome=C;for(var S=-1,x=y.queue.length;++S<x;)y.queue[S].callRejected(C);return y},p.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},p.reject=function(y){var C=new this(l);return r.reject(C,y)},p.all=function(y){var C=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,x=!1;if(!S)return this.resolve([]);for(var $=new Array(S),T=0,w=-1,R=new this(l);++w<S;)F(y[w],w);return R;function F(P,q){C.resolve(P).then(function(_){$[q]=_,++T!==S||x||(x=!0,r.resolve(R,$))},function(_){x||(x=!0,r.reject(R,_))})}},p.race=function(y){var C=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,x=!1;if(!S)return this.resolve([]);for(var $=-1,T=new this(l);++$<S;)w=y[$],C.resolve(w).then(function(R){x||(x=!0,r.resolve(T,R))},function(R){x||(x=!0,r.reject(T,R))});var w;return T}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,h=-1,u=0,v=8;function m(y){if(!(this instanceof m))return new m(y);this.options=l.assign({level:h,method:v,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var C=this.options;C.raw&&0<C.windowBits?C.windowBits=-C.windowBits:C.gzip&&0<C.windowBits&&C.windowBits<16&&(C.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=o.deflateInit2(this.strm,C.level,C.method,C.windowBits,C.memLevel,C.strategy);if(S!==p)throw new Error(a[S]);if(C.header&&o.deflateSetHeader(this.strm,C.header),C.dictionary){var x;if(x=typeof C.dictionary=="string"?r.string2buf(C.dictionary):d.call(C.dictionary)==="[object ArrayBuffer]"?new Uint8Array(C.dictionary):C.dictionary,(S=o.deflateSetDictionary(this.strm,x))!==p)throw new Error(a[S]);this._dict_set=!0}}function b(y,C){var S=new m(C);if(S.push(y,!0),S.err)throw S.msg||a[S.err];return S.result}m.prototype.push=function(y,C){var S,x,$=this.strm,T=this.options.chunkSize;if(this.ended)return!1;x=C===~~C?C:C===!0?4:0,typeof y=="string"?$.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?$.input=new Uint8Array(y):$.input=y,$.next_in=0,$.avail_in=$.input.length;do{if($.avail_out===0&&($.output=new l.Buf8(T),$.next_out=0,$.avail_out=T),(S=o.deflate($,x))!==1&&S!==p)return this.onEnd(S),!(this.ended=!0);$.avail_out!==0&&($.avail_in!==0||x!==4&&x!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf($.output,$.next_out))):this.onData(l.shrinkBuf($.output,$.next_out)))}while((0<$.avail_in||$.avail_out===0)&&S!==1);return x===4?(S=o.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===p):x!==2||(this.onEnd(p),!($.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=b,s.deflateRaw=function(y,C){return(C=C||{}).raw=!0,b(y,C)},s.gzip=function(y,C){return(C=C||{}).gzip=!0,b(y,C)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),h=Object.prototype.toString;function u(m){if(!(this instanceof u))return new u(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new p,o.inflateGetHeader(this.strm,this.header)}function v(m,b){var y=new u(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(m,b){var y,C,S,x,$,T,w=this.strm,R=this.options.chunkSize,F=this.options.dictionary,P=!1;if(this.ended)return!1;C=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?w.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?w.input=new Uint8Array(m):w.input=m,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(R),w.next_out=0,w.avail_out=R),(y=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&F&&(T=typeof F=="string"?r.string2buf(F):h.call(F)==="[object ArrayBuffer]"?new Uint8Array(F):F,y=o.inflateSetDictionary(this.strm,T)),y===a.Z_BUF_ERROR&&P===!0&&(y=a.Z_OK,P=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||C!==a.Z_FINISH&&C!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=r.utf8border(w.output,w.next_out),x=w.next_out-S,$=r.buf2string(w.output,S),w.next_out=x,w.avail_out=R-x,x&&l.arraySet(w.output,w.output,S,x,0),this.onData($)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(P=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(C=a.Z_FINISH),C===a.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):C!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(m){this.chunks.push(m)},u.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=u,s.inflate=v,s.inflateRaw=function(m,b){return(b=b||{}).raw=!0,v(m,b)},s.ungzip=v},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,h){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),h);else for(var u=0;u<p;u++)a[h+u]=c[d+u]},flattenChunks:function(a){var c,d,p,h,u,v;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(v=new Uint8Array(p),c=h=0,d=a.length;c<d;c++)u=a[c],v.set(u,h),h+=u.length;return v}},r={arraySet:function(a,c,d,p,h){for(var u=0;u<p;u++)a[h+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,h){if(h<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(p,h));for(var u="",v=0;v<h;v++)u+=String.fromCharCode(p[v]);return u}a[254]=a[254]=1,s.string2buf=function(p){var h,u,v,m,b,y=p.length,C=0;for(m=0;m<y;m++)(64512&(u=p.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=p.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(v-56320),m++),C+=u<128?1:u<2048?2:u<65536?3:4;for(h=new o.Buf8(C),m=b=0;b<C;m++)(64512&(u=p.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=p.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(v-56320),m++),u<128?h[b++]=u:(u<2048?h[b++]=192|u>>>6:(u<65536?h[b++]=224|u>>>12:(h[b++]=240|u>>>18,h[b++]=128|u>>>12&63),h[b++]=128|u>>>6&63),h[b++]=128|63&u);return h},s.buf2binstring=function(p){return d(p,p.length)},s.binstring2buf=function(p){for(var h=new o.Buf8(p.length),u=0,v=h.length;u<v;u++)h[u]=p.charCodeAt(u);return h},s.buf2string=function(p,h){var u,v,m,b,y=h||p.length,C=new Array(2*y);for(u=v=0;u<y;)if((m=p[u++])<128)C[v++]=m;else if(4<(b=a[m]))C[v++]=65533,u+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&u<y;)m=m<<6|63&p[u++],b--;1<b?C[v++]=65533:m<65536?C[v++]=m:(m-=65536,C[v++]=55296|m>>10&1023,C[v++]=56320|1023&m)}return d(C,v)},s.utf8border=function(p,h){var u;for((h=h||p.length)>p.length&&(h=p.length),u=h-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?h:u+a[p[u]]>h?u:h}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,p=c+a;l^=-1;for(var h=c;h<p;h++)l=l>>>8^d[255&(l^r[h])];return-1^l}},{}],46:[function(i,n,s){var o,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,h=4,u=0,v=-2,m=-1,b=4,y=2,C=8,S=9,x=286,$=30,T=19,w=2*x+1,R=15,F=3,P=258,q=P+F+1,_=42,H=113,k=1,M=2,j=3,A=4;function D(g,G){return g.msg=d[G],G}function N(g){return(g<<1)-(4<g?9:0)}function ee(g){for(var G=g.length;0<=--G;)g[G]=0}function W(g){var G=g.state,U=G.pending;U>g.avail_out&&(U=g.avail_out),U!==0&&(l.arraySet(g.output,G.pending_buf,G.pending_out,U,g.next_out),g.next_out+=U,G.pending_out+=U,g.total_out+=U,g.avail_out-=U,G.pending-=U,G.pending===0&&(G.pending_out=0))}function K(g,G){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,G),g.block_start=g.strstart,W(g.strm)}function re(g,G){g.pending_buf[g.pending++]=G}function ae(g,G){g.pending_buf[g.pending++]=G>>>8&255,g.pending_buf[g.pending++]=255&G}function de(g,G){var U,I,E=g.max_chain_length,O=g.strstart,Y=g.prev_length,B=g.nice_match,z=g.strstart>g.w_size-q?g.strstart-(g.w_size-q):0,J=g.window,ne=g.w_mask,oe=g.prev,me=g.strstart+P,ie=J[O+Y-1],se=J[O+Y];g.prev_length>=g.good_match&&(E>>=2),B>g.lookahead&&(B=g.lookahead);do if(J[(U=G)+Y]===se&&J[U+Y-1]===ie&&J[U]===J[O]&&J[++U]===J[O+1]){O+=2,U++;do;while(J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&J[++O]===J[++U]&&O<me);if(I=P-(me-O),O=me-P,Y<I){if(g.match_start=G,B<=(Y=I))break;ie=J[O+Y-1],se=J[O+Y]}}while((G=oe[G&ne])>z&&--E!=0);return Y<=g.lookahead?Y:g.lookahead}function ve(g){var G,U,I,E,O,Y,B,z,J,ne,oe=g.w_size;do{if(E=g.window_size-g.lookahead-g.strstart,g.strstart>=oe+(oe-q)){for(l.arraySet(g.window,g.window,oe,oe,0),g.match_start-=oe,g.strstart-=oe,g.block_start-=oe,G=U=g.hash_size;I=g.head[--G],g.head[G]=oe<=I?I-oe:0,--U;);for(G=U=oe;I=g.prev[--G],g.prev[G]=oe<=I?I-oe:0,--U;);E+=oe}if(g.strm.avail_in===0)break;if(Y=g.strm,B=g.window,z=g.strstart+g.lookahead,J=E,ne=void 0,ne=Y.avail_in,J<ne&&(ne=J),U=ne===0?0:(Y.avail_in-=ne,l.arraySet(B,Y.input,Y.next_in,ne,z),Y.state.wrap===1?Y.adler=a(Y.adler,B,ne,z):Y.state.wrap===2&&(Y.adler=c(Y.adler,B,ne,z)),Y.next_in+=ne,Y.total_in+=ne,ne),g.lookahead+=U,g.lookahead+g.insert>=F)for(O=g.strstart-g.insert,g.ins_h=g.window[O],g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+F-1])&g.hash_mask,g.prev[O&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=O,O++,g.insert--,!(g.lookahead+g.insert<F)););}while(g.lookahead<q&&g.strm.avail_in!==0)}function Ee(g,G){for(var U,I;;){if(g.lookahead<q){if(ve(g),g.lookahead<q&&G===p)return k;if(g.lookahead===0)break}if(U=0,g.lookahead>=F&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),U!==0&&g.strstart-U<=g.w_size-q&&(g.match_length=de(g,U)),g.match_length>=F)if(I=r._tr_tally(g,g.strstart-g.match_start,g.match_length-F),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=F){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else I=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(I&&(K(g,!1),g.strm.avail_out===0))return k}return g.insert=g.strstart<F-1?g.strstart:F-1,G===h?(K(g,!0),g.strm.avail_out===0?j:A):g.last_lit&&(K(g,!1),g.strm.avail_out===0)?k:M}function Se(g,G){for(var U,I,E;;){if(g.lookahead<q){if(ve(g),g.lookahead<q&&G===p)return k;if(g.lookahead===0)break}if(U=0,g.lookahead>=F&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=F-1,U!==0&&g.prev_length<g.max_lazy_match&&g.strstart-U<=g.w_size-q&&(g.match_length=de(g,U),g.match_length<=5&&(g.strategy===1||g.match_length===F&&4096<g.strstart-g.match_start)&&(g.match_length=F-1)),g.prev_length>=F&&g.match_length<=g.prev_length){for(E=g.strstart+g.lookahead-F,I=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-F),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=E&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=F-1,g.strstart++,I&&(K(g,!1),g.strm.avail_out===0))return k}else if(g.match_available){if((I=r._tr_tally(g,0,g.window[g.strstart-1]))&&K(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return k}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(I=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<F-1?g.strstart:F-1,G===h?(K(g,!0),g.strm.avail_out===0?j:A):g.last_lit&&(K(g,!1),g.strm.avail_out===0)?k:M}function fe(g,G,U,I,E){this.good_length=g,this.max_lazy=G,this.nice_length=U,this.max_chain=I,this.func=E}function Z(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=C,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*$+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),ee(this.dyn_ltree),ee(this.dyn_dtree),ee(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(R+1),this.heap=new l.Buf16(2*x+1),ee(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*x+1),ee(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(g){var G;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(G=g.state).pending=0,G.pending_out=0,G.wrap<0&&(G.wrap=-G.wrap),G.status=G.wrap?_:H,g.adler=G.wrap===2?0:1,G.last_flush=p,r._tr_init(G),u):D(g,v)}function L(g){var G=pe(g);return G===u&&(function(U){U.window_size=2*U.w_size,ee(U.head),U.max_lazy_match=o[U.level].max_lazy,U.good_match=o[U.level].good_length,U.nice_match=o[U.level].nice_length,U.max_chain_length=o[U.level].max_chain,U.strstart=0,U.block_start=0,U.lookahead=0,U.insert=0,U.match_length=U.prev_length=F-1,U.match_available=0,U.ins_h=0})(g.state),G}function V(g,G,U,I,E,O){if(!g)return v;var Y=1;if(G===m&&(G=6),I<0?(Y=0,I=-I):15<I&&(Y=2,I-=16),E<1||S<E||U!==C||I<8||15<I||G<0||9<G||O<0||b<O)return D(g,v);I===8&&(I=9);var B=new Z;return(g.state=B).strm=g,B.wrap=Y,B.gzhead=null,B.w_bits=I,B.w_size=1<<B.w_bits,B.w_mask=B.w_size-1,B.hash_bits=E+7,B.hash_size=1<<B.hash_bits,B.hash_mask=B.hash_size-1,B.hash_shift=~~((B.hash_bits+F-1)/F),B.window=new l.Buf8(2*B.w_size),B.head=new l.Buf16(B.hash_size),B.prev=new l.Buf16(B.w_size),B.lit_bufsize=1<<E+6,B.pending_buf_size=4*B.lit_bufsize,B.pending_buf=new l.Buf8(B.pending_buf_size),B.d_buf=1*B.lit_bufsize,B.l_buf=3*B.lit_bufsize,B.level=G,B.strategy=O,B.method=U,L(g)}o=[new fe(0,0,0,0,function(g,G){var U=65535;for(U>g.pending_buf_size-5&&(U=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ve(g),g.lookahead===0&&G===p)return k;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var I=g.block_start+U;if((g.strstart===0||g.strstart>=I)&&(g.lookahead=g.strstart-I,g.strstart=I,K(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-q&&(K(g,!1),g.strm.avail_out===0))return k}return g.insert=0,G===h?(K(g,!0),g.strm.avail_out===0?j:A):(g.strstart>g.block_start&&(K(g,!1),g.strm.avail_out),k)}),new fe(4,4,8,4,Ee),new fe(4,5,16,8,Ee),new fe(4,6,32,32,Ee),new fe(4,4,16,16,Se),new fe(8,16,32,32,Se),new fe(8,16,128,128,Se),new fe(8,32,128,256,Se),new fe(32,128,258,1024,Se),new fe(32,258,258,4096,Se)],s.deflateInit=function(g,G){return V(g,G,C,15,8,0)},s.deflateInit2=V,s.deflateReset=L,s.deflateResetKeep=pe,s.deflateSetHeader=function(g,G){return g&&g.state?g.state.wrap!==2?v:(g.state.gzhead=G,u):v},s.deflate=function(g,G){var U,I,E,O;if(!g||!g.state||5<G||G<0)return g?D(g,v):v;if(I=g.state,!g.output||!g.input&&g.avail_in!==0||I.status===666&&G!==h)return D(g,g.avail_out===0?-5:v);if(I.strm=g,U=I.last_flush,I.last_flush=G,I.status===_)if(I.wrap===2)g.adler=0,re(I,31),re(I,139),re(I,8),I.gzhead?(re(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),re(I,255&I.gzhead.time),re(I,I.gzhead.time>>8&255),re(I,I.gzhead.time>>16&255),re(I,I.gzhead.time>>24&255),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(re(I,255&I.gzhead.extra.length),re(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(g.adler=c(g.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(re(I,0),re(I,0),re(I,0),re(I,0),re(I,0),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,3),I.status=H);else{var Y=C+(I.w_bits-8<<4)<<8;Y|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(Y|=32),Y+=31-Y%31,I.status=H,ae(I,Y),I.strstart!==0&&(ae(I,g.adler>>>16),ae(I,65535&g.adler)),g.adler=1}if(I.status===69)if(I.gzhead.extra){for(E=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending!==I.pending_buf_size));)re(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){E=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,re(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),O===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){E=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,re(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),O===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&W(g),I.pending+2<=I.pending_buf_size&&(re(I,255&g.adler),re(I,g.adler>>8&255),g.adler=0,I.status=H)):I.status=H),I.pending!==0){if(W(g),g.avail_out===0)return I.last_flush=-1,u}else if(g.avail_in===0&&N(G)<=N(U)&&G!==h)return D(g,-5);if(I.status===666&&g.avail_in!==0)return D(g,-5);if(g.avail_in!==0||I.lookahead!==0||G!==p&&I.status!==666){var B=I.strategy===2?(function(z,J){for(var ne;;){if(z.lookahead===0&&(ve(z),z.lookahead===0)){if(J===p)return k;break}if(z.match_length=0,ne=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++,ne&&(K(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(K(z,!0),z.strm.avail_out===0?j:A):z.last_lit&&(K(z,!1),z.strm.avail_out===0)?k:M})(I,G):I.strategy===3?(function(z,J){for(var ne,oe,me,ie,se=z.window;;){if(z.lookahead<=P){if(ve(z),z.lookahead<=P&&J===p)return k;if(z.lookahead===0)break}if(z.match_length=0,z.lookahead>=F&&0<z.strstart&&(oe=se[me=z.strstart-1])===se[++me]&&oe===se[++me]&&oe===se[++me]){ie=z.strstart+P;do;while(oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&oe===se[++me]&&me<ie);z.match_length=P-(ie-me),z.match_length>z.lookahead&&(z.match_length=z.lookahead)}if(z.match_length>=F?(ne=r._tr_tally(z,1,z.match_length-F),z.lookahead-=z.match_length,z.strstart+=z.match_length,z.match_length=0):(ne=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++),ne&&(K(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(K(z,!0),z.strm.avail_out===0?j:A):z.last_lit&&(K(z,!1),z.strm.avail_out===0)?k:M})(I,G):o[I.level].func(I,G);if(B!==j&&B!==A||(I.status=666),B===k||B===j)return g.avail_out===0&&(I.last_flush=-1),u;if(B===M&&(G===1?r._tr_align(I):G!==5&&(r._tr_stored_block(I,0,0,!1),G===3&&(ee(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),W(g),g.avail_out===0))return I.last_flush=-1,u}return G!==h?u:I.wrap<=0?1:(I.wrap===2?(re(I,255&g.adler),re(I,g.adler>>8&255),re(I,g.adler>>16&255),re(I,g.adler>>24&255),re(I,255&g.total_in),re(I,g.total_in>>8&255),re(I,g.total_in>>16&255),re(I,g.total_in>>24&255)):(ae(I,g.adler>>>16),ae(I,65535&g.adler)),W(g),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?u:1)},s.deflateEnd=function(g){var G;return g&&g.state?(G=g.state.status)!==_&&G!==69&&G!==73&&G!==91&&G!==103&&G!==H&&G!==666?D(g,v):(g.state=null,G===H?D(g,-3):u):v},s.deflateSetDictionary=function(g,G){var U,I,E,O,Y,B,z,J,ne=G.length;if(!g||!g.state||(O=(U=g.state).wrap)===2||O===1&&U.status!==_||U.lookahead)return v;for(O===1&&(g.adler=a(g.adler,G,ne,0)),U.wrap=0,ne>=U.w_size&&(O===0&&(ee(U.head),U.strstart=0,U.block_start=0,U.insert=0),J=new l.Buf8(U.w_size),l.arraySet(J,G,ne-U.w_size,U.w_size,0),G=J,ne=U.w_size),Y=g.avail_in,B=g.next_in,z=g.input,g.avail_in=ne,g.next_in=0,g.input=G,ve(U);U.lookahead>=F;){for(I=U.strstart,E=U.lookahead-(F-1);U.ins_h=(U.ins_h<<U.hash_shift^U.window[I+F-1])&U.hash_mask,U.prev[I&U.w_mask]=U.head[U.ins_h],U.head[U.ins_h]=I,I++,--E;);U.strstart=I,U.lookahead=F-1,ve(U)}return U.strstart+=U.lookahead,U.block_start=U.strstart,U.insert=U.lookahead,U.lookahead=0,U.match_length=U.prev_length=F-1,U.match_available=0,g.next_in=B,g.input=z,g.avail_in=Y,U.wrap=O,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,l){var r,a,c,d,p,h,u,v,m,b,y,C,S,x,$,T,w,R,F,P,q,_,H,k,M;r=o.state,a=o.next_in,k=o.input,c=a+(o.avail_in-5),d=o.next_out,M=o.output,p=d-(l-o.avail_out),h=d+(o.avail_out-257),u=r.dmax,v=r.wsize,m=r.whave,b=r.wnext,y=r.window,C=r.hold,S=r.bits,x=r.lencode,$=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{S<15&&(C+=k[a++]<<S,S+=8,C+=k[a++]<<S,S+=8),R=x[C&T];t:for(;;){if(C>>>=F=R>>>24,S-=F,(F=R>>>16&255)===0)M[d++]=65535&R;else{if(!(16&F)){if((64&F)==0){R=x[(65535&R)+(C&(1<<F)-1)];continue t}if(32&F){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}P=65535&R,(F&=15)&&(S<F&&(C+=k[a++]<<S,S+=8),P+=C&(1<<F)-1,C>>>=F,S-=F),S<15&&(C+=k[a++]<<S,S+=8,C+=k[a++]<<S,S+=8),R=$[C&w];i:for(;;){if(C>>>=F=R>>>24,S-=F,!(16&(F=R>>>16&255))){if((64&F)==0){R=$[(65535&R)+(C&(1<<F)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(q=65535&R,S<(F&=15)&&(C+=k[a++]<<S,(S+=8)<F&&(C+=k[a++]<<S,S+=8)),u<(q+=C&(1<<F)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(C>>>=F,S-=F,(F=d-p)<q){if(m<(F=q-F)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(H=y,(_=0)===b){if(_+=v-F,F<P){for(P-=F;M[d++]=y[_++],--F;);_=d-q,H=M}}else if(b<F){if(_+=v+b-F,(F-=b)<P){for(P-=F;M[d++]=y[_++],--F;);if(_=0,b<P){for(P-=F=b;M[d++]=y[_++],--F;);_=d-q,H=M}}}else if(_+=b-F,F<P){for(P-=F;M[d++]=y[_++],--F;);_=d-q,H=M}for(;2<P;)M[d++]=H[_++],M[d++]=H[_++],M[d++]=H[_++],P-=3;P&&(M[d++]=H[_++],1<P&&(M[d++]=H[_++]))}else{for(_=d-q;M[d++]=M[_++],M[d++]=M[_++],M[d++]=M[_++],2<(P-=3););P&&(M[d++]=M[_++],1<P&&(M[d++]=M[_++]))}break}}break}}while(a<c&&d<h);a-=P=S>>3,C&=(1<<(S-=P<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<h?h-d+257:257-(d-h),r.hold=C,r.bits=S}},{}],49:[function(i,n,s){var o=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,p=2,h=0,u=-2,v=1,m=852,b=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function C(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(_){var H;return _&&_.state?(H=_.state,_.total_in=_.total_out=H.total=0,_.msg="",H.wrap&&(_.adler=1&H.wrap),H.mode=v,H.last=0,H.havedict=0,H.dmax=32768,H.head=null,H.hold=0,H.bits=0,H.lencode=H.lendyn=new o.Buf32(m),H.distcode=H.distdyn=new o.Buf32(b),H.sane=1,H.back=-1,h):u}function x(_){var H;return _&&_.state?((H=_.state).wsize=0,H.whave=0,H.wnext=0,S(_)):u}function $(_,H){var k,M;return _&&_.state?(M=_.state,H<0?(k=0,H=-H):(k=1+(H>>4),H<48&&(H&=15)),H&&(H<8||15<H)?u:(M.window!==null&&M.wbits!==H&&(M.window=null),M.wrap=k,M.wbits=H,x(_))):u}function T(_,H){var k,M;return _?(M=new C,(_.state=M).window=null,(k=$(_,H))!==h&&(_.state=null),k):u}var w,R,F=!0;function P(_){if(F){var H;for(w=new o.Buf32(512),R=new o.Buf32(32),H=0;H<144;)_.lens[H++]=8;for(;H<256;)_.lens[H++]=9;for(;H<280;)_.lens[H++]=7;for(;H<288;)_.lens[H++]=8;for(c(d,_.lens,0,288,w,0,_.work,{bits:9}),H=0;H<32;)_.lens[H++]=5;c(p,_.lens,0,32,R,0,_.work,{bits:5}),F=!1}_.lencode=w,_.lenbits=9,_.distcode=R,_.distbits=5}function q(_,H,k,M){var j,A=_.state;return A.window===null&&(A.wsize=1<<A.wbits,A.wnext=0,A.whave=0,A.window=new o.Buf8(A.wsize)),M>=A.wsize?(o.arraySet(A.window,H,k-A.wsize,A.wsize,0),A.wnext=0,A.whave=A.wsize):(M<(j=A.wsize-A.wnext)&&(j=M),o.arraySet(A.window,H,k-M,j,A.wnext),(M-=j)?(o.arraySet(A.window,H,k-M,M,0),A.wnext=M,A.whave=A.wsize):(A.wnext+=j,A.wnext===A.wsize&&(A.wnext=0),A.whave<A.wsize&&(A.whave+=j))),0}s.inflateReset=x,s.inflateReset2=$,s.inflateResetKeep=S,s.inflateInit=function(_){return T(_,15)},s.inflateInit2=T,s.inflate=function(_,H){var k,M,j,A,D,N,ee,W,K,re,ae,de,ve,Ee,Se,fe,Z,pe,L,V,g,G,U,I,E=0,O=new o.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return u;(k=_.state).mode===12&&(k.mode=13),D=_.next_out,j=_.output,ee=_.avail_out,A=_.next_in,M=_.input,N=_.avail_in,W=k.hold,K=k.bits,re=N,ae=ee,G=h;e:for(;;)switch(k.mode){case v:if(k.wrap===0){k.mode=13;break}for(;K<16;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(2&k.wrap&&W===35615){O[k.check=0]=255&W,O[1]=W>>>8&255,k.check=r(k.check,O,2,0),K=W=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&W)<<8)+(W>>8))%31){_.msg="incorrect header check",k.mode=30;break}if((15&W)!=8){_.msg="unknown compression method",k.mode=30;break}if(K-=4,g=8+(15&(W>>>=4)),k.wbits===0)k.wbits=g;else if(g>k.wbits){_.msg="invalid window size",k.mode=30;break}k.dmax=1<<g,_.adler=k.check=1,k.mode=512&W?10:12,K=W=0;break;case 2:for(;K<16;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(k.flags=W,(255&k.flags)!=8){_.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){_.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=W>>8&1),512&k.flags&&(O[0]=255&W,O[1]=W>>>8&255,k.check=r(k.check,O,2,0)),K=W=0,k.mode=3;case 3:for(;K<32;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.head&&(k.head.time=W),512&k.flags&&(O[0]=255&W,O[1]=W>>>8&255,O[2]=W>>>16&255,O[3]=W>>>24&255,k.check=r(k.check,O,4,0)),K=W=0,k.mode=4;case 4:for(;K<16;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.head&&(k.head.xflags=255&W,k.head.os=W>>8),512&k.flags&&(O[0]=255&W,O[1]=W>>>8&255,k.check=r(k.check,O,2,0)),K=W=0,k.mode=5;case 5:if(1024&k.flags){for(;K<16;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.length=W,k.head&&(k.head.extra_len=W),512&k.flags&&(O[0]=255&W,O[1]=W>>>8&255,k.check=r(k.check,O,2,0)),K=W=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(N<(de=k.length)&&(de=N),de&&(k.head&&(g=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,M,A,de,g)),512&k.flags&&(k.check=r(k.check,M,de,A)),N-=de,A+=de,k.length-=de),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(N===0)break e;for(de=0;g=M[A+de++],k.head&&g&&k.length<65536&&(k.head.name+=String.fromCharCode(g)),g&&de<N;);if(512&k.flags&&(k.check=r(k.check,M,de,A)),N-=de,A+=de,g)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(N===0)break e;for(de=0;g=M[A+de++],k.head&&g&&k.length<65536&&(k.head.comment+=String.fromCharCode(g)),g&&de<N;);if(512&k.flags&&(k.check=r(k.check,M,de,A)),N-=de,A+=de,g)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;K<16;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(W!==(65535&k.check)){_.msg="header crc mismatch",k.mode=30;break}K=W=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),_.adler=k.check=0,k.mode=12;break;case 10:for(;K<32;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}_.adler=k.check=y(W),K=W=0,k.mode=11;case 11:if(k.havedict===0)return _.next_out=D,_.avail_out=ee,_.next_in=A,_.avail_in=N,k.hold=W,k.bits=K,2;_.adler=k.check=1,k.mode=12;case 12:if(H===5||H===6)break e;case 13:if(k.last){W>>>=7&K,K-=7&K,k.mode=27;break}for(;K<3;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}switch(k.last=1&W,K-=1,3&(W>>>=1)){case 0:k.mode=14;break;case 1:if(P(k),k.mode=20,H!==6)break;W>>>=2,K-=2;break e;case 2:k.mode=17;break;case 3:_.msg="invalid block type",k.mode=30}W>>>=2,K-=2;break;case 14:for(W>>>=7&K,K-=7&K;K<32;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if((65535&W)!=(W>>>16^65535)){_.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&W,K=W=0,k.mode=15,H===6)break e;case 15:k.mode=16;case 16:if(de=k.length){if(N<de&&(de=N),ee<de&&(de=ee),de===0)break e;o.arraySet(j,M,A,de,D),N-=de,A+=de,ee-=de,D+=de,k.length-=de;break}k.mode=12;break;case 17:for(;K<14;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(k.nlen=257+(31&W),W>>>=5,K-=5,k.ndist=1+(31&W),W>>>=5,K-=5,k.ncode=4+(15&W),W>>>=4,K-=4,286<k.nlen||30<k.ndist){_.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;K<3;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.lens[Y[k.have++]]=7&W,W>>>=3,K-=3}for(;k.have<19;)k.lens[Y[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,U={bits:k.lenbits},G=c(0,k.lens,0,19,k.lencode,0,k.work,U),k.lenbits=U.bits,G){_.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;fe=(E=k.lencode[W&(1<<k.lenbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=K);){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(Z<16)W>>>=Se,K-=Se,k.lens[k.have++]=Z;else{if(Z===16){for(I=Se+2;K<I;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(W>>>=Se,K-=Se,k.have===0){_.msg="invalid bit length repeat",k.mode=30;break}g=k.lens[k.have-1],de=3+(3&W),W>>>=2,K-=2}else if(Z===17){for(I=Se+3;K<I;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}K-=Se,g=0,de=3+(7&(W>>>=Se)),W>>>=3,K-=3}else{for(I=Se+7;K<I;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}K-=Se,g=0,de=11+(127&(W>>>=Se)),W>>>=7,K-=7}if(k.have+de>k.nlen+k.ndist){_.msg="invalid bit length repeat",k.mode=30;break}for(;de--;)k.lens[k.have++]=g}}if(k.mode===30)break;if(k.lens[256]===0){_.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,U={bits:k.lenbits},G=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,U),k.lenbits=U.bits,G){_.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,U={bits:k.distbits},G=c(p,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,U),k.distbits=U.bits,G){_.msg="invalid distances set",k.mode=30;break}if(k.mode=20,H===6)break e;case 20:k.mode=21;case 21:if(6<=N&&258<=ee){_.next_out=D,_.avail_out=ee,_.next_in=A,_.avail_in=N,k.hold=W,k.bits=K,a(_,ae),D=_.next_out,j=_.output,ee=_.avail_out,A=_.next_in,M=_.input,N=_.avail_in,W=k.hold,K=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;fe=(E=k.lencode[W&(1<<k.lenbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=K);){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(fe&&(240&fe)==0){for(pe=Se,L=fe,V=Z;fe=(E=k.lencode[V+((W&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&E,!(pe+(Se=E>>>24)<=K);){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}W>>>=pe,K-=pe,k.back+=pe}if(W>>>=Se,K-=Se,k.back+=Se,k.length=Z,fe===0){k.mode=26;break}if(32&fe){k.back=-1,k.mode=12;break}if(64&fe){_.msg="invalid literal/length code",k.mode=30;break}k.extra=15&fe,k.mode=22;case 22:if(k.extra){for(I=k.extra;K<I;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.length+=W&(1<<k.extra)-1,W>>>=k.extra,K-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;fe=(E=k.distcode[W&(1<<k.distbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=K);){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if((240&fe)==0){for(pe=Se,L=fe,V=Z;fe=(E=k.distcode[V+((W&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&E,!(pe+(Se=E>>>24)<=K);){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}W>>>=pe,K-=pe,k.back+=pe}if(W>>>=Se,K-=Se,k.back+=Se,64&fe){_.msg="invalid distance code",k.mode=30;break}k.offset=Z,k.extra=15&fe,k.mode=24;case 24:if(k.extra){for(I=k.extra;K<I;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}k.offset+=W&(1<<k.extra)-1,W>>>=k.extra,K-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){_.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(ee===0)break e;if(de=ae-ee,k.offset>de){if((de=k.offset-de)>k.whave&&k.sane){_.msg="invalid distance too far back",k.mode=30;break}ve=de>k.wnext?(de-=k.wnext,k.wsize-de):k.wnext-de,de>k.length&&(de=k.length),Ee=k.window}else Ee=j,ve=D-k.offset,de=k.length;for(ee<de&&(de=ee),ee-=de,k.length-=de;j[D++]=Ee[ve++],--de;);k.length===0&&(k.mode=21);break;case 26:if(ee===0)break e;j[D++]=k.length,ee--,k.mode=21;break;case 27:if(k.wrap){for(;K<32;){if(N===0)break e;N--,W|=M[A++]<<K,K+=8}if(ae-=ee,_.total_out+=ae,k.total+=ae,ae&&(_.adler=k.check=k.flags?r(k.check,j,ae,D-ae):l(k.check,j,ae,D-ae)),ae=ee,(k.flags?W:y(W))!==k.check){_.msg="incorrect data check",k.mode=30;break}K=W=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;K<32;){if(N===0)break e;N--,W+=M[A++]<<K,K+=8}if(W!==(4294967295&k.total)){_.msg="incorrect length check",k.mode=30;break}K=W=0}k.mode=29;case 29:G=1;break e;case 30:G=-3;break e;case 31:return-4;case 32:default:return u}return _.next_out=D,_.avail_out=ee,_.next_in=A,_.avail_in=N,k.hold=W,k.bits=K,(k.wsize||ae!==_.avail_out&&k.mode<30&&(k.mode<27||H!==4))&&q(_,_.output,_.next_out,ae-_.avail_out)?(k.mode=31,-4):(re-=_.avail_in,ae-=_.avail_out,_.total_in+=re,_.total_out+=ae,k.total+=ae,k.wrap&&ae&&(_.adler=k.check=k.flags?r(k.check,j,ae,_.next_out-ae):l(k.check,j,ae,_.next_out-ae)),_.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(re==0&&ae===0||H===4)&&G===h&&(G=-5),G)},s.inflateEnd=function(_){if(!_||!_.state)return u;var H=_.state;return H.window&&(H.window=null),_.state=null,h},s.inflateGetHeader=function(_,H){var k;return _&&_.state?(2&(k=_.state).wrap)==0?u:((k.head=H).done=!1,h):u},s.inflateSetDictionary=function(_,H){var k,M=H.length;return _&&_.state?(k=_.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,H,M,0)!==k.check?-3:q(_,H,M,M)?(k.mode=31,-4):(k.havedict=1,h):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,h,u,v,m,b,y){var C,S,x,$,T,w,R,F,P,q=y.bits,_=0,H=0,k=0,M=0,j=0,A=0,D=0,N=0,ee=0,W=0,K=null,re=0,ae=new o.Buf16(16),de=new o.Buf16(16),ve=null,Ee=0;for(_=0;_<=15;_++)ae[_]=0;for(H=0;H<u;H++)ae[p[h+H]]++;for(j=q,M=15;1<=M&&ae[M]===0;M--);if(M<j&&(j=M),M===0)return v[m++]=20971520,v[m++]=20971520,y.bits=1,0;for(k=1;k<M&&ae[k]===0;k++);for(j<k&&(j=k),_=N=1;_<=15;_++)if(N<<=1,(N-=ae[_])<0)return-1;if(0<N&&(d===0||M!==1))return-1;for(de[1]=0,_=1;_<15;_++)de[_+1]=de[_]+ae[_];for(H=0;H<u;H++)p[h+H]!==0&&(b[de[p[h+H]]++]=H);if(w=d===0?(K=ve=b,19):d===1?(K=l,re-=257,ve=r,Ee-=257,256):(K=a,ve=c,-1),_=k,T=m,D=H=W=0,x=-1,$=(ee=1<<(A=j))-1,d===1&&852<ee||d===2&&592<ee)return 1;for(;;){for(R=_-D,P=b[H]<w?(F=0,b[H]):b[H]>w?(F=ve[Ee+b[H]],K[re+b[H]]):(F=96,0),C=1<<_-D,k=S=1<<A;v[T+(W>>D)+(S-=C)]=R<<24|F<<16|P|0,S!==0;);for(C=1<<_-1;W&C;)C>>=1;if(C!==0?(W&=C-1,W+=C):W=0,H++,--ae[_]==0){if(_===M)break;_=p[h+b[H]]}if(j<_&&(W&$)!==x){for(D===0&&(D=j),T+=k,N=1<<(A=_-D);A+D<M&&!((N-=ae[A+D])<=0);)A++,N<<=1;if(ee+=1<<A,d===1&&852<ee||d===2&&592<ee)return 1;v[x=W&$]=j<<24|A<<16|T-m|0}}return W!==0&&(v[T+W]=_-D<<24|64<<16|0),y.bits=j,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),l=0,r=1;function a(E){for(var O=E.length;0<=--O;)E[O]=0}var c=0,d=29,p=256,h=p+1+d,u=30,v=19,m=2*h+1,b=15,y=16,C=7,S=256,x=16,$=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],R=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],F=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],P=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],q=new Array(2*(h+2));a(q);var _=new Array(2*u);a(_);var H=new Array(512);a(H);var k=new Array(256);a(k);var M=new Array(d);a(M);var j,A,D,N=new Array(u);function ee(E,O,Y,B,z){this.static_tree=E,this.extra_bits=O,this.extra_base=Y,this.elems=B,this.max_length=z,this.has_stree=E&&E.length}function W(E,O){this.dyn_tree=E,this.max_code=0,this.stat_desc=O}function K(E){return E<256?H[E]:H[256+(E>>>7)]}function re(E,O){E.pending_buf[E.pending++]=255&O,E.pending_buf[E.pending++]=O>>>8&255}function ae(E,O,Y){E.bi_valid>y-Y?(E.bi_buf|=O<<E.bi_valid&65535,re(E,E.bi_buf),E.bi_buf=O>>y-E.bi_valid,E.bi_valid+=Y-y):(E.bi_buf|=O<<E.bi_valid&65535,E.bi_valid+=Y)}function de(E,O,Y){ae(E,Y[2*O],Y[2*O+1])}function ve(E,O){for(var Y=0;Y|=1&E,E>>>=1,Y<<=1,0<--O;);return Y>>>1}function Ee(E,O,Y){var B,z,J=new Array(b+1),ne=0;for(B=1;B<=b;B++)J[B]=ne=ne+Y[B-1]<<1;for(z=0;z<=O;z++){var oe=E[2*z+1];oe!==0&&(E[2*z]=ve(J[oe]++,oe))}}function Se(E){var O;for(O=0;O<h;O++)E.dyn_ltree[2*O]=0;for(O=0;O<u;O++)E.dyn_dtree[2*O]=0;for(O=0;O<v;O++)E.bl_tree[2*O]=0;E.dyn_ltree[2*S]=1,E.opt_len=E.static_len=0,E.last_lit=E.matches=0}function fe(E){8<E.bi_valid?re(E,E.bi_buf):0<E.bi_valid&&(E.pending_buf[E.pending++]=E.bi_buf),E.bi_buf=0,E.bi_valid=0}function Z(E,O,Y,B){var z=2*O,J=2*Y;return E[z]<E[J]||E[z]===E[J]&&B[O]<=B[Y]}function pe(E,O,Y){for(var B=E.heap[Y],z=Y<<1;z<=E.heap_len&&(z<E.heap_len&&Z(O,E.heap[z+1],E.heap[z],E.depth)&&z++,!Z(O,B,E.heap[z],E.depth));)E.heap[Y]=E.heap[z],Y=z,z<<=1;E.heap[Y]=B}function L(E,O,Y){var B,z,J,ne,oe=0;if(E.last_lit!==0)for(;B=E.pending_buf[E.d_buf+2*oe]<<8|E.pending_buf[E.d_buf+2*oe+1],z=E.pending_buf[E.l_buf+oe],oe++,B===0?de(E,z,O):(de(E,(J=k[z])+p+1,O),(ne=w[J])!==0&&ae(E,z-=M[J],ne),de(E,J=K(--B),Y),(ne=R[J])!==0&&ae(E,B-=N[J],ne)),oe<E.last_lit;);de(E,S,O)}function V(E,O){var Y,B,z,J=O.dyn_tree,ne=O.stat_desc.static_tree,oe=O.stat_desc.has_stree,me=O.stat_desc.elems,ie=-1;for(E.heap_len=0,E.heap_max=m,Y=0;Y<me;Y++)J[2*Y]!==0?(E.heap[++E.heap_len]=ie=Y,E.depth[Y]=0):J[2*Y+1]=0;for(;E.heap_len<2;)J[2*(z=E.heap[++E.heap_len]=ie<2?++ie:0)]=1,E.depth[z]=0,E.opt_len--,oe&&(E.static_len-=ne[2*z+1]);for(O.max_code=ie,Y=E.heap_len>>1;1<=Y;Y--)pe(E,J,Y);for(z=me;Y=E.heap[1],E.heap[1]=E.heap[E.heap_len--],pe(E,J,1),B=E.heap[1],E.heap[--E.heap_max]=Y,E.heap[--E.heap_max]=B,J[2*z]=J[2*Y]+J[2*B],E.depth[z]=(E.depth[Y]>=E.depth[B]?E.depth[Y]:E.depth[B])+1,J[2*Y+1]=J[2*B+1]=z,E.heap[1]=z++,pe(E,J,1),2<=E.heap_len;);E.heap[--E.heap_max]=E.heap[1],(function(se,_e){var Be,Ne,Re,De,Qt,ot,Xe=_e.dyn_tree,Ht=_e.max_code,Vi=_e.stat_desc.static_tree,Ys=_e.stat_desc.has_stree,Zs=_e.stat_desc.extra_bits,es=_e.stat_desc.extra_base,_i=_e.stat_desc.max_length,Gi=0;for(De=0;De<=b;De++)se.bl_count[De]=0;for(Xe[2*se.heap[se.heap_max]+1]=0,Be=se.heap_max+1;Be<m;Be++)_i<(De=Xe[2*Xe[2*(Ne=se.heap[Be])+1]+1]+1)&&(De=_i,Gi++),Xe[2*Ne+1]=De,Ht<Ne||(se.bl_count[De]++,Qt=0,es<=Ne&&(Qt=Zs[Ne-es]),ot=Xe[2*Ne],se.opt_len+=ot*(De+Qt),Ys&&(se.static_len+=ot*(Vi[2*Ne+1]+Qt)));if(Gi!==0){do{for(De=_i-1;se.bl_count[De]===0;)De--;se.bl_count[De]--,se.bl_count[De+1]+=2,se.bl_count[_i]--,Gi-=2}while(0<Gi);for(De=_i;De!==0;De--)for(Ne=se.bl_count[De];Ne!==0;)Ht<(Re=se.heap[--Be])||(Xe[2*Re+1]!==De&&(se.opt_len+=(De-Xe[2*Re+1])*Xe[2*Re],Xe[2*Re+1]=De),Ne--)}})(E,O),Ee(J,ie,E.bl_count)}function g(E,O,Y){var B,z,J=-1,ne=O[1],oe=0,me=7,ie=4;for(ne===0&&(me=138,ie=3),O[2*(Y+1)+1]=65535,B=0;B<=Y;B++)z=ne,ne=O[2*(B+1)+1],++oe<me&&z===ne||(oe<ie?E.bl_tree[2*z]+=oe:z!==0?(z!==J&&E.bl_tree[2*z]++,E.bl_tree[2*x]++):oe<=10?E.bl_tree[2*$]++:E.bl_tree[2*T]++,J=z,ie=(oe=0)===ne?(me=138,3):z===ne?(me=6,3):(me=7,4))}function G(E,O,Y){var B,z,J=-1,ne=O[1],oe=0,me=7,ie=4;for(ne===0&&(me=138,ie=3),B=0;B<=Y;B++)if(z=ne,ne=O[2*(B+1)+1],!(++oe<me&&z===ne)){if(oe<ie)for(;de(E,z,E.bl_tree),--oe!=0;);else z!==0?(z!==J&&(de(E,z,E.bl_tree),oe--),de(E,x,E.bl_tree),ae(E,oe-3,2)):oe<=10?(de(E,$,E.bl_tree),ae(E,oe-3,3)):(de(E,T,E.bl_tree),ae(E,oe-11,7));J=z,ie=(oe=0)===ne?(me=138,3):z===ne?(me=6,3):(me=7,4)}}a(N);var U=!1;function I(E,O,Y,B){ae(E,(c<<1)+(B?1:0),3),(function(z,J,ne,oe){fe(z),re(z,ne),re(z,~ne),o.arraySet(z.pending_buf,z.window,J,ne,z.pending),z.pending+=ne})(E,O,Y)}s._tr_init=function(E){U||((function(){var O,Y,B,z,J,ne=new Array(b+1);for(z=B=0;z<d-1;z++)for(M[z]=B,O=0;O<1<<w[z];O++)k[B++]=z;for(k[B-1]=z,z=J=0;z<16;z++)for(N[z]=J,O=0;O<1<<R[z];O++)H[J++]=z;for(J>>=7;z<u;z++)for(N[z]=J<<7,O=0;O<1<<R[z]-7;O++)H[256+J++]=z;for(Y=0;Y<=b;Y++)ne[Y]=0;for(O=0;O<=143;)q[2*O+1]=8,O++,ne[8]++;for(;O<=255;)q[2*O+1]=9,O++,ne[9]++;for(;O<=279;)q[2*O+1]=7,O++,ne[7]++;for(;O<=287;)q[2*O+1]=8,O++,ne[8]++;for(Ee(q,h+1,ne),O=0;O<u;O++)_[2*O+1]=5,_[2*O]=ve(O,5);j=new ee(q,w,p+1,h,b),A=new ee(_,R,0,u,b),D=new ee(new Array(0),F,0,v,C)})(),U=!0),E.l_desc=new W(E.dyn_ltree,j),E.d_desc=new W(E.dyn_dtree,A),E.bl_desc=new W(E.bl_tree,D),E.bi_buf=0,E.bi_valid=0,Se(E)},s._tr_stored_block=I,s._tr_flush_block=function(E,O,Y,B){var z,J,ne=0;0<E.level?(E.strm.data_type===2&&(E.strm.data_type=(function(oe){var me,ie=4093624447;for(me=0;me<=31;me++,ie>>>=1)if(1&ie&&oe.dyn_ltree[2*me]!==0)return l;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(me=32;me<p;me++)if(oe.dyn_ltree[2*me]!==0)return r;return l})(E)),V(E,E.l_desc),V(E,E.d_desc),ne=(function(oe){var me;for(g(oe,oe.dyn_ltree,oe.l_desc.max_code),g(oe,oe.dyn_dtree,oe.d_desc.max_code),V(oe,oe.bl_desc),me=v-1;3<=me&&oe.bl_tree[2*P[me]+1]===0;me--);return oe.opt_len+=3*(me+1)+5+5+4,me})(E),z=E.opt_len+3+7>>>3,(J=E.static_len+3+7>>>3)<=z&&(z=J)):z=J=Y+5,Y+4<=z&&O!==-1?I(E,O,Y,B):E.strategy===4||J===z?(ae(E,2+(B?1:0),3),L(E,q,_)):(ae(E,4+(B?1:0),3),(function(oe,me,ie,se){var _e;for(ae(oe,me-257,5),ae(oe,ie-1,5),ae(oe,se-4,4),_e=0;_e<se;_e++)ae(oe,oe.bl_tree[2*P[_e]+1],3);G(oe,oe.dyn_ltree,me-1),G(oe,oe.dyn_dtree,ie-1)})(E,E.l_desc.max_code+1,E.d_desc.max_code+1,ne+1),L(E,E.dyn_ltree,E.dyn_dtree)),Se(E),B&&fe(E)},s._tr_tally=function(E,O,Y){return E.pending_buf[E.d_buf+2*E.last_lit]=O>>>8&255,E.pending_buf[E.d_buf+2*E.last_lit+1]=255&O,E.pending_buf[E.l_buf+E.last_lit]=255&Y,E.last_lit++,O===0?E.dyn_ltree[2*Y]++:(E.matches++,O--,E.dyn_ltree[2*(k[Y]+p+1)]++,E.dyn_dtree[2*K(O)]++),E.last_lit===E.lit_bufsize-1},s._tr_align=function(E){ae(E,2,3),de(E,S,q),(function(O){O.bi_valid===16?(re(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})(E)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,p,h=1,u={},v=!1,m=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(x){process.nextTick(function(){C(x)})}:(function(){if(l.postMessage&&!l.importScripts){var x=!0,$=l.onmessage;return l.onmessage=function(){x=!1},l.postMessage("","*"),l.onmessage=$,x}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(x){l.postMessage(p+x,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(x){C(x.data)},function(x){d.port2.postMessage(x)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(x){var $=m.createElement("script");$.onreadystatechange=function(){C(x),$.onreadystatechange=null,c.removeChild($),$=null},c.appendChild($)}):function(x){setTimeout(C,0,x)},b.setImmediate=function(x){typeof x!="function"&&(x=new Function(""+x));for(var $=new Array(arguments.length-1),T=0;T<$.length;T++)$[T]=arguments[T+1];var w={callback:x,args:$};return u[h]=w,a(h),h++},b.clearImmediate=y}function y(x){delete u[x]}function C(x){if(v)setTimeout(C,0,x);else{var $=u[x];if($){v=!0;try{(function(T){var w=T.callback,R=T.args;switch(R.length){case 0:w();break;case 1:w(R[0]);break;case 2:w(R[0],R[1]);break;case 3:w(R[0],R[1],R[2]);break;default:w.apply(r,R)}})($)}finally{y(x),v=!1}}}}function S(x){x.source===l&&typeof x.data=="string"&&x.data.indexOf(p)===0&&C(+x.data.slice(p.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ho)),ho.exports}var cg=ag();const Ga=lg(cg);function Ka(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function qa(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const o=await an(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function dg(e,t,i){var c,d,p;const n=kw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&i&&i!==o)return;const l=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await qa(e,l));const a=Ka(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of h){const v=u.querySelector(".item__text"),m=((p=v==null?void 0:v.textContent)==null?void 0:p.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){v&&(v.textContent=a),u.setAttribute("title",a);break}}}}function _n(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function ji(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const l=await i.fetchDocumentTitle(n);if(l&&l.trim())return _n(l)}catch{}if(typeof document<"u")try{const l=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return _n(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return _n(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return _n(a)}return"presentation"}function ug(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function rl(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function fg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function zo(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(a=>a()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{o(),i({success:!0,dataUrl:a.dataUrl})});n.push(l);const r=e.onCaptureError(a=>{o(),i({success:!1,error:a})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Ya(e,t){const i=[],n=_n((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),o.forEach(u=>u()),o=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(u=>{var v;a(),(v=t==null?void 0:t.onProgress)==null||v.call(t,u.current,u.total,u.pageIndex)});o.push(c);const d=e.onCapturePageDone(u=>{a(),(u.mode==="all"||!u.mode)&&i.push({pageIndex:u.pageIndex,dataUrl:u.dataUrl})});o.push(d);const p=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const u=new Ga,v=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of i){const C=String(y.pageIndex).padStart(2,"0"),S=y.dataUrl.split(",")[1];u.file(`slide-${C}.${v}`,S,{base64:!0})}const m=await u.generateAsync({type:"blob",compression:"DEFLATE"}),b=ug(`${n}.zip`,m);s({success:b,total:i.length})}catch(u){s({success:!1,error:(u==null?void 0:u.message)||String(u)})}};o.push(e.onCaptureComplete(p));const h=e.onCaptureError(u=>{r(),s({success:!1,error:u})});o.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Za(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const l=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(l),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await zo(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await ji(e,e.docId);return await Ya(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const pg=1500,hg=500,mg=4,gg=new Set(["INPUT","TEXTAREA","SELECT"]);function Ja(e){const t=e;return!t||!t.tagName?!1:gg.has(t.tagName)||t.isContentEditable===!0}function vg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){l(),t="",i=!1,o()}function a(){n&&clearTimeout(n),n=setTimeout(r,pg)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,hg)}function d(p){if(e.isEnabled&&!e.isEnabled()||Ja(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=mg||(t+=p.key,o(),a()),!0;if(p.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),v=e.getTotalPages();return!isNaN(u)&&u>=1&&v>0&&u<=v?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const bg={class:"spm-slides-tab__toolbar"},yg={class:"spm-slides-tab__nav"},kg=["disabled"],wg={class:"spm-page-badge"},xg=["disabled"],Sg=["aria-label"],Cg=["aria-label"],_g={class:"spm-slides-tab__tools"},$g={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Ig={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Tg=["src"],Eg=Et({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=Ot("plugin"),n=Ot("sandboxBridge",new Qn),s=new Rm(n),o=new kp,l=ge("web-sandbox"),r=ge(3030),a=ge(null),c=ge(!1),d=ge(null),p=ge(1),h=ge(1),u=ge(!1),v=ge(!1),m=ge(!1),b=ge("siyuan"),y=ge(""),C=ge(""),S=ge(""),x=ge(!1),$=ge(!1),T=ge(""),w=ge(""),R=ge(!1),F=vg({getTotalPages:()=>h.value,isEnabled:()=>!v.value,onJump:B=>_(B),onStateChange:B=>{w.value=B.display,R.value=B.invalid}});function P(B){if(B.key==="o"||B.key==="O"){if(v.value||B.isComposing||B.ctrlKey||B.metaKey||B.altKey||Ja(B.target))return;B.preventDefault(),q();return}F.handleKeydown(B)&&B.preventDefault()}function q(){var B,z;if(l.value==="pro-cli"){(B=d.value)==null||B.focus(),ce.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(z=d.value)==null||z.focus()}function _(B){var z;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B),(z=d.value)==null||z.focus()}const H=ge("/plugins/siyuan-live-slides/slides-client/index.html");let k=null,M=null,j=null,A=null,D=null,N=null,ee=null,W=null;mn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),k=n.onSlideChanged((B,z)=>{p.value=B,h.value=z}),M=n.onBlockClicked((B,z)=>{p.value=z,s.setActiveBlockId(B),B||Pn(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(B,z):B&&Fi(B,i==null?void 0:i.app)}),j=n.onOpenInEditor((B,z)=>{p.value=z,s.setActiveBlockId(B),Fi(B,i==null?void 0:i.app)}),A=o.nativeBridge.onPageChanged((B,z)=>{p.value=B,h.value=z}),D=n.onOpenPeekDrawer(async B=>{const z=qs();if(B.peekType==="siyuan"&&z.enableWebServeJump){let J=!1;if(W&&W.docId===B.target)J=!0;else if(W&&W.slides&&W.slides.some(ne=>{var oe;return(oe=ne.blocks)==null?void 0:oe.some(me=>me.id===B.target)}))J=!1;else try{const ne=await an(`SELECT id, root_id, type FROM blocks WHERE id = '${B.target}' LIMIT 1`);ne&&ne.length>0&&(J=ne[0].type==="d"||ne[0].id===ne[0].root_id)}catch(ne){console.warn("[SlidesPreviewTab] detect block type failed:",ne)}b.value="web",x.value=!0,C.value=Ta(z.webServeUrl,B.target,{focus:!J}),S.value=B.title||`${J?"思源文档":"思源块"}: ${B.target.slice(0,8)}`,v.value=!0,n.freezeKeyboardNav(!0)}else{if(b.value=B.peekType,B.peekType==="siyuan")y.value=B.target,S.value=B.title||`块速览: ${B.target.slice(0,8)}`;else{const J=Na(B.target);if(J.external){pe(B.target);return}x.value=!0,C.value=J.url,S.value=B.title||J.url}v.value=!0,n.freezeKeyboardNav(!0)}}),N=n.onRequestToggleFullscreen(()=>{V()}),ee=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",L)}),Us(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",L),D&&D(),N&&N(),ee&&ee(),k&&k(),M&&M(),j&&j(),A&&A(),n.detach(),F.clear(),s.destroy(),o.destroy()});async function K(){if(l.value==="web-sandbox"){if(!W){ce.showMessage("请先在主编辑区打开演示文档");return}ce.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const B=await o.startProMode(W,ko);if(!B.success){ce.showMessage(`无法启动官方 Pro 模式：${B.error}`);return}l.value="pro-cli",r.value=B.port||3030,H.value=B.url,d.value&&o.nativeBridge.attach(d.value),ce.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",H.value="/plugins/siyuan-live-slides/slides-client/index.html",d.value&&n.attach(d.value),ce.showMessage("已切回内置高保真沙箱")}function re(){$.value=!$.value,$.value?(T.value=(W==null?void 0:W.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",T.value)):(T.value="",Se(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ae=0;function de(B){if(v.value||Math.abs(B.deltaY)<Math.abs(B.deltaX)||Math.abs(B.deltaY)<15)return;const z=Date.now();z-ae<280||(ae=z,B.deltaY>0?Ee():ve())}function ve(){if(p.value>1){const B=p.value-1;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Ee(){if(p.value<h.value){const B=p.value+1;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Se(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function fe(){v.value=!1,n.freezeKeyboardNav(!1)}function Z(){fe()}function pe(B){var oe,me;const z=/^file:/i.test(B),J=z||/^[a-zA-Z]:[\\/]/.test(B),ne=$t("electron");if(J&&typeof((oe=ne==null?void 0:ne.shell)==null?void 0:oe.openPath)=="function"){ne.shell.openPath(z?Ra(B):B),ce.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=ne==null?void 0:ne.shell)==null?void 0:me.openExternal)=="function"?ne.shell.openExternal(B).catch(()=>{typeof window<"u"&&window.open(B,"_blank")}):typeof window<"u"&&window.open(B,"_blank"),ce.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function L(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function V(){const B=a.value||d.value;B&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):B.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function G(){if(!W){ce.showMessage("请先在主编辑区打开幻灯片文档");return}const B=Wa(W);Ua("presentation.html",B)&&ce.showMessage("已开始下载单文件离线 HTML 演示包")}function U(){if(!W){ce.showMessage("请先在主编辑区打开幻灯片文档");return}Va(W)&&ce.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const I=ge(!1);async function E(){if(I.value){ce.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!W){ce.showMessage("请先在主编辑区打开幻灯片文档");return}I.value=!0;try{ce.showMessage("正在逐页导出幻灯片图片...",2e3);const B=await ji(W,i==null?void 0:i.currentDocId,i),z=await Ya(n,{title:B,onProgress:(J,ne)=>{ce.showMessage(`正在导出幻灯片图片 (${J} / ${ne})...`,1500)}});z.success?ce.showMessage(`🎉 成功导出 ${z.total||0} 张高清图片并保存为 ${B}.zip！`,4e3):ce.showMessage(`导出图片失败：${z.error||"未知异常"}`)}finally{I.value=!1}}async function O(){if(!W){ce.showMessage("请先在主编辑区打开幻灯片文档");return}ce.showMessage("正在导出当前幻灯片图片...",1500);const B=await zo(n);if(B.success&&B.dataUrl){const z=await ji(W,i==null?void 0:i.currentDocId,i),J=p.value||1,oe=(h.value||1)>1?`${z}-${J}.png`:`${z}.png`;rl(oe,B.dataUrl),ce.showMessage(`已下载当前页高清图片 (${oe})`)}else ce.showMessage(`导出当前页图片失败：${B.error||"未知异常"}`)}async function Y(){if(!W){ce.showMessage("请先在主编辑区打开幻灯片文档");return}ce.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const B=await zo(n);if(B.success&&B.dataUrl)if(await fg(B.dataUrl))ce.showMessage(`已成功将第 ${p.value||1} 页幻灯片复制到剪贴板！`);else{const J=await ji(W,i==null?void 0:i.currentDocId,i),ne=p.value||1,me=(h.value||1)>1?`${J}-${ne}.png`:`${J}.png`;rl(me,B.dataUrl),ce.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else ce.showMessage(`复制失败：${B.error||"未知异常"}`)}return t({updateDocument(B,z){$.value&&T.value&&z&&z!==T.value||(W=B,$.value&&!T.value&&(T.value=B.docId),h.value=B.slides.length,s.setDocId(B.docId),s.updateSlidesIndex(B.slides),l.value==="pro-cli"?o.scaffolder.scaffold(B,ko).catch(()=>{}):n.updateSlides(B.slides,B.config,B.fullMarkdown,B.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",B.docId))},navigateToBlock(B){s.onCursorFocusBlock(B)},isPinned:$,pinnedDocId:T,engineMode:l,toggleEngineMode:K}),(B,z)=>(X(),te("div",{class:"spm-slides-preview-tab",onKeydown:P},[f("div",bg,[f("div",yg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:ve},[le(ue,{name:"chevron-left"})],8,kg),f("span",wg,xe(p.value)+" / "+xe(h.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=h.value,"aria-label":"下一页",onClick:Ee},[le(ue,{name:"chevron-right"})],8,xg),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":$.value}]),"aria-label":$.value?"已锁定当前文档（点击解除）："+T.value:"点击锁定当前文档（不随主编辑区切换）",onClick:re},[le(ue,{name:"pin"}),f("span",null,xe($.value?"已锁定":"跟随"),1)],10,Sg),he(Ct)("proMode")?(X(),te("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:K},[le(ue,{name:"rocket"}),f("span",null,xe(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Cg)):Ie("",!0)]),f("div",_g,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:q},[le(ue,{name:"columns"})]),he(Ct)("presenterMode")?(X(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[le(ue,{name:"presenter"})])):Ie("",!0),he(Ct)("exportHtml")?(X(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:G},[le(ue,{name:"export-html"})])):Ie("",!0),he(Ct)("exportPdf")?(X(),te("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:U},[le(ue,{name:"export-pdf"})])):Ie("",!0),he(Ct)("exportImage")?(X(),te("div",$g,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:E},[le(ue,{name:"export-image"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:z[0]||(z[0]=Kt(J=>u.value=!u.value,["stop"]))},[le(ue,{name:"chevron-down"})]),u.value?(X(),te("div",Ig,[f("button",{class:"b3-menu__item",onClick:z[1]||(z[1]=J=>{E(),u.value=!1})},[...z[6]||(z[6]=[f("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[2]||(z[2]=J=>{O(),u.value=!1})},[...z[7]||(z[7]=[f("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[3]||(z[3]=J=>{Y(),u.value=!1})},[...z[8]||(z[8]=[f("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Ie("",!0)])):Ie("",!0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Se},[le(ue,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:V},[le(ue,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:de},[f("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slides-tab__iframe",src:H.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Tg),le(Yh,{visible:v.value,"onUpdate:visible":z[4]||(z[4]=J=>v.value=J),"is-maximized":m.value,"onUpdate:isMaximized":z[5]||(z[5]=J=>m.value=J),title:S.value,onClose:fe},{default:Jl(()=>[b.value==="siyuan"&&y.value?(X(),qt(sm,{key:0,"block-id":y.value,title:S.value,plugin:he(i),onExternalJump:Z},null,8,["block-id","title","plugin"])):Ie("",!0),x.value?Dt((X(),qt(Pm,{key:1,visible:v.value&&b.value==="web",url:C.value,title:S.value,onExternalJump:Z},null,8,["visible","url","title"])),[[Do,b.value==="web"]]):Ie("",!0)]),_:1},8,["visible","is-maximized","title"]),Dt(f("div",{class:Ce(["spm-jump-badge",{"is-invalid":R.value}])},xe(w.value),3),[[Do,w.value]])],544)],32))}}),Mg=Xt(Eg,[["__scopeId","data-v-527d6ffd"]]);function Xa(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&i.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const h=parseInt(p,10);s=Math.max(s,h),n.set(r.parentContainerId,h)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const p=n.get(r.parentContainerId);o(r,{type:"step",step:p})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const h=Math.min(Number(p[0]),Number(p[1])),u=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(h)&&!isNaN(u)){s=Math.max(s,u),o(r,{type:"range",min:h,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;s+=p,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;s=Math.max(1,s-p),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){s=Math.max(s,p),o(r,{type:"step",step:p});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Ag(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ho=980;function Bg(e){if(!e)return 0;const i=Xa(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=ad(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Dg(e,t=Ho){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",l=i.split(o).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function ll(e,t,i=Ho,n=552,s=16){const o=i>0?i:Ho,l=n>0?n:552,r=Math.max(0,e-s),a=Math.max(0,t-s);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/o,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(l*d))}}function Lg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function al(e,t){if(!e)return"";const i=Lg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?Xa(i.blocks||[]):null,d=ja(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:a?S=>{if(Ag(S,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const $=S.id||S.blockId,T=a.blockMap.get(S)||($?a.idMap.get($):void 0);if((T==null?void 0:T.type)==="step"&&T.step===r||(T==null?void 0:T.type)==="range"&&T.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(S,x)=>{let $=x.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test($)||($+=" muted"),`<video ${$.trim()}>`}),p=n.spacing,h=p&&p!=="inherit"?p:o.spacing||"normal",u=["slide-content",`layout-${s}`,`spacing-${h}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),v=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const S=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;v.push(`background-image:url('${nt(S)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else v.push(`background:${nt(m)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&v.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const C=v.length>0?` style="${v.join("")}"`:"";return`<div class="${nt(u)}"${C}>${d}</div>`}const Pg={class:"presenter-header"},Og={class:"presenter-title-area"},Rg={class:"presenter-brand"},Ng={class:"header-pills"},zg={class:"pill pill-page"},Hg={key:0,class:"pill pill-step"},Fg={class:"header-toolbar"},jg={class:"timer-capsule"},Wg={class:"timer-digits"},Ug={class:"timer-actions"},Vg=["aria-label"],Gg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Kg={key:0,class:"presenter-grid"},qg={class:"slide-panels"},Yg={class:"panel-box current-slide-panel"},Zg={class:"panel-header"},Jg={class:"panel-header-left"},Xg={class:"panel-page-num"},Qg={class:"panel-header-meta"},ev={key:0,class:"panel-step-pill"},tv={class:"panel-layout-pill"},iv=["aria-label"],nv=["data-theme","data-slides-theme","data-normalize-headings","innerHTML"],sv={key:1,class:"panel-fallback"},ov=["aria-label"],rv={class:"panel-header"},lv={class:"panel-header-left"},av={key:0,class:"panel-page-num"},cv={class:"panel-header-meta"},dv={key:0,class:"panel-end-pill"},uv={key:1,class:"panel-layout-pill"},fv=["aria-label"],pv=["data-theme","data-slides-theme","data-normalize-headings","innerHTML"],hv={key:1,class:"panel-fallback"},mv={class:"notes-panel"},gv={class:"panel-header"},vv={class:"panel-header-left"},bv={class:"notes-size-controls"},yv=["disabled"],kv={class:"notes-size-value"},wv=["disabled"],xv={key:1,class:"presenter-empty"},Sv={class:"empty-icon-wrap"},Cv={class:"empty-actions"},_v={class:"presenter-actions"},$v={class:"nav-btn-group"},Iv=["disabled"],Tv=["disabled"],Ev={class:"actions-center"},Mv={class:"center-meta"},Av={class:"progress-pill"},Bv={class:"nav-btn-group"},Dv=["aria-label"],Lv={class:"step-dots-text"},Pv=["disabled"],Ov=["disabled"],Rv=280,Nv=15,zv=Et({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=Ot("plugin"),n=Ot("sandboxBridge",new Qn),s=ge([]),o=ge({}),l=ge(1),r=ge(0),a=ge(0),c=ge(0),d=ye(()=>s.value.length||a.value),p=ge(null),h=ge(null),u=ge({width:0,height:0}),v=ge({width:0,height:0}),m=ye(()=>{var ie;return Dg((ie=o.value)==null?void 0:ie.aspectRatio)}),b=ye(()=>{var ie;return((ie=o.value)==null?void 0:ie.theme)||"default"}),y=ye(()=>{var ie;return((ie=o.value)==null?void 0:ie.colorSchema)==="light"?"light":"dark"}),C=ye(()=>{var ie;return!!((ie=o.value)!=null&&ie.normalizeHeadingSizes)}),S=ye(()=>ll(u.value.width,u.value.height,m.value.baseWidth,m.value.baseHeight,14)),x=ye(()=>ll(v.value.width,v.value.height,m.value.baseWidth,m.value.baseHeight,14));function $(){p.value&&(u.value={width:p.value.clientWidth,height:p.value.clientHeight}),h.value&&(v.value={width:h.value.clientWidth,height:h.value.clientHeight})}let T=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(T||(T=new window.ResizeObserver(()=>{$()})),T.disconnect(),p.value&&T.observe(p.value),h.value&&T.observe(h.value))}Hi([p,h,d],()=>{Is(()=>{w(),$()})},{flush:"post"});const R=ge(0),F=ge(!0);let P=null;const q=ye(()=>{const ie=String(Math.floor(R.value/60)).padStart(2,"0"),se=String(R.value%60).padStart(2,"0");return`${ie}:${se}`});function _(){F.value=!F.value}function H(){R.value=0}const k=ge("");let M=null;function j(){const ie=new Date,se=String(ie.getHours()).padStart(2,"0"),_e=String(ie.getMinutes()).padStart(2,"0");k.value=`${se}:${_e}`}const A=ye(()=>s.value.length===0?null:s.value[l.value-1]||null),D=ye(()=>l.value>=s.value.length?null:s.value[l.value]||null),N=ye(()=>A.value?Bg(A.value):c.value),ee=ye(()=>l.value>1||r.value>0),W=ye(()=>l.value<d.value||r.value<N.value),K=ye(()=>al(A.value,{config:o.value,allSlides:s.value,pageIndex:l.value,currentStep:r.value})),re=ye(()=>al(D.value,{config:o.value,allSlides:s.value,pageIndex:l.value+1})),ae=ye(()=>{var se;if(!A.value)return"无内容";const ie=(se=A.value.blocks)==null?void 0:se[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value} 页`});function de(ie){return(ie||[]).slice(1).map(se=>(se.content||se.rawMarkdown||"").trim()).filter(se=>se&&!/^(image\s+)?assets\/\S*$/i.test(se)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(se)).join(" | ").slice(0,120)}const ve=ye(()=>{var ie;return de((ie=A.value)==null?void 0:ie.blocks)}),Ee=ye(()=>{var se;if(!D.value)return"演示结束";const ie=(se=D.value.blocks)==null?void 0:se[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value+1} 页`}),Se=ye(()=>D.value?de(D.value.blocks):"这是最后一页"),fe=ye(()=>{var ie;return((ie=A.value)==null?void 0:ie.notes)||""}),Z=ge(20);function pe(){Z.value<36&&(Z.value+=2)}function L(){Z.value>14&&(Z.value-=2)}const V=ye(()=>d.value<=1?100:Math.round(l.value/d.value*100));let g=null;try{g=new BroadcastChannel("siyuan-slides-sync"),g.onmessage=ie=>{const se=ie.data;if(se&&(se.type==="SYNC_PAGE"&&typeof se.page=="number"&&(l.value=se.page,r.value=typeof se.step=="number"?Math.max(0,se.step):0,typeof se.maxStep=="number"&&(c.value=Math.max(0,se.maxStep))),se.type==="SYNC_SLIDES"&&Array.isArray(se.slides)&&(s.value=se.slides,se.config&&typeof se.config=="object"&&(o.value=se.config)),se.type==="REQUEST_SYNC"&&s.value.length>0))try{g==null||g.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),g==null||g.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:N.value})}catch{}}}catch{g=null}function G(ie,se=0){const _e=Number(ie)||1,Be=Math.max(0,Number(se)||0);n.navigatePage(_e,Be);try{g==null||g.postMessage({type:"SYNC_PAGE",page:_e,step:Be,maxStep:N.value})}catch{}}function U(){if(r.value<N.value){r.value++,G(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function I(){if(r.value>0){r.value--,G(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,G(l.value,0))}function E(){l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function O(){l.value>1&&(l.value--,r.value=0,G(l.value,0))}function Y(){l.value=1,r.value=0,H(),G(1,0)}function B(){const ie=i;typeof(ie==null?void 0:ie.openBottomPreviewTab)=="function"&&ie.openBottomPreviewTab()}function z(){const ie=i;typeof(ie==null?void 0:ie.openStandalonePreviewWindow)=="function"&&ie.openStandalonePreviewWindow()}function J(ie){var se,_e;if(!(ie.key===" "&&((_e=(se=ie.target)==null?void 0:se.closest)!=null&&_e.call(se,"button")))){if(ie.shiftKey&&ie.key==="ArrowRight"||ie.key==="ArrowDown"){ie.preventDefault(),E();return}if(ie.shiftKey&&ie.key==="ArrowLeft"||ie.key==="ArrowUp"){ie.preventDefault(),O();return}ie.key==="ArrowRight"||ie.key===" "||ie.key==="PageDown"?(ie.preventDefault(),U()):(ie.key==="ArrowLeft"||ie.key==="PageUp")&&(ie.preventDefault(),I())}}let ne=0;function oe(ie){var Be,Ne;if(Math.abs(ie.deltaY)<Nv)return;const se=(Ne=(Be=ie.target)==null?void 0:Be.closest)==null?void 0:Ne.call(Be,".notes-content");if(se){const Re=se.scrollHeight-se.clientHeight;if(Re>2&&(ie.deltaY>0&&se.scrollTop<Re-1||ie.deltaY<0&&se.scrollTop>1))return}const _e=Date.now();_e-ne<Rv||(ne=_e,ie.deltaY>0?U():I())}let me=null;return mn(()=>{var se;P=window.setInterval(()=>{F.value&&R.value++},1e3),j(),M=window.setInterval(j,1e3),me=n.onSlideChanged((_e,Be,Ne,Re,De)=>{l.value=_e,Be>0&&(a.value=Be),typeof Re=="number"&&(r.value=Math.max(0,Re)),typeof De=="number"&&(c.value=Math.max(0,De))});try{g==null||g.postMessage({type:"REQUEST_SYNC"})}catch{}const ie=i==null?void 0:i.latestCompiledDoc;(se=ie==null?void 0:ie.slides)!=null&&se.length&&(s.value=ie.slides,ie.config&&(o.value=ie.config)),typeof window<"u"&&window.addEventListener("resize",$),Is(()=>{w(),$()})}),Us(()=>{P&&(window.clearInterval(P),P=null),M&&(window.clearInterval(M),M=null),me&&me(),typeof window<"u"&&window.removeEventListener("resize",$),T&&(T.disconnect(),T=null);try{g==null||g.close()}catch{}g=null}),t({updateDocument(ie){var se;(se=ie==null?void 0:ie.slides)!=null&&se.length&&(s.value=ie.slides),ie!=null&&ie.config&&(o.value=ie.config)}}),(ie,se)=>{var _e,Be,Ne;return X(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:J,onWheel:oe},[f("header",Pg,[f("div",Og,[f("div",Rg,[le(ue,{name:"presenter",class:"brand-icon"}),se[1]||(se[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Ng,[f("span",zg,"P."+xe(l.value)+" / "+xe(d.value||1),1),N.value>0?(X(),te("span",Hg,[le(ue,{name:"step",class:"pill-icon"}),St(" 步进 "+xe(r.value)+" / "+xe(N.value),1)])):Ie("",!0)])]),f("div",Fg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:z},[le(ue,{name:"window"}),se[2]||(se[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",jg,[le(ue,{name:"clock",class:"timer-icon"}),f("span",Wg,xe(q.value),1),f("div",Ug,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":F.value?"暂停计时":"继续计时",onClick:_},[le(ue,{name:F.value?"pause":"play"},null,8,["name"])],8,Vg),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:H},[le(ue,{name:"reset"})])])]),f("div",Gg,[f("span",null,xe(k.value),1)])])]),d.value>0?(X(),te("main",Kg,[f("section",qg,[f("div",Yg,[f("div",Zg,[f("div",Jg,[se[3]||(se[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",Xg,"P."+xe(l.value),1)]),f("div",Qg,[N.value>0?(X(),te("span",ev," 步进 "+xe(r.value)+" / "+xe(N.value),1)):Ie("",!0),f("span",tv,xe(((Be=(_e=A.value)==null?void 0:_e.frontmatter)==null?void 0:Be.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":ae.value},[A.value?(X(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:S.value.boxWidth+"px",height:S.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":C.value?"true":"false",style:Gt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+S.value.scale+")"}),innerHTML:K.value},null,14,nv)],4)):(X(),te("div",sv,[f("h2",null,xe(ae.value),1),f("p",null,xe(ve.value),1)]))],8,iv)]),f("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!D.value,"b3-tooltips b3-tooltips__n":!!D.value}]),"aria-label":D.value?"点击直接跳至下一页":"",onClick:se[0]||(se[0]=Re=>D.value&&E())},[f("div",rv,[f("div",lv,[se[4]||(se[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<d.value?(X(),te("span",av,"P."+xe(l.value+1),1)):Ie("",!0)]),f("div",cv,[l.value>=d.value?(X(),te("span",dv,"已到尾页")):D.value?(X(),te("span",uv,xe(((Ne=D.value.frontmatter)==null?void 0:Ne.layout)||"default"),1)):Ie("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":Ee.value},[D.value?(X(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:x.value.boxWidth+"px",height:x.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":C.value?"true":"false",style:Gt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+x.value.scale+")"}),innerHTML:re.value},null,14,pv)],4)):(X(),te("div",hv,[f("h2",null,xe(Ee.value),1),f("p",null,xe(Se.value),1)]))],8,fv)],10,ov)]),f("section",mv,[f("div",gv,[f("div",vv,[le(ue,{name:"notes",class:"panel-title-icon"}),se[5]||(se[5]=f("span",null,"讲稿备忘",-1))]),f("div",bv,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:Z.value<=14,onClick:L},[le(ue,{name:"minus"})],8,yv),f("span",kv,xe(Z.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:Z.value>=36,onClick:pe},[le(ue,{name:"plus"})],8,wv)])]),f("div",{class:Ce(["notes-content",{"is-empty":!fe.value}]),style:Gt({fontSize:Z.value+"px"})},xe(fe.value||"（本页未设置演讲者备忘录）"),7)])])):(X(),te("main",xv,[f("div",Sv,[le(ue,{name:"refresh",class:"empty-icon"})]),se[8]||(se[8]=f("h2",null,"等待大屏放映数据",-1)),se[9]||(se[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",Cv,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:B},[le(ue,{name:"presenter"}),se[6]||(se[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:z},[le(ue,{name:"window"}),se[7]||(se[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",_v,[f("div",$v,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:O},[le(ue,{name:"chevrons-left"}),se[10]||(se[10]=f("span",null,"上一页",-1))],8,Iv),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!ee.value,"aria-label":"回退一步 (←)",onClick:I},[le(ue,{name:"chevron-left"}),se[11]||(se[11]=f("span",null,"上一步",-1))],8,Tv)]),f("div",Ev,[f("div",Mv,[f("span",Av,xe(V.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Y},[le(ue,{name:"reset"}),se[12]||(se[12]=f("span",null,"重头放映",-1))])]),f("div",Bv,[N.value>0?(X(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${N.value}`},[(X(!0),te(Ge,null,kt(N.value,Re=>(X(),te("span",{key:Re,class:Ce(["step-dot",{"is-active":Re<=r.value}])},null,2))),128)),f("span",Lv,xe(r.value)+"/"+xe(N.value),1)],8,Dv)):Ie("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!W.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:U},[se[13]||(se[13]=f("span",null,"下一步",-1)),le(ue,{name:"chevron-right"})],8,Pv),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:E},[se[14]||(se[14]=f("span",null,"下一页",-1)),le(ue,{name:"chevrons-right"})],8,Ov)])])],32)}}}),Hv=Xt(zv,[["__scopeId","data-v-9cec5e4a"]]),Fv={class:"spm-layout-picker"},jv={class:"spm-layout-picker__grid"},Wv=["title","onClick"],Uv={class:"spm-layout-icon"},Vv={class:"spm-layout-label"},Gv=Et({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(X(),te("div",Fv,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",jv,[(X(),te(Ge,null,kt(s,c=>f("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[f("div",Uv,[le(ue,{name:"layout-"+c.name},null,8,["name"])]),f("span",Vv,xe(c.label),1)],10,Wv)),64))])]))}}),Kv=Xt(Gv,[["__scopeId","data-v-96c8a248"]]),qv={key:0,class:"spm-transition-selector__header"},Yv={class:"spm-transition-list"},Zv=["onClick"],Jv={class:"spm-transition-meta"},Xv={class:"spm-transition-label"},Qv={class:"spm-transition-name"},eb={class:"spm-transition-preview-box"},tb=Et({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,l)=>(X(),te("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Ie("",!0):(X(),te("div",qv,xe(e.title||"转场动效"),1)),f("div",Yv,[(X(),te(Ge,null,kt(n,r=>f("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>s(r.name)},[f("div",Jv,[f("span",Xv,xe(r.label),1),f("span",Qv,"("+xe(r.name)+")",1)]),f("div",eb,[f("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Zv)),64))])],2))}}),Qa=Xt(tb,[["__scopeId","data-v-8597e99e"]]),ib={class:"spm-section spm-section--page"},nb={class:"spm-section-header"},sb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},ob={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},rb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},lb={key:1,class:"spm-card-control"},ab={class:"spm-control-header"},cb={class:"spm-control-title-group"},db={class:"spm-control-title"},ub={class:"spm-quick-chips"},fb=["onClick"],pb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},hb=["value"],mb=["aria-label"],gb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},vb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},bb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},yb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},kb={class:"spm-card-control"},wb={class:"spm-control-header"},xb={class:"spm-control-title-group"},Sb={class:"spm-control-title"},Cb={class:"spm-segmented-group"},_b={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},$b={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Ib=["aria-label"],Tb={class:"spm-quick-chips"},Eb=["onClick"],Mb=["value"],Ab={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Bb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Db={style:{flex:"1"}},Lb={class:"spm-segmented-group"},Pb={style:{flex:"1"}},Ob={class:"spm-segmented-group"},Rb={class:"spm-card-control"},Nb={class:"spm-control-header"},zb={class:"spm-control-title-group"},Hb={class:"spm-control-title"},Fb={class:"spm-segmented-group"},jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Gb={class:"spm-quick-chips"},Kb=["onClick"],qb=["value"],Yb={key:2,class:"spm-card-control"},Zb={class:"spm-control-header"},Jb={class:"spm-control-title-group"},Xb={class:"spm-control-title"},Qb={class:"spm-quick-chips"},e1=["onClick"],t1=["value"],i1={class:"spm-card-control"},n1={class:"spm-control-header"},s1={class:"spm-control-title-group"},o1={class:"spm-control-title"},r1={key:0,class:"spm-note-status-box"},l1=["title"],a1={class:"spm-action-grid",style:{"margin-top":"6px"}},c1={key:1,class:"spm-note-empty-box"},d1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},u1={class:"spm-action-grid"},f1=["disabled"],p1=["disabled"],h1={class:"spm-card-control"},m1={class:"spm-action-grid"},g1=Et({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const S=i.pageMask;return S==="clockwise"||S==="counter-clockwise"||S==="cw"||S==="ccw"}),l=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||l.value);function a(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const d=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),p=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),h=ye(()=>{var $,T;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const S=(i.pageLayoutRatio||"").trim();if(S.includes(":")){const w=S.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}const x=(i.detectedSbRatio||"").trim();if(x.includes(":")){const w=x.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}if(($=i.detectedSbInfo)!=null&&$.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((T=i.detectedSbInfo)!=null&&T.slots&&Array.isArray(i.detectedSbInfo.slots)){const w=i.detectedSbInfo.slots.length;if(w>=2&&w<=6)return w}return 2}),u=ye(()=>{const S=h.value;return S===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:S===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:S===5?[{label:"默认 1:1:1:1:1",value:""}]:S===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),v=ye(()=>i.pageLayoutRatio||"");function m(){const S=h.value||2,x=Array(S).fill("1").join(":");n("update:pageLayoutRatio",x),n("resetSuperblockRatio")}const b=ye(()=>{if(!i.pageNotes)return"";const S=i.pageNotes.replace(/[\r\n]+/g," ").trim();return S.length>50?S.slice(0,50)+"...":S}),y=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],C=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(S,x)=>(X(),te("div",ib,[f("div",nb,[f("span",null,"幻灯片页面设置"+xe(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(Kv,{"model-value":e.pageLayout,onChange:x[0]||(x[0]=$=>S.$emit("update:pageLayout",$))},null,8,["model-value"]),!p.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(X(),te("div",sb,[f("div",ob,[f("div",rb,[le(ue,{name:"sparkles"}),f("span",null,[x[33]||(x[33]=St("检测到本页横向超级块列宽比例：",-1)),f("b",null,xe(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:x[1]||(x[1]=$=>S.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(ue,{name:"columns"}),x[34]||(x[34]=f("span",null,"设为分栏",-1))])])])):Ie("",!0),p.value?(X(),te("div",lb,[f("div",ab,[f("div",cb,[f("div",db,[le(ue,{name:"ratio"}),x[35]||(x[35]=f("span",null,"分栏比例 (Ratio)",-1))]),x[36]||(x[36]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",ub,[(X(!0),te(Ge,null,kt(u.value,$=>(X(),te("button",{key:$.value,class:Ce(["spm-chip",{active:v.value===$.value}]),onClick:T=>S.$emit("update:pageLayoutRatio",$.value)},xe($.label),11,fb))),128))]),f("div",pb,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:x[2]||(x[2]=$=>S.$emit("update:pageLayoutRatio",$.target.value)),onChange:x[3]||(x[3]=$=>S.$emit("update:pageLayoutRatio",$.target.value))},null,40,hb),e.detectedSbRatio?(X(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:x[4]||(x[4]=$=>S.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(ue,{name:"sparkles"}),x[37]||(x[37]=f("span",null,"读取",-1))],8,mb)):(X(),te("button",gb,[le(ue,{name:"sparkles"}),x[38]||(x[38]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[le(ue,{name:"reset"}),x[39]||(x[39]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(X(),te("div",vb,[le(ue,{name:"ratio"}),x[40]||(x[40]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",bb,xe(e.detectedSbRatio),1)])):(X(),te("div",yb,[le(ue,{name:"ratio"}),x[41]||(x[41]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ie("",!0),le(Qa,{"model-value":e.pageTransition,onChange:x[5]||(x[5]=$=>S.$emit("update:pageTransition",$))},null,8,["model-value"]),f("div",kb,[f("div",wb,[f("div",xb,[f("div",Sb,[le(ue,{name:"sparkles"}),x[42]||(x[42]=f("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),x[43]||(x[43]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",Cb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:x[6]||(x[6]=$=>S.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:x[7]||(x[7]=$=>c("down"))}," 从上至下 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:x[8]||(x[8]=$=>c("right"))}," 从左至右 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:x[9]||(x[9]=$=>a("clockwise"))}," 顺时针 ↻ ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:x[10]||(x[10]=$=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(X(),te("div",_b,[f("div",$b,[x[45]||(x[45]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":d.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[le(ue,{name:"help"}),x[44]||(x[44]=f("span",null,"输入规则",-1))],8,Ib)]),f("div",Tb,[(X(),te(Ge,null,kt(s,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:r.value===$.value}]),onClick:T=>S.$emit("update:pageMaskRatio",$.value)},xe($.label),11,Eb)),64))]),f("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:x[11]||(x[11]=$=>S.$emit("update:pageMaskRatio",$.target.value)),onChange:x[12]||(x[12]=$=>S.$emit("update:pageMaskRatio",$.target.value))},null,40,Mb),f("div",Ab,xe(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),f("div",Bb,[f("div",Db,[x[46]||(x[46]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Lb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:x[13]||(x[13]=$=>S.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:x[14]||(x[14]=$=>S.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",Pb,[x[47]||(x[47]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Ob,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:x[15]||(x[15]=$=>S.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:x[16]||(x[16]=$=>S.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Ie("",!0)]),f("div",Rb,[f("div",Nb,[f("div",zb,[f("div",Hb,[le(ue,{name:"ratio"}),x[48]||(x[48]=f("span",null,"页面间距 (Spacing)",-1))]),x[49]||(x[49]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",Fb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:x[17]||(x[17]=$=>S.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:x[18]||(x[18]=$=>S.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:x[19]||(x[19]=$=>S.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:x[20]||(x[20]=$=>S.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",jb,[f("div",Wb,[f("div",Ub,[f("div",Vb,[le(ue,{name:"palette"}),x[50]||(x[50]=f("span",null,"页面背景 (Background)",-1))]),x[51]||(x[51]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",Gb,[(X(),te(Ge,null,kt(y,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:e.pageBackground===$.value}]),onClick:T=>S.$emit("update:pageBackground",$.value)},xe($.label),11,Kb)),64))]),f("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:x[21]||(x[21]=$=>S.$emit("update:pageBackground",$.target.value)),onChange:x[22]||(x[22]=$=>S.$emit("update:pageBackground",$.target.value))},null,40,qb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(X(),te("div",Yb,[f("div",Zb,[f("div",Jb,[f("div",Xb,[le(ue,{name:"image"}),x[52]||(x[52]=f("span",null,"页面图片 (Image)",-1))]),x[53]||(x[53]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Qb,[(X(),te(Ge,null,kt(C,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:e.pageImage===$.value}]),onClick:T=>S.$emit("update:pageImage",$.value)},xe($.label),11,e1)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:x[23]||(x[23]=$=>S.$emit("update:pageImage",$.target.value)),onChange:x[24]||(x[24]=$=>S.$emit("update:pageImage",$.target.value))},null,40,t1)])):Ie("",!0),f("div",i1,[f("div",n1,[f("div",s1,[f("div",o1,[le(ue,{name:"presenter"}),x[54]||(x[54]=f("span",null,"演讲者提词 (Notes)",-1))]),x[55]||(x[55]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(Ct)("aiScript")?(X(),te("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:x[25]||(x[25]=$=>S.$emit("generateNotes"))},[le(ue,{name:"sparkles"}),x[56]||(x[56]=f("span",null,"AI 讲稿",-1))])):Ie("",!0)]),e.pageNotes?(X(),te("div",r1,[x[59]||(x[59]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},xe(b.value),9,l1),f("div",a1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:x[26]||(x[26]=$=>S.$emit("locateNoteBlock"))},[le(ue,{name:"search"}),x[57]||(x[57]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:x[27]||(x[27]=$=>S.$emit("addNoteBlock"))},[le(ue,{name:"insert-below"}),x[58]||(x[58]=f("span",null,"追加讲稿块",-1))])])])):(X(),te("div",c1,[x[61]||(x[61]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:x[28]||(x[28]=$=>S.$emit("addNoteBlock"))},[le(ue,{name:"insert-below"}),x[60]||(x[60]=f("span",null,"添加讲稿备注块",-1))])])),f("div",d1,[f("div",u1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:x[29]||(x[29]=$=>S.$emit("batchAppendNotes"))},[le(ue,{name:"insert-below"}),x[62]||(x[62]=f("span",null,"全部追加",-1))],12,f1),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:x[30]||(x[30]=$=>S.$emit("batchDeleteNotes"))},[le(ue,{name:"trash"}),x[63]||(x[63]=f("span",null,"全部删除",-1))],12,p1)])])]),f("div",h1,[x[66]||(x[66]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",m1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:x[31]||(x[31]=$=>S.$emit("insertDividerAfter"))},[le(ue,{name:"insert-below"}),x[64]||(x[64]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:x[32]||(x[32]=$=>S.$emit("deleteDivider"))},[le(ue,{name:"trash"}),x[65]||(x[65]=f("span",null,"删除此页",-1))])])])]))}}),v1=Xt(g1,[["__scopeId","data-v-87c0bbc3"]]),b1={class:"spm-section spm-section--block"},y1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},k1={class:"spm-control-header"},w1={class:"spm-control-title-group"},x1={class:"spm-control-title"},S1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},C1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},_1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},$1={key:0},I1={key:1},T1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},E1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},M1={class:"spm-action-grid"},A1={class:"spm-card-control"},B1={class:"spm-control-header"},D1={class:"spm-control-title-group"},L1={class:"spm-control-title"},P1=["aria-label"],O1=["checked"],R1={key:1,class:"spm-card-control"},N1={class:"spm-control-header"},z1={class:"spm-control-title-group"},H1={class:"spm-control-title"},F1={class:"spm-quick-chips"},j1={key:2,class:"spm-card-control"},W1={class:"spm-control-header"},U1={class:"spm-control-title-group"},V1={class:"spm-control-title"},G1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},K1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},q1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Y1=["aria-label"],Z1=["checked"],J1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},X1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Q1=["aria-label"],ey=["checked"],ty={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},iy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ny=["aria-label"],sy=["checked"],oy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ry={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ly=["aria-label"],ay=["checked"],cy={class:"spm-card-control"},dy={class:"spm-control-header"},uy={class:"spm-control-title-group"},fy={class:"spm-control-title"},py=["aria-label"],hy=["checked"],my={key:0,class:"spm-quick-chips"},gy=["onClick"],vy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},by={class:"spm-card-control"},yy={class:"spm-control-header"},ky={class:"spm-control-title-group"},wy={class:"spm-control-title"},xy=["aria-label"],Sy=["checked"],Cy={key:0,class:"spm-quick-chips"},_y=["onClick"],$y={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Iy={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Ty={style:{display:"flex",gap:"6px"}},Ey=["value"],My=["value"],Ay={key:3,class:"spm-card-control"},By={class:"spm-control-header"},Dy={class:"spm-control-title-group"},Ly={class:"spm-control-title"},Py={class:"spm-control-desc"},Oy={class:"spm-segmented-group"},Ry=["onClick"],Ny={key:4,class:"spm-card-control"},zy={class:"spm-control-header"},Hy={class:"spm-control-title-group"},Fy={class:"spm-control-title"},jy={class:"spm-quick-chips"},Wy=["onClick"],Uy=["value"],Vy={key:5,class:"spm-card-control"},Gy={class:"spm-control-header"},Ky={class:"spm-control-title-group"},qy={class:"spm-control-title"},Yy={class:"spm-quick-chips"},Zy=["onClick"],Jy=["value"],Xy={class:"spm-card-control"},Qy={class:"spm-action-grid"},e0=["aria-label"],t0=Et({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ye(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),s=ye(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),o=ye(()=>{var w,R,F,P;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(R=i.elemSlot)==null?void 0:R.match(/^col-(\d+)$/);if(T){const q=parseInt(T[1],10);if(q>=2&&q<=6)return Math.max(q,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((P=(F=i.detectedSbInfo)==null?void 0:F.ratio)!=null&&P.includes(":")){const q=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(q.length>=2)return Math.min(q.length,6)}return 3}),l=ye(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=ye(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,R=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let F=1;F<=w;F++)R.push({value:`col-${F}`,label:`第 ${F} 栏`});return R});function c(T){const w=i.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&o.value===3||T==="col-2"&&w==="right"&&o.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=ye(()=>!!h.value),v=ye(()=>{var T;return((T=h.value)==null?void 0:T.preset)||"slide-up"}),m=ye(()=>{var T;return((T=h.value)==null?void 0:T.duration)||0}),b=ye(()=>{var T;return((T=h.value)==null?void 0:T.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function C(T){$(T,m.value,b.value)}function S(T){$(v.value,T,b.value)}function x(T){$(v.value,m.value,T)}function $(T,w,R){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!R){d("update:elemMotion",T);return}const F={preset:T};w>0&&(F.duration=w),R>0&&(F.delay=R),d("update:elemMotion",JSON.stringify(F))}return(T,w)=>{var R,F,P,q,_,H;return X(),te("div",b1,[w[62]||(w[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(R=e.detectedSbInfo)!=null&&R.hasSuperBlock?(X(),te("div",y1,[f("div",k1,[f("div",w1,[f("div",x1,[le(ue,{name:"ratio"}),w[24]||(w[24]=f("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",S1,[f("div",C1,[f("div",_1,[le(ue,{name:"ratio"}),(F=e.detectedSbInfo)!=null&&F.isCustomWidth?(X(),te("span",$1,"已识别自定义列宽比例")):(X(),te("span",I1,"识别到 "+xe(((P=e.detectedSbInfo)==null?void 0:P.colCount)||2)+" 列超级块分栏",1))]),f("code",T1,xe(((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1"),1)]),f("div",E1,xe((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",M1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(ue,{name:"sparkles"}),w[26]||(w[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var M;return T.$emit("applySuperBlockRatio",((M=e.detectedSbInfo)==null?void 0:M.ratio)||"1:1")})},[le(ue,{name:"check"}),f("span",null,"应用比例 ("+xe(((H=e.detectedSbInfo)==null?void 0:H.ratio)||"1:1")+")",1)])])])):Ie("",!0),f("div",A1,[f("div",B1,[f("div",D1,[f("div",L1,[le(ue,{name:"presenter"}),w[27]||(w[27]=f("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>T.$emit("toggleNote"))},null,40,O1),w[29]||(w[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,P1)])]),e.isImage||e.imageRole?(X(),te("div",R1,[f("div",N1,[f("div",z1,[f("div",H1,[le(ue,{name:"image"}),w[30]||(w[30]=f("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",F1,[f("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>T.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>T.$emit("update:imageRole","background"))},[le(ue,{name:"image"}),w[32]||(w[32]=f("span",null,"背景图",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>T.$emit("update:imageRole","image-left"))},[le(ue,{name:"image-left"}),w[33]||(w[33]=f("span",null,"图左",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>T.$emit("update:imageRole","image-right"))},[le(ue,{name:"image-right"}),w[34]||(w[34]=f("span",null,"图右",-1))],2)])])):Ie("",!0),e.isVideo?(X(),te("div",j1,[f("div",W1,[f("div",U1,[f("div",V1,[le(ue,{name:"video"}),w[35]||(w[35]=f("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",G1,[f("div",K1,[f("span",q1,[le(ue,{name:"sliders"}),w[37]||(w[37]=St(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>T.$emit("toggleVideoControls"))},null,40,Z1),w[38]||(w[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,Y1)]),f("div",J1,[f("span",X1,[le(ue,{name:"video"}),w[39]||(w[39]=St(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>T.$emit("toggleVideoAutoplay"))},null,40,ey),w[40]||(w[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,Q1)]),f("div",ty,[f("span",iy,[le(ue,{name:"repeat"}),w[41]||(w[41]=St(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>T.$emit("toggleVideoLoop"))},null,40,sy),w[42]||(w[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,ny)]),f("div",oy,[f("span",ry,[le(ue,{name:"volume-x"}),w[43]||(w[43]=St(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>T.$emit("toggleVideoMuted"))},null,40,ay),w[44]||(w[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,ly)])])])):Ie("",!0),f("div",cy,[f("div",dy,[f("div",uy,[f("div",fy,[le(ue,{name:"step"}),w[45]||(w[45]=f("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>T.$emit("toggleElemClick"))},null,40,hy),w[47]||(w[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,py)]),e.elemClick?(X(),te("div",my,[(X(),te(Ge,null,kt(["+1","1","2","hide"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemClick===k}]),onClick:M=>T.$emit("update:elemClick",k)},xe(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,gy)),64))])):e.parentElemClick?(X(),te("div",vy,[le(ue,{name:"check"}),w[48]||(w[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ie("",!0)]),f("div",by,[f("div",yy,[f("div",ky,[f("div",wy,[le(ue,{name:"motion"}),w[49]||(w[49]=f("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[f("input",{type:"checkbox",checked:u.value,onChange:y},null,40,Sy),w[51]||(w[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,xy)]),u.value?(X(),te("div",Cy,[(X(),te(Ge,null,kt(p,k=>f("button",{key:k.value,class:Ce(["spm-chip",{active:v.value===k.value}]),onClick:M=>C(k.value)},xe(k.label),11,_y)),64))])):Ie("",!0),u.value?(X(),te("div",$y,[f("div",Iy,[f("span",null,"时长: "+xe(m.value?m.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+xe(b.value?b.value+"ms":"0ms"),1)]),f("div",Ty,[f("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:w[12]||(w[12]=k=>S(Number(k.target.value)))},[...w[52]||(w[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,Ey),f("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=k=>x(Number(k.target.value)))},[...w[53]||(w[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,My)])])):Ie("",!0)]),s.value||e.elemSlot?(X(),te("div",Ay,[f("div",By,[f("div",Dy,[f("div",Ly,[le(ue,{name:"columns"}),f("span",null,xe(l.value),1)]),f("span",Py,xe(r.value),1)])]),f("div",Oy,[(X(!0),te(Ge,null,kt(a.value,k=>(X(),te("button",{key:k.value,class:Ce(["spm-segmented-item",{active:c(k.value)}]),onClick:M=>T.$emit("update:elemSlot",k.value)},xe(k.label),11,Ry))),128))])])):Ie("",!0),e.isCodeBlock?(X(),te("div",Ny,[f("div",zy,[f("div",Hy,[f("div",Fy,[le(ue,{name:"code"}),w[54]||(w[54]=f("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",jy,[(X(),te(Ge,null,kt(["1-3","all","1|2|3","2-5"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemShikiLines===k}]),onClick:M=>T.$emit("update:elemShikiLines",k)},xe(k),11,Wy)),64)),e.elemShikiLines?(X(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Ie("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>T.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>T.$emit("update:elemShikiLines",k.target.value))},null,40,Uy)])):Ie("",!0),e.isCodeBlock?(X(),te("div",Vy,[f("div",Gy,[f("div",Ky,[f("div",qy,[le(ue,{name:"code"}),w[56]||(w[56]=f("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",Yy,[(X(),te(Ge,null,kt(["240px","320px","400px","50vh"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:M=>T.$emit("update:elemMaxHeight",k)},xe(k),11,Zy)),64)),e.elemMaxHeight?(X(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ie("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>T.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>T.$emit("update:elemMaxHeight",k.target.value))},null,40,Jy)])):Ie("",!0),f("div",Xy,[w[61]||(w[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",Qy,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>T.$emit("insertDividerBefore"))},[le(ue,{name:"insert-above"}),w[58]||(w[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>T.$emit("insertDividerAfter"))},[le(ue,{name:"insert-below"}),w[59]||(w[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>T.$emit("setTwoColsContrast"))},[le(ue,{name:"columns"}),f("span",null,xe(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,e0),e.hasBlockAttrs?(X(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:w[23]||(w[23]=k=>T.$emit("clearBlockAttrs"))},[le(ue,{name:"broom"}),w[60]||(w[60]=f("span",null,"清除属性",-1))])):Ie("",!0)])])])}}}),i0={class:"spm-section spm-section--doc"},n0={class:"spm-card-control"},s0={class:"spm-control-header"},o0={class:"spm-control-title-group"},r0={class:"spm-control-title"},l0={class:"spm-segmented-group"},a0=["aria-label","onClick"],c0={class:"spm-card-control"},d0={class:"spm-control-header"},u0={class:"spm-control-title-group"},f0={class:"spm-control-title"},p0={class:"spm-segmented-group"},h0={class:"spm-card-control"},m0={class:"spm-control-header"},g0={class:"spm-control-title-group"},v0={class:"spm-control-title"},b0={class:"spm-segmented-group"},y0={class:"spm-card-control"},k0={class:"spm-control-header"},w0={class:"spm-control-title-group"},x0={class:"spm-control-title"},S0={class:"spm-card-control"},C0={class:"spm-control-header"},_0={class:"spm-control-title-group"},$0={class:"spm-control-title"},I0=["aria-label"],T0=["checked"],E0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},M0=["value"],A0={class:"spm-card-control"},B0={class:"spm-control-header"},D0={class:"spm-control-title-group"},L0={class:"spm-control-title"},P0=["aria-label"],O0=["checked"],R0={class:"spm-card-control"},N0={class:"spm-action-grid"},z0=["disabled"],H0=["disabled","aria-label"],F0=Et({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=Ot("plugin"),i=yi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Pi({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Pi({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Pi({webServeUrl:a})}function r(a){Pi({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(X(),te("div",i0,[c[42]||(c[42]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",n0,[f("div",s0,[f("div",o0,[f("div",r0,[le(ue,{name:"palette"}),c[20]||(c[20]=f("span",null,"幻灯片主题 (Theme)",-1))]),c[21]||(c[21]=f("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),f("div",l0,[(X(),te(Ge,null,kt(n,d=>f("button",{key:d.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},xe(d.label),11,a0)),64))])]),f("div",c0,[f("div",d0,[f("div",u0,[f("div",f0,[le(ue,{name:"ratio"}),c[22]||(c[22]=f("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[23]||(c[23]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",p0,[f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",h0,[f("div",m0,[f("div",g0,[f("div",v0,[le(ue,{name:"ratio"}),c[24]||(c[24]=f("span",null,"间距风格 (Spacing)",-1))]),c[25]||(c[25]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",b0,[f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),f("div",y0,[f("div",k0,[f("div",w0,[f("div",x0,[le(ue,{name:"transition"}),c[26]||(c[26]=f("span",null,"全局默认转场",-1))]),c[27]||(c[27]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),le(Qa,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),f("div",S0,[f("div",C0,[f("div",_0,[f("div",$0,[le(ue,{name:"external-link"}),c[28]||(c[28]=f("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[29]||(c[29]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,T0),c[30]||(c[30]=f("span",{class:"spm-switch-slider"},null,-1))],8,I0)]),he(i).enableWebServeJump?(X(),te("div",E0,[f("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Kt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Kt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,M0),c[31]||(c[31]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ie("",!0)]),f("div",A0,[f("div",B0,[f("div",D0,[f("div",L0,[le(ue,{name:"type"}),c[32]||(c[32]=f("span",null,"固定特定标题大小",-1))]),c[33]||(c[33]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,O0),c[34]||(c[34]=f("span",{class:"spm-switch-slider"},null,-1))],8,P0)])]),f("div",R0,[c[41]||(c[41]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",N0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[le(ue,{name:"split-preview"}),c[35]||(c[35]=f("span",null,"分屏预览",-1))]),he(Ct)("presenterMode")?(X(),te("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[le(ue,{name:"presenter"}),c[36]||(c[36]=f("span",null,"演讲者视图",-1))])):Ie("",!0),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:c[15]||(c[15]=d=>a.$emit("identifyNotes"))},[le(ue,{name:"notes"}),c[37]||(c[37]=f("span",null,"识别讲稿块",-1))],8,z0),he(Ct)("aiScript")?(X(),te("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[16]||(c[16]=d=>a.$emit("aiAutoSplit"))},[le(ue,{name:"sparkles"}),c[38]||(c[38]=f("span",null,"AI 智能分页",-1))])):Ie("",!0),he(Ct)("exportHtml")?(X(),te("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[17]||(c[17]=d=>a.$emit("exportHtml"))},[le(ue,{name:"export-html"}),c[39]||(c[39]=f("span",null,"导出 HTML",-1))])):Ie("",!0),he(Ct)("exportPdf")?(X(),te("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[18]||(c[18]=d=>a.$emit("exportPdf"))},[le(ue,{name:"export-pdf"}),c[40]||(c[40]=f("span",null,"导出 PDF",-1))])):Ie("",!0),he(Ct)("exportImage")?(X(),te("button",{key:4,class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:c[19]||(c[19]=d=>a.$emit("exportImages"))},[le(ue,{name:"export-image"}),f("span",null,xe(e.isExportingImages?"正在导出...":"导出图片"),1)],10,H0)):Ie("",!0)])])]))}}),j0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,W0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function U0(e){const t=await Ga.loadAsync(e),i={},n=[];let s="",o="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||W0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(j0.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:h})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function V0(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],l=i(o);l&&(s.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function ec(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function G0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[v,m]of Object.entries(a))if(v.endsWith(`/${r}`)||u&&v.endsWith(`/${u}`)){c=m;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const v=require("path");u.push(v.resolve(t.baseDir,r)),u.push(v.resolve(t.baseDir,o))}catch{}try{const v=require("path");u.push(v.resolve(process.cwd(),r))}catch{}for(const v of u){const m=ec(v);if(m!==null){c=m;break}}}if(!c){const u=Oa||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const v=r.split("/").pop();for(const[m,b]of Object.entries(u))if(m.endsWith(`/${r}`)||v&&m.endsWith(`/${v}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),v=c.match(u);if(v){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(m?m[1]:"")+v[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function K0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),v=u?u[1].length:0;if(d===-1&&(d=v),v<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=K0(a),!a){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const h=i[c],u=h.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const v=h.match(/^(\s+)/),m=v?v[1].length:0;if(p===-1)if(m>0)p=m;else break;if(m<p)break;d.push(h.slice(p)),c++}if(d.length>0){t[r]=gs(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const q0=/^\s*```ya?ml([\s\S]*?)```/;function cl(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(q0);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=gs(l.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function Y0(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(l=p)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=Y0(d),h={};let u="",v="",m=0;if(p.length>0){const P=p[0],q=cl(P),_=Object.keys(q.frontmatter).length>0,H=q.content.length>0;_&&!H&&p.length>1?(m=1,b(q.frontmatter)):_&&b(q.frontmatter)}function b(P){u=P.title||"",P.theme&&(h[On]=String(P.theme)),P.aspectRatio&&(h[Rn]=String(P.aspectRatio)),P.highlighter&&(h[bl]=String(P.highlighter)),P.transition&&(h[Nn]=String(P.transition)),P.colorSchema&&(h[yl]=String(P.colorSchema)),P.layout&&(h[we]=String(P.layout)),P.background&&(h[it]=String(P.background)),P.image&&(h[Lt]=String(P.image)),P.class&&(h[Xi]=String(P.class));for(const[q,_]of Object.entries(P))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(q)||(h[`custom-slides-${q}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let C=0,S=0,x=0,$=0;const T=new Set,w={};let R=1;for(let P=m;P<p.length;P++){const q=p[P],{frontmatter:_,content:H}=cl(q),k=q.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),M=_.src||(k?k[1]:void 0);if(M){const fe=String(M).trim().replace(/^['"]|['"]$/g,"");let Z=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!Z){const L=fe.replace(/^\.\//,""),V=[];if(t.baseDir)try{const g=require("path");V.push(g.resolve(t.baseDir,L)),V.push(g.resolve(t.baseDir,fe))}catch{}try{const g=require("path");V.push(g.resolve(process.cwd(),L)),V.push(g.resolve(process.cwd(),fe))}catch{}for(const g of V){const G=ec(g);if(G!==null){Z=G;break}}}const pe={};_.layout&&(pe[we]=String(_.layout)),_.transition&&(pe[pt]=String(_.transition)),_.background&&(pe[it]=String(_.background)),_.image&&(pe[Lt]=String(_.image)),_.class&&(pe[Xi]=String(_.class));for(const[L,V]of Object.entries(_))["src","layout","transition","background","image","class"].includes(L)||(pe[`custom-slides-${L}`]=typeof V=="object"?JSON.stringify(V):String(V));if(Z){const L=vs(Z,{...t,virtualFiles:c});for(const V of L.slides){V.pageIndex=R++,V.pageAttrs={...pe,...V.pageAttrs},y.push(V);const g=V.pageAttrs[we]||"default";w[g]=(w[g]||0)+1}continue}else{y.push({pageIndex:R++,pageAttrs:{...pe,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=pe[we]||"default";w[L]=(w[L]||0)+1;continue}}const j={};_.layout&&(j[we]=String(_.layout)),_.transition&&(j[pt]=String(_.transition)),_.background&&(j[it]=String(_.background)),_.image&&(j[Lt]=String(_.image)),_.class&&(j[Xi]=String(_.class)),_.mask&&(j[Qi]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(j[Ri]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(j[en]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(j[tn]=String(_.maskInitial||_["mask-initial"]));for(const[fe,Z]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(j[`custom-slides-${fe}`]=typeof Z=="object"?JSON.stringify(Z):String(Z));let A=H;const D=[];let N=A.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const Z=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(fe),Z});N=N.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const Z=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(fe),Z});let ee="";const W=Array.from(N.matchAll(/<!--([\s\S]*?)-->/g));if(W.length>0){const fe=W[W.length-1],Z=N.slice(fe.index+fe[0].length).trim();if(!Z||!Z.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=fe[1].trim();L.startsWith("TODO:")||(ee=L,C++),i&&(N=N.slice(0,fe.index).trimEnd()+N.slice(fe.index+fe[0].length))}}i&&(N=N.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<D.length;fe++)N=N.replace(`__CODE_TOKEN_NOTE_${fe}__`,D[fe]);if(A=N,ee){for(let pe=0;pe<D.length;pe++)ee=ee.replace(`__CODE_TOKEN_NOTE_${pe}__`,D[pe]);const Z=`> [!NOTE] 💡 演讲备注
${ee.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slides-note="true"}`;A=A?`${A}

${Z}`:Z}let K=!1;if(/<style\b/i.test(A)){K=!0;const fe=A.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const Z of fe){const pe=Z.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();v=v?`${v}

${pe}`:pe}l&&(A=A.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const re=A.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);re&&(S+=re.length);const ae=A.match(/```\w+\s+\{[^}]+\}/g);ae&&(x+=ae.length);const de=A.match(/::\w+::|<template\s+#[^>]+>/g);if(de&&($+=de.length),A=A.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>G0(fe,{...t,virtualFiles:c})||fe),n&&(A=A.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(A=A.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),A=A.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(A=A.replace(/^::\w+::\s*$/gm,"")),r&&(A=Yf(A)),a){let fe=A.trim(),Z="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(Z=fe.slice(pe),fe=fe.slice(0,pe).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const L=String(_.image).trim(),V=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${L})
{: custom-slides-layout="${V}" }`;_.layout==="image-left"?fe=`{{{col

${g}

${fe}

}}}`:fe=`{{{col

${fe}

${g}

}}}`}if(_.background){const V=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${V}

${fe}`:V}A=Z?`${fe}

${Z}`:fe}const ve=Z0(A);j[it]&&ve.push(j[it]),j[Lt]&&ve.push(j[Lt]);for(const fe of ve)T.add(fe);const Ee=/<[A-Z][a-zA-Z0-9]+/.test(A),Se=j[we]||(R===1?h[we]||"cover":"default");w[Se]=(w[Se]||0)+1,y.push({pageIndex:R++,pageAttrs:j,notes:ee,rawMarkdown:A,hasVueComponent:Ee,hasStyleTag:K,assetReferences:ve})}if(!u&&y.length>0){const P=y[0].rawMarkdown.match(/^#\s+(.+)$/m);P&&(u=P[1].trim())}v&&(h["custom-slides-custom-css"]=v);let F=y.map(P=>`---

${P.rawMarkdown}`).join(`

`);return F.trimStart().startsWith("---")||(F=`---

${F.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:h,slides:y,totalSlides:y.length,stats:{totalNotes:C,totalVClicks:S,totalShikiHighlights:x,totalSlots:$,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:F,customCss:v}}function Z0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function tc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function J0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function X0(e,t,i=Fe){const n=e.filter(tc);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const l=t[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const l=t[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}return s}async function Q0(e,t=Fe){let i=!1,n=0;for(const s of e){if(tc(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[$e]:"right"}).catch(()=>{}),n++)}return n}async function ek(e,t,i=hl){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&V0(e,n),n}async function tk(e){var x;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||hl,d=a.createDocFn||id,p=a.setAttrsFn||Fe,h=a.getChildBlocksFn||Yn,u=a.openTabFn||ce.openTab,v=a.showMessageFn||ce.showMessage;o&&s.length>0&&await ek(t,s,c);const m=J0(n),b=`/${m}`,y=await d(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const C=((x=t.slides[0])==null?void 0:x.pageAttrs)||{};await p(y,{...C,...t.docRootAttrs});const S=await h(y).catch(()=>[]);return Array.isArray(S)&&S.length>0&&(await X0(S,t.slides,p),await Q0(S,p)),v(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function ik(e){const t=ge("file"),i=ge(!1),n=ge(!1),s=ge(""),o=ge(null),l=ge(null),r=ge(""),a=ge(0),c=ge(""),d=ge([]),p=ge(null),h=ge(""),u=ge([]),v=ge(""),m=ge(!0),b=ge(!0),y=ge(!0),C=ge(!0),S=ye(()=>{const j=a.value;if(j===0)return"0 B";const A=1024,D=["B","KB","MB","GB"],N=Math.floor(Math.log(j)/Math.log(A));return`${(j/A**N).toFixed(1)} ${D[N]}`}),x=ye(()=>{var j;return((j=p.value)==null?void 0:j.docRootAttrs["custom-slides-theme"])||"default"}),$=ye(()=>{var j;return d.value.length>0?d.value.length:((j=p.value)==null?void 0:j.stats.discoveredAssets.length)||0}),T=ye(()=>{var A;const j=((A=p.value)==null?void 0:A.stats.layoutDistribution)||{};return Object.entries(j).map(([D,N])=>({name:D,count:N}))});async function w(j=td){try{const A=await j();A!=null&&A.notebooks&&Array.isArray(A.notebooks)&&(u.value=A.notebooks.filter(D=>!D.closed),u.value.length>0&&!v.value&&(v.value=u.value[0].id))}catch(A){console.warn("获取笔记本列表失败:",A)}}function R(){var j;(j=o.value)==null||j.click()}function F(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],s.value=""}async function P(j){s.value="",l.value=j,r.value=j.name,a.value=j.size;try{if(j.name.toLowerCase().endsWith(".zip")){const D=await j.arrayBuffer(),N=await U0(D);if(!N.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=N.assets;const ee=vs(N.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:N.virtualFiles});p.value=ee,h.value=ee.docTitle||j.name.replace(/\.zip$/i,"")}else{const D=await j.text();d.value=[];const N=j.path||"",ee=N?N.replace(/[\\/][^\\/]+$/,""):"",W=vs(D,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:ee||void 0});p.value=W,h.value=W.docTitle||j.name.replace(/\.md$/i,"")}}catch(A){console.error("解析文件失败:",A),s.value=`解析文件失败: ${A.message||String(A)}`}}function q(){if(s.value="",!c.value.trim()){p.value=null;return}try{const j=vs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});p.value=j,h.value=j.docTitle||"Slidev 演示文稿"}catch(j){s.value=`解析 Markdown 源码失败: ${j.message||String(j)}`}}async function _(){l.value?await P(l.value):c.value&&q()}async function H(j){const A=j.target;A.files&&A.files[0]&&await P(A.files[0])}async function k(j){var A;i.value=!1,(A=j.dataTransfer)!=null&&A.files&&j.dataTransfer.files[0]&&await P(j.dataTransfer.files[0])}async function M(j=e){if(p.value){if(!v.value&&u.value.length>0&&(v.value=u.value[0].id),!v.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await tk({presentation:p.value,notebookId:v.value,docTitle:h.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:C.value,plugin:j})}catch(A){console.error("导入 Slidev 演示失败:",A),s.value=`导入执行失败: ${A.message||String(A)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:h,notebooks:u,selectedNotebookId:v,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:C,formattedFileSize:S,currentTheme:x,extractedAssetsCount:$,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:F,processFile:P,onFileSelected:H,onFileDrop:k,onTextChange:q,reprocessCurrentInput:_,handleConfirmImport:M}}const nk={class:"spm-import-dialog"},sk={class:"spm-tabs-header"},ok={class:"spm-dialog-body"},rk={key:0,class:"spm-file-section"},lk={key:0,class:"spm-dropzone-prompt"},ak={class:"spm-dropzone-icon"},ck={key:1,class:"spm-dropzone-active"},dk={class:"spm-file-badge"},uk={class:"spm-file-size"},fk={key:1,class:"spm-text-section"},pk={key:2,class:"spm-error-banner"},hk={key:3,class:"spm-preview-card"},mk={class:"spm-preview-card__header"},gk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},vk={class:"spm-config-grid"},bk={class:"spm-form-item"},yk={class:"spm-form-item"},kk=["value"],wk={class:"spm-stats-grid"},xk={class:"spm-stat-box"},Sk={class:"spm-stat-value"},Ck={class:"spm-stat-box"},_k={class:"spm-stat-value"},$k={class:"spm-stat-box"},Ik={class:"spm-stat-value"},Tk={class:"spm-stat-box"},Ek={class:"spm-stat-value"},Mk={key:0,class:"spm-chips-row"},Ak={class:"spm-options-group"},Bk={class:"spm-checkbox-label"},Dk={class:"spm-checkbox-label"},Lk={class:"spm-checkbox-label"},Pk={class:"spm-checkbox-label"},Ok={class:"spm-dialog-footer"},Rk=["disabled"],Nk=["disabled"],zk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Hk={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Fk=Et({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Ot("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:h,customDocTitle:u,notebooks:v,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:C,optAutoPreview:S,formattedFileSize:x,currentTheme:$,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:F,onFileSelected:P,onFileDrop:q,onTextChange:_,reprocessCurrentInput:H,handleConfirmImport:k}=ik(n);mn(async()=>{await w()});async function M(){const A=await k();A&&(i("success",{docId:A}),i("close"))}function j(){i("close")}return(A,D)=>(X(),te("div",{class:"spm-modal-overlay",onClick:Kt(j,["self"])},[f("div",nk,[f("div",{class:"spm-dialog-header"},[D[18]||(D[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlides"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),f("div",sk,[f("button",{class:Ce(["spm-tab-btn",{active:he(s)==="file"}]),onClick:D[0]||(D[0]=N=>s.value="file")},[le(ue,{name:"package"}),D[19]||(D[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:Ce(["spm-tab-btn",{active:he(s)==="text"}]),onClick:D[1]||(D[1]=N=>s.value="text")},[le(ue,{name:"notes"}),D[20]||(D[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",ok,[he(s)==="file"?(X(),te("div",rk,[f("div",{class:Ce(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:D[4]||(D[4]=Kt(N=>o.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Kt(N=>o.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Kt((...N)=>he(q)&&he(q)(...N),["prevent"])),onClick:D[7]||(D[7]=(...N)=>he(R)&&he(R)(...N))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...N)=>he(P)&&he(P)(...N))},null,544),he(c)?(X(),te("div",ck,[f("span",dk,[le(ue,{name:"notes"}),St(" "+xe(he(c)),1)]),f("span",uk,"("+xe(he(x))+")",1),f("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Kt((...N)=>he(F)&&he(F)(...N),["stop"]))},"更换文件")])):(X(),te("div",lk,[f("span",ak,[le(ue,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=f("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(X(),te("div",fk,[Dt(f("textarea",{"onUpdate:modelValue":D[8]||(D[8]=N=>Je(d)?d.value=N:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...N)=>he(_)&&he(_)(...N))},null,544),[[Lo,he(d)]])])),he(r)?(X(),te("div",pk," ⚠️ "+xe(he(r)),1)):Ie("",!0),he(h)?(X(),te("div",hk,[f("div",mk,[f("span",gk,[le(ue,{name:"sparkles"}),D[23]||(D[23]=St(" 演示解析摘要",-1))]),D[24]||(D[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",vk,[f("div",bk,[D[25]||(D[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Dt(f("input",{"onUpdate:modelValue":D[10]||(D[10]=N=>Je(u)?u.value=N:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Lo,he(u)]])]),f("div",yk,[D[26]||(D[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Dt(f("select",{"onUpdate:modelValue":D[11]||(D[11]=N=>Je(m)?m.value=N:null),class:"spm-select"},[(X(!0),te(Ge,null,kt(he(v),N=>(X(),te("option",{key:N.id,value:N.id},xe(N.name),9,kk))),128))],512),[[Ef,he(m)]])])]),f("div",wk,[f("div",xk,[f("span",Sk,xe(he(h).totalSlides),1),D[27]||(D[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",Ck,[f("span",_k,xe(he($)),1),D[28]||(D[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",$k,[f("span",Ik,xe(he(h).stats.totalNotes),1),D[29]||(D[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",Tk,[f("span",Ek,xe(he(p)),1),D[30]||(D[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(T).length>0?(X(),te("div",Mk,[D[31]||(D[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(X(!0),te(Ge,null,kt(he(T),N=>(X(),te("span",{key:N.name,class:"spm-chip-badge"},xe(N.name)+": "+xe(N.count),1))),128))])):Ie("",!0),f("div",Ak,[f("label",Bk,[Dt(f("input",{"onUpdate:modelValue":D[12]||(D[12]=N=>Je(b)?b.value=N:null),type:"checkbox",onChange:D[13]||(D[13]=(...N)=>he(H)&&he(H)(...N))},null,544),[[ls,he(b)]]),D[32]||(D[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",Dk,[Dt(f("input",{"onUpdate:modelValue":D[14]||(D[14]=N=>Je(y)?y.value=N:null),type:"checkbox",onChange:D[15]||(D[15]=(...N)=>he(H)&&he(H)(...N))},null,544),[[ls,he(y)]]),D[33]||(D[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",Lk,[Dt(f("input",{"onUpdate:modelValue":D[16]||(D[16]=N=>Je(C)?C.value=N:null),type:"checkbox"},null,512),[[ls,he(C)]]),D[34]||(D[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",Pk,[Dt(f("input",{"onUpdate:modelValue":D[17]||(D[17]=N=>Je(S)?S.value=N:null),type:"checkbox"},null,512),[[ls,he(S)]]),D[35]||(D[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ie("",!0)]),f("div",Ok,[f("button",{class:"spm-btn-secondary",disabled:he(l),onClick:j}," 取消 ",8,Rk),f("button",{class:"spm-btn-primary",disabled:!he(h)||he(l),onClick:M},[he(l)?(X(),te("span",zk,[le(ue,{name:"refresh"}),D[36]||(D[36]=St(" 正在导入生成中...",-1))])):(X(),te("span",Hk,[le(ue,{name:"rocket"}),D[37]||(D[37]=St(" 确认导入思源笔记",-1))]))],8,Nk)])])]))}}),jk=Xt(Fk,[["__scopeId","data-v-c56a3d7e"]]);function hr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Wk(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(hr(o)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(s){let a=e.find(c=>c.startBlockId===s);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===s}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var p,h;return((p=d.blocks)==null?void 0:p.some(u=>u.id===i))||((h=d.allBlockIds)==null?void 0:h.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var p,h;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((h=d.allBlockIds)==null?void 0:h.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(h=>h.id===i||h.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[$e];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,h;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((h=d.blocks)==null?void 0:h.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function Uk(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${we}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(we),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ye),n.removeAttribute("custom-slides-role");return}const o=e.get(s),l=(o==null?void 0:o[we])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(we)||n.getAttribute("custom-slides-layout");r&&r!==l&&(l?n.setAttribute(we,l):(n.removeAttribute(we),n.removeAttribute("custom-slides-layout")));const a=(o==null?void 0:o[Ye])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ye)||n.getAttribute("custom-slides-role");c&&c!==a&&(a?n.setAttribute(Ye,a):(n.removeAttribute(Ye),n.removeAttribute("custom-slides-role")))})}function Vk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function Gk(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[v,m]of Object.entries(c))e.activeBlockAttrs.value[v]=m;Pe.setBlockAttrOverride(d,c),et(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,h=!!(p&&Vk(d,p));if(Ze in c&&h&&p){const v=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=v),Pe.setBlockAttrOverride(p,{[Ze]:v}),et(p,{[Ze]:v}),Fe(p,{[Ze]:v}).catch(()=>{})}if(we in c){const v=c[we];e.currentPageDividerLayout.value=v,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=v)}if(yt in c){const v=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=v)}i("保存中...");try{await Fe(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=o();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Pe.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),c===we&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Fe(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=o();if(!p)return;const h={[we]:c,[yt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[we]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(p,h),et(p,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Fe(p,h),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var h;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Pe.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),(h=e.latestDoc.value)!=null&&h.config&&(c===On&&(e.latestDoc.value.config.theme=d),c===Rn&&(e.latestDoc.value.config.aspectRatio=d),c===Nn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await Fe(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function dl(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function ic(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:dl(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:dl(e),isAiGenerated:!1}}async function Kk(e,t){return(await ic(e,t)).notes}function qk(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Yk(e,t){if(!((t==null?void 0:t[Ke])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function Zk(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||Yn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(Kn({...r,ial:{...r.ial||{},...Pe.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const l=[];for(let r=0;r<s.length;r++){const a=s[r];if(!a||a.length===0)continue;let c=null;for(let v=a.length-1;v>=0;v--){const m=a[v];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!qk(c))continue;const d=Pe.getBlockAttrOverride(c.id)||{};let p={...c.ial||{},...d};if(!p[Ke]&&!p["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const v=await t.getBlockAttrsFn(c.id).catch(()=>({}));p={...p,...v,...d}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const v=await t.getBlockKramdownFn(c.id);v!=null&&v.kramdown&&(h=v.kramdown)}catch{}if(Yk(h,p))continue;const u=dr(h)||h.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:u||"在此输入本页讲稿提词..."})}return l}async function Jk(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||yo,s=(i==null?void 0:i.setBlockAttrsFn)||Fe,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${Ke}="true"}`;await n("markdown",r,e),await s(e,{[Ke]:"true"}),Pe.setBlockAttrOverride(e,{[Ke]:"true"}),o(e,{[Ke]:"true"})}async function nc(e,t){const i=(t==null?void 0:t.showMessageFn)||ce.showMessage,n=(t==null?void 0:t.confirmFn)||ce.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await Zk(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(l=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,a=0;for(const d of s)try{await Jk(d.id,d.cleanContent,t),r++}catch(p){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${d.id} 失败:`,p),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:o,matchedCount:o,successCount:r,errorCount:a})},()=>{l({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function Xk(e,t){const i=ge(!1),{triggerSaveNotice:n}=t;async function s(h){var $,T,w,R,F,P,q,_;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slides-note="true"}`,b=(($=e.latestDoc.value)==null?void 0:$.slides)||[],y=e.targetSlide.value,C=y?b.findIndex(H=>H===y):-1;let S=null;if(C!==-1&&C<b.length-1){const H=b[C+1];S=await Li("markdown",m,H.startBlockId)}else{const H=((T=y==null?void 0:y.noteBlocks)==null?void 0:T.slice(-1)[0])||((w=y==null?void 0:y.blocks)==null?void 0:w.slice(-1)[0]),k=(H==null?void 0:H.id)||(y==null?void 0:y.startBlockId);k?S=await Li("markdown",m,void 0,k):S=await bo("markdown",m,e.currentDocId.value)}const x=((P=(F=(R=S==null?void 0:S[0])==null?void 0:R.doOperations)==null?void 0:F[0])==null?void 0:P.id)||((q=S==null?void 0:S[0])==null?void 0:q.id);return x&&(await Fe(x,{[Ke]:"true"}),Pe.setBlockAttrOverride(x,{[Ke]:"true"}),Fi(x,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),x}async function o(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){n("取消中...");try{await Fe(h,{[Ke]:"","slides-note":""}),Pe.setBlockAttrOverride(h,{[Ke]:"","slides-note":""}),et(h,{[Ke]:"","slides-note":""}),delete e.activeBlockAttrs.value[Ke],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ce.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(u){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",u),n("取消失败"),ce.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let u=e.rawSnippet.value;try{const y=await nd(h);y!=null&&y.kramdown&&(u=y.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(dr(u)||u.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,h),await Fe(h,{[Ke]:"true"}),Pe.setBlockAttrOverride(h,{[Ke]:"true"}),et(h,{[Ke]:"true"}),e.activeBlockAttrs.value[Ke]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ce.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(u){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",u),n("设置失败"),ce.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await s(),ce.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){ce.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var v;const h=e.currentSlideNoteBlockId.value;if(!h){ce.showMessage("未找到本页关联的讲稿备注块");return}Fi(h,(v=e.plugin)==null?void 0:v.app)?ce.showMessage("已在编辑区定位讲稿备注块"):ce.showMessage("定位讲稿备注块失败")}async function a(){var v;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ce.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const u=await ic(h,gl);if(u.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${u.notes.split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,m),await Fe(m,{[Ke]:"true"}),Pe.setBlockAttrOverride(m,{[Ke]:"true"}),Fi(m,(v=e.plugin)==null?void 0:v.app)}else await s(u.notes);u.isAiGenerated?ce.showMessage("思源 AI 演讲提词卡生成成功！"):ce.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){ce.showMessage("当前文档无幻灯片页面");return}const u=h.map((b,y)=>({slide:b,idx:y})).filter(({slide:b})=>{var S;const y=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,C=!!((S=b.notes)!=null&&S.trim());return!y&&!C});if(u.length===0){ce.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const v=u.length;ce.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${v} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var y,C,S,x,$,T;if(i.value)return;i.value=!0,ce.showMessage("正在批量追加讲稿块...");let b=0;try{const F=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(P=>`> ${P}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:P,idx:q}of u)try{let _=null;if(q<h.length-1){const k=h[q+1];_=await Li("markdown",F,k.startBlockId)}else{const k=((y=P==null?void 0:P.noteBlocks)==null?void 0:y.slice(-1)[0])||((C=P==null?void 0:P.blocks)==null?void 0:C.slice(-1)[0]),M=(k==null?void 0:k.id)||(P==null?void 0:P.startBlockId);M?_=await Li("markdown",F,void 0,M):_=await bo("markdown",F,e.currentDocId.value)}const H=(($=(x=(S=_==null?void 0:_[0])==null?void 0:S.doOperations)==null?void 0:x[0])==null?void 0:$.id)||((T=_==null?void 0:_[0])==null?void 0:T.id);H&&(await Fe(H,{[Ke]:"true"}),Pe.setBlockAttrOverride(H,{[Ke]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${q+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ce.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",w),ce.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var b;if(i.value)return;const h=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(h.length===0){ce.showMessage("当前文档无幻灯片页面");return}const u=[];for(const y of h)if(y.noteBlocks&&y.noteBlocks.length>0)for(const C of y.noteBlocks)C.id&&u.push({id:C.id,pageIndex:y.pageIndex});if(u.length===0){ce.showMessage("当前文档中没有讲稿备注块，无需删除");return}const v=new Set(u.map(y=>y.pageIndex)).size,m=u.length;ce.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${v} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ce.showMessage("正在批量删除讲稿块...");let y=0;try{for(const C of u)try{await ml(C.id),Pe.clearBlockAttrOverride(C.id),y++}catch(S){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${C.id} 失败:`,S)}e.activeBlockId.value&&u.some(C=>C.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ke],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ce.showMessage(`已成功删除全部 ${y} 个讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",C),ce.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function p(){var u;const h=e.currentDocId.value||((u=e.plugin)==null?void 0:u.currentDocId);if(!h){ce.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ce.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await nc(h,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d,onIdentifyNotesBlocks:p}}function Qk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Di]:"true",[Ji]:"true"}),e.activeBlockAttrs.value[Di]="true",e.activeBlockAttrs.value[Ji]="true"):(await i(Di,"false"),e.activeBlockAttrs.value[Di]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(ws,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Ji,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(xs,w)}async function c(w){var _;const R=e.activeBlockId.value;if(!R)return;const F=e.rawSnippet.value||"",P=Si(F)||"",q=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const H={[Ye]:"background",[we]:""};q&&P&&(e.pageBackground.value=P,await Fe(q,{[it]:P}).catch(()=>{}),Pe.setBlockAttrOverride(q,{[it]:P}),et(q,{[it]:P}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=P)),await n(H)}else(w===Ss||w===Cs)&&await n({[we]:w,[Ye]:""});else{const H={[Ye]:"",[we]:""};if(e.activeBlockAttrs.value[it]==="true"&&(H[it]=""),q&&P&&e.pageBackground.value===P&&(e.pageBackground.value="",await Fe(q,{[it]:""}).catch(()=>{}),Pe.setBlockAttrOverride(q,{[it]:""}),et(q,{[it]:""}),(_=e.targetSlide.value)!=null&&_.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(H),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${R}"]`),M=k==null?void 0:k.closest('[data-type="NodeListItem"]'),j=M==null?void 0:M.getAttribute("data-node-id");if(j&&j!==R){const A={[we]:"",[Ye]:""};et(j,A),Pe.setBlockAttrOverride(j,A),await Fe(j,A).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function p(w){i(Ze,w)}function h(w){i(Yt,w)}function u(w){(e.activeBlockAttrs.value[$e]||"")===w?i($e,""):i($e,w)}function v(w){e.elemShikiLines.value=w,i(Wi,w)}function m(w){e.elemMaxHeight.value=w,i(zn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i($e,w?"col-1":"left"),ce.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const R={[Ze]:"",[Yt]:"",[$e]:"",[Wi]:"",[zn]:"",[Ke]:"","slides-note":"",[we]:"",[yt]:"",[Ye]:"",[pt]:"",[it]:"",[Lt]:"",[Di]:"",[ws]:"",[Ji]:"",[xs]:""};if(et(w,R),await Fe(w,R),Pe.clearBlockAttrOverride(w),typeof document<"u"){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),P=F==null?void 0:F.closest('[data-type="NodeListItem"]'),q=P==null?void 0:P.getAttribute("data-node-id");q&&q!==w&&(et(q,R),await Fe(q,R).catch(()=>{}),Pe.clearBlockAttrOverride(q))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",ce.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function C(){if(e.activeBlockId.value)try{await Li("markdown","---",e.activeBlockId.value,void 0),ce.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("插入分页符失败")}}async function S(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Li("markdown","---",void 0,w),ce.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("插入分页符失败")}}async function x(){if(e.activeBlockId.value)try{await ml(e.activeBlockId.value),ce.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("删除失败")}}async function $(){var w,R;try{let F=null;if(typeof document<"u"){const q=e.activeBlockId.value;if(q){const _=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`);_&&(F=_.getAttribute("data-type")==="NodeSuperBlock"?_:_.closest('[data-type="NodeSuperBlock"]'))}if(!F){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(_){const H=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(H){let k=H.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const M=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(M){F=M;break}k=k.nextElementSibling}}}else{const H=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of k)if(!H||M.compareDocumentPosition(H)&Node.DOCUMENT_POSITION_FOLLOWING){F=M;break}}}}const P=[];if(F){const q=Array.from(F.querySelectorAll(":scope > [data-node-id]"));for(const _ of q){const H=_.getAttribute("data-node-id");H&&(P.push(H),_.removeAttribute("style"))}}else if((R=e.targetSlide.value)!=null&&R.blocks){for(const q of e.targetSlide.value.blocks)if(q.children&&q.children.length>=2){for(const _ of q.children)_.id&&P.push(_.id);break}}if(P.length>0)for(const q of P)await Fe(q,{style:""}).catch(()=>{});await s(yt,""),ce.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(F){console.error("[layout-actions] resetSuperBlockWidth error:",F),ce.showMessage("重置超级块比例失败")}}async function T(){var w,R,F;try{let P=null;if(typeof document<"u"){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),H=e.activeBlockId.value;let k=[];if(_){const A=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(A){let D=A.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(D),D=D.nextElementSibling}}else{const A=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const N of D)if(!A||N.compareDocumentPosition(A)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(N);else break}const M=[];let j;for(const A of k){const D=A.getAttribute("data-type");D==="NodeHeading"&&(j=A.getAttribute("data-node-id")||void 0);const N=[];D==="NodeSuperBlock"?N.push(A):N.push(...Array.from(A.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const ee of N){if((ee.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const K=ee.getAttribute("data-node-id")||"";let re=[];const ae=Array.from(ee.querySelectorAll('[data-type="NodeListItem"]'));if(ae.length===4&&(re=ae.map(de=>de.getAttribute("data-node-id")).filter(Boolean)),re.length!==4){const de=Array.from(ee.querySelectorAll(":scope > [data-node-id]"));de.length===4&&(re=de.map(ve=>ve.getAttribute("data-node-id")).filter(Boolean))}re.length===4&&M.push({sbId:K,itemIds:re,headerId:j})}}M.length>0&&(H&&(P=M.find(A=>{if(A.sbId===H||A.itemIds.includes(H))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${A.sbId}"]`),N=document.querySelector(`.protyle-wysiwyg [data-node-id="${H}"]`);return!!(D&&N&&D.contains(N))})||null),P||(P=M[0]))}if(!P&&((R=e.targetSlide.value)!=null&&R.blocks)){const _=e.targetSlide.value,H=[];for(const M of _.blocks)M.rawNode?H.push(M.rawNode):H.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const k=Vf(H,e.activeBlockId.value);k&&k.items.length===4&&(P={sbId:k.superBlockNode.id,itemIds:k.items.map(M=>M.id),headerId:(F=k.headerNode)==null?void 0:F.id})}const q=e.currentPageDividerId.value||e.currentDocId.value;if(q&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(q,{[we]:"clover"}),et(q,{[we]:"clover"}),await Fe(q,{[we]:"clover"}).catch(()=>{})),P&&P.itemIds.length>0){P.headerId&&(Pe.setBlockAttrOverride(P.headerId,{[$e]:"header"}),et(P.headerId,{[$e]:"header"}),await Fe(P.headerId,{[$e]:"header"}).catch(()=>{}));const _=Math.min(4,P.itemIds.length);for(let H=0;H<_;H++){const k=P.itemIds[H],M=`col-${H+1}`;Pe.setBlockAttrOverride(k,{[$e]:M}),et(k,{[$e]:M}),await Fe(k,{[$e]:M}).catch(()=>{})}}return ce.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(P){return console.error("[layout-actions] applyCloverLayout error:",P),ce.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:h,onElemSlotChange:u,onElemShikiLinesChange:v,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:C,onInsertDividerAfter:S,onDeleteCurrentBlock:x,resetSuperBlockWidth:$,applyCloverLayout:T}}function ew(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l}=Gk(e),r=Xk(e,{triggerSaveNotice:t}),a=Qk(e,{saveAttr:n,saveAttrs:i,savePageAttr:s});async function c(){var y;if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}const u=e.latestDoc.value,v=await ji(u,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Wa(u);Ua(`${v}.html`,m)&&ce.showMessage(`已开始下载单文件离线 HTML 演示包 (${v}.html)`)}function d(){if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}Va(e.latestDoc.value)&&ce.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const p=ge(!1);async function h(){var u;if(p.value){ce.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}p.value=!0;try{ce.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const v=e.latestDoc.value,m=await ji(v,(u=e.currentDocId)==null?void 0:u.value,e.plugin),b=await Za(v,{title:m,onProgress:(y,C)=>{ce.showMessage(`正在导出幻灯片图片 (${y} / ${C})...`,2e3)}});b.success?ce.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ce.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{p.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,isExportingImages:p,onExportHtml:c,onExportPdf:d,onExportImages:h}}function tw(e){const t=ye(()=>hr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Pe.getBlockAttrOverride(a);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function iw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const l=e[o];if(Kn(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];Kn(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}async function sc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ce.showMessage("请先打开一篇思源笔记文档");return}const t=await Yn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ce.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=iw(i);if(n.length===0){ce.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ce.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Li("markdown","---",void 0,o.blockId),await Fe(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(l){console.warn("Failed to insert divider:",l)}ce.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const nw={class:"spm-slides-inspector"},sw={class:"spm-inspector-topbar"},ow={class:"spm-inspector-title"},rw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},lw={class:"spm-inspector-topbar-actions"},aw={class:"spm-target-banner"},cw={class:"spm-target-info"},dw=["aria-label"],uw={key:0,class:"spm-save-status"},fw=["title"],pw={class:"spm-inspector-body"},hw=Et({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=Ot("plugin"),n=ge(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ge(""),l=ge(""),r=ge({}),a=ge(""),c=ge(""),d=ge(""),p=ge(""),h=ge(""),u=ge(""),v=ge(""),m=ge(""),b=ge(null),y=ge(""),C=ge("");function S(){var be;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(Q).then(()=>{C.value="已复制！",setTimeout(()=>{C.value=""},1500)}).catch(()=>{})}const x=ye(()=>hr(l.value)),$=ye(()=>l.value==="NodeCodeBlock"),T=ge(!1),w=ye(()=>{if(T.value||Be.value)return!0;const Q=a.value||"";return!!Si(Q)}),R=ye(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const be=a.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),F=ye(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),P=ye(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),q=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(x.value)return"分页符 (---)";if(F.value)return"全局文档";if(R.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return u.value?v.value?`${v.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),H=ye(()=>x.value?"tag-divider":F.value?"tag-doc":"tag-block"),k=ye(()=>r.value[we]||"default"),M=ye(()=>r.value[pt]||"slide-left"),j=ge(""),A=ge(""),D=ye(()=>r.value[$n]||"inherit"),N=ye(()=>{var Q;return Wk((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),ee=ye(()=>{var Q;return((Q=N.value)==null?void 0:Q.notes)||""}),W=ye(()=>{var Q,be,Me;return((Me=(be=(Q=N.value)==null?void 0:Q.noteBlocks)==null?void 0:be[0])==null?void 0:Me.id)||""}),K=ye(()=>{var je,We,Oe,dt,ts,hi;if(x.value){const Qe=r.value[we]||r.value["custom-slides-layout"];if(Qe)return Qe}const Q=r.value[$e]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(h.value)return h.value;const be=p.value||(x.value?o.value:"");if(be){const Qe=Pe.getBlockAttrOverride(be);if(Qe!=null&&Qe[we])return Qe[we]}if(be&&((je=b.value)!=null&&je.slides)){const Qe=b.value.slides.find(Ki=>Ki.startBlockId===be);if((We=Qe==null?void 0:Qe.frontmatter)!=null&&We.layout)return Qe.frontmatter.layout}if((dt=(Oe=N.value)==null?void 0:Oe.frontmatter)!=null&&dt.layout)return N.value.frontmatter.layout;if((hi=(ts=N.value)==null?void 0:ts.blocks)!=null&&hi.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Me=Pe.getBlockAttrOverride(c.value);return Me!=null&&Me[we]?Me[we]:"default"}),re=tw({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),ae=re.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var Q,be;return((be=(Q=N.value)==null?void 0:Q.frontmatter)==null?void 0:be.layoutRatio)||""}}),de=re.resolvePageAttr({attrKey:Qi,fallback:()=>{var Q,be;return((be=(Q=N.value)==null?void 0:Q.frontmatter)==null?void 0:be.mask)||""}}),ve=re.resolvePageAttr({attrKey:Ri,fallback:()=>{var Q,be;return((be=(Q=N.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskRatio)||""}}),Ee=re.resolvePageAttr({attrKey:en,fallback:()=>{var Q,be;return((be=(Q=N.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskStyle)||"solid"}}),Se=re.resolvePageAttr({attrKey:tn,fallback:()=>{var Q,be;return((be=(Q=N.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Me=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Me.length<2)return null;const je=Me.length,We=Me.map(hi=>{const Qe=hi.getAttribute("style")||"",Ki=Qe.match(/calc\(\s*([\d.]+)%/);if(Ki)return parseFloat(Ki[1]);const bn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return bn?parseFloat(bn[1]):null});let Oe="",dt=!1;if(We.some(hi=>hi!==null)){dt=!0;const hi=We.reduce((Le,ut)=>Le+(ut||0),0),Qe=We.filter(Le=>Le===null).length,Ki=Qe>0?Math.max(0,100-hi)/Qe:100/Me.length,bn=We.map(Le=>Le!==null?Le:Ki),Kc=bn.reduce((Le,ut)=>Le+ut,0)||1,yn=bn.map(Le=>Le/Kc*100);if(yn.length===2){const[Le]=yn;if(Le>=48&&Le<=52)Oe="1:1";else if(Le>=31&&Le<=35)Oe="1:2";else if(Le>=65&&Le<=69)Oe="2:1";else if(Le>=28&&Le<=32)Oe="3:7";else if(Le>=68&&Le<=72)Oe="7:3";else if(Le>=38&&Le<=42)Oe="4:6";else if(Le>=58&&Le<=62)Oe="6:4";else{const ut=Math.round(Le);Oe=`${ut}:${100-ut}`}}else if(yn.length===3){const[Le,ut,mi]=yn;if(Le>=31&&Le<=35&&ut>=31&&ut<=35&&mi>=31&&mi<=35)Oe="1:1:1";else if(Le>=23&&Le<=27&&ut>=48&&ut<=52&&mi>=23&&mi<=27)Oe="1:2:1";else if(Le>=48&&Le<=52&&ut>=23&&ut<=27&&mi>=23&&mi<=27)Oe="2:1:1";else if(Le>=23&&Le<=27&&ut>=23&&ut<=27&&mi>=48&&mi<=52)Oe="1:1:2";else{const yr=Math.round(Le),kr=Math.round(ut);Oe=`${yr}:${kr}:${100-yr-kr}`}}else Oe=yn.map(Le=>Math.round(Le)).join(":")}else dt=!1,Oe=Array.from({length:je},()=>1).join(":");const ts=je>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:je,ratio:Oe,isCustomWidth:dt,recommendedLayout:ts}}function Z(Q){if(!(Q!=null&&Q.blocks))return null;for(const be of Q.blocks){const Me=be.rawNode;if(Me&&st(Me)&&Jt(Me)){const We=gn(Me).length,Oe=cr(Me);return{hasSuperBlock:!0,colCount:We,ratio:Oe||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const pe=ye(()=>{var Q;if(typeof document<"u"){const be=o.value;if(be){const je=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(je){const We=je.getAttribute("data-type")==="NodeSuperBlock"?je:je.closest('[data-type="NodeSuperBlock"]');if(We){const Oe=fe(We);if(Oe)return Oe}}}const Me=p.value||(x.value?o.value:"");if(Me){const je=document.querySelector(`.protyle-wysiwyg [data-node-id="${Me}"]`);if(je){let We=je.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(Q=We.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Oe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const dt=fe(Oe);if(dt)return dt}We=We.nextElementSibling}}}else{const je=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of We)if(!je||Oe.compareDocumentPosition(je)&Node.DOCUMENT_POSITION_FOLLOWING){const dt=fe(Oe);if(dt)return dt}}}return Z(N.value)}),L=ye(()=>{var Q;return((Q=pe.value)==null?void 0:Q.ratio)||""}),V=ye(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=ye(()=>{var Q;return((Q=N.value)==null?void 0:Q.pageIndex)||1}),G=ye(()=>!!(r.value[Ke]||r.value["slides-note"]));function U(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!Q)return!1;const be=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===o.value}const I=ye(()=>{var be;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&U())return m.value||"";if(u.value)return"";const Q=o.value;if(Q&&((be=N.value)!=null&&be.blocks)){const Me=N.value.blocks.find(je=>je.id===Q);if(Me!=null&&Me.clicks)return Me.clicks}return""}),E=ye(()=>{var be;if(r.value[Yt])return r.value[Yt];const Q=o.value;if(Q&&((be=N.value)!=null&&be.blocks)){const Me=N.value.blocks.find(je=>je.id===Q);if(Me!=null&&Me.motion)return typeof Me.motion=="string"?Me.motion:JSON.stringify(Me.motion)}return""}),O=ye(()=>{var be;if(r.value[$e])return r.value[$e];const Q=o.value;if(Q&&((be=N.value)!=null&&be.blocks)){const Me=N.value.blocks.find(je=>je.id===Q);if(Me!=null&&Me.slot)return Me.slot}return""}),Y=ge(""),B=ge(""),z=ye(()=>r.value[Di]==="true"),J=ye(()=>r.value[ws]==="true"),ne=ye(()=>r.value[Ji]==="true"),oe=ye(()=>r.value[xs]!=="false"),me=ye(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.theme)||r.value[On]||"default"}),ie=ye(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.aspectRatio)||r.value[Rn]||"16/9"}),se=ye(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.defaultTransition)||r.value[Nn]||"slide-left"}),_e=ye(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.spacing)||r.value[wo]||"normal"}),Be=ye(()=>{var We,Oe;if((r.value[Ye]||r.value["slides-role"])===kl||r.value[it]==="true")return"background";const be=r.value[we]||r.value["slides-layout"];if(be==="image-left"||be==="image-right")return be;const Me=a.value||"",je=Si(Me);if(je&&((Oe=(We=N.value)==null?void 0:We.frontmatter)!=null&&Oe.background)){const dt=N.value.frontmatter.background;if(dt===je||dt.endsWith(je)||je.endsWith(dt))return"background"}return""}),Ne=ye(()=>!!(r.value[Ze]||r.value[Yt]||r.value[$e]||r.value[Wi]||r.value[Ke]||r.value["slides-note"]||r.value[Ye]||r.value[we]||r.value[Di]||r.value[ws]||r.value[Ji]||r.value[xs])),{saveAttr:Re,savePageAttr:De,applyPageLayoutAndRatio:Qt,applyCloverLayout:ot,resetSuperBlockWidth:Xe,saveDocAttr:Ht,onToggleVideoAutoplay:Vi,onToggleVideoLoop:Ys,onToggleVideoMuted:Zs,onToggleVideoControls:es,onImageRoleChange:_i,onToggleNoteBlock:Gi,onAddNoteBlock:cc,onLocateNoteBlock:dc,onGenerateNotesWithAI:uc,isBatchProcessing:mr,onBatchAppendNotes:fc,onBatchDeleteNotes:pc,onIdentifyNotesBlocks:hc,toggleElemClick:mc,onElemClickStepChange:gc,onElemMotionChange:vc,onElemSlotChange:bc,onElemShikiLinesChange:yc,onElemMaxHeightChange:kc,onSetTwoColsContrast:wc,onClearBlockAttrs:xc,onInsertDividerBefore:Sc,onInsertDividerAfter:gr,onDeleteCurrentBlock:Cc,onExportHtml:_c,onExportPdf:$c,onExportImages:Ic,isExportingImages:Tc}=ew({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:h,parentContainerId:u,parentContainerClicks:m,latestDoc:b,targetSlide:N,currentSlideNoteBlockId:W,currentSlideLayout:K,isNoteBlock:G,elemClick:I,videoAutoplay:z,videoLoop:J,videoMuted:ne,videoControls:oe,pageBackground:j,pageImage:A,elemShikiLines:Y,elemMaxHeight:B,saveStatus:y,plugin:i});async function Ec(Q){if(Q==="clover"){if(!await ot())return}else Re(we,Q)}function Mc(Q){De(yt,Q)}async function Ac(Q){await De(Qi,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!ve.value||ve.value==="1:1")&&await De(Ri,"1:1:1:1")}function Bc(Q){De(Ri,Q)}function Dc(Q){De(en,Q)}function Lc(Q){De(tn,Q)}function vr(Q){if(!Q)return;const be=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Me=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");Qt(be,Me)}function Pc(Q){De(yt,Q)}async function Oc(){await Xe()}function Rc(Q){Re(pt,Q)}function Nc(Q){j.value=Q,Re(it,Q)}function zc(Q){A.value=Q,Re(Lt,Q)}function Hc(Q){Re($n,Q==="inherit"?"":Q)}function Fc(Q){Ht(On,Q)}function jc(Q){Ht(Rn,Q)}function Wc(Q){Ht(Nn,Q)}function Uc(Q){Ht(wo,Q)}function br(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Vc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Gc(){i&&Ct("aiScript")&&sc(i)}return t({setActiveBlock(Q){o.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,p.value=Q.pageDividerId||"",h.value=Q.pageDividerLayout||"",u.value=Q.parentContainerId||"",v.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),j.value=Q.attrs[it]||"",A.value=Q.attrs[Lt]||"",Y.value=Q.attrs[Wi]||"",B.value=Q.attrs[zn]||"",T.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,be)=>(X(),te("div",nw,[f("div",sw,[f("div",ow,[(X(),te("svg",rw,[...be[2]||(be[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=f("span",null,"演示配置",-1))]),f("div",lw,[he(Ct)("import")?(X(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Me=>n.value=!0)},[le(ue,{name:"import"}),be[4]||(be[4]=f("span",null,"导入",-1))])):Ie("",!0),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:br},[le(ue,{name:"split-preview"}),be[5]||(be[5]=f("span",null,"分屏预览",-1))])])]),f("div",aw,[f("div",cw,[f("span",{class:Ce(["spm-target-tag",H.value])},xe(_.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":C.value||"点击复制 ID: "+(o.value||c.value),onClick:S},[le(ue,{name:"copy"}),f("span",null,"#"+xe(P.value),1)],8,dw)]),y.value?(X(),te("span",uw,"● "+xe(y.value),1)):Ie("",!0)]),q.value?(X(),te("div",{key:0,class:"spm-context-quote",title:a.value},xe(q.value),9,fw)):Ie("",!0),f("div",pw,[x.value?(X(),qt(v1,{key:0,"page-layout":k.value,"page-layout-ratio":he(ae),"page-mask":he(de),"page-mask-ratio":he(ve),"page-mask-style":he(Ee),"page-mask-initial":he(Se),"detected-sb-ratio":L.value,"detected-sb-info":pe.value,"page-transition":M.value,"page-background":j.value,"page-spacing":D.value,"page-image":A.value,"page-notes":ee.value,"page-index":g.value,"onUpdate:pageLayout":Ec,"onUpdate:pageLayoutRatio":Mc,"onUpdate:pageMask":Ac,"onUpdate:pageMaskRatio":Bc,"onUpdate:pageMaskStyle":Dc,"onUpdate:pageMaskInitial":Lc,onApplySuperBlockLayout:vr,onResetSuperblockRatio:Oc,"onUpdate:pageTransition":Rc,"onUpdate:pageBackground":Nc,"onUpdate:pageSpacing":Hc,"onUpdate:pageImage":zc,onAddNoteBlock:he(cc),onLocateNoteBlock:he(dc),onGenerateNotes:he(uc),onBatchAppendNotes:he(fc),onBatchDeleteNotes:he(pc),"is-batch-processing":he(mr),onInsertDividerAfter:he(gr),onDeleteDivider:he(Cc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!F.value?(X(),qt(t0,{key:1,"elem-click":I.value,"elem-motion":E.value,"elem-slot":O.value,"elem-shiki-lines":Y.value,"elem-max-height":B.value,"is-code-block":$.value,"is-image":w.value,"is-video":R.value,"is-super-block":V.value,"detected-sb-info":pe.value,"video-autoplay":z.value,"video-loop":J.value,"video-muted":ne.value,"video-controls":oe.value,"has-block-attrs":Ne.value,"is-note":G.value,"image-role":Be.value,"current-slide-layout":K.value,"parent-elem-click":m.value,"parent-container-slot":v.value,"parent-container-id":u.value,onToggleNote:he(Gi),onToggleElemClick:he(mc),onToggleVideoAutoplay:he(Vi),onToggleVideoLoop:he(Ys),onToggleVideoMuted:he(Zs),onToggleVideoControls:he(es),"onUpdate:imageRole":he(_i),"onUpdate:elemClick":he(gc),"onUpdate:elemMotion":he(vc),"onUpdate:elemSlot":he(bc),"onUpdate:elemShikiLines":he(yc),"onUpdate:elemMaxHeight":he(kc),onApplySuperBlockLayout:vr,onApplySuperBlockRatio:Pc,onInsertDividerBefore:he(Sc),onInsertDividerAfter:he(gr),onSetTwoColsContrast:he(wc),onClearBlockAttrs:he(xc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(X(),qt(F0,{key:2,"doc-theme":me.value,"doc-aspect-ratio":ie.value,"doc-default-transition":se.value,"doc-spacing":_e.value,"is-exporting-images":he(Tc),"is-batch-processing":he(mr),"onUpdate:docTheme":Fc,"onUpdate:docAspectRatio":jc,"onUpdate:docDefaultTransition":Wc,"onUpdate:docSpacing":Uc,onOpenBottomPreview:br,onOpenPresenter:Vc,onIdentifyNotes:he(hc),onAiAutoSplit:Gc,onExportHtml:he(_c),onExportPdf:he($c),onExportImages:he(Ic)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&he(Ct)("import")?(X(),qt(jk,{key:1,onClose:be[1]||(be[1]=Me=>n.value=!1),onSuccess:s})):Ie("",!0)]))}}),mw=2e3,gw=600;function vw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function mo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(ul(e))return!0;const t=e.firstElementChild;return!!(t&&ul(t))}function ul(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function bw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class yw{constructor(){ke(this,"consumers",new Map);ke(this,"seq",0);ke(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=bw(),l={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=mo(i),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?mo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!vw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&mo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},mw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new yw,vn=new Qn;function oc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let ki=null,At=null,ys=null;function kw(){return At}function ww(e,t){ki&&rc(),ki=lr(Mg),ki.provide("plugin",t),ki.provide("sandboxBridge",vn);const i=ki.mount(e);return At=i,ys=oc("preview",e,t),i}function rc(e){ys&&(ys(),ys=null),ki&&(ki.unmount(),ki=null,At=null)}function xw(){return At!==null}let wi=null,Oi=null;function Sw(e,t){return wi&&lc(),wi=lr(Hv),wi.provide("plugin",t),wi.provide("sandboxBridge",vn),Oi=wi.mount(e),Oi}function lc(e){wi&&(wi.unmount(),wi=null,Oi=null)}function Cw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let xi=null,_t=null,ks=null;function _w(e,t){xi&&ac(),xi=lr(hw),xi.provide("plugin",t),xi.provide("sandboxBridge",vn);const i=xi.mount(e);return _t=i,ks=oc("dock",e,t),i}function ac(e){ks&&(ks(),ks=null),xi&&(xi.unmount(),xi=null,_t=null)}function $w(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),At!=null&&At.updateDocument?At.updateDocument(e,t):(vn.updateSlides(e.slides,e.config,e.fullMarkdown),Cw(e)),Oi!=null&&Oi.updateDocument&&Oi.updateDocument(e)}function Fo(e){At!=null&&At.navigateToBlock?At.navigateToBlock(e):vn.highlightElement(e)}function Zi(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function Iw(){return ni("import")?!1:_t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}const Tw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Bi,value:"true"},{key:we,value:"cover"},{key:pt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Bi,value:"true"},{key:we,value:"two-cols"},{key:pt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Bi,value:"true"},{key:we,value:"fact"},{key:pt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Bi,value:"true"},{key:we,value:"intro"},{key:pt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Bi,value:"true"},{key:we,value:"quote"},{key:pt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:$e,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Wi,value:"1-3"}]}];class go{getPresetTemplates(){return Tw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${pt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${pt}' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[pt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slides-layout' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slides-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Ew(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ni("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Iw()||ce.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Fe(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ce.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ni("aiScript")||e.addCommand({langKey:"slidesAiSplit",langText:"即现 AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>sc(e)}),ni("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!e.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ce.showMessage("请先打开一篇思源笔记文档");return}ce.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Yn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await Kk(i,gl)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slides-note="true"}`,l=await bo("markdown",o,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await Fe(r,{"custom-slides-note":"true"}),Pe.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Fi(r,e.app)),ce.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ce.showMessage("请先在主编辑区打开幻灯片文档");return}await nc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new go,i=t.buildTransitionStatsSql(),n=await an(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ce.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new go().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ce.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ce.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new go().batchUpdateTransitions("fade","slide-left",n=>an(n).catch(()=>[]),(n,s)=>Fe(n,s));ce.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ni("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ni("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ce.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ce.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ce.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ce.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",ko);t.success?ce.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ce.showMessage(`同步失败：${t.error}`)}})),!ni("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ce.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ce.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await ji(i,e.currentDocId,e),s=await Za(i,{title:n,onProgress:(o,l)=>{ce.showMessage(`正在导出幻灯片图片 (${o} / ${l})...`,2e3)}});s.success?ce.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ce.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class Mw{constructor(t=400){ke(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Aw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class Bw{constructor(t=150){ke(this,"lastBlockId","");ke(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class Dw{constructor(){ke(this,"attrCache",new Mw);ke(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Pe.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const l=await jo(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Aw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Zi({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Fo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,d,p,h;if(!t){Pn();const u=typeof o=="number"&&o>0?o:1,v=((c=s==null?void 0:s.slides)==null?void 0:c[u-1])||((d=s==null?void 0:s.slides)==null?void 0:d[0]);if(v){const m=v.startBlockId||"",b=((p=v.frontmatter)==null?void 0:p.layout)||"",y={"custom-slides-layout":b,...v.frontmatter};return Zi({id:m,rootId:n,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,s).then(C=>{C&&Object.keys(C).length>0&&Zi({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...y,...C},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(n),!0}const l=Fi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,n,s);else{let u="",v="";if(s!=null&&s.slides){const m=s.slides.find(b=>{var y,C,S;return b.startBlockId===t||((y=b.blocks)==null?void 0:y.some(x=>x.id===t))||((C=b.allBlockIds)==null?void 0:C.includes(t))||((S=b.noteBlocks)==null?void 0:S.some(x=>x.id===t))});m!=null&&m.startBlockId&&(u=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(v=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(u&&!v){const b=Pe.getBlockAttrOverride(u);if(b!=null&&b[we]||b!=null&&b["custom-slides-layout"])v=b[we]||b["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(u,s);v=y[we]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Pe.setBlockAttrOverride(u,y)}}Zi({id:t,rootId:n,type:a||"NodeParagraph",attrs:m||{},pageDividerId:u,pageDividerLayout:v})}).catch(()=>{})}return l}async syncInspectorBlock(t,i,n,s,o){var M,j,A,D,N,ee,W,K;let l=t,r=i,a=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const re=c.getAttribute("data-node-id");if(re){const ae=await this.resolveBlockAttrs(re,o),de=Pe.getBlockAttrOverride(re)||{},ve={...ae,...de};(ve[Ke]||ve["slides-note"])&&(l=c,r=re,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,h=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((M=d==null?void 0:d.classList)!=null&&M.contains("hr")),u=a==="NodeCodeBlock",v=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Pe.getBlockAttrOverride(r)||{},y={...m,...b};let C="",S="";if(h)C=r,S=y[we]||y["custom-slides-layout"]||"";else{let re=d.previousElementSibling;for(;re;){const ae=re.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(A=re.classList)!=null&&A.contains("hr")){C=re.getAttribute("data-node-id")||"";break}re=re.previousElementSibling}}if(o!=null&&o.slides){const re=[r,p];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const ve=ae.getAttribute("data-node-id");ve&&!re.includes(ve)&&re.push(ve),ae=ae.parentElement}const de=o.slides.find(ve=>{var Ee,Se,fe;return re.includes(ve.startBlockId)||((Ee=ve.blocks)==null?void 0:Ee.some(Z=>re.includes(Z.id)))||((Se=ve.allBlockIds)==null?void 0:Se.some(Z=>re.includes(Z)))||((fe=ve.noteBlocks)==null?void 0:fe.some(Z=>re.includes(Z.id)))});de&&(!C&&de.startBlockId&&(C=de.startBlockId),!S&&((D=de.frontmatter)!=null&&D.layout)&&(S=de.frontmatter.layout))}if(C){const re=Pe.getBlockAttrOverride(C);if(re&&(we in re||"custom-slides-layout"in re)&&(S=re[we]||re["custom-slides-layout"]||""),!S&&(o!=null&&o.slides)){const ae=o.slides.find(de=>de.startBlockId===C);(N=ae==null?void 0:ae.frontmatter)!=null&&N.layout&&(S=ae.frontmatter.layout)}if(!S){const ae=await this.resolveBlockAttrs(C,o);S=ae[we]||ae["custom-slides-layout"]||"",ae&&Object.keys(ae).length>0&&Pe.setBlockAttrOverride(C,ae)}et(C,{[we]:S||""})}else if(s){const re=Pe.getBlockAttrOverride(s);re&&(we in re||"custom-slides-layout"in re)?S=re[we]||re["custom-slides-layout"]||"":!S&&((K=(W=(ee=o==null?void 0:o.slides)==null?void 0:ee[0])==null?void 0:W.frontmatter)!=null&&K.layout)&&(S=o.slides[0].frontmatter.layout)}const x=l.getAttribute(we)||l.getAttribute("custom-slides-layout"),$=y[we]||y["custom-slides-layout"]||"";x&&x!==$&&et(r,{[we]:$});const T=l.getAttribute(Ye)||l.getAttribute("custom-slides-role"),w=y[Ye]||y["custom-slides-role"]||"";T&&T!==w&&et(r,{[Ye]:w});let R="",F="",P="";const q=l.closest('[data-type="NodeListItem"]');if(q&&q!==l){const re=q.getAttribute("data-node-id");if(re){R=re;const ae=await this.resolveBlockAttrs(re,o),de=Pe.getBlockAttrOverride(re)||{},ve={...ae,...de};F=ve[$e]||"",P=ve[Ze]||"";const Ee=ve[we]||ve["custom-slides-layout"]||"",Se=q.getAttribute(we)||q.getAttribute("custom-slides-layout");Se&&Se!==Ee&&et(re,{[we]:Ee});const fe=ve[Ye]||ve["custom-slides-role"]||"",Z=q.getAttribute(Ye)||q.getAttribute("custom-slides-role");Z&&Z!==fe&&et(re,{[Ye]:fe})}}const _=!!l.querySelector("img, span[data-type='img']"),H=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=_&&H.length<=50;Zi({id:r,rootId:s,type:a,content:v,attrs:y,isDivider:h,isCode:u,isImage:k,topBlockId:p,pageDividerId:C,pageDividerLayout:S,parentContainerId:R,parentContainerSlot:F,parentContainerClicks:P})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");et(n.id,l),Pe.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidesAttrs(t){var s,o,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[we]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(o=a.ial)!=null&&o[we]&&(c[we]=a.ial[we]),(l=a.ial)!=null&&l[Ye]&&(c[Ye]=a.ial[Ye]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[we]!==void 0&&(c[we]=a[we]),a[Ye]!==void 0&&(c[Ye]=a[Ye]),i.set(r,c)}Uk(i)}}const Mi=new Dw;class Lw{constructor(){ke(this,"inFlightDocId",null);ke(this,"pendingDocId",null);ke(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const Pw=150,Ow=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Rw="slides-dock",vo="slides-preview-tab",fl="slides-presenter-tab",pl=Nf;class Nw extends ce.Plugin{constructor(){super(...arguments);ke(this,"isMobile",!1);ke(this,"currentDocId","");ke(this,"previewTab",null);ke(this,"latestCompiledDoc",null);ke(this,"cliBridge",new ur);ke(this,"debounceTimer",null);ke(this,"activeCursorBlockId","");ke(this,"cancelledCursorBlockId","");ke(this,"compileScheduler",new Lw);ke(this,"dirtyDocId",null);ke(this,"inspectorSyncThrottle",new Bw);ke(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ke(this,"onWsMainBound",this.onWsMain.bind(this));ke(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ke(this,"onEditorClickBound",this.onEditorClick.bind(this));ke(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ke(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ke(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ce.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Ow),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Ew(this);const n=this;if(this.addTab({type:vo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,ww(o.element,n);const l=(r=o==null?void 0:o.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),rc(this.element)}}),this.addTab({type:fl,init(s){Sw((this||s).element,n)},destroy(){lc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:Rw,init(){_w(this.element,n)},destroy(){ac(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(pl),n=zf(i);return Pi(n),n}catch{return Pi(fn),fn}}async saveGlobalSettings(i){const n=qs(),s=Pi({...n,...i||{}});try{await this.saveData(pl,s)}catch(l){console.error("保存即现全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),vn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ce.openTab({app:this.app,custom:{id:this.name+vo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ni("presenterMode")||(xw()||await this.openBottomPreviewTab(),await ce.openTab({app:this.app,custom:{id:this.name+fl,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ce.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),l=await ce.openTab({app:this.app,custom:{id:this.name+vo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ce.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const p=await jo(s).catch(()=>({}));Zi({id:s,rootId:s,type:"doc",attrs:p}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,l;const n=i==null?void 0:i.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Ka(i)}async fetchDocumentTitle(i){return qa(this,i)}async updatePreviewTabHeader(i,n){return dg(this,i,n)}getActiveDocumentId(){return Mi.getActiveDocumentId()}resolveDocIdFromElement(i){return Mi.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Mi.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Mi.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=Pw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,gw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Mi.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),h=p==null?void 0:p.querySelector(".protyle-title__input"),u=((h==null?void 0:h.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Fo(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),h=p==null?void 0:p.querySelector(".protyle-title__input"),u=((h==null?void 0:h.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&a){if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId){if(a===this.cancelledCursorBlockId)return;this.activeCursorBlockId=a,Fo(a)}this.syncInspectorBlock(r,a,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Mi.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,$w(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidesAttrs(i){Mi.purgeStaleDomSlidesAttrs(i)}}module.exports=Nw;
