"use strict";var Bc=Object.create;var Ko=Object.defineProperty;var Mc=Object.getOwnPropertyDescriptor;var Dc=Object.getOwnPropertyNames;var Lc=Object.getPrototypeOf,Pc=Object.prototype.hasOwnProperty;var Oc=(e,t,i)=>t in e?Ko(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Rc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Dc(t))!Pc.call(e,o)&&o!==i&&Ko(e,o,{get:()=>t[o],enumerable:!(n=Mc(t,o))||n.enumerable});return e};var Gn=(e,t,i)=>(i=e!=null?Bc(Lc(e)):{},Rc(t||!e||!e.__esModule?Ko(i,"default",{value:e,enumerable:!0}):i,e));var we=(e,t,i)=>Oc(e,typeof t!="symbol"?t+"":t,i);const pe=require("siyuan");async function mt(e,t){const i=await pe.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Nc(){return mt("/api/notebook/lsNotebooks","")}async function zc(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function nl(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const o of t)i.append("file[]",o);return mt("/api/asset/upload",i)}async function Mi(e,t,i,n,o){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:o})}async function us(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function dr(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ol(e){return mt("/api/block/deleteBlock",{id:e})}async function Fc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function fo(e){return mt("/api/block/getChildBlocks",{id:e})}async function Hc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function Ne(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Ms(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function on(e){return mt("/api/query/sql",{stmt:e})}async function fs(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function sl(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function jc(){return mt("/api/storage/getInlineStyles","")}const rl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Wc(e){const t=[];if(!e)return t;const i=new RegExp(rl.source,"g");let n;for(;(n=i.exec(e))!==null;){const o=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return t}function Uc(e,t){if(!e)return"";const i=new RegExp(rl.source,"g");return e.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[o]){const d=t[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const An="custom-slidev-theme",Bn="custom-slidev-aspect-ratio",ll="custom-slidev-highlighter",Mn="custom-slidev-default-transition",al="custom-slidev-color-schema",ps="custom-slidev-spacing",Ai="custom-slidev-slide",he="custom-slidev-layout",tt="custom-slidev-transition",We="custom-slidev-background",Dt="custom-slidev-image",Ki="custom-slidev-notes",Gi="custom-slidev-class",wn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",qi="custom-slidev-mask",Zi="custom-slidev-mask-ratio",Yi="custom-slidev-mask-style",Ji="custom-slidev-mask-initial",Ze="custom-slidev-click",qt="custom-slidev-motion",Ni="custom-slidev-shiki-lines",Ce="custom-slidev-slot",nt="custom-slidev-note",Ge="custom-slidev-role",Dn="custom-slidev-max-height",Bi="custom-slidev-autoplay",po="custom-slidev-loop",Vi="custom-slidev-muted",ho="custom-slidev-controls",cl="background",mo="image-left",go="image-right";function Ln(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Vc(e){if(!e||typeof e!="string")return{steps:2,breakpoints:[50,100]};const t=e.trim();if(!t)return{steps:2,breakpoints:[50,100]};const i=t.split(":").map(c=>parseFloat(c.trim())).filter(c=>!isNaN(c)&&c>0);if(i.length===0)return{steps:2,breakpoints:[50,100]};if(i.length===1){const c=Math.min(100,Math.max(1,i[0]));return c===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(c*100)/100,100]}}const n=i.every((c,d)=>d===0||c>i[d-1]),o=i[i.length-1];if(n&&(o===100||i.some(c=>c>10))){const c=i.map(d=>Math.min(100,Math.round(d*100)/100));return c[c.length-1]<100&&c.push(100),{steps:c.length,breakpoints:c}}const l=i.reduce((c,d)=>c+d,0);if(l<=0)return{steps:2,breakpoints:[50,100]};let r=0;const a=[];for(let c=0;c<i.length;c++)r+=i[c],c===i.length-1?a.push(100):a.push(Math.round(r/l*1e4)/100);return{steps:a.length,breakpoints:a}}function Kc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Gc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function dl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function ul(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Tt(e,t){if(!dl(e))return e;const i=ul(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function qc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Tt(s,t);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Tt(s,t);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Tt(s,t);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ds(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ue={},Xi=[],Zt=()=>{},fl=()=>!1,To=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Eo=e=>e.startsWith("onUpdate:"),dt=Object.assign,Ls=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Zc=Object.prototype.hasOwnProperty,Re=(e,t)=>Zc.call(e,t),Ie=Array.isArray,Qi=e=>jn(e)==="[object Map]",cn=e=>jn(e)==="[object Set]",ur=e=>jn(e)==="[object Date]",Ee=e=>typeof e=="function",it=e=>typeof e=="string",Nt=e=>typeof e=="symbol",je=e=>e!==null&&typeof e=="object",pl=e=>(je(e)||Ee(e))&&Ee(e.then)&&Ee(e.catch),hl=Object.prototype.toString,jn=e=>hl.call(e),Yc=e=>jn(e).slice(8,-1),ml=e=>jn(e)==="[object Object]",Ps=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,xn=Ds(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Ao=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Jc=/-\w/g,wt=Ao(e=>e.replace(Jc,t=>t.slice(1).toUpperCase())),Xc=/\B([A-Z])/g,xi=Ao(e=>e.replace(Xc,"-$1").toLowerCase()),Bo=Ao(e=>e.charAt(0).toUpperCase()+e.slice(1)),Go=Ao(e=>e?`on${Bo(e)}`:""),Kt=(e,t)=>!Object.is(e,t),io=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},gl=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Mo=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let fr;const Do=()=>fr||(fr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Gt(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],o=it(n)?id(n):Gt(n);if(o)for(const s in o)t[s]=o[s]}return t}else if(it(e)||je(e))return e}const Qc=/;(?![^(]*\))/g,ed=/:([^]+)/,td=/\/\*[^]*?\*\//g;function id(e){const t={};return e.replace(td,"").split(Qc).forEach(i=>{if(i){const n=i.split(ed);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(it(e))t=e;else if(Ie(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(je(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const nd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",od=Ds(nd);function vl(e){return!!e||e===""}function sd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=dn(e[n],t[n]);return i}function dn(e,t){if(e===t)return!0;let i=ur(e),n=ur(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Nt(e),n=Nt(t),i||n)return e===t;if(i=Ie(e),n=Ie(t),i||n)return i&&n?sd(e,t):!1;if(i=je(e),n=je(t),i||n){if(!i||!n)return!1;const o=Object.keys(e).length,s=Object.keys(t).length;if(o!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!dn(e[l],t[l]))return!1}}return String(e)===String(t)}function Os(e,t){return e.findIndex(i=>dn(i,t))}const bl=e=>!!(e&&e.__v_isRef===!0),ge=e=>it(e)?e:e==null?"":Ie(e)||je(e)&&(e.toString===hl||!Ee(e.toString))?bl(e)?ge(e.value):JSON.stringify(e,yl,2):String(e),yl=(e,t)=>bl(t)?yl(e,t.value):Qi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,o],s)=>(i[qo(n,s)+" =>"]=o,i),{})}:cn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>qo(i))}:Nt(t)?qo(t):je(t)&&!Ie(t)&&!ml(t)?String(t):t,qo=(e,t="")=>{var i;return Nt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let at;class rd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&at&&(at.active?(this.parent=at,this.index=(at.scopes||(at.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const o=this.scopes.slice();for(t=0,i=o.length;t<i;t++)o[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=at;try{return at=this,t()}finally{at=i}}}on(){++this._on===1&&(this.prevScope=at,at=this)}off(){if(this._on>0&&--this._on===0){if(at===this)at=this.prevScope;else{let t=at;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function ld(){return at}let Ke;const Zo=new WeakSet;class kl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,at&&(at.active?at.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Zo.has(this)&&(Zo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||xl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,pr(this),Sl(this);const t=Ke,i=Ot;Ke=this,Ot=!0;try{return this.fn()}finally{_l(this),Ke=t,Ot=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)zs(t);this.deps=this.depsTail=void 0,pr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Zo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){hs(this)&&this.run()}get dirty(){return hs(this)}}let wl=0,Sn,_n;function xl(e,t=!1){if(e.flags|=8,t){e.next=_n,_n=e;return}e.next=Sn,Sn=e}function Rs(){wl++}function Ns(){if(--wl>0)return;if(_n){let t=_n;for(_n=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Sn;){let t=Sn;for(Sn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Sl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function _l(e){let t,i=e.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),zs(n),ad(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}e.deps=t,e.depsTail=i}function hs(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Cl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Cl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Pn)||(e.globalVersion=Pn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!hs(e))))return;e.flags|=2;const t=e.dep,i=Ke,n=Ot;Ke=e,Ot=!0;try{Sl(e);const o=e.fn(e._value);(t.version===0||Kt(o,e._value))&&(e.flags|=128,e._value=o,t.version++)}catch(o){throw t.version++,o}finally{Ke=i,Ot=n,_l(e),e.flags&=-3}}function zs(e,t=!1){const{dep:i,prevSub:n,nextSub:o}=e;if(n&&(n.nextSub=o,e.prevSub=void 0),o&&(o.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)zs(s,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function ad(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Ot=!0;const $l=[];function si(){$l.push(Ot),Ot=!1}function ri(){const e=$l.pop();Ot=e===void 0?!0:e}function pr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ke;Ke=void 0;try{t()}finally{Ke=i}}}let Pn=0;class cd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Fs{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ke||!Ot||Ke===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ke)i=this.activeLink=new cd(Ke,this),Ke.deps?(i.prevDep=Ke.depsTail,Ke.depsTail.nextDep=i,Ke.depsTail=i):Ke.deps=Ke.depsTail=i,Il(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ke.depsTail,i.nextDep=void 0,Ke.depsTail.nextDep=i,Ke.depsTail=i,Ke.deps===i&&(Ke.deps=n)}return i}trigger(t){this.version++,Pn++,this.notify(t)}notify(t){Rs();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Ns()}}}function Il(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Il(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const ms=new WeakMap,Pi=Symbol(""),gs=Symbol(""),On=Symbol("");function pt(e,t,i){if(Ot&&Ke){let n=ms.get(e);n||ms.set(e,n=new Map);let o=n.get(i);o||(n.set(i,o=new Fs),o.map=n,o.key=i),o.track()}}function ti(e,t,i,n,o,s){const l=ms.get(e);if(!l){Pn++;return}const r=a=>{a&&a.trigger()};if(Rs(),t==="clear")l.forEach(r);else{const a=Ie(e),c=a&&Ps(i);if(a&&i==="length"){const d=Number(n);l.forEach((f,g)=>{(g==="length"||g===On||!Nt(g)&&g>=d)&&r(f)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(On)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Pi)),Qi(e)&&r(l.get(gs)));break;case"delete":a||(r(l.get(Pi)),Qi(e)&&r(l.get(gs)));break;case"set":Qi(e)&&r(l.get(Pi));break}}Ns()}function Wi(e){const t=Oe(e);return t===e?t:(pt(t,"iterate",On),Bt(e)?t:t.map(zt))}function Lo(e){return pt(e=Oe(e),"iterate",On),e}function Ut(e,t){return li(e)?sn(Oi(e)?zt(t):t):zt(t)}const dd={__proto__:null,[Symbol.iterator](){return Yo(this,Symbol.iterator,e=>Ut(this,e))},concat(...e){return Wi(this).concat(...e.map(t=>Ie(t)?Wi(t):t))},entries(){return Yo(this,"entries",e=>(e[1]=Ut(this,e[1]),e))},every(e,t){return Xt(this,"every",e,t,void 0,arguments)},filter(e,t){return Xt(this,"filter",e,t,i=>i.map(n=>Ut(this,n)),arguments)},find(e,t){return Xt(this,"find",e,t,i=>Ut(this,i),arguments)},findIndex(e,t){return Xt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Xt(this,"findLast",e,t,i=>Ut(this,i),arguments)},findLastIndex(e,t){return Xt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Xt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Jo(this,"includes",e)},indexOf(...e){return Jo(this,"indexOf",e)},join(e){return Wi(this).join(e)},lastIndexOf(...e){return Jo(this,"lastIndexOf",e)},map(e,t){return Xt(this,"map",e,t,void 0,arguments)},pop(){return gn(this,"pop")},push(...e){return gn(this,"push",e)},reduce(e,...t){return hr(this,"reduce",e,t)},reduceRight(e,...t){return hr(this,"reduceRight",e,t)},shift(){return gn(this,"shift")},some(e,t){return Xt(this,"some",e,t,void 0,arguments)},splice(...e){return gn(this,"splice",e)},toReversed(){return Wi(this).toReversed()},toSorted(e){return Wi(this).toSorted(e)},toSpliced(...e){return Wi(this).toSpliced(...e)},unshift(...e){return gn(this,"unshift",e)},values(){return Yo(this,"values",e=>Ut(this,e))}};function Yo(e,t,i){const n=Lo(e),o=n[t]();return n!==e&&!Bt(e)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const ud=Array.prototype;function Xt(e,t,i,n,o,s){const l=Lo(e),r=l!==e&&!Bt(e),a=l[t];if(a!==ud[t]){const f=a.apply(e,s);return r?zt(f):f}let c=i;l!==e&&(r?c=function(f,g){return i.call(this,Ut(e,f),g,e)}:i.length>2&&(c=function(f,g){return i.call(this,f,g,e)}));const d=a.call(l,c,n);return r&&o?o(d):d}function hr(e,t,i,n){const o=Lo(e),s=o!==e&&!Bt(e);let l=i,r=!1;o!==e&&(s?(r=n.length===0,l=function(c,d,f){return r&&(r=!1,c=Ut(e,c)),i.call(this,c,Ut(e,d),f,e)}):i.length>3&&(l=function(c,d,f){return i.call(this,c,d,f,e)}));const a=o[t](l,...n);return r?Ut(e,a):a}function Jo(e,t,i){const n=Oe(e);pt(n,"iterate",On);const o=n[t](...i);return(o===-1||o===!1)&&Ws(i[0])?(i[0]=Oe(i[0]),n[t](...i)):o}function gn(e,t,i=[]){si(),Rs();const n=Oe(e)[t].apply(e,i);return Ns(),ri(),n}const fd=Ds("__proto__,__v_isRef,__isVue"),Tl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Nt));function pd(e){Nt(e)||(e=String(e));const t=Oe(this);return pt(t,"has",e),t.hasOwnProperty(e)}class El{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?Sd:Dl:s?Ml:Bl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Ie(t);if(!o){let a;if(l&&(a=dd[i]))return a;if(i==="hasOwnProperty")return pd}const r=Reflect.get(t,i,Ye(t)?t:n);if((Nt(i)?Tl.has(i):fd(i))||(o||pt(t,"get",i),s))return r;if(Ye(r)){const a=l&&Ps(i)?r:r.value;return o&&je(a)?bs(a):a}return je(r)?o?bs(r):Po(r):r}}class Al extends El{constructor(t=!1){super(!1,t)}set(t,i,n,o){let s=t[i];const l=Ie(t)&&Ps(i);if(!this._isShallow){const c=li(s);if(!Bt(n)&&!li(n)&&(s=Oe(s),n=Oe(n)),!l&&Ye(s)&&!Ye(n))return c||(s.value=n),!0}const r=l?Number(i)<t.length:Re(t,i),a=Reflect.set(t,i,n,Ye(t)?t:o);return t===Oe(o)&&a&&(r?Kt(n,s)&&ti(t,"set",i,n):ti(t,"add",i,n)),a}deleteProperty(t,i){const n=Re(t,i);t[i];const o=Reflect.deleteProperty(t,i);return o&&n&&ti(t,"delete",i,void 0),o}has(t,i){const n=Reflect.has(t,i);return(!Nt(i)||!Tl.has(i))&&pt(t,"has",i),n}ownKeys(t){return pt(t,"iterate",Ie(t)?"length":Pi),Reflect.ownKeys(t)}}class hd extends El{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const md=new Al,gd=new hd,vd=new Al(!0);const vs=e=>e,qn=e=>Reflect.getPrototypeOf(e);function bd(e,t,i){return function(...n){const o=this.__v_raw,s=Oe(o),l=Qi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=o[e](...n),d=i?vs:t?sn:zt;return!t&&pt(s,"iterate",a?gs:Pi),dt(Object.create(c),{next(){const{value:f,done:g}=c.next();return g?{value:f,done:g}:{value:r?[d(f[0]),d(f[1])]:d(f),done:g}}})}}function Zn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function yd(e,t){const i={get(o){const s=this.__v_raw,l=Oe(s),r=Oe(o);e||(Kt(o,r)&&pt(l,"get",o),pt(l,"get",r));const{has:a}=qn(l),c=t?vs:e?sn:zt;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!e&&pt(Oe(o),"iterate",Pi),o.size},has(o){const s=this.__v_raw,l=Oe(s),r=Oe(o);return e||(Kt(o,r)&&pt(l,"has",o),pt(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Oe(r),c=t?vs:e?sn:zt;return!e&&pt(a,"iterate",Pi),r.forEach((d,f)=>o.call(s,c(d),c(f),l))}};return dt(i,e?{add:Zn("add"),set:Zn("set"),delete:Zn("delete"),clear:Zn("clear")}:{add(o){const s=Oe(this),l=qn(s),r=Oe(o),a=!t&&!Bt(o)&&!li(o)?r:o;return l.has.call(s,a)||Kt(o,a)&&l.has.call(s,o)||Kt(r,a)&&l.has.call(s,r)||(s.add(a),ti(s,"add",a,a)),this},set(o,s){!t&&!Bt(s)&&!li(s)&&(s=Oe(s));const l=Oe(this),{has:r,get:a}=qn(l);let c=r.call(l,o);c||(o=Oe(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?Kt(s,d)&&ti(l,"set",o,s):ti(l,"add",o,s),this},delete(o){const s=Oe(this),{has:l,get:r}=qn(s);let a=l.call(s,o);a||(o=Oe(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&ti(s,"delete",o,void 0),c},clear(){const o=Oe(this),s=o.size!==0,l=o.clear();return s&&ti(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=bd(o,e,t)}),i}function Hs(e,t){const i=yd(e,t);return(n,o,s)=>o==="__v_isReactive"?!e:o==="__v_isReadonly"?e:o==="__v_raw"?n:Reflect.get(Re(i,o)&&o in n?i:n,o,s)}const kd={get:Hs(!1,!1)},wd={get:Hs(!1,!0)},xd={get:Hs(!0,!1)};const Bl=new WeakMap,Ml=new WeakMap,Dl=new WeakMap,Sd=new WeakMap;function _d(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Po(e){return li(e)?e:js(e,!1,md,kd,Bl)}function Cd(e){return js(e,!1,vd,wd,Ml)}function bs(e){return js(e,!0,gd,xd,Dl)}function js(e,t,i,n,o){if(!je(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=o.get(e);if(s)return s;const l=_d(Yc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return o.set(e,r),r}function Oi(e){return li(e)?Oi(e.__v_raw):!!(e&&e.__v_isReactive)}function li(e){return!!(e&&e.__v_isReadonly)}function Bt(e){return!!(e&&e.__v_isShallow)}function Ws(e){return e?!!e.__v_raw:!1}function Oe(e){const t=e&&e.__v_raw;return t?Oe(t):e}function $d(e){return!Re(e,"__v_skip")&&Object.isExtensible(e)&&gl(e,"__v_skip",!0),e}const zt=e=>je(e)?Po(e):e,sn=e=>je(e)?bs(e):e;function Ye(e){return e?e.__v_isRef===!0:!1}function fe(e){return Id(e,!1)}function Id(e,t){return Ye(e)?e:new Td(e,t)}class Td{constructor(t,i){this.dep=new Fs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Oe(t),this._value=i?t:zt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Bt(t)||li(t);t=n?t:Oe(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:zt(t),this.dep.trigger())}}function be(e){return Ye(e)?e.value:e}const Ed={get:(e,t,i)=>t==="__v_raw"?e:be(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const o=e[t];return Ye(o)&&!Ye(i)?(o.value=i,!0):Reflect.set(e,t,i,n)}};function Ll(e){return Oi(e)?e:new Proxy(e,Ed)}class Ad{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Fs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Pn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ke!==this)return xl(this,!0),!0}get value(){const t=this.dep.track();return Cl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Bd(e,t,i=!1){let n,o;return Ee(e)?n=e:(n=e.get,o=e.set),new Ad(n,o,i)}const Yn={},vo=new WeakMap;let Ei;function Md(e,t=!1,i=Ei){if(i){let n=vo.get(i);n||vo.set(i,n=[]),n.push(e)}}function Dd(e,t,i=Ue){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=B=>o?B:Bt(B)||o===!1||o===0?ii(B,1):ii(B);let d,f,g,u,m=!1,p=!1;if(Ye(e)?(f=()=>e.value,m=Bt(e)):Oi(e)?(f=()=>c(e),m=!0):Ie(e)?(p=!0,m=e.some(B=>Oi(B)||Bt(B)),f=()=>e.map(B=>{if(Ye(B))return B.value;if(Oi(B))return c(B);if(Ee(B))return a?a(B,2):B()})):Ee(e)?t?f=a?()=>a(e,2):e:f=()=>{if(g){si();try{g()}finally{ri()}}const B=Ei;Ei=d;try{return a?a(e,3,[u]):e(u)}finally{Ei=B}}:f=Zt,t&&o){const B=f,M=o===!0?1/0:o;f=()=>ii(B(),M)}const b=ld(),y=()=>{d.stop(),b&&b.active&&Ls(b.effects,d)};if(s&&t){const B=t;t=(...M)=>{const T=B(...M);return y(),T}}let x=p?new Array(e.length).fill(Yn):Yn;const _=B=>{if(!(!(d.flags&1)||!d.dirty&&!B))if(t){const M=d.run();if(B||o||m||(p?M.some((T,w)=>Kt(T,x[w])):Kt(M,x))){g&&g();const T=Ei;Ei=d;try{const w=[M,x===Yn?void 0:p&&x[0]===Yn?[]:x,u];x=M,a?a(t,3,w):t(...w)}finally{Ei=T}}}else d.run()};return r&&r(_),d=new kl(f),d.scheduler=l?()=>l(_,!1):_,u=B=>Md(B,!1,d),g=d.onStop=()=>{const B=vo.get(d);if(B){if(a)a(B,4);else for(const M of B)M();vo.delete(d)}},t?n?_(!0):x=d.run():l?l(_.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function ii(e,t=1/0,i){if(t<=0||!je(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ye(e))ii(e.value,t,i);else if(Ie(e))for(let n=0;n<e.length;n++)ii(e[n],t,i);else if(cn(e)||Qi(e))e.forEach(n=>{ii(n,t,i)});else if(ml(e)){for(const n in e)ii(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ii(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wn(e,t,i,n){try{return n?e(...n):e()}catch(o){Oo(o,t,i)}}function Ft(e,t,i,n){if(Ee(e)){const o=Wn(e,t,i,n);return o&&pl(o)&&o.catch(s=>{Oo(s,t,i)}),o}if(Ie(e)){const o=[];for(let s=0;s<e.length;s++)o.push(Ft(e[s],t,i,n));return o}}function Oo(e,t,i,n=!0){const o=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ue;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let f=0;f<d.length;f++)if(d[f](e,a,c)===!1)return}r=r.parent}if(s){si(),Wn(s,null,10,[e,a,c]),ri();return}}Ld(e,i,o,n,l)}function Ld(e,t,i,n=!0,o=!1){if(o)throw e;console.error(e)}const bt=[];let Wt=-1;const en=[];let hi=null,Ui=0;const Pl=Promise.resolve();let bo=null;function yo(e){const t=bo||Pl;return e?t.then(this?e.bind(this):e):t}function Pd(e){let t=Wt+1,i=bt.length;for(;t<i;){const n=t+i>>>1,o=bt[n],s=Rn(o);s<e||s===e&&o.flags&2?t=n+1:i=n}return t}function Us(e){if(!(e.flags&1)){const t=Rn(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Rn(i)?bt.push(e):bt.splice(Pd(t),0,e),e.flags|=1,Ol()}}function Ol(){bo||(bo=Pl.then(Nl))}function Od(e){Ie(e)?en.push(...e):hi&&e.id===-1?hi.splice(Ui+1,0,e):e.flags&1||(en.push(e),e.flags|=1),Ol()}function mr(e,t,i=Wt+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Rl(e){if(en.length){const t=[...new Set(en)].sort((i,n)=>Rn(i)-Rn(n));if(en.length=0,hi){hi.push(...t);return}for(hi=t,Ui=0;Ui<hi.length;Ui++){const i=hi[Ui];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}hi=null,Ui=0}}const Rn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Nl(e){try{for(Wt=0;Wt<bt.length;Wt++){const t=bt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Wn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<bt.length;Wt++){const t=bt[Wt];t&&(t.flags&=-2)}Wt=-1,bt.length=0,Rl(),bo=null,(bt.length||en.length)&&Nl()}}let ct=null,zl=null;function ko(e){const t=ct;return ct=e,zl=e&&e.type.__scopeId||null,t}function Fl(e,t=ct,i){if(!t||e._n)return e;const n=(...o)=>{n._d&&Ir(-1);const s=ko(t),l=ni.length;let r;try{r=e(...o)}finally{for(let a=ni.length;a>l;a--)Zs();ko(s),n._d&&Ir(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Et(e,t){if(ct===null)return e;const i=Ho(ct),n=e.dirs||(e.dirs=[]);for(let o=0;o<t.length;o++){let[s,l,r,a=Ue]=t[o];s&&(Ee(s)&&(s={mounted:s,updated:s}),s.deep&&ii(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function _i(e,t,i,n){const o=e.dirs,s=t&&t.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(si(),Ft(a,i,8,[e.el,r,e,t]),ri())}}function Rd(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function Rt(e,t,i=!1){const n=Pu();if(n||nn){let o=nn?nn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&e in o)return o[e];if(arguments.length>1)return i&&Ee(t)?t.call(n&&n.proxy):t}}const Nd=Symbol.for("v-scx"),zd=()=>Rt(Nd);function ki(e,t,i){return Hl(e,t,i)}function Hl(e,t,i=Ue){const{immediate:n,deep:o,flush:s,once:l}=i,r=dt({},i),a=t&&n||!t&&s!=="post";let c;if(zn){if(s==="sync"){const u=zd();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Zt,u.resume=Zt,u.pause=Zt,u}}const d=ht;r.call=(u,m,p)=>Ft(u,d,m,p);let f=!1;s==="post"?r.scheduler=u=>{St(u,d&&d.suspense)}:s!=="sync"&&(f=!0,r.scheduler=(u,m)=>{m?u():Us(u)}),r.augmentJob=u=>{t&&(u.flags|=4),f&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Dd(e,t,r);return zn&&(c?c.push(g):a&&g()),g}function Fd(e,t,i){const n=this.proxy,o=it(e)?e.includes(".")?jl(n,e):()=>n[e]:e.bind(n,n);let s;Ee(t)?s=t:(s=t.handler,i=t);const l=Un(this),r=Hl(o,s.bind(n),i);return l(),r}function jl(e,t){const i=t.split(".");return()=>{let n=e;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const Hd=Symbol("_vte"),jd=e=>e.__isTeleport,Xo=Symbol("_leaveCb");function Vs(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Vs(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function xt(e,t){return Ee(e)?dt({name:e.name},t,{setup:e}):e}function Wl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function gr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const wo=new WeakMap;function Cn(e,t,i,n,o=!1){if(Ie(e)){e.forEach((p,b)=>Cn(p,t&&(Ie(t)?t[b]:t),i,n,o));return}if(tn(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Cn(e,t,i,n.component.subTree);return}const s=n.shapeFlag&4?Ho(n.component):n.el,l=o?null:s,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ue?r.refs={}:r.refs,f=r.setupState,g=Oe(f),u=f===Ue?fl:p=>gr(d,p)?!1:Re(g,p),m=(p,b)=>!(b&&gr(d,b));if(c!=null&&c!==a){if(vr(t),it(c))d[c]=null,u(c)&&(f[c]=null);else if(Ye(c)){const p=t;m(c,p.k)&&(c.value=null),p.k&&(d[p.k]=null)}}if(Ee(a))Wn(a,r,12,[l,d]);else{const p=it(a),b=Ye(a);if(p||b){const y=()=>{if(e.f){const x=p?u(a)?f[a]:d[a]:m()||!e.k?a.value:d[e.k];if(o)Ie(x)&&Ls(x,s);else if(Ie(x))x.includes(s)||x.push(s);else if(p)d[a]=[s],u(a)&&(f[a]=d[a]);else{const _=[s];m(a,e.k)&&(a.value=_),e.k&&(d[e.k]=_)}}else p?(d[a]=l,u(a)&&(f[a]=l)):b&&(m(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{y(),wo.delete(e)};x.id=-1,wo.set(e,x),St(x,i)}else vr(e),y()}}}function vr(e){const t=wo.get(e);t&&(t.flags|=8,wo.delete(e))}Do().requestIdleCallback;Do().cancelIdleCallback;const tn=e=>!!e.type.__asyncLoader,Ul=e=>e.type.__isKeepAlive;function Wd(e,t){Vl(e,"a",t)}function Ud(e,t){Vl(e,"da",t)}function Vl(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return e()});if(Ro(t,n,i),i){let o=i.parent;for(;o&&o.parent;)Ul(o.parent.vnode)&&Vd(n,t,i,o),o=o.parent}}function Vd(e,t,i,n){const o=Ro(t,e,n,!0);No(()=>{Ls(n[t],o)},i)}function Ro(e,t,i=ht,n=!1){if(i){const o=i[e]||(i[e]=[]),s=t.__weh||(t.__weh=(...l)=>{si();const r=Un(i),a=Ft(t,i,e,l);return r(),ri(),a});return n?o.unshift(s):o.push(s),s}}const ci=e=>(t,i=ht)=>{(!zn||e==="sp")&&Ro(e,(...n)=>t(...n),i)},Kd=ci("bm"),un=ci("m"),Gd=ci("bu"),qd=ci("u"),Ks=ci("bum"),No=ci("um"),Zd=ci("sp"),Yd=ci("rtg"),Jd=ci("rtc");function Xd(e,t=ht){Ro("ec",e,t)}const Qd="components";function eu(e,t){return iu(Qd,e,!0,t)||e}const tu=Symbol.for("v-ndc");function iu(e,t,i=!0,n=!1){const o=ct||ht;if(o){const s=o.type;{const r=Fu(s,!1);if(r&&(r===t||r===wt(t)||r===Bo(wt(t))))return s}const l=br(o[e]||s[e],t)||br(o.appContext[e],t);return!l&&n?s:l}}function br(e,t){return e&&(e[t]||e[wt(t)]||e[Bo(wt(t))])}function kt(e,t,i,n){let o;const s=i,l=Ie(e);if(l||it(e)){const r=l&&Oi(e);let a=!1,c=!1;r&&(a=!Bt(e),c=li(e),e=Lo(e)),o=new Array(e.length);for(let d=0,f=e.length;d<f;d++)o[d]=t(a?c?sn(zt(e[d])):zt(e[d]):e[d],d,void 0,s)}else if(typeof e=="number"){o=new Array(e);for(let r=0;r<e;r++)o[r]=t(r+1,r,void 0,s)}else if(je(e))if(e[Symbol.iterator])o=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=t(e[d],d,a,s)}}else o=[];return o}function Jn(e,t,i={},n,o,s){if(ct.ce||ct.parent&&tn(ct.parent)&&ct.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),te(),Pt(Ve,null,[ae("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ni.length;te();let a;try{const c=l&&Kl(l(i)),d=i.key||s||c&&c.key;a=Pt(Ve,{key:(d&&!Nt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ni.length;d>r;d--)Zs();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Kl(e){return e.some(t=>Ys(t)?!(t.type===ai||t.type===Ve&&!Kl(t.children)):!0)?e:null}const ys=e=>e?fa(e)?Ho(e):ys(e.parent):null,$n=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>ys(e.parent),$root:e=>ys(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ql(e),$forceUpdate:e=>e.f||(e.f=()=>{Us(e.update)}),$nextTick:e=>e.n||(e.n=yo.bind(e.proxy)),$watch:e=>Fd.bind(e)}),Qo=(e,t)=>e!==Ue&&!e.__isScriptSetup&&Re(e,t),nu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const g=l[t];if(g!==void 0)switch(g){case 1:return n[t];case 2:return o[t];case 4:return i[t];case 3:return s[t]}else{if(Qo(n,t))return l[t]=1,n[t];if(o!==Ue&&Re(o,t))return l[t]=2,o[t];if(Re(s,t))return l[t]=3,s[t];if(i!==Ue&&Re(i,t))return l[t]=4,i[t];ks&&(l[t]=0)}}const c=$n[t];let d,f;if(c)return t==="$attrs"&&pt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ue&&Re(i,t))return l[t]=4,i[t];if(f=a.config.globalProperties,Re(f,t))return f[t]},set({_:e},t,i){const{data:n,setupState:o,ctx:s}=e;return Qo(o,t)?(o[t]=i,!0):n!==Ue&&Re(n,t)?(n[t]=i,!0):Re(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||e!==Ue&&r[0]!=="$"&&Re(e,r)||Qo(t,r)||Re(s,r)||Re(n,r)||Re($n,r)||Re(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Re(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function yr(e){return Ie(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let ks=!0;function ou(e){const t=ql(e),i=e.proxy,n=e.ctx;ks=!1,t.beforeCreate&&kr(t.beforeCreate,e,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:f,mounted:g,beforeUpdate:u,updated:m,activated:p,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:_,unmounted:B,render:M,renderTracked:T,renderTriggered:w,errorCaptured:P,serverPrefetch:O,expose:R,inheritAttrs:Y,components:S,directives:F,filters:k}=t;if(c&&su(c,n,null),l)for(const A in l){const D=l[A];Ee(D)&&(n[A]=D.bind(i))}if(o){const A=o.call(i,i);je(A)&&(e.data=Po(A))}if(ks=!0,s)for(const A in s){const D=s[A],z=Ee(D)?D.bind(i,i):Ee(D.get)?D.get.bind(i,i):Zt,Q=!Ee(D)&&Ee(D.set)?D.set.bind(i):Zt,G=ye({get:z,set:Q});Object.defineProperty(n,A,{enumerable:!0,configurable:!0,get:()=>G.value,set:W=>G.value=W})}if(r)for(const A in r)Gl(r[A],n,i,A);if(a){const A=Ee(a)?a.call(i):a;Reflect.ownKeys(A).forEach(D=>{Rd(D,A[D])})}d&&kr(d,e,"c");function N(A,D){Ie(D)?D.forEach(z=>A(z.bind(i))):D&&A(D.bind(i))}if(N(Kd,f),N(un,g),N(Gd,u),N(qd,m),N(Wd,p),N(Ud,b),N(Xd,P),N(Jd,T),N(Yd,w),N(Ks,x),N(No,B),N(Zd,O),Ie(R))if(R.length){const A=e.exposed||(e.exposed={});R.forEach(D=>{Object.defineProperty(A,D,{get:()=>i[D],set:z=>i[D]=z,enumerable:!0})})}else e.exposed||(e.exposed={});M&&e.render===Zt&&(e.render=M),Y!=null&&(e.inheritAttrs=Y),S&&(e.components=S),F&&(e.directives=F),O&&Wl(e)}function su(e,t,i=Zt){Ie(e)&&(e=ws(e));for(const n in e){const o=e[n];let s;je(o)?"default"in o?s=Rt(o.from||n,o.default,!0):s=Rt(o.from||n):s=Rt(o),Ye(s)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[n]=s}}function kr(e,t,i){Ft(Ie(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Gl(e,t,i,n){let o=n.includes(".")?jl(i,n):()=>i[n];if(it(e)){const s=t[e];Ee(s)&&ki(o,s)}else if(Ee(e))ki(o,e.bind(i));else if(je(e))if(Ie(e))e.forEach(s=>Gl(s,t,i,n));else{const s=Ee(e.handler)?e.handler.bind(i):t[e.handler];Ee(s)&&ki(o,s,e)}}function ql(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!o.length&&!i&&!n?a=t:(a={},o.length&&o.forEach(c=>xo(a,c,l,!0)),xo(a,t,l)),je(t)&&s.set(t,a),a}function xo(e,t,i,n=!1){const{mixins:o,extends:s}=t;s&&xo(e,s,i,!0),o&&o.forEach(l=>xo(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=ru[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const ru={data:wr,props:xr,emits:xr,methods:yn,computed:yn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:yn,directives:yn,watch:au,provide:wr,inject:lu};function wr(e,t){return t?e?function(){return dt(Ee(e)?e.call(this,this):e,Ee(t)?t.call(this,this):t)}:t:e}function lu(e,t){return yn(ws(e),ws(t))}function ws(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function yn(e,t){return e?dt(Object.create(null),e,t):t}function xr(e,t){return e?Ie(e)&&Ie(t)?[...new Set([...e,...t])]:dt(Object.create(null),yr(e),yr(t??{})):t}function au(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function Zl(){return{app:null,config:{isNativeTag:fl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let cu=0;function du(e,t){return function(n,o=null){Ee(n)||(n=dt({},n)),o!=null&&!je(o)&&(o=null);const s=Zl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:cu++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:ju,get config(){return s.config},set config(d){},use(d,...f){return l.has(d)||(d&&Ee(d.install)?(l.add(d),d.install(c,...f)):Ee(d)&&(l.add(d),d(c,...f))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,f){return f?(s.components[d]=f,c):s.components[d]},directive(d,f){return f?(s.directives[d]=f,c):s.directives[d]},mount(d,f,g){if(!a){const u=c._ceVNode||ae(n,o);return u.appContext=s,g===!0?g="svg":g===!1&&(g=void 0),e(u,d,g),a=!0,c._container=d,d.__vue_app__=c,Ho(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Ft(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,f){return s.provides[d]=f,c},runWithContext(d){const f=nn;nn=c;try{return d()}finally{nn=f}}};return c}}let nn=null;const uu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${xi(t)}Modifiers`];function fu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ue;let o=i;const s=t.startsWith("update:"),l=s&&uu(n,t.slice(7));l&&(l.trim&&(o=i.map(d=>it(d)?d.trim():d)),l.number&&(o=i.map(Mo)));let r,a=n[r=Go(t)]||n[r=Go(wt(t))];!a&&s&&(a=n[r=Go(xi(t))]),a&&Ft(a,e,6,o);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ft(c,e,6,o)}}const pu=new WeakMap;function Yl(e,t,i=!1){const n=i?pu:t.emitsCache,o=n.get(e);if(o!==void 0)return o;const s=e.emits;let l={},r=!1;if(!Ee(e)){const a=c=>{const d=Yl(c,t,!0);d&&(r=!0,dt(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(je(e)&&n.set(e,null),null):(Ie(s)?s.forEach(a=>l[a]=null):dt(l,s),je(e)&&n.set(e,l),l)}function zo(e,t){return!e||!To(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Re(e,t[0].toLowerCase()+t.slice(1))||Re(e,xi(t))||Re(e,t))}function Sr(e){const{type:t,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:f,data:g,setupState:u,ctx:m,inheritAttrs:p}=e,b=ko(e);let y,x;try{if(i.shapeFlag&4){const B=o||n,M=B;y=Vt(c.call(M,B,d,f,u,g,m)),x=r}else{const B=t;y=Vt(B.length>1?B(f,{attrs:r,slots:l,emit:a}):B(f,null)),x=t.props?r:hu(r)}}catch(B){ni.length=0,Oo(B,e,1),y=ae(ai)}let _=y;if(x&&p!==!1){const B=Object.keys(x),{shapeFlag:M}=_;B.length&&M&7&&(s&&B.some(Eo)&&(x=mu(x,s)),_=rn(_,x,!1,!0))}return i.dirs&&(_=rn(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(i.dirs):i.dirs),i.transition&&Vs(_,i.transition),y=_,ko(b),y}const hu=e=>{let t;for(const i in e)(i==="class"||i==="style"||To(i))&&((t||(t={}))[i]=e[i]);return t},mu=(e,t)=>{const i={};for(const n in e)(!Eo(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function gu(e,t,i){const{props:n,children:o,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?_r(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let f=0;f<d.length;f++){const g=d[f];if(Jl(l,n,g)&&!zo(c,g))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?_r(n,l,c):!0:!!l;return!1}function _r(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Jl(t,e,s)&&!zo(i,s))return!0}return!1}function Jl(e,t,i){const n=e[i],o=t[i];return i==="style"&&je(n)&&je(o)?!dn(n,o):n!==o}function vu({vnode:e,parent:t,suspense:i},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.suspense.vnode.el=o.el=n,e=o),o===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Xl={},Ql=()=>Object.create(Xl),ea=e=>Object.getPrototypeOf(e)===Xl;function bu(e,t,i,n=!1){const o={},s=Ql();e.propsDefaults=Object.create(null),ta(e,t,o,s);for(const l in e.propsOptions[0])l in o||(o[l]=void 0);i?e.props=n?o:Cd(o):e.type.props?e.props=o:e.props=s,e.attrs=s}function yu(e,t,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=e,r=Oe(o),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let f=0;f<d.length;f++){let g=d[f];if(zo(e.emitsOptions,g))continue;const u=t[g];if(a)if(Re(s,g))u!==s[g]&&(s[g]=u,c=!0);else{const m=wt(g);o[m]=xs(a,r,m,u,e,!1)}else u!==s[g]&&(s[g]=u,c=!0)}}}else{ta(e,t,o,s)&&(c=!0);let d;for(const f in r)(!t||!Re(t,f)&&((d=xi(f))===f||!Re(t,d)))&&(a?i&&(i[f]!==void 0||i[d]!==void 0)&&(o[f]=xs(a,r,f,void 0,e,!0)):delete o[f]);if(s!==r)for(const f in s)(!t||!Re(t,f))&&(delete s[f],c=!0)}c&&ti(e.attrs,"set","")}function ta(e,t,i,n){const[o,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(xn(a))continue;const c=t[a];let d;o&&Re(o,d=wt(a))?!s||!s.includes(d)?i[d]=c:(r||(r={}))[d]=c:zo(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Oe(i),c=r||Ue;for(let d=0;d<s.length;d++){const f=s[d];i[f]=xs(o,a,f,c[f],e,!Re(c,f))}}return l}function xs(e,t,i,n,o,s){const l=e[i];if(l!=null){const r=Re(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ee(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const d=Un(o);n=c[i]=a.call(null,t),d()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===xi(i))&&(n=!0))}return n}const ku=new WeakMap;function ia(e,t,i=!1){const n=i?ku:t.propsCache,o=n.get(e);if(o)return o;const s=e.props,l={},r=[];let a=!1;if(!Ee(e)){const d=f=>{a=!0;const[g,u]=ia(f,t,!0);dt(l,g),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!a)return je(e)&&n.set(e,Xi),Xi;if(Ie(s))for(let d=0;d<s.length;d++){const f=wt(s[d]);Cr(f)&&(l[f]=Ue)}else if(s)for(const d in s){const f=wt(d);if(Cr(f)){const g=s[d],u=l[f]=Ie(g)||Ee(g)?{type:g}:dt({},g),m=u.type;let p=!1,b=!0;if(Ie(m))for(let y=0;y<m.length;++y){const x=m[y],_=Ee(x)&&x.name;if(_==="Boolean"){p=!0;break}else _==="String"&&(b=!1)}else p=Ee(m)&&m.name==="Boolean";u[0]=p,u[1]=b,(p||Re(u,"default"))&&r.push(f)}}const c=[l,r];return je(e)&&n.set(e,c),c}function Cr(e){return e[0]!=="$"&&!xn(e)}const Gs=e=>e==="_"||e==="_ctx"||e==="$stable",qs=e=>Ie(e)?e.map(Vt):[Vt(e)],wu=(e,t,i)=>{if(t._n)return t;const n=Fl((...o)=>qs(t(...o)),i);return n._c=!1,n},na=(e,t,i)=>{const n=e._ctx;for(const o in e){if(Gs(o))continue;const s=e[o];if(Ee(s))t[o]=wu(o,s,n);else if(s!=null){const l=qs(s);t[o]=()=>l}}},oa=(e,t)=>{const i=qs(t);e.slots.default=()=>i},sa=(e,t,i)=>{for(const n in t)(i||!Gs(n))&&(e[n]=t[n])},xu=(e,t,i)=>{const n=e.slots=Ql();if(e.vnode.shapeFlag&32){const o=t._;o?(sa(n,t,i),i&&gl(n,"_",o,!0)):na(t,n)}else t&&oa(e,t)},Su=(e,t,i)=>{const{vnode:n,slots:o}=e;let s=!0,l=Ue;if(n.shapeFlag&32){const r=t._;r?i&&r===1?s=!1:sa(o,t,i):(s=!t.$stable,na(t,o)),l=t}else t&&(oa(e,t),l={default:1});if(s)for(const r in o)!Gs(r)&&l[r]==null&&delete o[r]},St=Tu;function _u(e){return Cu(e)}function Cu(e,t){const i=Do();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:f,nextSibling:g,setScopeId:u=Zt,insertStaticContent:m}=e,p=(L,j,v,V=null,H=null,$=null,I=void 0,C=null,U=!!j.dynamicChildren)=>{if(L===j)return;L&&!vn(L,j)&&(V=$e(L),W(L,H,$,!0),L=null),j.patchFlag===-2&&(U=!1,j.dynamicChildren=null);const{type:q,ref:K,shapeFlag:ie}=j;switch(q){case Fo:b(L,j,v,V);break;case ai:y(L,j,v,V);break;case no:L==null&&x(j,v,V,I);break;case Ve:S(L,j,v,V,H,$,I,C,U);break;default:ie&1?M(L,j,v,V,H,$,I,C,U):ie&6?F(L,j,v,V,H,$,I,C,U):(ie&64||ie&128)&&q.process(L,j,v,V,H,$,I,C,U,X)}K!=null&&H?Cn(K,L&&L.ref,$,j||L,!j):K==null&&L&&L.ref!=null&&Cn(L.ref,null,$,L,!0)},b=(L,j,v,V)=>{if(L==null)n(j.el=r(j.children),v,V);else{const H=j.el=L.el;j.children!==L.children&&c(H,j.children)}},y=(L,j,v,V)=>{L==null?n(j.el=a(j.children||""),v,V):j.el=L.el},x=(L,j,v,V)=>{[L.el,L.anchor]=m(L.children,j,v,V,L.el,L.anchor)},_=({el:L,anchor:j},v,V)=>{let H;for(;L&&L!==j;)H=g(L),n(L,v,V),L=H;n(j,v,V)},B=({el:L,anchor:j})=>{let v;for(;L&&L!==j;)v=g(L),o(L),L=v;o(j)},M=(L,j,v,V,H,$,I,C,U)=>{if(j.type==="svg"?I="svg":j.type==="math"&&(I="mathml"),L==null)T(j,v,V,H,$,I,C,U);else{const q=L.el&&L.el._isVueCE?L.el:null;try{q&&q._beginPatch(),O(L,j,H,$,I,C,U)}finally{q&&q._endPatch()}}},T=(L,j,v,V,H,$,I,C)=>{let U,q;const{props:K,shapeFlag:ie,transition:Z,dirs:J}=L;if(U=L.el=l(L.type,$,K&&K.is,K),ie&8?d(U,L.children):ie&16&&P(L.children,U,null,V,H,es(L,$),I,C),J&&_i(L,null,V,"created"),w(U,L,L.scopeId,I,V),K){for(const Se in K)Se!=="value"&&!xn(Se)&&s(U,Se,null,K[Se],$,V);"value"in K&&s(U,"value",null,K.value,$),(q=K.onVnodeBeforeMount)&&jt(q,V,L)}J&&_i(L,null,V,"beforeMount");const de=$u(H,Z);de&&Z.beforeEnter(U),n(U,j,v),((q=K&&K.onVnodeMounted)||de||J)&&St(()=>{try{q&&jt(q,V,L),de&&Z.enter(U),J&&_i(L,null,V,"mounted")}finally{}},H)},w=(L,j,v,V,H)=>{if(v&&u(L,v),V)for(let $=0;$<V.length;$++)u(L,V[$]);if(H){let $=H.subTree;if(j===$||ca($.type)&&($.ssContent===j||$.ssFallback===j)){const I=H.vnode;w(L,I,I.scopeId,I.slotScopeIds,H.parent)}}},P=(L,j,v,V,H,$,I,C,U=0)=>{for(let q=U;q<L.length;q++){const K=L[q]=C?ei(L[q]):Vt(L[q]);p(null,K,j,v,V,H,$,I,C)}},O=(L,j,v,V,H,$,I)=>{const C=j.el=L.el;let{patchFlag:U,dynamicChildren:q,dirs:K}=j;U|=L.patchFlag&16;const ie=L.props||Ue,Z=j.props||Ue;let J;if(v&&Ci(v,!1),(J=Z.onVnodeBeforeUpdate)&&jt(J,v,j,L),K&&_i(j,L,v,"beforeUpdate"),v&&Ci(v,!0),q&&(!L.dynamicChildren||L.dynamicChildren.length!==q.length)&&(U=0,I=!1,q=null),(ie.innerHTML&&Z.innerHTML==null||ie.textContent&&Z.textContent==null)&&d(C,""),q?R(L.dynamicChildren,q,C,v,V,es(j,H),$):I||D(L,j,C,null,v,V,es(j,H),$,!1),U>0){if(U&16)Y(C,ie,Z,v,H);else if(U&2&&ie.class!==Z.class&&s(C,"class",null,Z.class,H),U&4&&s(C,"style",ie.style,Z.style,H),U&8){const de=j.dynamicProps;for(let Se=0;Se<de.length;Se++){const xe=de[Se],Ae=ie[xe],ze=Z[xe];(ze!==Ae||xe==="value")&&s(C,xe,Ae,ze,H,v)}}U&1&&L.children!==j.children&&d(C,j.children)}else!I&&q==null&&Y(C,ie,Z,v,H);((J=Z.onVnodeUpdated)||K)&&St(()=>{J&&jt(J,v,j,L),K&&_i(j,L,v,"updated")},V)},R=(L,j,v,V,H,$,I)=>{for(let C=0;C<j.length;C++){const U=L[C],q=j[C],K=U.el&&(U.type===Ve||!vn(U,q)||U.shapeFlag&198)?f(U.el):v;p(U,q,K,null,V,H,$,I,!0)}},Y=(L,j,v,V,H)=>{if(j!==v){if(j!==Ue)for(const $ in j)!xn($)&&!($ in v)&&s(L,$,j[$],null,H,V);for(const $ in v){if(xn($))continue;const I=v[$],C=j[$];I!==C&&$!=="value"&&s(L,$,C,I,H,V)}"value"in v&&s(L,"value",j.value,v.value,H)}},S=(L,j,v,V,H,$,I,C,U)=>{const q=j.el=L?L.el:r(""),K=j.anchor=L?L.anchor:r("");let{patchFlag:ie,dynamicChildren:Z,slotScopeIds:J}=j;J&&(C=C?C.concat(J):J),L==null?(n(q,v,V),n(K,v,V),P(j.children||[],v,K,H,$,I,C,U)):ie>0&&ie&64&&Z&&L.dynamicChildren&&L.dynamicChildren.length===Z.length?(R(L.dynamicChildren,Z,v,H,$,I,C),(j.key!=null||H&&j===H.subTree)&&ra(L,j,!0)):D(L,j,v,K,H,$,I,C,U)},F=(L,j,v,V,H,$,I,C,U)=>{j.slotScopeIds=C,L==null?j.shapeFlag&512?H.ctx.activate(j,v,V,I,U):k(j,v,V,H,$,I,U):E(L,j,U)},k=(L,j,v,V,H,$,I)=>{const C=L.component=Lu(L,V,H);if(Ul(L)&&(C.ctx.renderer=X),Ou(C,!1,I),C.asyncDep){if(H&&H.registerDep(C,N,I),!L.el){const U=C.subTree=ae(ai);y(null,U,j,v),L.placeholder=U.el}}else N(C,L,j,v,H,$,I)},E=(L,j,v)=>{const V=j.component=L.component;if(gu(L,j,v))if(V.asyncDep&&!V.asyncResolved){A(V,j,v);return}else V.next=j,V.update();else j.el=L.el,V.vnode=j},N=(L,j,v,V,H,$,I)=>{const C=()=>{if(L.isMounted){let{next:ie,bu:Z,u:J,parent:de,vnode:Se}=L;{const Je=la(L);if(Je){ie&&(ie.el=Se.el,A(L,ie,I)),Je.asyncDep.then(()=>{St(()=>{L.isUnmounted||q()},H)});return}}let xe=ie,Ae;Ci(L,!1),ie?(ie.el=Se.el,A(L,ie,I)):ie=Se,Z&&io(Z),(Ae=ie.props&&ie.props.onVnodeBeforeUpdate)&&jt(Ae,de,ie,Se),Ci(L,!0);const ze=Sr(L),qe=L.subTree;L.subTree=ze,p(qe,ze,f(qe.el),$e(qe),L,H,$),ie.el=ze.el,xe===null&&vu(L,ze.el),J&&St(J,H),(Ae=ie.props&&ie.props.onVnodeUpdated)&&St(()=>jt(Ae,de,ie,Se),H)}else{let ie;const{el:Z,props:J}=j,{bm:de,m:Se,parent:xe,root:Ae,type:ze}=L,qe=tn(j);Ci(L,!1),de&&io(de),!qe&&(ie=J&&J.onVnodeBeforeMount)&&jt(ie,xe,j),Ci(L,!0);{Ae.ce&&Ae.ce._hasShadowRoot()&&Ae.ce._injectChildStyle(ze,L.parent?L.parent.type:void 0);const Je=L.subTree=Sr(L);p(null,Je,v,V,L,H,$),j.el=Je.el}if(Se&&St(Se,H),!qe&&(ie=J&&J.onVnodeMounted)){const Je=j;St(()=>jt(ie,xe,Je),H)}(j.shapeFlag&256||xe&&tn(xe.vnode)&&xe.vnode.shapeFlag&256)&&L.a&&St(L.a,H),L.isMounted=!0,j=v=V=null}};L.scope.on();const U=L.effect=new kl(C);L.scope.off();const q=L.update=U.run.bind(U),K=L.job=U.runIfDirty.bind(U);K.i=L,K.id=L.uid,U.scheduler=()=>Us(K),Ci(L,!0),q()},A=(L,j,v)=>{j.component=L;const V=L.vnode.props;L.vnode=j,L.next=null,yu(L,j.props,V,v),Su(L,j.children,v),si(),mr(L),ri()},D=(L,j,v,V,H,$,I,C,U=!1)=>{const q=L&&L.children,K=L?L.shapeFlag:0,ie=j.children,{patchFlag:Z,shapeFlag:J}=j;if(Z>0){if(Z&128){Q(q,ie,v,V,H,$,I,C,U);return}else if(Z&256){z(q,ie,v,V,H,$,I,C,U);return}}J&8?(K&16&&me(q,H,$),ie!==q&&d(v,ie)):K&16?J&16?Q(q,ie,v,V,H,$,I,C,U):me(q,H,$,!0):(K&8&&d(v,""),J&16&&P(ie,v,V,H,$,I,C,U))},z=(L,j,v,V,H,$,I,C,U)=>{L=L||Xi,j=j||Xi;const q=L.length,K=j.length,ie=Math.min(q,K);let Z;for(Z=0;Z<ie;Z++){const J=j[Z]=U?ei(j[Z]):Vt(j[Z]);p(L[Z],J,v,null,H,$,I,C,U)}q>K?me(L,H,$,!0,!1,ie):P(j,v,V,H,$,I,C,U,ie)},Q=(L,j,v,V,H,$,I,C,U)=>{let q=0;const K=j.length;let ie=L.length-1,Z=K-1;for(;q<=ie&&q<=Z;){const J=L[q],de=j[q]=U?ei(j[q]):Vt(j[q]);if(vn(J,de))p(J,de,v,null,H,$,I,C,U);else break;q++}for(;q<=ie&&q<=Z;){const J=L[ie],de=j[Z]=U?ei(j[Z]):Vt(j[Z]);if(vn(J,de))p(J,de,v,null,H,$,I,C,U);else break;ie--,Z--}if(q>ie){if(q<=Z){const J=Z+1,de=J<K?j[J].el:V;for(;q<=Z;)p(null,j[q]=U?ei(j[q]):Vt(j[q]),v,de,H,$,I,C,U),q++}}else if(q>Z)for(;q<=ie;)W(L[q],H,$,!0),q++;else{const J=q,de=q,Se=new Map;for(q=de;q<=Z;q++){const rt=j[q]=U?ei(j[q]):Vt(j[q]);rt.key!=null&&Se.set(rt.key,q)}let xe,Ae=0;const ze=Z-de+1;let qe=!1,Je=0;const Le=new Array(ze);for(q=0;q<ze;q++)Le[q]=0;for(q=J;q<=ie;q++){const rt=L[q];if(Ae>=ze){W(rt,H,$,!0);continue}let Xe;if(rt.key!=null)Xe=Se.get(rt.key);else for(xe=de;xe<=Z;xe++)if(Le[xe-de]===0&&vn(rt,j[xe])){Xe=xe;break}Xe===void 0?W(rt,H,$,!0):(Le[Xe-de]=q+1,Xe>=Je?Je=Xe:qe=!0,p(rt,j[Xe],v,null,H,$,I,C,U),Ae++)}const Jt=qe?Iu(Le):Xi;for(xe=Jt.length-1,q=ze-1;q>=0;q--){const rt=de+q,Xe=j[rt],Ht=j[rt+1],Fi=rt+1<K?Ht.el||aa(Ht):V;Le[q]===0?p(null,Xe,v,Fi,H,$,I,C,U):qe&&(xe<0||q!==Jt[xe]?G(Xe,v,Fi,2):xe--)}}},G=(L,j,v,V,H=null)=>{const{el:$,type:I,transition:C,children:U,shapeFlag:q}=L;if(q&6){G(L.component.subTree,j,v,V);return}if(q&128){L.suspense.move(j,v,V);return}if(q&64){I.move(L,j,v,X);return}if(I===Ve){n($,j,v);for(let ie=0;ie<U.length;ie++)G(U[ie],j,v,V);n(L.anchor,j,v);return}if(I===no){_(L,j,v);return}if(V!==2&&q&1&&C)if(V===0)C.persisted&&!$[Xo]?n($,j,v):(C.beforeEnter($),n($,j,v),St(()=>C.enter($),H));else{const{leave:ie,delayLeave:Z,afterLeave:J}=C,de=()=>{L.ctx.isUnmounted?o($):n($,j,v)},Se=()=>{const xe=$._isLeaving||!!$[Xo];$._isLeaving&&$[Xo](!0),C.persisted&&!xe?de():ie($,()=>{de(),J&&J()})};Z?Z($,de,Se):Se()}else n($,j,v)},W=(L,j,v,V=!1,H=!1)=>{const{type:$,props:I,ref:C,children:U,dynamicChildren:q,shapeFlag:K,patchFlag:ie,dirs:Z,cacheIndex:J,memo:de}=L;if(ie===-2&&(H=!1),C!=null&&(si(),Cn(C,null,v,L,!0),ri()),J!=null&&(j.renderCache[J]=void 0),K&256){j.ctx.deactivate(L);return}const Se=K&1&&Z,xe=!tn(L);let Ae;if(xe&&(Ae=I&&I.onVnodeBeforeUnmount)&&jt(Ae,j,L),K&6)le(L.component,v,V);else{if(K&128){L.suspense.unmount(v,V);return}Se&&_i(L,null,j,"beforeUnmount"),K&64?L.type.remove(L,j,v,X,V):q&&!q.hasOnce&&($!==Ve||ie>0&&ie&64)?me(q,j,v,!1,!0):($===Ve&&ie&384||!H&&K&16)&&me(U,j,v),V&&oe(L)}const ze=de!=null&&J==null;(xe&&(Ae=I&&I.onVnodeUnmounted)||Se||ze)&&St(()=>{Ae&&jt(Ae,j,L),Se&&_i(L,null,j,"unmounted"),ze&&(L.el=null)},v)},oe=L=>{const{type:j,el:v,anchor:V,transition:H}=L;if(j===Ve){re(v,V);return}if(j===no){B(L);return}const $=()=>{o(v),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(L.shapeFlag&1&&H&&!H.persisted){const{leave:I,delayLeave:C}=H,U=()=>I(v,$);C?C(L.el,$,U):U()}else $()},re=(L,j)=>{let v;for(;L!==j;)v=g(L),o(L),L=v;o(j)},le=(L,j,v)=>{const{bum:V,scope:H,job:$,subTree:I,um:C,m:U,a:q}=L;$r(U),$r(q),V&&io(V),H.stop(),$&&($.flags|=8,W(I,L,j,v)),C&&St(C,j),St(()=>{L.isUnmounted=!0},j)},me=(L,j,v,V=!1,H=!1,$=0)=>{for(let I=$;I<L.length;I++)W(L[I],j,v,V,H)},$e=L=>{if(L.shapeFlag&6)return $e(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const j=g(L.anchor||L.el),v=j&&j[Hd];return v?g(v):j};let ke=!1;const ce=(L,j,v)=>{let V;L==null?j._vnode&&(W(j._vnode,null,null,!0),V=j._vnode.component):p(j._vnode||null,L,j,null,null,null,v),j._vnode=L,ke||(ke=!0,mr(V),Rl(),ke=!1)},X={p,um:W,m:G,r:oe,mt:k,mc:P,pc:D,pbc:R,n:$e,o:e};return{render:ce,hydrate:void 0,createApp:du(ce)}}function es({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Ci({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function $u(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function ra(e,t,i=!1){const n=e.children,o=t.children;if(Ie(n)&&Ie(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=ei(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&ra(l,r)),r.type===Fo&&(r.patchFlag===-1&&(r=o[s]=ei(r)),r.el=l.el),r.type===ai&&!r.el&&(r.el=l.el)}}function Iu(e){const t=e.slice(),i=[0];let n,o,s,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(o=i[i.length-1],e[o]<c){t[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,e[i[r]]<c?s=r+1:l=r;c<e[i[s]]&&(s>0&&(t[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=t[l];return i}function la(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:la(t)}function $r(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function aa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?aa(t.subTree):null}const ca=e=>e.__isSuspense;function Tu(e,t){t&&t.pendingBranch?Ie(e)?t.effects.push(...e):t.effects.push(e):Od(e)}const Ve=Symbol.for("v-fgt"),Fo=Symbol.for("v-txt"),ai=Symbol.for("v-cmt"),no=Symbol.for("v-stc"),ni=[];let It=null;function te(e=!1){ni.push(It=e?null:[])}function Zs(){ni.pop(),It=ni[ni.length-1]||null}let Nn=1;function Ir(e,t=!1){Nn+=e,e<0&&It&&t&&(It.hasOnce=!0)}function da(e){return e.dynamicChildren=Nn>0?It||Xi:null,Zs(),Nn>0&&It&&It.push(e),e}function ne(e,t,i,n,o,s){return da(h(e,t,i,n,o,s,!0))}function Pt(e,t,i,n,o){return da(ae(e,t,i,n,o,!0))}function Ys(e){return e?e.__v_isVNode===!0:!1}function vn(e,t){return e.type===t.type&&e.key===t.key}const ua=({key:e})=>e??null,oo=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Ye(e)||Ee(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function h(e,t=null,i=null,n=0,o=null,s=e===Ve?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&ua(t),ref:t&&oo(t),scopeId:zl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ct};return r?(So(a,i),s&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),Nn>0&&!l&&It&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&It.push(a),a}const ae=Eu;function Eu(e,t=null,i=null,n=0,o=null,s=!1){if((!e||e===tu)&&(e=ai),Ys(e)){const r=rn(e,t,!0);return i&&So(r,i),Nn>0&&!s&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Hu(e)&&(e=e.__vccOpts),t){t=Au(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=_e(r)),je(a)&&(Ws(a)&&!Ie(a)&&(a=dt({},a)),t.style=Gt(a))}const l=it(e)?1:ca(e)?128:jd(e)?64:je(e)?4:Ee(e)?2:0;return h(e,t,i,n,o,l,s,!0)}function Au(e){return e?Ws(e)||ea(e)?dt({},e):e:null}function rn(e,t,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?Bu(o||{},t):o,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&ua(c),ref:t&&t.ref?i&&s?Ie(s)?s.concat(oo(t)):[s,oo(t)]:oo(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ve?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&rn(e.ssContent),ssFallback:e.ssFallback&&rn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Vs(d,a.clone(d)),d}function $t(e=" ",t=0){return ae(Fo,null,e,t)}function gt(e,t){const i=ae(no,null,e);return i.staticCount=t,i}function Me(e="",t=!1){return t?(te(),Pt(ai,null,e)):ae(ai,null,e)}function Vt(e){return e==null||typeof e=="boolean"?ae(ai):Ie(e)?ae(Ve,null,e.slice()):Ys(e)?ei(e):ae(Fo,null,String(e))}function ei(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:rn(e)}function So(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ie(t))i=16;else if(typeof t=="object")if(n&65){const o=t.default;o&&(o._c&&(o._d=!1),So(e,o()),o._c&&(o._d=!0));return}else{i=32;const o=t._;!o&&!ea(t)?t._ctx=ct:o===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ee(t)){if(n&65){So(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function Bu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const o in n)if(o==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(o==="style")t.style=Gt([t.style,n.style]);else if(To(o)){const s=t[o],l=n[o];l&&s!==l&&!(Ie(s)&&s.includes(l))?t[o]=s?[].concat(s,l):l:l==null&&s==null&&!Eo(o)&&(t[o]=l)}else o!==""&&(t[o]=n[o])}return t}function jt(e,t,i,n=null){Ft(e,t,7,[i,n])}const Mu=Zl();let Du=0;function Lu(e,t,i){const n=e.type,o=(t?t.appContext:e.appContext)||Mu,s={uid:Du++,vnode:e,type:n,parent:t,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new rd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(o.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ia(n,o),emitsOptions:Yl(n,o),emit:null,emitted:null,propsDefaults:Ue,inheritAttrs:n.inheritAttrs,ctx:Ue,data:Ue,props:Ue,attrs:Ue,slots:Ue,refs:Ue,setupState:Ue,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=fu.bind(null,s),e.ce&&e.ce(s),s}let ht=null;const Pu=()=>ht||ct;let _o,Ss;{const e=Do(),t=(i,n)=>{let o;return(o=e[i])||(o=e[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};_o=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),Ss=t("__VUE_SSR_SETTERS__",i=>zn=i)}const Un=e=>{const t=ht;return _o(e),e.scope.on(),()=>{e.scope.off(),_o(t)}},Tr=()=>{ht&&ht.scope.off(),_o(null)};function fa(e){return e.vnode.shapeFlag&4}let zn=!1;function Ou(e,t=!1,i=!1){t&&Ss(t);const{props:n,children:o}=e.vnode,s=fa(e);bu(e,n,s,t),xu(e,o,i||t);const l=s?Ru(e,t):void 0;return t&&Ss(!1),l}function Ru(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,nu);const{setup:n}=i;if(n){si();const o=e.setupContext=n.length>1?zu(e):null,s=Un(e),l=Wn(n,e,0,[e.props,o]),r=pl(l);if(ri(),s(),(r||e.sp)&&!tn(e)&&Wl(e),r){if(l.then(Tr,Tr),t)return l.then(a=>{Er(e,a)}).catch(a=>{Oo(a,e,0)});e.asyncDep=l}else Er(e,l)}else pa(e)}function Er(e,t,i){Ee(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:je(t)&&(e.setupState=Ll(t)),pa(e)}function pa(e,t,i){const n=e.type;e.render||(e.render=n.render||Zt);{const o=Un(e);si();try{ou(e)}finally{ri(),o()}}}const Nu={get(e,t){return pt(e,"get",""),e[t]}};function zu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Nu),slots:e.slots,emit:e.emit,expose:t}}function Ho(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ll($d(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in $n)return $n[i](e)},has(t,i){return i in t||i in $n}})):e.proxy}function Fu(e,t=!0){return Ee(e)?e.displayName||e.name:e.name||t&&e.__name}function Hu(e){return Ee(e)&&"__vccOpts"in e}const ye=(e,t)=>Bd(e,t,zn),ju="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let _s;const Ar=typeof window<"u"&&window.trustedTypes;if(Ar)try{_s=Ar.createPolicy("vue",{createHTML:e=>e})}catch{}const ha=_s?e=>_s.createHTML(e):e=>e,Wu="http://www.w3.org/2000/svg",Uu="http://www.w3.org/1998/Math/MathML",Qt=typeof document<"u"?document:null,Br=Qt&&Qt.createElement("template"),Vu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const o=t==="svg"?Qt.createElementNS(Wu,e):t==="mathml"?Qt.createElementNS(Uu,e):i?Qt.createElement(e,{is:i}):Qt.createElement(e);return e==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:e=>Qt.createTextNode(e),createComment:e=>Qt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Qt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,o,s){const l=i?i.previousSibling:t.lastChild;if(o&&(o===s||o.nextSibling))for(;t.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{Br.innerHTML=ha(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Br.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Ku=Symbol("_vtc");function Gu(e,t,i){const n=e[Ku];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Co=Symbol("_vod"),ma=Symbol("_vsh"),Cs={name:"show",beforeMount(e,{value:t},{transition:i}){e[Co]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):bn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),bn(e,!0),n.enter(e)):n.leave(e,()=>{bn(e,!1)}):bn(e,t))},beforeUnmount(e,{value:t}){bn(e,t)}};function bn(e,t){e.style.display=t?e[Co]:"none",e[ma]=!t}const qu=Symbol(""),Zu=/(?:^|;)\s*display\s*:/;function Yu(e,t,i){const n=e.style,o=it(i);let s=!1;if(i&&!o){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&kn(n,r,"")}else for(const l in t)i[l]==null&&kn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?Xu(e,l,!it(t)&&t?t[l]:void 0,r)||kn(n,l,r):kn(n,l,"")}}else if(o){if(t!==i){const l=n[qu];l&&(i+=";"+l),n.cssText=i,s=Zu.test(i)}}else t&&e.removeAttribute("style");Co in e&&(e[Co]=s?n.display:"",e[ma]&&(n.display="none"))}const Mr=/\s*!important$/;function kn(e,t,i){if(Ie(i))i.forEach(n=>kn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Ju(e,t);Mr.test(i)?e.setProperty(xi(n),i.replace(Mr,""),"important"):e[n]=i}}const Dr=["Webkit","Moz","ms"],ts={};function Ju(e,t){const i=ts[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return ts[t]=n;n=Bo(n);for(let o=0;o<Dr.length;o++){const s=Dr[o]+n;if(s in e)return ts[t]=s}return t}function Xu(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Lr="http://www.w3.org/1999/xlink";function Pr(e,t,i,n,o,s=od(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Lr,t.slice(6,t.length)):e.setAttributeNS(Lr,t,i):i==null||s&&!vl(i)?e.removeAttribute(t):e.setAttribute(t,s?"":Nt(i)?String(i):i)}function Or(e,t,i,n,o){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?ha(i):i);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=vl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(o||t)}function mi(e,t,i,n){e.addEventListener(t,i,n)}function Qu(e,t,i,n){e.removeEventListener(t,i,n)}const Rr=Symbol("_vei");function ef(e,t,i,n,o=null){const s=e[Rr]||(e[Rr]={}),l=s[t];if(n&&l)l.value=n;else{const[r,a]=of(t);if(n){const c=s[t]=lf(n,o);mi(e,r,c,a)}else l&&(Qu(e,r,l,a),s[t]=void 0)}}const tf=/(Once|Passive|Capture)$/,nf=/^on:?(?:Once|Passive|Capture)$/;function of(e){let t,i;for(;(i=e.match(tf))&&!nf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):xi(e.slice(2)),t]}let is=0;const sf=Promise.resolve(),rf=()=>is||(sf.then(()=>is=0),is=Date.now());function lf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if(Ie(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Ft(c,t,5,r)}}else Ft(o,t,5,[n])};return i.value=e,i.attached=rf(),i}const Nr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,af=(e,t,i,n,o,s)=>{const l=o==="svg";t==="class"?Gu(e,n,l):t==="style"?Yu(e,i,n):To(t)?Eo(t)||ef(e,t,i,n,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):cf(e,t,n,l))?(Or(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Pr(e,t,n,l,s,t!=="value")):e._isVueCE&&(df(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Or(e,wt(t),n,s,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Pr(e,t,n,l))};function cf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Nr(t)&&Ee(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const o=e.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Nr(t)&&it(i)?!1:t in e}function df(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(o=>wt(o)===n):Object.keys(i).some(o=>wt(o)===n)}const ln=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ie(t)?i=>io(t,i):t};function uf(e){e.target.composing=!0}function zr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const oi=Symbol("_assign");function Fr(e,t,i){return t&&(e=e.trim()),i&&(e=Mo(e)),e}const $o={created(e,{modifiers:{lazy:t,trim:i,number:n}},o){e[oi]=ln(o);const s=n||o.props&&o.props.type==="number";mi(e,t?"change":"input",l=>{l.target.composing||e[oi](Fr(e.value,i,s))}),(i||s)&&mi(e,"change",()=>{e.value=Fr(e.value,i,s)}),t||(mi(e,"compositionstart",uf),mi(e,"compositionend",zr),mi(e,"change",zr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(e[oi]=ln(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Mo(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||o&&e.value.trim()===a)||(e.value=a)}},Xn={deep:!0,created(e,t,i){e[oi]=ln(i),mi(e,"change",()=>{const n=e._modelValue,o=Fn(e),s=e.checked,l=e[oi];if(Ie(n)){const r=Os(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(cn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(ga(e,s))})},mounted:Hr,beforeUpdate(e,t,i){e[oi]=ln(i),Hr(e,t,i)}};function Hr(e,{value:t,oldValue:i},n){e._modelValue=t;let o;if(Ie(t))o=Os(t,n.props.value)>-1;else if(cn(t))o=t.has(n.props.value);else{if(t===i)return;o=dn(t,ga(e,!0))}e.checked!==o&&(e.checked=o)}const ff={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,mi(e,"change",()=>{const o=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>i?Mo(Fn(s)):Fn(s));e[oi](e.multiple?cn(e._modelValue)?new Set(o):o:o[0]),e._assigning=!0,yo(()=>{e._assigning=!1})}),e[oi]=ln(n)},mounted(e,{value:t}){jr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[oi]=ln(i)},updated(e,{value:t}){e._assigning||jr(e,t)}};function jr(e,t){const i=e.multiple,n=Ie(t);if(!(i&&!n&&!cn(t))){for(let o=0,s=e.options.length;o<s;o++){const l=e.options[o],r=Fn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Os(t,r)>-1}else l.selected=t.has(r);else if(dn(Fn(l),t)){e.selectedIndex!==o&&(e.selectedIndex=o);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Fn(e){return"_value"in e?e._value:e.value}function ga(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const pf=["ctrl","shift","alt","meta"],hf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>pf.some(i=>e[`${i}Key`]&&!t.includes(i))},Lt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<t.length;l++){const r=hf[t[l]];if(r&&r(o,t))return}return e(o,...s)}))},mf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},gf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=xi(o.key);if(t.some(l=>l===s||mf[l]===s))return e(o)}))},vf=dt({patchProp:af},Vu);let Wr;function bf(){return Wr||(Wr=_u(vf))}const Js=((...e)=>{const t=bf().createApp(...e),{mount:i}=t;return t.mount=n=>{const o=kf(n);if(!o)return;const s=t._component;!Ee(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,yf(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},t});function yf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function kf(e){return it(e)?document.querySelector(e):e}const wf="slidev-config.json",an={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},gi=Po({...an});function xf(e){if(!e||typeof e!="object")return{...an};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():an.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Di(e){if(!e||typeof e!="object")return{...gi};const t=e;return t.enableWebServeJump!==void 0&&(gi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(gi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(gi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...gi}}function jo(){return{...gi}}function va(e,t,i){const n=(e||an.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const $i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Sf(e){var i,n,o,s,l,r;const t=jo();return e?{theme:((i=e[An])==null?void 0:i.trim())||$i.theme,aspectRatio:((n=e[Bn])==null?void 0:n.trim())||$i.aspectRatio,highlighter:((o=e[ll])==null?void 0:o.trim())||$i.highlighter,defaultTransition:((s=e[Mn])==null?void 0:s.trim())||$i.defaultTransition,colorSchema:((l=e[al])==null?void 0:l.trim())||$i.colorSchema,spacing:((r=e[ps])==null?void 0:r.trim())||$i.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...$i,normalizeHeadingSizes:t.normalizeHeadingSizes}}function Io(e){var i,n,o,s,l;const t=(i=e.ial)==null?void 0:i[Ai];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((o=e.markdown)==null?void 0:o.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Ur(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[he]&&(t.layout=e[he].trim()),e[tt]&&(t.transition=e[tt].trim()),e[We]&&(t.background=e[We].trim()),e[Dt]&&(t.image=e[Dt].trim()),e[Gi]&&(t.class=e[Gi].trim()),e[wn]&&(t.spacing=e[wn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[qi]&&(t.mask=e[qi].trim()),e[Zi]&&(t.maskRatio=e[Zi].trim()),e[Yi]&&(t.maskStyle=e[Yi].trim()),e[Ji]&&(t.maskInitial=e[Ji].trim()),e[Ki]&&(i=e[Ki].trim());for(const[n,o]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![he,yt,qi,Zi,Yi,Ji,tt,We,Dt,Gi,wn,Ki,Ai].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{t[s]=JSON.parse(o)}catch{t[s]=o}}return{frontmatter:t,notes:i}}function _f(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ge]??e["slidev-role"],o=e[We]??e["slidev-background"];(n===cl||o==="true"||o==="1")&&(t.isBackground=!0);const s=e[he]??e["slidev-layout"];s===mo||s===go?t.imageLayout=s:(n===mo||n===go)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[qt])try{const r=JSON.parse(e[qt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[qt].trim()}}return e[Ni]&&(t.shikiLines=e[Ni].trim()),e[Dn]&&(t.maxHeight=e[Dn].trim()),e[Ce]&&(t.slot=e[Ce].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function wi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function In(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),f=d?d[1].length:0;f>=l?r.push(c.slice(l)):f>o?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function zi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function ns(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Tn(e){if(!e)return[];if(st(e)&&Yt(e)&&!di(e)){const n=fn(e),o=[];for(const s of n)o.push(...Tn(s));return o}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(zi);if(l.length>0)return l}const o=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return zi(e)?[e]:[]}function Xs(e){var o;if(!e||!st(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;if(t.length===1&&st(t[0])&&Yt(t[0])){const s=Xs(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of t)if(st(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(st))||[];i.push(...l)}const n=t.map(Tn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(t.length===2){const s=Tn(t[0]),l=Tn(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function Cf(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Xs(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const o=Qs(e)||void 0,s=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function ba(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;const i=[];for(const n of t){const o=Tn(n);if(o.length===0)return null;i.push(...o)}return i}function $f(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=ba(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function If(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Xs(e);if(t&&t.items.length===4)return t.items;const i=ba(e);if(i&&i.length===4)return i;const n=fn(e);return n.length===4?n:null}function Tf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(st(r)){const c=If(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let o=null;t&&(o=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=e.slice(0,o.topLevelIndex).slice().reverse().find(r=>ya(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function Ef(e,t,i){var d,f,g,u,m;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let p=0;p<t.length;p++){const b=t[p];if(Io(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(p){const b=[];for(const y of p)st(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...a(y.children));return b}function c(p,b,y){const x={blockId:p,attrs:b,previousAttrs:y};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const p of l){const b=p.pageTargetId,y=t.find(T=>T.id===b),x=s.find(T=>T.pageTargetId===b);if(p.blocks.some(T=>{var w,P;return!!(di(T)||$s(T)&&(((w=T.ial)==null?void 0:w[he])==="image-left"||((P=T.ial)==null?void 0:P[he])==="image-right"))})){if(x){const T=x.headerId;if(T){c(T,{[Ce]:""});const w=t.find(P=>P.id===T);w!=null&&w.ial&&(w.ial[Ce]="")}for(const w of x.itemIds){c(w,{[Ce]:""});const P=t.find(O=>O.id===w);P!=null&&P.ial&&(P.ial[Ce]="")}}continue}let B=null,M=-1;for(let T=0;T<p.blocks.length;T++){const w=p.blocks[T],P=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const O of P){const R=Cf(O);if(R){B=R,M=T;break}}if(B)break}if(B){const{superBlockNode:T,layout:w,items:P,slots:O}=B,Y=p.blocks.slice(0,M).find(A=>ya(A)),S=Y==null?void 0:Y.id,F=((d=y==null?void 0:y.ial)==null?void 0:d[he])||"",k=F==="clover",E=k?"clover":w;if(F!==E&&(c(b,{[he]:E},{[he]:F}),y&&(y.ial||(y.ial={}),y.ial[he]=E)),Y){const A=((f=Y.ial)==null?void 0:f[Ce])||"";A!=="header"&&(c(Y.id,{[Ce]:"header"},{[Ce]:A}),Y.ial||(Y.ial={}),Y.ial[Ce]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[Ce]:""});const A=t.find(D=>D.id===x.headerId);A&&(A.ial||(A.ial={}),A.ial[Ce]="")}const N=[];for(let A=0;A<P.length;A++){const D=P[A],z=O[A];N.push(D.id);const Q=((g=D.ial)==null?void 0:g[Ce])||"";if(Q!==z&&(c(D.id,{[Ce]:z},{[Ce]:Q}),D.ial||(D.ial={}),D.ial[Ce]=z),D.children&&D.children.length>0)for(const G of D.children)G.ial||(G.ial={}),G.ial[Ce]!==z&&(G.ial[Ce]=z)}if(x!=null&&x.itemIds){for(const A of x.itemIds)if(!N.includes(A)){c(A,{[Ce]:""});const D=t.find(z=>z.id===A);D&&(D.ial||(D.ial={}),D.ial[Ce]="")}}o.push({superBlockId:T.id,nestedSuperBlockIds:(u=B.nestedSuperBlocks)==null?void 0:u.map(A=>A.id),pageTargetId:b,headerId:S,itemIds:N,layout:k?"clover":w})}else{let T=!1;const w=[];for(const R of p.blocks){const Y=st(R)?[R,...a(R.children||[])]:R.children?a(R.children):[];for(const S of Y){const F=$f(S);if(F){T=!0;for(const k of F.items)w.push(k.id)}}}const P=((m=y==null?void 0:y.ial)==null?void 0:m[he])||"",O=Ln(P);if(x||T&&O){c(b,{[he]:""},{[he]:P}),y&&(y.ial||(y.ial={}),y.ial[he]="");const R=x==null?void 0:x.headerId;if(R){c(R,{[Ce]:""});const S=t.find(F=>F.id===R);S&&(S.ial||(S.ial={}),S.ial[Ce]="")}const Y=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of Y){c(S,{[Ce]:""});const F=t.find(k=>k.id===S);F&&(F.ial||(F.ial={}),F.ial[Ce]="")}}}}return{changes:n,newTracked:o}}function st(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Yt(e){if(!st(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function $s(e){return!e||zi(e)||st(e)||!wi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Qs(e){var g;if(!e||!st(e)||!Yt(e))return null;const t=fn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const m=(((g=u.ial)==null?void 0:g.style)||u.style||"").trim();let p=null;if(m){const b=m.match(/calc\(\s*([\d.]+)%/i);if(b)p=parseFloat(b[1]);else{const y=m.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(p=parseFloat(y[1]))}}p!==null&&!isNaN(p)&&p>0?(i.push(p),n=!0):i.push(null)}if(!n)return null;const o=t.length,s=i.reduce((u,m)=>u+(m||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(u=>u!==null?u:a),d=c.reduce((u,m)=>u+m,0);if(d<=0)return null;const f=c.map(u=>u/d*100);if(f.length===2){const[u]=f;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const m=Math.round(u),p=100-m;return`${m}:${p}`}if(f.length===3){const[u,m,p]=f;if(u>=31&&u<=35&&m>=31&&m<=35&&p>=31&&p<=35)return"1:1:1";if(u>=23&&u<=27&&m>=48&&m<=52&&p>=23&&p<=27)return"1:2:1";if(u>=48&&u<=52&&m>=23&&m<=27&&p>=23&&p<=27)return"2:1:1";if(u>=23&&u<=27&&m>=23&&m<=27&&p>=48&&p<=52)return"1:1:2";if(u>=18&&u<=22&&m>=58&&m<=62&&p>=18&&p<=22)return"1:3:1";const b=Math.round(u),y=Math.round(m),x=100-b-y;return`${b}:${y}:${x}`}return f.map(u=>Math.round(u)).join(":")}function di(e){if(!e||!st(e)||!Yt(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=$s(t[0]),n=$s(t[t.length-1]),o=Qs(e)||void 0;if(i&&!n){const s=wi(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:mo,contentNodes:t.slice(1),ratio:o}}if(!i&&n){const s=wi(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:go,contentNodes:t.slice(0,t.length-1),ratio:o}}return null}function Af(e,t){const i=[];function n(o){for(const s of o){const l=di(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[he];if(d!==a){const g={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[he]=a,i.push(g),t&&t(g)}}s.children&&s.children.length>0&&n(s.children)}}return n(e),i}function fn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ya(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ii(e,t,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<e.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(o);break}n+=e.slice(o,a);const d=a+c;let f=1,g=-1,u=-1;const m=/<\/?div\b[^>]*>/gi;m.lastIndex=d;let p;for(;(p=m.exec(e))!==null;)if(p[0].startsWith("</")){if(f--,f===0){g=p.index,u=p.index+p[0].length;break}}else f++;if(g!==-1&&u!==-1){const b=e.slice(d,g);n+=i(b),o=u}else n+=e.slice(a,d),o=d}return n}function Bf(e){const t=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(e))!==null;){const p=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(p)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,f=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let m;for(;(m=u.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){f=m.index,g=m.index+m[0].length;break}}else d++;if(f!==-1&&g!==-1){const p=e.slice(r,g),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(p),i+=b,n=g}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Mf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Bf(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ii(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),f=c[3].trim();return`**${d}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=Ii(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ii(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let f="-";return d.includes("warn")?f="- ⚠️":d.includes("bad")?f="- ❌":d.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ii(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ii(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ii(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ii(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,g)=>Math.max(f,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,f)=>{const g=f.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ka(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>t[parseInt(o,10)]||""),i}function Df(e){const t=Object.entries(e).filter(([n,o])=>o!=null&&o!=="");return t.length===0?"":`---
${t.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function Lf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),o=e.slice(i);return n.includes("{")?e:`${n} {${t}}${o}`}function wa(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Pf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const o={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(o.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(o.delay=e.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Qn(e,t,i,n){const o=t!=null&&t.trim()!=="",s=Pf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${e}

</div>`:e;if(o&&!s){if(r){const m=t.trim();let p="v-click";return m==="hide"?p="v-click.hide":m!==""&&m!=="+1"&&(p=`v-click="${m}"`),`<div ${p}${a}>

${e}

</div>`}return wa(e,t)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),f=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${f}${a}>

${e}

</div>`;const g=t.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${f}${a}>

${e}

</div>`}function xa(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let o=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Of(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Sa(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),f=Math.min(i,c.length),g=Math.floor(c.length/f),u=c.length%f;let m=0;for(let p=0;p<f;p++){const b=g+(p<u?1:0);d[p]=c.slice(m,m+b),m+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const f=d.match(/^col-(\d+)$/i);if(f){const g=parseInt(f[1],10);if(g>=1&&g<=i)return g}return null},o=e.map(n);if(o.some(c=>c!==null)){if(o.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let m=1;for(const p of e){const b=n(p);b!==null&&(m=b),u[m-1].push(p)}return u}const d=e.filter(u=>n(u)===1),f=e.filter(u=>n(u)===null),g=i-1;if(f.length>=g){const u=Math.floor(f.length/g),m=f.length%g,p=[d];let b=0;for(let y=0;y<g;y++){const x=u+(y<m?1:0);p.push(f.slice(b,b+x)),b+=x}return p}else if(f.length>0){const u=[d];for(let m=0;m<g;m++)u.push(m<f.length?[f[m]]:[]);return u}else return[d,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const f=r[d],g=d+1<i?r[d+1]:e.length;c[d]=e.slice(f,g)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let f=0;f<i;f++){const g=i-f,u=e.length-d,m=Math.ceil(u/g);c[f]=e.slice(d,d+m),d+=m}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),f=d.split(/\r?\n/),g=[];for(let p=0;p<f.length;p++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(f[p])&&g.push(p);if(g.length>=i){const p=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=g.length-b,B=Math.ceil(_/x),M=g[b],T=b+B<g.length?g[b+B]:f.length,w=f.slice(M,T).join(`
`);p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:w,content:w}],b+=B}return p}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const p=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=u.length-b,B=Math.ceil(_/x),M=`<ul>
${u.slice(b,b+B).join(`
`)}
</ul>`;p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:M,content:M}],b+=B}return p}const m=d.split(/\r?\n\s*\r?\n/).filter(p=>p.trim()!=="");if(m.length>=i){const p=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=m.length-b,B=Math.ceil(_/x),M=m.slice(b,b+B).join(`

`);p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:M,content:M}],b+=B}return p}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Vr(e,t,i,n){var d;const o=Sf(t),s=[],l=Ur(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),s.push(r);let a=[];for(const f of i){if(Io(f)){a=[];const u=Ur(f.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=f.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(f.id)||r.allBlockIds.push(f.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:f.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[f.id]},r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),s.push(r);continue}const g=(u,m)=>{var N,A,D,z;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const Q=G=>{for(const W of G)W.id&&!r.allBlockIds.includes(W.id)&&r.allBlockIds.push(W.id),W.children&&W.children.length>0&&Q(W.children)};Q(u.children)}let p=Kc(u),b=u.ial?{...u.ial}:{};const y=p.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...Gc(y[0]),...b},p=p.slice(0,y.index).trim()),u.type!=="c"&&!p.startsWith("```")&&(p=ka(p));let x=p.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(p=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=p.trim());const _=_f(b);if(p=qc(p,n),p=Uc(p,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const Q=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],G=W=>{for(const oe of W){if(oe.ial)for(const[re,le]of Object.entries(oe.ial))Q.includes(re)&&!b[re]&&(b[re]=le);oe.children&&oe.children.length>0&&G(oe.children)}};G(u.children)}const B=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(p);if(B){const Q=b["custom-slidev-autoplay"]==="true",G=b["custom-slidev-loop"]==="true",W=b["custom-slidev-muted"]==="true"||Q,oe=b["custom-slidev-controls"]==="false";p=p.replace(/<video\b([^>]*)>/gi,(re,le)=>{let me=le;return oe?me=me.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(me)||(me+=" controls"),Q&&!/autoplay/i.test(me)?me+=" autoplay playsinline":!Q&&b["custom-slidev-autoplay"]==="false"&&(me=me.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),G&&!/loop/i.test(me)?me+=" loop":!G&&b["custom-slidev-loop"]==="false"&&(me=me.replace(/\bloop\b/gi,"").trim()),W&&!/muted/i.test(me)?me+=" muted":!W&&b["custom-slidev-muted"]==="false"&&(me=me.replace(/\bmuted\b/gi,"").trim()),`<video ${me.trim()}>`})}if(_.isBackground){const Q=wi(p,u.content);if(Q){r.frontmatter.background=Tt(Q,n);return}}const M=di(u);if(M){r.frontmatter.layout=M.layout,r.frontmatter.image=Tt(M.imageUrl,n),!r.frontmatter.layoutRatio&&M.ratio&&(r.frontmatter.layoutRatio=M.ratio);for(const Q of M.contentNodes)g(Q);return}if(_.imageLayout==="image-left"||_.imageLayout==="image-right"){const Q=wi(p,u.content);if(Q){r.frontmatter.layout=_.imageLayout,r.frontmatter.image=Tt(Q,n),!r.frontmatter.layoutRatio&&((N=u.ial)!=null&&N[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const Q of u.children)g(Q);return}const T=!!(_.slot||m!=null&&m.defaultSlot||r.frontmatter.layout==="clover"||Ln(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(Q=>{var G,W;return((G=Q.ial)==null?void 0:G[Ce])||((W=Q.ial)==null?void 0:W[Ze])})||_.slot||_.clicks||T)){for(const Q of u.children)_.slot&&(!Q.ial||!Q.ial[Ce])&&(Q.ial||(Q.ial={}),Q.ial[Ce]=_.slot),g(Q,{...m,parentClicks:_.clicks||(m==null?void 0:m.parentClicks),defaultSlot:_.slot||(m==null?void 0:m.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!_.clicks||!!((A=u.children)!=null&&A.some(Q=>{var G;return(G=Q.ial)==null?void 0:G[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(zi(u)&&u.children&&u.children.length>0&&(T||_.clicks||u.children.some(Q=>{var G;return(G=Q.ial)==null?void 0:G[Ze]}))&&w){const Q=!!(u.children&&u.children.length>=2),G=u.children.find(ke=>!!(ke.markdown||ke.content||"").trim())||u.children[0],W=((D=G==null?void 0:G.ial)==null?void 0:D[Ze])||((z=G==null?void 0:G.ial)==null?void 0:z["custom-slidev-click"]),oe=!!(!_.clicks&&Q&&W),re=_.clicks||(oe?W:void 0)||(m==null?void 0:m.parentClicks),le=u.id||(m==null?void 0:m.parentContainerId),me=_.slot||(m==null?void 0:m.defaultSlot);let $e=!0;for(const ke of u.children){me&&(!ke.ial||!ke.ial[Ce])&&(ke.ial||(ke.ial={}),ke.ial[Ce]=me);const ce=!!(ke.markdown||ke.content||"").trim(),X=$e&&ce;X&&(ke.markdown&&(ke.markdown=In(ke.markdown)),ke.content&&(ke.content=In(ke.content)),$e=!1);let se=ke;X&&re&&Q&&(se={...ke,ial:{...ke.ial||{}}},delete se.ial[Ze],delete se.ial["custom-slidev-click"]),g(se,{parentClicks:re,parentContainerId:le,defaultSlot:me})}return}if(_.isNote){const Q=xa(p);Q&&(r.notes?r.notes+=`

`+Q:r.notes=Q),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:Q||u.content||"",rawMarkdown:p,isNote:!0,attributes:u.ial});return}_.shikiLines&&(p=Lf(p,_.shikiLines)),x=p.trim();const P=(u.content||"").trim();if(x==="::right::"||P==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const R=Of(u);let Y=_.slot,S=_.clicks,F=_.motion,k={...u.ial||{}};if(R!==null){for(;a.length>0&&a[a.length-1].level>=R;)a.pop();const Q=a.length>0?a[a.length-1]:void 0;!Y&&(Q!=null&&Q.slot)&&(Y=Q.slot),!S&&(Q!=null&&Q.clicks)&&!(m!=null&&m.parentContainerId)&&(S=Q.clicks),!F&&(Q!=null&&Q.motion)&&(F=Q.motion);const G={...(Q==null?void 0:Q.customAttrs)||{}};if(u.ial)for(const[W,oe]of Object.entries(u.ial))W.startsWith("custom-slidev-")&&!W.startsWith("custom-slidev-slide")&&(G[W]=oe);m!=null&&m.parentContainerId||a.push({level:R,slot:Y,clicks:S,motion:F,customAttrs:G})}else{const Q=a.length>0?a[a.length-1]:void 0;Q&&(!Y&&Q.slot&&Q.slot!=="header"&&(Y=Q.slot),!S&&Q.clicks&&!(m!=null&&m.parentContainerId)&&(S=Q.clicks),!F&&Q.motion&&(F=Q.motion),Q.customAttrs&&(k={...Q.customAttrs,...k}))}!Y&&r.blocks.some(Q=>Q.slot==="slot-divider-right")&&(Y="right"),!Y&&(m!=null&&m.defaultSlot)&&(Y=m.defaultSlot),Y&&(k[Ce]=Y),S&&!k[Ze]&&(k[Ze]=S),F&&!k[qt]&&(k[qt]=JSON.stringify(F)),(B||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(k["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(k["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(k["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(k["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(k["custom-slidev-controls"]=b["custom-slidev-controls"]));const E={id:u.id,type:u.type,content:u.content||"",rawMarkdown:p,clicks:S,parentClicks:m==null?void 0:m.parentClicks,parentContainerId:m==null?void 0:m.parentContainerId,motion:F,shikiLines:_.shikiLines,slot:Y,attributes:k,rawNode:u};r.blocks.push(E)};g(f)}for(let f=0;f<s.length;f++){const g=s[f],u=[],m={...g.frontmatter};f===0&&(m.theme=o.theme,m.aspectRatio=o.aspectRatio,m.highlighter=o.highlighter,m.transition=g.frontmatter.transition||o.defaultTransition);const p=Df(m);p&&u.push(p);const b=g.blocks.filter(M=>M.slot!=="slot-divider-right"),y=M=>M.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return Qn(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),x=M=>{const T=M.filter(R=>!!(R.rawMarkdown||R.content||"").trim());if(T.length===0)return;const w=T[0],P=(w.rawMarkdown||w.content||"").trim();(zi(w)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(w.rawMarkdown=In(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},_=M=>{var R,Y;if(M.length===0)return"";x(M);const T=(R=M.find(S=>S.parentClicks))==null?void 0:R.parentClicks;if(!T)return M.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var F;return Qn(S.rawMarkdown,S.clicks,S.motion,(F=S.attributes)==null?void 0:F.style)}).join(`

`);const w=[];let P=[];const O=()=>{if(P.length===0)return;const S=P.map(F=>(F.rawMarkdown||F.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(wa(S,T)),P=[]};for(const S of M){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(O(),w.push(Qn(S.rawMarkdown,S.clicks,S.motion,(Y=S.attributes)==null?void 0:Y.style))):P.push(S)}return O(),w.join(`

`)},B=g.frontmatter.layout||"default";if(B==="clover"||Ln(B)){let M=[];const T=b.filter(S=>S.slot==="header");if(T.length>0)M=T;else if(b.length>0){const S=b.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));S&&(M=[S])}const w=b.filter(S=>!M.includes(S));let P=2;if(B==="clover")P=4;else if(B==="three-cols-header")P=3;else if(B==="two-cols-header")P=2;else{let S=0;for(const F of w){const k=(F.slot||"").match(/^col-(\d+)$/i);k&&(S=Math.max(S,parseInt(k[1],10)))}if(S>=2)P=S;else if(g.frontmatter.layoutRatio){const F=g.frontmatter.layoutRatio.trim();if(F.includes(":")){const k=F.split(":").map(E=>parseFloat(E.trim())).filter(E=>!isNaN(E)&&E>0);k.length>=2&&(P=k.length)}else{const k=F.split(/\s+/).filter(Boolean);k.length>=2&&(P=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(P=Math.min(6,w[0].children.length))}const O=Sa(w,P);O.forEach((S,F)=>{const k=`col-${F+1}`;for(const E of S)(!E.slot||E.slot==="default")&&(E.slot=k);x(S)});const R=O.flat();if(w.length===1&&R.length>1){const S=g.blocks.findIndex(F=>F.id===w[0].id);S!==-1&&g.blocks.splice(S,1,...R)}const Y=y(M);if(Y&&u.push(Y),B==="two-cols-header"&&P===2){const S=_(O[0]||[]),F=_(O[1]||[]);S&&u.push(`::left::

${S}`),F&&u.push(`::right::

${F}`)}else O.forEach((S,F)=>{const k=_(S);k&&u.push(`::col-${F+1}::

${k}`)})}else if(B==="two-cols"){const M=b.filter(O=>O.slot==="left"),T=b.filter(O=>O.slot==="right");x(M),x(T);const w=y(M.length>0?M:b.filter(O=>O.slot!=="right")),P=y(T);u.push(w),P&&u.push(`::right::

${P}`)}else for(const M of b)u.push(Qn(M.rawMarkdown,M.clicks,M.motion,(d=M.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=s.map(f=>f.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:o,slides:s,fullMarkdown:c}}const Is=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Rf(e){var o,s,l,r,a,c,d,f,g,u,m,p;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(o=b.light)!=null&&o.color&&t.push(`  ${y}-color: ${b.light.color};`),(s=b.light)!=null&&s.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(g=b.light)!=null&&g.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(m=b.dark)!=null&&m.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function En(e){const t=Rf(e);return t?`${Is}

/* Custom Workspace Inline Styles */
${t}`:Is}function os(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function Nf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function zf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of t)s!=null&&s.id&&o.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Nf(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Ff(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ts(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Hf(e,t,i,n=8,o){const s=new Map;for(const g of t)g!=null&&g.id&&s.set(g.id,g);const l=g=>({id:g.id,parent_id:g.parent_id,root_id:g.root_id||e,type:g.type,subType:g.subtype??g.subType??"",content:g.content||"",markdown:g.markdown||"",ial:i(g.id,g.ial),children:[]}),r=g=>{let u=g.parent_id,m=0;for(;u&&u!==e&&m++<16;){const p=s.get(u);if(!p||!Ff(p))return u;u=p.parent_id}return u||e},a=new Map;for(const g of t){if(!(g!=null&&g.id)||g.id===e||o&&o.size>0&&!o.has(g.id))continue;const u=r(g),m=a.get(u);m?m.push(g):a.set(u,[g])}if(o&&o.size>0)for(const g of a.values())g.sort((u,m)=>(o.get(u.id)??Number.MAX_SAFE_INTEGER)-(o.get(m.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(g,u)=>{const m=l(g);if(c.set(m.id,m),u>=n||!Ts(m))return m;const p=a.get(m.id);return p&&p.length>0&&(m.children=p.map(b=>d(b,u+1))),m};return{topLevel:(a.get(e)||[]).map(g=>d(g,0)),byId:c}}const jf={getBlockAttrs:Ms,getChildBlocks:fo,getDocBlocksOrders:Hc,setBlockAttrs:Ne,sql:on,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:jc};class Wf{constructor(t){we(this,"deps");we(this,"attrOverrides",new Map);we(this,"trackedListSuperBlocks",new Map);we(this,"fallbackWarnedDocId","");this.deps={...jf,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const o={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,o)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let E=0;E<s.length;E++)s[E]&&l.set(s[E],E);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=zf(o,c),f=new Map;if(Array.isArray(c))for(const E of c)E.id&&E.ial&&f.set(E.id,os(E.ial));const g=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(g).catch(()=>[])||[];if(Array.isArray(u)){for(const E of u)if(E.block_id&&E.name){let N=f.get(E.block_id);N||(N={},f.set(E.block_id,N)),N[E.name]=E.value||""}}const m=(E,N)=>{const A={...f.get(E)||(N?os(N):{})},D=this.attrOverrides.get(E);return D&&Object.assign(A,D),A},p=Array.isArray(c)&&c.length>0?Hf(t,c,m,8,l):null,b=o.map(E=>E.id).filter(Boolean),y=E=>({id:E.id,parent_id:E.parent_id,root_id:E.root_id||t,type:E.type,subType:E.subType,content:E.content||"",markdown:E.markdown||"",ial:m(E.id,E.ial),children:E.children}),x=async(E,N=0)=>{if(!E||N>8||!Ts(E))return;const A=await this.deps.getChildBlocks(E.id).catch(()=>[])||[];if(!(!Array.isArray(A)||A.length===0)){E.children=A.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:E.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:m(D.id,D.ial),children:[]}));for(const D of E.children)await x(D,N+1)}},_=new Map;for(const E of c)E!=null&&E.id&&_.set(E.id,E);const B=b.every(E=>{const N=_.get(E);return!N||!!N.type});let M=[],T=!1;if(p&&d.usable&&r&&B){this.fallbackWarnedDocId="";for(const[N,A]of d.leafPatch){const D=p.byId.get(N);D&&(D.content=A.content,D.markdown=A.markdown)}const E=new Map;for(const N of o)N!=null&&N.id&&E.set(N.id,N);for(const N of d.rebuildRoots){const A=p.byId.get(N),D=E.get(N);A&&D&&(A.content=D.content||"",A.markdown=D.markdown||""),await x(A)}for(const N of o){if(!(N!=null&&N.id)||p.byId.has(N.id))continue;const A=y(N);await x(A),p.byId.set(A.id,A),p.topLevel.push(A)}M=p.topLevel.filter(N=>l.has(N.id)).sort((N,A)=>(l.get(N.id)??0)-(l.get(A.id)??0))}else b.length>0?(T=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${s.length} 原因=${d.reason||"缺少实时文档序"}`)),M=o.map(E=>y(E))):p&&(M=p.topLevel);const w=async(E,N=0)=>{if(!(!E||E.length===0||N>8))for(const A of E){if(Ts(A)&&(!A.children||A.children.length===0)){let z=await this.deps.getChildBlocks(A.id).catch(()=>[]);if(!z||z.length===0){const Q=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${A.id}' ORDER BY sort ASC, created ASC`;z=await this.deps.sql(Q).catch(()=>[])||[]}if(Array.isArray(z)&&z.length>0){const Q=new Set(M.map(W=>W.id)),G=z.filter(W=>W.id!==A.id&&!Q.has(W.id));G.length>0&&(A.children=G.map(W=>{const oe=f.get(W.id)||(W.ial?os(W.ial):{}),re=this.attrOverrides.get(W.id);return re&&Object.assign(oe,re),{id:W.id,parent_id:W.parent_id||A.id,root_id:W.root_id||t,type:W.type,subType:W.subType,content:W.content||"",markdown:W.markdown||"",ial:oe}}))}}A.children&&A.children.length>0&&await w(A.children,N+1)}};T&&await w(M);const P=E=>{var N,A;for(const D of E)if(D.children&&D.children.length>0){P(D.children);for(const z of D.children)if(z.ial)for(const[Q,G]of Object.entries(z.ial))Q.startsWith("custom-slidev-")&&!((N=D.ial)!=null&&N[Q])&&(D.ial||(D.ial={}),D.ial[Q]=G);if(D.ial){for(const[z,Q]of Object.entries(D.ial))if(z.startsWith("custom-slidev-"))for(const G of D.children)(G.type==="video"||G.type==="NodeVideo"||/<video\b/i.test(G.markdown||G.content||""))&&!((A=G.ial)!=null&&A[z])&&(G.ial||(G.ial={}),G.ial[z]=Q)}}};P(M),Af(M,E=>{const N={[he]:E.layout};this.setBlockAttrOverride(E.blockId,N),(this.deps.setBlockAttrs||Ne)(E.blockId,N).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const O=this.trackedListSuperBlocks.get(t)||[],R=Ef(t,M,{tracked:O,onTagChange:E=>{this.setBlockAttrOverride(E.blockId,E.attrs),E.blockId===t&&Object.assign(i,E.attrs);const N=D=>{for(const z of D)z.id===E.blockId&&(z.ial||(z.ial={}),Object.assign(z.ial,E.attrs)),z.children&&z.children.length>0&&N(z.children)};N(M),(this.deps.setBlockAttrs||Ne)(E.blockId,E.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,R.newTracked);const Y=new Set;for(const E of M){const N=E.markdown||E.content||"";if(N.includes("((")){const A=Wc(N);for(const D of A)Y.add(D.blockId)}}const S={};if(Y.size>0){const E=Array.from(Y).map(A=>`'${A}'`).join(","),N=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${E})`).catch(()=>[])||[];if(Array.isArray(N))for(const A of N)A.id&&(S[A.id]=A.markdown||A.content||"")}const F=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=Vr(t,i,M,{baseUrl:F,refContentMap:S});try{const E=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=En(E)}catch{k.customThemeCss=En(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Vr(t,{},[],{});return n.customThemeCss=En(null),n}}}const De=new Wf;class er{constructor(t){we(this,"devServerUrl","http://localhost:3030");we(this,"isConnected",!1);we(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],f=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let g="";d.length>0?g=f?"":`---
${d.join(`
`)}
---

`:f||(g=`---

`);let u="";if(c.layout==="two-cols"){const p=r.blocks.filter(_=>_.slot!=="right"),b=r.blocks.filter(_=>_.slot==="right"),y=p.map(_=>_.rawMarkdown||_.content||"").join(`

`),x=b.map(_=>_.rawMarkdown||_.content||"").join(`

`);u=`${y}

::right::

${x}`}else u=r.blocks.map(p=>p.rawMarkdown||p.content||"").join(`

`);let m="";return r.notes&&r.notes.trim()&&(m=`

<!--
${r.notes.trim()}
-->`),`${g}${u}${m}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function Uf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ct(e){const t=Uf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function tr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Ct("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function _a(){var t,i;const e=tr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ct("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Vf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Hn(){const e=tr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Ct("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Ca(){var n,o;const e=tr(),t={...(e==null?void 0:e.env)||{}};if(Hn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(o=e==null?void 0:e.env)!=null&&o.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Es(e){var i,n,o;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const s=e.slice(6);return`${t}/${s}`.replace(/\\/g,"/")}return e}function Kf(){const e=Ct("os"),t=Ct("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class ir{constructor(t){we(this,"runner");this.runner=t||ir.defaultRunner}static async defaultRunner(t,i){var n;try{let o=(n=Ct("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Hn()==="win32",r=Ca();return await new Promise(a=>{o(t,i,{timeout:5e3,shell:l,env:r},(c,d,f)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:f?String(f).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const t=_a(),i=Hn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:t}}}class Gf{constructor(){we(this,"iframe",null);we(this,"isReady",!1);we(this,"pageChangedHandlers",[]);we(this,"readyHandlers",[]);we(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class qf{constructor(t){we(this,"childProcess",null);we(this,"activePort",null);we(this,"isRunning",!1);we(this,"defaultPort");we(this,"maxPortRetries");we(this,"probeTimeoutMs");we(this,"customSpawner");we(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Ct("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(t,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Hn()==="win32"?"npx.cmd":"npx",l=Es(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let f=(a=Ct("child_process"))==null?void 0:a.spawn;if(!f){const m=await import("node:child_process").catch(()=>({}));f=m==null?void 0:m.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ca();this.childProcess=f(s,r,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Hn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=Ct("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Wo{constructor(){we(this,"iframe",null);we(this,"isReady",!1);we(this,"pendingMessages",[]);we(this,"slideChangedHandlers",[]);we(this,"blockClickedHandlers",[]);we(this,"openInEditorHandlers",[]);we(this,"clientReadyHandlers",[]);we(this,"openPeekDrawerHandlers",[]);we(this,"toggleFullscreenHandlers",[]);we(this,"openPresenterHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var o;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break}}}const $a={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Zf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Yf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Jf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Xf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Qf=`${Is}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function ep(e){var o;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!t.includes(s)&&t.push(s)}return t}class tp{constructor(t){we(this,"workspacePath");we(this,"slidesFileName");we(this,"cliBridge",new er);const i=Kf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),o=this.generatePackageJson(t.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Es(s),a=Es(l),c=ep(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const _ of c){const B=$a[_]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${_}
// #endregion snippet
`;d.set(_,B)}t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Zf),t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Yf),t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="clover"})&&d.set("layouts/clover.vue",Jf),d.set("setup/root.ts",Xf),d.set("styles/index.css",Qf);const m=Ct("fs"),p=Ct("path");let b=!1;const y=p!=null&&p.dirname?p.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(m&&p&&x)try{m.existsSync(y)||m.mkdirSync(y,{recursive:!0}),m.writeFileSync(a,o,"utf-8"),m.writeFileSync(r,n,"utf-8");for(const[_,B]of d.entries()){const M=p.join(y,_),T=p.dirname(M);m.existsSync(T)||m.mkdirSync(T,{recursive:!0}),m.existsSync(M)||m.writeFileSync(M,B,"utf-8")}b=!0}catch{}if(!b&&i)try{const _=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),B=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,B),await i(s,!1,_);for(const[M,T]of d.entries()){const w=`${this.workspacePath}/${M}`,P=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(w,!1,P).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(_){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(_)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class ip{constructor(){we(this,"mode","web-sandbox");we(this,"webBridge");we(this,"cliBridge");we(this,"nativeBridge");we(this,"processManager");we(this,"scaffolder");we(this,"envDetector");this.webBridge=new Wo,this.cliBridge=new er,this.nativeBridge=new Gf,this.processManager=new qf,this.scaffolder=new tp,this.envDetector=new ir}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(t,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const np={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},op={key:0},sp={key:1},rp={key:2},lp={key:3},ap={key:4},cp={key:5},dp={key:6},up={key:7},fp={key:8},pp={key:9},hp={key:10},mp={key:11},gp={key:12},vp={key:13},bp={key:14},yp={key:15},kp={key:16},wp={key:17},xp={key:18},Sp={key:19},_p={key:20},Cp={key:21},$p={key:22},Ip={key:23},Tp={key:24},Ep={key:25},Ap={key:26},Bp={key:27},Mp={key:28},Dp={key:29},Lp={key:30},Pp={key:31},Op={key:32},Rp={key:33},Np={key:34},zp={key:35},Fp={key:36},Hp={key:37},jp={key:38},Wp={key:39},Up={key:40},Vp={key:41},Kp={key:42},Gp={key:43},qp={key:44},Zp={key:45},Yp={key:46},Jp={key:47},Xp={key:48},Qp={key:49},eh={key:50},th={key:51},ih={key:52},nh={key:53},oh={key:54},sh={key:55},rh={key:56},lh={key:57},ah={key:58},ch={key:59},dh={key:60},uh={key:61},fh={key:62},ph={key:63},hh={key:64},mh={key:65},gh={key:66},vh=xt({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(te(),ne("svg",np,[e.name==="fullscreen"||e.name==="maximize"?(te(),ne("g",op,[...i[0]||(i[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(te(),ne("g",sp,[...i[1]||(i[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(te(),ne("g",rp,[...i[2]||(i[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(te(),ne("g",lp,[...i[3]||(i[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(te(),ne("g",ap,[...i[4]||(i[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(te(),ne("g",cp,[...i[5]||(i[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(te(),ne("g",dp,[...i[6]||(i[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(te(),ne("g",up,[...i[7]||(i[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(te(),ne("g",fp,[...i[8]||(i[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(te(),ne("g",pp,[...i[9]||(i[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(te(),ne("g",hp,[...i[10]||(i[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(te(),ne("g",mp,[...i[11]||(i[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(te(),ne("g",gp,[...i[12]||(i[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(te(),ne("g",vp,[...i[13]||(i[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(te(),ne("g",bp,[...i[14]||(i[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(te(),ne("g",yp,[...i[15]||(i[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(te(),ne("g",kp,[...i[16]||(i[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(te(),ne("g",wp,[...i[17]||(i[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(te(),ne("g",xp,[...i[18]||(i[18]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(te(),ne("g",Sp,[...i[19]||(i[19]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(te(),ne("g",_p,[...i[20]||(i[20]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(te(),ne("g",Cp,[...i[21]||(i[21]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(te(),ne("g",$p,[...i[22]||(i[22]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(te(),ne("g",Ip,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):e.name==="ratio"?(te(),ne("g",Tp,[...i[24]||(i[24]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(te(),ne("g",Ep,[...i[25]||(i[25]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(te(),ne("g",Ap,[...i[26]||(i[26]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(te(),ne("g",Bp,[...i[27]||(i[27]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(te(),ne("g",Mp,[...i[28]||(i[28]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(te(),ne("g",Dp,[...i[29]||(i[29]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(te(),ne("g",Lp,[...i[30]||(i[30]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(te(),ne("g",Pp,[...i[31]||(i[31]=[h("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),h("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),h("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(te(),ne("g",Op,[...i[32]||(i[32]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(te(),ne("g",Rp,[...i[33]||(i[33]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="copy"?(te(),ne("g",Np,[...i[34]||(i[34]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(te(),ne("g",zp,[...i[35]||(i[35]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(te(),ne("g",Fp,[...i[36]||(i[36]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(te(),ne("g",Hp,[...i[37]||(i[37]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(te(),ne("g",jp,[...i[38]||(i[38]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):e.name==="focus"||e.name==="target"?(te(),ne("g",Wp,[...i[39]||(i[39]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(te(),ne("g",Up,[...i[40]||(i[40]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(te(),ne("g",Vp,[...i[41]||(i[41]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(te(),ne("g",Kp,[...i[42]||(i[42]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(te(),ne("g",Gp,[...i[43]||(i[43]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(te(),ne("g",qp,[...i[44]||(i[44]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(te(),ne("g",Zp,[...i[45]||(i[45]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(te(),ne("g",Yp,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(te(),ne("g",Jp,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):e.name==="layout-center"||e.name==="center"?(te(),ne("g",Xp,[...i[48]||(i[48]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(te(),ne("g",Qp,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(te(),ne("g",eh,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(te(),ne("g",th,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(te(),ne("g",ih,[...i[52]||(i[52]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(te(),ne("g",nh,[...i[53]||(i[53]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(te(),ne("g",oh,[...i[54]||(i[54]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(te(),ne("g",sh,[...i[55]||(i[55]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(te(),ne("g",rh,[...i[56]||(i[56]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(te(),ne("g",lh,[...i[57]||(i[57]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(te(),ne("g",ah,[...i[58]||(i[58]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(te(),ne("g",ch,[...i[59]||(i[59]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(te(),ne("g",dh,[...i[60]||(i[60]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(te(),ne("g",uh,[...i[61]||(i[61]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(te(),ne("g",fh,[...i[62]||(i[62]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(te(),ne("g",ph,[...i[63]||(i[63]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):e.name==="image-right"?(te(),ne("g",hh,[...i[64]||(i[64]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(te(),ne("g",mh,[...i[65]||(i[65]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(te(),ne("g",gh,[...i[66]||(i[66]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Mt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,o]of t)i[n]=o;return i},ue=Mt(vh,[["__scopeId","data-v-57969535"]]);function et(e,t){var o;if(typeof document>"u"||!e)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function bh(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${he}], .protyle-wysiwyg [${Ge}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(he),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role");return}const s=e.get(o),l=(s==null?void 0:s[he])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(he)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(he,l):(n.removeAttribute(he),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Ge])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Ge)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Ge,a):(n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role")))})}const yh={class:"spm-layout-picker"},kh={class:"spm-layout-picker__grid"},wh=["title","onClick"],xh={class:"spm-layout-icon"},Sh={class:"spm-layout-label"},_h=xt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(te(),ne("div",yh,[a[0]||(a[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",kh,[(te(),ne(Ve,null,kt(o,c=>h("div",{key:c.name,class:_e(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[h("div",xh,[ae(ue,{name:"layout-"+c.name},null,8,["name"])]),h("span",Sh,ge(c.label),1)],10,wh)),64))])]))}}),Ia=Mt(_h,[["__scopeId","data-v-1964d02c"]]),Ch={key:0,class:"spm-transition-selector__header"},$h={class:"spm-transition-list"},Ih=["onClick"],Th={class:"spm-transition-meta"},Eh={class:"spm-transition-label"},Ah={class:"spm-transition-name"},Bh={class:"spm-transition-preview-box"},Mh=xt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(te(),ne("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Me("",!0):(te(),ne("div",Ch,ge(e.title||"转场动效"),1)),h("div",$h,[(te(),ne(Ve,null,kt(n,r=>h("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>o(r.name)},[h("div",Th,[h("span",Eh,ge(r.label),1),h("span",Ah,"("+ge(r.name)+")",1)]),h("div",Bh,[h("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Ih)),64))])],2))}}),nr=Mt(Mh,[["__scopeId","data-v-8597e99e"]]),Dh={class:"spm-divider-popover"},Lh={class:"spm-divider-popover__title"},Ph={class:"spm-form-item"},Oh={class:"spm-popover-footer"},Rh={class:"spm-save-hint"},Nh=xt({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var g,u,m;const i=e,n=t,o=fe(((g=i.initialAttrs)==null?void 0:g[he])||"default"),s=fe(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=fe(((m=i.initialAttrs)==null?void 0:m[We])||""),r=fe("");ki(()=>i.initialAttrs,p=>{o.value=(p==null?void 0:p[he])||"default",s.value=(p==null?void 0:p[tt])||"slide-left",l.value=(p==null?void 0:p[We])||""},{deep:!0});async function a(p,b){if(i.blockId){r.value="正在同步...",De.setBlockAttrOverride(i.blockId,{[p]:b}),et(i.blockId,{[p]:b});try{await Ne(i.blockId,{[p]:b}),r.value="已同步至块属性",n("updated",{[p]:b}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(p){a(he,p)}function d(p){a(tt,p)}function f(){a(We,l.value.trim())}return(p,b)=>(te(),ne("div",Dh,[h("div",Lh,[b[4]||(b[4]=h("span",null,"幻灯片页面设置",-1)),h("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=y=>n("close"))},"✕")]),ae(Ia,{modelValue:o.value,"onUpdate:modelValue":b[1]||(b[1]=y=>o.value=y),onChange:c},null,8,["modelValue"]),ae(nr,{modelValue:s.value,"onUpdate:modelValue":b[2]||(b[2]=y=>s.value=y),onChange:d},null,8,["modelValue"]),h("div",Ph,[b[5]||(b[5]=h("label",{class:"spm-form-label"},"页面背景",-1)),Et(h("input",{"onUpdate:modelValue":b[3]||(b[3]=y=>l.value=y),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:f},null,544),[[$o,l.value]])]),h("div",Oh,[h("span",Rh,ge(r.value),1)])]))}}),zh=Mt(Nh,[["__scopeId","data-v-e4871368"]]),Fh={class:"spm-slide-inspector"},Hh={class:"spm-inspector-header"},jh={class:"spm-inspector-list"},Wh=["onClick"],Uh={class:"spm-card-top"},Vh={class:"spm-card-badge"},Kh={class:"spm-card-layout"},Gh=["onClick"],qh={class:"spm-card-preview"},Zh={key:0,class:"spm-card-notes",title:"演讲备忘录"},Yh={class:"spm-inspector-modal-content"},Jh=xt({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=fe(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[he]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[We]=c.frontmatter.background),c.notes&&(d[Ki]=c.notes),d}function l(c){n.value&&(c[he]&&(n.value.frontmatter.layout=c[he]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[We]&&(n.value.frontmatter.background=c[We]),c[Ki]&&(n.value.notes=c[Ki]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],f=d.content||d.rawMarkdown||"";return f.slice(0,40)+(f.length>40?"...":"")}return(c,d)=>(te(),ne("div",Fh,[h("div",Hh,[h("span",null,"幻灯片大纲 ("+ge(e.slides.length)+" 页)",1)]),h("div",jh,[(te(!0),ne(Ve,null,kt(e.slides,f=>(te(),ne("div",{key:f.pageIndex,class:_e(["spm-card",{active:e.currentActivePage===f.pageIndex}]),onClick:g=>r(f.pageIndex)},[h("div",Uh,[h("span",Vh,"P"+ge(f.pageIndex),1),h("span",Kh,ge(f.frontmatter.layout||"default"),1),h("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Lt(g=>o(f),["stop"])},[ae(ue,{name:"settings"})],8,Gh)]),h("div",qh,ge(a(f)),1),f.notes?(te(),ne("div",Zh,[ae(ue,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),h("span",null,ge(f.notes),1)])):Me("",!0)],10,Wh))),128))]),n.value?(te(),ne("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Lt(f=>n.value=null,["self"]))},[h("div",Yh,[ae(zh,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=f=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Me("",!0)]))}}),Xh=Mt(Jh,[["__scopeId","data-v-68b25edd"]]),Qh={class:"spm-immersion-header"},em={class:"spm-immersion-header__left"},tm={class:"spm-immersion-title"},im={class:"spm-immersion-header__center"},nm={class:"spm-immersion-header__actions"},om=["aria-label"],sm={class:"spm-immersion-body"},rm=xt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Et((te(),ne("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Lt(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",Qh,[h("div",em,[Jn(a.$slots,"header-left",{},()=>[h("span",tm,ge(e.title),1)])]),h("div",im,[Jn(a.$slots,"header-center",{},void 0)]),h("div",nm,[Jn(a.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ae(ue,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,om),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[ae(ue,{name:"close"})])])]),h("div",sm,[Jn(a.$slots,"default",{},void 0)])],2)],34)),[[Cs,e.visible]])}}),lm=Mt(rm,[["__scopeId","data-v-3f1665db"]]),am={class:"spm-protyle-drawer"},cm={class:"spm-protyle-drawer__subbar"},dm={class:"spm-protyle-drawer__nav"},um=["title"],fm={class:"spm-protyle-drawer__actions"},pm=["aria-label"],hm=["aria-label"],mm=xt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(n.blockId),s=fe(n.title||""),l=fe(!1),r=fe(!0),a=fe(!1),c=fe(""),d=gi,f=fe([]),g=fe(null);let u=null;ki(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",f.value=[],p(w))}),un(()=>{o.value&&p(o.value)}),Ks(()=>{b()});async function m(w){try{const P=await on(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(P)&&P.length>0){const O=P[0];c.value=O.root_id||"";const R=O.id===O.root_id||O.type==="d";a.value=R,r.value=!R,!s.value&&O.content&&(s.value=O.content.trim().slice(0,30));return}}catch(P){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",P)}a.value=!1,r.value=!0}async function p(w,P){if(!g.value||!w)return;b(),await m(w),typeof P=="boolean"&&(r.value=!a.value&&P);let O,R;r.value&&!a.value?(O=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(O=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new pe.Protyle(n.plugin.app,g.value,{blockId:w,action:O,render:R}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(Y){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",Y)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}g.value&&(g.value.innerHTML="")}function y(){a.value||(r.value=!r.value,p(o.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function _(){if(o.value)try{pe.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function B(){var O;if(!o.value)return;const w=jo(),P=va(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const R=Ct("electron");(O=R==null?void 0:R.shell)!=null&&O.openExternal?R.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}i("external-jump",P)}function M(){if(f.value.length>0){const w=f.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,p(w.blockId,w.isFocusMode))}}function T(w){const P=w.target;if(!P)return;const O=P.closest('[data-type="block-ref"]');if(O){const Y=O.getAttribute("data-id");if(Y&&Y!==o.value){w.preventDefault(),w.stopPropagation(),f.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=Y,s.value=O.innerText.trim()||Y,p(Y);return}}const R=P.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const Y=R.href.replace("siyuan://blocks/","").split("?")[0];Y&&Y!==o.value&&(f.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=Y,s.value=R.innerText.trim()||Y,p(Y))}}return(w,P)=>(te(),ne("div",am,[h("div",cm,[h("div",dm,[f.value.length>0?(te(),ne("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:M},[ae(ue,{name:"arrow-left"}),P[0]||(P[0]=h("span",null,"返回",-1))])):Me("",!0),h("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ge(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||o.value},ge(s.value||o.value),9,um)]),h("div",fm,[a.value?Me("",!0):(te(),ne("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[ae(ue,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,ge(r.value?"块聚焦":"展开全文"),1)],10,pm)),h("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[ae(ue,{name:l.value?"edit":"eye"},null,8,["name"]),h("span",null,ge(l.value?"编辑中":"只读"),1)],10,hm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[ae(ue,{name:"window"}),P[1]||(P[1]=h("span",null,"独立窗口",-1))]),be(d).enableWebServeJump?(te(),ne("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:B},[ae(ue,{name:"external-link"}),P[2]||(P[2]=h("span",null,"外跳",-1))])):Me("",!0)])]),h("div",{ref_key:"mountEl",ref:g,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),gm=Mt(mm,[["__scopeId","data-v-7e586ef3"]]),vm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,bm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Kr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Ta(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function ym(e){const t=e.split(/[/?#]/)[0];return!t||bm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function km(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function Ea(e){const t=wm(e);return t.external||!t.url?t:{url:km(t.url),external:!1}}function wm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(dl(t))return{url:`/${ul(t)}`,external:!1};if(/^file:/i.test(t)){const n=Kr(Ta(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Kr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return vm.test(t)?{url:t,external:!0}:ym(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const xm={class:"spm-webview-drawer"},Sm={class:"spm-webview-toolbar"},_m={class:"spm-webview-toolbar__nav"},Cm=["disabled"],$m=["disabled"],Im=["aria-label"],Tm={class:"spm-webview-toolbar__address"},Em=["aria-label"],Am={class:"spm-webview-toolbar__actions"},Bm=["aria-label"],Mm={class:"spm-zoom-controller"},Dm=["disabled"],Lm=["disabled"],Pm={key:1,class:"spm-webview-fallback"},Om=["src"],Rm={key:2,class:"spm-load-error"},Nm={class:"spm-load-error__code"},zm={class:"spm-load-error__code-num"},Fm={class:"spm-load-error__url"},Hm={class:"spm-load-error__hint"},jm={class:"spm-load-error__actions"},Gr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Aa="siyuan-slidev-peek-view-mode";let Ba="desktop";function Wm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Aa);if(e==="mobile"||e==="desktop")return e}catch{}return Ba}function Um(e){if(Ba=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Aa,e)}catch{}}function Vm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Km=xt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(_a()&&!Vf()),s=fe(n.url),l=fe(n.url),r=n.url,a=fe(!1),c=fe(null),d=fe(!1),f=fe(!1),g=fe(1),u=fe(!1),m=fe(Wm());let p=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ye(()=>m.value==="mobile"?Gr:p||void 0),y=fe(null),x=fe(null);let _=null,B=null,M=null;ki(()=>n.url,X=>{X&&X!==s.value&&(s.value=X,l.value=X,m.value==="mobile"&&R(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X))}),ki(()=>n.visible,X=>{if(X)oe(),m.value==="mobile"&&R(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),un(()=>{T(),x.value&&typeof ResizeObserver<"u"&&(_=new ResizeObserver(()=>{const X=y.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),_.observe(x.value)),B=X=>{var L;const se=X.message||((L=X.error)==null?void 0:L.message);if(typeof se=="string"&&se.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",B,!0),M=X=>{const se=X.reason,L=typeof se=="string"?se:se==null?void 0:se.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",M)}),Ks(()=>{if(w(),_&&(_.disconnect(),_=null),B&&(window.removeEventListener("error",B,!0),B=null),M&&(window.removeEventListener("unhandledrejection",M),M=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function T(){const X=y.value;X&&(X.addEventListener("dom-ready",P),X.addEventListener("did-start-loading",Y),X.addEventListener("did-stop-loading",k),X.addEventListener("did-navigate",E),X.addEventListener("did-navigate-in-page",N),X.addEventListener("new-window",A),X.addEventListener("did-fail-load",S),X.addEventListener("did-fail-provisional-load",S))}function w(){const X=y.value;if(X)try{X.removeEventListener("dom-ready",P),X.removeEventListener("did-start-loading",Y),X.removeEventListener("did-stop-loading",k),X.removeEventListener("did-navigate",E),X.removeEventListener("did-navigate-in-page",N),X.removeEventListener("new-window",A),X.removeEventListener("did-fail-load",S),X.removeEventListener("did-fail-provisional-load",S)}catch{}}function P(){const X=y.value;if(X&&typeof X.getUserAgent=="function"&&!p)try{const se=X.getUserAgent();se&&!se.includes("iPhone")&&(p=se)}catch{}m.value==="mobile"&&R(!1),oe(),D()}function O(){const X=m.value==="mobile"?"desktop":"mobile";m.value=X,Um(X),R(!0)}function R(X=!1){const se=y.value;if(!se)return;const L=m.value==="mobile"?Gr:p;if(typeof se.setUserAgent=="function"&&L)try{se.setUserAgent(L)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(X&&typeof se.reload=="function")try{se.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function Y(){a.value=!0,c.value=null}function S(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const se=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:se,validatedURL:String((X==null?void 0:X.validatedURL)||s.value),hint:Vm(se)},a.value=!1}function F(){c.value=null,G()}function k(){if(a.value=!1,D(),y.value&&typeof y.value.getURL=="function"){const X=y.value.getURL();X&&X!=="about:blank"&&(s.value=X,l.value=X)}}function E(X){X!=null&&X.url&&(s.value=X.url,l.value=X.url),D()}function N(X){X!=null&&X.url&&(s.value=X.url,l.value=X.url),D()}function A(X){X&&X.url&&(X.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url))}function D(){const X=y.value;X&&(typeof X.canGoBack=="function"&&(d.value=X.canGoBack()),typeof X.canGoForward=="function"&&(f.value=X.canGoForward()))}function z(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function Q(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function G(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function W(){const X=Ea(l.value);if(X.url){if(X.external){s.value=X.url,ce();return}s.value=X.url,l.value=X.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url)}}function oe(){const X=y.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(g.value)}catch(se){console.warn("[WebviewPeekDrawer] setZoomFactor error:",se)}}function re(){g.value=Math.min(2.5,Math.round((g.value+.1)*10)/10),oe()}function le(){g.value=Math.max(.5,Math.round((g.value-.1)*10)/10),oe()}function me(){g.value=1,oe()}function $e(X){X.preventDefault(),X.deltaY<0?re():X.deltaY>0&&le()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function ce(){var se;const X=s.value;if(typeof window<"u"){const L=Ct("electron");(se=L==null?void 0:L.shell)!=null&&se.openExternal?L.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,se)=>{const L=eu("webview");return te(),ne("div",xm,[h("div",Sm,[h("div",_m,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:z},[ae(ue,{name:"arrow-left"})],8,Cm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:Q},[ae(ue,{name:"arrow-right"})],8,$m),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:G},[ae(ue,{name:"refresh"})],8,Im)]),h("div",Tm,[Et(h("input",{"onUpdate:modelValue":se[0]||(se[0]=j=>l.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:gf(W,["enter"])},null,544),[[$o,l.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:ke},[ae(ue,{name:"copy"})],8,Em)]),h("div",Am,[h("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:O},[ae(ue,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Bm),h("div",Mm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:g.value<=.5,onClick:le},[ae(ue,{name:"minus"})],8,Dm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:me},ge(Math.round(g.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:g.value>=2.5,onClick:re},[ae(ue,{name:"plus"})],8,Lm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ce},[ae(ue,{name:"external-link"}),se[1]||(se[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:x,class:_e(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:Lt($e,["ctrl"])},[h("div",{class:_e(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[o.value?(te(),Pt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:be(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(te(),ne("div",Pm,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Om),h("div",{class:"spm-fallback-bar"},[se[2]||(se[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:ce}," 在新标签页中打开 ↗ ")])])),c.value?(te(),ne("div",Rm,[ae(ue,{name:"alert",class:"spm-load-error__icon"}),se[5]||(se[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",Nm,[$t(ge(c.value.description)+" ",1),h("span",zm,"("+ge(c.value.errorCode)+")",1)]),h("div",Fm,ge(c.value.validatedURL),1),h("p",Hm,ge(c.value.hint),1),h("div",jm,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:F},[ae(ue,{name:"refresh"}),se[3]||(se[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:ce},[ae(ue,{name:"external-link"}),se[4]||(se[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Me("",!0)],2)],34)])}}}),Gm=Mt(Km,[["__scopeId","data-v-192d3665"]]);class qm{constructor(){we(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const o=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,o)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Zm{constructor(t){we(this,"blockToPageMap",new Map);we(this,"debounceCtrl",new qm);we(this,"activeBlockId","");we(this,"activePageIndex",1);we(this,"currentDocId","");we(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ri(e,t){var s,l;if(!e||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return pe.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Ym(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>lt(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>lt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${lt(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Jm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();t.push(`<h${o} class="slide-list-item-title">${lt(s)}</h${o}>`)}else t.push(`<p class="slide-list-item-title">${lt(i)}</p>`);if(e.length>1){const o=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>lt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${lt(d)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Ma(e,t,i){var g,u,m,p;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const s=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const T=x[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const _=y.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const T=_[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:_[2],media:[]});continue}const B=y.match(/^(\s*)\d+\.\s+(.*)$/);if(B){l.length===0&&(r=!0);const T=B[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:B[2],media:[]});continue}const M=y.trim();if(!(!M||/^\{:.*?\}$/.test(M)))if(l.length>0){const T=M.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const O=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ot(T[1])}" src="${T[2]}" class="${O}" /></div>`);continue}if(M.match(/^<img\b[\s\S]*?\/?>$/i)){const P=M.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${P}</div>`);continue}if(/<video\b/i.test(M)){let P=M;if(!/<\/video>/i.test(P))for(;b+1<n.length&&!/<\/video>/i.test(P);)b++,P+=" "+n[b].trim();const O=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),R=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(P),Y=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-muted"])==="true"||O||/muted/i.test(P),S=((p=i==null?void 0:i.attributes)==null?void 0:p["custom-slidev-controls"])==="false",F=P.match(/\bsrc=["']([^"']+)["']/i),k=F?F[1]:"",E=['class="slide-video-player"'];S||E.push("controls"),O&&(E.push("autoplay"),E.push("playsinline")),R&&E.push("loop"),Y&&E.push("muted"),E.push('preload="metadata"'),k&&E.push(`src="${k}"`);const N=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=N?N[1].trim():"";!A&&k&&(A=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${Y?"true":"false"}"><video ${E.join(" ")}>${A}</video></div>`);continue}l[l.length-1].text+=`
`+M}else s.push(M)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const y=Ym(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",_=b.level||0,B=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",M=_>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${M}"${B}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${x}</li>`}return`<li${M?` class="${M.trim()}"`:""}${B}>${y}${x}</li>`}).join(`
`);return`${Jm(s)}<${a} class="${c}">
${d}
</${a}>`}function Xm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",o=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const d=o[c],f=d.trim();if(/^#{1,6}\s+/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(!f){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(/<video\b/i.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]);let g=f;if(!/<\/video>/i.test(g))for(;c+1<o.length&&!/<\/video>/i.test(g);)c++,g+=`
`+o[c];s.push(g);continue}l.push(d)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var m,p,b,y;const d=c.trim();if(!d)return"";const f=d.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const x=f[1].length;return`<h${x} class="slide-list-item-title">${lt(f[2].trim())}</h${x}>`}const g=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const x=/\.gif(?:\?|$)/i.test(g[2]),_=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ot(g[1])}" src="${g[2]}" class="${_}" /></div>`}if(/<video\b/i.test(d)){const x=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),_=((p=i==null?void 0:i.attributes)==null?void 0:p["custom-slidev-loop"])==="true"||/loop/i.test(d),B=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),M=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",P=['class="slide-video-player"'];M||P.push("controls"),x&&P.push("autoplay playsinline"),_&&P.push("loop"),B&&P.push("muted"),P.push('preload="metadata"'),w&&P.push(`src="${w}"`);const O=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let R=O?O[1].trim():"";return!R&&w&&(R=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${B?"true":"false"}"><video ${P.join(" ")}>${R}</video></div>`}const u=Ma(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${lt(x[0])}</p>`;const _=x[0],M=x.slice(1).map(T=>lt(T)).join("<br/>");return`<p class="slide-list-item-title">${lt(_)}</p>
<p class="slide-list-item-desc">${M}</p>`}return`<p class="slide-list-item-desc">${lt(d)}</p>`}).filter(Boolean).join(`
`)}function ss(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Da(e,t){var r,a,c,d,f,g,u,m;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",o=(e.blocks||[]).filter(p=>p.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(ss);if(i==="two-cols"){const p=o.some(Y=>Y.slot==="right");let b=[],y=[];if(p)b=o.filter(Y=>Y.slot!=="right"),y=o.filter(Y=>Y.slot==="right");else{const Y=Math.ceil(o.length/2);b=o.slice(0,Y),y=o.slice(Y)}const x=Y=>{const S=Y.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(S.length>0){const F=S[0],k=(F.rawMarkdown||F.content||"").trim();(zi(F)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(F.rawMarkdown=In(F.rawMarkdown||F.content||""),F.content=F.rawMarkdown)}};x(b),x(y);const _=b.map(Y=>pi(Y,t)).join(`
`),B=y.map(Y=>pi(Y,t)).join(`
`),M=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",P=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",R=`style="grid-template-columns: ${ns((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${M}${T}" ${R}>
        <div class="${w}">${_}</div>
        <div class="${P}">${B}</div>
      </div>
    `}if(i==="clover"||Ln(i)){const p=i==="clover";let b=[];const y=o.filter(E=>E.slot==="header");if(y.length>0)b=y;else if(o.length>0){const E=o.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));E&&(b=[E])}const x=o.filter(E=>!b.includes(E));let _=2;if(p)_=4;else if(i==="three-cols-header")_=3;else if(i==="two-cols-header")_=2;else{let E=0;for(const N of x){const A=(N.slot||"").match(/^col-(\d+)$/i);A&&(E=Math.max(E,parseInt(A[1],10)))}if(E>=2)_=E;else if((d=e.frontmatter)!=null&&d.layoutRatio){const N=e.frontmatter.layoutRatio.trim();if(N.includes(":")){const A=N.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);A.length>=2&&(_=A.length)}else{const A=N.split(/\s+/).filter(Boolean);A.length>=2&&(_=A.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(_=Math.min(6,x[0].children.length))}const B=Sa(x,_),M=x.some(E=>E.slot&&/^(?:col-\d+|left|right)$/i.test(E.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Ln(i)&&M,w=E=>{const N=E.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(T&&N.length>0){const D=N[0],z=(D.rawMarkdown||D.content||"").trim();(zi(D)||/^(?:[-*+]|\d+\.)\s+/.test(z))&&(D.rawMarkdown=In(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const A=T?N.find(ss):null;return N.map(D=>pi(D,{...t,extraClassName:D===A?"slidev-col-first-heading-block":""})).join(`
`)},P=b.find(ss),O=b.map(E=>pi(E,{...t,extraClassName:E===P?"slidev-page-first-heading-block":""})).join(`
`),R=p?"repeat(2, minmax(0, 1fr))":ns((f=e.frontmatter)==null?void 0:f.layoutRatio,_),Y=p?`style="grid-template-columns: ${R}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${R};"`,S=[p?"layout-clover-container":"layout-cols-header-container",_===2?"layout-two-cols-header-container":"",_===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),F=[p?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",_===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",_===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),k=B.map((E,N)=>{const A=N+1;return`<div class="${["pdf-col",_===2&&A===1?"pdf-col--left":"",_===2&&A===2?"pdf-col--right":"",`pdf-col--${A}`,`col-${A}`].filter(Boolean).join(" ")}">${w(E)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${O}</div>
        <div class="${F}" ${Y}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const p=i==="image-right",b=o.map(T=>pi(T,t)).join(`
`),y=((g=e.frontmatter)==null?void 0:g.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ot(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ot(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,_=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,B=p?`${_}
${x}`:`${x}
${_}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${ns((m=e.frontmatter)==null?void 0:m.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${B}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(b=>pi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(b=>pi(b,t)).join(`
`)}</div>`:o.map(p=>pi(p,{...t,extraClassName:p===l?"slidev-page-first-heading-block":""})).join(`
`)}function ot(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Qm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(o,10);isNaN(s)||t.add(s)}}return t}const eg=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function lt(e){if(!e)return"";const t=ka(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!eg.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ot(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,f)=>{const u=(r??a??c??d??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function tg(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${lt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${lt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function rs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function qr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${rs(e)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${rs(l)}</span>`),`__TOK_${i.length-1}__`}let o=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=rs(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function ig(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:e.pageIndex||t,title:n,level:o}):null}function ng(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,d)=>{const f=ig(c,d+1);f&&s.push(f)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const f=[];for(const g of c){const u=a(g.children,d+1);d>=n?f.push({...g,children:u}):f.push(...u)}return f}return a(l,1)}function og(e,t=1,i={}){const n=ng(e,t,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const f=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const m=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",p=u.children&&u.children.length>0?r(u.children,d+1):"";let b=lt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${m}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${p}
        </li>
      `}).join("");return`<ol class="${f}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function pi(e,t){var M,T,w,P,O,R,Y,S,F,k;let i="",n="",o="";const s=[];(M=e.motion)!=null&&M.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ot(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",f=`${r}${i}${o}${a}${d}`,g=(e.rawMarkdown||e.content||"").trim();if(!g)return`<div class="${f}"${n}></div>`;if(g.includes('class="slidev-block-ref"')||g.includes('class="slidev-ref-tag"'))return`<div class="${f}"${n}>${g}</div>`;if(g.startsWith("$$")&&g.endsWith("$$")){const E=g.slice(2,-2).trim();return`<div class="${f} katex-display-container"${n}><div class="katex-display font-math"><em>${ot(E)}</em></div></div>`}const u=g.match(/^(#{1,6})\s+(.*)$/);if(u){const E=u[1].length,N=lt(u[2]),D=!!(e.isColFirst||e.type==="i"&&((w=t==null?void 0:t.extraClassName)!=null&&w.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><h${E}${D}>${N}</h${E}></div>`}if(g.startsWith(":::")){const E=g.split(`
`),A=E[0].replace(/^:::\s*/,"").trim()||"info",D=E.slice(1,E[E.length-1].startsWith(":::")?-1:void 0).join(`
`),z=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${n}><div class="${z} ${z}--${A}"><div class="${z}-title">${A.toUpperCase()}</div><div class="${z}-body">${lt(D)}</div></div></div>`}if(g.startsWith("<<<")){const A=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((G,W)=>`<span class="code-line shiki-focus"><span class="line-no">${W+1}</span><span class="line-content">${qr(G,"ts")}</span></span>`).join(`
`),D=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",z=((P=e.attrs)==null?void 0:P["custom-slidev-max-height"])||e.maxHeight||"",Q=z?` style="max-height:${ot(z)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${D}"${Q}><span class="lang-badge">TS</span><code>${A}</code></pre></div>`}if(g.startsWith("<style")||g.startsWith("<!-- Inline style -->")||g.startsWith(`<!--
Notes`))return"";if(g.startsWith("```")){const E=g.split(`
`),N=E[0].slice(3).trim(),A=N.match(/^([^\s{\[]+)/),D=A?A[1]:"",z=N.match(/\[([^\]]+)\]/),Q=z?z[1]:"",G=N.includes("twoslash"),W=e.shikiLines||((O=N.match(/\{([^}]+)\}/))==null?void 0:O[1])||"",oe=Qm(W),re=E.length>2?E[E.length-1]==="```"?E.slice(1,-1):E.slice(1):[g.slice(3).replace(/```$/,"")],le=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",me=Q?`${le} has-filename`:le,$e=oe!=="all",ke=re.map((j,v)=>{const V=v+1,$=oe==="all"||oe.has(V)?"code-line shiki-focus":$e?"code-line shiki-dimmed":"code-line";let C=(t==null?void 0:t.highlight)===!0?qr(j,D):ot(j);return G&&j.includes("doubled.value = 2")?(C=C.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${$}"><span class="line-no">${V}</span><span class="line-content">${C}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${$}"><span class="line-no">${V}</span><span class="line-content">${C}</span></span>`}).join(`
`),ce=D?`<span class="lang-badge">${ot(D)}</span>`:"",X=Q?`<span class="code-filename">${ot(Q)}</span>`:"",se=((R=e.attrs)==null?void 0:R["custom-slidev-max-height"])||e.maxHeight||"",L=se?` style="max-height:${ot(se)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${me}"${L}>${X}${ce}<code>${ke}</code></pre></div>`}if(g.includes("|")&&g.split(`
`).filter(E=>E.trim().startsWith("|")).length>=2){const E=g.split(`
`).filter(A=>A.trim().startsWith("|")),N=tg(E,t==null?void 0:t.tableClassName);return`<div class="${f}"${n}>${N}</div>`}if(g.startsWith("> ")){const E=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${n}><blockquote class="${E}"><p>${lt(g.slice(2))}</p></blockquote></div>`}const m=/<video\b/i.test(g)||e.type==="video"||e.type==="NodeVideo",p=/^(\s*)([-*+]|\d+\.)\s+/m.test(g),b=/(?:^|\n)\s*#{1,6}\s+/.test(g);if(m&&!p&&!b&&!g.includes(`
`)){const E=((Y=e.attributes)==null?void 0:Y["custom-slidev-autoplay"])==="true"||/autoplay/i.test(g),N=((S=e.attributes)==null?void 0:S["custom-slidev-loop"])==="true"||/loop/i.test(g),A=((F=e.attributes)==null?void 0:F["custom-slidev-muted"])==="true"||E||/muted/i.test(g),D=((k=e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",z=g.match(/\bsrc=["']([^"']+)["']/i),Q=z?z[1]:"",G=['class="slide-video-player"'];D||G.push("controls"),E&&(G.push("autoplay"),G.push("playsinline")),N&&G.push("loop"),A&&G.push("muted"),G.push('preload="metadata"'),Q&&G.push(`src="${Q}"`);const W=g.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let oe=W?W[1].trim():"";return!oe&&Q&&(oe=`<source src="${Q}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${E?"true":"false"}" data-muted="${A?"true":"false"}"${n}><video ${G.join(" ")}>${oe}</video></div>`}const y=g.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const E=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${n}><img alt="${ot(y[1])}" src="${y[2]}" class="${E}" /></div>`}const x=Ma(g,t,e);if(x)return`<div class="${f} pdf-list-item"${n}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(g)&&!g.startsWith("```")){const E=g.match(/minDepth=["']?(\d+)["']?/i),N=g.match(/maxDepth=["']?(\d+)["']?/i),A=g.match(/columns=["']?(\d+)["']?/i),D=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${n}>${og(D,(t==null?void 0:t.currentPageIndex)||1,{minDepth:E?parseInt(E[1],10):1,maxDepth:N?parseInt(N[1],10):1/0,columns:A?parseInt(A[1],10):1,textSm:g.includes("text-sm")})}</div>`}if(g.includes(`
`)||b){const E=Xm(g,t,e);if(E)return`<div class="${f}"${n}>${E}</div>`}const B=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><p${B}>${lt(g)}</p></div>`}function sg(e){return`
    ${En(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function rg(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function lg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function ag(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function cg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function dg(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function ug(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function fg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function pg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function hg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function mg(){return[rg(),lg(),ag(),cg(),dg(),ug(),fg(),pg(),hg()].join("")}function La(e,t){const i="Slidev 演示文稿";let n=e.slides;const o=JSON.stringify(n),s=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ot(i)}</title>
  <style>
${sg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${mg()}
  <\/script>
</body>
</html>`}function Pa(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function gg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function vg(e){const t=gg(e==null?void 0:e.pageRatio);return`
    ${En(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function bg(e,t){const i="Slidev 演示讲义",n="16:9",o="light",s=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",f=Da(l),g=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ot(i)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${f}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ot(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ot(i)} - 高保真讲义</title>
  <style>
    ${vg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Oa(e,t){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=bg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const yg=1500,kg=500,wg=4,xg=new Set(["INPUT","TEXTAREA","SELECT"]);function Ra(e){const t=e;return!t||!t.tagName?!1:xg.has(t.tagName)||t.isContentEditable===!0}function Sg(e){let t="",i=!1,n=null,o=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),o&&(clearTimeout(o),o=null)}function r(){l(),t="",i=!1,s()}function a(){n&&clearTimeout(n),n=setTimeout(r,yg)}function c(){n&&(clearTimeout(n),n=null),i=!0,s(),o&&clearTimeout(o),o=setTimeout(r,kg)}function d(f){if(e.isEnabled&&!e.isEnabled()||Ra(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return i||t.length>=wg||(t+=f.key,s(),a()),!0;if(f.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),m=e.getTotalPages();return!isNaN(u)&&u>=1&&m>0&&u<=m?(r(),e.onJump(u),!0):(c(),!0)}return f.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const _g={class:"spm-slidev-tab__toolbar"},Cg={class:"spm-slidev-tab__nav"},$g=["disabled"],Ig={class:"spm-page-badge"},Tg=["disabled"],Eg=["aria-label"],Ag=["aria-label"],Bg={class:"spm-slidev-tab__tools"},Mg=["src"],Dg=xt({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Wo),o=new Zm(n),s=new ip,l=fe("web-sandbox"),r=fe(3030),a=fe(null),c=fe(!1),d=fe(null),f=fe(1),g=fe(1),u=fe([]),m=fe(!1),p=fe(!1),b=fe(!1),y=fe("siyuan"),x=fe(""),_=fe(""),B=fe(""),M=fe(!1),T=fe(!1),w=fe(""),P=fe(""),O=fe(!1),R=Sg({getTotalPages:()=>g.value,isEnabled:()=>!p.value,onJump:C=>F(C),onStateChange:C=>{P.value=C.display,O.value=C.invalid}});function Y(C){if(C.key==="o"||C.key==="O"){if(p.value||C.isComposing||C.ctrlKey||C.metaKey||C.altKey||Ra(C.target))return;C.preventDefault(),S();return}R.handleKeydown(C)&&C.preventDefault()}function S(){var C,U;if(l.value==="pro-cli"){(C=d.value)==null||C.focus(),pe.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(U=d.value)==null||U.focus()}function F(C){var U;f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C),(U=d.value)==null||U.focus()}const k=fe("/plugins/siyuan-slidev/slidev-client/index.html");let E=null,N=null,A=null,D=null,z=null,Q=null,G=null,W=null;un(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),E=n.onSlideChanged((C,U)=>{f.value=C,g.value=U}),N=n.onBlockClicked((C,U)=>{f.value=U,o.setActiveBlockId(C),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(C,U):Ri(C,i==null?void 0:i.app)}),A=n.onOpenInEditor((C,U)=>{f.value=U,o.setActiveBlockId(C),Ri(C,i==null?void 0:i.app)}),D=s.nativeBridge.onPageChanged((C,U)=>{f.value=C,g.value=U}),z=n.onOpenPeekDrawer(async C=>{const U=jo();if(C.peekType==="siyuan"&&U.enableWebServeJump){let q=!1;if(W&&W.docId===C.target)q=!0;else if(W&&W.slides&&W.slides.some(K=>{var ie;return(ie=K.blocks)==null?void 0:ie.some(Z=>Z.id===C.target)}))q=!1;else try{const K=await on(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);K&&K.length>0&&(q=K[0].type==="d"||K[0].id===K[0].root_id)}catch(K){console.warn("[SlidevPreviewTab] detect block type failed:",K)}y.value="web",M.value=!0,_.value=va(U.webServeUrl,C.target,{focus:!q}),B.value=C.title||`${q?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,p.value=!0,n.freezeKeyboardNav(!0)}else{if(y.value=C.peekType,C.peekType==="siyuan")x.value=C.target,B.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const q=Ea(C.target);if(q.external){j(C.target);return}M.value=!0,_.value=q.url,B.value=C.title||q.url}p.value=!0,n.freezeKeyboardNav(!0)}}),Q=n.onRequestToggleFullscreen(()=>{V()}),G=n.onOpenPresenter(()=>{H()}),typeof document<"u"&&document.addEventListener("fullscreenchange",v)}),No(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",v),z&&z(),Q&&Q(),G&&G(),E&&E(),N&&N(),A&&A(),D&&D(),n.detach(),R.clear(),o.destroy(),s.destroy()});async function oe(){if(l.value==="web-sandbox"){if(!W){pe.showMessage("请先在主编辑区打开演示文档");return}pe.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const C=await s.startProMode(W,fs);if(!C.success){pe.showMessage(`无法启动官方 Pro 模式：${C.error}`);return}l.value="pro-cli",r.value=C.port||3030,k.value=C.url,d.value&&s.nativeBridge.attach(d.value),pe.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",k.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),pe.showMessage("已切回内置高保真沙箱")}function re(){T.value=!T.value,T.value?(w.value=(W==null?void 0:W.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",X(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let le=0;function me(C){if(p.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const U=Date.now();U-le<280||(le=U,C.deltaY>0?ke():$e())}function $e(){if(f.value>1){const C=f.value-1;f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function ke(){if(f.value<g.value){const C=f.value+1;f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function ce(C){f.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}function X(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function se(){p.value=!1,n.freezeKeyboardNav(!1)}function L(){se()}function j(C){var ie,Z;const U=/^file:/i.test(C),q=U||/^[a-zA-Z]:[\\/]/.test(C),K=Ct("electron");if(q&&typeof((ie=K==null?void 0:K.shell)==null?void 0:ie.openPath)=="function"){K.shell.openPath(U?Ta(C):C),pe.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Z=K==null?void 0:K.shell)==null?void 0:Z.openExternal)=="function"?K.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),pe.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function v(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function V(){const C=a.value||d.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function H(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function $(){if(!W){pe.showMessage("请先在主编辑区打开幻灯片文档");return}const C=La(W);Pa("presentation.html",C)&&pe.showMessage("已开始下载单文件离线 HTML 演示包")}function I(){if(!W){pe.showMessage("请先在主编辑区打开幻灯片文档");return}Oa(W)&&pe.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(C,U){T.value&&w.value&&U&&U!==w.value||(W=C,T.value&&!w.value&&(w.value=C.docId),u.value=C.slides,g.value=C.slides.length,o.setDocId(C.docId),o.updateSlidesIndex(C.slides),l.value==="pro-cli"?s.scaffolder.scaffold(C,fs).catch(()=>{}):n.updateSlides(C.slides,C.config,C.fullMarkdown,C.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",C.docId))},navigateToBlock(C){o.onCursorFocusBlock(C)},isPinned:T,pinnedDocId:w,engineMode:l,toggleEngineMode:oe}),(C,U)=>(te(),ne("div",{class:"spm-slidev-preview-tab",onKeydown:Y},[h("div",_g,[h("div",Cg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:$e},[ae(ue,{name:"chevron-left"})],8,$g),h("span",Ig,ge(f.value)+" / "+ge(g.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=g.value,"aria-label":"下一页",onClick:ke},[ae(ue,{name:"chevron-right"})],8,Tg),h("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":T.value}]),"aria-label":T.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:re},[ae(ue,{name:"pin"}),h("span",null,ge(T.value?"已锁定":"跟随"),1)],10,Eg),h("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:oe},[ae(ue,{name:"rocket"}),h("span",null,ge(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Ag)]),h("div",Bg,[h("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":m.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:U[0]||(U[0]=q=>m.value=!m.value)},[ae(ue,{name:"outline"})],2),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:S},[ae(ue,{name:"columns"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:H},[ae(ue,{name:"presenter"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:$},[ae(ue,{name:"export-html"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:I},[ae(ue,{name:"export-pdf"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:X},[ae(ue,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:V},[ae(ue,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:me},[h("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:k.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Mg),ae(lm,{visible:p.value,"onUpdate:visible":U[1]||(U[1]=q=>p.value=q),"is-maximized":b.value,"onUpdate:isMaximized":U[2]||(U[2]=q=>b.value=q),title:B.value,onClose:se},{default:Fl(()=>[y.value==="siyuan"&&x.value?(te(),Pt(gm,{key:0,"block-id":x.value,title:B.value,plugin:be(i),onExternalJump:L},null,8,["block-id","title","plugin"])):Me("",!0),M.value?Et((te(),Pt(Gm,{key:1,visible:p.value&&y.value==="web",url:_.value,title:B.value,onExternalJump:L},null,8,["visible","url","title"])),[[Cs,y.value==="web"]]):Me("",!0)]),_:1},8,["visible","is-maximized","title"]),Et(h("div",{class:_e(["spm-jump-badge",{"is-invalid":O.value}])},ge(P.value),3),[[Cs,P.value]])],544),m.value&&u.value.length>0?(te(),Pt(Xh,{key:0,slides:u.value,"current-active-page":f.value,onNavigate:ce,onRefresh:X},null,8,["slides","current-active-page"])):Me("",!0)],32))}}),Lg=Mt(Dg,[["__scopeId","data-v-3d9b9312"]]);function Na(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let o=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&i.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const g=parseInt(f,10);o=Math.max(o,g),n.set(r.parentContainerId,g)}else o+=1,n.set(r.parentContainerId,o)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const f=n.get(r.parentContainerId);s(r,{type:"step",step:f})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){o+=1,s(r,{type:"step",step:o});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const g=Math.min(Number(f[0]),Number(f[1])),u=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(g)&&!isNaN(u)){o=Math.max(o,u),s(r,{type:"range",min:g,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){o+=1,s(r,{type:"hide",step:o});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;o+=f,s(r,{type:"step",step:o});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;o=Math.max(1,o-f),s(r,{type:"step",step:o});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){o=Math.max(o,f),s(r,{type:"step",step:f});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(o=Math.max(o,d),s(r,{type:"step",step:d})):(o+=1,s(r,{type:"step",step:o}))}return{maxStep:o,blockMap:t,idMap:i}}function Pg(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,o=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!o||o.type==="always"?"v-click-visible":o.type==="range"?t>=o.min&&t<=o.max?"v-click-visible":"v-click-hidden":o.type==="hide"?t<o.step?"v-click-visible":"v-click-hidden":o.type==="step"?t>=o.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const As=980;function Og(e){if(!e)return 0;const i=Na(e.blocks||[]).maxStep||0,n=e.frontmatter||{},o=n.mask;if(o!=="down"&&o!=="right")return i;const s=Vc(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(i,r)}function Rg(e,t=As){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const s=i.includes("/")?"/":":",l=i.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const s=parseFloat(i);!isNaN(s)&&s>.2&&s<5&&(n=s)}const o=Math.ceil(t/n);return{baseWidth:t,baseHeight:o,ratio:n}}function Zr(e,t,i=As,n=552,o=16){const s=i>0?i:As,l=n>0?n:552,r=Math.max(0,e-o),a=Math.max(0,t-o);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(s*d)),boxHeight:Math.max(1,Math.round(l*d))}}function Ng(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function Yr(e,t){if(!e)return"";const i=Ng(e),n=i.frontmatter||{},o=n.layout||"default",s=(t==null?void 0:t.config)||{};(o==="image-right"||o==="image-left")&&!n.image&&!n.background&&s.image&&(n.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?Na(i.blocks||[]):null,d=Da(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:a?_=>{if(Pg(_,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const M=_.id||_.blockId,T=a.blockMap.get(_)||(M?a.idMap.get(M):void 0);if((T==null?void 0:T.type)==="step"&&T.step===r||(T==null?void 0:T.type)==="range"&&T.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(_,B)=>{let M=B.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(M)||(M+=" muted"),`<video ${M.trim()}>`}),f=n.spacing,g=f&&f!=="inherit"?f:s.spacing||"normal",u=["slide-content",`layout-${o}`,`spacing-${g}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),m=[],p=(n.background||"").trim();if(p)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(p)){const _=p.startsWith("assets/")?`/${p}`:p.startsWith("./assets/")?p.slice(1):p;m.push(`background-image:url('${ot(_)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else m.push(`background:${ot(p)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&m.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=m.length>0?` style="${m.join("")}"`:"";return`<div class="${ot(u)}"${x}>${d}</div>`}const zg={class:"presenter-header"},Fg={class:"presenter-title"},Hg={key:0,class:"header-step-badge"},jg={class:"header-timer"},Wg={class:"timer-badge"},Ug={class:"timer-controls"},Vg={key:0,class:"presenter-grid"},Kg={class:"slide-panels"},Gg={class:"panel-box current-slide-panel"},qg={class:"panel-header"},Zg={class:"panel-header-meta"},Yg={key:0,class:"panel-step-pill"},Jg=["aria-label"],Xg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Qg={key:1,class:"panel-fallback"},ev=["title"],tv={class:"panel-header"},iv={key:0},nv={key:1},ov=["aria-label"],sv=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],rv={key:1,class:"panel-fallback"},lv={class:"notes-panel"},av={class:"panel-header"},cv={class:"notes-size-controls"},dv={class:"notes-size-value"},uv={key:1,class:"presenter-empty"},fv={class:"presenter-actions"},pv={class:"nav-btn-group"},hv=["disabled"],mv=["disabled"],gv={class:"actions-center"},vv={key:0,class:"step-progress-text"},bv={class:"nav-btn-group"},yv=["disabled"],kv=["disabled"],wv=280,xv=15,Sv=xt({__name:"SlidevPresenterTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Wo),o=fe([]),s=fe({}),l=fe(1),r=fe(0),a=fe(0),c=fe(0),d=ye(()=>o.value.length||a.value),f=fe(null),g=fe(null),u=fe({width:0,height:0}),m=fe({width:0,height:0}),p=ye(()=>{var Z;return Rg((Z=s.value)==null?void 0:Z.aspectRatio)}),b=ye(()=>{var Z;return((Z=s.value)==null?void 0:Z.theme)||"default"}),y=ye(()=>{var Z;return((Z=s.value)==null?void 0:Z.colorSchema)==="light"?"light":"dark"}),x=ye(()=>{var Z;return!!((Z=s.value)!=null&&Z.normalizeHeadingSizes)}),_=ye(()=>Zr(u.value.width,u.value.height,p.value.baseWidth,p.value.baseHeight,14)),B=ye(()=>Zr(m.value.width,m.value.height,p.value.baseWidth,p.value.baseHeight,14));function M(){f.value&&(u.value={width:f.value.clientWidth,height:f.value.clientHeight}),g.value&&(m.value={width:g.value.clientWidth,height:g.value.clientHeight})}let T=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(T||(T=new window.ResizeObserver(()=>{M()})),T.disconnect(),f.value&&T.observe(f.value),g.value&&T.observe(g.value))}ki([f,g,d],()=>{yo(()=>{w(),M()})},{flush:"post"});const P=fe(0),O=fe(!0);let R=null;const Y=ye(()=>{const Z=String(Math.floor(P.value/60)).padStart(2,"0"),J=String(P.value%60).padStart(2,"0");return`${Z}:${J}`});function S(){O.value=!O.value}function F(){P.value=0}const k=ye(()=>o.value.length===0?null:o.value[l.value-1]||null),E=ye(()=>l.value>=o.value.length?null:o.value[l.value]||null),N=ye(()=>k.value?Og(k.value):c.value),A=ye(()=>l.value>1||r.value>0),D=ye(()=>l.value<d.value||r.value<N.value),z=ye(()=>Yr(k.value,{config:s.value,allSlides:o.value,pageIndex:l.value,currentStep:r.value})),Q=ye(()=>Yr(E.value,{config:s.value,allSlides:o.value,pageIndex:l.value+1})),G=ye(()=>{var J;if(!k.value)return"无内容";const Z=(J=k.value.blocks)==null?void 0:J[0];return(Z==null?void 0:Z.content)||(Z==null?void 0:Z.rawMarkdown)||`第 ${l.value} 页`});function W(Z){return(Z||[]).slice(1).map(J=>(J.content||J.rawMarkdown||"").trim()).filter(J=>J&&!/^(image\s+)?assets\/\S*$/i.test(J)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(J)).join(" | ").slice(0,120)}const oe=ye(()=>{var Z;return W((Z=k.value)==null?void 0:Z.blocks)}),re=ye(()=>{var J;if(!E.value)return"演示结束";const Z=(J=E.value.blocks)==null?void 0:J[0];return(Z==null?void 0:Z.content)||(Z==null?void 0:Z.rawMarkdown)||`第 ${l.value+1} 页`}),le=ye(()=>E.value?W(E.value.blocks):"这是最后一页"),me=ye(()=>{var Z;return((Z=k.value)==null?void 0:Z.notes)||""}),$e=fe(20);function ke(){$e.value<36&&($e.value+=2)}function ce(){$e.value>12&&($e.value-=2)}const X=ye(()=>d.value<=1?100:Math.round(l.value/d.value*100));let se=null;try{se=new BroadcastChannel("siyuan-slidev-sync"),se.onmessage=Z=>{const J=Z.data;if(J&&(J.type==="SYNC_PAGE"&&typeof J.page=="number"&&(l.value=J.page,r.value=typeof J.step=="number"?Math.max(0,J.step):0,typeof J.maxStep=="number"&&(c.value=Math.max(0,J.maxStep))),J.type==="SYNC_SLIDES"&&Array.isArray(J.slides)&&(o.value=J.slides,J.config&&typeof J.config=="object"&&(s.value=J.config)),J.type==="REQUEST_SYNC"&&o.value.length>0))try{se==null||se.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(o.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),se==null||se.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:N.value})}catch{}}}catch{se=null}function L(Z,J=0){const de=Number(Z)||1,Se=Math.max(0,Number(J)||0);n.navigatePage(de,Se);try{se==null||se.postMessage({type:"SYNC_PAGE",page:de,step:Se,maxStep:N.value})}catch{}}function j(){if(r.value<N.value){r.value++,L(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,L(l.value,0))}function v(){if(r.value>0){r.value--,L(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,L(l.value,0))}function V(){l.value<d.value&&(l.value++,r.value=0,L(l.value,0))}function H(){l.value>1&&(l.value--,r.value=0,L(l.value,0))}function $(){l.value=1,r.value=0,F(),L(1,0)}function I(){const Z=i;typeof(Z==null?void 0:Z.openBottomPreviewTab)=="function"&&Z.openBottomPreviewTab()}function C(){const Z=i;typeof(Z==null?void 0:Z.openStandalonePreviewWindow)=="function"&&Z.openStandalonePreviewWindow()}function U(Z){var J,de;if(!(Z.key===" "&&((de=(J=Z.target)==null?void 0:J.closest)!=null&&de.call(J,"button")))){if(Z.shiftKey&&Z.key==="ArrowRight"||Z.key==="ArrowDown"){Z.preventDefault(),V();return}if(Z.shiftKey&&Z.key==="ArrowLeft"||Z.key==="ArrowUp"){Z.preventDefault(),H();return}Z.key==="ArrowRight"||Z.key===" "||Z.key==="PageDown"?(Z.preventDefault(),j()):(Z.key==="ArrowLeft"||Z.key==="PageUp")&&(Z.preventDefault(),v())}}let q=0;function K(Z){var Se,xe;if(Math.abs(Z.deltaY)<xv)return;const J=(xe=(Se=Z.target)==null?void 0:Se.closest)==null?void 0:xe.call(Se,".notes-content");if(J){const Ae=J.scrollHeight-J.clientHeight;if(Ae>2&&(Z.deltaY>0&&J.scrollTop<Ae-1||Z.deltaY<0&&J.scrollTop>1))return}const de=Date.now();de-q<wv||(q=de,Z.deltaY>0?j():v())}let ie=null;return un(()=>{var J;R=window.setInterval(()=>{O.value&&P.value++},1e3),ie=n.onSlideChanged((de,Se,xe,Ae,ze)=>{l.value=de,Se>0&&(a.value=Se),typeof Ae=="number"&&(r.value=Math.max(0,Ae)),typeof ze=="number"&&(c.value=Math.max(0,ze))});try{se==null||se.postMessage({type:"REQUEST_SYNC"})}catch{}const Z=i==null?void 0:i.latestCompiledDoc;(J=Z==null?void 0:Z.slides)!=null&&J.length&&(o.value=Z.slides,Z.config&&(s.value=Z.config)),typeof window<"u"&&window.addEventListener("resize",M),yo(()=>{w(),M()})}),No(()=>{R&&(window.clearInterval(R),R=null),ie&&ie(),typeof window<"u"&&window.removeEventListener("resize",M),T&&(T.disconnect(),T=null);try{se==null||se.close()}catch{}se=null}),t({updateDocument(Z){var J;(J=Z==null?void 0:Z.slides)!=null&&J.length&&(o.value=Z.slides),Z!=null&&Z.config&&(s.value=Z.config)}}),(Z,J)=>{var de,Se,xe;return te(),ne("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:U,onWheel:K},[h("header",zg,[h("div",Fg,[J[1]||(J[1]=h("span",{class:"title-name"},"🎤 Slidev 演讲者控制台",-1)),J[2]||(J[2]=h("span",{class:"title-divider"},"|",-1)),h("span",null,"第 "+ge(l.value)+" / "+ge(d.value||1)+" 页",1),N.value>0?(te(),ne("span",Hg," ⚡ 步进 "+ge(r.value)+" / "+ge(N.value),1)):Me("",!0)]),h("div",jg,[h("button",{class:"btn-popout-window",title:"将大屏放映弹出为 16:9 独立窗口，便于会议软件按窗口共享或双屏扩展投屏",onClick:C}," 🗗 弹出独立放映窗口 "),h("div",Wg,"⏱ 已演讲: "+ge(Y.value),1),h("div",Ug,[h("button",{onClick:S},ge(O.value?"暂停":"开始"),1),h("button",{onClick:F},"重置")])])]),d.value>0?(te(),ne("main",Vg,[h("section",Kg,[h("div",Gg,[h("div",qg,[h("span",null,"当前大屏放映 (Page "+ge(l.value)+")",1),h("div",Zg,[N.value>0?(te(),ne("span",Yg," 步进: "+ge(r.value)+" / "+ge(N.value),1)):Me("",!0),h("span",null,"布局: "+ge(((Se=(de=k.value)==null?void 0:de.frontmatter)==null?void 0:Se.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":G.value},[k.value?(te(),ne("div",{key:0,class:"presenter-thumb-box",style:Gt({width:_.value.boxWidth+"px",height:_.value.boxHeight+"px"})},[h("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Gt({width:p.value.baseWidth+"px",height:p.value.baseHeight+"px",transform:"scale("+_.value.scale+")"}),innerHTML:z.value},null,14,Xg)],4)):(te(),ne("div",Qg,[h("h2",null,ge(G.value),1),h("p",null,ge(oe.value),1)]))],8,Jg)]),h("div",{class:_e(["panel-box next-slide-panel",{"is-clickable":!!E.value}]),title:E.value?"点击直接跳至下一页":"",onClick:J[0]||(J[0]=Ae=>E.value&&V())},[h("div",tv,[h("span",null,"下一页预告 (Page "+ge(l.value+1)+")",1),l.value>=d.value?(te(),ne("span",iv,"已到达最后一页")):E.value?(te(),ne("span",nv,"布局: "+ge(((xe=E.value.frontmatter)==null?void 0:xe.layout)||"default"),1)):Me("",!0)]),h("div",{ref_key:"nextPreviewRef",ref:g,class:"panel-preview panel-preview--dim","aria-label":re.value},[E.value?(te(),ne("div",{key:0,class:"presenter-thumb-box",style:Gt({width:B.value.boxWidth+"px",height:B.value.boxHeight+"px"})},[h("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Gt({width:p.value.baseWidth+"px",height:p.value.baseHeight+"px",transform:"scale("+B.value.scale+")"}),innerHTML:Q.value},null,14,sv)],4)):(te(),ne("div",rv,[h("h2",null,ge(re.value),1),h("p",null,ge(le.value),1)]))],8,ov)],10,ev)]),h("section",lv,[h("div",av,[J[3]||(J[3]=h("span",null,"📝 演讲者私有备忘录 (Speaker Notes)",-1)),h("div",cv,[h("button",{onClick:ce},"A-"),h("span",dv,ge($e.value)+"px",1),h("button",{onClick:ke},"A+")])]),h("div",{class:"notes-content",style:Gt({fontSize:$e.value+"px"})},ge(me.value||"（本页未设置演讲者备忘录）"),5)])])):(te(),ne("main",uv,[J[4]||(J[4]=h("div",{class:"empty-icon"},"📡",-1)),J[5]||(J[5]=h("h2",null,"等待大屏放映数据…",-1)),J[6]||(J[6]=h("p",null,"演讲者控制台需要「演示预览」页签（大屏放映端）提供幻灯片数据。",-1)),J[7]||(J[7]=h("p",{class:"empty-hint"},"若预览页签在另一窗口放映，本控制台将自动通过广播信道接入。",-1)),h("div",{class:"empty-actions"},[h("button",{class:"btn-empty-action",onClick:I},"打开大屏放映页签"),h("button",{class:"btn-empty-action btn-empty-action--popout",onClick:C}," 🗗 弹出独立放映窗口 ")])])),h("footer",fv,[h("div",pv,[h("button",{class:"btn-nav-slide",disabled:l.value<=1,title:"跳过本页步进，直接返回上一页 (Shift+Left)",onClick:H}," ⏮ 上一页 ",8,hv),h("button",{class:"btn-nav",disabled:!A.value,title:"回退一步或返回上一页 (Left)",onClick:v}," ◀ 上一步 (Left) ",8,mv)]),h("div",gv,[h("span",null,"进度: "+ge(X.value)+"%",1),N.value>0?(te(),ne("span",vv," 步进: "+ge(r.value)+" / "+ge(N.value),1)):Me("",!0),J[8]||(J[8]=h("span",{class:"hint-text"},"空格/方向键逐步触发，Shift+方向键整页快跳",-1)),h("button",{class:"btn-ghost",onClick:$},"⏮ 重头放映")]),h("div",bv,[h("button",{class:"btn-nav",disabled:!D.value,title:"触发下一个 v-click 对象显示或进入下一页 (Right / Space)",onClick:j},ge(r.value<N.value?`下一步 (${r.value+1}/${N.value}) ▶`:"下一步 (Right) ▶"),9,yv),h("button",{class:"btn-nav-slide",disabled:l.value>=d.value,title:"跳过本页剩余步进，直接进入下一页 (Shift+Right)",onClick:V}," 下一页 ⏭ ",8,kv)])])],32)}}}),_v=Mt(Sv,[["__scopeId","data-v-633acea6"]]),Cv={class:"spm-section spm-section--page"},$v={class:"spm-section-header"},Iv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Tv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Ev={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Av={key:1,class:"spm-card-control"},Bv={class:"spm-control-header"},Mv={class:"spm-control-title-group"},Dv={class:"spm-control-title"},Lv={class:"spm-quick-chips"},Pv=["onClick"],Ov={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Rv=["value"],Nv=["aria-label"],zv={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Fv={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Hv={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},jv={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Wv={class:"spm-card-control"},Uv={class:"spm-control-header"},Vv={class:"spm-control-title-group"},Kv={class:"spm-control-title"},Gv={class:"spm-segmented-group"},qv={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Zv={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Yv={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},Jv={class:"spm-quick-chips"},Xv=["onClick"],Qv={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},eb=["value"],tb={style:{display:"flex",gap:"8px","margin-top":"2px"}},ib={style:{flex:"1"}},nb={class:"spm-segmented-group"},ob={style:{flex:"1"}},sb={class:"spm-segmented-group"},rb={class:"spm-card-control"},lb={class:"spm-control-header"},ab={class:"spm-control-title-group"},cb={class:"spm-control-title"},db={class:"spm-segmented-group"},ub={class:"spm-card-control"},fb={class:"spm-control-header"},pb={class:"spm-control-title-group"},hb={class:"spm-control-title"},mb={class:"spm-quick-chips"},gb=["onClick"],vb=["value"],bb={key:2,class:"spm-card-control"},yb={class:"spm-control-header"},kb={class:"spm-control-title-group"},wb={class:"spm-control-title"},xb={class:"spm-quick-chips"},Sb=["onClick"],_b=["value"],Cb={class:"spm-card-control"},$b={class:"spm-control-header"},Ib={class:"spm-control-title-group"},Tb={class:"spm-control-title"},Eb={key:0,class:"spm-note-status-box"},Ab=["title"],Bb={class:"spm-action-grid",style:{"margin-top":"6px"}},Mb={key:1,class:"spm-note-empty-box"},Db={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Lb={class:"spm-action-grid"},Pb=["disabled"],Ob=["disabled"],Rb={class:"spm-card-control"},Nb={class:"spm-action-grid"},zb=xt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,o=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=ye(()=>{var p,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const y=u.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}const m=(i.detectedSbRatio||"").trim();if(m.includes(":")){const y=m.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}if((p=i.detectedSbInfo)!=null&&p.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const y=i.detectedSbInfo.slots.length;if(y>=2&&y<=6)return y}return 2}),r=ye(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=ye(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,m=Array(u).fill("1").join(":");n("update:pageLayoutRatio",m),n("resetSuperblockRatio")}const d=ye(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),f=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],g=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,m)=>(te(),ne("div",Cv,[h("div",$v,[h("span",null,"幻灯片页面设置"+ge(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),ae(Ia,{"model-value":e.pageLayout,onChange:m[0]||(m[0]=p=>u.$emit("update:pageLayout",p))},null,8,["model-value"]),!s.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(te(),ne("div",Iv,[h("div",Tv,[h("div",Ev,[ae(ue,{name:"sparkles"}),h("span",null,[m[31]||(m[31]=$t("检测到本页横向超级块列宽比例：",-1)),h("b",null,ge(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:m[1]||(m[1]=p=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[ae(ue,{name:"columns"}),m[32]||(m[32]=h("span",null,"设为分栏",-1))])])])):Me("",!0),s.value?(te(),ne("div",Av,[h("div",Bv,[h("div",Mv,[h("div",Dv,[ae(ue,{name:"ratio"}),m[33]||(m[33]=h("span",null,"分栏比例 (Ratio)",-1))]),m[34]||(m[34]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",Lv,[(te(!0),ne(Ve,null,kt(r.value,p=>(te(),ne("button",{key:p.value,class:_e(["spm-chip",{active:a.value===p.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",p.value)},ge(p.label),11,Pv))),128))]),h("div",Ov,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:m[2]||(m[2]=p=>u.$emit("update:pageLayoutRatio",p.target.value)),onChange:m[3]||(m[3]=p=>u.$emit("update:pageLayoutRatio",p.target.value))},null,40,Rv),e.detectedSbRatio?(te(),ne("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m[4]||(m[4]=p=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[ae(ue,{name:"sparkles"}),m[35]||(m[35]=h("span",null,"读取",-1))],8,Nv)):(te(),ne("button",zv,[ae(ue,{name:"sparkles"}),m[36]||(m[36]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[ae(ue,{name:"reset"}),m[37]||(m[37]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(te(),ne("div",Fv,[ae(ue,{name:"ratio"}),m[38]||(m[38]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Hv,ge(e.detectedSbRatio),1)])):(te(),ne("div",jv,[ae(ue,{name:"ratio"}),m[39]||(m[39]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Me("",!0),ae(nr,{"model-value":e.pageTransition,onChange:m[5]||(m[5]=p=>u.$emit("update:pageTransition",p))},null,8,["model-value"]),h("div",Wv,[h("div",Uv,[h("div",Vv,[h("div",Kv,[ae(ue,{name:"sparkles"}),m[40]||(m[40]=h("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),m[41]||(m[41]=h("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),h("div",Gv,[h("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:m[6]||(m[6]=p=>u.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:m[7]||(m[7]=p=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:m[8]||(m[8]=p=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(te(),ne("div",qv,[h("div",Zv,[m[43]||(m[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",Yv,[ae(ue,{name:"help"}),m[42]||(m[42]=h("span",null,"输入规则",-1))])]),h("div",Jv,[(te(),ne(Ve,null,kt(o,p=>h("button",{key:p.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===p.value}]),onClick:b=>u.$emit("update:pageMaskRatio",p.value)},ge(p.label),11,Xv)),64))]),h("div",Qv,[h("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:m[9]||(m[9]=p=>u.$emit("update:pageMaskRatio",p.target.value)),onChange:m[10]||(m[10]=p=>u.$emit("update:pageMaskRatio",p.target.value))},null,40,eb)]),m[46]||(m[46]=h("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),h("div",tb,[h("div",ib,[m[44]||(m[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",nb,[h("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:m[11]||(m[11]=p=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:m[12]||(m[12]=p=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",ob,[m[45]||(m[45]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",sb,[h("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:m[13]||(m[13]=p=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:m[14]||(m[14]=p=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Me("",!0)]),h("div",rb,[h("div",lb,[h("div",ab,[h("div",cb,[ae(ue,{name:"ratio"}),m[47]||(m[47]=h("span",null,"页面间距 (Spacing)",-1))]),m[48]||(m[48]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",db,[h("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:m[15]||(m[15]=p=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:m[16]||(m[16]=p=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:m[17]||(m[17]=p=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:m[18]||(m[18]=p=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),h("div",ub,[h("div",fb,[h("div",pb,[h("div",hb,[ae(ue,{name:"palette"}),m[49]||(m[49]=h("span",null,"页面背景 (Background)",-1))]),m[50]||(m[50]=h("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),h("div",mb,[(te(),ne(Ve,null,kt(f,p=>h("button",{key:p.value,class:_e(["spm-chip",{active:e.pageBackground===p.value}]),onClick:b=>u.$emit("update:pageBackground",p.value)},ge(p.label),11,gb)),64))]),h("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:m[19]||(m[19]=p=>u.$emit("update:pageBackground",p.target.value)),onChange:m[20]||(m[20]=p=>u.$emit("update:pageBackground",p.target.value))},null,40,vb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(te(),ne("div",bb,[h("div",yb,[h("div",kb,[h("div",wb,[ae(ue,{name:"image"}),m[51]||(m[51]=h("span",null,"页面图片 (Image)",-1))]),m[52]||(m[52]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",xb,[(te(),ne(Ve,null,kt(g,p=>h("button",{key:p.value,class:_e(["spm-chip",{active:e.pageImage===p.value}]),onClick:b=>u.$emit("update:pageImage",p.value)},ge(p.label),11,Sb)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:m[21]||(m[21]=p=>u.$emit("update:pageImage",p.target.value)),onChange:m[22]||(m[22]=p=>u.$emit("update:pageImage",p.target.value))},null,40,_b)])):Me("",!0),h("div",Cb,[h("div",$b,[h("div",Ib,[h("div",Tb,[ae(ue,{name:"presenter"}),m[53]||(m[53]=h("span",null,"演讲者提词 (Notes)",-1))]),m[54]||(m[54]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),h("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:m[23]||(m[23]=p=>u.$emit("generateNotes"))},[ae(ue,{name:"sparkles"}),m[55]||(m[55]=h("span",null,"AI 讲稿",-1))])]),e.pageNotes?(te(),ne("div",Eb,[m[58]||(m[58]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},ge(d.value),9,Ab),h("div",Bb,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:m[24]||(m[24]=p=>u.$emit("locateNoteBlock"))},[ae(ue,{name:"search"}),m[56]||(m[56]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:m[25]||(m[25]=p=>u.$emit("addNoteBlock"))},[ae(ue,{name:"insert-below"}),m[57]||(m[57]=h("span",null,"追加讲稿块",-1))])])])):(te(),ne("div",Mb,[m[60]||(m[60]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:m[26]||(m[26]=p=>u.$emit("addNoteBlock"))},[ae(ue,{name:"insert-below"}),m[59]||(m[59]=h("span",null,"添加讲稿备注块",-1))])])),h("div",Db,[h("div",Lb,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:m[27]||(m[27]=p=>u.$emit("batchAppendNotes"))},[ae(ue,{name:"insert-below"}),m[61]||(m[61]=h("span",null,"全部追加",-1))],12,Pb),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:m[28]||(m[28]=p=>u.$emit("batchDeleteNotes"))},[ae(ue,{name:"trash"}),m[62]||(m[62]=h("span",null,"全部删除",-1))],12,Ob)])])]),h("div",Rb,[m[65]||(m[65]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",Nb,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:m[29]||(m[29]=p=>u.$emit("insertDividerAfter"))},[ae(ue,{name:"insert-below"}),m[63]||(m[63]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:m[30]||(m[30]=p=>u.$emit("deleteDivider"))},[ae(ue,{name:"trash"}),m[64]||(m[64]=h("span",null,"删除此页",-1))])])])]))}}),Fb=Mt(zb,[["__scopeId","data-v-1f9d4630"]]),Hb={class:"spm-section spm-section--block"},jb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Kb={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Gb={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},qb={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Zb={key:0},Yb={key:1},Jb={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Xb={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Qb={class:"spm-action-grid"},e1={class:"spm-card-control"},t1={class:"spm-control-header"},i1={class:"spm-control-title-group"},n1={class:"spm-control-title"},o1=["aria-label"],s1=["checked"],r1={key:1,class:"spm-card-control"},l1={class:"spm-control-header"},a1={class:"spm-control-title-group"},c1={class:"spm-control-title"},d1={class:"spm-quick-chips"},u1={key:2,class:"spm-card-control"},f1={class:"spm-control-header"},p1={class:"spm-control-title-group"},h1={class:"spm-control-title"},m1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},g1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},v1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},b1=["aria-label"],y1=["checked"],k1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},w1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},x1=["aria-label"],S1=["checked"],_1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},C1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},$1=["aria-label"],I1=["checked"],T1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},E1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},A1=["aria-label"],B1=["checked"],M1={class:"spm-card-control"},D1={class:"spm-control-header"},L1={class:"spm-control-title-group"},P1={class:"spm-control-title"},O1=["aria-label"],R1=["checked"],N1={key:0,class:"spm-quick-chips"},z1=["onClick"],F1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},H1={class:"spm-card-control"},j1={class:"spm-control-header"},W1={class:"spm-control-title-group"},U1={class:"spm-control-title"},V1=["aria-label"],K1=["checked"],G1={key:0,class:"spm-quick-chips"},q1=["onClick"],Z1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Y1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},J1={style:{display:"flex",gap:"6px"}},X1=["value"],Q1=["value"],ey={key:3,class:"spm-card-control"},ty={class:"spm-control-header"},iy={class:"spm-control-title-group"},ny={class:"spm-control-title"},oy={class:"spm-control-desc"},sy={class:"spm-segmented-group"},ry=["onClick"],ly={key:4,class:"spm-card-control"},ay={class:"spm-control-header"},cy={class:"spm-control-title-group"},dy={class:"spm-control-title"},uy={class:"spm-quick-chips"},fy=["onClick"],py=["value"],hy={key:5,class:"spm-card-control"},my={class:"spm-control-header"},gy={class:"spm-control-title-group"},vy={class:"spm-control-title"},by={class:"spm-quick-chips"},yy=["onClick"],ky=["value"],wy={class:"spm-card-control"},xy={class:"spm-action-grid"},Sy=["aria-label"],_y=xt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ye(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),o=ye(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),s=ye(()=>{var w,P,O,R;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(P=i.elemSlot)==null?void 0:P.match(/^col-(\d+)$/);if(T){const Y=parseInt(T[1],10);if(Y>=2&&Y<=6)return Math.max(Y,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((R=(O=i.detectedSbInfo)==null?void 0:O.ratio)!=null&&R.includes(":")){const Y=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(Y.length>=2)return Math.min(Y.length,6)}return 3}),l=ye(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=ye(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,P=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let O=1;O<=w;O++)P.push({value:`col-${O}`,label:`第 ${O} 栏`});return P});function c(T){const w=i.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&s.value===3||T==="col-2"&&w==="right"&&s.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,f=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=ye(()=>!!g.value),m=ye(()=>{var T;return((T=g.value)==null?void 0:T.preset)||"slide-up"}),p=ye(()=>{var T;return((T=g.value)==null?void 0:T.duration)||0}),b=ye(()=>{var T;return((T=g.value)==null?void 0:T.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(T){M(T,p.value,b.value)}function _(T){M(m.value,T,b.value)}function B(T){M(m.value,p.value,T)}function M(T,w,P){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!P){d("update:elemMotion",T);return}const O={preset:T};w>0&&(O.duration=w),P>0&&(O.delay=P),d("update:elemMotion",JSON.stringify(O))}return(T,w)=>{var P,O,R,Y,S,F;return te(),ne("div",Hb,[w[62]||(w[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(P=e.detectedSbInfo)!=null&&P.hasSuperBlock?(te(),ne("div",jb,[h("div",Wb,[h("div",Ub,[h("div",Vb,[ae(ue,{name:"ratio"}),w[24]||(w[24]=h("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",Kb,[h("div",Gb,[h("div",qb,[ae(ue,{name:"ratio"}),(O=e.detectedSbInfo)!=null&&O.isCustomWidth?(te(),ne("span",Zb,"已识别自定义列宽比例")):(te(),ne("span",Yb,"识别到 "+ge(((R=e.detectedSbInfo)==null?void 0:R.colCount)||2)+" 列超级块分栏",1))]),h("code",Jb,ge(((Y=e.detectedSbInfo)==null?void 0:Y.ratio)||"1:1"),1)]),h("div",Xb,ge((S=e.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",Qb,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[ae(ue,{name:"sparkles"}),w[26]||(w[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var E;return T.$emit("applySuperBlockRatio",((E=e.detectedSbInfo)==null?void 0:E.ratio)||"1:1")})},[ae(ue,{name:"check"}),h("span",null,"应用比例 ("+ge(((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1")+")",1)])])])):Me("",!0),h("div",e1,[h("div",t1,[h("div",i1,[h("div",n1,[ae(ue,{name:"presenter"}),w[27]||(w[27]=h("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>T.$emit("toggleNote"))},null,40,s1),w[29]||(w[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,o1)])]),e.isImage||e.imageRole?(te(),ne("div",r1,[h("div",l1,[h("div",a1,[h("div",c1,[ae(ue,{name:"image"}),w[30]||(w[30]=h("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",d1,[h("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>T.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>T.$emit("update:imageRole","background"))},[ae(ue,{name:"image"}),w[32]||(w[32]=h("span",null,"背景图",-1))],2),h("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>T.$emit("update:imageRole","image-left"))},[ae(ue,{name:"image-left"}),w[33]||(w[33]=h("span",null,"图左",-1))],2),h("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>T.$emit("update:imageRole","image-right"))},[ae(ue,{name:"image-right"}),w[34]||(w[34]=h("span",null,"图右",-1))],2)])])):Me("",!0),e.isVideo?(te(),ne("div",u1,[h("div",f1,[h("div",p1,[h("div",h1,[ae(ue,{name:"video"}),w[35]||(w[35]=h("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",m1,[h("div",g1,[h("span",v1,[ae(ue,{name:"sliders"}),w[37]||(w[37]=$t(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>T.$emit("toggleVideoControls"))},null,40,y1),w[38]||(w[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,b1)]),h("div",k1,[h("span",w1,[ae(ue,{name:"video"}),w[39]||(w[39]=$t(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>T.$emit("toggleVideoAutoplay"))},null,40,S1),w[40]||(w[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,x1)]),h("div",_1,[h("span",C1,[ae(ue,{name:"repeat"}),w[41]||(w[41]=$t(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>T.$emit("toggleVideoLoop"))},null,40,I1),w[42]||(w[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,$1)]),h("div",T1,[h("span",E1,[ae(ue,{name:"volume-x"}),w[43]||(w[43]=$t(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>T.$emit("toggleVideoMuted"))},null,40,B1),w[44]||(w[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,A1)])])])):Me("",!0),h("div",M1,[h("div",D1,[h("div",L1,[h("div",P1,[ae(ue,{name:"step"}),w[45]||(w[45]=h("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>T.$emit("toggleElemClick"))},null,40,R1),w[47]||(w[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,O1)]),e.elemClick?(te(),ne("div",N1,[(te(),ne(Ve,null,kt(["+1","1","2","hide"],k=>h("button",{key:k,class:_e(["spm-chip",{active:e.elemClick===k}]),onClick:E=>T.$emit("update:elemClick",k)},ge(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,z1)),64))])):e.parentElemClick?(te(),ne("div",F1,[ae(ue,{name:"check"}),w[48]||(w[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Me("",!0)]),h("div",H1,[h("div",j1,[h("div",W1,[h("div",U1,[ae(ue,{name:"motion"}),w[49]||(w[49]=h("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[h("input",{type:"checkbox",checked:u.value,onChange:y},null,40,K1),w[51]||(w[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,V1)]),u.value?(te(),ne("div",G1,[(te(),ne(Ve,null,kt(f,k=>h("button",{key:k.value,class:_e(["spm-chip",{active:m.value===k.value}]),onClick:E=>x(k.value)},ge(k.label),11,q1)),64))])):Me("",!0),u.value?(te(),ne("div",Z1,[h("div",Y1,[h("span",null,"时长: "+ge(p.value?p.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+ge(b.value?b.value+"ms":"0ms"),1)]),h("div",J1,[h("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:w[12]||(w[12]=k=>_(Number(k.target.value)))},[...w[52]||(w[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,X1),h("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=k=>B(Number(k.target.value)))},[...w[53]||(w[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Q1)])])):Me("",!0)]),o.value||e.elemSlot?(te(),ne("div",ey,[h("div",ty,[h("div",iy,[h("div",ny,[ae(ue,{name:"columns"}),h("span",null,ge(l.value),1)]),h("span",oy,ge(r.value),1)])]),h("div",sy,[(te(!0),ne(Ve,null,kt(a.value,k=>(te(),ne("button",{key:k.value,class:_e(["spm-segmented-item",{active:c(k.value)}]),onClick:E=>T.$emit("update:elemSlot",k.value)},ge(k.label),11,ry))),128))])])):Me("",!0),e.isCodeBlock?(te(),ne("div",ly,[h("div",ay,[h("div",cy,[h("div",dy,[ae(ue,{name:"code"}),w[54]||(w[54]=h("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",uy,[(te(),ne(Ve,null,kt(["1-3","all","1|2|3","2-5"],k=>h("button",{key:k,class:_e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:E=>T.$emit("update:elemShikiLines",k)},ge(k),11,fy)),64)),e.elemShikiLines?(te(),ne("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Me("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>T.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>T.$emit("update:elemShikiLines",k.target.value))},null,40,py)])):Me("",!0),e.isCodeBlock?(te(),ne("div",hy,[h("div",my,[h("div",gy,[h("div",vy,[ae(ue,{name:"code"}),w[56]||(w[56]=h("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",by,[(te(),ne(Ve,null,kt(["240px","320px","400px","50vh"],k=>h("button",{key:k,class:_e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:E=>T.$emit("update:elemMaxHeight",k)},ge(k),11,yy)),64)),e.elemMaxHeight?(te(),ne("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Me("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>T.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>T.$emit("update:elemMaxHeight",k.target.value))},null,40,ky)])):Me("",!0),h("div",wy,[w[61]||(w[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",xy,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>T.$emit("insertDividerBefore"))},[ae(ue,{name:"insert-above"}),w[58]||(w[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>T.$emit("insertDividerAfter"))},[ae(ue,{name:"insert-below"}),w[59]||(w[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>T.$emit("setTwoColsContrast"))},[ae(ue,{name:"columns"}),h("span",null,ge(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Sy),e.hasBlockAttrs?(te(),ne("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=k=>T.$emit("clearBlockAttrs"))},[ae(ue,{name:"broom"}),w[60]||(w[60]=h("span",null,"清除属性",-1))])):Me("",!0)])])])}}}),Cy={class:"spm-section spm-section--doc"},$y={class:"spm-card-control"},Iy={class:"spm-control-header"},Ty={class:"spm-control-title-group"},Ey={class:"spm-control-title"},Ay={class:"spm-segmented-group"},By=["aria-label","onClick"],My={class:"spm-card-control"},Dy={class:"spm-control-header"},Ly={class:"spm-control-title-group"},Py={class:"spm-control-title"},Oy={class:"spm-segmented-group"},Ry={class:"spm-card-control"},Ny={class:"spm-control-header"},zy={class:"spm-control-title-group"},Fy={class:"spm-control-title"},Hy={class:"spm-segmented-group"},jy={class:"spm-card-control"},Wy={class:"spm-control-header"},Uy={class:"spm-control-title-group"},Vy={class:"spm-control-title"},Ky={class:"spm-card-control"},Gy={class:"spm-control-header"},qy={class:"spm-control-title-group"},Zy={class:"spm-control-title"},Yy=["aria-label"],Jy=["checked"],Xy={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Qy=["value"],e0={class:"spm-card-control"},t0={class:"spm-control-header"},i0={class:"spm-control-title-group"},n0={class:"spm-control-title"},o0=["aria-label"],s0=["checked"],r0={class:"spm-card-control"},l0={class:"spm-action-grid"},a0=xt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=Rt("plugin"),i=gi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Di({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Di({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Di({webServeUrl:a})}function r(a){Di({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(te(),ne("div",Cy,[c[39]||(c[39]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",$y,[h("div",Iy,[h("div",Ty,[h("div",Ey,[ae(ue,{name:"palette"}),c[18]||(c[18]=h("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=h("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),h("div",Ay,[(te(),ne(Ve,null,kt(n,d=>h("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:f=>a.$emit("update:docTheme",d.value)},ge(d.label),11,By)),64))])]),h("div",My,[h("div",Dy,[h("div",Ly,[h("div",Py,[ae(ue,{name:"ratio"}),c[20]||(c[20]=h("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",Oy,[h("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",Ry,[h("div",Ny,[h("div",zy,[h("div",Fy,[ae(ue,{name:"ratio"}),c[22]||(c[22]=h("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",Hy,[h("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),h("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),h("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),h("div",jy,[h("div",Wy,[h("div",Uy,[h("div",Vy,[ae(ue,{name:"transition"}),c[24]||(c[24]=h("span",null,"全局默认转场",-1))]),c[25]||(c[25]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ae(nr,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),h("div",Ky,[h("div",Gy,[h("div",qy,[h("div",Zy,[ae(ue,{name:"external-link"}),c[26]||(c[26]=h("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":be(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:be(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>o(d.target.checked))},null,40,Jy),c[28]||(c[28]=h("span",{class:"spm-switch-slider"},null,-1))],8,Yy)]),be(i).enableWebServeJump?(te(),ne("div",Xy,[h("input",{value:be(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Lt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Lt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,Qy),c[29]||(c[29]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Me("",!0)]),h("div",e0,[h("div",t0,[h("div",i0,[h("div",n0,[ae(ue,{name:"type"}),c[30]||(c[30]=h("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":be(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:be(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>s(d.target.checked))},null,40,s0),c[32]||(c[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,o0)])]),h("div",r0,[c[38]||(c[38]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",l0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[ae(ue,{name:"split-preview"}),c[33]||(c[33]=h("span",null,"分屏预览",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[ae(ue,{name:"presenter"}),c[34]||(c[34]=h("span",null,"演讲者视图",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[ae(ue,{name:"sparkles"}),c[35]||(c[35]=h("span",null,"AI 智能分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[ae(ue,{name:"export-html"}),c[36]||(c[36]=h("span",null,"导出 HTML",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[ae(ue,{name:"export-pdf"}),c[37]||(c[37]=h("span",null,"导出 PDF",-1))])])])]))}});var eo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function c0(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function to(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ls={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Jr;function d0(){return Jr||(Jr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var f=typeof to=="function"&&to;if(!d&&f)return f(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(m){var p=n[c][1][m];return l(p||m)},u,u.exports,i,n,o,s)}return o[c].exports}for(var r=typeof to=="function"&&to,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,f,g,u,m,p,b=[],y=0,x=a.length,_=x,B=s.getTypeOf(a)!=="string";y<a.length;)_=x-y,f=B?(c=a[y++],d=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),d=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),g=c>>2,u=(3&c)<<4|d>>4,m=1<_?(15&d)<<2|f>>6:64,p=2<_?63&f:64,b.push(r.charAt(g)+r.charAt(u)+r.charAt(m)+r.charAt(p));return b.join("")},o.decode=function(a){var c,d,f,g,u,m,p=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&_--,a.charAt(a.length-2)===r.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|_):new Array(0|_);p<a.length;)c=r.indexOf(a.charAt(p++))<<2|(g=r.indexOf(a.charAt(p++)))>>4,d=(15&g)<<4|(u=r.indexOf(a.charAt(p++)))>>2,f=(3&u)<<6|(m=r.indexOf(a.charAt(p++))),x[b++]=c,u!==64&&(x[b++]=d),m!==64&&(x[b++]=f);return x}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,f,g,u,m){this.compressedSize=d,this.uncompressedSize=f,this.crc32=g,this.compression=u,this.compressedContent=m}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return d.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,f,g){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(f.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,f,g){var u=l,m=g+f;c^=-1;for(var p=g;p<m;p++)c=c>>>8^u[255&(c^d[p])];return-1^c})(0|a,r,r.length,0):(function(c,d,f,g){var u=l,m=g+f;c^=-1;for(var p=g;p<m;p++)c=c>>>8^u[255&(c^d.charCodeAt(p))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function d(f,g){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=g,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(g){f.push({data:g,meta:f.meta})}},o.compressWorker=function(f){return new d("Deflate",f)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(u,m){var p,b="";for(p=0;p<m;p++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,m,p,b,y,x){var _,B,M=u.file,T=u.compression,w=x!==c.utf8encode,P=r.transformTo("string",x(M.name)),O=r.transformTo("string",c.utf8encode(M.name)),R=M.comment,Y=r.transformTo("string",x(R)),S=r.transformTo("string",c.utf8encode(R)),F=O.length!==M.name.length,k=S.length!==R.length,E="",N="",A="",D=M.dir,z=M.date,Q={crc32:0,compressedSize:0,uncompressedSize:0};m&&!p||(Q.crc32=u.crc32,Q.compressedSize=u.compressedSize,Q.uncompressedSize=u.uncompressedSize);var G=0;m&&(G|=8),w||!F&&!k||(G|=2048);var W=0,oe=0;D&&(W|=16),y==="UNIX"?(oe=798,W|=(function(le,me){var $e=le;return le||($e=me?16893:33204),(65535&$e)<<16})(M.unixPermissions,D)):(oe=20,W|=(function(le){return 63&(le||0)})(M.dosPermissions)),_=z.getUTCHours(),_<<=6,_|=z.getUTCMinutes(),_<<=5,_|=z.getUTCSeconds()/2,B=z.getUTCFullYear()-1980,B<<=4,B|=z.getUTCMonth()+1,B<<=5,B|=z.getUTCDate(),F&&(N=s(1,1)+s(d(P),4)+O,E+="up"+s(N.length,2)+N),k&&(A=s(1,1)+s(d(Y),4)+S,E+="uc"+s(A.length,2)+A);var re="";return re+=`
\0`,re+=s(G,2),re+=T.magic,re+=s(_,2),re+=s(B,2),re+=s(Q.crc32,4),re+=s(Q.compressedSize,4),re+=s(Q.uncompressedSize,4),re+=s(P.length,2),re+=s(E.length,2),{fileRecord:f.LOCAL_FILE_HEADER+re+P+E,dirRecord:f.CENTRAL_FILE_HEADER+s(oe,2)+re+s(Y.length,2)+"\0\0\0\0"+s(W,4)+s(b,4)+P+E+Y}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),f=i("../signature");function g(u,m,p,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=m,this.zipPlatform=p,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(u){var m=u.meta.percent||0,p=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:p?(m+100*(p-b-1))/p:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var m=this.streamFiles&&!u.file.dir;if(m){var p=l(u,m,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:p.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var m=this.streamFiles&&!u.file.dir,p=l(u,m,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(p.dirRecord),m)this.push({data:(function(b){return f.DATA_DESCRIPTOR+s(b.crc32,4)+s(b.compressedSize,4)+s(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:p.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,m=0;m<this.dirRecords.length;m++)this.push({data:this.dirRecords[m],meta:{percent:100}});var p=this.bytesWritten-u,b=(function(y,x,_,B,M){var T=r.transformTo("string",M(B));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(y,2)+s(y,2)+s(x,4)+s(_,4)+s(T.length,2)+T})(this.dirRecords.length,p,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var m=this;return u.on("data",function(p){m.processChunk(p)}),u.on("end",function(){m.closedSource(m.previous.streamInfo),m._sources.length?m.prepareNextSource():m.end()}),u.on("error",function(p){m.error(p)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var m=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var p=0;p<m.length;p++)try{m[p].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,m=0;m<u.length;m++)u[m].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{r.forEach(function(g,u){f++;var m=(function(x,_){var B=x||_,M=s[B];if(!M)throw new Error(B+" is not a valid compression method !");return M})(u.options.compression,a.compression),p=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,y=u.date;u._compressWorker(m,p).withStreamInfo("file",{name:g,dir:b,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=f}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function f(g){return new l.Promise(function(u,m){var p=g.decompressed.getContentWorker().pipe(new c);p.on("error",function(b){m(b)}).on("end",function(){p.streamInfo.crc32!==g.decompressed.crc32?m(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(g,u){var m=this;return u=s.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(p){var b=new a(u);return b.load(p),b}).then(function(p){var b=[l.Promise.resolve(p)],y=p.files;if(u.checkCRC32)for(var x=0;x<y.length;x++)b.push(f(y[x]));return l.Promise.all(b)}).then(function(p){for(var b=p.shift(),y=b.files,x=0;x<y.length;x++){var _=y[x],B=_.fileNameStr,M=s.resolve(_.fileNameStr);m.file(M,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:u.createFolders}),_.dir||(m.file(M).unsafeOriginalName=B)}return b.zipComment.length&&(m.comment=b.zipComment),m})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(f,g){d.push(f)||d._helper.pause(),c&&c(g)}).on("error",function(f){d.emit("error",f)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(M,T,w){var P,O=r.getTypeOf(T),R=r.extend(w||{},d);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(M=y(M)),R.createFolders&&(P=b(M))&&x.call(this,P,!0);var Y=O==="string"&&R.binary===!1&&R.base64===!1;w&&w.binary!==void 0||(R.binary=!Y),(T instanceof f&&T.uncompressedSize===0||R.dir||!T||T.length===0)&&(R.base64=!1,R.binary=!0,T="",R.compression="STORE",O="string");var S=null;S=T instanceof f||T instanceof a?T:m.isNode&&m.isStream(T)?new p(M,T):r.prepareContent(M,T,R.binary,R.optimizedBinaryString,R.base64);var F=new g(M,S,R);this.files[M]=F}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),f=i("./compressedObject"),g=i("./zipObject"),u=i("./generate"),m=i("./nodejsUtils"),p=i("./nodejs/NodejsStreamInputAdapter"),b=function(M){M.slice(-1)==="/"&&(M=M.substring(0,M.length-1));var T=M.lastIndexOf("/");return 0<T?M.substring(0,T):""},y=function(M){return M.slice(-1)!=="/"&&(M+="/"),M},x=function(M,T){return T=T!==void 0?T:d.createFolders,M=y(M),this.files[M]||s.call(this,M,null,{dir:!0,createFolders:T}),this.files[M]};function _(M){return Object.prototype.toString.call(M)==="[object RegExp]"}var B={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(M){var T,w,P;for(T in this.files)P=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&M(w,P)},filter:function(M){var T=[];return this.forEach(function(w,P){M(w,P)&&T.push(P)}),T},file:function(M,T,w){if(arguments.length!==1)return M=this.root+M,s.call(this,M,T,w),this;if(_(M)){var P=M;return this.filter(function(R,Y){return!Y.dir&&P.test(R)})}var O=this.files[this.root+M];return O&&!O.dir?O:null},folder:function(M){if(!M)return this;if(_(M))return this.filter(function(O,R){return R.dir&&M.test(O)});var T=this.root+M,w=x.call(this,T),P=this.clone();return P.root=w.name,P},remove:function(M){M=this.root+M;var T=this.files[M];if(T||(M.slice(-1)!=="/"&&(M+="/"),T=this.files[M]),T&&!T.dir)delete this.files[M];else for(var w=this.filter(function(O,R){return R.name.slice(0,M.length)===M}),P=0;P<w.length;P++)delete this.files[w[P].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(M){var T,w={};try{if((w=r.extend(M||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var P=w.comment||this.comment||"";T=u.generateWorker(this,w,P)}catch(O){(T=new a("error")).error(O)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function(M,T){return this.generateInternalStream(M).accumulate(T)},generateNodeStream:function(M,T){return(M=M||{}).type||(M.type="nodebuffer"),this.generateInternalStream(M).toNodejsStream(T)}};n.exports=B},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),f=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===f)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),f=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&f===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(f){var g=s.getTypeOf(f);return s.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(f):l.uint8array?new d(s.transformTo("uint8array",f)):new r(s.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(m,p){return new d.Promise(function(b,y){var x=[],_=m._internalType,B=m._outputType,M=m._mimeType;m.on("data",function(T,w){x.push(T),p&&p(w)}).on("error",function(T){x=[],y(T)}).on("end",function(){try{var T=(function(w,P,O){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",P),O);case"base64":return a.encode(P);default:return s.transformTo(w,P)}})(B,(function(w,P){var O,R=0,Y=null,S=0;for(O=0;O<P.length;O++)S+=P[O].length;switch(w){case"string":return P.join("");case"array":return Array.prototype.concat.apply([],P);case"uint8array":for(Y=new Uint8Array(S),O=0;O<P.length;O++)Y.set(P[O],R),R+=P[O].length;return Y;case"nodebuffer":return Buffer.concat(P);default:throw new Error("concat : unsupported type '"+w+"'")}})(_,x),M);b(T)}catch(w){y(w)}x=[]}).resume()})}function u(m,p,b){var y=p;switch(p){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=p,this._mimeType=b,s.checkSupport(y),this._worker=m.pipe(new l(y)),m.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(m){return g(this,m)},on:function(m,p){var b=this;return m==="data"?this._worker.on(m,function(y){p.call(b,y.data,y.meta)}):this._worker.on(m,function(){s.delay(p,arguments,b)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(m){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},m)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(m){var p,b,y,x,_,B=m.length,M=0;for(x=0;x<B;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<B&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),M+=b<128?1:b<2048?2:b<65536?3:4;for(p=l.uint8array?new Uint8Array(M):new Array(M),x=_=0;_<M;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<B&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?p[_++]=b:(b<2048?p[_++]=192|b>>>6:(b<65536?p[_++]=224|b>>>12:(p[_++]=240|b>>>18,p[_++]=128|b>>>12&63),p[_++]=128|b>>>6&63),p[_++]=128|63&b);return p})(u)},o.utf8decode=function(u){return l.nodebuffer?s.transformTo("nodebuffer",u).toString("utf-8"):(function(m){var p,b,y,x,_=m.length,B=new Array(2*_);for(p=b=0;p<_;)if((y=m[p++])<128)B[b++]=y;else if(4<(x=c[y]))B[b++]=65533,p+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&p<_;)y=y<<6|63&m[p++],x--;1<x?B[b++]=65533:y<65536?B[b++]=y:(y-=65536,B[b++]=55296|y>>10&1023,B[b++]=56320|1023&y)}return B.length!==b&&(B.subarray?B=B.subarray(0,b):B.length=b),s.applyFromCharCode(B)})(u=s.transformTo(l.uint8array?"uint8array":"array",u))},s.inherits(f,a),f.prototype.processChunk=function(u){var m=s.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var p=m;(m=new Uint8Array(p.length+this.leftOver.length)).set(this.leftOver,0),m.set(p,this.leftOver.length)}else m=this.leftOver.concat(m);this.leftOver=null}var b=(function(x,_){var B;for((_=_||x.length)>x.length&&(_=x.length),B=_-1;0<=B&&(192&x[B])==128;)B--;return B<0||B===0?_:B+c[x[B]]>_?B:_})(m),y=m;b!==m.length&&(l.uint8array?(y=m.subarray(0,b),this.leftOver=m.subarray(b,m.length)):(y=m.slice(0,b),this.leftOver=m.slice(b,m.length))),this.push({data:o.utf8decode(y),meta:u.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=f,s.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(p){return p}function d(p,b){for(var y=0;y<p.length;++y)b[y]=255&p.charCodeAt(y);return b}i("setimmediate"),o.newBlob=function(p,b){o.checkSupport("blob");try{return new Blob([p],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(p),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(p,b,y){var x=[],_=0,B=p.length;if(B<=y)return String.fromCharCode.apply(null,p);for(;_<B;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,p.slice(_,Math.min(_+y,B)))):x.push(String.fromCharCode.apply(null,p.subarray(_,Math.min(_+y,B)))),_+=y;return x.join("")},stringifyByChar:function(p){for(var b="",y=0;y<p.length;y++)b+=String.fromCharCode(p[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(p){var b=65536,y=o.getTypeOf(p),x=!0;if(y==="uint8array"?x=f.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=f.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return f.stringifyByChunk(p,y,b)}catch{b=Math.floor(b/2)}return f.stringifyByChar(p)}function u(p,b){for(var y=0;y<p.length;y++)b[y]=p[y];return b}o.applyFromCharCode=g;var m={};m.string={string:c,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return m.string.uint8array(p).buffer},uint8array:function(p){return d(p,new Uint8Array(p.length))},nodebuffer:function(p){return d(p,r.allocBuffer(p.length))}},m.array={string:g,array:c,arraybuffer:function(p){return new Uint8Array(p).buffer},uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(p)}},m.arraybuffer={string:function(p){return g(new Uint8Array(p))},array:function(p){return u(new Uint8Array(p),new Array(p.byteLength))},arraybuffer:c,uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(new Uint8Array(p))}},m.uint8array={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return p.buffer},uint8array:c,nodebuffer:function(p){return r.newBufferFrom(p)}},m.nodebuffer={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return m.nodebuffer.uint8array(p).buffer},uint8array:function(p){return u(p,new Uint8Array(p.length))},nodebuffer:c},o.transformTo=function(p,b){if(b=b||"",!p)return b;o.checkSupport(p);var y=o.getTypeOf(b);return m[y][p](b)},o.resolve=function(p){for(var b=p.split("/"),y=[],x=0;x<b.length;x++){var _=b[x];_==="."||_===""&&x!==0&&x!==b.length-1||(_===".."?y.pop():y.push(_))}return y.join("/")},o.getTypeOf=function(p){return typeof p=="string"?"string":Object.prototype.toString.call(p)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(p)?"nodebuffer":s.uint8array&&p instanceof Uint8Array?"uint8array":s.arraybuffer&&p instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(p){if(!s[p.toLowerCase()])throw new Error(p+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(p){var b,y,x="";for(y=0;y<(p||"").length;y++)x+="\\x"+((b=p.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},o.delay=function(p,b,y){setImmediate(function(){p.apply(y||null,b||[])})},o.inherits=function(p,b){function y(){}y.prototype=b.prototype,p.prototype=new y},o.extend=function(){var p,b,y={};for(p=0;p<arguments.length;p++)for(b in arguments[p])Object.prototype.hasOwnProperty.call(arguments[p],b)&&y[b]===void 0&&(y[b]=arguments[p][b]);return y},o.prepareContent=function(p,b,y,x,_){return a.Promise.resolve(b).then(function(B){return s.blob&&(B instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(B))!==-1)&&typeof FileReader<"u"?new a.Promise(function(M,T){var w=new FileReader;w.onload=function(P){M(P.target.result)},w.onerror=function(P){T(P.target.error)},w.readAsArrayBuffer(B)}):B}).then(function(B){var M=o.getTypeOf(B);return M?(M==="arraybuffer"?B=o.transformTo("uint8array",B):M==="string"&&(_?B=l.decode(B):y&&x!==!0&&(B=(function(T){return d(T,s.uint8array?new Uint8Array(T.length):new Array(T.length))})(B))),B):a.Promise.reject(new Error("Can't read the data of '"+p+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(f){this.files=[],this.loadOptions=f}d.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(f)+")")}},isSignature:function(f,g){var u=this.reader.index;this.reader.setIndex(f);var m=this.reader.readString(4)===g;return this.reader.setIndex(u),m},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,f);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,g,u,m=this.zip64EndOfCentralSize-44;0<m;)f=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[f]={id:f,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,g;for(f=0;f<this.files.length;f++)g=this.files[f],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var g=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var m=g-u;if(0<m)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=m);else if(m<0)throw new Error("Corrupted zip: missing "+Math.abs(m)+" bytes.")},prepareReader:function(f){this.reader=s(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),f=i("./support");function g(u,m){this.options=u,this.loadOptions=m}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var m,p;if(u.skip(22),this.fileNameLength=u.readInt(2),p=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(p),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((m=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,m,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var m=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(m),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var m,p,b,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)m=u.readInt(2),p=u.readInt(2),b=u.readData(p),this.extraFields[m]={id:m,length:p,value:b};u.setIndex(y)},handleUTF8:function(){var u=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var m=this.findExtraFieldUnicodePath();if(m!==null)this.fileNameStr=m;else{var p=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(p)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var m=s(u.value);return m.readInt(1)!==1||a(this.fileName)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var m=s(u.value);return m.readInt(1)!==1||a(this.fileComment)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(m,p,b){this.name=m,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=p,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");s.prototype={internalStream:function(m){var p=null,b="string";try{if(!m)throw new Error("No output type specified.");var y=(b=m.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),p=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(p=p.pipe(new a.Utf8EncodeWorker)),!x&&y&&(p=p.pipe(new a.Utf8DecodeWorker))}catch(_){(p=new d("error")).error(_)}return new l(p,b,"")},async:function(m,p){return this.internalStream(m).accumulate(p)},nodeStream:function(m,p){return this.internalStream(m||"nodebuffer").toNodejsStream(p)},_compressWorker:function(m,p){if(this._data instanceof c&&this._data.compression.magic===m.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,m,p)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<f.length;u++)s.prototype[f[u]]=g;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(m),f=s.document.createTextNode("");d.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var p=s.document.createElement("script");p.onreadystatechange=function(){m(),p.onreadystatechange=null,p.parentNode.removeChild(p),p=null},s.document.documentElement.appendChild(p)}:function(){setTimeout(m,0)};else{var g=new s.MessageChannel;g.port1.onmessage=m,l=function(){g.port2.postMessage(0)}}var u=[];function m(){var p,b;r=!0;for(var y=u.length;y;){for(b=u,u=[],p=-1;++p<y;)b[p]();y=u.length}r=!1}n.exports=function(p){u.push(p)!==1||r||l()}}).call(this,typeof eo<"u"?eo:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function f(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&p(this,y)}function g(y,x,_){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function u(y,x,_){s(function(){var B;try{B=x(_)}catch(M){return r.reject(y,M)}B===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,B)})}function m(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function p(y,x){var _=!1;function B(w){_||(_=!0,r.reject(y,w))}function M(w){_||(_=!0,r.resolve(y,w))}var T=b(function(){x(M,B)});T.status==="error"&&B(T.value)}function b(y,x){var _={};try{_.value=y(x),_.status="success"}catch(B){_.status="error",_.value=B}return _}(n.exports=f).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(_){return x.resolve(y()).then(function(){return _})},function(_){return x.resolve(y()).then(function(){throw _})})},f.prototype.catch=function(y){return this.then(null,y)},f.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?u(_,this.state===c?y:x,this.outcome):this.queue.push(new g(_,y,x)),_},g.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},g.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},g.prototype.callRejected=function(y){r.reject(this.promise,y)},g.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,x){var _=b(m,x);if(_.status==="error")return r.reject(y,_.value);var B=_.value;if(B)p(y,B);else{y.state=c,y.outcome=x;for(var M=-1,T=y.queue.length;++M<T;)y.queue[M].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var _=-1,B=y.queue.length;++_<B;)y.queue[_].callRejected(x);return y},f.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},f.reject=function(y){var x=new this(l);return r.reject(x,y)},f.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,B=!1;if(!_)return this.resolve([]);for(var M=new Array(_),T=0,w=-1,P=new this(l);++w<_;)O(y[w],w);return P;function O(R,Y){x.resolve(R).then(function(S){M[Y]=S,++T!==_||B||(B=!0,r.resolve(P,M))},function(S){B||(B=!0,r.reject(P,S))})}},f.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,B=!1;if(!_)return this.resolve([]);for(var M=-1,T=new this(l);++M<_;)w=y[M],x.resolve(w).then(function(P){B||(B=!0,r.resolve(T,P))},function(P){B||(B=!0,r.reject(T,P))});var w;return T}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,f=0,g=-1,u=0,m=8;function p(y){if(!(this instanceof p))return new p(y);this.options=l.assign({level:g,method:m,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(_!==f)throw new Error(a[_]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var B;if(B=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(_=s.deflateSetDictionary(this.strm,B))!==f)throw new Error(a[_]);this._dict_set=!0}}function b(y,x){var _=new p(x);if(_.push(y,!0),_.err)throw _.msg||a[_.err];return _.result}p.prototype.push=function(y,x){var _,B,M=this.strm,T=this.options.chunkSize;if(this.ended)return!1;B=x===~~x?x:x===!0?4:0,typeof y=="string"?M.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?M.input=new Uint8Array(y):M.input=y,M.next_in=0,M.avail_in=M.input.length;do{if(M.avail_out===0&&(M.output=new l.Buf8(T),M.next_out=0,M.avail_out=T),(_=s.deflate(M,B))!==1&&_!==f)return this.onEnd(_),!(this.ended=!0);M.avail_out!==0&&(M.avail_in!==0||B!==4&&B!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(M.output,M.next_out))):this.onData(l.shrinkBuf(M.output,M.next_out)))}while((0<M.avail_in||M.avail_out===0)&&_!==1);return B===4?(_=s.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===f):B!==2||(this.onEnd(f),!(M.avail_out=0))},p.prototype.onData=function(y){this.chunks.push(y)},p.prototype.onEnd=function(y){y===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},o.Deflate=p,o.deflate=b,o.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},o.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),f=i("./zlib/gzheader"),g=Object.prototype.toString;function u(p){if(!(this instanceof u))return new u(p);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},p||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||p&&p.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=s.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new f,s.inflateGetHeader(this.strm,this.header)}function m(p,b){var y=new u(b);if(y.push(p,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(p,b){var y,x,_,B,M,T,w=this.strm,P=this.options.chunkSize,O=this.options.dictionary,R=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof p=="string"?w.input=r.binstring2buf(p):g.call(p)==="[object ArrayBuffer]"?w.input=new Uint8Array(p):w.input=p,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(P),w.next_out=0,w.avail_out=P),(y=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&O&&(T=typeof O=="string"?r.string2buf(O):g.call(O)==="[object ArrayBuffer]"?new Uint8Array(O):O,y=s.inflateSetDictionary(this.strm,T)),y===a.Z_BUF_ERROR&&R===!0&&(y=a.Z_OK,R=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=r.utf8border(w.output,w.next_out),B=w.next_out-_,M=r.buf2string(w.output,_),w.next_out=B,w.avail_out=P-B,B&&l.arraySet(w.output,w.output,_,B,0),this.onData(M)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(R=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=s.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(p){this.chunks.push(p)},u.prototype.onEnd=function(p){p===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},o.Inflate=u,o.inflate=m,o.inflateRaw=function(p,b){return(b=b||{}).raw=!0,m(p,b)},o.ungzip=m},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var f in d)d.hasOwnProperty(f)&&(a[f]=d[f])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,f,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+f),g);else for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,f,g,u,m;for(c=f=0,d=a.length;c<d;c++)f+=a[c].length;for(m=new Uint8Array(f),c=g=0,d=a.length;c<d;c++)u=a[c],m.set(u,g),g+=u.length;return m}},r={arraySet:function(a,c,d,f,g){for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(f,g){if(g<65537&&(f.subarray&&r||!f.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(f,g));for(var u="",m=0;m<g;m++)u+=String.fromCharCode(f[m]);return u}a[254]=a[254]=1,o.string2buf=function(f){var g,u,m,p,b,y=f.length,x=0;for(p=0;p<y;p++)(64512&(u=f.charCodeAt(p)))==55296&&p+1<y&&(64512&(m=f.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),p++),x+=u<128?1:u<2048?2:u<65536?3:4;for(g=new s.Buf8(x),p=b=0;b<x;p++)(64512&(u=f.charCodeAt(p)))==55296&&p+1<y&&(64512&(m=f.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),p++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},o.buf2binstring=function(f){return d(f,f.length)},o.binstring2buf=function(f){for(var g=new s.Buf8(f.length),u=0,m=g.length;u<m;u++)g[u]=f.charCodeAt(u);return g},o.buf2string=function(f,g){var u,m,p,b,y=g||f.length,x=new Array(2*y);for(u=m=0;u<y;)if((p=f[u++])<128)x[m++]=p;else if(4<(b=a[p]))x[m++]=65533,u+=b-1;else{for(p&=b===2?31:b===3?15:7;1<b&&u<y;)p=p<<6|63&f[u++],b--;1<b?x[m++]=65533:p<65536?x[m++]=p:(p-=65536,x[m++]=55296|p>>10&1023,x[m++]=56320|1023&p)}return d(x,m)},o.utf8border=function(f,g){var u;for((g=g||f.length)>f.length&&(g=f.length),u=g-1;0<=u&&(192&f[u])==128;)u--;return u<0||u===0?g:u+a[f[u]]>g?u:g}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--f;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,f=c+a;l^=-1;for(var g=c;g<f;g++)l=l>>>8^d[255&(l^r[g])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),f=0,g=4,u=0,m=-2,p=-1,b=4,y=2,x=8,_=9,B=286,M=30,T=19,w=2*B+1,P=15,O=3,R=258,Y=R+O+1,S=42,F=113,k=1,E=2,N=3,A=4;function D(v,V){return v.msg=d[V],V}function z(v){return(v<<1)-(4<v?9:0)}function Q(v){for(var V=v.length;0<=--V;)v[V]=0}function G(v){var V=v.state,H=V.pending;H>v.avail_out&&(H=v.avail_out),H!==0&&(l.arraySet(v.output,V.pending_buf,V.pending_out,H,v.next_out),v.next_out+=H,V.pending_out+=H,v.total_out+=H,v.avail_out-=H,V.pending-=H,V.pending===0&&(V.pending_out=0))}function W(v,V){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,V),v.block_start=v.strstart,G(v.strm)}function oe(v,V){v.pending_buf[v.pending++]=V}function re(v,V){v.pending_buf[v.pending++]=V>>>8&255,v.pending_buf[v.pending++]=255&V}function le(v,V){var H,$,I=v.max_chain_length,C=v.strstart,U=v.prev_length,q=v.nice_match,K=v.strstart>v.w_size-Y?v.strstart-(v.w_size-Y):0,ie=v.window,Z=v.w_mask,J=v.prev,de=v.strstart+R,Se=ie[C+U-1],xe=ie[C+U];v.prev_length>=v.good_match&&(I>>=2),q>v.lookahead&&(q=v.lookahead);do if(ie[(H=V)+U]===xe&&ie[H+U-1]===Se&&ie[H]===ie[C]&&ie[++H]===ie[C+1]){C+=2,H++;do;while(ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&ie[++C]===ie[++H]&&C<de);if($=R-(de-C),C=de-R,U<$){if(v.match_start=V,q<=(U=$))break;Se=ie[C+U-1],xe=ie[C+U]}}while((V=J[V&Z])>K&&--I!=0);return U<=v.lookahead?U:v.lookahead}function me(v){var V,H,$,I,C,U,q,K,ie,Z,J=v.w_size;do{if(I=v.window_size-v.lookahead-v.strstart,v.strstart>=J+(J-Y)){for(l.arraySet(v.window,v.window,J,J,0),v.match_start-=J,v.strstart-=J,v.block_start-=J,V=H=v.hash_size;$=v.head[--V],v.head[V]=J<=$?$-J:0,--H;);for(V=H=J;$=v.prev[--V],v.prev[V]=J<=$?$-J:0,--H;);I+=J}if(v.strm.avail_in===0)break;if(U=v.strm,q=v.window,K=v.strstart+v.lookahead,ie=I,Z=void 0,Z=U.avail_in,ie<Z&&(Z=ie),H=Z===0?0:(U.avail_in-=Z,l.arraySet(q,U.input,U.next_in,Z,K),U.state.wrap===1?U.adler=a(U.adler,q,Z,K):U.state.wrap===2&&(U.adler=c(U.adler,q,Z,K)),U.next_in+=Z,U.total_in+=Z,Z),v.lookahead+=H,v.lookahead+v.insert>=O)for(C=v.strstart-v.insert,v.ins_h=v.window[C],v.ins_h=(v.ins_h<<v.hash_shift^v.window[C+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[C+O-1])&v.hash_mask,v.prev[C&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=C,C++,v.insert--,!(v.lookahead+v.insert<O)););}while(v.lookahead<Y&&v.strm.avail_in!==0)}function $e(v,V){for(var H,$;;){if(v.lookahead<Y){if(me(v),v.lookahead<Y&&V===f)return k;if(v.lookahead===0)break}if(H=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),H!==0&&v.strstart-H<=v.w_size-Y&&(v.match_length=le(v,H)),v.match_length>=O)if($=r._tr_tally(v,v.strstart-v.match_start,v.match_length-O),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=O){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else $=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if($&&(W(v,!1),v.strm.avail_out===0))return k}return v.insert=v.strstart<O-1?v.strstart:O-1,V===g?(W(v,!0),v.strm.avail_out===0?N:A):v.last_lit&&(W(v,!1),v.strm.avail_out===0)?k:E}function ke(v,V){for(var H,$,I;;){if(v.lookahead<Y){if(me(v),v.lookahead<Y&&V===f)return k;if(v.lookahead===0)break}if(H=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=O-1,H!==0&&v.prev_length<v.max_lazy_match&&v.strstart-H<=v.w_size-Y&&(v.match_length=le(v,H),v.match_length<=5&&(v.strategy===1||v.match_length===O&&4096<v.strstart-v.match_start)&&(v.match_length=O-1)),v.prev_length>=O&&v.match_length<=v.prev_length){for(I=v.strstart+v.lookahead-O,$=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-O),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=I&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=O-1,v.strstart++,$&&(W(v,!1),v.strm.avail_out===0))return k}else if(v.match_available){if(($=r._tr_tally(v,0,v.window[v.strstart-1]))&&W(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return k}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&($=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<O-1?v.strstart:O-1,V===g?(W(v,!0),v.strm.avail_out===0?N:A):v.last_lit&&(W(v,!1),v.strm.avail_out===0)?k:E}function ce(v,V,H,$,I){this.good_length=v,this.max_lazy=V,this.nice_length=H,this.max_chain=$,this.func=I}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*M+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),Q(this.dyn_ltree),Q(this.dyn_dtree),Q(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(P+1),this.heap=new l.Buf16(2*B+1),Q(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*B+1),Q(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function se(v){var V;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=y,(V=v.state).pending=0,V.pending_out=0,V.wrap<0&&(V.wrap=-V.wrap),V.status=V.wrap?S:F,v.adler=V.wrap===2?0:1,V.last_flush=f,r._tr_init(V),u):D(v,m)}function L(v){var V=se(v);return V===u&&(function(H){H.window_size=2*H.w_size,Q(H.head),H.max_lazy_match=s[H.level].max_lazy,H.good_match=s[H.level].good_length,H.nice_match=s[H.level].nice_length,H.max_chain_length=s[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=O-1,H.match_available=0,H.ins_h=0})(v.state),V}function j(v,V,H,$,I,C){if(!v)return m;var U=1;if(V===p&&(V=6),$<0?(U=0,$=-$):15<$&&(U=2,$-=16),I<1||_<I||H!==x||$<8||15<$||V<0||9<V||C<0||b<C)return D(v,m);$===8&&($=9);var q=new X;return(v.state=q).strm=v,q.wrap=U,q.gzhead=null,q.w_bits=$,q.w_size=1<<q.w_bits,q.w_mask=q.w_size-1,q.hash_bits=I+7,q.hash_size=1<<q.hash_bits,q.hash_mask=q.hash_size-1,q.hash_shift=~~((q.hash_bits+O-1)/O),q.window=new l.Buf8(2*q.w_size),q.head=new l.Buf16(q.hash_size),q.prev=new l.Buf16(q.w_size),q.lit_bufsize=1<<I+6,q.pending_buf_size=4*q.lit_bufsize,q.pending_buf=new l.Buf8(q.pending_buf_size),q.d_buf=1*q.lit_bufsize,q.l_buf=3*q.lit_bufsize,q.level=V,q.strategy=C,q.method=H,L(v)}s=[new ce(0,0,0,0,function(v,V){var H=65535;for(H>v.pending_buf_size-5&&(H=v.pending_buf_size-5);;){if(v.lookahead<=1){if(me(v),v.lookahead===0&&V===f)return k;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var $=v.block_start+H;if((v.strstart===0||v.strstart>=$)&&(v.lookahead=v.strstart-$,v.strstart=$,W(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-Y&&(W(v,!1),v.strm.avail_out===0))return k}return v.insert=0,V===g?(W(v,!0),v.strm.avail_out===0?N:A):(v.strstart>v.block_start&&(W(v,!1),v.strm.avail_out),k)}),new ce(4,4,8,4,$e),new ce(4,5,16,8,$e),new ce(4,6,32,32,$e),new ce(4,4,16,16,ke),new ce(8,16,32,32,ke),new ce(8,16,128,128,ke),new ce(8,32,128,256,ke),new ce(32,128,258,1024,ke),new ce(32,258,258,4096,ke)],o.deflateInit=function(v,V){return j(v,V,x,15,8,0)},o.deflateInit2=j,o.deflateReset=L,o.deflateResetKeep=se,o.deflateSetHeader=function(v,V){return v&&v.state?v.state.wrap!==2?m:(v.state.gzhead=V,u):m},o.deflate=function(v,V){var H,$,I,C;if(!v||!v.state||5<V||V<0)return v?D(v,m):m;if($=v.state,!v.output||!v.input&&v.avail_in!==0||$.status===666&&V!==g)return D(v,v.avail_out===0?-5:m);if($.strm=v,H=$.last_flush,$.last_flush=V,$.status===S)if($.wrap===2)v.adler=0,oe($,31),oe($,139),oe($,8),$.gzhead?(oe($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),oe($,255&$.gzhead.time),oe($,$.gzhead.time>>8&255),oe($,$.gzhead.time>>16&255),oe($,$.gzhead.time>>24&255),oe($,$.level===9?2:2<=$.strategy||$.level<2?4:0),oe($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(oe($,255&$.gzhead.extra.length),oe($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(v.adler=c(v.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(oe($,0),oe($,0),oe($,0),oe($,0),oe($,0),oe($,$.level===9?2:2<=$.strategy||$.level<2?4:0),oe($,3),$.status=F);else{var U=x+($.w_bits-8<<4)<<8;U|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(U|=32),U+=31-U%31,$.status=F,re($,U),$.strstart!==0&&(re($,v.adler>>>16),re($,65535&v.adler)),v.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending!==$.pending_buf_size));)oe($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,oe($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),C===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,oe($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),C===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&G(v),$.pending+2<=$.pending_buf_size&&(oe($,255&v.adler),oe($,v.adler>>8&255),v.adler=0,$.status=F)):$.status=F),$.pending!==0){if(G(v),v.avail_out===0)return $.last_flush=-1,u}else if(v.avail_in===0&&z(V)<=z(H)&&V!==g)return D(v,-5);if($.status===666&&v.avail_in!==0)return D(v,-5);if(v.avail_in!==0||$.lookahead!==0||V!==f&&$.status!==666){var q=$.strategy===2?(function(K,ie){for(var Z;;){if(K.lookahead===0&&(me(K),K.lookahead===0)){if(ie===f)return k;break}if(K.match_length=0,Z=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++,Z&&(W(K,!1),K.strm.avail_out===0))return k}return K.insert=0,ie===g?(W(K,!0),K.strm.avail_out===0?N:A):K.last_lit&&(W(K,!1),K.strm.avail_out===0)?k:E})($,V):$.strategy===3?(function(K,ie){for(var Z,J,de,Se,xe=K.window;;){if(K.lookahead<=R){if(me(K),K.lookahead<=R&&ie===f)return k;if(K.lookahead===0)break}if(K.match_length=0,K.lookahead>=O&&0<K.strstart&&(J=xe[de=K.strstart-1])===xe[++de]&&J===xe[++de]&&J===xe[++de]){Se=K.strstart+R;do;while(J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&J===xe[++de]&&de<Se);K.match_length=R-(Se-de),K.match_length>K.lookahead&&(K.match_length=K.lookahead)}if(K.match_length>=O?(Z=r._tr_tally(K,1,K.match_length-O),K.lookahead-=K.match_length,K.strstart+=K.match_length,K.match_length=0):(Z=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++),Z&&(W(K,!1),K.strm.avail_out===0))return k}return K.insert=0,ie===g?(W(K,!0),K.strm.avail_out===0?N:A):K.last_lit&&(W(K,!1),K.strm.avail_out===0)?k:E})($,V):s[$.level].func($,V);if(q!==N&&q!==A||($.status=666),q===k||q===N)return v.avail_out===0&&($.last_flush=-1),u;if(q===E&&(V===1?r._tr_align($):V!==5&&(r._tr_stored_block($,0,0,!1),V===3&&(Q($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),G(v),v.avail_out===0))return $.last_flush=-1,u}return V!==g?u:$.wrap<=0?1:($.wrap===2?(oe($,255&v.adler),oe($,v.adler>>8&255),oe($,v.adler>>16&255),oe($,v.adler>>24&255),oe($,255&v.total_in),oe($,v.total_in>>8&255),oe($,v.total_in>>16&255),oe($,v.total_in>>24&255)):(re($,v.adler>>>16),re($,65535&v.adler)),G(v),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},o.deflateEnd=function(v){var V;return v&&v.state?(V=v.state.status)!==S&&V!==69&&V!==73&&V!==91&&V!==103&&V!==F&&V!==666?D(v,m):(v.state=null,V===F?D(v,-3):u):m},o.deflateSetDictionary=function(v,V){var H,$,I,C,U,q,K,ie,Z=V.length;if(!v||!v.state||(C=(H=v.state).wrap)===2||C===1&&H.status!==S||H.lookahead)return m;for(C===1&&(v.adler=a(v.adler,V,Z,0)),H.wrap=0,Z>=H.w_size&&(C===0&&(Q(H.head),H.strstart=0,H.block_start=0,H.insert=0),ie=new l.Buf8(H.w_size),l.arraySet(ie,V,Z-H.w_size,H.w_size,0),V=ie,Z=H.w_size),U=v.avail_in,q=v.next_in,K=v.input,v.avail_in=Z,v.next_in=0,v.input=V,me(H);H.lookahead>=O;){for($=H.strstart,I=H.lookahead-(O-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[$+O-1])&H.hash_mask,H.prev[$&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=$,$++,--I;);H.strstart=$,H.lookahead=O-1,me(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=O-1,H.match_available=0,v.next_in=q,v.input=K,v.avail_in=U,H.wrap=C,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,d,f,g,u,m,p,b,y,x,_,B,M,T,w,P,O,R,Y,S,F,k,E;r=s.state,a=s.next_in,k=s.input,c=a+(s.avail_in-5),d=s.next_out,E=s.output,f=d-(l-s.avail_out),g=d+(s.avail_out-257),u=r.dmax,m=r.wsize,p=r.whave,b=r.wnext,y=r.window,x=r.hold,_=r.bits,B=r.lencode,M=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),P=B[x&T];t:for(;;){if(x>>>=O=P>>>24,_-=O,(O=P>>>16&255)===0)E[d++]=65535&P;else{if(!(16&O)){if((64&O)==0){P=B[(65535&P)+(x&(1<<O)-1)];continue t}if(32&O){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}R=65535&P,(O&=15)&&(_<O&&(x+=k[a++]<<_,_+=8),R+=x&(1<<O)-1,x>>>=O,_-=O),_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),P=M[x&w];i:for(;;){if(x>>>=O=P>>>24,_-=O,!(16&(O=P>>>16&255))){if((64&O)==0){P=M[(65535&P)+(x&(1<<O)-1)];continue i}s.msg="invalid distance code",r.mode=30;break e}if(Y=65535&P,_<(O&=15)&&(x+=k[a++]<<_,(_+=8)<O&&(x+=k[a++]<<_,_+=8)),u<(Y+=x&(1<<O)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=O,_-=O,(O=d-f)<Y){if(p<(O=Y-O)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(F=y,(S=0)===b){if(S+=m-O,O<R){for(R-=O;E[d++]=y[S++],--O;);S=d-Y,F=E}}else if(b<O){if(S+=m+b-O,(O-=b)<R){for(R-=O;E[d++]=y[S++],--O;);if(S=0,b<R){for(R-=O=b;E[d++]=y[S++],--O;);S=d-Y,F=E}}}else if(S+=b-O,O<R){for(R-=O;E[d++]=y[S++],--O;);S=d-Y,F=E}for(;2<R;)E[d++]=F[S++],E[d++]=F[S++],E[d++]=F[S++],R-=3;R&&(E[d++]=F[S++],1<R&&(E[d++]=F[S++]))}else{for(S=d-Y;E[d++]=E[S++],E[d++]=E[S++],E[d++]=E[S++],2<(R-=3););R&&(E[d++]=E[S++],1<R&&(E[d++]=E[S++]))}break}}break}}while(a<c&&d<g);a-=R=_>>3,x&=(1<<(_-=R<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<g?g-d+257:257-(d-g),r.hold=x,r.bits=_}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,f=2,g=0,u=-2,m=1,p=852,b=592;function y(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(S){var F;return S&&S.state?(F=S.state,S.total_in=S.total_out=F.total=0,S.msg="",F.wrap&&(S.adler=1&F.wrap),F.mode=m,F.last=0,F.havedict=0,F.dmax=32768,F.head=null,F.hold=0,F.bits=0,F.lencode=F.lendyn=new s.Buf32(p),F.distcode=F.distdyn=new s.Buf32(b),F.sane=1,F.back=-1,g):u}function B(S){var F;return S&&S.state?((F=S.state).wsize=0,F.whave=0,F.wnext=0,_(S)):u}function M(S,F){var k,E;return S&&S.state?(E=S.state,F<0?(k=0,F=-F):(k=1+(F>>4),F<48&&(F&=15)),F&&(F<8||15<F)?u:(E.window!==null&&E.wbits!==F&&(E.window=null),E.wrap=k,E.wbits=F,B(S))):u}function T(S,F){var k,E;return S?(E=new x,(S.state=E).window=null,(k=M(S,F))!==g&&(S.state=null),k):u}var w,P,O=!0;function R(S){if(O){var F;for(w=new s.Buf32(512),P=new s.Buf32(32),F=0;F<144;)S.lens[F++]=8;for(;F<256;)S.lens[F++]=9;for(;F<280;)S.lens[F++]=7;for(;F<288;)S.lens[F++]=8;for(c(d,S.lens,0,288,w,0,S.work,{bits:9}),F=0;F<32;)S.lens[F++]=5;c(f,S.lens,0,32,P,0,S.work,{bits:5}),O=!1}S.lencode=w,S.lenbits=9,S.distcode=P,S.distbits=5}function Y(S,F,k,E){var N,A=S.state;return A.window===null&&(A.wsize=1<<A.wbits,A.wnext=0,A.whave=0,A.window=new s.Buf8(A.wsize)),E>=A.wsize?(s.arraySet(A.window,F,k-A.wsize,A.wsize,0),A.wnext=0,A.whave=A.wsize):(E<(N=A.wsize-A.wnext)&&(N=E),s.arraySet(A.window,F,k-E,N,A.wnext),(E-=N)?(s.arraySet(A.window,F,k-E,E,0),A.wnext=E,A.whave=A.wsize):(A.wnext+=N,A.wnext===A.wsize&&(A.wnext=0),A.whave<A.wsize&&(A.whave+=N))),0}o.inflateReset=B,o.inflateReset2=M,o.inflateResetKeep=_,o.inflateInit=function(S){return T(S,15)},o.inflateInit2=T,o.inflate=function(S,F){var k,E,N,A,D,z,Q,G,W,oe,re,le,me,$e,ke,ce,X,se,L,j,v,V,H,$,I=0,C=new s.Buf8(4),U=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return u;(k=S.state).mode===12&&(k.mode=13),D=S.next_out,N=S.output,Q=S.avail_out,A=S.next_in,E=S.input,z=S.avail_in,G=k.hold,W=k.bits,oe=z,re=Q,V=g;e:for(;;)switch(k.mode){case m:if(k.wrap===0){k.mode=13;break}for(;W<16;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(2&k.wrap&&G===35615){C[k.check=0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0),W=G=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&G)<<8)+(G>>8))%31){S.msg="incorrect header check",k.mode=30;break}if((15&G)!=8){S.msg="unknown compression method",k.mode=30;break}if(W-=4,v=8+(15&(G>>>=4)),k.wbits===0)k.wbits=v;else if(v>k.wbits){S.msg="invalid window size",k.mode=30;break}k.dmax=1<<v,S.adler=k.check=1,k.mode=512&G?10:12,W=G=0;break;case 2:for(;W<16;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(k.flags=G,(255&k.flags)!=8){S.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){S.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=G>>8&1),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0,k.mode=3;case 3:for(;W<32;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.head&&(k.head.time=G),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,C[2]=G>>>16&255,C[3]=G>>>24&255,k.check=r(k.check,C,4,0)),W=G=0,k.mode=4;case 4:for(;W<16;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.head&&(k.head.xflags=255&G,k.head.os=G>>8),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0,k.mode=5;case 5:if(1024&k.flags){for(;W<16;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.length=G,k.head&&(k.head.extra_len=G),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(z<(le=k.length)&&(le=z),le&&(k.head&&(v=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),s.arraySet(k.head.extra,E,A,le,v)),512&k.flags&&(k.check=r(k.check,E,le,A)),z-=le,A+=le,k.length-=le),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(z===0)break e;for(le=0;v=E[A+le++],k.head&&v&&k.length<65536&&(k.head.name+=String.fromCharCode(v)),v&&le<z;);if(512&k.flags&&(k.check=r(k.check,E,le,A)),z-=le,A+=le,v)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(z===0)break e;for(le=0;v=E[A+le++],k.head&&v&&k.length<65536&&(k.head.comment+=String.fromCharCode(v)),v&&le<z;);if(512&k.flags&&(k.check=r(k.check,E,le,A)),z-=le,A+=le,v)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;W<16;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(G!==(65535&k.check)){S.msg="header crc mismatch",k.mode=30;break}W=G=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),S.adler=k.check=0,k.mode=12;break;case 10:for(;W<32;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}S.adler=k.check=y(G),W=G=0,k.mode=11;case 11:if(k.havedict===0)return S.next_out=D,S.avail_out=Q,S.next_in=A,S.avail_in=z,k.hold=G,k.bits=W,2;S.adler=k.check=1,k.mode=12;case 12:if(F===5||F===6)break e;case 13:if(k.last){G>>>=7&W,W-=7&W,k.mode=27;break}for(;W<3;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}switch(k.last=1&G,W-=1,3&(G>>>=1)){case 0:k.mode=14;break;case 1:if(R(k),k.mode=20,F!==6)break;G>>>=2,W-=2;break e;case 2:k.mode=17;break;case 3:S.msg="invalid block type",k.mode=30}G>>>=2,W-=2;break;case 14:for(G>>>=7&W,W-=7&W;W<32;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if((65535&G)!=(G>>>16^65535)){S.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&G,W=G=0,k.mode=15,F===6)break e;case 15:k.mode=16;case 16:if(le=k.length){if(z<le&&(le=z),Q<le&&(le=Q),le===0)break e;s.arraySet(N,E,A,le,D),z-=le,A+=le,Q-=le,D+=le,k.length-=le;break}k.mode=12;break;case 17:for(;W<14;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(k.nlen=257+(31&G),G>>>=5,W-=5,k.ndist=1+(31&G),G>>>=5,W-=5,k.ncode=4+(15&G),G>>>=4,W-=4,286<k.nlen||30<k.ndist){S.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;W<3;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.lens[U[k.have++]]=7&G,G>>>=3,W-=3}for(;k.have<19;)k.lens[U[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,H={bits:k.lenbits},V=c(0,k.lens,0,19,k.lencode,0,k.work,H),k.lenbits=H.bits,V){S.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;ce=(I=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,X=65535&I,!((ke=I>>>24)<=W);){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(X<16)G>>>=ke,W-=ke,k.lens[k.have++]=X;else{if(X===16){for($=ke+2;W<$;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(G>>>=ke,W-=ke,k.have===0){S.msg="invalid bit length repeat",k.mode=30;break}v=k.lens[k.have-1],le=3+(3&G),G>>>=2,W-=2}else if(X===17){for($=ke+3;W<$;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}W-=ke,v=0,le=3+(7&(G>>>=ke)),G>>>=3,W-=3}else{for($=ke+7;W<$;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}W-=ke,v=0,le=11+(127&(G>>>=ke)),G>>>=7,W-=7}if(k.have+le>k.nlen+k.ndist){S.msg="invalid bit length repeat",k.mode=30;break}for(;le--;)k.lens[k.have++]=v}}if(k.mode===30)break;if(k.lens[256]===0){S.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,H={bits:k.lenbits},V=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,H),k.lenbits=H.bits,V){S.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,H={bits:k.distbits},V=c(f,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,H),k.distbits=H.bits,V){S.msg="invalid distances set",k.mode=30;break}if(k.mode=20,F===6)break e;case 20:k.mode=21;case 21:if(6<=z&&258<=Q){S.next_out=D,S.avail_out=Q,S.next_in=A,S.avail_in=z,k.hold=G,k.bits=W,a(S,re),D=S.next_out,N=S.output,Q=S.avail_out,A=S.next_in,E=S.input,z=S.avail_in,G=k.hold,W=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;ce=(I=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,X=65535&I,!((ke=I>>>24)<=W);){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(ce&&(240&ce)==0){for(se=ke,L=ce,j=X;ce=(I=k.lencode[j+((G&(1<<se+L)-1)>>se)])>>>16&255,X=65535&I,!(se+(ke=I>>>24)<=W);){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}G>>>=se,W-=se,k.back+=se}if(G>>>=ke,W-=ke,k.back+=ke,k.length=X,ce===0){k.mode=26;break}if(32&ce){k.back=-1,k.mode=12;break}if(64&ce){S.msg="invalid literal/length code",k.mode=30;break}k.extra=15&ce,k.mode=22;case 22:if(k.extra){for($=k.extra;W<$;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.length+=G&(1<<k.extra)-1,G>>>=k.extra,W-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;ce=(I=k.distcode[G&(1<<k.distbits)-1])>>>16&255,X=65535&I,!((ke=I>>>24)<=W);){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if((240&ce)==0){for(se=ke,L=ce,j=X;ce=(I=k.distcode[j+((G&(1<<se+L)-1)>>se)])>>>16&255,X=65535&I,!(se+(ke=I>>>24)<=W);){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}G>>>=se,W-=se,k.back+=se}if(G>>>=ke,W-=ke,k.back+=ke,64&ce){S.msg="invalid distance code",k.mode=30;break}k.offset=X,k.extra=15&ce,k.mode=24;case 24:if(k.extra){for($=k.extra;W<$;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}k.offset+=G&(1<<k.extra)-1,G>>>=k.extra,W-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){S.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(Q===0)break e;if(le=re-Q,k.offset>le){if((le=k.offset-le)>k.whave&&k.sane){S.msg="invalid distance too far back",k.mode=30;break}me=le>k.wnext?(le-=k.wnext,k.wsize-le):k.wnext-le,le>k.length&&(le=k.length),$e=k.window}else $e=N,me=D-k.offset,le=k.length;for(Q<le&&(le=Q),Q-=le,k.length-=le;N[D++]=$e[me++],--le;);k.length===0&&(k.mode=21);break;case 26:if(Q===0)break e;N[D++]=k.length,Q--,k.mode=21;break;case 27:if(k.wrap){for(;W<32;){if(z===0)break e;z--,G|=E[A++]<<W,W+=8}if(re-=Q,S.total_out+=re,k.total+=re,re&&(S.adler=k.check=k.flags?r(k.check,N,re,D-re):l(k.check,N,re,D-re)),re=Q,(k.flags?G:y(G))!==k.check){S.msg="incorrect data check",k.mode=30;break}W=G=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;W<32;){if(z===0)break e;z--,G+=E[A++]<<W,W+=8}if(G!==(4294967295&k.total)){S.msg="incorrect length check",k.mode=30;break}W=G=0}k.mode=29;case 29:V=1;break e;case 30:V=-3;break e;case 31:return-4;case 32:default:return u}return S.next_out=D,S.avail_out=Q,S.next_in=A,S.avail_in=z,k.hold=G,k.bits=W,(k.wsize||re!==S.avail_out&&k.mode<30&&(k.mode<27||F!==4))&&Y(S,S.output,S.next_out,re-S.avail_out)?(k.mode=31,-4):(oe-=S.avail_in,re-=S.avail_out,S.total_in+=oe,S.total_out+=re,k.total+=re,k.wrap&&re&&(S.adler=k.check=k.flags?r(k.check,N,re,S.next_out-re):l(k.check,N,re,S.next_out-re)),S.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(oe==0&&re===0||F===4)&&V===g&&(V=-5),V)},o.inflateEnd=function(S){if(!S||!S.state)return u;var F=S.state;return F.window&&(F.window=null),S.state=null,g},o.inflateGetHeader=function(S,F){var k;return S&&S.state?(2&(k=S.state).wrap)==0?u:((k.head=F).done=!1,g):u},o.inflateSetDictionary=function(S,F){var k,E=F.length;return S&&S.state?(k=S.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,F,E,0)!==k.check?-3:Y(S,F,E,E)?(k.mode=31,-4):(k.havedict=1,g):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,f,g,u,m,p,b,y){var x,_,B,M,T,w,P,O,R,Y=y.bits,S=0,F=0,k=0,E=0,N=0,A=0,D=0,z=0,Q=0,G=0,W=null,oe=0,re=new s.Buf16(16),le=new s.Buf16(16),me=null,$e=0;for(S=0;S<=15;S++)re[S]=0;for(F=0;F<u;F++)re[f[g+F]]++;for(N=Y,E=15;1<=E&&re[E]===0;E--);if(E<N&&(N=E),E===0)return m[p++]=20971520,m[p++]=20971520,y.bits=1,0;for(k=1;k<E&&re[k]===0;k++);for(N<k&&(N=k),S=z=1;S<=15;S++)if(z<<=1,(z-=re[S])<0)return-1;if(0<z&&(d===0||E!==1))return-1;for(le[1]=0,S=1;S<15;S++)le[S+1]=le[S]+re[S];for(F=0;F<u;F++)f[g+F]!==0&&(b[le[f[g+F]]++]=F);if(w=d===0?(W=me=b,19):d===1?(W=l,oe-=257,me=r,$e-=257,256):(W=a,me=c,-1),S=k,T=p,D=F=G=0,B=-1,M=(Q=1<<(A=N))-1,d===1&&852<Q||d===2&&592<Q)return 1;for(;;){for(P=S-D,R=b[F]<w?(O=0,b[F]):b[F]>w?(O=me[$e+b[F]],W[oe+b[F]]):(O=96,0),x=1<<S-D,k=_=1<<A;m[T+(G>>D)+(_-=x)]=P<<24|O<<16|R|0,_!==0;);for(x=1<<S-1;G&x;)x>>=1;if(x!==0?(G&=x-1,G+=x):G=0,F++,--re[S]==0){if(S===E)break;S=f[g+b[F]]}if(N<S&&(G&M)!==B){for(D===0&&(D=N),T+=k,z=1<<(A=S-D);A+D<E&&!((z-=re[A+D])<=0);)A++,z<<=1;if(Q+=1<<A,d===1&&852<Q||d===2&&592<Q)return 1;m[B=G&M]=N<<24|A<<16|T-p|0}}return G!==0&&(m[T+G]=S-D<<24|64<<16|0),y.bits=N,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(I){for(var C=I.length;0<=--C;)I[C]=0}var c=0,d=29,f=256,g=f+1+d,u=30,m=19,p=2*g+1,b=15,y=16,x=7,_=256,B=16,M=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],P=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],O=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Y=new Array(2*(g+2));a(Y);var S=new Array(2*u);a(S);var F=new Array(512);a(F);var k=new Array(256);a(k);var E=new Array(d);a(E);var N,A,D,z=new Array(u);function Q(I,C,U,q,K){this.static_tree=I,this.extra_bits=C,this.extra_base=U,this.elems=q,this.max_length=K,this.has_stree=I&&I.length}function G(I,C){this.dyn_tree=I,this.max_code=0,this.stat_desc=C}function W(I){return I<256?F[I]:F[256+(I>>>7)]}function oe(I,C){I.pending_buf[I.pending++]=255&C,I.pending_buf[I.pending++]=C>>>8&255}function re(I,C,U){I.bi_valid>y-U?(I.bi_buf|=C<<I.bi_valid&65535,oe(I,I.bi_buf),I.bi_buf=C>>y-I.bi_valid,I.bi_valid+=U-y):(I.bi_buf|=C<<I.bi_valid&65535,I.bi_valid+=U)}function le(I,C,U){re(I,U[2*C],U[2*C+1])}function me(I,C){for(var U=0;U|=1&I,I>>>=1,U<<=1,0<--C;);return U>>>1}function $e(I,C,U){var q,K,ie=new Array(b+1),Z=0;for(q=1;q<=b;q++)ie[q]=Z=Z+U[q-1]<<1;for(K=0;K<=C;K++){var J=I[2*K+1];J!==0&&(I[2*K]=me(ie[J]++,J))}}function ke(I){var C;for(C=0;C<g;C++)I.dyn_ltree[2*C]=0;for(C=0;C<u;C++)I.dyn_dtree[2*C]=0;for(C=0;C<m;C++)I.bl_tree[2*C]=0;I.dyn_ltree[2*_]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function ce(I){8<I.bi_valid?oe(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function X(I,C,U,q){var K=2*C,ie=2*U;return I[K]<I[ie]||I[K]===I[ie]&&q[C]<=q[U]}function se(I,C,U){for(var q=I.heap[U],K=U<<1;K<=I.heap_len&&(K<I.heap_len&&X(C,I.heap[K+1],I.heap[K],I.depth)&&K++,!X(C,q,I.heap[K],I.depth));)I.heap[U]=I.heap[K],U=K,K<<=1;I.heap[U]=q}function L(I,C,U){var q,K,ie,Z,J=0;if(I.last_lit!==0)for(;q=I.pending_buf[I.d_buf+2*J]<<8|I.pending_buf[I.d_buf+2*J+1],K=I.pending_buf[I.l_buf+J],J++,q===0?le(I,K,C):(le(I,(ie=k[K])+f+1,C),(Z=w[ie])!==0&&re(I,K-=E[ie],Z),le(I,ie=W(--q),U),(Z=P[ie])!==0&&re(I,q-=z[ie],Z)),J<I.last_lit;);le(I,_,C)}function j(I,C){var U,q,K,ie=C.dyn_tree,Z=C.stat_desc.static_tree,J=C.stat_desc.has_stree,de=C.stat_desc.elems,Se=-1;for(I.heap_len=0,I.heap_max=p,U=0;U<de;U++)ie[2*U]!==0?(I.heap[++I.heap_len]=Se=U,I.depth[U]=0):ie[2*U+1]=0;for(;I.heap_len<2;)ie[2*(K=I.heap[++I.heap_len]=Se<2?++Se:0)]=1,I.depth[K]=0,I.opt_len--,J&&(I.static_len-=Z[2*K+1]);for(C.max_code=Se,U=I.heap_len>>1;1<=U;U--)se(I,ie,U);for(K=de;U=I.heap[1],I.heap[1]=I.heap[I.heap_len--],se(I,ie,1),q=I.heap[1],I.heap[--I.heap_max]=U,I.heap[--I.heap_max]=q,ie[2*K]=ie[2*U]+ie[2*q],I.depth[K]=(I.depth[U]>=I.depth[q]?I.depth[U]:I.depth[q])+1,ie[2*U+1]=ie[2*q+1]=K,I.heap[1]=K++,se(I,ie,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xe,Ae){var ze,qe,Je,Le,Jt,rt,Xe=Ae.dyn_tree,Ht=Ae.max_code,Fi=Ae.stat_desc.static_tree,Uo=Ae.stat_desc.has_stree,Vo=Ae.stat_desc.extra_bits,Vn=Ae.stat_desc.extra_base,Si=Ae.stat_desc.max_length,Hi=0;for(Le=0;Le<=b;Le++)xe.bl_count[Le]=0;for(Xe[2*xe.heap[xe.heap_max]+1]=0,ze=xe.heap_max+1;ze<p;ze++)Si<(Le=Xe[2*Xe[2*(qe=xe.heap[ze])+1]+1]+1)&&(Le=Si,Hi++),Xe[2*qe+1]=Le,Ht<qe||(xe.bl_count[Le]++,Jt=0,Vn<=qe&&(Jt=Vo[qe-Vn]),rt=Xe[2*qe],xe.opt_len+=rt*(Le+Jt),Uo&&(xe.static_len+=rt*(Fi[2*qe+1]+Jt)));if(Hi!==0){do{for(Le=Si-1;xe.bl_count[Le]===0;)Le--;xe.bl_count[Le]--,xe.bl_count[Le+1]+=2,xe.bl_count[Si]--,Hi-=2}while(0<Hi);for(Le=Si;Le!==0;Le--)for(qe=xe.bl_count[Le];qe!==0;)Ht<(Je=xe.heap[--ze])||(Xe[2*Je+1]!==Le&&(xe.opt_len+=(Le-Xe[2*Je+1])*Xe[2*Je],Xe[2*Je+1]=Le),qe--)}})(I,C),$e(ie,Se,I.bl_count)}function v(I,C,U){var q,K,ie=-1,Z=C[1],J=0,de=7,Se=4;for(Z===0&&(de=138,Se=3),C[2*(U+1)+1]=65535,q=0;q<=U;q++)K=Z,Z=C[2*(q+1)+1],++J<de&&K===Z||(J<Se?I.bl_tree[2*K]+=J:K!==0?(K!==ie&&I.bl_tree[2*K]++,I.bl_tree[2*B]++):J<=10?I.bl_tree[2*M]++:I.bl_tree[2*T]++,ie=K,Se=(J=0)===Z?(de=138,3):K===Z?(de=6,3):(de=7,4))}function V(I,C,U){var q,K,ie=-1,Z=C[1],J=0,de=7,Se=4;for(Z===0&&(de=138,Se=3),q=0;q<=U;q++)if(K=Z,Z=C[2*(q+1)+1],!(++J<de&&K===Z)){if(J<Se)for(;le(I,K,I.bl_tree),--J!=0;);else K!==0?(K!==ie&&(le(I,K,I.bl_tree),J--),le(I,B,I.bl_tree),re(I,J-3,2)):J<=10?(le(I,M,I.bl_tree),re(I,J-3,3)):(le(I,T,I.bl_tree),re(I,J-11,7));ie=K,Se=(J=0)===Z?(de=138,3):K===Z?(de=6,3):(de=7,4)}}a(z);var H=!1;function $(I,C,U,q){re(I,(c<<1)+(q?1:0),3),(function(K,ie,Z,J){ce(K),oe(K,Z),oe(K,~Z),s.arraySet(K.pending_buf,K.window,ie,Z,K.pending),K.pending+=Z})(I,C,U)}o._tr_init=function(I){H||((function(){var C,U,q,K,ie,Z=new Array(b+1);for(K=q=0;K<d-1;K++)for(E[K]=q,C=0;C<1<<w[K];C++)k[q++]=K;for(k[q-1]=K,K=ie=0;K<16;K++)for(z[K]=ie,C=0;C<1<<P[K];C++)F[ie++]=K;for(ie>>=7;K<u;K++)for(z[K]=ie<<7,C=0;C<1<<P[K]-7;C++)F[256+ie++]=K;for(U=0;U<=b;U++)Z[U]=0;for(C=0;C<=143;)Y[2*C+1]=8,C++,Z[8]++;for(;C<=255;)Y[2*C+1]=9,C++,Z[9]++;for(;C<=279;)Y[2*C+1]=7,C++,Z[7]++;for(;C<=287;)Y[2*C+1]=8,C++,Z[8]++;for($e(Y,g+1,Z),C=0;C<u;C++)S[2*C+1]=5,S[2*C]=me(C,5);N=new Q(Y,w,f+1,g,b),A=new Q(S,P,0,u,b),D=new Q(new Array(0),O,0,m,x)})(),H=!0),I.l_desc=new G(I.dyn_ltree,N),I.d_desc=new G(I.dyn_dtree,A),I.bl_desc=new G(I.bl_tree,D),I.bi_buf=0,I.bi_valid=0,ke(I)},o._tr_stored_block=$,o._tr_flush_block=function(I,C,U,q){var K,ie,Z=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(J){var de,Se=4093624447;for(de=0;de<=31;de++,Se>>>=1)if(1&Se&&J.dyn_ltree[2*de]!==0)return l;if(J.dyn_ltree[18]!==0||J.dyn_ltree[20]!==0||J.dyn_ltree[26]!==0)return r;for(de=32;de<f;de++)if(J.dyn_ltree[2*de]!==0)return r;return l})(I)),j(I,I.l_desc),j(I,I.d_desc),Z=(function(J){var de;for(v(J,J.dyn_ltree,J.l_desc.max_code),v(J,J.dyn_dtree,J.d_desc.max_code),j(J,J.bl_desc),de=m-1;3<=de&&J.bl_tree[2*R[de]+1]===0;de--);return J.opt_len+=3*(de+1)+5+5+4,de})(I),K=I.opt_len+3+7>>>3,(ie=I.static_len+3+7>>>3)<=K&&(K=ie)):K=ie=U+5,U+4<=K&&C!==-1?$(I,C,U,q):I.strategy===4||ie===K?(re(I,2+(q?1:0),3),L(I,Y,S)):(re(I,4+(q?1:0),3),(function(J,de,Se,xe){var Ae;for(re(J,de-257,5),re(J,Se-1,5),re(J,xe-4,4),Ae=0;Ae<xe;Ae++)re(J,J.bl_tree[2*R[Ae]+1],3);V(J,J.dyn_ltree,de-1),V(J,J.dyn_dtree,Se-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,Z+1),L(I,I.dyn_ltree,I.dyn_dtree)),ke(I),q&&ce(I)},o._tr_tally=function(I,C,U){return I.pending_buf[I.d_buf+2*I.last_lit]=C>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&C,I.pending_buf[I.l_buf+I.last_lit]=255&U,I.last_lit++,C===0?I.dyn_ltree[2*U]++:(I.matches++,C--,I.dyn_ltree[2*(k[U]+f+1)]++,I.dyn_dtree[2*W(C)]++),I.last_lit===I.lit_bufsize-1},o._tr_align=function(I){re(I,2,3),le(I,_,Y),(function(C){C.bi_valid===16?(oe(C,C.bi_buf),C.bi_buf=0,C.bi_valid=0):8<=C.bi_valid&&(C.pending_buf[C.pending++]=255&C.bi_buf,C.bi_buf>>=8,C.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,f,g=1,u={},m=!1,p=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(B){process.nextTick(function(){x(B)})}:(function(){if(l.postMessage&&!l.importScripts){var B=!0,M=l.onmessage;return l.onmessage=function(){B=!1},l.postMessage("","*"),l.onmessage=M,B}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(B){l.postMessage(f+B,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(B){x(B.data)},function(B){d.port2.postMessage(B)}):p&&"onreadystatechange"in p.createElement("script")?(c=p.documentElement,function(B){var M=p.createElement("script");M.onreadystatechange=function(){x(B),M.onreadystatechange=null,c.removeChild(M),M=null},c.appendChild(M)}):function(B){setTimeout(x,0,B)},b.setImmediate=function(B){typeof B!="function"&&(B=new Function(""+B));for(var M=new Array(arguments.length-1),T=0;T<M.length;T++)M[T]=arguments[T+1];var w={callback:B,args:M};return u[g]=w,a(g),g++},b.clearImmediate=y}function y(B){delete u[B]}function x(B){if(m)setTimeout(x,0,B);else{var M=u[B];if(M){m=!0;try{(function(T){var w=T.callback,P=T.args;switch(P.length){case 0:w();break;case 1:w(P[0]);break;case 2:w(P[0],P[1]);break;case 3:w(P[0],P[1],P[2]);break;default:w.apply(r,P)}})(M)}finally{y(B),m=!1}}}}function _(B){B.source===l&&typeof B.data=="string"&&B.data.indexOf(f)===0&&x(+B.data.slice(f.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof eo<"u"?eo:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ls)),ls.exports}var u0=d0();const f0=c0(u0),p0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,h0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function m0(e){const t=await f0.loadAsync(e),i={},n=[];let o="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||h0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=d)}else if(p0.test(c)){const d=await a.file.async("uint8array"),f=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:f,data:d,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function g0(e,t){if(Object.keys(t).length===0)return e;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of e.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const o=e.docRootAttrs["custom-slidev-background"],s=i(o);s&&(e.docRootAttrs["custom-slidev-background"]=s)}return e}function za(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function v0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[m,p]of Object.entries(a))if(m.endsWith(`/${r}`)||u&&m.endsWith(`/${u}`)){c=p;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const m=require("path");u.push(m.resolve(t.baseDir,r)),u.push(m.resolve(t.baseDir,s))}catch{}try{const m=require("path");u.push(m.resolve(process.cwd(),r))}catch{}for(const m of u){const p=za(m);if(p!==null){c=p;break}}}if(!c){const u=$a||{};if(c=u[s]||u[r]||u[`snippets/${r}`],!c){const m=r.split("/").pop();for(const[p,b]of Object.entries(u))if(p.endsWith(`/${r}`)||m&&p.endsWith(`/${m}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),m=c.match(u);if(m){const p=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(p?p[1]:"")+m[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${d}
\`\`\``}function b0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const o=e[n];if(o==="'"&&!i)t=!t;else if(o==='"'&&!t)i=!i;else if(o==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function so(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const f=i[n];if(!f.trim()){c.push(""),n++;continue}const u=f.match(/^(\s+)/),m=u?u[1].length:0;if(d===-1&&(d=m),m<d)break;c.push(f.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=b0(a),!a){let c=n+1;const d=[];let f=-1;for(;c<i.length;){const g=i[c],u=g.trim();if(!u||u.startsWith("#")){f!==-1&&d.push(""),c++;continue}const m=g.match(/^(\s+)/),p=m?m[1].length:0;if(f===-1)if(p>0)f=p;else break;if(p<f)break;d.push(g.slice(f)),c++}if(d.length>0){t[r]=so(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const y0=/^\s*```ya?ml([\s\S]*?)```/;function Xr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=so(n[1]);if(Object.keys(s).length>0||!n[1].trim())return t=s,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(y0);if(o)t=so(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=so(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function k0(e){const t=e.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let f=l+1;for(;f<t.length&&!t[f].trimStart().startsWith(d);f++);f<t.length&&(l=f)}}return n<t.length&&s(t.length),i}function ro(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const f=k0(d),g={};let u="",m="",p=0;if(f.length>0){const R=f[0],Y=Xr(R),S=Object.keys(Y.frontmatter).length>0,F=Y.content.length>0;S&&!F&&f.length>1?(p=1,b(Y.frontmatter)):S&&b(Y.frontmatter)}function b(R){u=R.title||"",R.theme&&(g[An]=String(R.theme)),R.aspectRatio&&(g[Bn]=String(R.aspectRatio)),R.highlighter&&(g[ll]=String(R.highlighter)),R.transition&&(g[Mn]=String(R.transition)),R.colorSchema&&(g[al]=String(R.colorSchema)),R.layout&&(g[he]=String(R.layout)),R.background&&(g[We]=String(R.background)),R.image&&(g[Dt]=String(R.image)),R.class&&(g[Gi]=String(R.class));for(const[Y,S]of Object.entries(R))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(Y)||(g[`custom-slidev-${Y}`]=typeof S=="object"?JSON.stringify(S):String(S))}const y=[];let x=0,_=0,B=0,M=0;const T=new Set,w={};let P=1;for(let R=p;R<f.length;R++){const Y=f[R],{frontmatter:S,content:F}=Xr(Y),k=Y.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),E=S.src||(k?k[1]:void 0);if(E){const ce=String(E).trim().replace(/^['"]|['"]$/g,"");let X=c[ce]||c[ce.replace(/^\.\//,"")]||c[`pages/${ce.replace(/^.*pages\//,"")}`];if(!X){const L=ce.replace(/^\.\//,""),j=[];if(t.baseDir)try{const v=require("path");j.push(v.resolve(t.baseDir,L)),j.push(v.resolve(t.baseDir,ce))}catch{}try{const v=require("path");j.push(v.resolve(process.cwd(),L)),j.push(v.resolve(process.cwd(),ce))}catch{}for(const v of j){const V=za(v);if(V!==null){X=V;break}}}const se={};S.layout&&(se[he]=String(S.layout)),S.transition&&(se[tt]=String(S.transition)),S.background&&(se[We]=String(S.background)),S.image&&(se[Dt]=String(S.image)),S.class&&(se[Gi]=String(S.class));for(const[L,j]of Object.entries(S))["src","layout","transition","background","image","class"].includes(L)||(se[`custom-slidev-${L}`]=typeof j=="object"?JSON.stringify(j):String(j));if(X){const L=ro(X,{...t,virtualFiles:c});for(const j of L.slides){j.pageIndex=P++,j.pageAttrs={...se,...j.pageAttrs},y.push(j);const v=j.pageAttrs[he]||"default";w[v]=(w[v]||0)+1}continue}else{y.push({pageIndex:P++,pageAttrs:{...se,"custom-slidev-src":ce},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${ce}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=se[he]||"default";w[L]=(w[L]||0)+1;continue}}const N={};S.layout&&(N[he]=String(S.layout)),S.transition&&(N[tt]=String(S.transition)),S.background&&(N[We]=String(S.background)),S.image&&(N[Dt]=String(S.image)),S.class&&(N[Gi]=String(S.class)),S.mask&&(N[qi]=String(S.mask)),(S.maskRatio||S["mask-ratio"])&&(N[Zi]=String(S.maskRatio||S["mask-ratio"])),(S.maskStyle||S["mask-style"])&&(N[Yi]=String(S.maskStyle||S["mask-style"])),(S.maskInitial||S["mask-initial"])&&(N[Ji]=String(S.maskInitial||S["mask-initial"]));for(const[ce,X]of Object.entries(S))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(ce)||(N[`custom-slidev-${ce}`]=typeof X=="object"?JSON.stringify(X):String(X));let A=F;const D=[];let z=A.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,ce=>{const X=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ce),X});z=z.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,ce=>{const X=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ce),X});let Q="";const G=Array.from(z.matchAll(/<!--([\s\S]*?)-->/g));if(G.length>0){const ce=G[G.length-1],X=z.slice(ce.index+ce[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=ce[1].trim();L.startsWith("TODO:")||(Q=L,x++),i&&(z=z.slice(0,ce.index).trimEnd()+z.slice(ce.index+ce[0].length))}}i&&(z=z.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let ce=0;ce<D.length;ce++)z=z.replace(`__CODE_TOKEN_NOTE_${ce}__`,D[ce]);if(A=z,Q){for(let se=0;se<D.length;se++)Q=Q.replace(`__CODE_TOKEN_NOTE_${se}__`,D[se]);const X=`> [!NOTE] 💡 演讲备注
${Q.split(/\r?\n/).map(se=>`> ${se}`).join(`
`)}
{: custom-slidev-note="true"}`;A=A?`${A}

${X}`:X}let W=!1;if(/<style\b/i.test(A)){W=!0;const ce=A.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(ce){for(const X of ce){const se=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();m=m?`${m}

${se}`:se}l&&(A=A.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=A.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(_+=oe.length);const re=A.match(/```\w+\s+\{[^}]+\}/g);re&&(B+=re.length);const le=A.match(/::\w+::|<template\s+#[^>]+>/g);if(le&&(M+=le.length),A=A.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,ce=>v0(ce,{...t,virtualFiles:c})||ce),n&&(A=A.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(A=A.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),A=A.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(A=A.replace(/^::\w+::\s*$/gm,"")),r&&(A=Mf(A)),a){let ce=A.trim(),X="";const se=ce.lastIndexOf("> [!NOTE] 💡 演讲备注");if(se!==-1&&(X=ce.slice(se),ce=ce.slice(0,se).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const L=String(S.image).trim(),j=S.layout==="image-left"?"image-left":"image-right",v=`![配图](${L})
{: custom-slidev-layout="${j}" }`;S.layout==="image-left"?ce=`{{{col

${v}

${ce}

}}}`:ce=`{{{col

${ce}

${v}

}}}`}if(S.background){const j=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;ce=ce?`${j}

${ce}`:j}A=X?`${ce}

${X}`:ce}const me=w0(A);N[We]&&me.push(N[We]),N[Dt]&&me.push(N[Dt]);for(const ce of me)T.add(ce);const $e=/<[A-Z][a-zA-Z0-9]+/.test(A),ke=N[he]||(P===1?g[he]||"cover":"default");w[ke]=(w[ke]||0)+1,y.push({pageIndex:P++,pageAttrs:N,notes:Q,rawMarkdown:A,hasVueComponent:$e,hasStyleTag:W,assetReferences:me})}if(!u&&y.length>0){const R=y[0].rawMarkdown.match(/^#\s+(.+)$/m);R&&(u=R[1].trim())}m&&(g["custom-slidev-custom-css"]=m);let O=y.map(R=>`---

${R.rawMarkdown}`).join(`

`);return O.trimStart().startsWith("---")||(O=`---

${O.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:B,totalSlots:M,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:O,customCss:m}}function w0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&t.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(e))!==null;){const s=n[1].trim();s&&t.push(s)}return t}function Fa(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function x0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function S0(e,t,i=Ne){const n=e.filter(Fa);let o=0;if(n.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<t.length;s++){const l=t[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function _0(e,t=Ne){let i=!1,n=0;for(const o of e){if(Fa(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await t(o.id,{[Ce]:"right"}).catch(()=>{}),n++)}return n}async function C0(e,t,i=nl){const n={};if(!t||t.length===0)return n;const o=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&g0(e,n),n}async function $0(e){var B;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||nl,d=a.createDocFn||zc,f=a.setAttrsFn||Ne,g=a.getChildBlocksFn||fo,u=a.openTabFn||pe.openTab,m=a.showMessageFn||pe.showMessage;s&&o.length>0&&await C0(t,o,c);const p=x0(n),b=`/${p}`,y=await d(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((B=t.slides[0])==null?void 0:B.pageAttrs)||{};await f(y,{...x,...t.docRootAttrs});const _=await g(y).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await S0(_,t.slides,f),await _0(_,f)),m(`🎉 成功导入 Slidev 演示文档《${p}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function I0(e){const t=fe("file"),i=fe(!1),n=fe(!1),o=fe(""),s=fe(null),l=fe(null),r=fe(""),a=fe(0),c=fe(""),d=fe([]),f=fe(null),g=fe(""),u=fe([]),m=fe(""),p=fe(!0),b=fe(!0),y=fe(!0),x=fe(!0),_=ye(()=>{const N=a.value;if(N===0)return"0 B";const A=1024,D=["B","KB","MB","GB"],z=Math.floor(Math.log(N)/Math.log(A));return`${(N/A**z).toFixed(1)} ${D[z]}`}),B=ye(()=>{var N;return((N=f.value)==null?void 0:N.docRootAttrs["custom-slidev-theme"])||"default"}),M=ye(()=>{var N;return d.value.length>0?d.value.length:((N=f.value)==null?void 0:N.stats.discoveredAssets.length)||0}),T=ye(()=>{var A;const N=((A=f.value)==null?void 0:A.stats.layoutDistribution)||{};return Object.entries(N).map(([D,z])=>({name:D,count:z}))});async function w(N=Nc){try{const A=await N();A!=null&&A.notebooks&&Array.isArray(A.notebooks)&&(u.value=A.notebooks.filter(D=>!D.closed),u.value.length>0&&!m.value&&(m.value=u.value[0].id))}catch(A){console.warn("获取笔记本列表失败:",A)}}function P(){var N;(N=s.value)==null||N.click()}function O(){l.value=null,r.value="",a.value=0,f.value=null,d.value=[],o.value=""}async function R(N){o.value="",l.value=N,r.value=N.name,a.value=N.size;try{if(N.name.toLowerCase().endsWith(".zip")){const D=await N.arrayBuffer(),z=await m0(D);if(!z.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=z.assets;const Q=ro(z.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,virtualFiles:z.virtualFiles});f.value=Q,g.value=Q.docTitle||N.name.replace(/\.zip$/i,"")}else{const D=await N.text();d.value=[];const z=N.path||"",Q=z?z.replace(/[\\/][^\\/]+$/,""):"",G=ro(D,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,baseDir:Q||void 0});f.value=G,g.value=G.docTitle||N.name.replace(/\.md$/i,"")}}catch(A){console.error("解析文件失败:",A),o.value=`解析文件失败: ${A.message||String(A)}`}}function Y(){if(o.value="",!c.value.trim()){f.value=null;return}try{const N=ro(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1});f.value=N,g.value=N.docTitle||"Slidev 演示文稿"}catch(N){o.value=`解析 Markdown 源码失败: ${N.message||String(N)}`}}async function S(){l.value?await R(l.value):c.value&&Y()}async function F(N){const A=N.target;A.files&&A.files[0]&&await R(A.files[0])}async function k(N){var A;i.value=!1,(A=N.dataTransfer)!=null&&A.files&&N.dataTransfer.files[0]&&await R(N.dataTransfer.files[0])}async function E(N=e){if(f.value){if(!m.value&&u.value.length>0&&(m.value=u.value[0].id),!m.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await $0({presentation:f.value,notebookId:m.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:x.value,plugin:N})}catch(A){console.error("导入 Slidev 演示失败:",A),o.value=`导入执行失败: ${A.message||String(A)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:f,customDocTitle:g,notebooks:u,selectedNotebookId:m,optCleanHtml:p,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:_,currentTheme:B,extractedAssetsCount:M,layoutChips:T,fetchNotebooks:w,triggerFileInput:P,clearFile:O,processFile:R,onFileSelected:F,onFileDrop:k,onTextChange:Y,reprocessCurrentInput:S,handleConfirmImport:E}}const T0={class:"spm-import-dialog"},E0={class:"spm-tabs-header"},A0={class:"spm-dialog-body"},B0={key:0,class:"spm-file-section"},M0={key:0,class:"spm-dropzone-prompt"},D0={class:"spm-dropzone-icon"},L0={key:1,class:"spm-dropzone-active"},P0={class:"spm-file-badge"},O0={class:"spm-file-size"},R0={key:1,class:"spm-text-section"},N0={key:2,class:"spm-error-banner"},z0={key:3,class:"spm-preview-card"},F0={class:"spm-preview-card__header"},H0={style:{display:"inline-flex","align-items":"center",gap:"4px"}},j0={class:"spm-config-grid"},W0={class:"spm-form-item"},U0={class:"spm-form-item"},V0=["value"],K0={class:"spm-stats-grid"},G0={class:"spm-stat-box"},q0={class:"spm-stat-value"},Z0={class:"spm-stat-box"},Y0={class:"spm-stat-value"},J0={class:"spm-stat-box"},X0={class:"spm-stat-value"},Q0={class:"spm-stat-box"},ek={class:"spm-stat-value"},tk={key:0,class:"spm-chips-row"},ik={class:"spm-options-group"},nk={class:"spm-checkbox-label"},ok={class:"spm-checkbox-label"},sk={class:"spm-checkbox-label"},rk={class:"spm-checkbox-label"},lk={class:"spm-dialog-footer"},ak=["disabled"],ck=["disabled"],dk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},uk={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},fk=xt({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Rt("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:f,parsedPresentation:g,customDocTitle:u,notebooks:m,selectedNotebookId:p,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:_,formattedFileSize:B,currentTheme:M,layoutChips:T,fetchNotebooks:w,triggerFileInput:P,clearFile:O,onFileSelected:R,onFileDrop:Y,onTextChange:S,reprocessCurrentInput:F,handleConfirmImport:k}=I0(n);un(async()=>{await w()});async function E(){const A=await k();A&&(i("success",{docId:A}),i("close"))}function N(){i("close")}return(A,D)=>(te(),ne("div",{class:"spm-modal-overlay",onClick:Lt(N,["self"])},[h("div",T0,[h("div",{class:"spm-dialog-header"},[D[18]||(D[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:N},"✕")]),h("div",E0,[h("button",{class:_e(["spm-tab-btn",{active:be(o)==="file"}]),onClick:D[0]||(D[0]=z=>o.value="file")},[ae(ue,{name:"package"}),D[19]||(D[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:_e(["spm-tab-btn",{active:be(o)==="text"}]),onClick:D[1]||(D[1]=z=>o.value="text")},[ae(ue,{name:"notes"}),D[20]||(D[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",A0,[be(o)==="file"?(te(),ne("div",B0,[h("div",{class:_e(["spm-dropzone",{dragover:be(s),"has-file":!!be(c)}]),onDragover:D[4]||(D[4]=Lt(z=>s.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Lt(z=>s.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Lt((...z)=>be(Y)&&be(Y)(...z),["prevent"])),onClick:D[7]||(D[7]=(...z)=>be(P)&&be(P)(...z))},[h("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...z)=>be(R)&&be(R)(...z))},null,544),be(c)?(te(),ne("div",L0,[h("span",P0,[ae(ue,{name:"notes"}),$t(" "+ge(be(c)),1)]),h("span",O0,"("+ge(be(B))+")",1),h("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Lt((...z)=>be(O)&&be(O)(...z),["stop"]))},"更换文件")])):(te(),ne("div",M0,[h("span",D0,[ae(ue,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=h("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(te(),ne("div",R0,[Et(h("textarea",{"onUpdate:modelValue":D[8]||(D[8]=z=>Ye(d)?d.value=z:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...z)=>be(S)&&be(S)(...z))},null,544),[[$o,be(d)]])])),be(r)?(te(),ne("div",N0," ⚠️ "+ge(be(r)),1)):Me("",!0),be(g)?(te(),ne("div",z0,[h("div",F0,[h("span",H0,[ae(ue,{name:"sparkles"}),D[23]||(D[23]=$t(" 演示解析摘要",-1))]),D[24]||(D[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",j0,[h("div",W0,[D[25]||(D[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Et(h("input",{"onUpdate:modelValue":D[10]||(D[10]=z=>Ye(u)?u.value=z:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[$o,be(u)]])]),h("div",U0,[D[26]||(D[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Et(h("select",{"onUpdate:modelValue":D[11]||(D[11]=z=>Ye(p)?p.value=z:null),class:"spm-select"},[(te(!0),ne(Ve,null,kt(be(m),z=>(te(),ne("option",{key:z.id,value:z.id},ge(z.name),9,V0))),128))],512),[[ff,be(p)]])])]),h("div",K0,[h("div",G0,[h("span",q0,ge(be(g).totalSlides),1),D[27]||(D[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",Z0,[h("span",Y0,ge(be(M)),1),D[28]||(D[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",J0,[h("span",X0,ge(be(g).stats.totalNotes),1),D[29]||(D[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Q0,[h("span",ek,ge(be(f)),1),D[30]||(D[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),be(T).length>0?(te(),ne("div",tk,[D[31]||(D[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(te(!0),ne(Ve,null,kt(be(T),z=>(te(),ne("span",{key:z.name,class:"spm-chip-badge"},ge(z.name)+": "+ge(z.count),1))),128))])):Me("",!0),h("div",ik,[h("label",nk,[Et(h("input",{"onUpdate:modelValue":D[12]||(D[12]=z=>Ye(b)?b.value=z:null),type:"checkbox",onChange:D[13]||(D[13]=(...z)=>be(F)&&be(F)(...z))},null,544),[[Xn,be(b)]]),D[32]||(D[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",ok,[Et(h("input",{"onUpdate:modelValue":D[14]||(D[14]=z=>Ye(y)?y.value=z:null),type:"checkbox",onChange:D[15]||(D[15]=(...z)=>be(F)&&be(F)(...z))},null,544),[[Xn,be(y)]]),D[33]||(D[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",sk,[Et(h("input",{"onUpdate:modelValue":D[16]||(D[16]=z=>Ye(x)?x.value=z:null),type:"checkbox"},null,512),[[Xn,be(x)]]),D[34]||(D[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",rk,[Et(h("input",{"onUpdate:modelValue":D[17]||(D[17]=z=>Ye(_)?_.value=z:null),type:"checkbox"},null,512),[[Xn,be(_)]]),D[35]||(D[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Me("",!0)]),h("div",lk,[h("button",{class:"spm-btn-secondary",disabled:be(l),onClick:N}," 取消 ",8,ak),h("button",{class:"spm-btn-primary",disabled:!be(g)||be(l),onClick:E},[be(l)?(te(),ne("span",dk,[ae(ue,{name:"refresh"}),D[36]||(D[36]=$t(" 正在导入生成中...",-1))])):(te(),ne("span",uk,[ae(ue,{name:"rocket"}),D[37]||(D[37]=$t(" 确认导入思源笔记",-1))]))],8,ck)])])]))}}),pk=Mt(fk,[["__scopeId","data-v-2eff6f1e"]]);function or(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function hk(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,o=t.currentPageDividerId||"",s=t.activeBlockType||"";if(or(s)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===o}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===i))||((g=d.allBlockIds)==null?void 0:g.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=e.find(d=>{var f;return(f=d.noteBlocks)==null?void 0:f.some(g=>g.id===i||g.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ce];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var f,g;return((f=d.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function mk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function gk(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[m,p]of Object.entries(c))e.activeBlockAttrs.value[m]=p;De.setBlockAttrOverride(d,c),et(d,c);const f=(u=e.parentContainerId)==null?void 0:u.value,g=!!(f&&mk(d,f));if(Ze in c&&g&&f){const m=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=m),De.setBlockAttrOverride(f,{[Ze]:m}),et(f,{[Ze]:m}),Ne(f,{[Ze]:m}).catch(()=>{})}if(he in c){const m=c[he];e.currentPageDividerLayout.value=m,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=m)}if(yt in c){const m=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=m)}i("保存中...");try{await Ne(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function o(c,d){await n({[c]:d})}function s(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const f=s();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),De.setBlockAttrOverride(f,{[c]:d}),et(f,{[c]:d}),c===he&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Ne(f,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const f=s();if(!f)return;const g={[he]:c,[yt]:d};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[he]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,De.setBlockAttrOverride(f,g),et(f,g),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Ne(f,g),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var g;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=d,De.setBlockAttrOverride(f,{[c]:d}),et(f,{[c]:d}),(g=e.latestDoc.value)!=null&&g.config&&(c===An&&(e.latestDoc.value.config.theme=d),c===Bn&&(e.latestDoc.value.config.aspectRatio=d),c===Mn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await Ne(f,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:o,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Qr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Ha(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await t(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Qr(e),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Qr(e),isAiGenerated:!1}}async function vk(e,t){return(await Ha(e,t)).notes}function bk(e,t){const i=fe(!1),{triggerSaveNotice:n}=t;async function o(f){var B,M,T,w,P,O,R,Y;const m=`> [!NOTE] 💡 演讲备注
${(f||"在此输入本页讲稿提词...").split(/\r?\n/).map(S=>`> ${S}`).join(`
`)}
{: custom-slidev-note="true"}`,p=((B=e.latestDoc.value)==null?void 0:B.slides)||[],b=e.targetSlide.value,y=b?p.findIndex(S=>S===b):-1;let x=null;if(y!==-1&&y<p.length-1){const S=p[y+1];x=await Mi("markdown",m,S.startBlockId)}else{const S=((M=b==null?void 0:b.noteBlocks)==null?void 0:M.slice(-1)[0])||((T=b==null?void 0:b.blocks)==null?void 0:T.slice(-1)[0]),F=(S==null?void 0:S.id)||(b==null?void 0:b.startBlockId);F?x=await Mi("markdown",m,void 0,F):x=await us("markdown",m,e.currentDocId.value)}const _=((O=(P=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:P[0])==null?void 0:O.id)||((R=x==null?void 0:x[0])==null?void 0:R.id);return _&&(await Ne(_,{[nt]:"true"}),De.setBlockAttrOverride(_,{[nt]:"true"}),Ri(_,(Y=e.plugin)==null?void 0:Y.app)),e.plugin&&await e.plugin.compileCurrentDocument(),_}async function s(){const f=e.activeBlockId.value;if(f)if(e.isNoteBlock.value){n("取消中...");try{await Ne(f,{[nt]:"","slidev-note":""}),De.setBlockAttrOverride(f,{[nt]:"","slidev-note":""}),et(f,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),pe.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 取消讲稿备注失败:",g),n("取消失败"),pe.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let g=e.rawSnippet.value;try{const b=await Fc(f);b!=null&&b.kramdown&&(g=b.kramdown)}catch{}const p=`> [!NOTE] 💡 演讲备注
${(xa(g)||g.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",p,f),await Ne(f,{[nt]:"true"}),De.setBlockAttrOverride(f,{[nt]:"true"}),et(f,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),pe.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",g),n("设置失败"),pe.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await o(),pe.showMessage("已在正文末尾插入讲稿备注提示块")}catch(f){pe.showMessage("插入讲稿备注块失败"),console.error(f)}}function r(){var u;const f=e.currentSlideNoteBlockId.value;if(!f){pe.showMessage("未找到本页关联的讲稿备注块");return}Ri(f,(u=e.plugin)==null?void 0:u.app)?pe.showMessage("已在编辑区定位讲稿备注块"):pe.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const f=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};pe.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const g=await Ha(f,sl);if(g.notes){const m=e.currentSlideNoteBlockId.value;if(m){const p=`> [!NOTE] 💡 演讲备注
${g.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",p,m),await Ne(m,{[nt]:"true"}),De.setBlockAttrOverride(m,{[nt]:"true"}),Ri(m,(u=e.plugin)==null?void 0:u.app)}else await o(g.notes);g.isAiGenerated?pe.showMessage("思源 AI 演讲提词卡生成成功！"):pe.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const f=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(f.length===0){pe.showMessage("当前文档无幻灯片页面");return}const g=f.map((p,b)=>({slide:p,idx:b})).filter(({slide:p})=>{var x;const b=Array.isArray(p.noteBlocks)&&p.noteBlocks.length>0,y=!!((x=p.notes)!=null&&x.trim());return!b&&!y});if(g.length===0){pe.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=g.length;pe.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,y,x,_,B,M;if(i.value)return;i.value=!0,pe.showMessage("正在批量追加讲稿块...");let p=0;try{const P=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(O=>`> ${O}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:O,idx:R}of g)try{let Y=null;if(R<f.length-1){const F=f[R+1];Y=await Mi("markdown",P,F.startBlockId)}else{const F=((b=O==null?void 0:O.noteBlocks)==null?void 0:b.slice(-1)[0])||((y=O==null?void 0:O.blocks)==null?void 0:y.slice(-1)[0]),k=(F==null?void 0:F.id)||(O==null?void 0:O.startBlockId);k?Y=await Mi("markdown",P,void 0,k):Y=await us("markdown",P,e.currentDocId.value)}const S=((B=(_=(x=Y==null?void 0:Y[0])==null?void 0:x.doOperations)==null?void 0:_[0])==null?void 0:B.id)||((M=Y==null?void 0:Y[0])==null?void 0:M.id);S&&(await Ne(S,{[nt]:"true"}),De.setBlockAttrOverride(S,{[nt]:"true"})),p++}catch(Y){console.error(`[SiYuanSlidev] 为第 ${R+1} 页追加讲稿块失败:`,Y)}e.plugin&&await e.plugin.compileCurrentDocument(),pe.showMessage(`已成功为 ${p} 页追加讲稿备注块`)}catch(T){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",T),pe.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var p;if(i.value)return;const f=((p=e.latestDoc.value)==null?void 0:p.slides)||[];if(f.length===0){pe.showMessage("当前文档无幻灯片页面");return}const g=[];for(const b of f)if(b.noteBlocks&&b.noteBlocks.length>0)for(const y of b.noteBlocks)y.id&&g.push({id:y.id,pageIndex:b.pageIndex});if(g.length===0){pe.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(g.map(b=>b.pageIndex)).size,m=g.length;pe.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,pe.showMessage("正在批量删除讲稿块...");let b=0;try{for(const y of g)try{await ol(y.id),De.clearBlockAttrOverride(y.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${y.id} 失败:`,x)}e.activeBlockId.value&&g.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),pe.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(y){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",y),pe.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:o,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function yk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:o}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Bi]:"true",[Vi]:"true"}),e.activeBlockAttrs.value[Bi]="true",e.activeBlockAttrs.value[Vi]="true"):(await i(Bi,"false"),e.activeBlockAttrs.value[Bi]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(po,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Vi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(ho,w)}async function c(w){var S;const P=e.activeBlockId.value;if(!P)return;const O=e.rawSnippet.value||"",R=wi(O)||"",Y=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const F={[Ge]:"background",[he]:""};Y&&R&&(e.pageBackground.value=R,await Ne(Y,{[We]:R}).catch(()=>{}),De.setBlockAttrOverride(Y,{[We]:R}),et(Y,{[We]:R}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=R)),await n(F)}else(w===mo||w===go)&&await n({[he]:w,[Ge]:""});else{const F={[Ge]:"",[he]:""};if(e.activeBlockAttrs.value[We]==="true"&&(F[We]=""),Y&&R&&e.pageBackground.value===R&&(e.pageBackground.value="",await Ne(Y,{[We]:""}).catch(()=>{}),De.setBlockAttrOverride(Y,{[We]:""}),et(Y,{[We]:""}),(S=e.targetSlide.value)!=null&&S.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(F),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`),E=k==null?void 0:k.closest('[data-type="NodeListItem"]'),N=E==null?void 0:E.getAttribute("data-node-id");if(N&&N!==P){const A={[he]:"",[Ge]:""};et(N,A),De.setBlockAttrOverride(N,A),await Ne(N,A).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function f(w){i(Ze,w)}function g(w){i(qt,w)}function u(w){(e.activeBlockAttrs.value[Ce]||"")===w?i(Ce,""):i(Ce,w)}function m(w){e.elemShikiLines.value=w,i(Ni,w)}function p(w){e.elemMaxHeight.value=w,i(Dn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i(Ce,w?"col-1":"left"),pe.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const P={[Ze]:"",[qt]:"",[Ce]:"",[Ni]:"",[Dn]:"",[nt]:"","slidev-note":"",[he]:"",[yt]:"",[Ge]:"",[tt]:"",[We]:"",[Dt]:"",[Bi]:"",[po]:"",[Vi]:"",[ho]:""};if(et(w,P),await Ne(w,P),De.clearBlockAttrOverride(w),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),R=O==null?void 0:O.closest('[data-type="NodeListItem"]'),Y=R==null?void 0:R.getAttribute("data-node-id");Y&&Y!==w&&(et(Y,P),await Ne(Y,P).catch(()=>{}),De.clearBlockAttrOverride(Y))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",pe.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Mi("markdown","---",e.activeBlockId.value,void 0),pe.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("插入分页符失败")}}async function _(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Mi("markdown","---",void 0,w),pe.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("插入分页符失败")}}async function B(){if(e.activeBlockId.value)try{await ol(e.activeBlockId.value),pe.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("删除失败")}}async function M(){var w,P;try{let O=null;if(typeof document<"u"){const Y=e.activeBlockId.value;if(Y){const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${Y}"]`);S&&(O=S.getAttribute("data-type")==="NodeSuperBlock"?S:S.closest('[data-type="NodeSuperBlock"]'))}if(!O){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(S){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(F){let k=F.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const E=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(E){O=E;break}k=k.nextElementSibling}}}else{const F=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const E of k)if(!F||E.compareDocumentPosition(F)&Node.DOCUMENT_POSITION_FOLLOWING){O=E;break}}}}const R=[];if(O){const Y=Array.from(O.querySelectorAll(":scope > [data-node-id]"));for(const S of Y){const F=S.getAttribute("data-node-id");F&&(R.push(F),S.removeAttribute("style"))}}else if((P=e.targetSlide.value)!=null&&P.blocks){for(const Y of e.targetSlide.value.blocks)if(Y.children&&Y.children.length>=2){for(const S of Y.children)S.id&&R.push(S.id);break}}if(R.length>0)for(const Y of R)await Ne(Y,{style:""}).catch(()=>{});await o(yt,""),pe.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(O){console.error("[layout-actions] resetSuperBlockWidth error:",O),pe.showMessage("重置超级块比例失败")}}async function T(){var w,P,O;try{let R=null;if(typeof document<"u"){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),F=e.activeBlockId.value;let k=[];if(S){const A=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(A){let D=A.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(D),D=D.nextElementSibling}}else{const A=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const z of D)if(!A||z.compareDocumentPosition(A)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(z);else break}const E=[];let N;for(const A of k){const D=A.getAttribute("data-type");D==="NodeHeading"&&(N=A.getAttribute("data-node-id")||void 0);const z=[];D==="NodeSuperBlock"?z.push(A):z.push(...Array.from(A.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const Q of z){if((Q.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const W=Q.getAttribute("data-node-id")||"";let oe=[];const re=Array.from(Q.querySelectorAll('[data-type="NodeListItem"]'));if(re.length===4&&(oe=re.map(le=>le.getAttribute("data-node-id")).filter(Boolean)),oe.length!==4){const le=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));le.length===4&&(oe=le.map(me=>me.getAttribute("data-node-id")).filter(Boolean))}oe.length===4&&E.push({sbId:W,itemIds:oe,headerId:N})}}E.length>0&&(F&&(R=E.find(A=>{if(A.sbId===F||A.itemIds.includes(F))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${A.sbId}"]`),z=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`);return!!(D&&z&&D.contains(z))})||null),R||(R=E[0]))}if(!R&&((P=e.targetSlide.value)!=null&&P.blocks)){const S=e.targetSlide.value,F=[];for(const E of S.blocks)E.rawNode?F.push(E.rawNode):F.push({id:E.id,type:E.type,content:E.content,markdown:E.rawMarkdown,children:E.children,ial:E.attributes||E.ial||{}});const k=Tf(F,e.activeBlockId.value);k&&k.items.length===4&&(R={sbId:k.superBlockNode.id,itemIds:k.items.map(E=>E.id),headerId:(O=k.headerNode)==null?void 0:O.id})}if(!R||R.itemIds.length!==4)return pe.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const Y=e.currentPageDividerId.value||e.currentDocId.value;Y&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),De.setBlockAttrOverride(Y,{[he]:"clover"}),et(Y,{[he]:"clover"}),await Ne(Y,{[he]:"clover"}).catch(()=>{})),R.headerId&&(De.setBlockAttrOverride(R.headerId,{[Ce]:"header"}),et(R.headerId,{[Ce]:"header"}),await Ne(R.headerId,{[Ce]:"header"}).catch(()=>{}));for(let S=0;S<4;S++){const F=R.itemIds[S],k=`col-${S+1}`;De.setBlockAttrOverride(F,{[Ce]:k}),et(F,{[Ce]:k}),await Ne(F,{[Ce]:k}).catch(()=>{})}return pe.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(R){return console.error("[layout-actions] applyCloverLayout error:",R),pe.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:f,onElemMotionChange:g,onElemSlotChange:u,onElemShikiLinesChange:m,onElemMaxHeightChange:p,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:_,onDeleteCurrentBlock:B,resetSuperBlockWidth:M,applyCloverLayout:T}}function kk(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l}=gk(e),r=bk(e,{triggerSaveNotice:t}),a=yk(e,{saveAttr:n,saveAttrs:i,savePageAttr:o});function c(){if(!e.latestDoc.value){pe.showMessage("请先在主编辑区打开幻灯片文档");return}const f=La(e.latestDoc.value);Pa("presentation.html",f)&&pe.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){pe.showMessage("请先在主编辑区打开幻灯片文档");return}Oa(e.latestDoc.value)&&pe.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function wk(e){const t=ye(()=>or(e.activeBlockType.value));function i(n){const{attrKey:o,fallback:s,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[o];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=De.getBlockAttrOverride(a);if(r(c==null?void 0:c[o]))return c[o]}return s()})}return{isDivider:t,resolvePageAttr:i}}const xk={class:"spm-slidev-inspector"},Sk={class:"spm-inspector-topbar"},_k={class:"spm-inspector-title"},Ck={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},$k={class:"spm-inspector-topbar-actions"},Ik={class:"spm-target-banner"},Tk={class:"spm-target-info"},Ek=["aria-label"],Ak={key:0,class:"spm-save-status"},Bk=["title"],Mk={class:"spm-inspector-body"},Dk=xt({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=Rt("plugin"),n=fe(!1);function o(ee){n.value=!1,c.value=ee.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(ee.docId)}const s=fe(""),l=fe(""),r=fe({}),a=fe(""),c=fe(""),d=fe(""),f=fe(""),g=fe(""),u=fe(""),m=fe(""),p=fe(""),b=fe(null),y=fe(""),x=fe("");function _(){var ve;const ee=s.value||c.value;ee&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(ee).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const B=ye(()=>or(l.value)),M=ye(()=>l.value==="NodeCodeBlock"),T=fe(!1),w=ye(()=>{if(T.value||ze.value)return!0;const ee=a.value||"";return!!wi(ee)}),P=ye(()=>{const ee=l.value||"";if(ee==="NodeVideo"||ee==="video")return!0;const ve=a.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),O=ye(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),R=ye(()=>{const ee=s.value||c.value||"";return ee.length>8?ee.slice(-8):ee||"无"}),Y=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=ye(()=>{if(B.value)return"分页符 (---)";if(O.value)return"全局文档";if(P.value)return"视频块";let ee="内容块";switch(l.value){case"NodeHeading":ee="标题块";break;case"NodeParagraph":ee="段落块";break;case"NodeCodeBlock":ee="代码块";break;case"NodeVideo":ee="视频块";break;case"NodeList":case"NodeListItem":ee="列表项";break;case"NodeBlockquote":ee="引述块";break;case"NodeTable":ee="表格块";break;case"NodeSuperBlock":case"s":case"sb":ee="超级块";break;default:ee="内容块";break}return u.value?m.value?`${m.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ee}`:`分栏容器 › ${ee}`:ee}),F=ye(()=>B.value?"tag-divider":O.value?"tag-doc":"tag-block"),k=ye(()=>r.value[he]||"default"),E=ye(()=>r.value[tt]||"slide-left"),N=fe(""),A=fe(""),D=ye(()=>r.value[wn]||"inherit"),z=ye(()=>{var ee;return hk((ee=b.value)==null?void 0:ee.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),Q=ye(()=>{var ee;return((ee=z.value)==null?void 0:ee.notes)||""}),G=ye(()=>{var ee,ve,Te;return((Te=(ve=(ee=z.value)==null?void 0:ee.noteBlocks)==null?void 0:ve[0])==null?void 0:Te.id)||""}),W=ye(()=>{var Fe,He,Pe,ut,Kn,ui;if(B.value){const Qe=r.value[he]||r.value["custom-slidev-layout"];if(Qe)return Qe}const ee=r.value[Ce]||r.value["custom-slidev-slot"];if(ee&&(["col-1","col-2","col-3"].includes(ee)||/^col-\d+$/.test(ee)))return"cols-header";if(g.value)return g.value;const ve=f.value||(B.value?s.value:"");if(ve){const Qe=De.getBlockAttrOverride(ve);if(Qe!=null&&Qe[he])return Qe[he]}if(ve&&((Fe=b.value)!=null&&Fe.slides)){const Qe=b.value.slides.find(ji=>ji.startBlockId===ve);if((He=Qe==null?void 0:Qe.frontmatter)!=null&&He.layout)return Qe.frontmatter.layout}if((ut=(Pe=z.value)==null?void 0:Pe.frontmatter)!=null&&ut.layout)return z.value.frontmatter.layout;if((ui=(Kn=z.value)==null?void 0:Kn.blocks)!=null&&ui.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Te=De.getBlockAttrOverride(c.value);return Te!=null&&Te[he]?Te[he]:"default"}),oe=wk({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:f}),re=oe.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var ee,ve;return((ve=(ee=z.value)==null?void 0:ee.frontmatter)==null?void 0:ve.layoutRatio)||""}}),le=oe.resolvePageAttr({attrKey:qi,fallback:()=>{var ee,ve;return((ve=(ee=z.value)==null?void 0:ee.frontmatter)==null?void 0:ve.mask)||""}}),me=oe.resolvePageAttr({attrKey:Zi,fallback:()=>{var ee,ve;return((ve=(ee=z.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskRatio)||""}}),$e=oe.resolvePageAttr({attrKey:Yi,fallback:()=>{var ee,ve;return((ve=(ee=z.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),ke=oe.resolvePageAttr({attrKey:Ji,fallback:()=>{var ee,ve;return((ve=(ee=z.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function ce(ee){if(!ee||(ee.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Te=Array.from(ee.querySelectorAll(":scope > [data-node-id]"));if(Te.length<2)return null;const Fe=Te.length,He=Te.map(ui=>{const Qe=ui.getAttribute("style")||"",ji=Qe.match(/calc\(\s*([\d.]+)%/);if(ji)return parseFloat(ji[1]);const hn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return hn?parseFloat(hn[1]):null});let Pe="",ut=!1;if(He.some(ui=>ui!==null)){ut=!0;const ui=He.reduce((Be,ft)=>Be+(ft||0),0),Qe=He.filter(Be=>Be===null).length,ji=Qe>0?Math.max(0,100-ui)/Qe:100/Te.length,hn=He.map(Be=>Be!==null?Be:ji),Ac=hn.reduce((Be,ft)=>Be+ft,0)||1,mn=hn.map(Be=>Be/Ac*100);if(mn.length===2){const[Be]=mn;if(Be>=48&&Be<=52)Pe="1:1";else if(Be>=31&&Be<=35)Pe="1:2";else if(Be>=65&&Be<=69)Pe="2:1";else if(Be>=28&&Be<=32)Pe="3:7";else if(Be>=68&&Be<=72)Pe="7:3";else if(Be>=38&&Be<=42)Pe="4:6";else if(Be>=58&&Be<=62)Pe="6:4";else{const ft=Math.round(Be);Pe=`${ft}:${100-ft}`}}else if(mn.length===3){const[Be,ft,fi]=mn;if(Be>=31&&Be<=35&&ft>=31&&ft<=35&&fi>=31&&fi<=35)Pe="1:1:1";else if(Be>=23&&Be<=27&&ft>=48&&ft<=52&&fi>=23&&fi<=27)Pe="1:2:1";else if(Be>=48&&Be<=52&&ft>=23&&ft<=27&&fi>=23&&fi<=27)Pe="2:1:1";else if(Be>=23&&Be<=27&&ft>=23&&ft<=27&&fi>=48&&fi<=52)Pe="1:1:2";else{const ar=Math.round(Be),cr=Math.round(ft);Pe=`${ar}:${cr}:${100-ar-cr}`}}else Pe=mn.map(Be=>Math.round(Be)).join(":")}else ut=!1,Pe=Array.from({length:Fe},()=>1).join(":");const Kn=Fe>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Fe,ratio:Pe,isCustomWidth:ut,recommendedLayout:Kn}}function X(ee){if(!(ee!=null&&ee.blocks))return null;for(const ve of ee.blocks){const Te=ve.rawNode;if(Te&&st(Te)&&Yt(Te)){const He=fn(Te).length,Pe=Qs(Te);return{hasSuperBlock:!0,colCount:He,ratio:Pe||Array.from({length:He},()=>1).join(":"),isCustomWidth:!!Pe,recommendedLayout:He>=2?"cols-header":"two-cols"}}}return null}const se=ye(()=>{var ee;if(typeof document<"u"){const ve=s.value;if(ve){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(Fe){const He=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.closest('[data-type="NodeSuperBlock"]');if(He){const Pe=ce(He);if(Pe)return Pe}}}const Te=f.value||(B.value?s.value:"");if(Te){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${Te}"]`);if(Fe){let He=Fe.nextElementSibling;for(;He&&!(He.getAttribute("data-type")==="NodeThematicBreak"||(ee=He.classList)!=null&&ee.contains("protyle-wysiwyg__block--hr"));){const Pe=He.getAttribute("data-type")==="NodeSuperBlock"?He:He.querySelector('[data-type="NodeSuperBlock"]');if(Pe){const ut=ce(Pe);if(ut)return ut}He=He.nextElementSibling}}}else{const Fe=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),He=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Pe of He)if(!Fe||Pe.compareDocumentPosition(Fe)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=ce(Pe);if(ut)return ut}}}return X(z.value)}),L=ye(()=>{var ee;return((ee=se.value)==null?void 0:ee.ratio)||""}),j=ye(()=>{const ee=l.value||"";if(ee==="NodeSuperBlock"||ee==="s"||ee==="sb")return!0;if(typeof document<"u"&&s.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var ee;return((ee=z.value)==null?void 0:ee.pageIndex)||1}),V=ye(()=>!!(r.value[nt]||r.value["slidev-note"]));function H(){if(!u.value)return!1;if(s.value===u.value||typeof document>"u")return!0;const ee=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!ee)return!1;const ve=ee.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===s.value}const $=ye(()=>{var ve;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&H())return p.value||"";if(u.value)return"";const ee=s.value;if(ee&&((ve=z.value)!=null&&ve.blocks)){const Te=z.value.blocks.find(Fe=>Fe.id===ee);if(Te!=null&&Te.clicks)return Te.clicks}return""}),I=ye(()=>{var ve;if(r.value[qt])return r.value[qt];const ee=s.value;if(ee&&((ve=z.value)!=null&&ve.blocks)){const Te=z.value.blocks.find(Fe=>Fe.id===ee);if(Te!=null&&Te.motion)return typeof Te.motion=="string"?Te.motion:JSON.stringify(Te.motion)}return""}),C=ye(()=>{var ve;if(r.value[Ce])return r.value[Ce];const ee=s.value;if(ee&&((ve=z.value)!=null&&ve.blocks)){const Te=z.value.blocks.find(Fe=>Fe.id===ee);if(Te!=null&&Te.slot)return Te.slot}return""}),U=fe(""),q=fe(""),K=ye(()=>r.value[Bi]==="true"),ie=ye(()=>r.value[po]==="true"),Z=ye(()=>r.value[Vi]==="true"),J=ye(()=>r.value[ho]!=="false"),de=ye(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.theme)||r.value[An]||"default"}),Se=ye(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.aspectRatio)||r.value[Bn]||"16/9"}),xe=ye(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.defaultTransition)||r.value[Mn]||"slide-left"}),Ae=ye(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.spacing)||r.value[ps]||"normal"}),ze=ye(()=>{var He,Pe;if((r.value[Ge]||r.value["slidev-role"])===cl||r.value[We]==="true")return"background";const ve=r.value[he]||r.value["slidev-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Te=a.value||"",Fe=wi(Te);if(Fe&&((Pe=(He=z.value)==null?void 0:He.frontmatter)!=null&&Pe.background)){const ut=z.value.frontmatter.background;if(ut===Fe||ut.endsWith(Fe)||Fe.endsWith(ut))return"background"}return""}),qe=ye(()=>!!(r.value[Ze]||r.value[qt]||r.value[Ce]||r.value[Ni]||r.value[nt]||r.value["slidev-note"]||r.value[Ge]||r.value[he]||r.value[Bi]||r.value[po]||r.value[Vi]||r.value[ho])),{saveAttr:Je,savePageAttr:Le,applyPageLayoutAndRatio:Jt,applyCloverLayout:rt,resetSuperBlockWidth:Xe,saveDocAttr:Ht,onToggleVideoAutoplay:Fi,onToggleVideoLoop:Uo,onToggleVideoMuted:Vo,onToggleVideoControls:Vn,onImageRoleChange:Si,onToggleNoteBlock:Hi,onAddNoteBlock:qa,onLocateNoteBlock:Za,onGenerateNotesWithAI:Ya,isBatchProcessing:Ja,onBatchAppendNotes:Xa,onBatchDeleteNotes:Qa,toggleElemClick:ec,onElemClickStepChange:tc,onElemMotionChange:ic,onElemSlotChange:nc,onElemShikiLinesChange:oc,onElemMaxHeightChange:sc,onSetTwoColsContrast:rc,onClearBlockAttrs:lc,onInsertDividerBefore:ac,onInsertDividerAfter:sr,onDeleteCurrentBlock:cc,onExportHtml:dc,onExportPdf:uc}=kk({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:g,parentContainerId:u,parentContainerClicks:p,latestDoc:b,targetSlide:z,currentSlideNoteBlockId:G,currentSlideLayout:W,isNoteBlock:V,elemClick:$,videoAutoplay:K,videoLoop:ie,videoMuted:Z,videoControls:J,pageBackground:N,pageImage:A,elemShikiLines:U,elemMaxHeight:q,saveStatus:y,plugin:i});async function fc(ee){if(ee==="clover"){if(!await rt())return}else Je(he,ee)}function pc(ee){Le(yt,ee)}function hc(ee){Le(qi,ee)}function mc(ee){Le(Zi,ee)}function gc(ee){Le(Yi,ee)}function vc(ee){Le(Ji,ee)}function rr(ee){if(!ee)return;const ve=ee.recommendedLayout||(ee.colCount&&ee.colCount>=2?"cols-header":"two-cols"),Te=ee.ratio||(ee.colCount?Array(ee.colCount).fill(1).join(":"):"1:1");Jt(ve,Te)}function bc(ee){Le(yt,ee)}async function yc(){await Xe()}function kc(ee){Je(tt,ee)}function wc(ee){N.value=ee,Je(We,ee)}function xc(ee){A.value=ee,Je(Dt,ee)}function Sc(ee){Je(wn,ee==="inherit"?"":ee)}function _c(ee){Ht(An,ee)}function Cc(ee){Ht(Bn,ee)}function $c(ee){Ht(Mn,ee)}function Ic(ee){Ht(ps,ee)}function lr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Tc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Ec(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(ee){s.value=ee.id,l.value=ee.type,r.value={...ee.attrs},a.value=ee.content||ee.markdown||"",d.value=ee.topBlockId||ee.id,f.value=ee.pageDividerId||"",g.value=ee.pageDividerLayout||"",u.value=ee.parentContainerId||"",m.value=ee.parentContainerSlot||"",p.value=ee.parentContainerClicks||"",ee.rootId?c.value=ee.rootId:(ee.type==="doc"||ee.type==="NodeDocument")&&ee.id&&(c.value=ee.id),N.value=ee.attrs[We]||"",A.value=ee.attrs[Dt]||"",U.value=ee.attrs[Ni]||"",q.value=ee.attrs[Dn]||"",T.value=!!ee.isImage},updateDocument(ee){b.value=ee,c.value=ee.docId},openImportDialog(){n.value=!0},setCurrentDocId(ee){c.value=ee}}),(ee,ve)=>(te(),ne("div",xk,[h("div",Sk,[h("div",_k,[(te(),ne("svg",Ck,[...ve[2]||(ve[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=h("span",null,"演示配置",-1))]),h("div",$k,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Te=>n.value=!0)},[ae(ue,{name:"import"}),ve[4]||(ve[4]=h("span",null,"导入",-1))]),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:lr},[ae(ue,{name:"split-preview"}),ve[5]||(ve[5]=h("span",null,"分屏预览",-1))])])]),h("div",Ik,[h("div",Tk,[h("span",{class:_e(["spm-target-tag",F.value])},ge(S.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:_},[ae(ue,{name:"copy"}),h("span",null,"#"+ge(R.value),1)],8,Ek)]),y.value?(te(),ne("span",Ak,"● "+ge(y.value),1)):Me("",!0)]),Y.value?(te(),ne("div",{key:0,class:"spm-context-quote",title:a.value},ge(Y.value),9,Bk)):Me("",!0),h("div",Mk,[B.value?(te(),Pt(Fb,{key:0,"page-layout":k.value,"page-layout-ratio":be(re),"page-mask":be(le),"page-mask-ratio":be(me),"page-mask-style":be($e),"page-mask-initial":be(ke),"detected-sb-ratio":L.value,"detected-sb-info":se.value,"page-transition":E.value,"page-background":N.value,"page-spacing":D.value,"page-image":A.value,"page-notes":Q.value,"page-index":v.value,"onUpdate:pageLayout":fc,"onUpdate:pageLayoutRatio":pc,"onUpdate:pageMask":hc,"onUpdate:pageMaskRatio":mc,"onUpdate:pageMaskStyle":gc,"onUpdate:pageMaskInitial":vc,onApplySuperBlockLayout:rr,onResetSuperblockRatio:yc,"onUpdate:pageTransition":kc,"onUpdate:pageBackground":wc,"onUpdate:pageSpacing":Sc,"onUpdate:pageImage":xc,onAddNoteBlock:be(qa),onLocateNoteBlock:be(Za),onGenerateNotes:be(Ya),onBatchAppendNotes:be(Xa),onBatchDeleteNotes:be(Qa),"is-batch-processing":be(Ja),onInsertDividerAfter:be(sr),onDeleteDivider:be(cc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!O.value?(te(),Pt(_y,{key:1,"elem-click":$.value,"elem-motion":I.value,"elem-slot":C.value,"elem-shiki-lines":U.value,"elem-max-height":q.value,"is-code-block":M.value,"is-image":w.value,"is-video":P.value,"is-super-block":j.value,"detected-sb-info":se.value,"video-autoplay":K.value,"video-loop":ie.value,"video-muted":Z.value,"video-controls":J.value,"has-block-attrs":qe.value,"is-note":V.value,"image-role":ze.value,"current-slide-layout":W.value,"parent-elem-click":p.value,"parent-container-slot":m.value,"parent-container-id":u.value,onToggleNote:be(Hi),onToggleElemClick:be(ec),onToggleVideoAutoplay:be(Fi),onToggleVideoLoop:be(Uo),onToggleVideoMuted:be(Vo),onToggleVideoControls:be(Vn),"onUpdate:imageRole":be(Si),"onUpdate:elemClick":be(tc),"onUpdate:elemMotion":be(ic),"onUpdate:elemSlot":be(nc),"onUpdate:elemShikiLines":be(oc),"onUpdate:elemMaxHeight":be(sc),onApplySuperBlockLayout:rr,onApplySuperBlockRatio:bc,onInsertDividerBefore:be(ac),onInsertDividerAfter:be(sr),onSetTwoColsContrast:be(rc),onClearBlockAttrs:be(lc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(te(),Pt(a0,{key:2,"doc-theme":de.value,"doc-aspect-ratio":Se.value,"doc-default-transition":xe.value,"doc-spacing":Ae.value,"onUpdate:docTheme":_c,"onUpdate:docAspectRatio":Cc,"onUpdate:docDefaultTransition":$c,"onUpdate:docSpacing":Ic,onOpenBottomPreview:lr,onOpenPresenter:Tc,onAiAutoSplit:Ec,onExportHtml:be(dc),onExportPdf:be(uc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(te(),Pt(pk,{key:1,onClose:ve[1]||(ve[1]=Te=>n.value=!1),onSuccess:o})):Me("",!0)]))}}),Lk=2e3,Pk=600;function Ok(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function as(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(el(e))return!0;const t=e.firstElementChild;return!!(t&&el(t))}function el(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Rk(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Nk{constructor(){we(this,"consumers",new Map);we(this,"seq",0);we(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const o=++this.seq,s=Rk(),l={kind:t,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=as(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?as(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Ok(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&as(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Lk))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const lo=new Nk,pn=new Wo;function ja(e,t,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=lo.register(e,t,n);return n(),o}let vi=null,At=null,ao=null;function zk(){return At}function Fk(e,t){vi&&Wa(),vi=Js(Lg),vi.provide("plugin",t),vi.provide("sandboxBridge",pn);const i=vi.mount(e);return At=i,ao=ja("preview",e,t),i}function Wa(e){ao&&(ao(),ao=null),vi&&(vi.unmount(),vi=null,At=null)}function Hk(){return At!==null}let bi=null,Li=null;function jk(e,t){return bi&&Ua(),bi=Js(_v),bi.provide("plugin",t),bi.provide("sandboxBridge",pn),Li=bi.mount(e),Li}function Ua(e){bi&&(bi.unmount(),bi=null,Li=null)}function Wk(e){try{const t=new BroadcastChannel("siyuan-slidev-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let yi=null,_t=null,co=null;function Uk(e,t){yi&&Va(),yi=Js(Dk),yi.provide("plugin",t),yi.provide("sandboxBridge",pn);const i=yi.mount(e);return _t=i,co=ja("dock",e,t),i}function Va(e){co&&(co(),co=null),yi&&(yi.unmount(),yi=null,_t=null)}function Vk(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),At!=null&&At.updateDocument?At.updateDocument(e,t):(pn.updateSlides(e.slides,e.config,e.fullMarkdown),Wk(e)),Li!=null&&Li.updateDocument&&Li.updateDocument(e)}function Bs(e){At!=null&&At.navigateToBlock?At.navigateToBlock(e):pn.highlightElement(e)}function uo(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function Kk(){return _t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}function Gk(e,t){const i=[];let o=0;for(let s=0;s<e.length;s++){const l=e[s];if(Io(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<e.length-1){const c=e[s+1];Io(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const qk=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ce,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class cs{getPresetTemplates(){return qk}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Zk(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Kk()||pe.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Ne(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),pe.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){pe.showMessage("请先打开一篇思源笔记文档");return}const t=await fo(e.currentDocId).catch(()=>[]);if(!t||t.length===0){pe.showMessage("当前文档无内容，无需断页");return}const i=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=Gk(i);if(n.length===0){pe.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}pe.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Mi("markdown","---",void 0,s.blockId),await Ne(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}pe.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,f;if(!e.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!e.currentDocId){pe.showMessage("请先打开一篇思源笔记文档");return}pe.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await fo(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await vk(i,sl)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await us("markdown",s,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((f=l==null?void 0:l[0])==null?void 0:f.id);r&&(await Ne(r,{"custom-slidev-note":"true"}),De.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Ri(r,e.app)),pe.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new cs,i=t.buildTransitionStatsSql(),n=await on(i).catch(()=>[]),o=t.formatTransitionSummary(n||[]);pe.showMessage(o)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new cs().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),pe.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):pe.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new cs().batchUpdateTransitions("fade","slide-left",n=>on(n).catch(()=>[]),(n,o)=>Ne(n,o));pe.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){pe.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&pe.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{pe.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?pe.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):pe.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){pe.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",fs);t.success?pe.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):pe.showMessage(`同步失败：${t.error}`)}})}function Ka(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ga(e,t){var i,n,o;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=s==null?void 0:s.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await on(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((o=s[0])!=null&&o.content))return String(s[0].content).trim()}catch{}return""}async function Yk(e,t,i){var c,d,f;const n=zk(),o=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),s=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(o&&s&&i&&i!==s)return;const l=i||(o&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ga(e,l));const a=Ka(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const g=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of g){const m=u.querySelector(".item__text"),p=((f=m==null?void 0:m.textContent)==null?void 0:f.trim())||"";if(p.includes("Slidev 演示预览")||p.startsWith("即现")){m&&(m.textContent=a),u.setAttribute("title",a);break}}}}class Jk{constructor(t=400){we(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Xk(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&t.set(o.id,o.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class Qk{constructor(t=150){we(this,"lastBlockId","");we(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class ew{constructor(){we(this,"attrCache",new Jk);we(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=De.getBlockAttrOverride(t),o=this.getCompiledIal(i,t);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(t);if(s)return s;const l=await Ms(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Xk(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var s;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(t,null);uo({id:t,rootId:t,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),Bs(t)}handleBlockClickedFromSlide(t,i,n,o){var a;if(!t)return!1;const s=Ri(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const f=o.slides.find(g=>{var u,m,p;return g.startBlockId===t||((u=g.blocks)==null?void 0:u.some(b=>b.id===t))||((m=g.allBlockIds)==null?void 0:m.includes(t))||((p=g.noteBlocks)==null?void 0:p.some(b=>b.id===t))});f!=null&&f.startBlockId&&(c=f.startBlockId),(a=f==null?void 0:f.frontmatter)!=null&&a.layout&&(d=f.frontmatter.layout)}this.resolveBlockAttrs(t,o).then(async f=>{if(c&&!d){const g=De.getBlockAttrOverride(c);if(g!=null&&g[he]||g!=null&&g["custom-slidev-layout"])d=g[he]||g["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,o);d=u[he]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&De.setBlockAttrOverride(c,u)}}uo({id:t,rootId:n,type:r||"NodeParagraph",attrs:f||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(t,i,n,o,s){var E,N,A,D,z,Q,G,W;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const re=await this.resolveBlockAttrs(oe,s),le=De.getBlockAttrOverride(oe)||{},me={...re,...le};(me[nt]||me["slidev-note"])&&(l=c,r=oe,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(d==null?void 0:d.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((E=d==null?void 0:d.classList)!=null&&E.contains("hr")),u=a==="NodeCodeBlock",m=((N=l.innerText)==null?void 0:N.trim())||"",p=await this.resolveBlockAttrs(r,s),b=De.getBlockAttrOverride(r)||{},y={...p,...b};let x="",_="";if(g)x=r,_=y[he]||y["custom-slidev-layout"]||"";else{let oe=d.previousElementSibling;for(;oe;){const re=oe.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||(A=oe.classList)!=null&&A.contains("hr")){x=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,f];let re=l.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const me=re.getAttribute("data-node-id");me&&!oe.includes(me)&&oe.push(me),re=re.parentElement}const le=s.slides.find(me=>{var $e,ke,ce;return oe.includes(me.startBlockId)||(($e=me.blocks)==null?void 0:$e.some(X=>oe.includes(X.id)))||((ke=me.allBlockIds)==null?void 0:ke.some(X=>oe.includes(X)))||((ce=me.noteBlocks)==null?void 0:ce.some(X=>oe.includes(X.id)))});le&&(!x&&le.startBlockId&&(x=le.startBlockId),!_&&((D=le.frontmatter)!=null&&D.layout)&&(_=le.frontmatter.layout))}if(x){const oe=De.getBlockAttrOverride(x);if(oe&&(he in oe||"custom-slidev-layout"in oe)&&(_=oe[he]||oe["custom-slidev-layout"]||""),!_&&(s!=null&&s.slides)){const re=s.slides.find(le=>le.startBlockId===x);(z=re==null?void 0:re.frontmatter)!=null&&z.layout&&(_=re.frontmatter.layout)}if(!_){const re=await this.resolveBlockAttrs(x,s);_=re[he]||re["custom-slidev-layout"]||"",re&&Object.keys(re).length>0&&De.setBlockAttrOverride(x,re)}et(x,{[he]:_||""})}else if(o){const oe=De.getBlockAttrOverride(o);oe&&(he in oe||"custom-slidev-layout"in oe)?_=oe[he]||oe["custom-slidev-layout"]||"":!_&&((W=(G=(Q=s==null?void 0:s.slides)==null?void 0:Q[0])==null?void 0:G.frontmatter)!=null&&W.layout)&&(_=s.slides[0].frontmatter.layout)}const B=l.getAttribute(he)||l.getAttribute("custom-slidev-layout"),M=y[he]||y["custom-slidev-layout"]||"";B&&B!==M&&et(r,{[he]:M});const T=l.getAttribute(Ge)||l.getAttribute("custom-slidev-role"),w=y[Ge]||y["custom-slidev-role"]||"";T&&T!==w&&et(r,{[Ge]:w});let P="",O="",R="";const Y=l.closest('[data-type="NodeListItem"]');if(Y&&Y!==l){const oe=Y.getAttribute("data-node-id");if(oe){P=oe;const re=await this.resolveBlockAttrs(oe,s),le=De.getBlockAttrOverride(oe)||{},me={...re,...le};O=me[Ce]||"",R=me[Ze]||"";const $e=me[he]||me["custom-slidev-layout"]||"",ke=Y.getAttribute(he)||Y.getAttribute("custom-slidev-layout");ke&&ke!==$e&&et(oe,{[he]:$e});const ce=me[Ge]||me["custom-slidev-role"]||"",X=Y.getAttribute(Ge)||Y.getAttribute("custom-slidev-role");X&&X!==ce&&et(oe,{[Ge]:ce})}}const S=!!l.querySelector("img, span[data-type='img']"),F=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=S&&F.length<=50;uo({id:r,rootId:o,type:a,content:m,attrs:y,isDivider:g,isCode:u,isImage:k,topBlockId:f,pageDividerId:x,pageDividerLayout:_,parentContainerId:P,parentContainerSlot:O,parentContainerClicks:R})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(n.id,l),De.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var o,s,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[he]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[he]&&(c[he]=a.ial[he]),(l=a.ial)!=null&&l[Ge]&&(c[Ge]=a.ial[Ge]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=De.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[he]!==void 0&&(c[he]=a[he]),a[Ge]!==void 0&&(c[Ge]=a[Ge]),i.set(r,c)}bh(i)}}const Ti=new ew;class tw{constructor(){we(this,"inFlightDocId",null);we(this,"pendingDocId",null);we(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const iw=150,nw=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,ow="slidev-dock",ds="slidev-preview-tab",tl="slidev-presenter-tab",il=wf;class sw extends pe.Plugin{constructor(){super(...arguments);we(this,"isMobile",!1);we(this,"currentDocId","");we(this,"previewTab",null);we(this,"latestCompiledDoc",null);we(this,"cliBridge",new er);we(this,"debounceTimer",null);we(this,"activeCursorBlockId","");we(this,"compileScheduler",new tw);we(this,"dirtyDocId",null);we(this,"inspectorSyncThrottle",new Qk);we(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));we(this,"onWsMainBound",this.onWsMain.bind(this));we(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));we(this,"onEditorClickBound",this.onEditorClick.bind(this));we(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));we(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));we(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=pe.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(nw),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Zk(this);const n=this;if(this.addTab({type:ds,init(o){var r;const s=this||o;n.previewTab=(s==null?void 0:s.tab)||null,Fk(s.element,n);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Wa(this.element)}}),this.addTab({type:tl,init(o){jk((this||o).element,n)},destroy(){Ua(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:ow,init(){Uk(this.element,n)},destroy(){Va(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(il),n=xf(i);return Di(n),n}catch{return Di(an),an}}async saveGlobalSettings(i){const n=jo(),o=Di({...n,...i||{}});try{await this.saveData(il,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,lo.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),pn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await pe.openTab({app:this.app,custom:{id:this.name+ds,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){Hk()||await this.openBottomPreviewTab(),await pe.openTab({app:this.app,custom:{id:this.name+tl,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=pe.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-slidev/slidev-client/index.html","SlidevBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(o),l=await pe.openTab({app:this.app,custom:{id:this.name+ds,title:s,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),pe.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,o=(r=n==null?void 0:n.block)==null?void 0:r.rootID,s=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const f=await Ms(o).catch(()=>({}));uo({id:o,rootId:o,type:"doc",attrs:f}),this.markCompileDirty(o),this.updatePreviewTabHeader(s,o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Ka(i)}async fetchDocumentTitle(i){return Ga(this,i)}async updatePreviewTabHeader(i,n){return Yk(this,i,n)}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(i){return Ti.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ti.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=iw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=lo.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,Pk);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ti.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const f=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const f=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&lo.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await De.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Vk(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ti.purgeStaleDomSlidevAttrs(i)}}module.exports=sw;
