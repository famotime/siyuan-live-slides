"use strict";var Ac=Object.create;var Ws=Object.defineProperty;var Bc=Object.getOwnPropertyDescriptor;var Mc=Object.getOwnPropertyNames;var Dc=Object.getPrototypeOf,Lc=Object.prototype.hasOwnProperty;var Pc=(e,t,i)=>t in e?Ws(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Oc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Mc(t))!Lc.call(e,s)&&s!==i&&Ws(e,s,{get:()=>t[s],enumerable:!(n=Bc(t,s))||n.enumerable});return e};var Kn=(e,t,i)=>(i=e!=null?Ac(Dc(e)):{},Oc(t||!e||!e.__esModule?Ws(i,"default",{value:e,enumerable:!0}):i,e));var Se=(e,t,i)=>Pc(e,typeof t!="symbol"?t+"":t,i);const me=require("siyuan");async function mt(e,t){const i=await me.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Rc(){return mt("/api/notebook/lsNotebooks","")}async function Nc(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function il(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return mt("/api/asset/upload",i)}async function Bi(e,t,i,n,s){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function co(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function cr(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function nl(e){return mt("/api/block/deleteBlock",{id:e})}async function zc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function ds(e){return mt("/api/block/getChildBlocks",{id:e})}async function Fc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function je(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Mo(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function nn(e){return mt("/api/query/sql",{stmt:e})}async function uo(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function sl(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Hc(){return mt("/api/storage/getInlineStyles","")}const ol=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function jc(e){const t=[];if(!e)return t;const i=new RegExp(ol.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function Wc(e,t){if(!e)return"";const i=new RegExp(ol.source,"g");return e.replace(i,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(t&&t[s]){const d=t[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}const En="custom-slidev-theme",An="custom-slidev-aspect-ratio",rl="custom-slidev-highlighter",Bn="custom-slidev-default-transition",ll="custom-slidev-color-schema",fo="custom-slidev-spacing",Ei="custom-slidev-slide",ye="custom-slidev-layout",pt="custom-slidev-transition",et="custom-slidev-background",Mt="custom-slidev-image",Us="custom-slidev-notes",Ki="custom-slidev-class",kn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",Gi="custom-slidev-mask",qi="custom-slidev-mask-ratio",Zi="custom-slidev-mask-style",Yi="custom-slidev-mask-initial",Ze="custom-slidev-click",Kt="custom-slidev-motion",Ni="custom-slidev-shiki-lines",$e="custom-slidev-slot",it="custom-slidev-note",qe="custom-slidev-role",Mn="custom-slidev-max-height",Ai="custom-slidev-autoplay",us="custom-slidev-loop",Vi="custom-slidev-muted",fs="custom-slidev-controls",al="background",ps="image-left",hs="image-right";function Dn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Uc(e){if(!e||typeof e!="string")return{steps:2,breakpoints:[50,100]};const t=e.trim();if(!t)return{steps:2,breakpoints:[50,100]};const i=t.split(":").map(c=>parseFloat(c.trim())).filter(c=>!isNaN(c)&&c>0);if(i.length===0)return{steps:2,breakpoints:[50,100]};if(i.length===1){const c=Math.min(100,Math.max(1,i[0]));return c===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(c*100)/100,100]}}const n=i.every((c,d)=>d===0||c>i[d-1]),s=i[i.length-1];if(n&&(s===100||i.some(c=>c>10))){const c=i.map(d=>Math.min(100,Math.round(d*100)/100));return c[c.length-1]<100&&c.push(100),{steps:c.length,breakpoints:c}}const l=i.reduce((c,d)=>c+d,0);if(l<=0)return{steps:2,breakpoints:[50,100]};let r=0;const a=[];for(let c=0;c<i.length;c++)r+=i[c],c===i.length-1?a.push(100):a.push(Math.round(r/l*1e4)/100);return{steps:a.length,breakpoints:a}}function Vc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Kc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function cl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function dl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Tt(e,t){if(!cl(e))return e;const i=dl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Gc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Tt(o,t);return`![${s}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Do(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ve={},Ji=[],Gt=()=>{},ul=()=>!1,Cs=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),$s=e=>e.startsWith("onUpdate:"),ct=Object.assign,Lo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},qc=Object.prototype.hasOwnProperty,Fe=(e,t)=>qc.call(e,t),Ie=Array.isArray,Xi=e=>Hn(e)==="[object Map]",an=e=>Hn(e)==="[object Set]",dr=e=>Hn(e)==="[object Date]",Ae=e=>typeof e=="function",Qe=e=>typeof e=="string",Pt=e=>typeof e=="symbol",Ue=e=>e!==null&&typeof e=="object",fl=e=>(Ue(e)||Ae(e))&&Ae(e.then)&&Ae(e.catch),pl=Object.prototype.toString,Hn=e=>pl.call(e),Zc=e=>Hn(e).slice(8,-1),hl=e=>Hn(e)==="[object Object]",Po=e=>Qe(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,wn=Do(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Is=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Yc=/-\w/g,wt=Is(e=>e.replace(Yc,t=>t.slice(1).toUpperCase())),Jc=/\B([A-Z])/g,wi=Is(e=>e.replace(Jc,"-$1").toLowerCase()),Ts=Is(e=>e.charAt(0).toUpperCase()+e.slice(1)),Vs=Is(e=>e?`on${Ts(e)}`:""),Wt=(e,t)=>!Object.is(e,t),ts=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},ml=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Es=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let ur;const As=()=>ur||(ur=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Ut(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=Qe(n)?td(n):Ut(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(Qe(e)||Ue(e))return e}const Xc=/;(?![^(]*\))/g,Qc=/:([^]+)/,ed=/\/\*[^]*?\*\//g;function td(e){const t={};return e.replace(ed,"").split(Xc).forEach(i=>{if(i){const n=i.split(Qc);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(Qe(e))t=e;else if(Ie(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(Ue(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const id="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",nd=Do(id);function gl(e){return!!e||e===""}function sd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=cn(e[n],t[n]);return i}function cn(e,t){if(e===t)return!0;let i=dr(e),n=dr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Pt(e),n=Pt(t),i||n)return e===t;if(i=Ie(e),n=Ie(t),i||n)return i&&n?sd(e,t):!1;if(i=Ue(e),n=Ue(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!cn(e[l],t[l]))return!1}}return String(e)===String(t)}function Oo(e,t){return e.findIndex(i=>cn(i,t))}const vl=e=>!!(e&&e.__v_isRef===!0),xe=e=>Qe(e)?e:e==null?"":Ie(e)||Ue(e)&&(e.toString===pl||!Ae(e.toString))?vl(e)?xe(e.value):JSON.stringify(e,bl,2):String(e),bl=(e,t)=>vl(t)?bl(e,t.value):Xi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[Ks(n,o)+" =>"]=s,i),{})}:an(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Ks(i))}:Pt(t)?Ks(t):Ue(t)&&!Ie(t)&&!hl(t)?String(t):t,Ks=(e,t="")=>{var i;return Pt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class od{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function rd(){return lt}let Ge;const Gs=new WeakSet;class yl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Gs.has(this)&&(Gs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||wl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,fr(this),xl(this);const t=Ge,i=Dt;Ge=this,Dt=!0;try{return this.fn()}finally{Sl(this),Ge=t,Dt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)zo(t);this.deps=this.depsTail=void 0,fr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Gs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){po(this)&&this.run()}get dirty(){return po(this)}}let kl=0,xn,Sn;function wl(e,t=!1){if(e.flags|=8,t){e.next=Sn,Sn=e;return}e.next=xn,xn=e}function Ro(){kl++}function No(){if(--kl>0)return;if(Sn){let t=Sn;for(Sn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;xn;){let t=xn;for(xn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function xl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Sl(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),zo(n),ld(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function po(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(_l(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function _l(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Ln)||(e.globalVersion=Ln,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!po(e))))return;e.flags|=2;const t=e.dep,i=Ge,n=Dt;Ge=e,Dt=!0;try{xl(e);const s=e.fn(e._value);(t.version===0||Wt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Ge=i,Dt=n,Sl(e),e.flags&=-3}}function zo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)zo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function ld(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Dt=!0;const Cl=[];function oi(){Cl.push(Dt),Dt=!1}function ri(){const e=Cl.pop();Dt=e===void 0?!0:e}function fr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ge;Ge=void 0;try{t()}finally{Ge=i}}}let Ln=0;class ad{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Fo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ge||!Dt||Ge===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ge)i=this.activeLink=new ad(Ge,this),Ge.deps?(i.prevDep=Ge.depsTail,Ge.depsTail.nextDep=i,Ge.depsTail=i):Ge.deps=Ge.depsTail=i,$l(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ge.depsTail,i.nextDep=void 0,Ge.depsTail.nextDep=i,Ge.depsTail=i,Ge.deps===i&&(Ge.deps=n)}return i}trigger(t){this.version++,Ln++,this.notify(t)}notify(t){Ro();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{No()}}}function $l(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)$l(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const ho=new WeakMap,Li=Symbol(""),mo=Symbol(""),Pn=Symbol("");function ft(e,t,i){if(Dt&&Ge){let n=ho.get(e);n||ho.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Fo),s.map=n,s.key=i),s.track()}}function ei(e,t,i,n,s,o){const l=ho.get(e);if(!l){Ln++;return}const r=a=>{a&&a.trigger()};if(Ro(),t==="clear")l.forEach(r);else{const a=Ie(e),c=a&&Po(i);if(a&&i==="length"){const d=Number(n);l.forEach((p,g)=>{(g==="length"||g===Pn||!Pt(g)&&g>=d)&&r(p)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Pn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Li)),Xi(e)&&r(l.get(mo)));break;case"delete":a||(r(l.get(Li)),Xi(e)&&r(l.get(mo)));break;case"set":Xi(e)&&r(l.get(Li));break}}No()}function Wi(e){const t=ze(e);return t===e?t:(ft(t,"iterate",Pn),At(e)?t:t.map(Ot))}function Bs(e){return ft(e=ze(e),"iterate",Pn),e}function Ht(e,t){return li(e)?sn(Pi(e)?Ot(t):t):Ot(t)}const cd={__proto__:null,[Symbol.iterator](){return qs(this,Symbol.iterator,e=>Ht(this,e))},concat(...e){return Wi(this).concat(...e.map(t=>Ie(t)?Wi(t):t))},entries(){return qs(this,"entries",e=>(e[1]=Ht(this,e[1]),e))},every(e,t){return Jt(this,"every",e,t,void 0,arguments)},filter(e,t){return Jt(this,"filter",e,t,i=>i.map(n=>Ht(this,n)),arguments)},find(e,t){return Jt(this,"find",e,t,i=>Ht(this,i),arguments)},findIndex(e,t){return Jt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Jt(this,"findLast",e,t,i=>Ht(this,i),arguments)},findLastIndex(e,t){return Jt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Jt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Zs(this,"includes",e)},indexOf(...e){return Zs(this,"indexOf",e)},join(e){return Wi(this).join(e)},lastIndexOf(...e){return Zs(this,"lastIndexOf",e)},map(e,t){return Jt(this,"map",e,t,void 0,arguments)},pop(){return mn(this,"pop")},push(...e){return mn(this,"push",e)},reduce(e,...t){return pr(this,"reduce",e,t)},reduceRight(e,...t){return pr(this,"reduceRight",e,t)},shift(){return mn(this,"shift")},some(e,t){return Jt(this,"some",e,t,void 0,arguments)},splice(...e){return mn(this,"splice",e)},toReversed(){return Wi(this).toReversed()},toSorted(e){return Wi(this).toSorted(e)},toSpliced(...e){return Wi(this).toSpliced(...e)},unshift(...e){return mn(this,"unshift",e)},values(){return qs(this,"values",e=>Ht(this,e))}};function qs(e,t,i){const n=Bs(e),s=n[t]();return n!==e&&!At(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const dd=Array.prototype;function Jt(e,t,i,n,s,o){const l=Bs(e),r=l!==e&&!At(e),a=l[t];if(a!==dd[t]){const p=a.apply(e,o);return r?Ot(p):p}let c=i;l!==e&&(r?c=function(p,g){return i.call(this,Ht(e,p),g,e)}:i.length>2&&(c=function(p,g){return i.call(this,p,g,e)}));const d=a.call(l,c,n);return r&&s?s(d):d}function pr(e,t,i,n){const s=Bs(e),o=s!==e&&!At(e);let l=i,r=!1;s!==e&&(o?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=Ht(e,c)),i.call(this,c,Ht(e,d),p,e)}):i.length>3&&(l=function(c,d,p){return i.call(this,c,d,p,e)}));const a=s[t](l,...n);return r?Ht(e,a):a}function Zs(e,t,i){const n=ze(e);ft(n,"iterate",Pn);const s=n[t](...i);return(s===-1||s===!1)&&Wo(i[0])?(i[0]=ze(i[0]),n[t](...i)):s}function mn(e,t,i=[]){oi(),Ro();const n=ze(e)[t].apply(e,i);return No(),ri(),n}const ud=Do("__proto__,__v_isRef,__isVue"),Il=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Pt));function fd(e){Pt(e)||(e=String(e));const t=ze(this);return ft(t,"has",e),t.hasOwnProperty(e)}class Tl{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?xd:Ml:o?Bl:Al).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Ie(t);if(!s){let a;if(l&&(a=cd[i]))return a;if(i==="hasOwnProperty")return fd}const r=Reflect.get(t,i,Ye(t)?t:n);if((Pt(i)?Il.has(i):ud(i))||(s||ft(t,"get",i),o))return r;if(Ye(r)){const a=l&&Po(i)?r:r.value;return s&&Ue(a)?vo(a):a}return Ue(r)?s?vo(r):Ms(r):r}}class El extends Tl{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const l=Ie(t)&&Po(i);if(!this._isShallow){const c=li(o);if(!At(n)&&!li(n)&&(o=ze(o),n=ze(n)),!l&&Ye(o)&&!Ye(n))return c||(o.value=n),!0}const r=l?Number(i)<t.length:Fe(t,i),a=Reflect.set(t,i,n,Ye(t)?t:s);return t===ze(s)&&a&&(r?Wt(n,o)&&ei(t,"set",i,n):ei(t,"add",i,n)),a}deleteProperty(t,i){const n=Fe(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ei(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Pt(i)||!Il.has(i))&&ft(t,"has",i),n}ownKeys(t){return ft(t,"iterate",Ie(t)?"length":Li),Reflect.ownKeys(t)}}class pd extends Tl{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const hd=new El,md=new pd,gd=new El(!0);const go=e=>e,Gn=e=>Reflect.getPrototypeOf(e);function vd(e,t,i){return function(...n){const s=this.__v_raw,o=ze(s),l=Xi(o),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=s[e](...n),d=i?go:t?sn:Ot;return!t&&ft(o,"iterate",a?mo:Li),ct(Object.create(c),{next(){const{value:p,done:g}=c.next();return g?{value:p,done:g}:{value:r?[d(p[0]),d(p[1])]:d(p),done:g}}})}}function qn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function bd(e,t){const i={get(s){const o=this.__v_raw,l=ze(o),r=ze(s);e||(Wt(s,r)&&ft(l,"get",s),ft(l,"get",r));const{has:a}=Gn(l),c=t?go:e?sn:Ot;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!e&&ft(ze(s),"iterate",Li),s.size},has(s){const o=this.__v_raw,l=ze(o),r=ze(s);return e||(Wt(s,r)&&ft(l,"has",s),ft(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=ze(r),c=t?go:e?sn:Ot;return!e&&ft(a,"iterate",Li),r.forEach((d,p)=>s.call(o,c(d),c(p),l))}};return ct(i,e?{add:qn("add"),set:qn("set"),delete:qn("delete"),clear:qn("clear")}:{add(s){const o=ze(this),l=Gn(o),r=ze(s),a=!t&&!At(s)&&!li(s)?r:s;return l.has.call(o,a)||Wt(s,a)&&l.has.call(o,s)||Wt(r,a)&&l.has.call(o,r)||(o.add(a),ei(o,"add",a,a)),this},set(s,o){!t&&!At(o)&&!li(o)&&(o=ze(o));const l=ze(this),{has:r,get:a}=Gn(l);let c=r.call(l,s);c||(s=ze(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Wt(o,d)&&ei(l,"set",s,o):ei(l,"add",s,o),this},delete(s){const o=ze(this),{has:l,get:r}=Gn(o);let a=l.call(o,s);a||(s=ze(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&ei(o,"delete",s,void 0),c},clear(){const s=ze(this),o=s.size!==0,l=s.clear();return o&&ei(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=vd(s,e,t)}),i}function Ho(e,t){const i=bd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(Fe(i,s)&&s in n?i:n,s,o)}const yd={get:Ho(!1,!1)},kd={get:Ho(!1,!0)},wd={get:Ho(!0,!1)};const Al=new WeakMap,Bl=new WeakMap,Ml=new WeakMap,xd=new WeakMap;function Sd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ms(e){return li(e)?e:jo(e,!1,hd,yd,Al)}function _d(e){return jo(e,!1,gd,kd,Bl)}function vo(e){return jo(e,!0,md,wd,Ml)}function jo(e,t,i,n,s){if(!Ue(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const l=Sd(Zc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return s.set(e,r),r}function Pi(e){return li(e)?Pi(e.__v_raw):!!(e&&e.__v_isReactive)}function li(e){return!!(e&&e.__v_isReadonly)}function At(e){return!!(e&&e.__v_isShallow)}function Wo(e){return e?!!e.__v_raw:!1}function ze(e){const t=e&&e.__v_raw;return t?ze(t):e}function Cd(e){return!Fe(e,"__v_skip")&&Object.isExtensible(e)&&ml(e,"__v_skip",!0),e}const Ot=e=>Ue(e)?Ms(e):e,sn=e=>Ue(e)?vo(e):e;function Ye(e){return e?e.__v_isRef===!0:!1}function he(e){return $d(e,!1)}function $d(e,t){return Ye(e)?e:new Id(e,t)}class Id{constructor(t,i){this.dep=new Fo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:ze(t),this._value=i?t:Ot(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||At(t)||li(t);t=n?t:ze(t),Wt(t,i)&&(this._rawValue=t,this._value=n?t:Ot(t),this.dep.trigger())}}function be(e){return Ye(e)?e.value:e}const Td={get:(e,t,i)=>t==="__v_raw"?e:be(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return Ye(s)&&!Ye(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Dl(e){return Pi(e)?e:new Proxy(e,Td)}class Ed{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Fo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Ln-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ge!==this)return wl(this,!0),!0}get value(){const t=this.dep.track();return _l(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Ad(e,t,i=!1){let n,s;return Ae(e)?n=e:(n=e.get,s=e.set),new Ed(n,s,i)}const Zn={},ms=new WeakMap;let Ti;function Bd(e,t=!1,i=Ti){if(i){let n=ms.get(i);n||ms.set(i,n=[]),n.push(e)}}function Md(e,t,i=Ve){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=i,c=M=>s?M:At(M)||s===!1||s===0?ti(M,1):ti(M);let d,p,g,u,m=!1,h=!1;if(Ye(e)?(p=()=>e.value,m=At(e)):Pi(e)?(p=()=>c(e),m=!0):Ie(e)?(h=!0,m=e.some(M=>Pi(M)||At(M)),p=()=>e.map(M=>{if(Ye(M))return M.value;if(Pi(M))return c(M);if(Ae(M))return a?a(M,2):M()})):Ae(e)?t?p=a?()=>a(e,2):e:p=()=>{if(g){oi();try{g()}finally{ri()}}const M=Ti;Ti=d;try{return a?a(e,3,[u]):e(u)}finally{Ti=M}}:p=Gt,t&&s){const M=p,B=s===!0?1/0:s;p=()=>ti(M(),B)}const b=rd(),y=()=>{d.stop(),b&&b.active&&Lo(b.effects,d)};if(o&&t){const M=t;t=(...B)=>{const I=M(...B);return y(),I}}let x=h?new Array(e.length).fill(Zn):Zn;const C=M=>{if(!(!(d.flags&1)||!d.dirty&&!M))if(t){const B=d.run();if(M||s||m||(h?B.some((I,w)=>Wt(I,x[w])):Wt(B,x))){g&&g();const I=Ti;Ti=d;try{const w=[B,x===Zn?void 0:h&&x[0]===Zn?[]:x,u];x=B,a?a(t,3,w):t(...w)}finally{Ti=I}}}else d.run()};return r&&r(C),d=new yl(p),d.scheduler=l?()=>l(C,!1):C,u=M=>Bd(M,!1,d),g=d.onStop=()=>{const M=ms.get(d);if(M){if(a)a(M,4);else for(const B of M)B();ms.delete(d)}},t?n?C(!0):x=d.run():l?l(C.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function ti(e,t=1/0,i){if(t<=0||!Ue(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ye(e))ti(e.value,t,i);else if(Ie(e))for(let n=0;n<e.length;n++)ti(e[n],t,i);else if(an(e)||Xi(e))e.forEach(n=>{ti(n,t,i)});else if(hl(e)){for(const n in e)ti(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ti(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function jn(e,t,i,n){try{return n?e(...n):e()}catch(s){Ds(s,t,i)}}function Rt(e,t,i,n){if(Ae(e)){const s=jn(e,t,i,n);return s&&fl(s)&&s.catch(o=>{Ds(o,t,i)}),s}if(Ie(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Rt(e[o],t,i,n));return s}}function Ds(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ve;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(o){oi(),jn(o,null,10,[e,a,c]),ri();return}}Dd(e,i,s,n,l)}function Dd(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const bt=[];let Ft=-1;const Qi=[];let hi=null,Ui=0;const Ll=Promise.resolve();let gs=null;function vs(e){const t=gs||Ll;return e?t.then(this?e.bind(this):e):t}function Ld(e){let t=Ft+1,i=bt.length;for(;t<i;){const n=t+i>>>1,s=bt[n],o=On(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function Uo(e){if(!(e.flags&1)){const t=On(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=On(i)?bt.push(e):bt.splice(Ld(t),0,e),e.flags|=1,Pl()}}function Pl(){gs||(gs=Ll.then(Rl))}function Pd(e){Ie(e)?Qi.push(...e):hi&&e.id===-1?hi.splice(Ui+1,0,e):e.flags&1||(Qi.push(e),e.flags|=1),Pl()}function hr(e,t,i=Ft+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Ol(e){if(Qi.length){const t=[...new Set(Qi)].sort((i,n)=>On(i)-On(n));if(Qi.length=0,hi){hi.push(...t);return}for(hi=t,Ui=0;Ui<hi.length;Ui++){const i=hi[Ui];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}hi=null,Ui=0}}const On=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Rl(e){try{for(Ft=0;Ft<bt.length;Ft++){const t=bt[Ft];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ft<bt.length;Ft++){const t=bt[Ft];t&&(t.flags&=-2)}Ft=-1,bt.length=0,Ol(),gs=null,(bt.length||Qi.length)&&Rl()}}let at=null,Nl=null;function bs(e){const t=at;return at=e,Nl=e&&e.type.__scopeId||null,t}function zl(e,t=at,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&$r(-1);const o=bs(t),l=ni.length;let r;try{r=e(...s)}finally{for(let a=ni.length;a>l;a--)Zo();bs(o),n._d&&$r(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Bt(e,t){if(at===null)return e;const i=Ns(at),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,l,r,a=Ve]=t[s];o&&(Ae(o)&&(o={mounted:o,updated:o}),o.deep&&ti(l),n.push({dir:o,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Si(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(oi(),Rt(a,i,8,[e.el,r,e,t]),ri())}}function Od(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function Lt(e,t,i=!1){const n=Lu();if(n||tn){let s=tn?tn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Ae(t)?t.call(n&&n.proxy):t}}const Rd=Symbol.for("v-scx"),Nd=()=>Lt(Rd);function Oi(e,t,i){return Fl(e,t,i)}function Fl(e,t,i=Ve){const{immediate:n,deep:s,flush:o,once:l}=i,r=ct({},i),a=t&&n||!t&&o!=="post";let c;if(Nn){if(o==="sync"){const u=Nd();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Gt,u.resume=Gt,u.pause=Gt,u}}const d=ht;r.call=(u,m,h)=>Rt(u,d,m,h);let p=!1;o==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:o!=="sync"&&(p=!0,r.scheduler=(u,m)=>{m?u():Uo(u)}),r.augmentJob=u=>{t&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Md(e,t,r);return Nn&&(c?c.push(g):a&&g()),g}function zd(e,t,i){const n=this.proxy,s=Qe(e)?e.includes(".")?Hl(n,e):()=>n[e]:e.bind(n,n);let o;Ae(t)?o=t:(o=t.handler,i=t);const l=Wn(this),r=Fl(s,o.bind(n),i);return l(),r}function Hl(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const Fd=Symbol("_vte"),Hd=e=>e.__isTeleport,Ys=Symbol("_leaveCb");function Vo(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Vo(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function It(e,t){return Ae(e)?ct({name:e.name},t,{setup:e}):e}function jl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function mr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const ys=new WeakMap;function _n(e,t,i,n,s=!1){if(Ie(e)){e.forEach((h,b)=>_n(h,t&&(Ie(t)?t[b]:t),i,n,s));return}if(en(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&_n(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Ns(n.component):n.el,l=s?null:o,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ve?r.refs={}:r.refs,p=r.setupState,g=ze(p),u=p===Ve?ul:h=>mr(d,h)?!1:Fe(g,h),m=(h,b)=>!(b&&mr(d,b));if(c!=null&&c!==a){if(gr(t),Qe(c))d[c]=null,u(c)&&(p[c]=null);else if(Ye(c)){const h=t;m(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(Ae(a))jn(a,r,12,[l,d]);else{const h=Qe(a),b=Ye(a);if(h||b){const y=()=>{if(e.f){const x=h?u(a)?p[a]:d[a]:m()||!e.k?a.value:d[e.k];if(s)Ie(x)&&Lo(x,o);else if(Ie(x))x.includes(o)||x.push(o);else if(h)d[a]=[o],u(a)&&(p[a]=d[a]);else{const C=[o];m(a,e.k)&&(a.value=C),e.k&&(d[e.k]=C)}}else h?(d[a]=l,u(a)&&(p[a]=l)):b&&(m(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{y(),ys.delete(e)};x.id=-1,ys.set(e,x),xt(x,i)}else gr(e),y()}}}function gr(e){const t=ys.get(e);t&&(t.flags|=8,ys.delete(e))}As().requestIdleCallback;As().cancelIdleCallback;const en=e=>!!e.type.__asyncLoader,Wl=e=>e.type.__isKeepAlive;function jd(e,t){Ul(e,"a",t)}function Wd(e,t){Ul(e,"da",t)}function Ul(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ls(t,n,i),i){let s=i.parent;for(;s&&s.parent;)Wl(s.parent.vnode)&&Ud(n,t,i,s),s=s.parent}}function Ud(e,t,i,n){const s=Ls(t,e,n,!0);Ps(()=>{Lo(n[t],s)},i)}function Ls(e,t,i=ht,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...l)=>{oi();const r=Wn(i),a=Rt(t,i,e,l);return r(),ri(),a});return n?s.unshift(o):s.push(o),o}}const ci=e=>(t,i=ht)=>{(!Nn||e==="sp")&&Ls(e,(...n)=>t(...n),i)},Vd=ci("bm"),dn=ci("m"),Kd=ci("bu"),Gd=ci("u"),Ko=ci("bum"),Ps=ci("um"),qd=ci("sp"),Zd=ci("rtg"),Yd=ci("rtc");function Jd(e,t=ht){Ls("ec",e,t)}const Xd="components";function Qd(e,t){return tu(Xd,e,!0,t)||e}const eu=Symbol.for("v-ndc");function tu(e,t,i=!0,n=!1){const s=at||ht;if(s){const o=s.type;{const r=zu(o,!1);if(r&&(r===t||r===wt(t)||r===Ts(wt(t))))return o}const l=vr(s[e]||o[e],t)||vr(s.appContext[e],t);return!l&&n?o:l}}function vr(e,t){return e&&(e[t]||e[wt(t)]||e[Ts(wt(t))])}function kt(e,t,i,n){let s;const o=i,l=Ie(e);if(l||Qe(e)){const r=l&&Pi(e);let a=!1,c=!1;r&&(a=!At(e),c=li(e),e=Bs(e)),s=new Array(e.length);for(let d=0,p=e.length;d<p;d++)s[d]=t(a?c?sn(Ot(e[d])):Ot(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ue(e))if(e[Symbol.iterator])s=Array.from(e,(r,a)=>t(r,a,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=t(e[d],d,a,o)}}else s=[];return s}function Yn(e,t,i={},n,s,o){if(at.ce||at.parent&&en(at.parent)&&at.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),Q(),Vt(Ke,null,[re("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ni.length;Q();let a;try{const c=l&&Vl(l(i)),d=i.key||o||c&&c.key;a=Vt(Ke,{key:(d&&!Pt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ni.length;d>r;d--)Zo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Vl(e){return e.some(t=>Yo(t)?!(t.type===ai||t.type===Ke&&!Vl(t.children)):!0)?e:null}const bo=e=>e?ua(e)?Ns(e):bo(e.parent):null,Cn=ct(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>bo(e.parent),$root:e=>bo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Gl(e),$forceUpdate:e=>e.f||(e.f=()=>{Uo(e.update)}),$nextTick:e=>e.n||(e.n=vs.bind(e.proxy)),$watch:e=>zd.bind(e)}),Js=(e,t)=>e!==Ve&&!e.__isScriptSetup&&Fe(e,t),iu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const g=l[t];if(g!==void 0)switch(g){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(Js(n,t))return l[t]=1,n[t];if(s!==Ve&&Fe(s,t))return l[t]=2,s[t];if(Fe(o,t))return l[t]=3,o[t];if(i!==Ve&&Fe(i,t))return l[t]=4,i[t];yo&&(l[t]=0)}}const c=Cn[t];let d,p;if(c)return t==="$attrs"&&ft(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ve&&Fe(i,t))return l[t]=4,i[t];if(p=a.config.globalProperties,Fe(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return Js(s,t)?(s[t]=i,!0):n!==Ve&&Fe(n,t)?(n[t]=i,!0):Fe(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(i[r]||e!==Ve&&r[0]!=="$"&&Fe(e,r)||Js(t,r)||Fe(o,r)||Fe(n,r)||Fe(Cn,r)||Fe(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Fe(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function br(e){return Ie(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let yo=!0;function nu(e){const t=Gl(e),i=e.proxy,n=e.ctx;yo=!1,t.beforeCreate&&yr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:g,beforeUpdate:u,updated:m,activated:h,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:C,unmounted:M,render:B,renderTracked:I,renderTriggered:w,errorCaptured:N,serverPrefetch:R,expose:z,inheritAttrs:V,components:S,directives:F,filters:k}=t;if(c&&su(c,n,null),l)for(const E in l){const D=l[E];Ae(D)&&(n[E]=D.bind(i))}if(s){const E=s.call(i,i);Ue(E)&&(e.data=Ms(E))}if(yo=!0,o)for(const E in o){const D=o[E],O=Ae(D)?D.bind(i,i):Ae(D.get)?D.get.bind(i,i):Gt,J=!Ae(D)&&Ae(D.set)?D.set.bind(i):Gt,U=ke({get:O,set:J});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>U.value,set:K=>U.value=K})}if(r)for(const E in r)Kl(r[E],n,i,E);if(a){const E=Ae(a)?a.call(i):a;Reflect.ownKeys(E).forEach(D=>{Od(D,E[D])})}d&&yr(d,e,"c");function H(E,D){Ie(D)?D.forEach(O=>E(O.bind(i))):D&&E(D.bind(i))}if(H(Vd,p),H(dn,g),H(Kd,u),H(Gd,m),H(jd,h),H(Wd,b),H(Jd,N),H(Yd,I),H(Zd,w),H(Ko,x),H(Ps,M),H(qd,R),Ie(z))if(z.length){const E=e.exposed||(e.exposed={});z.forEach(D=>{Object.defineProperty(E,D,{get:()=>i[D],set:O=>i[D]=O,enumerable:!0})})}else e.exposed||(e.exposed={});B&&e.render===Gt&&(e.render=B),V!=null&&(e.inheritAttrs=V),S&&(e.components=S),F&&(e.directives=F),R&&jl(e)}function su(e,t,i=Gt){Ie(e)&&(e=ko(e));for(const n in e){const s=e[n];let o;Ue(s)?"default"in s?o=Lt(s.from||n,s.default,!0):o=Lt(s.from||n):o=Lt(s),Ye(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):t[n]=o}}function yr(e,t,i){Rt(Ie(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Kl(e,t,i,n){let s=n.includes(".")?Hl(i,n):()=>i[n];if(Qe(e)){const o=t[e];Ae(o)&&Oi(s,o)}else if(Ae(e))Oi(s,e.bind(i));else if(Ue(e))if(Ie(e))e.forEach(o=>Kl(o,t,i,n));else{const o=Ae(e.handler)?e.handler.bind(i):t[e.handler];Ae(o)&&Oi(s,o,e)}}function Gl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=e.appContext,r=o.get(t);let a;return r?a=r:!s.length&&!i&&!n?a=t:(a={},s.length&&s.forEach(c=>ks(a,c,l,!0)),ks(a,t,l)),Ue(t)&&o.set(t,a),a}function ks(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&ks(e,o,i,!0),s&&s.forEach(l=>ks(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=ou[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const ou={data:kr,props:wr,emits:wr,methods:bn,computed:bn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:bn,directives:bn,watch:lu,provide:kr,inject:ru};function kr(e,t){return t?e?function(){return ct(Ae(e)?e.call(this,this):e,Ae(t)?t.call(this,this):t)}:t:e}function ru(e,t){return bn(ko(e),ko(t))}function ko(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function bn(e,t){return e?ct(Object.create(null),e,t):t}function wr(e,t){return e?Ie(e)&&Ie(t)?[...new Set([...e,...t])]:ct(Object.create(null),br(e),br(t??{})):t}function lu(e,t){if(!e)return t;if(!t)return e;const i=ct(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function ql(){return{app:null,config:{isNativeTag:ul,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let au=0;function cu(e,t){return function(n,s=null){Ae(n)||(n=ct({},n)),s!=null&&!Ue(s)&&(s=null);const o=ql(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:au++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:Hu,get config(){return o.config},set config(d){},use(d,...p){return l.has(d)||(d&&Ae(d.install)?(l.add(d),d.install(c,...p)):Ae(d)&&(l.add(d),d(c,...p))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,p){return p?(o.components[d]=p,c):o.components[d]},directive(d,p){return p?(o.directives[d]=p,c):o.directives[d]},mount(d,p,g){if(!a){const u=c._ceVNode||re(n,s);return u.appContext=o,g===!0?g="svg":g===!1&&(g=void 0),e(u,d,g),a=!0,c._container=d,d.__vue_app__=c,Ns(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Rt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return o.provides[d]=p,c},runWithContext(d){const p=tn;tn=c;try{return d()}finally{tn=p}}};return c}}let tn=null;const du=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${wi(t)}Modifiers`];function uu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ve;let s=i;const o=t.startsWith("update:"),l=o&&du(n,t.slice(7));l&&(l.trim&&(s=i.map(d=>Qe(d)?d.trim():d)),l.number&&(s=i.map(Es)));let r,a=n[r=Vs(t)]||n[r=Vs(wt(t))];!a&&o&&(a=n[r=Vs(wi(t))]),a&&Rt(a,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Rt(c,e,6,s)}}const fu=new WeakMap;function Zl(e,t,i=!1){const n=i?fu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let l={},r=!1;if(!Ae(e)){const a=c=>{const d=Zl(c,t,!0);d&&(r=!0,ct(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!o&&!r?(Ue(e)&&n.set(e,null),null):(Ie(o)?o.forEach(a=>l[a]=null):ct(l,o),Ue(e)&&n.set(e,l),l)}function Os(e,t){return!e||!Cs(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Fe(e,t[0].toLowerCase()+t.slice(1))||Fe(e,wi(t))||Fe(e,t))}function xr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:g,setupState:u,ctx:m,inheritAttrs:h}=e,b=bs(e);let y,x;try{if(i.shapeFlag&4){const M=s||n,B=M;y=jt(c.call(B,M,d,p,u,g,m)),x=r}else{const M=t;y=jt(M.length>1?M(p,{attrs:r,slots:l,emit:a}):M(p,null)),x=t.props?r:pu(r)}}catch(M){ni.length=0,Ds(M,e,1),y=re(ai)}let C=y;if(x&&h!==!1){const M=Object.keys(x),{shapeFlag:B}=C;M.length&&B&7&&(o&&M.some($s)&&(x=hu(x,o)),C=on(C,x,!1,!0))}return i.dirs&&(C=on(C,null,!1,!0),C.dirs=C.dirs?C.dirs.concat(i.dirs):i.dirs),i.transition&&Vo(C,i.transition),y=C,bs(b),y}const pu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Cs(i))&&((t||(t={}))[i]=e[i]);return t},hu=(e,t)=>{const i={};for(const n in e)(!$s(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function mu(e,t,i){const{props:n,children:s,component:o}=e,{props:l,children:r,patchFlag:a}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?Sr(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const g=d[p];if(Yl(l,n,g)&&!Os(c,g))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?Sr(n,l,c):!0:!!l;return!1}function Sr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(Yl(t,e,o)&&!Os(i,o))return!0}return!1}function Yl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ue(n)&&Ue(s)?!cn(n,s):n!==s}function gu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Jl={},Xl=()=>Object.create(Jl),Ql=e=>Object.getPrototypeOf(e)===Jl;function vu(e,t,i,n=!1){const s={},o=Xl();e.propsDefaults=Object.create(null),ea(e,t,s,o);for(const l in e.propsOptions[0])l in s||(s[l]=void 0);i?e.props=n?s:_d(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function bu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=e,r=ze(s),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let g=d[p];if(Os(e.emitsOptions,g))continue;const u=t[g];if(a)if(Fe(o,g))u!==o[g]&&(o[g]=u,c=!0);else{const m=wt(g);s[m]=wo(a,r,m,u,e,!1)}else u!==o[g]&&(o[g]=u,c=!0)}}}else{ea(e,t,s,o)&&(c=!0);let d;for(const p in r)(!t||!Fe(t,p)&&((d=wi(p))===p||!Fe(t,d)))&&(a?i&&(i[p]!==void 0||i[d]!==void 0)&&(s[p]=wo(a,r,p,void 0,e,!0)):delete s[p]);if(o!==r)for(const p in o)(!t||!Fe(t,p))&&(delete o[p],c=!0)}c&&ei(e.attrs,"set","")}function ea(e,t,i,n){const[s,o]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(wn(a))continue;const c=t[a];let d;s&&Fe(s,d=wt(a))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Os(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=ze(i),c=r||Ve;for(let d=0;d<o.length;d++){const p=o[d];i[p]=wo(s,a,p,c[p],e,!Fe(c,p))}}return l}function wo(e,t,i,n,s,o){const l=e[i];if(l!=null){const r=Fe(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ae(a)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Wn(s);n=c[i]=a.call(null,t),d()}}else n=a;s.ce&&s.ce._setProp(i,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===wi(i))&&(n=!0))}return n}const yu=new WeakMap;function ta(e,t,i=!1){const n=i?yu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,l={},r=[];let a=!1;if(!Ae(e)){const d=p=>{a=!0;const[g,u]=ta(p,t,!0);ct(l,g),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!a)return Ue(e)&&n.set(e,Ji),Ji;if(Ie(o))for(let d=0;d<o.length;d++){const p=wt(o[d]);_r(p)&&(l[p]=Ve)}else if(o)for(const d in o){const p=wt(d);if(_r(p)){const g=o[d],u=l[p]=Ie(g)||Ae(g)?{type:g}:ct({},g),m=u.type;let h=!1,b=!0;if(Ie(m))for(let y=0;y<m.length;++y){const x=m[y],C=Ae(x)&&x.name;if(C==="Boolean"){h=!0;break}else C==="String"&&(b=!1)}else h=Ae(m)&&m.name==="Boolean";u[0]=h,u[1]=b,(h||Fe(u,"default"))&&r.push(p)}}const c=[l,r];return Ue(e)&&n.set(e,c),c}function _r(e){return e[0]!=="$"&&!wn(e)}const Go=e=>e==="_"||e==="_ctx"||e==="$stable",qo=e=>Ie(e)?e.map(jt):[jt(e)],ku=(e,t,i)=>{if(t._n)return t;const n=zl((...s)=>qo(t(...s)),i);return n._c=!1,n},ia=(e,t,i)=>{const n=e._ctx;for(const s in e){if(Go(s))continue;const o=e[s];if(Ae(o))t[s]=ku(s,o,n);else if(o!=null){const l=qo(o);t[s]=()=>l}}},na=(e,t)=>{const i=qo(t);e.slots.default=()=>i},sa=(e,t,i)=>{for(const n in t)(i||!Go(n))&&(e[n]=t[n])},wu=(e,t,i)=>{const n=e.slots=Xl();if(e.vnode.shapeFlag&32){const s=t._;s?(sa(n,t,i),i&&ml(n,"_",s,!0)):ia(t,n)}else t&&na(e,t)},xu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,l=Ve;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:sa(s,t,i):(o=!t.$stable,ia(t,s)),l=t}else t&&(na(e,t),l={default:1});if(o)for(const r in s)!Go(r)&&l[r]==null&&delete s[r]},xt=Iu;function Su(e){return _u(e)}function _u(e,t){const i=As();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:g,setScopeId:u=Gt,insertStaticContent:m}=e,h=(P,j,v,W=null,T=null,_=null,$=void 0,L=null,Z=!!j.dynamicChildren)=>{if(P===j)return;P&&!gn(P,j)&&(W=Te(P),K(P,T,_,!0),P=null),j.patchFlag===-2&&(Z=!1,j.dynamicChildren=null);const{type:G,ref:q,shapeFlag:ee}=j;switch(G){case Rs:b(P,j,v,W);break;case ai:y(P,j,v,W);break;case is:P==null&&x(j,v,W,$);break;case Ke:S(P,j,v,W,T,_,$,L,Z);break;default:ee&1?B(P,j,v,W,T,_,$,L,Z):ee&6?F(P,j,v,W,T,_,$,L,Z):(ee&64||ee&128)&&G.process(P,j,v,W,T,_,$,L,Z,Y)}q!=null&&T?_n(q,P&&P.ref,_,j||P,!j):q==null&&P&&P.ref!=null&&_n(P.ref,null,_,P,!0)},b=(P,j,v,W)=>{if(P==null)n(j.el=r(j.children),v,W);else{const T=j.el=P.el;j.children!==P.children&&c(T,j.children)}},y=(P,j,v,W)=>{P==null?n(j.el=a(j.children||""),v,W):j.el=P.el},x=(P,j,v,W)=>{[P.el,P.anchor]=m(P.children,j,v,W,P.el,P.anchor)},C=({el:P,anchor:j},v,W)=>{let T;for(;P&&P!==j;)T=g(P),n(P,v,W),P=T;n(j,v,W)},M=({el:P,anchor:j})=>{let v;for(;P&&P!==j;)v=g(P),s(P),P=v;s(j)},B=(P,j,v,W,T,_,$,L,Z)=>{if(j.type==="svg"?$="svg":j.type==="math"&&($="mathml"),P==null)I(j,v,W,T,_,$,L,Z);else{const G=P.el&&P.el._isVueCE?P.el:null;try{G&&G._beginPatch(),R(P,j,T,_,$,L,Z)}finally{G&&G._endPatch()}}},I=(P,j,v,W,T,_,$,L)=>{let Z,G;const{props:q,shapeFlag:ee,transition:le,dirs:oe}=P;if(Z=P.el=l(P.type,_,q&&q.is,q),ee&8?d(Z,P.children):ee&16&&N(P.children,Z,null,W,T,Xs(P,_),$,L),oe&&Si(P,null,W,"created"),w(Z,P,P.scopeId,$,W),q){for(const ie in q)ie!=="value"&&!wn(ie)&&o(Z,ie,null,q[ie],_,W);"value"in q&&o(Z,"value",null,q.value,_),(G=q.onVnodeBeforeMount)&&zt(G,W,P)}oe&&Si(P,null,W,"beforeMount");const pe=Cu(T,le);pe&&le.beforeEnter(Z),n(Z,j,v),((G=q&&q.onVnodeMounted)||pe||oe)&&xt(()=>{try{G&&zt(G,W,P),pe&&le.enter(Z),oe&&Si(P,null,W,"mounted")}finally{}},T)},w=(P,j,v,W,T)=>{if(v&&u(P,v),W)for(let _=0;_<W.length;_++)u(P,W[_]);if(T){let _=T.subTree;if(j===_||aa(_.type)&&(_.ssContent===j||_.ssFallback===j)){const $=T.vnode;w(P,$,$.scopeId,$.slotScopeIds,T.parent)}}},N=(P,j,v,W,T,_,$,L,Z=0)=>{for(let G=Z;G<P.length;G++){const q=P[G]=L?Qt(P[G]):jt(P[G]);h(null,q,j,v,W,T,_,$,L)}},R=(P,j,v,W,T,_,$)=>{const L=j.el=P.el;let{patchFlag:Z,dynamicChildren:G,dirs:q}=j;Z|=P.patchFlag&16;const ee=P.props||Ve,le=j.props||Ve;let oe;if(v&&_i(v,!1),(oe=le.onVnodeBeforeUpdate)&&zt(oe,v,j,P),q&&Si(j,P,v,"beforeUpdate"),v&&_i(v,!0),G&&(!P.dynamicChildren||P.dynamicChildren.length!==G.length)&&(Z=0,$=!1,G=null),(ee.innerHTML&&le.innerHTML==null||ee.textContent&&le.textContent==null)&&d(L,""),G?z(P.dynamicChildren,G,L,v,W,Xs(j,T),_):$||D(P,j,L,null,v,W,Xs(j,T),_,!1),Z>0){if(Z&16)V(L,ee,le,v,T);else if(Z&2&&ee.class!==le.class&&o(L,"class",null,le.class,T),Z&4&&o(L,"style",ee.style,le.style,T),Z&8){const pe=j.dynamicProps;for(let ie=0;ie<pe.length;ie++){const ne=pe[ie],Ce=ee[ne],Be=le[ne];(Be!==Ce||ne==="value")&&o(L,ne,Ce,Be,T,v)}}Z&1&&P.children!==j.children&&d(L,j.children)}else!$&&G==null&&V(L,ee,le,v,T);((oe=le.onVnodeUpdated)||q)&&xt(()=>{oe&&zt(oe,v,j,P),q&&Si(j,P,v,"updated")},W)},z=(P,j,v,W,T,_,$)=>{for(let L=0;L<j.length;L++){const Z=P[L],G=j[L],q=Z.el&&(Z.type===Ke||!gn(Z,G)||Z.shapeFlag&198)?p(Z.el):v;h(Z,G,q,null,W,T,_,$,!0)}},V=(P,j,v,W,T)=>{if(j!==v){if(j!==Ve)for(const _ in j)!wn(_)&&!(_ in v)&&o(P,_,j[_],null,T,W);for(const _ in v){if(wn(_))continue;const $=v[_],L=j[_];$!==L&&_!=="value"&&o(P,_,L,$,T,W)}"value"in v&&o(P,"value",j.value,v.value,T)}},S=(P,j,v,W,T,_,$,L,Z)=>{const G=j.el=P?P.el:r(""),q=j.anchor=P?P.anchor:r("");let{patchFlag:ee,dynamicChildren:le,slotScopeIds:oe}=j;oe&&(L=L?L.concat(oe):oe),P==null?(n(G,v,W),n(q,v,W),N(j.children||[],v,q,T,_,$,L,Z)):ee>0&&ee&64&&le&&P.dynamicChildren&&P.dynamicChildren.length===le.length?(z(P.dynamicChildren,le,v,T,_,$,L),(j.key!=null||T&&j===T.subTree)&&oa(P,j,!0)):D(P,j,v,q,T,_,$,L,Z)},F=(P,j,v,W,T,_,$,L,Z)=>{j.slotScopeIds=L,P==null?j.shapeFlag&512?T.ctx.activate(j,v,W,$,Z):k(j,v,W,T,_,$,Z):A(P,j,Z)},k=(P,j,v,W,T,_,$)=>{const L=P.component=Du(P,W,T);if(Wl(P)&&(L.ctx.renderer=Y),Pu(L,!1,$),L.asyncDep){if(T&&T.registerDep(L,H,$),!P.el){const Z=L.subTree=re(ai);y(null,Z,j,v),P.placeholder=Z.el}}else H(L,P,j,v,T,_,$)},A=(P,j,v)=>{const W=j.component=P.component;if(mu(P,j,v))if(W.asyncDep&&!W.asyncResolved){E(W,j,v);return}else W.next=j,W.update();else j.el=P.el,W.vnode=j},H=(P,j,v,W,T,_,$)=>{const L=()=>{if(P.isMounted){let{next:ee,bu:le,u:oe,parent:pe,vnode:ie}=P;{const Re=ra(P);if(Re){ee&&(ee.el=ie.el,E(P,ee,$)),Re.asyncDep.then(()=>{xt(()=>{P.isUnmounted||G()},T)});return}}let ne=ee,Ce;_i(P,!1),ee?(ee.el=ie.el,E(P,ee,$)):ee=ie,le&&ts(le),(Ce=ee.props&&ee.props.onVnodeBeforeUpdate)&&zt(Ce,pe,ee,ie),_i(P,!0);const Be=xr(P),Ne=P.subTree;P.subTree=Be,h(Ne,Be,p(Ne.el),Te(Ne),P,T,_),ee.el=Be.el,ne===null&&gu(P,Be.el),oe&&xt(oe,T),(Ce=ee.props&&ee.props.onVnodeUpdated)&&xt(()=>zt(Ce,pe,ee,ie),T)}else{let ee;const{el:le,props:oe}=j,{bm:pe,m:ie,parent:ne,root:Ce,type:Be}=P,Ne=en(j);_i(P,!1),pe&&ts(pe),!Ne&&(ee=oe&&oe.onVnodeBeforeMount)&&zt(ee,ne,j),_i(P,!0);{Ce.ce&&Ce.ce._hasShadowRoot()&&Ce.ce._injectChildStyle(Be,P.parent?P.parent.type:void 0);const Re=P.subTree=xr(P);h(null,Re,v,W,P,T,_),j.el=Re.el}if(ie&&xt(ie,T),!Ne&&(ee=oe&&oe.onVnodeMounted)){const Re=j;xt(()=>zt(ee,ne,Re),T)}(j.shapeFlag&256||ne&&en(ne.vnode)&&ne.vnode.shapeFlag&256)&&P.a&&xt(P.a,T),P.isMounted=!0,j=v=W=null}};P.scope.on();const Z=P.effect=new yl(L);P.scope.off();const G=P.update=Z.run.bind(Z),q=P.job=Z.runIfDirty.bind(Z);q.i=P,q.id=P.uid,Z.scheduler=()=>Uo(q),_i(P,!0),G()},E=(P,j,v)=>{j.component=P;const W=P.vnode.props;P.vnode=j,P.next=null,bu(P,j.props,W,v),xu(P,j.children,v),oi(),hr(P),ri()},D=(P,j,v,W,T,_,$,L,Z=!1)=>{const G=P&&P.children,q=P?P.shapeFlag:0,ee=j.children,{patchFlag:le,shapeFlag:oe}=j;if(le>0){if(le&128){J(G,ee,v,W,T,_,$,L,Z);return}else if(le&256){O(G,ee,v,W,T,_,$,L,Z);return}}oe&8?(q&16&&ge(G,T,_),ee!==G&&d(v,ee)):q&16?oe&16?J(G,ee,v,W,T,_,$,L,Z):ge(G,T,_,!0):(q&8&&d(v,""),oe&16&&N(ee,v,W,T,_,$,L,Z))},O=(P,j,v,W,T,_,$,L,Z)=>{P=P||Ji,j=j||Ji;const G=P.length,q=j.length,ee=Math.min(G,q);let le;for(le=0;le<ee;le++){const oe=j[le]=Z?Qt(j[le]):jt(j[le]);h(P[le],oe,v,null,T,_,$,L,Z)}G>q?ge(P,T,_,!0,!1,ee):N(j,v,W,T,_,$,L,Z,ee)},J=(P,j,v,W,T,_,$,L,Z)=>{let G=0;const q=j.length;let ee=P.length-1,le=q-1;for(;G<=ee&&G<=le;){const oe=P[G],pe=j[G]=Z?Qt(j[G]):jt(j[G]);if(gn(oe,pe))h(oe,pe,v,null,T,_,$,L,Z);else break;G++}for(;G<=ee&&G<=le;){const oe=P[ee],pe=j[le]=Z?Qt(j[le]):jt(j[le]);if(gn(oe,pe))h(oe,pe,v,null,T,_,$,L,Z);else break;ee--,le--}if(G>ee){if(G<=le){const oe=le+1,pe=oe<q?j[oe].el:W;for(;G<=le;)h(null,j[G]=Z?Qt(j[G]):jt(j[G]),v,pe,T,_,$,L,Z),G++}}else if(G>le)for(;G<=ee;)K(P[G],T,_,!0),G++;else{const oe=G,pe=G,ie=new Map;for(G=pe;G<=le;G++){const ot=j[G]=Z?Qt(j[G]):jt(j[G]);ot.key!=null&&ie.set(ot.key,G)}let ne,Ce=0;const Be=le-pe+1;let Ne=!1,Re=0;const De=new Array(Be);for(G=0;G<Be;G++)De[G]=0;for(G=oe;G<=ee;G++){const ot=P[G];if(Ce>=Be){K(ot,T,_,!0);continue}let Je;if(ot.key!=null)Je=ie.get(ot.key);else for(ne=pe;ne<=le;ne++)if(De[ne-pe]===0&&gn(ot,j[ne])){Je=ne;break}Je===void 0?K(ot,T,_,!0):(De[Je-pe]=G+1,Je>=Re?Re=Je:Ne=!0,h(ot,j[Je],v,null,T,_,$,L,Z),Ce++)}const Yt=Ne?$u(De):Ji;for(ne=Yt.length-1,G=Be-1;G>=0;G--){const ot=pe+G,Je=j[ot],Nt=j[ot+1],Fi=ot+1<q?Nt.el||la(Nt):W;De[G]===0?h(null,Je,v,Fi,T,_,$,L,Z):Ne&&(ne<0||G!==Yt[ne]?U(Je,v,Fi,2):ne--)}}},U=(P,j,v,W,T=null)=>{const{el:_,type:$,transition:L,children:Z,shapeFlag:G}=P;if(G&6){U(P.component.subTree,j,v,W);return}if(G&128){P.suspense.move(j,v,W);return}if(G&64){$.move(P,j,v,Y);return}if($===Ke){n(_,j,v);for(let ee=0;ee<Z.length;ee++)U(Z[ee],j,v,W);n(P.anchor,j,v);return}if($===is){C(P,j,v);return}if(W!==2&&G&1&&L)if(W===0)L.persisted&&!_[Ys]?n(_,j,v):(L.beforeEnter(_),n(_,j,v),xt(()=>L.enter(_),T));else{const{leave:ee,delayLeave:le,afterLeave:oe}=L,pe=()=>{P.ctx.isUnmounted?s(_):n(_,j,v)},ie=()=>{const ne=_._isLeaving||!!_[Ys];_._isLeaving&&_[Ys](!0),L.persisted&&!ne?pe():ee(_,()=>{pe(),oe&&oe()})};le?le(_,pe,ie):ie()}else n(_,j,v)},K=(P,j,v,W=!1,T=!1)=>{const{type:_,props:$,ref:L,children:Z,dynamicChildren:G,shapeFlag:q,patchFlag:ee,dirs:le,cacheIndex:oe,memo:pe}=P;if(ee===-2&&(T=!1),L!=null&&(oi(),_n(L,null,v,P,!0),ri()),oe!=null&&(j.renderCache[oe]=void 0),q&256){j.ctx.deactivate(P);return}const ie=q&1&&le,ne=!en(P);let Ce;if(ne&&(Ce=$&&$.onVnodeBeforeUnmount)&&zt(Ce,j,P),q&6)ce(P.component,v,W);else{if(q&128){P.suspense.unmount(v,W);return}ie&&Si(P,null,j,"beforeUnmount"),q&64?P.type.remove(P,j,v,Y,W):G&&!G.hasOnce&&(_!==Ke||ee>0&&ee&64)?ge(G,j,v,!1,!0):(_===Ke&&ee&384||!T&&q&16)&&ge(Z,j,v),W&&se(P)}const Be=pe!=null&&oe==null;(ne&&(Ce=$&&$.onVnodeUnmounted)||ie||Be)&&xt(()=>{Ce&&zt(Ce,j,P),ie&&Si(P,null,j,"unmounted"),Be&&(P.el=null)},v)},se=P=>{const{type:j,el:v,anchor:W,transition:T}=P;if(j===Ke){ae(v,W);return}if(j===is){M(P);return}const _=()=>{s(v),T&&!T.persisted&&T.afterLeave&&T.afterLeave()};if(P.shapeFlag&1&&T&&!T.persisted){const{leave:$,delayLeave:L}=T,Z=()=>$(v,_);L?L(P.el,_,Z):Z()}else _()},ae=(P,j)=>{let v;for(;P!==j;)v=g(P),s(P),P=v;s(j)},ce=(P,j,v)=>{const{bum:W,scope:T,job:_,subTree:$,um:L,m:Z,a:G}=P;Cr(Z),Cr(G),W&&ts(W),T.stop(),_&&(_.flags|=8,K($,P,j,v)),L&&xt(L,j),xt(()=>{P.isUnmounted=!0},j)},ge=(P,j,v,W=!1,T=!1,_=0)=>{for(let $=_;$<P.length;$++)K(P[$],j,v,W,T)},Te=P=>{if(P.shapeFlag&6)return Te(P.component.subTree);if(P.shapeFlag&128)return P.suspense.next();const j=g(P.anchor||P.el),v=j&&j[Fd];return v?g(v):j};let we=!1;const ue=(P,j,v)=>{let W;P==null?j._vnode&&(K(j._vnode,null,null,!0),W=j._vnode.component):h(j._vnode||null,P,j,null,null,null,v),j._vnode=P,we||(we=!0,hr(W),Ol(),we=!1)},Y={p:h,um:K,m:U,r:se,mt:k,mc:N,pc:D,pbc:z,n:Te,o:e};return{render:ue,hydrate:void 0,createApp:cu(ue)}}function Xs({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function _i({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Cu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function oa(e,t,i=!1){const n=e.children,s=t.children;if(Ie(n)&&Ie(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=Qt(s[o]),r.el=l.el),!i&&r.patchFlag!==-2&&oa(l,r)),r.type===Rs&&(r.patchFlag===-1&&(r=s[o]=Qt(r)),r.el=l.el),r.type===ai&&!r.el&&(r.el=l.el)}}function $u(e){const t=e.slice(),i=[0];let n,s,o,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,l=i.length-1;o<l;)r=o+l>>1,e[i[r]]<c?o=r+1:l=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,l=i[o-1];o-- >0;)i[o]=l,l=t[l];return i}function ra(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:ra(t)}function Cr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function la(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?la(t.subTree):null}const aa=e=>e.__isSuspense;function Iu(e,t){t&&t.pendingBranch?Ie(e)?t.effects.push(...e):t.effects.push(e):Pd(e)}const Ke=Symbol.for("v-fgt"),Rs=Symbol.for("v-txt"),ai=Symbol.for("v-cmt"),is=Symbol.for("v-stc"),ni=[];let $t=null;function Q(e=!1){ni.push($t=e?null:[])}function Zo(){ni.pop(),$t=ni[ni.length-1]||null}let Rn=1;function $r(e,t=!1){Rn+=e,e<0&&$t&&t&&($t.hasOnce=!0)}function ca(e){return e.dynamicChildren=Rn>0?$t||Ji:null,Zo(),Rn>0&&$t&&$t.push(e),e}function te(e,t,i,n,s,o){return ca(f(e,t,i,n,s,o,!0))}function Vt(e,t,i,n,s){return ca(re(e,t,i,n,s,!0))}function Yo(e){return e?e.__v_isVNode===!0:!1}function gn(e,t){return e.type===t.type&&e.key===t.key}const da=({key:e})=>e??null,ns=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?Qe(e)||Ye(e)||Ae(e)?{i:at,r:e,k:t,f:!!i}:e:null);function f(e,t=null,i=null,n=0,s=null,o=e===Ke?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&da(t),ref:t&&ns(t),scopeId:Nl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:at};return r?(ws(a,i),o&128&&e.normalize(a)):i&&(a.shapeFlag|=Qe(i)?8:16),Rn>0&&!l&&$t&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&$t.push(a),a}const re=Tu;function Tu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===eu)&&(e=ai),Yo(e)){const r=on(e,t,!0);return i&&ws(r,i),Rn>0&&!o&&$t&&(r.shapeFlag&6?$t[$t.indexOf(e)]=r:$t.push(r)),r.patchFlag=-2,r}if(Fu(e)&&(e=e.__vccOpts),t){t=Eu(t);let{class:r,style:a}=t;r&&!Qe(r)&&(t.class=_e(r)),Ue(a)&&(Wo(a)&&!Ie(a)&&(a=ct({},a)),t.style=Ut(a))}const l=Qe(e)?1:aa(e)?128:Hd(e)?64:Ue(e)?4:Ae(e)?2:0;return f(e,t,i,n,s,l,o,!0)}function Eu(e){return e?Wo(e)||Ql(e)?ct({},e):e:null}function on(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=e,c=t?Au(s||{},t):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&da(c),ref:t&&t.ref?i&&o?Ie(o)?o.concat(ns(t)):[o,ns(t)]:ns(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ke?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&on(e.ssContent),ssFallback:e.ssFallback&&on(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Vo(d,a.clone(d)),d}function St(e=" ",t=0){return re(Rs,null,e,t)}function gt(e,t){const i=re(is,null,e);return i.staticCount=t,i}function Le(e="",t=!1){return t?(Q(),Vt(ai,null,e)):re(ai,null,e)}function jt(e){return e==null||typeof e=="boolean"?re(ai):Ie(e)?re(Ke,null,e.slice()):Yo(e)?Qt(e):re(Rs,null,String(e))}function Qt(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:on(e)}function ws(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ie(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),ws(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!Ql(t)?t._ctx=at:s===3&&at&&(at.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ae(t)){if(n&65){ws(e,{default:t});return}t={default:t,_ctx:at},i=32}else t=String(t),n&64?(i=16,t=[St(t)]):i=8;e.children=t,e.shapeFlag|=i}function Au(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(s==="style")t.style=Ut([t.style,n.style]);else if(Cs(s)){const o=t[s],l=n[s];l&&o!==l&&!(Ie(o)&&o.includes(l))?t[s]=o?[].concat(o,l):l:l==null&&o==null&&!$s(s)&&(t[s]=l)}else s!==""&&(t[s]=n[s])}return t}function zt(e,t,i,n=null){Rt(e,t,7,[i,n])}const Bu=ql();let Mu=0;function Du(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Bu,o={uid:Mu++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new od(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ta(n,s),emitsOptions:Zl(n,s),emit:null,emitted:null,propsDefaults:Ve,inheritAttrs:n.inheritAttrs,ctx:Ve,data:Ve,props:Ve,attrs:Ve,slots:Ve,refs:Ve,setupState:Ve,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=uu.bind(null,o),e.ce&&e.ce(o),o}let ht=null;const Lu=()=>ht||at;let xs,xo;{const e=As(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};xs=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),xo=t("__VUE_SSR_SETTERS__",i=>Nn=i)}const Wn=e=>{const t=ht;return xs(e),e.scope.on(),()=>{e.scope.off(),xs(t)}},Ir=()=>{ht&&ht.scope.off(),xs(null)};function ua(e){return e.vnode.shapeFlag&4}let Nn=!1;function Pu(e,t=!1,i=!1){t&&xo(t);const{props:n,children:s}=e.vnode,o=ua(e);vu(e,n,o,t),wu(e,s,i||t);const l=o?Ou(e,t):void 0;return t&&xo(!1),l}function Ou(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,iu);const{setup:n}=i;if(n){oi();const s=e.setupContext=n.length>1?Nu(e):null,o=Wn(e),l=jn(n,e,0,[e.props,s]),r=fl(l);if(ri(),o(),(r||e.sp)&&!en(e)&&jl(e),r){if(l.then(Ir,Ir),t)return l.then(a=>{Tr(e,a)}).catch(a=>{Ds(a,e,0)});e.asyncDep=l}else Tr(e,l)}else fa(e)}function Tr(e,t,i){Ae(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ue(t)&&(e.setupState=Dl(t)),fa(e)}function fa(e,t,i){const n=e.type;e.render||(e.render=n.render||Gt);{const s=Wn(e);oi();try{nu(e)}finally{ri(),s()}}}const Ru={get(e,t){return ft(e,"get",""),e[t]}};function Nu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Ru),slots:e.slots,emit:e.emit,expose:t}}function Ns(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Dl(Cd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Cn)return Cn[i](e)},has(t,i){return i in t||i in Cn}})):e.proxy}function zu(e,t=!0){return Ae(e)?e.displayName||e.name:e.name||t&&e.__name}function Fu(e){return Ae(e)&&"__vccOpts"in e}const ke=(e,t)=>Ad(e,t,Nn),Hu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let So;const Er=typeof window<"u"&&window.trustedTypes;if(Er)try{So=Er.createPolicy("vue",{createHTML:e=>e})}catch{}const pa=So?e=>So.createHTML(e):e=>e,ju="http://www.w3.org/2000/svg",Wu="http://www.w3.org/1998/Math/MathML",Xt=typeof document<"u"?document:null,Ar=Xt&&Xt.createElement("template"),Uu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?Xt.createElementNS(ju,e):t==="mathml"?Xt.createElementNS(Wu,e):i?Xt.createElement(e,{is:i}):Xt.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>Xt.createTextNode(e),createComment:e=>Xt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Xt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const l=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Ar.innerHTML=pa(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Ar.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Vu=Symbol("_vtc");function Ku(e,t,i){const n=e[Vu];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ss=Symbol("_vod"),ha=Symbol("_vsh"),_o={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ss]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):vn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),vn(e,!0),n.enter(e)):n.leave(e,()=>{vn(e,!1)}):vn(e,t))},beforeUnmount(e,{value:t}){vn(e,t)}};function vn(e,t){e.style.display=t?e[Ss]:"none",e[ha]=!t}const Gu=Symbol(""),qu=/(?:^|;)\s*display\s*:/;function Zu(e,t,i){const n=e.style,s=Qe(i);let o=!1;if(i&&!s){if(t)if(Qe(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&yn(n,r,"")}else for(const l in t)i[l]==null&&yn(n,l,"");for(const l in i){l==="display"&&(o=!0);const r=i[l];r!=null?Ju(e,l,!Qe(t)&&t?t[l]:void 0,r)||yn(n,l,r):yn(n,l,"")}}else if(s){if(t!==i){const l=n[Gu];l&&(i+=";"+l),n.cssText=i,o=qu.test(i)}}else t&&e.removeAttribute("style");Ss in e&&(e[Ss]=o?n.display:"",e[ha]&&(n.display="none"))}const Br=/\s*!important$/;function yn(e,t,i){if(Ie(i))i.forEach(n=>yn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Yu(e,t);Br.test(i)?e.setProperty(wi(n),i.replace(Br,""),"important"):e[n]=i}}const Mr=["Webkit","Moz","ms"],Qs={};function Yu(e,t){const i=Qs[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return Qs[t]=n;n=Ts(n);for(let s=0;s<Mr.length;s++){const o=Mr[s]+n;if(o in e)return Qs[t]=o}return t}function Ju(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&Qe(n)&&i===n}const Dr="http://www.w3.org/1999/xlink";function Lr(e,t,i,n,s,o=nd(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Dr,t.slice(6,t.length)):e.setAttributeNS(Dr,t,i):i==null||o&&!gl(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Pt(i)?String(i):i)}function Pr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?pa(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=gl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(s||t)}function mi(e,t,i,n){e.addEventListener(t,i,n)}function Xu(e,t,i,n){e.removeEventListener(t,i,n)}const Or=Symbol("_vei");function Qu(e,t,i,n,s=null){const o=e[Or]||(e[Or]={}),l=o[t];if(n&&l)l.value=n;else{const[r,a]=nf(t);if(n){const c=o[t]=rf(n,s);mi(e,r,c,a)}else l&&(Xu(e,r,l,a),o[t]=void 0)}}const ef=/(Once|Passive|Capture)$/,tf=/^on:?(?:Once|Passive|Capture)$/;function nf(e){let t,i;for(;(i=e.match(ef))&&!tf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):wi(e.slice(2)),t]}let eo=0;const sf=Promise.resolve(),of=()=>eo||(sf.then(()=>eo=0),eo=Date.now());function rf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ie(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Rt(c,t,5,r)}}else Rt(s,t,5,[n])};return i.value=e,i.attached=of(),i}const Rr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,lf=(e,t,i,n,s,o)=>{const l=s==="svg";t==="class"?Ku(e,n,l):t==="style"?Zu(e,i,n):Cs(t)?$s(t)||Qu(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):af(e,t,n,l))?(Pr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Lr(e,t,n,l,o,t!=="value")):e._isVueCE&&(cf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!Qe(n)))?Pr(e,wt(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Lr(e,t,n,l))};function af(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Rr(t)&&Ae(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Rr(t)&&Qe(i)?!1:t in e}function cf(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(s=>wt(s)===n):Object.keys(i).some(s=>wt(s)===n)}const rn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ie(t)?i=>ts(t,i):t};function df(e){e.target.composing=!0}function Nr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const si=Symbol("_assign");function zr(e,t,i){return t&&(e=e.trim()),i&&(e=Es(e)),e}const Co={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[si]=rn(s);const o=n||s.props&&s.props.type==="number";mi(e,t?"change":"input",l=>{l.target.composing||e[si](zr(e.value,i,o))}),(i||o)&&mi(e,"change",()=>{e.value=zr(e.value,i,o)}),t||(mi(e,"compositionstart",df),mi(e,"compositionend",Nr),mi(e,"change",Nr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},l){if(e[si]=rn(l),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Es(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===a)||(e.value=a)}},Jn={deep:!0,created(e,t,i){e[si]=rn(i),mi(e,"change",()=>{const n=e._modelValue,s=zn(e),o=e.checked,l=e[si];if(Ie(n)){const r=Oo(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(an(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(ma(e,o))})},mounted:Fr,beforeUpdate(e,t,i){e[si]=rn(i),Fr(e,t,i)}};function Fr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ie(t))s=Oo(t,n.props.value)>-1;else if(an(t))s=t.has(n.props.value);else{if(t===i)return;s=cn(t,ma(e,!0))}e.checked!==s&&(e.checked=s)}const uf={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,mi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Es(zn(o)):zn(o));e[si](e.multiple?an(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,vs(()=>{e._assigning=!1})}),e[si]=rn(n)},mounted(e,{value:t}){Hr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[si]=rn(i)},updated(e,{value:t}){e._assigning||Hr(e,t)}};function Hr(e,t){const i=e.multiple,n=Ie(t);if(!(i&&!n&&!an(t))){for(let s=0,o=e.options.length;s<o;s++){const l=e.options[s],r=zn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Oo(t,r)>-1}else l.selected=t.has(r);else if(cn(zn(l),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function zn(e){return"_value"in e?e._value:e.value}function ma(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const ff=["ctrl","shift","alt","meta"],pf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>ff.some(i=>e[`${i}Key`]&&!t.includes(i))},ii=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let l=0;l<t.length;l++){const r=pf[t[l]];if(r&&r(s,t))return}return e(s,...o)}))},hf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},mf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=wi(s.key);if(t.some(l=>l===o||hf[l]===o))return e(s)}))},gf=ct({patchProp:lf},Uu);let jr;function vf(){return jr||(jr=Su(gf))}const Jo=((...e)=>{const t=vf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=yf(n);if(!s)return;const o=t._component;!Ae(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=i(s,!1,bf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},t});function bf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function yf(e){return Qe(e)?document.querySelector(e):e}const kf="slidev-config.json",ln={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},gi=Ms({...ln});function wf(e){if(!e||typeof e!="object")return{...ln};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():ln.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Mi(e){if(!e||typeof e!="object")return{...gi};const t=e;return t.enableWebServeJump!==void 0&&(gi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(gi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(gi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...gi}}function zs(){return{...gi}}function ga(e,t,i){const n=(e||ln.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${o}`}}const Ci={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function xf(e){var i,n,s,o,l,r;const t=zs();return e?{theme:((i=e[En])==null?void 0:i.trim())||Ci.theme,aspectRatio:((n=e[An])==null?void 0:n.trim())||Ci.aspectRatio,highlighter:((s=e[rl])==null?void 0:s.trim())||Ci.highlighter,defaultTransition:((o=e[Bn])==null?void 0:o.trim())||Ci.defaultTransition,colorSchema:((l=e[ll])==null?void 0:l.trim())||Ci.colorSchema,spacing:((r=e[fo])==null?void 0:r.trim())||Ci.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Ci,normalizeHeadingSizes:t.normalizeHeadingSizes}}function _s(e){var i,n,s,o,l;const t=(i=e.ial)==null?void 0:i[Ei];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Wr(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ye]&&(t.layout=e[ye].trim()),e[pt]&&(t.transition=e[pt].trim()),e[et]&&(t.background=e[et].trim()),e[Mt]&&(t.image=e[Mt].trim()),e[Ki]&&(t.class=e[Ki].trim()),e[kn]&&(t.spacing=e[kn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[Gi]&&(t.mask=e[Gi].trim()),e[qi]&&(t.maskRatio=e[qi].trim()),e[Zi]&&(t.maskStyle=e[Zi].trim()),e[Yi]&&(t.maskInitial=e[Yi].trim()),e[Us]&&(i=e[Us].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![ye,yt,Gi,qi,Zi,Yi,pt,et,Mt,Ki,kn,Us,Ei].includes(n)){const o=n.replace(/^custom-slidev-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function Sf(e){const t={};if(!e)return t;const i=e[it]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[qe]??e["slidev-role"],s=e[et]??e["slidev-background"];(n===al||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ye]??e["slidev-layout"];o===ps||o===hs?t.imageLayout=o:(n===ps||n===hs)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Kt])try{const r=JSON.parse(e[Kt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Kt].trim()}}return e[Ni]&&(t.shikiLines=e[Ni].trim()),e[Mn]&&(t.maxHeight=e[Mn].trim()),e[$e]&&(t.slot=e[$e].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function ki(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function $n(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>s?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function zi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function to(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function In(e){if(!e)return[];if(st(e)&&qt(e)&&!di(e)){const n=un(e),s=[];for(const o of n)s.push(...In(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(zi);if(l.length>0)return l}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return zi(e)?[e]:[]}function Xo(e){var s;if(!e||!st(e)||!qt(e)||di(e))return null;const t=un(e);if(t.length===0)return null;if(t.length===1&&st(t[0])&&qt(t[0])){const o=Xo(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(st(o)){i.push(o);const l=((s=o.children)==null?void 0:s.filter(st))||[];i.push(...l)}const n=t.map(In);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=In(t[0]),l=In(t[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:i}}return null}function _f(e){if(!e||!st(e)||!qt(e)||di(e))return null;const t=Xo(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=Qo(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:s}}function va(e){if(!e||!st(e)||!qt(e)||di(e))return null;const t=un(e);if(t.length===0)return null;const i=[];for(const n of t){const s=In(n);if(s.length===0)return null;i.push(...s)}return i}function Cf(e){if(!e||!st(e)||!qt(e)||di(e))return null;const t=va(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function $f(e){if(!e||!st(e)||!qt(e)||di(e))return null;const t=Xo(e);if(t&&t.items.length===4)return t.items;const i=va(e);if(i&&i.length===4)return i;const n=un(e);return n.length===4?n:null}function If(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(st(r)){const c=$f(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=i[0]);const l=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>ba(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function Tf(e,t,i){var d,p,g,u,m;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let h=0;h<t.length;h++){const b=t[h];if(_s(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(h){const b=[];for(const y of h)st(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...a(y.children));return b}function c(h,b,y){const x={blockId:h,attrs:b,previousAttrs:y};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const h of l){const b=h.pageTargetId,y=t.find(I=>I.id===b),x=o.find(I=>I.pageTargetId===b);if(h.blocks.some(I=>{var w,N;return!!(di(I)||$o(I)&&(((w=I.ial)==null?void 0:w[ye])==="image-left"||((N=I.ial)==null?void 0:N[ye])==="image-right"))})){if(x){const I=x.headerId;if(I){c(I,{[$e]:""});const w=t.find(N=>N.id===I);w!=null&&w.ial&&(w.ial[$e]="")}for(const w of x.itemIds){c(w,{[$e]:""});const N=t.find(R=>R.id===w);N!=null&&N.ial&&(N.ial[$e]="")}}continue}let M=null,B=-1;for(let I=0;I<h.blocks.length;I++){const w=h.blocks[I],N=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const R of N){const z=_f(R);if(z){M=z,B=I;break}}if(M)break}if(M){const{superBlockNode:I,layout:w,items:N,slots:R}=M,V=h.blocks.slice(0,B).find(E=>ba(E)),S=V==null?void 0:V.id,F=((d=y==null?void 0:y.ial)==null?void 0:d[ye])||"",k=F==="clover",A=k?"clover":w;if(F!==A&&(c(b,{[ye]:A},{[ye]:F}),y&&(y.ial||(y.ial={}),y.ial[ye]=A)),V){const E=((p=V.ial)==null?void 0:p[$e])||"";E!=="header"&&(c(V.id,{[$e]:"header"},{[$e]:E}),V.ial||(V.ial={}),V.ial[$e]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[$e]:""});const E=t.find(D=>D.id===x.headerId);E&&(E.ial||(E.ial={}),E.ial[$e]="")}const H=[];for(let E=0;E<N.length;E++){const D=N[E],O=R[E];H.push(D.id);const J=((g=D.ial)==null?void 0:g[$e])||"";if(J!==O&&(c(D.id,{[$e]:O},{[$e]:J}),D.ial||(D.ial={}),D.ial[$e]=O),D.children&&D.children.length>0)for(const U of D.children)U.ial||(U.ial={}),U.ial[$e]!==O&&(U.ial[$e]=O)}if(x!=null&&x.itemIds){for(const E of x.itemIds)if(!H.includes(E)){c(E,{[$e]:""});const D=t.find(O=>O.id===E);D&&(D.ial||(D.ial={}),D.ial[$e]="")}}s.push({superBlockId:I.id,nestedSuperBlockIds:(u=M.nestedSuperBlocks)==null?void 0:u.map(E=>E.id),pageTargetId:b,headerId:S,itemIds:H,layout:k?"clover":w})}else{let I=!1;const w=[];for(const z of h.blocks){const V=st(z)?[z,...a(z.children||[])]:z.children?a(z.children):[];for(const S of V){const F=Cf(S);if(F){I=!0;for(const k of F.items)w.push(k.id)}}}const N=((m=y==null?void 0:y.ial)==null?void 0:m[ye])||"",R=Dn(N);if(x||I&&R){c(b,{[ye]:""},{[ye]:N}),y&&(y.ial||(y.ial={}),y.ial[ye]="");const z=x==null?void 0:x.headerId;if(z){c(z,{[$e]:""});const S=t.find(F=>F.id===z);S&&(S.ial||(S.ial={}),S.ial[$e]="")}const V=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of V){c(S,{[$e]:""});const F=t.find(k=>k.id===S);F&&(F.ial||(F.ial={}),F.ial[$e]="")}}}}return{changes:n,newTracked:s}}function st(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function qt(e){if(!st(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function $o(e){return!e||zi(e)||st(e)||!ki(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Qo(e){var g;if(!e||!st(e)||!qt(e))return null;const t=un(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const m=(((g=u.ial)==null?void 0:g.style)||u.style||"").trim();let h=null;if(m){const b=m.match(/calc\(\s*([\d.]+)%/i);if(b)h=parseFloat(b[1]);else{const y=m.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(h=parseFloat(y[1]))}}h!==null&&!isNaN(h)&&h>0?(i.push(h),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((u,m)=>u+(m||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=i.map(u=>u!==null?u:a),d=c.reduce((u,m)=>u+m,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const m=Math.round(u),h=100-m;return`${m}:${h}`}if(p.length===3){const[u,m,h]=p;if(u>=31&&u<=35&&m>=31&&m<=35&&h>=31&&h<=35)return"1:1:1";if(u>=23&&u<=27&&m>=48&&m<=52&&h>=23&&h<=27)return"1:2:1";if(u>=48&&u<=52&&m>=23&&m<=27&&h>=23&&h<=27)return"2:1:1";if(u>=23&&u<=27&&m>=23&&m<=27&&h>=48&&h<=52)return"1:1:2";if(u>=18&&u<=22&&m>=58&&m<=62&&h>=18&&h<=22)return"1:3:1";const b=Math.round(u),y=Math.round(m),x=100-b-y;return`${b}:${y}:${x}`}return p.map(u=>Math.round(u)).join(":")}function di(e){if(!e||!st(e)||!qt(e))return null;const t=(e.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=$o(t[0]),n=$o(t[t.length-1]),s=Qo(e)||void 0;if(i&&!n){const o=ki(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:ps,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=ki(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:hs,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Ef(e,t){const i=[];function n(s){for(const o of s){const l=di(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[ye];if(d!==a){const g={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[ye]=a,i.push(g),t&&t(g)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function un(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ba(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function $i(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,a);const d=a+c;let p=1,g=-1,u=-1;const m=/<\/?div\b[^>]*>/gi;m.lastIndex=d;let h;for(;(h=m.exec(e))!==null;)if(h[0].startsWith("</")){if(p--,p===0){g=h.index,u=h.index+h[0].length;break}}else p++;if(g!==-1&&u!==-1){const b=e.slice(d,g);n+=i(b),s=u}else n+=e.slice(a,d),s=d}return n}function Af(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(e))!==null;){const h=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,r=o.index,a=o[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,p=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let m;for(;(m=u.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){p=m.index,g=m.index+m[0].length;break}}else d++;if(p!==-1&&g!==-1){const h=e.slice(r,g),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(h),i+=b,n=g}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Bf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=Af(i);i=s;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=$i(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=$i(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=$i(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=$i(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=$i(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=$i(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=$i(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,g)=>Math.max(p,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const g=p.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ya(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function Mf(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Df(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function ka(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Lf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function Xn(e,t,i,n){const s=t!=null&&t.trim()!=="",o=Lf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${e}

</div>`:e;if(s&&!o){if(r){const m=t.trim();let h="v-click";return m==="hide"?h="v-click.hide":m!==""&&m!=="+1"&&(h=`v-click="${m}"`),`<div ${h}${a}>

${e}

</div>`}return ka(e,t)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${p}${a}>

${e}

</div>`;const g=t.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function wa(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Pf(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function xa(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),g=Math.floor(c.length/p),u=c.length%p;let m=0;for(let h=0;h<p;h++){const b=g+(h<u?1:0);d[h]=c.slice(m,m+b),m+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const g=parseInt(p[1],10);if(g>=1&&g<=i)return g}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let m=1;for(const h of e){const b=n(h);b!==null&&(m=b),u[m-1].push(h)}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),g=i-1;if(p.length>=g){const u=Math.floor(p.length/g),m=p.length%g,h=[d];let b=0;for(let y=0;y<g;y++){const x=u+(y<m?1:0);h.push(p.slice(b,b+x)),b+=x}return h}else if(p.length>0){const u=[d];for(let m=0;m<g;m++)u.push(m<p.length?[p[m]]:[]);return u}else return[d,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],g=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,g)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const g=i-p,u=e.length-d,m=Math.ceil(u/g);c[p]=e.slice(d,d+m),d+=m}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),p=d.split(/\r?\n/),g=[];for(let h=0;h<p.length;h++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(p[h])&&g.push(h);if(g.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,C=g.length-b,M=Math.ceil(C/x),B=g[b],I=b+M<g.length?g[b+M]:p.length,w=p.slice(B,I).join(`
`);h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:w,content:w}],b+=M}return h}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,C=u.length-b,M=Math.ceil(C/x),B=`<ul>
${u.slice(b,b+M).join(`
`)}
</ul>`;h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:B,content:B}],b+=M}return h}const m=d.split(/\r?\n\s*\r?\n/).filter(h=>h.trim()!=="");if(m.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,C=m.length-b,M=Math.ceil(C/x),B=m.slice(b,b+M).join(`

`);h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:B,content:B}],b+=M}return h}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Ur(e,t,i,n){var d;const s=xf(t),o=[],l=Wr(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);let a=[];for(const p of i){if(_s(p)){a=[];const u=Wr(p.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);continue}const g=(u,m)=>{var H,E,D,O;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const J=U=>{for(const K of U)K.id&&!r.allBlockIds.includes(K.id)&&r.allBlockIds.push(K.id),K.children&&K.children.length>0&&J(K.children)};J(u.children)}let h=Vc(u),b=u.ial?{...u.ial}:{};const y=h.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...Kc(y[0]),...b},h=h.slice(0,y.index).trim()),u.type!=="c"&&!h.startsWith("```")&&(h=ya(h));let x=h.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(h=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=h.trim());const C=Sf(b);if(h=Gc(h,n),h=Wc(h,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const J=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],U=K=>{for(const se of K){if(se.ial)for(const[ae,ce]of Object.entries(se.ial))J.includes(ae)&&!b[ae]&&(b[ae]=ce);se.children&&se.children.length>0&&U(se.children)}};U(u.children)}const M=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(h);if(M){const J=b["custom-slidev-autoplay"]==="true",U=b["custom-slidev-loop"]==="true",K=b["custom-slidev-muted"]==="true"||J,se=b["custom-slidev-controls"]==="false";h=h.replace(/<video\b([^>]*)>/gi,(ae,ce)=>{let ge=ce;return se?ge=ge.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ge)||(ge+=" controls"),J&&!/autoplay/i.test(ge)?ge+=" autoplay playsinline":!J&&b["custom-slidev-autoplay"]==="false"&&(ge=ge.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),U&&!/loop/i.test(ge)?ge+=" loop":!U&&b["custom-slidev-loop"]==="false"&&(ge=ge.replace(/\bloop\b/gi,"").trim()),K&&!/muted/i.test(ge)?ge+=" muted":!K&&b["custom-slidev-muted"]==="false"&&(ge=ge.replace(/\bmuted\b/gi,"").trim()),`<video ${ge.trim()}>`})}if(C.isBackground){const J=ki(h,u.content);if(J){r.frontmatter.background=Tt(J,n);return}}const B=di(u);if(B){r.frontmatter.layout=B.layout,r.frontmatter.image=Tt(B.imageUrl,n),!r.frontmatter.layoutRatio&&B.ratio&&(r.frontmatter.layoutRatio=B.ratio);for(const J of B.contentNodes)g(J);return}if(C.imageLayout==="image-left"||C.imageLayout==="image-right"){const J=ki(h,u.content);if(J){r.frontmatter.layout=C.imageLayout,r.frontmatter.image=Tt(J,n),!r.frontmatter.layoutRatio&&((H=u.ial)!=null&&H[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const J of u.children)g(J);return}const I=!!(C.slot||m!=null&&m.defaultSlot||r.frontmatter.layout==="clover"||Dn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(J=>{var U,K;return((U=J.ial)==null?void 0:U[$e])||((K=J.ial)==null?void 0:K[Ze])})||C.slot||C.clicks||I)){for(const J of u.children)C.slot&&(!J.ial||!J.ial[$e])&&(J.ial||(J.ial={}),J.ial[$e]=C.slot),g(J,{...m,parentClicks:C.clicks||(m==null?void 0:m.parentClicks),defaultSlot:C.slot||(m==null?void 0:m.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!C.clicks||!!((E=u.children)!=null&&E.some(J=>{var U;return(U=J.ial)==null?void 0:U[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(zi(u)&&u.children&&u.children.length>0&&(I||C.clicks||u.children.some(J=>{var U;return(U=J.ial)==null?void 0:U[Ze]}))&&w){const J=!!(u.children&&u.children.length>=2),U=u.children.find(we=>!!(we.markdown||we.content||"").trim())||u.children[0],K=((D=U==null?void 0:U.ial)==null?void 0:D[Ze])||((O=U==null?void 0:U.ial)==null?void 0:O["custom-slidev-click"]),se=!!(!C.clicks&&J&&K),ae=C.clicks||(se?K:void 0)||(m==null?void 0:m.parentClicks),ce=u.id||(m==null?void 0:m.parentContainerId),ge=C.slot||(m==null?void 0:m.defaultSlot);let Te=!0;for(const we of u.children){ge&&(!we.ial||!we.ial[$e])&&(we.ial||(we.ial={}),we.ial[$e]=ge);const ue=!!(we.markdown||we.content||"").trim(),Y=Te&&ue;Y&&(we.markdown&&(we.markdown=$n(we.markdown)),we.content&&(we.content=$n(we.content)),Te=!1);let fe=we;Y&&ae&&J&&(fe={...we,ial:{...we.ial||{}}},delete fe.ial[Ze],delete fe.ial["custom-slidev-click"]),g(fe,{parentClicks:ae,parentContainerId:ce,defaultSlot:ge})}return}if(C.isNote){const J=wa(h);J&&(r.notes?r.notes+=`

`+J:r.notes=J),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:J||u.content||"",rawMarkdown:h,isNote:!0,attributes:u.ial});return}C.shikiLines&&(h=Df(h,C.shikiLines)),x=h.trim();const N=(u.content||"").trim();if(x==="::right::"||N==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const z=Pf(u);let V=C.slot,S=C.clicks,F=C.motion,k={...u.ial||{}};if(z!==null){for(;a.length>0&&a[a.length-1].level>=z;)a.pop();const J=a.length>0?a[a.length-1]:void 0;!V&&(J!=null&&J.slot)&&(V=J.slot),!S&&(J!=null&&J.clicks)&&!(m!=null&&m.parentContainerId)&&(S=J.clicks),!F&&(J!=null&&J.motion)&&(F=J.motion);const U={...(J==null?void 0:J.customAttrs)||{}};if(u.ial)for(const[K,se]of Object.entries(u.ial))K.startsWith("custom-slidev-")&&!K.startsWith("custom-slidev-slide")&&(U[K]=se);m!=null&&m.parentContainerId||a.push({level:z,slot:V,clicks:S,motion:F,customAttrs:U})}else{const J=a.length>0?a[a.length-1]:void 0;J&&(!V&&J.slot&&J.slot!=="header"&&(V=J.slot),!S&&J.clicks&&!(m!=null&&m.parentContainerId)&&(S=J.clicks),!F&&J.motion&&(F=J.motion),J.customAttrs&&(k={...J.customAttrs,...k}))}!V&&r.blocks.some(J=>J.slot==="slot-divider-right")&&(V="right"),!V&&(m!=null&&m.defaultSlot)&&(V=m.defaultSlot),V&&(k[$e]=V),S&&!k[Ze]&&(k[Ze]=S),F&&!k[Kt]&&(k[Kt]=JSON.stringify(F)),(M||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(k["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(k["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(k["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(k["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(k["custom-slidev-controls"]=b["custom-slidev-controls"]));const A={id:u.id,type:u.type,content:u.content||"",rawMarkdown:h,clicks:S,parentClicks:m==null?void 0:m.parentClicks,parentContainerId:m==null?void 0:m.parentContainerId,motion:F,shikiLines:C.shikiLines,slot:V,attributes:k,rawNode:u};r.blocks.push(A)};g(p)}for(let p=0;p<o.length;p++){const g=o[p],u=[],m={...g.frontmatter};p===0&&(m.theme=s.theme,m.aspectRatio=s.aspectRatio,m.highlighter=s.highlighter,m.transition=g.frontmatter.transition||s.defaultTransition);const h=Mf(m);h&&u.push(h);const b=g.blocks.filter(B=>B.slot!=="slot-divider-right"),y=B=>B.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return Xn(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),x=B=>{const I=B.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(I.length===0)return;const w=I[0],N=(w.rawMarkdown||w.content||"").trim();(zi(w)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(w.rawMarkdown=$n(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},C=B=>{var z,V;if(B.length===0)return"";x(B);const I=(z=B.find(S=>S.parentClicks))==null?void 0:z.parentClicks;if(!I)return B.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var F;return Xn(S.rawMarkdown,S.clicks,S.motion,(F=S.attributes)==null?void 0:F.style)}).join(`

`);const w=[];let N=[];const R=()=>{if(N.length===0)return;const S=N.map(F=>(F.rawMarkdown||F.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(ka(S,I)),N=[]};for(const S of B){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(R(),w.push(Xn(S.rawMarkdown,S.clicks,S.motion,(V=S.attributes)==null?void 0:V.style))):N.push(S)}return R(),w.join(`

`)},M=g.frontmatter.layout||"default";if(M==="clover"||Dn(M)){let B=[];const I=b.filter(S=>S.slot==="header");if(I.length>0)B=I;else if(b.length>0){const S=b.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));S&&(B=[S])}const w=b.filter(S=>!B.includes(S));let N=2;if(M==="clover")N=4;else if(M==="three-cols-header")N=3;else if(M==="two-cols-header")N=2;else{let S=0;for(const F of w){const k=(F.slot||"").match(/^col-(\d+)$/i);k&&(S=Math.max(S,parseInt(k[1],10)))}if(S>=2)N=S;else if(g.frontmatter.layoutRatio){const F=g.frontmatter.layoutRatio.trim();if(F.includes(":")){const k=F.split(":").map(A=>parseFloat(A.trim())).filter(A=>!isNaN(A)&&A>0);k.length>=2&&(N=k.length)}else{const k=F.split(/\s+/).filter(Boolean);k.length>=2&&(N=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(N=Math.min(6,w[0].children.length))}const R=xa(w,N);R.forEach((S,F)=>{const k=`col-${F+1}`;for(const A of S)(!A.slot||A.slot==="default")&&(A.slot=k);x(S)});const z=R.flat();if(w.length===1&&z.length>1){const S=g.blocks.findIndex(F=>F.id===w[0].id);S!==-1&&g.blocks.splice(S,1,...z)}const V=y(B);if(V&&u.push(V),M==="two-cols-header"&&N===2){const S=C(R[0]||[]),F=C(R[1]||[]);S&&u.push(`::left::

${S}`),F&&u.push(`::right::

${F}`)}else R.forEach((S,F)=>{const k=C(S);k&&u.push(`::col-${F+1}::

${k}`)})}else if(M==="two-cols"){const B=b.filter(R=>R.slot==="left"),I=b.filter(R=>R.slot==="right");x(B),x(I);const w=y(B.length>0?B:b.filter(R=>R.slot!=="right")),N=y(I);u.push(w),N&&u.push(`::right::

${N}`)}else for(const B of b)u.push(Xn(B.rawMarkdown,B.clicks,B.motion,(d=B.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=o.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Io=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Of(e){var s,o,l,r,a,c,d,p,g,u,m,h;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(g=b.light)!=null&&g.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(m=b.dark)!=null&&m.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Tn(e){const t=Of(e);return t?`${Io}

/* Custom Workspace Inline Styles */
${t}`:Io}function io(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function Rf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Nf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Rf(l)?n.push(o.id):i.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function zf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function To(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Ff(e,t,i,n=8,s){const o=new Map;for(const g of t)g!=null&&g.id&&o.set(g.id,g);const l=g=>({id:g.id,parent_id:g.parent_id,root_id:g.root_id||e,type:g.type,subType:g.subtype??g.subType??"",content:g.content||"",markdown:g.markdown||"",ial:i(g.id,g.ial),children:[]}),r=g=>{let u=g.parent_id,m=0;for(;u&&u!==e&&m++<16;){const h=o.get(u);if(!h||!zf(h))return u;u=h.parent_id}return u||e},a=new Map;for(const g of t){if(!(g!=null&&g.id)||g.id===e||s&&s.size>0&&!s.has(g.id))continue;const u=r(g),m=a.get(u);m?m.push(g):a.set(u,[g])}if(s&&s.size>0)for(const g of a.values())g.sort((u,m)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(m.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(g,u)=>{const m=l(g);if(c.set(m.id,m),u>=n||!To(m))return m;const h=a.get(m.id);return h&&h.length>0&&(m.children=h.map(b=>d(b,u+1))),m};return{topLevel:(a.get(e)||[]).map(g=>d(g,0)),byId:c}}const Hf={getBlockAttrs:Mo,getChildBlocks:ds,getDocBlocksOrders:Fc,setBlockAttrs:je,sql:nn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Hc};class jf{constructor(t){Se(this,"deps");Se(this,"attrOverrides",new Map);Se(this,"trackedListSuperBlocks",new Map);Se(this,"fallbackWarnedDocId","");this.deps={...Hf,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,l]of Object.entries(i))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let A=0;A<o.length;A++)o[A]&&l.set(o[A],A);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Nf(s,c),p=new Map;if(Array.isArray(c))for(const A of c)A.id&&A.ial&&p.set(A.id,io(A.ial));const g=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(g).catch(()=>[])||[];if(Array.isArray(u)){for(const A of u)if(A.block_id&&A.name){let H=p.get(A.block_id);H||(H={},p.set(A.block_id,H)),H[A.name]=A.value||""}}const m=(A,H)=>{const E={...p.get(A)||(H?io(H):{})},D=this.attrOverrides.get(A);return D&&Object.assign(E,D),E},h=Array.isArray(c)&&c.length>0?Ff(t,c,m,8,l):null,b=s.map(A=>A.id).filter(Boolean),y=A=>({id:A.id,parent_id:A.parent_id,root_id:A.root_id||t,type:A.type,subType:A.subType,content:A.content||"",markdown:A.markdown||"",ial:m(A.id,A.ial),children:A.children}),x=async(A,H=0)=>{if(!A||H>8||!To(A))return;const E=await this.deps.getChildBlocks(A.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){A.children=E.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:A.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:m(D.id,D.ial),children:[]}));for(const D of A.children)await x(D,H+1)}},C=new Map;for(const A of c)A!=null&&A.id&&C.set(A.id,A);const M=b.every(A=>{const H=C.get(A);return!H||!!H.type});let B=[],I=!1;if(h&&d.usable&&r&&M){this.fallbackWarnedDocId="";for(const[H,E]of d.leafPatch){const D=h.byId.get(H);D&&(D.content=E.content,D.markdown=E.markdown)}const A=new Map;for(const H of s)H!=null&&H.id&&A.set(H.id,H);for(const H of d.rebuildRoots){const E=h.byId.get(H),D=A.get(H);E&&D&&(E.content=D.content||"",E.markdown=D.markdown||""),await x(E)}for(const H of s){if(!(H!=null&&H.id)||h.byId.has(H.id))continue;const E=y(H);await x(E),h.byId.set(E.id,E),h.topLevel.push(E)}B=h.topLevel.filter(H=>l.has(H.id)).sort((H,E)=>(l.get(H.id)??0)-(l.get(E.id)??0))}else b.length>0?(I=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),B=s.map(A=>y(A))):h&&(B=h.topLevel);const w=async(A,H=0)=>{if(!(!A||A.length===0||H>8))for(const E of A){if(To(E)&&(!E.children||E.children.length===0)){let O=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!O||O.length===0){const J=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;O=await this.deps.sql(J).catch(()=>[])||[]}if(Array.isArray(O)&&O.length>0){const J=new Set(B.map(K=>K.id)),U=O.filter(K=>K.id!==E.id&&!J.has(K.id));U.length>0&&(E.children=U.map(K=>{const se=p.get(K.id)||(K.ial?io(K.ial):{}),ae=this.attrOverrides.get(K.id);return ae&&Object.assign(se,ae),{id:K.id,parent_id:K.parent_id||E.id,root_id:K.root_id||t,type:K.type,subType:K.subType,content:K.content||"",markdown:K.markdown||"",ial:se}}))}}E.children&&E.children.length>0&&await w(E.children,H+1)}};I&&await w(B);const N=A=>{var H,E;for(const D of A)if(D.children&&D.children.length>0){N(D.children);for(const O of D.children)if(O.ial)for(const[J,U]of Object.entries(O.ial))J.startsWith("custom-slidev-")&&!((H=D.ial)!=null&&H[J])&&(D.ial||(D.ial={}),D.ial[J]=U);if(D.ial){for(const[O,J]of Object.entries(D.ial))if(O.startsWith("custom-slidev-"))for(const U of D.children)(U.type==="video"||U.type==="NodeVideo"||/<video\b/i.test(U.markdown||U.content||""))&&!((E=U.ial)!=null&&E[O])&&(U.ial||(U.ial={}),U.ial[O]=J)}}};N(B),Ef(B,A=>{const H={[ye]:A.layout};this.setBlockAttrOverride(A.blockId,H),(this.deps.setBlockAttrs||je)(A.blockId,H).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const R=this.trackedListSuperBlocks.get(t)||[],z=Tf(t,B,{tracked:R,onTagChange:A=>{this.setBlockAttrOverride(A.blockId,A.attrs),A.blockId===t&&Object.assign(i,A.attrs);const H=D=>{for(const O of D)O.id===A.blockId&&(O.ial||(O.ial={}),Object.assign(O.ial,A.attrs)),O.children&&O.children.length>0&&H(O.children)};H(B),(this.deps.setBlockAttrs||je)(A.blockId,A.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,z.newTracked);const V=new Set;for(const A of B){const H=A.markdown||A.content||"";if(H.includes("((")){const E=jc(H);for(const D of E)V.add(D.blockId)}}const S={};if(V.size>0){const A=Array.from(V).map(E=>`'${E}'`).join(","),H=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${A})`).catch(()=>[])||[];if(Array.isArray(H))for(const E of H)E.id&&(S[E.id]=E.markdown||E.content||"")}const F=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=Ur(t,i,B,{baseUrl:F,refContentMap:S});try{const A=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=Tn(A)}catch{k.customThemeCss=Tn(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Ur(t,{},[],{});return n.customThemeCss=Tn(null),n}}}const Pe=new jf;class er{constructor(t){Se(this,"devServerUrl","http://localhost:3030");Se(this,"isConnected",!1);Se(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let g="";d.length>0?g=p?"":`---
${d.join(`
`)}
---

`:p||(g=`---

`);let u="";if(c.layout==="two-cols"){const h=r.blocks.filter(C=>C.slot!=="right"),b=r.blocks.filter(C=>C.slot==="right"),y=h.map(C=>C.rawMarkdown||C.content||"").join(`

`),x=b.map(C=>C.rawMarkdown||C.content||"").join(`

`);u=`${y}

::right::

${x}`}else u=r.blocks.map(h=>h.rawMarkdown||h.content||"").join(`

`);let m="";return r.notes&&r.notes.trim()&&(m=`

<!--
${r.notes.trim()}
-->`),`${g}${u}${m}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}function Wf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ct(e){const t=Wf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function tr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Ct("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Sa(){var t,i;const e=tr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ct("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Uf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Fn(){const e=tr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Ct("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function _a(){var n,s;const e=tr(),t={...(e==null?void 0:e.env)||{}};if(Fn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Eo(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function Vf(){const e=Ct("os"),t=Ct("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class ir{constructor(t){Se(this,"runner");this.runner=t||ir.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Ct("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Fn()==="win32",r=_a();return await new Promise(a=>{s(t,i,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Sa(),i=Fn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:i,isDesktop:t}}}class Kf{constructor(){Se(this,"iframe",null);Se(this,"isReady",!1);Se(this,"pageChangedHandlers",[]);Se(this,"readyHandlers",[]);Se(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidevBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Gf{constructor(t){Se(this,"childProcess",null);Se(this,"activePort",null);Se(this,"isRunning",!1);Se(this,"defaultPort");Se(this,"maxPortRetries");Se(this,"probeTimeoutMs");Se(this,"customSpawner");Se(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Ct("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=Fn()==="win32"?"npx.cmd":"npx",l=Eo(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let p=(a=Ct("child_process"))==null?void 0:a.spawn;if(!p){const m=await import("node:child_process").catch(()=>({}));p=m==null?void 0:m.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=_a();this.childProcess=p(o,r,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Fn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=Ct("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Fs{constructor(){Se(this,"iframe",null);Se(this,"isReady",!1);Se(this,"pendingMessages",[]);Se(this,"slideChangedHandlers",[]);Se(this,"blockClickedHandlers",[]);Se(this,"openInEditorHandlers",[]);Se(this,"clientReadyHandlers",[]);Se(this,"openPeekDrawerHandlers",[]);Se(this,"toggleFullscreenHandlers",[]);Se(this,"openPresenterHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var s;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const s=i.payload.blockId||i.payload.clickedBlockId||"";for(const o of this.openInEditorHandlers)o(s,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const s=i.payload.blockId||i.payload.url||"",o={peekType:i.payload.peekType,target:s,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(o)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break}}}const Ca={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},qf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Zf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Yf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Jf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Xf=`${Io}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Qf(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class ep{constructor(t){Se(this,"workspacePath");Se(this,"slidesFileName");Se(this,"cliBridge",new er);const i=Vf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Eo(o),a=Eo(l),c=Qf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const C of c){const M=Ca[C]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${C}
// #endregion snippet
`;d.set(C,M)}t.slides.some(C=>{var M;return((M=C.frontmatter)==null?void 0:M.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",qf),t.slides.some(C=>{var M;return((M=C.frontmatter)==null?void 0:M.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Zf),t.slides.some(C=>{var M;return((M=C.frontmatter)==null?void 0:M.layout)==="clover"})&&d.set("layouts/clover.vue",Yf),d.set("setup/root.ts",Jf),d.set("styles/index.css",Xf);const m=Ct("fs"),h=Ct("path");let b=!1;const y=h!=null&&h.dirname?h.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(m&&h&&x)try{m.existsSync(y)||m.mkdirSync(y,{recursive:!0}),m.writeFileSync(a,s,"utf-8"),m.writeFileSync(r,n,"utf-8");for(const[C,M]of d.entries()){const B=h.join(y,C),I=h.dirname(B);m.existsSync(I)||m.mkdirSync(I,{recursive:!0}),m.existsSync(B)||m.writeFileSync(B,M,"utf-8")}b=!0}catch{}if(!b&&i)try{const C=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),M=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(l,!1,M),await i(o,!1,C);for(const[B,I]of d.entries()){const w=`${this.workspacePath}/${B}`,N=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await i(w,!1,N).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch(C){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String(C)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class tp{constructor(){Se(this,"mode","web-sandbox");Se(this,"webBridge");Se(this,"cliBridge");Se(this,"nativeBridge");Se(this,"processManager");Se(this,"scaffolder");Se(this,"envDetector");this.webBridge=new Fs,this.cliBridge=new er,this.nativeBridge=new Kf,this.processManager=new Gf,this.scaffolder=new ep,this.envDetector=new ir}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const ip={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},np={key:0},sp={key:1},op={key:2},rp={key:3},lp={key:4},ap={key:5},cp={key:6},dp={key:7},up={key:8},fp={key:9},pp={key:10},hp={key:11},mp={key:12},gp={key:13},vp={key:14},bp={key:15},yp={key:16},kp={key:17},wp={key:18},xp={key:19},Sp={key:20},_p={key:21},Cp={key:22},$p={key:23},Ip={key:24},Tp={key:25},Ep={key:26},Ap={key:27},Bp={key:28},Mp={key:29},Dp={key:30},Lp={key:31},Pp={key:32},Op={key:33},Rp={key:34},Np={key:35},zp={key:36},Fp={key:37},Hp={key:38},jp={key:39},Wp={key:40},Up={key:41},Vp={key:42},Kp={key:43},Gp={key:44},qp={key:45},Zp={key:46},Yp={key:47},Jp={key:48},Xp={key:49},Qp={key:50},eh={key:51},th={key:52},ih={key:53},nh={key:54},sh={key:55},oh={key:56},rh={key:57},lh={key:58},ah={key:59},ch={key:60},dh={key:61},uh={key:62},fh={key:63},ph={key:64},hh={key:65},mh={key:66},gh={key:67},vh={key:68},bh={key:69},yh={key:70},kh=It({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(Q(),te("svg",ip,[e.name==="fullscreen"||e.name==="maximize"?(Q(),te("g",np,[...i[0]||(i[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(Q(),te("g",sp,[...i[1]||(i[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(Q(),te("g",op,[...i[2]||(i[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(Q(),te("g",rp,[...i[3]||(i[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(Q(),te("g",lp,[...i[4]||(i[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(Q(),te("g",ap,[...i[5]||(i[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(Q(),te("g",cp,[...i[6]||(i[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(Q(),te("g",dp,[...i[7]||(i[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(Q(),te("g",up,[...i[8]||(i[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(Q(),te("g",fp,[...i[9]||(i[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(Q(),te("g",pp,[...i[10]||(i[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(Q(),te("g",hp,[...i[11]||(i[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(Q(),te("g",mp,[...i[12]||(i[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(Q(),te("g",gp,[...i[13]||(i[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(Q(),te("g",vp,[...i[14]||(i[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(Q(),te("g",bp,[...i[15]||(i[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(Q(),te("g",yp,[...i[16]||(i[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(Q(),te("g",kp,[...i[17]||(i[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(Q(),te("g",wp,[...i[18]||(i[18]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(Q(),te("g",xp,[...i[19]||(i[19]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(Q(),te("g",Sp,[...i[20]||(i[20]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(Q(),te("g",_p,[...i[21]||(i[21]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(Q(),te("g",Cp,[...i[22]||(i[22]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(Q(),te("g",$p,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-7b1482ef></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-7b1482ef></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-7b1482ef></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-7b1482ef></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-7b1482ef></path>',5)])])):e.name==="ratio"?(Q(),te("g",Ip,[...i[24]||(i[24]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(Q(),te("g",Tp,[...i[25]||(i[25]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(Q(),te("g",Ep,[...i[26]||(i[26]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(Q(),te("g",Ap,[...i[27]||(i[27]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(Q(),te("g",Bp,[...i[28]||(i[28]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(Q(),te("g",Mp,[...i[29]||(i[29]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(Q(),te("g",Dp,[...i[30]||(i[30]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(Q(),te("g",Lp,[...i[31]||(i[31]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(Q(),te("g",Pp,[...i[32]||(i[32]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevrons-left"?(Q(),te("g",Op,[...i[33]||(i[33]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(Q(),te("g",Rp,[...i[34]||(i[34]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(Q(),te("g",Np,[...i[35]||(i[35]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(Q(),te("g",zp,[...i[36]||(i[36]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(Q(),te("g",Fp,[...i[37]||(i[37]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(Q(),te("g",Hp,[...i[38]||(i[38]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(Q(),te("g",jp,[...i[39]||(i[39]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(Q(),te("g",Wp,[...i[40]||(i[40]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(Q(),te("g",Up,[...i[41]||(i[41]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(Q(),te("g",Vp,[...i[42]||(i[42]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-7b1482ef></path><polyline points="14 2 14 8 20 8" data-v-7b1482ef></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-7b1482ef></line><line x1="16" y1="17" x2="8" y2="17" data-v-7b1482ef></line><line x1="10" y1="9" x2="8" y2="9" data-v-7b1482ef></line>',5)])])):e.name==="focus"||e.name==="target"?(Q(),te("g",Kp,[...i[43]||(i[43]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(Q(),te("g",Gp,[...i[44]||(i[44]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(Q(),te("g",qp,[...i[45]||(i[45]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-7b1482ef></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-7b1482ef></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-7b1482ef></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-7b1482ef></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(Q(),te("g",Zp,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-7b1482ef></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-7b1482ef></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-7b1482ef></line><line x1="5" y1="15" x2="8" y2="15" data-v-7b1482ef></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-7b1482ef></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-7b1482ef></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-7b1482ef></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(Q(),te("g",Yp,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-7b1482ef></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-7b1482ef></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-7b1482ef></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-7b1482ef></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-7b1482ef></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-7b1482ef></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(Q(),te("g",Jp,[...i[48]||(i[48]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-7b1482ef></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-7b1482ef></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-7b1482ef></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-7b1482ef></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-7b1482ef></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-7b1482ef></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-7b1482ef></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-7b1482ef></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-7b1482ef></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(Q(),te("g",Xp,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="5" y1="7" x2="13" y2="7" data-v-7b1482ef></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-7b1482ef></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-7b1482ef></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-7b1482ef></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-7b1482ef></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-7b1482ef></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-7b1482ef></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(Q(),te("g",Qp,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="12" y1="4" x2="12" y2="20" data-v-7b1482ef></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-7b1482ef></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-7b1482ef></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-7b1482ef></line><circle cx="15.5" cy="8.5" r="1.2" data-v-7b1482ef></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-7b1482ef></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(Q(),te("g",eh,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><line x1="12" y1="4" x2="12" y2="20" data-v-7b1482ef></line><circle cx="6" cy="8.5" r="1.2" data-v-7b1482ef></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-7b1482ef></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-7b1482ef></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-7b1482ef></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-7b1482ef></line>',7)])])):e.name==="layout-center"||e.name==="center"?(Q(),te("g",th,[...i[52]||(i[52]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(Q(),te("g",ih,[...i[53]||(i[53]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><circle cx="8" cy="9" r="1.5" data-v-7b1482ef></circle><line x1="14" y1="8" x2="9" y2="14" data-v-7b1482ef></line><circle cx="15" cy="13" r="1.5" data-v-7b1482ef></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-7b1482ef></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(Q(),te("g",nh,[...i[54]||(i[54]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><circle cx="7.5" cy="9.5" r="2" data-v-7b1482ef></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-7b1482ef></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-7b1482ef></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-7b1482ef></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-7b1482ef></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(Q(),te("g",sh,[...i[55]||(i[55]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-7b1482ef></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-7b1482ef></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-7b1482ef></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-7b1482ef></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(Q(),te("g",oh,[...i[56]||(i[56]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(Q(),te("g",rh,[...i[57]||(i[57]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(Q(),te("g",lh,[...i[58]||(i[58]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(Q(),te("g",ah,[...i[59]||(i[59]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(Q(),te("g",ch,[...i[60]||(i[60]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(Q(),te("g",dh,[...i[61]||(i[61]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(Q(),te("g",uh,[...i[62]||(i[62]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-7b1482ef></line><line x1="4" y1="10" x2="4" y2="3" data-v-7b1482ef></line><line x1="12" y1="21" x2="12" y2="12" data-v-7b1482ef></line><line x1="12" y1="8" x2="12" y2="3" data-v-7b1482ef></line><line x1="20" y1="21" x2="20" y2="16" data-v-7b1482ef></line><line x1="20" y1="12" x2="20" y2="3" data-v-7b1482ef></line><line x1="1" y1="14" x2="7" y2="14" data-v-7b1482ef></line><line x1="9" y1="8" x2="15" y2="8" data-v-7b1482ef></line><line x1="17" y1="16" x2="23" y2="16" data-v-7b1482ef></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(Q(),te("g",fh,[...i[63]||(i[63]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(Q(),te("g",ph,[...i[64]||(i[64]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(Q(),te("g",hh,[...i[65]||(i[65]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(Q(),te("g",mh,[...i[66]||(i[66]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(Q(),te("g",gh,[...i[67]||(i[67]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-7b1482ef></rect><line x1="13" y1="8" x2="19" y2="8" data-v-7b1482ef></line><line x1="13" y1="12" x2="19" y2="12" data-v-7b1482ef></line><line x1="13" y1="16" x2="17" y2="16" data-v-7b1482ef></line>',5)])])):e.name==="image-right"?(Q(),te("g",vh,[...i[68]||(i[68]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-7b1482ef></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-7b1482ef></rect><line x1="5" y1="8" x2="11" y2="8" data-v-7b1482ef></line><line x1="5" y1="12" x2="11" y2="12" data-v-7b1482ef></line><line x1="5" y1="16" x2="9" y2="16" data-v-7b1482ef></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(Q(),te("g",bh,[...i[69]||(i[69]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(Q(),te("g",yh,[...i[70]||(i[70]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Zt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},de=Zt(kh,[["__scopeId","data-v-7b1482ef"]]),wh={class:"spm-immersion-header"},xh={class:"spm-immersion-header__left"},Sh={class:"spm-immersion-title"},_h={class:"spm-immersion-header__center"},Ch={class:"spm-immersion-header__actions"},$h=["aria-label"],Ih={class:"spm-immersion-body"},Th=It({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Bt((Q(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:ii(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:o}),f("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",wh,[f("div",xh,[Yn(a.$slots,"header-left",{},()=>[f("span",Sh,xe(e.title),1)])]),f("div",_h,[Yn(a.$slots,"header-center",{},void 0)]),f("div",Ch,[Yn(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[re(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,$h),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[re(de,{name:"close"})])])]),f("div",Ih,[Yn(a.$slots,"default",{},void 0)])],2)],34)),[[_o,e.visible]])}}),Eh=Zt(Th,[["__scopeId","data-v-3f1665db"]]),Ah={class:"spm-protyle-drawer"},Bh={class:"spm-protyle-drawer__subbar"},Mh={class:"spm-protyle-drawer__nav"},Dh=["title"],Lh={class:"spm-protyle-drawer__actions"},Ph=["aria-label"],Oh=["aria-label"],Rh=It({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=he(n.blockId),o=he(n.title||""),l=he(!1),r=he(!0),a=he(!1),c=he(""),d=gi,p=he([]),g=he(null);let u=null;Oi(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",p.value=[],h(w))}),dn(()=>{s.value&&h(s.value)}),Ko(()=>{b()});async function m(w){try{const N=await nn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const R=N[0];c.value=R.root_id||"";const z=R.id===R.root_id||R.type==="d";a.value=z,r.value=!z,!o.value&&R.content&&(o.value=R.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function h(w,N){if(!g.value||!w)return;b(),await m(w),typeof N=="boolean"&&(r.value=!a.value&&N);let R,z;r.value&&!a.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],z={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],z={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new me.Protyle(n.plugin.app,g.value,{blockId:w,action:R,render:z}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(V){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",V)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}g.value&&(g.value.innerHTML="")}function y(){a.value||(r.value=!r.value,h(s.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function C(){if(s.value)try{me.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function M(){var R;if(!s.value)return;const w=zs(),N=ga(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const z=Ct("electron");(R=z==null?void 0:z.shell)!=null&&R.openExternal?z.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}i("external-jump",N)}function B(){if(p.value.length>0){const w=p.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,h(w.blockId,w.isFocusMode))}}function I(w){const N=w.target;if(!N)return;const R=N.closest('[data-type="block-ref"]');if(R){const V=R.getAttribute("data-id");if(V&&V!==s.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=V,o.value=R.innerText.trim()||V,h(V);return}}const z=N.closest("a");if(z&&z.href&&z.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const V=z.href.replace("siyuan://blocks/","").split("?")[0];V&&V!==s.value&&(p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=V,o.value=z.innerText.trim()||V,h(V))}}return(w,N)=>(Q(),te("div",Ah,[f("div",Bh,[f("div",Mh,[p.value.length>0?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:B},[re(de,{name:"arrow-left"}),N[0]||(N[0]=f("span",null,"返回",-1))])):Le("",!0),f("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xe(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:o.value||s.value},xe(o.value||s.value),9,Dh)]),f("div",Lh,[a.value?Le("",!0):(Q(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[re(de,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,xe(r.value?"块聚焦":"展开全文"),1)],10,Ph)),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[re(de,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,xe(l.value?"编辑中":"只读"),1)],10,Oh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:C},[re(de,{name:"window"}),N[1]||(N[1]=f("span",null,"独立窗口",-1))]),be(d).enableWebServeJump?(Q(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:M},[re(de,{name:"external-link"}),N[2]||(N[2]=f("span",null,"外跳",-1))])):Le("",!0)])]),f("div",{ref_key:"mountEl",ref:g,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),Nh=Zt(Rh,[["__scopeId","data-v-7e586ef3"]]),zh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Fh=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Vr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function $a(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function Hh(e){const t=e.split(/[/?#]/)[0];return!t||Fh.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function jh(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Ia(e){const t=Wh(e);return t.external||!t.url?t:{url:jh(t.url),external:!1}}function Wh(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(cl(t))return{url:`/${dl(t)}`,external:!1};if(/^file:/i.test(t)){const n=Vr($a(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Vr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return zh.test(t)?{url:t,external:!0}:Hh(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Uh={class:"spm-webview-drawer"},Vh={class:"spm-webview-toolbar"},Kh={class:"spm-webview-toolbar__nav"},Gh=["disabled"],qh=["disabled"],Zh=["aria-label"],Yh={class:"spm-webview-toolbar__address"},Jh=["aria-label"],Xh={class:"spm-webview-toolbar__actions"},Qh=["aria-label"],em={class:"spm-zoom-controller"},tm=["disabled"],im=["disabled"],nm={key:1,class:"spm-webview-fallback"},sm=["src"],om={key:2,class:"spm-load-error"},rm={class:"spm-load-error__code"},lm={class:"spm-load-error__code-num"},am={class:"spm-load-error__url"},cm={class:"spm-load-error__hint"},dm={class:"spm-load-error__actions"},Kr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Ta="siyuan-slidev-peek-view-mode";let Ea="desktop";function um(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Ta);if(e==="mobile"||e==="desktop")return e}catch{}return Ea}function fm(e){if(Ea=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Ta,e)}catch{}}function pm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const hm=It({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=he(Sa()&&!Uf()),o=he(n.url),l=he(n.url),r=n.url,a=he(!1),c=he(null),d=he(!1),p=he(!1),g=he(1),u=he(!1),m=he(um());let h=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ke(()=>m.value==="mobile"?Kr:h||void 0),y=he(null),x=he(null);let C=null,M=null,B=null;Oi(()=>n.url,Y=>{Y&&Y!==o.value&&(o.value=Y,l.value=Y,m.value==="mobile"&&z(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y))}),Oi(()=>n.visible,Y=>{if(Y)se(),m.value==="mobile"&&z(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),dn(()=>{I(),x.value&&typeof ResizeObserver<"u"&&(C=new ResizeObserver(()=>{const Y=y.value;if(Y&&typeof Y.invalidate=="function")try{Y.invalidate()}catch{}}),C.observe(x.value)),M=Y=>{var P;const fe=Y.message||((P=Y.error)==null?void 0:P.message);if(typeof fe=="string"&&fe.includes("Invalid guestInstanceId"))return Y.preventDefault(),Y.stopImmediatePropagation(),!0},window.addEventListener("error",M,!0),B=Y=>{const fe=Y.reason,P=typeof fe=="string"?fe:fe==null?void 0:fe.message;typeof P=="string"&&P.includes("Invalid guestInstanceId")&&Y.preventDefault()},window.addEventListener("unhandledrejection",B)}),Ko(()=>{if(w(),C&&(C.disconnect(),C=null),M&&(window.removeEventListener("error",M,!0),M=null),B&&(window.removeEventListener("unhandledrejection",B),B=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function I(){const Y=y.value;Y&&(Y.addEventListener("dom-ready",N),Y.addEventListener("did-start-loading",V),Y.addEventListener("did-stop-loading",k),Y.addEventListener("did-navigate",A),Y.addEventListener("did-navigate-in-page",H),Y.addEventListener("new-window",E),Y.addEventListener("did-fail-load",S),Y.addEventListener("did-fail-provisional-load",S))}function w(){const Y=y.value;if(Y)try{Y.removeEventListener("dom-ready",N),Y.removeEventListener("did-start-loading",V),Y.removeEventListener("did-stop-loading",k),Y.removeEventListener("did-navigate",A),Y.removeEventListener("did-navigate-in-page",H),Y.removeEventListener("new-window",E),Y.removeEventListener("did-fail-load",S),Y.removeEventListener("did-fail-provisional-load",S)}catch{}}function N(){const Y=y.value;if(Y&&typeof Y.getUserAgent=="function"&&!h)try{const fe=Y.getUserAgent();fe&&!fe.includes("iPhone")&&(h=fe)}catch{}m.value==="mobile"&&z(!1),se(),D()}function R(){const Y=m.value==="mobile"?"desktop":"mobile";m.value=Y,fm(Y),z(!0)}function z(Y=!1){const fe=y.value;if(!fe)return;const P=m.value==="mobile"?Kr:h;if(typeof fe.setUserAgent=="function"&&P)try{fe.setUserAgent(P)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(Y&&typeof fe.reload=="function")try{fe.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function V(){a.value=!0,c.value=null}function S(Y){if(Y&&Y.isMainFrame===!1||Y&&Number(Y.errorCode)===-3)return;const fe=String((Y==null?void 0:Y.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Y==null?void 0:Y.errorCode)??0),description:fe,validatedURL:String((Y==null?void 0:Y.validatedURL)||o.value),hint:pm(fe)},a.value=!1}function F(){c.value=null,U()}function k(){if(a.value=!1,D(),y.value&&typeof y.value.getURL=="function"){const Y=y.value.getURL();Y&&Y!=="about:blank"&&(o.value=Y,l.value=Y)}}function A(Y){Y!=null&&Y.url&&(o.value=Y.url,l.value=Y.url),D()}function H(Y){Y!=null&&Y.url&&(o.value=Y.url,l.value=Y.url),D()}function E(Y){Y&&Y.url&&(Y.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y.url))}function D(){const Y=y.value;Y&&(typeof Y.canGoBack=="function"&&(d.value=Y.canGoBack()),typeof Y.canGoForward=="function"&&(p.value=Y.canGoForward()))}function O(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function J(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function U(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function K(){const Y=Ia(l.value);if(Y.url){if(Y.external){o.value=Y.url,ue();return}o.value=Y.url,l.value=Y.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y.url)}}function se(){const Y=y.value;if(Y&&typeof Y.setZoomFactor=="function")try{Y.setZoomFactor(g.value)}catch(fe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",fe)}}function ae(){g.value=Math.min(2.5,Math.round((g.value+.1)*10)/10),se()}function ce(){g.value=Math.max(.5,Math.round((g.value-.1)*10)/10),se()}function ge(){g.value=1,se()}function Te(Y){Y.preventDefault(),Y.deltaY<0?ae():Y.deltaY>0&&ce()}async function we(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Y){console.warn("Copy url failed:",Y)}}function ue(){var fe;const Y=o.value;if(typeof window<"u"){const P=Ct("electron");(fe=P==null?void 0:P.shell)!=null&&fe.openExternal?P.shell.openExternal(Y).catch(()=>{window.open(Y,"_blank")}):window.open(Y,"_blank")}i("external-jump",Y)}return(Y,fe)=>{const P=Qd("webview");return Q(),te("div",Uh,[f("div",Vh,[f("div",Kh,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:O},[re(de,{name:"arrow-left"})],8,Gh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:J},[re(de,{name:"arrow-right"})],8,qh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:U},[re(de,{name:"refresh"})],8,Zh)]),f("div",Yh,[Bt(f("input",{"onUpdate:modelValue":fe[0]||(fe[0]=j=>l.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:mf(K,["enter"])},null,544),[[Co,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:we},[re(de,{name:"copy"})],8,Jh)]),f("div",Xh,[f("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:R},[re(de,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Qh),f("div",em,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:g.value<=.5,onClick:ce},[re(de,{name:"minus"})],8,tm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ge},xe(Math.round(g.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:g.value>=2.5,onClick:ae},[re(de,{name:"plus"})],8,im)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ue},[re(de,{name:"external-link"}),fe[1]||(fe[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:x,class:_e(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:ii(Te,["ctrl"])},[f("div",{class:_e(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[s.value?(Q(),Vt(P,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:be(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(Q(),te("div",nm,[f("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,sm),f("div",{class:"spm-fallback-bar"},[fe[2]||(fe[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:ue}," 在新标签页中打开 ↗ ")])])),c.value?(Q(),te("div",om,[re(de,{name:"alert",class:"spm-load-error__icon"}),fe[5]||(fe[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",rm,[St(xe(c.value.description)+" ",1),f("span",lm,"("+xe(c.value.errorCode)+")",1)]),f("div",am,xe(c.value.validatedURL),1),f("p",cm,xe(c.value.hint),1),f("div",dm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:F},[re(de,{name:"refresh"}),fe[3]||(fe[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:ue},[re(de,{name:"external-link"}),fe[4]||(fe[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Le("",!0)],2)],34)])}}}),mm=Zt(hm,[["__scopeId","data-v-192d3665"]]);class gm{constructor(){Se(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class vm{constructor(t){Se(this,"blockToPageMap",new Map);Se(this,"debounceCtrl",new gm);Se(this,"activeBlockId","");Se(this,"activePageIndex",1);Se(this,"currentDocId","");Se(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ri(e,t){var o,l;if(!e||typeof document>"u")return!1;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return me.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function bm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function ym(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else o.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Aa(e,t,i){var g,u,m,h;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const I=x[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const C=y.match(/^(\s*)[-*+]\s+(.*)$/);if(C){const I=C[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:C[2],media:[]});continue}const M=y.match(/^(\s*)\d+\.\s+(.*)$/);if(M){l.length===0&&(r=!0);const I=M[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:M[2],media:[]});continue}const B=y.trim();if(!(!B||/^\{:.*?\}$/.test(B)))if(l.length>0){const I=B.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const R=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(I[1])}" src="${I[2]}" class="${R}" /></div>`);continue}if(B.match(/^<img\b[\s\S]*?\/?>$/i)){const N=B.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(B)){let N=B;if(!/<\/video>/i.test(N))for(;b+1<n.length&&!/<\/video>/i.test(N);)b++,N+=" "+n[b].trim();const R=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(N),z=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(N),V=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-muted"])==="true"||R||/muted/i.test(N),S=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-controls"])==="false",F=N.match(/\bsrc=["']([^"']+)["']/i),k=F?F[1]:"",A=['class="slide-video-player"'];S||A.push("controls"),R&&(A.push("autoplay"),A.push("playsinline")),z&&A.push("loop"),V&&A.push("muted"),A.push('preload="metadata"'),k&&A.push(`src="${k}"`);const H=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=H?H[1].trim():"";!E&&k&&(E=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${V?"true":"false"}"><video ${A.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+B}else o.push(B)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const y=bm(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",C=b.level||0,M=C>0?` style="margin-left:${(C*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${C%2===1?"circle":"square"} !important;`:""}"`:"",B=C>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${B}"${M}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${x}</li>`}return`<li${B?` class="${B.trim()}"`:""}${M}>${y}${x}</li>`}).join(`
`);return`${ym(o)}<${a} class="${c}">
${d}
</${a}>`}function km(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(!p){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]);let g=p;if(!/<\/video>/i.test(g))for(;c+1<s.length&&!/<\/video>/i.test(g);)c++,g+=`
`+s[c];o.push(g);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var m,h,b,y;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const x=p[1].length;return`<h${x} class="slide-list-item-title">${rt(p[2].trim())}</h${x}>`}const g=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const x=/\.gif(?:\?|$)/i.test(g[2]),C=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(g[1])}" src="${g[2]}" class="${C}" /></div>`}if(/<video\b/i.test(d)){const x=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),C=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-loop"])==="true"||/loop/i.test(d),M=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),B=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-controls"])==="false",I=d.match(/\bsrc=["']([^"']+)["']/i),w=I?I[1]:"",N=['class="slide-video-player"'];B||N.push("controls"),x&&N.push("autoplay playsinline"),C&&N.push("loop"),M&&N.push("muted"),N.push('preload="metadata"'),w&&N.push(`src="${w}"`);const R=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let z=R?R[1].trim():"";return!z&&w&&(z=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${M?"true":"false"}"><video ${N.join(" ")}>${z}</video></div>`}const u=Aa(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(I=>I.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${rt(x[0])}</p>`;const C=x[0],B=x.slice(1).map(I=>rt(I)).join("<br/>");return`<p class="slide-list-item-title">${rt(C)}</p>
<p class="slide-list-item-desc">${B}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function no(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Ba(e,t){var r,a,c,d,p,g,u,m;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(h=>h.slot!=="slot-divider-right"),l=i==="cover"?null:s.find(no);if(i==="two-cols"){const h=s.some(V=>V.slot==="right");let b=[],y=[];if(h)b=s.filter(V=>V.slot!=="right"),y=s.filter(V=>V.slot==="right");else{const V=Math.ceil(s.length/2);b=s.slice(0,V),y=s.slice(V)}const x=V=>{const S=V.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(S.length>0){const F=S[0],k=(F.rawMarkdown||F.content||"").trim();(zi(F)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(F.rawMarkdown=$n(F.rawMarkdown||F.content||""),F.content=F.rawMarkdown)}};x(b),x(y);const C=b.map(V=>pi(V,t)).join(`
`),M=y.map(V=>pi(V,t)).join(`
`),B=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",I=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",N=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",z=`style="grid-template-columns: ${to((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${B}${I}" ${z}>
        <div class="${w}">${C}</div>
        <div class="${N}">${M}</div>
      </div>
    `}if(i==="clover"||Dn(i)){const h=i==="clover";let b=[];const y=s.filter(A=>A.slot==="header");if(y.length>0)b=y;else if(s.length>0){const A=s.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));A&&(b=[A])}const x=s.filter(A=>!b.includes(A));let C=2;if(h)C=4;else if(i==="three-cols-header")C=3;else if(i==="two-cols-header")C=2;else{let A=0;for(const H of x){const E=(H.slot||"").match(/^col-(\d+)$/i);E&&(A=Math.max(A,parseInt(E[1],10)))}if(A>=2)C=A;else if((d=e.frontmatter)!=null&&d.layoutRatio){const H=e.frontmatter.layoutRatio.trim();if(H.includes(":")){const E=H.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);E.length>=2&&(C=E.length)}else{const E=H.split(/\s+/).filter(Boolean);E.length>=2&&(C=E.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(C=Math.min(6,x[0].children.length))}const M=xa(x,C),B=x.some(A=>A.slot&&/^(?:col-\d+|left|right)$/i.test(A.slot)),I=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Dn(i)&&B,w=A=>{const H=A.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(I&&H.length>0){const D=H[0],O=(D.rawMarkdown||D.content||"").trim();(zi(D)||/^(?:[-*+]|\d+\.)\s+/.test(O))&&(D.rawMarkdown=$n(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const E=I?H.find(no):null;return H.map(D=>pi(D,{...t,extraClassName:D===E?"slidev-col-first-heading-block":""})).join(`
`)},N=b.find(no),R=b.map(A=>pi(A,{...t,extraClassName:A===N?"slidev-page-first-heading-block":""})).join(`
`),z=h?"repeat(2, minmax(0, 1fr))":to((p=e.frontmatter)==null?void 0:p.layoutRatio,C),V=h?`style="grid-template-columns: ${z}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${z};"`,S=[h?"layout-clover-container":"layout-cols-header-container",C===2?"layout-two-cols-header-container":"",C===3?"layout-three-cols-header-container":"",`layout-${i}-container`,I?"has-superblock-cols":""].filter(Boolean).join(" "),F=[h?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",C===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",C===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",I?"has-superblock-cols":""].filter(Boolean).join(" "),k=M.map((A,H)=>{const E=H+1;return`<div class="${["pdf-col",C===2&&E===1?"pdf-col--left":"",C===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(A)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${R}</div>
        <div class="${F}" ${V}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const h=i==="image-right",b=s.map(I=>pi(I,t)).join(`
`),y=((g=e.frontmatter)==null?void 0:g.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${nt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,C=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,M=h?`${C}
${x}`:`${x}
${C}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${to((m=e.frontmatter)==null?void 0:m.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${M}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:s.map(h=>pi(h,{...t,extraClassName:h===l?"slidev-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function wm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const xm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=ya(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!xm.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=nt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return i[r]||""}),s}function Sm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(s=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function so(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Gr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${so(e)}</span>`;const i=[];function n(o,l){return i.push(`<span class="${o}">${so(l)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=so(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>i[parseInt(l,10)]||""),s}function _m(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Cm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=_m(c,d+1);p&&o.push(p)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const p=[];for(const g of c){const u=a(g.children,d+1);d>=n?p.push({...g,children:u}):p.push(...u)}return p}return a(l,1)}function $m(e,t=1,i={}){const n=Cm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const m=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?r(u.children,d+1):"";let b=rt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${m}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${p}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${o}>${a}</div>`}function pi(e,t){var B,I,w,N,R,z,V,S,F,k;let i="",n="",s="";const o=[];(B=e.motion)!=null&&B.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const l=((I=e.attributes)==null?void 0:I.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${nt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",p=`${r}${i}${s}${a}${d}`,g=(e.rawMarkdown||e.content||"").trim();if(!g)return`<div class="${p}"${n}></div>`;if(g.includes('class="slidev-block-ref"')||g.includes('class="slidev-ref-tag"'))return`<div class="${p}"${n}>${g}</div>`;if(g.startsWith("$$")&&g.endsWith("$$")){const A=g.slice(2,-2).trim();return`<div class="${p} katex-display-container"${n}><div class="katex-display font-math"><em>${nt(A)}</em></div></div>`}const u=g.match(/^(#{1,6})\s+(.*)$/);if(u){const A=u[1].length,H=rt(u[2]),D=!!(e.isColFirst||e.type==="i"&&((w=t==null?void 0:t.extraClassName)!=null&&w.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><h${A}${D}>${H}</h${A}></div>`}if(g.startsWith(":::")){const A=g.split(`
`),E=A[0].replace(/^:::\s*/,"").trim()||"info",D=A.slice(1,A[A.length-1].startsWith(":::")?-1:void 0).join(`
`),O=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${p}"${n}><div class="${O} ${O}--${E}"><div class="${O}-title">${E.toUpperCase()}</div><div class="${O}-body">${rt(D)}</div></div></div>`}if(g.startsWith("<<<")){const E=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((U,K)=>`<span class="code-line shiki-focus"><span class="line-no">${K+1}</span><span class="line-content">${Gr(U,"ts")}</span></span>`).join(`
`),D=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",O=((N=e.attrs)==null?void 0:N["custom-slidev-max-height"])||e.maxHeight||"",J=O?` style="max-height:${nt(O)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${D}"${J}><span class="lang-badge">TS</span><code>${E}</code></pre></div>`}if(g.startsWith("<style")||g.startsWith("<!-- Inline style -->")||g.startsWith(`<!--
Notes`))return"";if(g.startsWith("```")){const A=g.split(`
`),H=A[0].slice(3).trim(),E=H.match(/^([^\s{\[]+)/),D=E?E[1]:"",O=H.match(/\[([^\]]+)\]/),J=O?O[1]:"",U=H.includes("twoslash"),K=e.shikiLines||((R=H.match(/\{([^}]+)\}/))==null?void 0:R[1])||"",se=wm(K),ae=A.length>2?A[A.length-1]==="```"?A.slice(1,-1):A.slice(1):[g.slice(3).replace(/```$/,"")],ce=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ge=J?`${ce} has-filename`:ce,Te=se!=="all",we=ae.map((j,v)=>{const W=v+1,_=se==="all"||se.has(W)?"code-line shiki-focus":Te?"code-line shiki-dimmed":"code-line";let L=(t==null?void 0:t.highlight)===!0?Gr(j,D):nt(j);return U&&j.includes("doubled.value = 2")?(L=L.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${_}"><span class="line-no">${W}</span><span class="line-content">${L}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${_}"><span class="line-no">${W}</span><span class="line-content">${L}</span></span>`}).join(`
`),ue=D?`<span class="lang-badge">${nt(D)}</span>`:"",Y=J?`<span class="code-filename">${nt(J)}</span>`:"",fe=((z=e.attrs)==null?void 0:z["custom-slidev-max-height"])||e.maxHeight||"",P=fe?` style="max-height:${nt(fe)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${ge}"${P}>${Y}${ue}<code>${we}</code></pre></div>`}if(g.includes("|")&&g.split(`
`).filter(A=>A.trim().startsWith("|")).length>=2){const A=g.split(`
`).filter(E=>E.trim().startsWith("|")),H=Sm(A,t==null?void 0:t.tableClassName);return`<div class="${p}"${n}>${H}</div>`}if(g.startsWith("> ")){const A=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${p}"${n}><blockquote class="${A}"><p>${rt(g.slice(2))}</p></blockquote></div>`}const m=/<video\b/i.test(g)||e.type==="video"||e.type==="NodeVideo",h=/^(\s*)([-*+]|\d+\.)\s+/m.test(g),b=/(?:^|\n)\s*#{1,6}\s+/.test(g);if(m&&!h&&!b&&!g.includes(`
`)){const A=((V=e.attributes)==null?void 0:V["custom-slidev-autoplay"])==="true"||/autoplay/i.test(g),H=((S=e.attributes)==null?void 0:S["custom-slidev-loop"])==="true"||/loop/i.test(g),E=((F=e.attributes)==null?void 0:F["custom-slidev-muted"])==="true"||A||/muted/i.test(g),D=((k=e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",O=g.match(/\bsrc=["']([^"']+)["']/i),J=O?O[1]:"",U=['class="slide-video-player"'];D||U.push("controls"),A&&(U.push("autoplay"),U.push("playsinline")),H&&U.push("loop"),E&&U.push("muted"),U.push('preload="metadata"'),J&&U.push(`src="${J}"`);const K=g.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let se=K?K[1].trim():"";return!se&&J&&(se=`<source src="${J}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${A?"true":"false"}" data-muted="${E?"true":"false"}"${n}><video ${U.join(" ")}>${se}</video></div>`}const y=g.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const A=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${n}><img alt="${nt(y[1])}" src="${y[2]}" class="${A}" /></div>`}const x=Aa(g,t,e);if(x)return`<div class="${p} pdf-list-item"${n}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(g)&&!g.startsWith("```")){const A=g.match(/minDepth=["']?(\d+)["']?/i),H=g.match(/maxDepth=["']?(\d+)["']?/i),E=g.match(/columns=["']?(\d+)["']?/i),D=(t==null?void 0:t.allSlides)||[];return`<div class="${p}"${n}>${$m(D,(t==null?void 0:t.currentPageIndex)||1,{minDepth:A?parseInt(A[1],10):1,maxDepth:H?parseInt(H[1],10):1/0,columns:E?parseInt(E[1],10):1,textSm:g.includes("text-sm")})}</div>`}if(g.includes(`
`)||b){const A=km(g,t,e);if(A)return`<div class="${p}"${n}>${A}</div>`}const M=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><p${M}>${rt(g)}</p></div>`}function Im(e){return`
    ${Tn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function Tm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Em(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Am(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function Bm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function Mm(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function Dm(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function Lm(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function Pm(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function Om(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Rm(){return[Tm(),Em(),Am(),Bm(),Mm(),Dm(),Lm(),Pm(),Om()].join("")}function Ma(e,t){const i="Slidev 演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(i)}</title>
  <style>
${Im(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Rm()}
  <\/script>
</body>
</html>`}function Da(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function Nm(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function zm(e){const t=Nm(e==null?void 0:e.pageRatio);return`
    ${Tn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Fm(e,t){const i="Slidev 演示讲义",n="16:9",s="light",o=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=Ba(l),g=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(i)} - 高保真讲义</title>
  <style>
    ${zm({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function La(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=Fm(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Hm=1500,jm=500,Wm=4,Um=new Set(["INPUT","TEXTAREA","SELECT"]);function Pa(e){const t=e;return!t||!t.tagName?!1:Um.has(t.tagName)||t.isContentEditable===!0}function Vm(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){l(),t="",i=!1,o()}function a(){n&&clearTimeout(n),n=setTimeout(r,Hm)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,jm)}function d(p){if(e.isEnabled&&!e.isEnabled()||Pa(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=Wm||(t+=p.key,o(),a()),!0;if(p.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),m=e.getTotalPages();return!isNaN(u)&&u>=1&&m>0&&u<=m?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const Km={class:"spm-slidev-tab__toolbar"},Gm={class:"spm-slidev-tab__nav"},qm=["disabled"],Zm={class:"spm-page-badge"},Ym=["disabled"],Jm=["aria-label"],Xm=["aria-label"],Qm={class:"spm-slidev-tab__tools"},eg=["src"],tg=It({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=Lt("plugin"),n=Lt("sandboxBridge",new Fs),s=new vm(n),o=new tp,l=he("web-sandbox"),r=he(3030),a=he(null),c=he(!1),d=he(null),p=he(1),g=he(1),u=he(!1),m=he(!1),h=he("siyuan"),b=he(""),y=he(""),x=he(""),C=he(!1),M=he(!1),B=he(""),I=he(""),w=he(!1),N=Vm({getTotalPages:()=>g.value,isEnabled:()=>!u.value,onJump:T=>V(T),onStateChange:T=>{I.value=T.display,w.value=T.invalid}});function R(T){if(T.key==="o"||T.key==="O"){if(u.value||T.isComposing||T.ctrlKey||T.metaKey||T.altKey||Pa(T.target))return;T.preventDefault(),z();return}N.handleKeydown(T)&&T.preventDefault()}function z(){var T,_;if(l.value==="pro-cli"){(T=d.value)==null||T.focus(),me.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(_=d.value)==null||_.focus()}function V(T){var _;p.value=T,l.value==="pro-cli"?o.nativeBridge.navigateToPage(T):n.navigatePage(T),(_=d.value)==null||_.focus()}const S=he("/plugins/siyuan-slidev/slidev-client/index.html");let F=null,k=null,A=null,H=null,E=null,D=null,O=null,J=null;dn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),F=n.onSlideChanged((T,_)=>{p.value=T,g.value=_}),k=n.onBlockClicked((T,_)=>{p.value=_,s.setActiveBlockId(T),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(T,_):Ri(T,i==null?void 0:i.app)}),A=n.onOpenInEditor((T,_)=>{p.value=_,s.setActiveBlockId(T),Ri(T,i==null?void 0:i.app)}),H=o.nativeBridge.onPageChanged((T,_)=>{p.value=T,g.value=_}),E=n.onOpenPeekDrawer(async T=>{const _=zs();if(T.peekType==="siyuan"&&_.enableWebServeJump){let $=!1;if(J&&J.docId===T.target)$=!0;else if(J&&J.slides&&J.slides.some(L=>{var Z;return(Z=L.blocks)==null?void 0:Z.some(G=>G.id===T.target)}))$=!1;else try{const L=await nn(`SELECT id, root_id, type FROM blocks WHERE id = '${T.target}' LIMIT 1`);L&&L.length>0&&($=L[0].type==="d"||L[0].id===L[0].root_id)}catch(L){console.warn("[SlidevPreviewTab] detect block type failed:",L)}h.value="web",C.value=!0,y.value=ga(_.webServeUrl,T.target,{focus:!$}),x.value=T.title||`${$?"思源文档":"思源块"}: ${T.target.slice(0,8)}`,u.value=!0,n.freezeKeyboardNav(!0)}else{if(h.value=T.peekType,T.peekType==="siyuan")b.value=T.target,x.value=T.title||`块速览: ${T.target.slice(0,8)}`;else{const $=Ia(T.target);if($.external){Y(T.target);return}C.value=!0,y.value=$.url,x.value=T.title||$.url}u.value=!0,n.freezeKeyboardNav(!0)}}),D=n.onRequestToggleFullscreen(()=>{P()}),O=n.onOpenPresenter(()=>{j()}),typeof document<"u"&&document.addEventListener("fullscreenchange",fe)}),Ps(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",fe),E&&E(),D&&D(),O&&O(),F&&F(),k&&k(),A&&A(),H&&H(),n.detach(),N.clear(),s.destroy(),o.destroy()});async function U(){if(l.value==="web-sandbox"){if(!J){me.showMessage("请先在主编辑区打开演示文档");return}me.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const T=await o.startProMode(J,uo);if(!T.success){me.showMessage(`无法启动官方 Pro 模式：${T.error}`);return}l.value="pro-cli",r.value=T.port||3030,S.value=T.url,d.value&&o.nativeBridge.attach(d.value),me.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",S.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),me.showMessage("已切回内置高保真沙箱")}function K(){M.value=!M.value,M.value?(B.value=(J==null?void 0:J.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",B.value)):(B.value="",Te(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let se=0;function ae(T){if(u.value||Math.abs(T.deltaY)<Math.abs(T.deltaX)||Math.abs(T.deltaY)<15)return;const _=Date.now();_-se<280||(se=_,T.deltaY>0?ge():ce())}function ce(){if(p.value>1){const T=p.value-1;p.value=T,l.value==="pro-cli"?o.nativeBridge.navigateToPage(T):n.navigatePage(T)}}function ge(){if(p.value<g.value){const T=p.value+1;p.value=T,l.value==="pro-cli"?o.nativeBridge.navigateToPage(T):n.navigatePage(T)}}function Te(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function we(){u.value=!1,n.freezeKeyboardNav(!1)}function ue(){we()}function Y(T){var Z,G;const _=/^file:/i.test(T),$=_||/^[a-zA-Z]:[\\/]/.test(T),L=Ct("electron");if($&&typeof((Z=L==null?void 0:L.shell)==null?void 0:Z.openPath)=="function"){L.shell.openPath(_?$a(T):T),me.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((G=L==null?void 0:L.shell)==null?void 0:G.openExternal)=="function"?L.shell.openExternal(T).catch(()=>{typeof window<"u"&&window.open(T,"_blank")}):typeof window<"u"&&window.open(T,"_blank"),me.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function fe(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function P(){const T=a.value||d.value;T&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):T.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function j(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function v(){if(!J){me.showMessage("请先在主编辑区打开幻灯片文档");return}const T=Ma(J);Da("presentation.html",T)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function W(){if(!J){me.showMessage("请先在主编辑区打开幻灯片文档");return}La(J)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(T,_){M.value&&B.value&&_&&_!==B.value||(J=T,M.value&&!B.value&&(B.value=T.docId),g.value=T.slides.length,s.setDocId(T.docId),s.updateSlidesIndex(T.slides),l.value==="pro-cli"?o.scaffolder.scaffold(T,uo).catch(()=>{}):n.updateSlides(T.slides,T.config,T.fullMarkdown,T.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",T.docId))},navigateToBlock(T){s.onCursorFocusBlock(T)},isPinned:M,pinnedDocId:B,engineMode:l,toggleEngineMode:U}),(T,_)=>(Q(),te("div",{class:"spm-slidev-preview-tab",onKeydown:R},[f("div",Km,[f("div",Gm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:ce},[re(de,{name:"chevron-left"})],8,qm),f("span",Zm,xe(p.value)+" / "+xe(g.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=g.value,"aria-label":"下一页",onClick:ge},[re(de,{name:"chevron-right"})],8,Ym),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":M.value}]),"aria-label":M.value?"已锁定当前文档（点击解除）："+B.value:"点击锁定当前文档（不随主编辑区切换）",onClick:K},[re(de,{name:"pin"}),f("span",null,xe(M.value?"已锁定":"跟随"),1)],10,Jm),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:U},[re(de,{name:"rocket"}),f("span",null,xe(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Xm)]),f("div",Qm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:z},[re(de,{name:"columns"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:j},[re(de,{name:"presenter"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:v},[re(de,{name:"export-html"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:W},[re(de,{name:"export-pdf"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Te},[re(de,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:P},[re(de,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:ae},[f("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:S.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,eg),re(Eh,{visible:u.value,"onUpdate:visible":_[0]||(_[0]=$=>u.value=$),"is-maximized":m.value,"onUpdate:isMaximized":_[1]||(_[1]=$=>m.value=$),title:x.value,onClose:we},{default:zl(()=>[h.value==="siyuan"&&b.value?(Q(),Vt(Nh,{key:0,"block-id":b.value,title:x.value,plugin:be(i),onExternalJump:ue},null,8,["block-id","title","plugin"])):Le("",!0),C.value?Bt((Q(),Vt(mm,{key:1,visible:u.value&&h.value==="web",url:y.value,title:x.value,onExternalJump:ue},null,8,["visible","url","title"])),[[_o,h.value==="web"]]):Le("",!0)]),_:1},8,["visible","is-maximized","title"]),Bt(f("div",{class:_e(["spm-jump-badge",{"is-invalid":w.value}])},xe(I.value),3),[[_o,I.value]])],544)],32))}}),ig=Zt(tg,[["__scopeId","data-v-d46e0f5b"]]);function Oa(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&i.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const g=parseInt(p,10);s=Math.max(s,g),n.set(r.parentContainerId,g)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const p=n.get(r.parentContainerId);o(r,{type:"step",step:p})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const g=Math.min(Number(p[0]),Number(p[1])),u=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(g)&&!isNaN(u)){s=Math.max(s,u),o(r,{type:"range",min:g,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;s+=p,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;s=Math.max(1,s-p),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){s=Math.max(s,p),o(r,{type:"step",step:p});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function ng(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ao=980;function sg(e){if(!e)return 0;const i=Oa(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=Uc(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function og(e,t=Ao){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",l=i.split(o).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function qr(e,t,i=Ao,n=552,s=16){const o=i>0?i:Ao,l=n>0?n:552,r=Math.max(0,e-s),a=Math.max(0,t-s);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/o,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(l*d))}}function rg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function Zr(e,t){if(!e)return"";const i=rg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?Oa(i.blocks||[]):null,d=Ba(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:a?C=>{if(ng(C,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const B=C.id||C.blockId,I=a.blockMap.get(C)||(B?a.idMap.get(B):void 0);if((I==null?void 0:I.type)==="step"&&I.step===r||(I==null?void 0:I.type)==="range"&&I.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(C,M)=>{let B=M.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(B)||(B+=" muted"),`<video ${B.trim()}>`}),p=n.spacing,g=p&&p!=="inherit"?p:o.spacing||"normal",u=["slide-content",`layout-${s}`,`spacing-${g}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),m=[],h=(n.background||"").trim();if(h)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(h)){const C=h.startsWith("assets/")?`/${h}`:h.startsWith("./assets/")?h.slice(1):h;m.push(`background-image:url('${nt(C)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else m.push(`background:${nt(h)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&m.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=m.length>0?` style="${m.join("")}"`:"";return`<div class="${nt(u)}"${x}>${d}</div>`}const lg={class:"presenter-header"},ag={class:"presenter-title-area"},cg={class:"presenter-brand"},dg={class:"header-pills"},ug={class:"pill pill-page"},fg={key:0,class:"pill pill-step"},pg={class:"header-toolbar"},hg={class:"timer-capsule"},mg={class:"timer-digits"},gg={class:"timer-actions"},vg=["aria-label"],bg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},yg={key:0,class:"presenter-grid"},kg={class:"slide-panels"},wg={class:"panel-box current-slide-panel"},xg={class:"panel-header"},Sg={class:"panel-header-left"},_g={class:"panel-page-num"},Cg={class:"panel-header-meta"},$g={key:0,class:"panel-step-pill"},Ig={class:"panel-layout-pill"},Tg=["aria-label"],Eg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Ag={key:1,class:"panel-fallback"},Bg=["aria-label"],Mg={class:"panel-header"},Dg={class:"panel-header-left"},Lg={key:0,class:"panel-page-num"},Pg={class:"panel-header-meta"},Og={key:0,class:"panel-end-pill"},Rg={key:1,class:"panel-layout-pill"},Ng=["aria-label"],zg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Fg={key:1,class:"panel-fallback"},Hg={class:"notes-panel"},jg={class:"panel-header"},Wg={class:"panel-header-left"},Ug={class:"notes-size-controls"},Vg=["disabled"],Kg={class:"notes-size-value"},Gg=["disabled"],qg={key:1,class:"presenter-empty"},Zg={class:"empty-icon-wrap"},Yg={class:"empty-actions"},Jg={class:"presenter-actions"},Xg={class:"nav-btn-group"},Qg=["disabled"],ev=["disabled"],tv={class:"actions-center"},iv={class:"center-meta"},nv={class:"progress-pill"},sv={class:"nav-btn-group"},ov=["aria-label"],rv={class:"step-dots-text"},lv=["disabled"],av=["disabled"],cv=280,dv=15,uv=It({__name:"SlidevPresenterTab",setup(e,{expose:t}){const i=Lt("plugin"),n=Lt("sandboxBridge",new Fs),s=he([]),o=he({}),l=he(1),r=he(0),a=he(0),c=he(0),d=ke(()=>s.value.length||a.value),p=he(null),g=he(null),u=he({width:0,height:0}),m=he({width:0,height:0}),h=ke(()=>{var ie;return og((ie=o.value)==null?void 0:ie.aspectRatio)}),b=ke(()=>{var ie;return((ie=o.value)==null?void 0:ie.theme)||"default"}),y=ke(()=>{var ie;return((ie=o.value)==null?void 0:ie.colorSchema)==="light"?"light":"dark"}),x=ke(()=>{var ie;return!!((ie=o.value)!=null&&ie.normalizeHeadingSizes)}),C=ke(()=>qr(u.value.width,u.value.height,h.value.baseWidth,h.value.baseHeight,14)),M=ke(()=>qr(m.value.width,m.value.height,h.value.baseWidth,h.value.baseHeight,14));function B(){p.value&&(u.value={width:p.value.clientWidth,height:p.value.clientHeight}),g.value&&(m.value={width:g.value.clientWidth,height:g.value.clientHeight})}let I=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(I||(I=new window.ResizeObserver(()=>{B()})),I.disconnect(),p.value&&I.observe(p.value),g.value&&I.observe(g.value))}Oi([p,g,d],()=>{vs(()=>{w(),B()})},{flush:"post"});const N=he(0),R=he(!0);let z=null;const V=ke(()=>{const ie=String(Math.floor(N.value/60)).padStart(2,"0"),ne=String(N.value%60).padStart(2,"0");return`${ie}:${ne}`});function S(){R.value=!R.value}function F(){N.value=0}const k=he("");let A=null;function H(){const ie=new Date,ne=String(ie.getHours()).padStart(2,"0"),Ce=String(ie.getMinutes()).padStart(2,"0");k.value=`${ne}:${Ce}`}const E=ke(()=>s.value.length===0?null:s.value[l.value-1]||null),D=ke(()=>l.value>=s.value.length?null:s.value[l.value]||null),O=ke(()=>E.value?sg(E.value):c.value),J=ke(()=>l.value>1||r.value>0),U=ke(()=>l.value<d.value||r.value<O.value),K=ke(()=>Zr(E.value,{config:o.value,allSlides:s.value,pageIndex:l.value,currentStep:r.value})),se=ke(()=>Zr(D.value,{config:o.value,allSlides:s.value,pageIndex:l.value+1})),ae=ke(()=>{var ne;if(!E.value)return"无内容";const ie=(ne=E.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value} 页`});function ce(ie){return(ie||[]).slice(1).map(ne=>(ne.content||ne.rawMarkdown||"").trim()).filter(ne=>ne&&!/^(image\s+)?assets\/\S*$/i.test(ne)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ne)).join(" | ").slice(0,120)}const ge=ke(()=>{var ie;return ce((ie=E.value)==null?void 0:ie.blocks)}),Te=ke(()=>{var ne;if(!D.value)return"演示结束";const ie=(ne=D.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value+1} 页`}),we=ke(()=>D.value?ce(D.value.blocks):"这是最后一页"),ue=ke(()=>{var ie;return((ie=E.value)==null?void 0:ie.notes)||""}),Y=he(20);function fe(){Y.value<36&&(Y.value+=2)}function P(){Y.value>14&&(Y.value-=2)}const j=ke(()=>d.value<=1?100:Math.round(l.value/d.value*100));let v=null;try{v=new BroadcastChannel("siyuan-slidev-sync"),v.onmessage=ie=>{const ne=ie.data;if(ne&&(ne.type==="SYNC_PAGE"&&typeof ne.page=="number"&&(l.value=ne.page,r.value=typeof ne.step=="number"?Math.max(0,ne.step):0,typeof ne.maxStep=="number"&&(c.value=Math.max(0,ne.maxStep))),ne.type==="SYNC_SLIDES"&&Array.isArray(ne.slides)&&(s.value=ne.slides,ne.config&&typeof ne.config=="object"&&(o.value=ne.config)),ne.type==="REQUEST_SYNC"&&s.value.length>0))try{v==null||v.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),v==null||v.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:O.value})}catch{}}}catch{v=null}function W(ie,ne=0){const Ce=Number(ie)||1,Be=Math.max(0,Number(ne)||0);n.navigatePage(Ce,Be);try{v==null||v.postMessage({type:"SYNC_PAGE",page:Ce,step:Be,maxStep:O.value})}catch{}}function T(){if(r.value<O.value){r.value++,W(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,W(l.value,0))}function _(){if(r.value>0){r.value--,W(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,W(l.value,0))}function $(){l.value<d.value&&(l.value++,r.value=0,W(l.value,0))}function L(){l.value>1&&(l.value--,r.value=0,W(l.value,0))}function Z(){l.value=1,r.value=0,F(),W(1,0)}function G(){const ie=i;typeof(ie==null?void 0:ie.openBottomPreviewTab)=="function"&&ie.openBottomPreviewTab()}function q(){const ie=i;typeof(ie==null?void 0:ie.openStandalonePreviewWindow)=="function"&&ie.openStandalonePreviewWindow()}function ee(ie){var ne,Ce;if(!(ie.key===" "&&((Ce=(ne=ie.target)==null?void 0:ne.closest)!=null&&Ce.call(ne,"button")))){if(ie.shiftKey&&ie.key==="ArrowRight"||ie.key==="ArrowDown"){ie.preventDefault(),$();return}if(ie.shiftKey&&ie.key==="ArrowLeft"||ie.key==="ArrowUp"){ie.preventDefault(),L();return}ie.key==="ArrowRight"||ie.key===" "||ie.key==="PageDown"?(ie.preventDefault(),T()):(ie.key==="ArrowLeft"||ie.key==="PageUp")&&(ie.preventDefault(),_())}}let le=0;function oe(ie){var Be,Ne;if(Math.abs(ie.deltaY)<dv)return;const ne=(Ne=(Be=ie.target)==null?void 0:Be.closest)==null?void 0:Ne.call(Be,".notes-content");if(ne){const Re=ne.scrollHeight-ne.clientHeight;if(Re>2&&(ie.deltaY>0&&ne.scrollTop<Re-1||ie.deltaY<0&&ne.scrollTop>1))return}const Ce=Date.now();Ce-le<cv||(le=Ce,ie.deltaY>0?T():_())}let pe=null;return dn(()=>{var ne;z=window.setInterval(()=>{R.value&&N.value++},1e3),H(),A=window.setInterval(H,1e3),pe=n.onSlideChanged((Ce,Be,Ne,Re,De)=>{l.value=Ce,Be>0&&(a.value=Be),typeof Re=="number"&&(r.value=Math.max(0,Re)),typeof De=="number"&&(c.value=Math.max(0,De))});try{v==null||v.postMessage({type:"REQUEST_SYNC"})}catch{}const ie=i==null?void 0:i.latestCompiledDoc;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides,ie.config&&(o.value=ie.config)),typeof window<"u"&&window.addEventListener("resize",B),vs(()=>{w(),B()})}),Ps(()=>{z&&(window.clearInterval(z),z=null),A&&(window.clearInterval(A),A=null),pe&&pe(),typeof window<"u"&&window.removeEventListener("resize",B),I&&(I.disconnect(),I=null);try{v==null||v.close()}catch{}v=null}),t({updateDocument(ie){var ne;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides),ie!=null&&ie.config&&(o.value=ie.config)}}),(ie,ne)=>{var Ce,Be,Ne;return Q(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:ee,onWheel:oe},[f("header",lg,[f("div",ag,[f("div",cg,[re(de,{name:"presenter",class:"brand-icon"}),ne[1]||(ne[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",dg,[f("span",ug,"P."+xe(l.value)+" / "+xe(d.value||1),1),O.value>0?(Q(),te("span",fg,[re(de,{name:"step",class:"pill-icon"}),St(" 步进 "+xe(r.value)+" / "+xe(O.value),1)])):Le("",!0)])]),f("div",pg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:q},[re(de,{name:"window"}),ne[2]||(ne[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",hg,[re(de,{name:"clock",class:"timer-icon"}),f("span",mg,xe(V.value),1),f("div",gg,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":R.value?"暂停计时":"继续计时",onClick:S},[re(de,{name:R.value?"pause":"play"},null,8,["name"])],8,vg),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:F},[re(de,{name:"reset"})])])]),f("div",bg,[f("span",null,xe(k.value),1)])])]),d.value>0?(Q(),te("main",yg,[f("section",kg,[f("div",wg,[f("div",xg,[f("div",Sg,[ne[3]||(ne[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",_g,"P."+xe(l.value),1)]),f("div",Cg,[O.value>0?(Q(),te("span",$g," 步进 "+xe(r.value)+" / "+xe(O.value),1)):Le("",!0),f("span",Ig,xe(((Be=(Ce=E.value)==null?void 0:Ce.frontmatter)==null?void 0:Be.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":ae.value},[E.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:Ut({width:C.value.boxWidth+"px",height:C.value.boxHeight+"px"})},[f("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Ut({width:h.value.baseWidth+"px",height:h.value.baseHeight+"px",transform:"scale("+C.value.scale+")"}),innerHTML:K.value},null,14,Eg)],4)):(Q(),te("div",Ag,[f("h2",null,xe(ae.value),1),f("p",null,xe(ge.value),1)]))],8,Tg)]),f("div",{class:_e(["panel-box next-slide-panel",{"is-clickable":!!D.value,"b3-tooltips b3-tooltips__n":!!D.value}]),"aria-label":D.value?"点击直接跳至下一页":"",onClick:ne[0]||(ne[0]=Re=>D.value&&$())},[f("div",Mg,[f("div",Dg,[ne[4]||(ne[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<d.value?(Q(),te("span",Lg,"P."+xe(l.value+1),1)):Le("",!0)]),f("div",Pg,[l.value>=d.value?(Q(),te("span",Og,"已到尾页")):D.value?(Q(),te("span",Rg,xe(((Ne=D.value.frontmatter)==null?void 0:Ne.layout)||"default"),1)):Le("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:g,class:"panel-preview panel-preview--dim","aria-label":Te.value},[D.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:Ut({width:M.value.boxWidth+"px",height:M.value.boxHeight+"px"})},[f("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Ut({width:h.value.baseWidth+"px",height:h.value.baseHeight+"px",transform:"scale("+M.value.scale+")"}),innerHTML:se.value},null,14,zg)],4)):(Q(),te("div",Fg,[f("h2",null,xe(Te.value),1),f("p",null,xe(we.value),1)]))],8,Ng)],10,Bg)]),f("section",Hg,[f("div",jg,[f("div",Wg,[re(de,{name:"notes",class:"panel-title-icon"}),ne[5]||(ne[5]=f("span",null,"讲稿备忘",-1))]),f("div",Ug,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:Y.value<=14,onClick:P},[re(de,{name:"minus"})],8,Vg),f("span",Kg,xe(Y.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:Y.value>=36,onClick:fe},[re(de,{name:"plus"})],8,Gg)])]),f("div",{class:_e(["notes-content",{"is-empty":!ue.value}]),style:Ut({fontSize:Y.value+"px"})},xe(ue.value||"（本页未设置演讲者备忘录）"),7)])])):(Q(),te("main",qg,[f("div",Zg,[re(de,{name:"refresh",class:"empty-icon"})]),ne[8]||(ne[8]=f("h2",null,"等待大屏放映数据",-1)),ne[9]||(ne[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",Yg,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:G},[re(de,{name:"presenter"}),ne[6]||(ne[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:q},[re(de,{name:"window"}),ne[7]||(ne[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",Jg,[f("div",Xg,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:L},[re(de,{name:"chevrons-left"}),ne[10]||(ne[10]=f("span",null,"上一页",-1))],8,Qg),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!J.value,"aria-label":"回退一步 (←)",onClick:_},[re(de,{name:"chevron-left"}),ne[11]||(ne[11]=f("span",null,"上一步",-1))],8,ev)]),f("div",tv,[f("div",iv,[f("span",nv,xe(j.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Z},[re(de,{name:"reset"}),ne[12]||(ne[12]=f("span",null,"重头放映",-1))])]),f("div",sv,[O.value>0?(Q(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${O.value}`},[(Q(!0),te(Ke,null,kt(O.value,Re=>(Q(),te("span",{key:Re,class:_e(["step-dot",{"is-active":Re<=r.value}])},null,2))),128)),f("span",rv,xe(r.value)+"/"+xe(O.value),1)],8,ov)):Le("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!U.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:T},[ne[13]||(ne[13]=f("span",null,"下一步",-1)),re(de,{name:"chevron-right"})],8,lv),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:$},[ne[14]||(ne[14]=f("span",null,"下一页",-1)),re(de,{name:"chevrons-right"})],8,av)])])],32)}}}),fv=Zt(uv,[["__scopeId","data-v-aa1ee0a8"]]),pv={class:"spm-layout-picker"},hv={class:"spm-layout-picker__grid"},mv=["title","onClick"],gv={class:"spm-layout-icon"},vv={class:"spm-layout-label"},bv=It({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(Q(),te("div",pv,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",hv,[(Q(),te(Ke,null,kt(s,c=>f("div",{key:c.name,class:_e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[f("div",gv,[re(de,{name:"layout-"+c.name},null,8,["name"])]),f("span",vv,xe(c.label),1)],10,mv)),64))])]))}}),yv=Zt(bv,[["__scopeId","data-v-1964d02c"]]),kv={key:0,class:"spm-transition-selector__header"},wv={class:"spm-transition-list"},xv=["onClick"],Sv={class:"spm-transition-meta"},_v={class:"spm-transition-label"},Cv={class:"spm-transition-name"},$v={class:"spm-transition-preview-box"},Iv=It({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,l)=>(Q(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Le("",!0):(Q(),te("div",kv,xe(e.title||"转场动效"),1)),f("div",wv,[(Q(),te(Ke,null,kt(n,r=>f("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>s(r.name)},[f("div",Sv,[f("span",_v,xe(r.label),1),f("span",Cv,"("+xe(r.name)+")",1)]),f("div",$v,[f("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,xv)),64))])],2))}}),Ra=Zt(Iv,[["__scopeId","data-v-8597e99e"]]),Tv={class:"spm-section spm-section--page"},Ev={class:"spm-section-header"},Av={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Bv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Mv={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Dv={key:1,class:"spm-card-control"},Lv={class:"spm-control-header"},Pv={class:"spm-control-title-group"},Ov={class:"spm-control-title"},Rv={class:"spm-quick-chips"},Nv=["onClick"],zv={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Fv=["value"],Hv=["aria-label"],jv={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Wv={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Uv={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Vv={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Kv={class:"spm-card-control"},Gv={class:"spm-control-header"},qv={class:"spm-control-title-group"},Zv={class:"spm-control-title"},Yv={class:"spm-segmented-group"},Jv={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Xv={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Qv={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},eb={class:"spm-quick-chips"},tb=["onClick"],ib={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},nb=["value"],sb={style:{display:"flex",gap:"8px","margin-top":"2px"}},ob={style:{flex:"1"}},rb={class:"spm-segmented-group"},lb={style:{flex:"1"}},ab={class:"spm-segmented-group"},cb={class:"spm-card-control"},db={class:"spm-control-header"},ub={class:"spm-control-title-group"},fb={class:"spm-control-title"},pb={class:"spm-segmented-group"},hb={class:"spm-card-control"},mb={class:"spm-control-header"},gb={class:"spm-control-title-group"},vb={class:"spm-control-title"},bb={class:"spm-quick-chips"},yb=["onClick"],kb=["value"],wb={key:2,class:"spm-card-control"},xb={class:"spm-control-header"},Sb={class:"spm-control-title-group"},_b={class:"spm-control-title"},Cb={class:"spm-quick-chips"},$b=["onClick"],Ib=["value"],Tb={class:"spm-card-control"},Eb={class:"spm-control-header"},Ab={class:"spm-control-title-group"},Bb={class:"spm-control-title"},Mb={key:0,class:"spm-note-status-box"},Db=["title"],Lb={class:"spm-action-grid",style:{"margin-top":"6px"}},Pb={key:1,class:"spm-note-empty-box"},Ob={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Rb={class:"spm-action-grid"},Nb=["disabled"],zb=["disabled"],Fb={class:"spm-card-control"},Hb={class:"spm-action-grid"},jb=It({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ke(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=ke(()=>{var h,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const y=u.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}const m=(i.detectedSbRatio||"").trim();if(m.includes(":")){const y=m.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}if((h=i.detectedSbInfo)!=null&&h.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const y=i.detectedSbInfo.slots.length;if(y>=2&&y<=6)return y}return 2}),r=ke(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=ke(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,m=Array(u).fill("1").join(":");n("update:pageLayoutRatio",m),n("resetSuperblockRatio")}const d=ke(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),p=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],g=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,m)=>(Q(),te("div",Tv,[f("div",Ev,[f("span",null,"幻灯片页面设置"+xe(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(yv,{"model-value":e.pageLayout,onChange:m[0]||(m[0]=h=>u.$emit("update:pageLayout",h))},null,8,["model-value"]),!o.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(Q(),te("div",Av,[f("div",Bv,[f("div",Mv,[re(de,{name:"sparkles"}),f("span",null,[m[31]||(m[31]=St("检测到本页横向超级块列宽比例：",-1)),f("b",null,xe(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:m[1]||(m[1]=h=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(de,{name:"columns"}),m[32]||(m[32]=f("span",null,"设为分栏",-1))])])])):Le("",!0),o.value?(Q(),te("div",Dv,[f("div",Lv,[f("div",Pv,[f("div",Ov,[re(de,{name:"ratio"}),m[33]||(m[33]=f("span",null,"分栏比例 (Ratio)",-1))]),m[34]||(m[34]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",Rv,[(Q(!0),te(Ke,null,kt(r.value,h=>(Q(),te("button",{key:h.value,class:_e(["spm-chip",{active:a.value===h.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",h.value)},xe(h.label),11,Nv))),128))]),f("div",zv,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:m[2]||(m[2]=h=>u.$emit("update:pageLayoutRatio",h.target.value)),onChange:m[3]||(m[3]=h=>u.$emit("update:pageLayoutRatio",h.target.value))},null,40,Fv),e.detectedSbRatio?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m[4]||(m[4]=h=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(de,{name:"sparkles"}),m[35]||(m[35]=f("span",null,"读取",-1))],8,Hv)):(Q(),te("button",jv,[re(de,{name:"sparkles"}),m[36]||(m[36]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[re(de,{name:"reset"}),m[37]||(m[37]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(Q(),te("div",Wv,[re(de,{name:"ratio"}),m[38]||(m[38]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",Uv,xe(e.detectedSbRatio),1)])):(Q(),te("div",Vv,[re(de,{name:"ratio"}),m[39]||(m[39]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Le("",!0),re(Ra,{"model-value":e.pageTransition,onChange:m[5]||(m[5]=h=>u.$emit("update:pageTransition",h))},null,8,["model-value"]),f("div",Kv,[f("div",Gv,[f("div",qv,[f("div",Zv,[re(de,{name:"sparkles"}),m[40]||(m[40]=f("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),m[41]||(m[41]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",Yv,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:m[6]||(m[6]=h=>u.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:m[7]||(m[7]=h=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:m[8]||(m[8]=h=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(Q(),te("div",Jv,[f("div",Xv,[m[43]||(m[43]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",Qv,[re(de,{name:"help"}),m[42]||(m[42]=f("span",null,"输入规则",-1))])]),f("div",eb,[(Q(),te(Ke,null,kt(s,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===h.value}]),onClick:b=>u.$emit("update:pageMaskRatio",h.value)},xe(h.label),11,tb)),64))]),f("div",ib,[f("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:m[9]||(m[9]=h=>u.$emit("update:pageMaskRatio",h.target.value)),onChange:m[10]||(m[10]=h=>u.$emit("update:pageMaskRatio",h.target.value))},null,40,nb)]),m[46]||(m[46]=f("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),f("div",sb,[f("div",ob,[m[44]||(m[44]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",rb,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:m[11]||(m[11]=h=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:m[12]||(m[12]=h=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",lb,[m[45]||(m[45]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",ab,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:m[13]||(m[13]=h=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:m[14]||(m[14]=h=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Le("",!0)]),f("div",cb,[f("div",db,[f("div",ub,[f("div",fb,[re(de,{name:"ratio"}),m[47]||(m[47]=f("span",null,"页面间距 (Spacing)",-1))]),m[48]||(m[48]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",pb,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:m[15]||(m[15]=h=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:m[16]||(m[16]=h=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:m[17]||(m[17]=h=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:m[18]||(m[18]=h=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",hb,[f("div",mb,[f("div",gb,[f("div",vb,[re(de,{name:"palette"}),m[49]||(m[49]=f("span",null,"页面背景 (Background)",-1))]),m[50]||(m[50]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",bb,[(Q(),te(Ke,null,kt(p,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:e.pageBackground===h.value}]),onClick:b=>u.$emit("update:pageBackground",h.value)},xe(h.label),11,yb)),64))]),f("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:m[19]||(m[19]=h=>u.$emit("update:pageBackground",h.target.value)),onChange:m[20]||(m[20]=h=>u.$emit("update:pageBackground",h.target.value))},null,40,kb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(Q(),te("div",wb,[f("div",xb,[f("div",Sb,[f("div",_b,[re(de,{name:"image"}),m[51]||(m[51]=f("span",null,"页面图片 (Image)",-1))]),m[52]||(m[52]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Cb,[(Q(),te(Ke,null,kt(g,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:e.pageImage===h.value}]),onClick:b=>u.$emit("update:pageImage",h.value)},xe(h.label),11,$b)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:m[21]||(m[21]=h=>u.$emit("update:pageImage",h.target.value)),onChange:m[22]||(m[22]=h=>u.$emit("update:pageImage",h.target.value))},null,40,Ib)])):Le("",!0),f("div",Tb,[f("div",Eb,[f("div",Ab,[f("div",Bb,[re(de,{name:"presenter"}),m[53]||(m[53]=f("span",null,"演讲者提词 (Notes)",-1))]),m[54]||(m[54]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),f("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:m[23]||(m[23]=h=>u.$emit("generateNotes"))},[re(de,{name:"sparkles"}),m[55]||(m[55]=f("span",null,"AI 讲稿",-1))])]),e.pageNotes?(Q(),te("div",Mb,[m[58]||(m[58]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},xe(d.value),9,Db),f("div",Lb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:m[24]||(m[24]=h=>u.$emit("locateNoteBlock"))},[re(de,{name:"search"}),m[56]||(m[56]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:m[25]||(m[25]=h=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),m[57]||(m[57]=f("span",null,"追加讲稿块",-1))])])])):(Q(),te("div",Pb,[m[60]||(m[60]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:m[26]||(m[26]=h=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),m[59]||(m[59]=f("span",null,"添加讲稿备注块",-1))])])),f("div",Ob,[f("div",Rb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Ut(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:m[27]||(m[27]=h=>u.$emit("batchAppendNotes"))},[re(de,{name:"insert-below"}),m[61]||(m[61]=f("span",null,"全部追加",-1))],12,Nb),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Ut(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:m[28]||(m[28]=h=>u.$emit("batchDeleteNotes"))},[re(de,{name:"trash"}),m[62]||(m[62]=f("span",null,"全部删除",-1))],12,zb)])])]),f("div",Fb,[m[65]||(m[65]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",Hb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:m[29]||(m[29]=h=>u.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),m[63]||(m[63]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:m[30]||(m[30]=h=>u.$emit("deleteDivider"))},[re(de,{name:"trash"}),m[64]||(m[64]=f("span",null,"删除此页",-1))])])])]))}}),Wb=Zt(jb,[["__scopeId","data-v-1f9d4630"]]),Ub={class:"spm-section spm-section--block"},Vb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Kb={class:"spm-control-header"},Gb={class:"spm-control-title-group"},qb={class:"spm-control-title"},Zb={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Yb={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Jb={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Xb={key:0},Qb={key:1},e1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},t1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},i1={class:"spm-action-grid"},n1={class:"spm-card-control"},s1={class:"spm-control-header"},o1={class:"spm-control-title-group"},r1={class:"spm-control-title"},l1=["aria-label"],a1=["checked"],c1={key:1,class:"spm-card-control"},d1={class:"spm-control-header"},u1={class:"spm-control-title-group"},f1={class:"spm-control-title"},p1={class:"spm-quick-chips"},h1={key:2,class:"spm-card-control"},m1={class:"spm-control-header"},g1={class:"spm-control-title-group"},v1={class:"spm-control-title"},b1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},y1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},k1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},w1=["aria-label"],x1=["checked"],S1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},C1=["aria-label"],$1=["checked"],I1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},T1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},E1=["aria-label"],A1=["checked"],B1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},M1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},D1=["aria-label"],L1=["checked"],P1={class:"spm-card-control"},O1={class:"spm-control-header"},R1={class:"spm-control-title-group"},N1={class:"spm-control-title"},z1=["aria-label"],F1=["checked"],H1={key:0,class:"spm-quick-chips"},j1=["onClick"],W1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},U1={class:"spm-card-control"},V1={class:"spm-control-header"},K1={class:"spm-control-title-group"},G1={class:"spm-control-title"},q1=["aria-label"],Z1=["checked"],Y1={key:0,class:"spm-quick-chips"},J1=["onClick"],X1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Q1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},ey={style:{display:"flex",gap:"6px"}},ty=["value"],iy=["value"],ny={key:3,class:"spm-card-control"},sy={class:"spm-control-header"},oy={class:"spm-control-title-group"},ry={class:"spm-control-title"},ly={class:"spm-control-desc"},ay={class:"spm-segmented-group"},cy=["onClick"],dy={key:4,class:"spm-card-control"},uy={class:"spm-control-header"},fy={class:"spm-control-title-group"},py={class:"spm-control-title"},hy={class:"spm-quick-chips"},my=["onClick"],gy=["value"],vy={key:5,class:"spm-card-control"},by={class:"spm-control-header"},yy={class:"spm-control-title-group"},ky={class:"spm-control-title"},wy={class:"spm-quick-chips"},xy=["onClick"],Sy=["value"],_y={class:"spm-card-control"},Cy={class:"spm-action-grid"},$y=["aria-label"],Iy=It({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ke(()=>{const I=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":I}),s=ke(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),o=ke(()=>{var w,N,R,z;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const I=(N=i.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(I){const V=parseInt(I[1],10);if(V>=2&&V<=6)return Math.max(V,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((z=(R=i.detectedSbInfo)==null?void 0:R.ratio)!=null&&z.includes(":")){const V=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(V.length>=2)return Math.min(V.length,6)}return 3}),l=ke(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=ke(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ke(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let R=1;R<=w;R++)N.push({value:`col-${R}`,label:`第 ${R} 栏`});return N});function c(I){const w=i.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&o.value===3||I==="col-2"&&w==="right"&&o.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=ke(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const I=JSON.parse(i.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=ke(()=>!!g.value),m=ke(()=>{var I;return((I=g.value)==null?void 0:I.preset)||"slide-up"}),h=ke(()=>{var I;return((I=g.value)==null?void 0:I.duration)||0}),b=ke(()=>{var I;return((I=g.value)==null?void 0:I.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(I){B(I,h.value,b.value)}function C(I){B(m.value,I,b.value)}function M(I){B(m.value,h.value,I)}function B(I,w,N){if(!I||I==="none"){d("update:elemMotion","");return}if(!w&&!N){d("update:elemMotion",I);return}const R={preset:I};w>0&&(R.duration=w),N>0&&(R.delay=N),d("update:elemMotion",JSON.stringify(R))}return(I,w)=>{var N,R,z,V,S,F;return Q(),te("div",Ub,[w[62]||(w[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(N=e.detectedSbInfo)!=null&&N.hasSuperBlock?(Q(),te("div",Vb,[f("div",Kb,[f("div",Gb,[f("div",qb,[re(de,{name:"ratio"}),w[24]||(w[24]=f("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",Zb,[f("div",Yb,[f("div",Jb,[re(de,{name:"ratio"}),(R=e.detectedSbInfo)!=null&&R.isCustomWidth?(Q(),te("span",Xb,"已识别自定义列宽比例")):(Q(),te("span",Qb,"识别到 "+xe(((z=e.detectedSbInfo)==null?void 0:z.colCount)||2)+" 列超级块分栏",1))]),f("code",e1,xe(((V=e.detectedSbInfo)==null?void 0:V.ratio)||"1:1"),1)]),f("div",t1,xe((S=e.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",i1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>I.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(de,{name:"sparkles"}),w[26]||(w[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var A;return I.$emit("applySuperBlockRatio",((A=e.detectedSbInfo)==null?void 0:A.ratio)||"1:1")})},[re(de,{name:"check"}),f("span",null,"应用比例 ("+xe(((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1")+")",1)])])])):Le("",!0),f("div",n1,[f("div",s1,[f("div",o1,[f("div",r1,[re(de,{name:"presenter"}),w[27]||(w[27]=f("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>I.$emit("toggleNote"))},null,40,a1),w[29]||(w[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,l1)])]),e.isImage||e.imageRole?(Q(),te("div",c1,[f("div",d1,[f("div",u1,[f("div",f1,[re(de,{name:"image"}),w[30]||(w[30]=f("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",p1,[f("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>I.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>I.$emit("update:imageRole","background"))},[re(de,{name:"image"}),w[32]||(w[32]=f("span",null,"背景图",-1))],2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>I.$emit("update:imageRole","image-left"))},[re(de,{name:"image-left"}),w[33]||(w[33]=f("span",null,"图左",-1))],2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>I.$emit("update:imageRole","image-right"))},[re(de,{name:"image-right"}),w[34]||(w[34]=f("span",null,"图右",-1))],2)])])):Le("",!0),e.isVideo?(Q(),te("div",h1,[f("div",m1,[f("div",g1,[f("div",v1,[re(de,{name:"video"}),w[35]||(w[35]=f("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",b1,[f("div",y1,[f("span",k1,[re(de,{name:"sliders"}),w[37]||(w[37]=St(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>I.$emit("toggleVideoControls"))},null,40,x1),w[38]||(w[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,w1)]),f("div",S1,[f("span",_1,[re(de,{name:"video"}),w[39]||(w[39]=St(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>I.$emit("toggleVideoAutoplay"))},null,40,$1),w[40]||(w[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,C1)]),f("div",I1,[f("span",T1,[re(de,{name:"repeat"}),w[41]||(w[41]=St(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>I.$emit("toggleVideoLoop"))},null,40,A1),w[42]||(w[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,E1)]),f("div",B1,[f("span",M1,[re(de,{name:"volume-x"}),w[43]||(w[43]=St(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>I.$emit("toggleVideoMuted"))},null,40,L1),w[44]||(w[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,D1)])])])):Le("",!0),f("div",P1,[f("div",O1,[f("div",R1,[f("div",N1,[re(de,{name:"step"}),w[45]||(w[45]=f("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>I.$emit("toggleElemClick"))},null,40,F1),w[47]||(w[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,z1)]),e.elemClick?(Q(),te("div",H1,[(Q(),te(Ke,null,kt(["+1","1","2","hide"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemClick===k}]),onClick:A=>I.$emit("update:elemClick",k)},xe(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,j1)),64))])):e.parentElemClick?(Q(),te("div",W1,[re(de,{name:"check"}),w[48]||(w[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Le("",!0)]),f("div",U1,[f("div",V1,[f("div",K1,[f("div",G1,[re(de,{name:"motion"}),w[49]||(w[49]=f("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[f("input",{type:"checkbox",checked:u.value,onChange:y},null,40,Z1),w[51]||(w[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,q1)]),u.value?(Q(),te("div",Y1,[(Q(),te(Ke,null,kt(p,k=>f("button",{key:k.value,class:_e(["spm-chip",{active:m.value===k.value}]),onClick:A=>x(k.value)},xe(k.label),11,J1)),64))])):Le("",!0),u.value?(Q(),te("div",X1,[f("div",Q1,[f("span",null,"时长: "+xe(h.value?h.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+xe(b.value?b.value+"ms":"0ms"),1)]),f("div",ey,[f("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:w[12]||(w[12]=k=>C(Number(k.target.value)))},[...w[52]||(w[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,ty),f("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=k=>M(Number(k.target.value)))},[...w[53]||(w[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,iy)])])):Le("",!0)]),s.value||e.elemSlot?(Q(),te("div",ny,[f("div",sy,[f("div",oy,[f("div",ry,[re(de,{name:"columns"}),f("span",null,xe(l.value),1)]),f("span",ly,xe(r.value),1)])]),f("div",ay,[(Q(!0),te(Ke,null,kt(a.value,k=>(Q(),te("button",{key:k.value,class:_e(["spm-segmented-item",{active:c(k.value)}]),onClick:A=>I.$emit("update:elemSlot",k.value)},xe(k.label),11,cy))),128))])])):Le("",!0),e.isCodeBlock?(Q(),te("div",dy,[f("div",uy,[f("div",fy,[f("div",py,[re(de,{name:"code"}),w[54]||(w[54]=f("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",hy,[(Q(),te(Ke,null,kt(["1-3","all","1|2|3","2-5"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:A=>I.$emit("update:elemShikiLines",k)},xe(k),11,my)),64)),e.elemShikiLines?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Le("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>I.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>I.$emit("update:elemShikiLines",k.target.value))},null,40,gy)])):Le("",!0),e.isCodeBlock?(Q(),te("div",vy,[f("div",by,[f("div",yy,[f("div",ky,[re(de,{name:"code"}),w[56]||(w[56]=f("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",wy,[(Q(),te(Ke,null,kt(["240px","320px","400px","50vh"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:A=>I.$emit("update:elemMaxHeight",k)},xe(k),11,xy)),64)),e.elemMaxHeight?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Le("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>I.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>I.$emit("update:elemMaxHeight",k.target.value))},null,40,Sy)])):Le("",!0),f("div",_y,[w[61]||(w[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",Cy,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>I.$emit("insertDividerBefore"))},[re(de,{name:"insert-above"}),w[58]||(w[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>I.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),w[59]||(w[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>I.$emit("setTwoColsContrast"))},[re(de,{name:"columns"}),f("span",null,xe(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,$y),e.hasBlockAttrs?(Q(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=k=>I.$emit("clearBlockAttrs"))},[re(de,{name:"broom"}),w[60]||(w[60]=f("span",null,"清除属性",-1))])):Le("",!0)])])])}}}),Ty={class:"spm-section spm-section--doc"},Ey={class:"spm-card-control"},Ay={class:"spm-control-header"},By={class:"spm-control-title-group"},My={class:"spm-control-title"},Dy={class:"spm-segmented-group"},Ly=["aria-label","onClick"],Py={class:"spm-card-control"},Oy={class:"spm-control-header"},Ry={class:"spm-control-title-group"},Ny={class:"spm-control-title"},zy={class:"spm-segmented-group"},Fy={class:"spm-card-control"},Hy={class:"spm-control-header"},jy={class:"spm-control-title-group"},Wy={class:"spm-control-title"},Uy={class:"spm-segmented-group"},Vy={class:"spm-card-control"},Ky={class:"spm-control-header"},Gy={class:"spm-control-title-group"},qy={class:"spm-control-title"},Zy={class:"spm-card-control"},Yy={class:"spm-control-header"},Jy={class:"spm-control-title-group"},Xy={class:"spm-control-title"},Qy=["aria-label"],e0=["checked"],t0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},i0=["value"],n0={class:"spm-card-control"},s0={class:"spm-control-header"},o0={class:"spm-control-title-group"},r0={class:"spm-control-title"},l0=["aria-label"],a0=["checked"],c0={class:"spm-card-control"},d0={class:"spm-action-grid"},u0=It({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=Lt("plugin"),i=gi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Mi({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Mi({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Mi({webServeUrl:a})}function r(a){Mi({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(Q(),te("div",Ty,[c[39]||(c[39]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",Ey,[f("div",Ay,[f("div",By,[f("div",My,[re(de,{name:"palette"}),c[18]||(c[18]=f("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=f("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),f("div",Dy,[(Q(),te(Ke,null,kt(n,d=>f("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},xe(d.label),11,Ly)),64))])]),f("div",Py,[f("div",Oy,[f("div",Ry,[f("div",Ny,[re(de,{name:"ratio"}),c[20]||(c[20]=f("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",zy,[f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",Fy,[f("div",Hy,[f("div",jy,[f("div",Wy,[re(de,{name:"ratio"}),c[22]||(c[22]=f("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",Uy,[f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),f("div",Vy,[f("div",Ky,[f("div",Gy,[f("div",qy,[re(de,{name:"transition"}),c[24]||(c[24]=f("span",null,"全局默认转场",-1))]),c[25]||(c[25]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(Ra,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),f("div",Zy,[f("div",Yy,[f("div",Jy,[f("div",Xy,[re(de,{name:"external-link"}),c[26]||(c[26]=f("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":be(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:be(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,e0),c[28]||(c[28]=f("span",{class:"spm-switch-slider"},null,-1))],8,Qy)]),be(i).enableWebServeJump?(Q(),te("div",t0,[f("input",{value:be(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=ii(()=>{},["stop"])),onKeyup:c[9]||(c[9]=ii(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,i0),c[29]||(c[29]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Le("",!0)]),f("div",n0,[f("div",s0,[f("div",o0,[f("div",r0,[re(de,{name:"type"}),c[30]||(c[30]=f("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":be(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:be(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,a0),c[32]||(c[32]=f("span",{class:"spm-switch-slider"},null,-1))],8,l0)])]),f("div",c0,[c[38]||(c[38]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",d0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[re(de,{name:"split-preview"}),c[33]||(c[33]=f("span",null,"分屏预览",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[re(de,{name:"presenter"}),c[34]||(c[34]=f("span",null,"演讲者视图",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[re(de,{name:"sparkles"}),c[35]||(c[35]=f("span",null,"AI 智能分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[re(de,{name:"export-html"}),c[36]||(c[36]=f("span",null,"导出 HTML",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[re(de,{name:"export-pdf"}),c[37]||(c[37]=f("span",null,"导出 PDF",-1))])])])]))}});var Qn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function f0(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function es(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var oo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Yr;function p0(){return Yr||(Yr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var p=typeof es=="function"&&es;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(m){var h=n[c][1][m];return l(h||m)},u,u.exports,i,n,s,o)}return s[c].exports}for(var r=typeof es=="function"&&es,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(i,n,s){var o=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,p,g,u,m,h,b=[],y=0,x=a.length,C=x,M=o.getTypeOf(a)!=="string";y<a.length;)C=x-y,p=M?(c=a[y++],d=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),d=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),g=c>>2,u=(3&c)<<4|d>>4,m=1<C?(15&d)<<2|p>>6:64,h=2<C?63&p:64,b.push(r.charAt(g)+r.charAt(u)+r.charAt(m)+r.charAt(h));return b.join("")},s.decode=function(a){var c,d,p,g,u,m,h=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,C=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&C--,a.charAt(a.length-2)===r.charAt(64)&&C--,C%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|C):new Array(0|C);h<a.length;)c=r.indexOf(a.charAt(h++))<<2|(g=r.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=r.indexOf(a.charAt(h++)))>>2,p=(3&u)<<6|(m=r.indexOf(a.charAt(h++))),x[b++]=c,u!==64&&(x[b++]=d),m!==64&&(x[b++]=p);return x}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,p,g,u,m){this.compressedSize=d,this.uncompressedSize=p,this.crc32=g,this.compression=u,this.compressedContent=m}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,g){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,p,g){var u=l,m=g+p;c^=-1;for(var h=g;h<m;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,g){var u=l,m=g+p;c^=-1;for(var h=g;h<m;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(p,g){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=g,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(g){p.push({data:g,meta:p.meta})}},s.compressWorker=function(p){return new d("Deflate",p)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(u,m){var h,b="";for(h=0;h<m;h++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,m,h,b,y,x){var C,M,B=u.file,I=u.compression,w=x!==c.utf8encode,N=r.transformTo("string",x(B.name)),R=r.transformTo("string",c.utf8encode(B.name)),z=B.comment,V=r.transformTo("string",x(z)),S=r.transformTo("string",c.utf8encode(z)),F=R.length!==B.name.length,k=S.length!==z.length,A="",H="",E="",D=B.dir,O=B.date,J={crc32:0,compressedSize:0,uncompressedSize:0};m&&!h||(J.crc32=u.crc32,J.compressedSize=u.compressedSize,J.uncompressedSize=u.uncompressedSize);var U=0;m&&(U|=8),w||!F&&!k||(U|=2048);var K=0,se=0;D&&(K|=16),y==="UNIX"?(se=798,K|=(function(ce,ge){var Te=ce;return ce||(Te=ge?16893:33204),(65535&Te)<<16})(B.unixPermissions,D)):(se=20,K|=(function(ce){return 63&(ce||0)})(B.dosPermissions)),C=O.getUTCHours(),C<<=6,C|=O.getUTCMinutes(),C<<=5,C|=O.getUTCSeconds()/2,M=O.getUTCFullYear()-1980,M<<=4,M|=O.getUTCMonth()+1,M<<=5,M|=O.getUTCDate(),F&&(H=o(1,1)+o(d(N),4)+R,A+="up"+o(H.length,2)+H),k&&(E=o(1,1)+o(d(V),4)+S,A+="uc"+o(E.length,2)+E);var ae="";return ae+=`
\0`,ae+=o(U,2),ae+=I.magic,ae+=o(C,2),ae+=o(M,2),ae+=o(J.crc32,4),ae+=o(J.compressedSize,4),ae+=o(J.uncompressedSize,4),ae+=o(N.length,2),ae+=o(A.length,2),{fileRecord:p.LOCAL_FILE_HEADER+ae+N+A,dirRecord:p.CENTRAL_FILE_HEADER+o(se,2)+ae+o(V.length,2)+"\0\0\0\0"+o(K,4)+o(b,4)+N+A+V}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function g(u,m,h,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=m,this.zipPlatform=h,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(u){var m=u.meta.percent||0,h=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(m+100*(h-b-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var m=this.streamFiles&&!u.file.dir;if(m){var h=l(u,m,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var m=this.streamFiles&&!u.file.dir,h=l(u,m,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),m)this.push({data:(function(b){return p.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,m=0;m<this.dirRecords.length;m++)this.push({data:this.dirRecords[m],meta:{percent:100}});var h=this.bytesWritten-u,b=(function(y,x,C,M,B){var I=r.transformTo("string",B(M));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(x,4)+o(C,4)+o(I.length,2)+I})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var m=this;return u.on("data",function(h){m.processChunk(h)}),u.on("end",function(){m.closedSource(m.previous.streamInfo),m._sources.length?m.prepareNextSource():m.end()}),u.on("error",function(h){m.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var m=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<m.length;h++)try{m[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,m=0;m<u.length;m++)u[m].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),l=i("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(g,u){p++;var m=(function(x,C){var M=x||C,B=o[M];if(!B)throw new Error(M+" is not a valid compression method !");return B})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,y=u.date;u._compressWorker(m,h).withStreamInfo("file",{name:g,dir:b,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(g){return new l.Promise(function(u,m){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(b){m(b)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?m(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(g,u){var m=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var b=new a(u);return b.load(h),b}).then(function(h){var b=[l.Promise.resolve(h)],y=h.files;if(u.checkCRC32)for(var x=0;x<y.length;x++)b.push(p(y[x]));return l.Promise.all(b)}).then(function(h){for(var b=h.shift(),y=b.files,x=0;x<y.length;x++){var C=y[x],M=C.fileNameStr,B=o.resolve(C.fileNameStr);m.file(B,C.decompressed,{binary:!0,optimizedBinaryString:!0,date:C.date,dir:C.dir,comment:C.fileCommentStr.length?C.fileCommentStr:null,unixPermissions:C.unixPermissions,dosPermissions:C.dosPermissions,createFolders:u.createFolders}),C.dir||(m.file(B).unsafeOriginalName=M)}return b.zipComment.length&&(m.comment=b.zipComment),m})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(p,g){d.push(p)||d._helper.pause(),c&&c(g)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(B,I,w){var N,R=r.getTypeOf(I),z=r.extend(w||{},d);z.date=z.date||new Date,z.compression!==null&&(z.compression=z.compression.toUpperCase()),typeof z.unixPermissions=="string"&&(z.unixPermissions=parseInt(z.unixPermissions,8)),z.unixPermissions&&16384&z.unixPermissions&&(z.dir=!0),z.dosPermissions&&16&z.dosPermissions&&(z.dir=!0),z.dir&&(B=y(B)),z.createFolders&&(N=b(B))&&x.call(this,N,!0);var V=R==="string"&&z.binary===!1&&z.base64===!1;w&&w.binary!==void 0||(z.binary=!V),(I instanceof p&&I.uncompressedSize===0||z.dir||!I||I.length===0)&&(z.base64=!1,z.binary=!0,I="",z.compression="STORE",R="string");var S=null;S=I instanceof p||I instanceof a?I:m.isNode&&m.isStream(I)?new h(B,I):r.prepareContent(B,I,z.binary,z.optimizedBinaryString,z.base64);var F=new g(B,S,z);this.files[B]=F}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),g=i("./zipObject"),u=i("./generate"),m=i("./nodejsUtils"),h=i("./nodejs/NodejsStreamInputAdapter"),b=function(B){B.slice(-1)==="/"&&(B=B.substring(0,B.length-1));var I=B.lastIndexOf("/");return 0<I?B.substring(0,I):""},y=function(B){return B.slice(-1)!=="/"&&(B+="/"),B},x=function(B,I){return I=I!==void 0?I:d.createFolders,B=y(B),this.files[B]||o.call(this,B,null,{dir:!0,createFolders:I}),this.files[B]};function C(B){return Object.prototype.toString.call(B)==="[object RegExp]"}var M={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(B){var I,w,N;for(I in this.files)N=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&B(w,N)},filter:function(B){var I=[];return this.forEach(function(w,N){B(w,N)&&I.push(N)}),I},file:function(B,I,w){if(arguments.length!==1)return B=this.root+B,o.call(this,B,I,w),this;if(C(B)){var N=B;return this.filter(function(z,V){return!V.dir&&N.test(z)})}var R=this.files[this.root+B];return R&&!R.dir?R:null},folder:function(B){if(!B)return this;if(C(B))return this.filter(function(R,z){return z.dir&&B.test(R)});var I=this.root+B,w=x.call(this,I),N=this.clone();return N.root=w.name,N},remove:function(B){B=this.root+B;var I=this.files[B];if(I||(B.slice(-1)!=="/"&&(B+="/"),I=this.files[B]),I&&!I.dir)delete this.files[B];else for(var w=this.filter(function(R,z){return z.name.slice(0,B.length)===B}),N=0;N<w.length;N++)delete this.files[w[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(B){var I,w={};try{if((w=r.extend(B||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var N=w.comment||this.comment||"";I=u.generateWorker(this,w,N)}catch(R){(I=new a("error")).error(R)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(B,I){return this.generateInternalStream(B).accumulate(I)},generateNodeStream:function(B,I){return(B=B||{}).type||(B.type="nodebuffer"),this.generateInternalStream(B).toNodejsStream(I)}};n.exports=M},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===p)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&p===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var g=o.getTypeOf(p);return o.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(p):l.uint8array?new d(o.transformTo("uint8array",p)):new r(o.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),l=i("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),l=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(m,h){return new d.Promise(function(b,y){var x=[],C=m._internalType,M=m._outputType,B=m._mimeType;m.on("data",function(I,w){x.push(I),h&&h(w)}).on("error",function(I){x=[],y(I)}).on("end",function(){try{var I=(function(w,N,R){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",N),R);case"base64":return a.encode(N);default:return o.transformTo(w,N)}})(M,(function(w,N){var R,z=0,V=null,S=0;for(R=0;R<N.length;R++)S+=N[R].length;switch(w){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(V=new Uint8Array(S),R=0;R<N.length;R++)V.set(N[R],z),z+=N[R].length;return V;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+w+"'")}})(C,x),B);b(I)}catch(w){y(w)}x=[]}).resume()})}function u(m,h,b){var y=h;switch(h){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=h,this._mimeType=b,o.checkSupport(y),this._worker=m.pipe(new l(y)),m.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(m){return g(this,m)},on:function(m,h){var b=this;return m==="data"?this._worker.on(m,function(y){h.call(b,y.data,y.meta)}):this._worker.on(m,function(){o.delay(h,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(m){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},m)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(m){var h,b,y,x,C,M=m.length,B=0;for(x=0;x<M;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<M&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),B+=b<128?1:b<2048?2:b<65536?3:4;for(h=l.uint8array?new Uint8Array(B):new Array(B),x=C=0;C<B;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<M&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?h[C++]=b:(b<2048?h[C++]=192|b>>>6:(b<65536?h[C++]=224|b>>>12:(h[C++]=240|b>>>18,h[C++]=128|b>>>12&63),h[C++]=128|b>>>6&63),h[C++]=128|63&b);return h})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(m){var h,b,y,x,C=m.length,M=new Array(2*C);for(h=b=0;h<C;)if((y=m[h++])<128)M[b++]=y;else if(4<(x=c[y]))M[b++]=65533,h+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&h<C;)y=y<<6|63&m[h++],x--;1<x?M[b++]=65533:y<65536?M[b++]=y:(y-=65536,M[b++]=55296|y>>10&1023,M[b++]=56320|1023&y)}return M.length!==b&&(M.subarray?M=M.subarray(0,b):M.length=b),o.applyFromCharCode(M)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(p,a),p.prototype.processChunk=function(u){var m=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=m;(m=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),m.set(h,this.leftOver.length)}else m=this.leftOver.concat(m);this.leftOver=null}var b=(function(x,C){var M;for((C=C||x.length)>x.length&&(C=x.length),M=C-1;0<=M&&(192&x[M])==128;)M--;return M<0||M===0?C:M+c[x[M]]>C?M:C})(m),y=m;b!==m.length&&(l.uint8array?(y=m.subarray(0,b),this.leftOver=m.subarray(b,m.length)):(y=m.slice(0,b),this.leftOver=m.slice(b,m.length))),this.push({data:s.utf8decode(y),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=p,o.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(h){return h}function d(h,b){for(var y=0;y<h.length;++y)b[y]=255&h.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(h,b){s.checkSupport("blob");try{return new Blob([h],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(h),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(h,b,y){var x=[],C=0,M=h.length;if(M<=y)return String.fromCharCode.apply(null,h);for(;C<M;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,h.slice(C,Math.min(C+y,M)))):x.push(String.fromCharCode.apply(null,h.subarray(C,Math.min(C+y,M)))),C+=y;return x.join("")},stringifyByChar:function(h){for(var b="",y=0;y<h.length;y++)b+=String.fromCharCode(h[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var b=65536,y=s.getTypeOf(h),x=!0;if(y==="uint8array"?x=p.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=p.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return p.stringifyByChunk(h,y,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(h)}function u(h,b){for(var y=0;y<h.length;y++)b[y]=h[y];return b}s.applyFromCharCode=g;var m={};m.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return m.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,r.allocBuffer(h.length))}},m.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return r.newBufferFrom(h)}},m.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return r.newBufferFrom(new Uint8Array(h))}},m.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return r.newBufferFrom(h)}},m.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return m.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},s.transformTo=function(h,b){if(b=b||"",!h)return b;s.checkSupport(h);var y=s.getTypeOf(b);return m[y][h](b)},s.resolve=function(h){for(var b=h.split("/"),y=[],x=0;x<b.length;x++){var C=b[x];C==="."||C===""&&x!==0&&x!==b.length-1||(C===".."?y.pop():y.push(C))}return y.join("/")},s.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(h)?"nodebuffer":o.uint8array&&h instanceof Uint8Array?"uint8array":o.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(h){if(!o[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(h){var b,y,x="";for(y=0;y<(h||"").length;y++)x+="\\x"+((b=h.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},s.delay=function(h,b,y){setImmediate(function(){h.apply(y||null,b||[])})},s.inherits=function(h,b){function y(){}y.prototype=b.prototype,h.prototype=new y},s.extend=function(){var h,b,y={};for(h=0;h<arguments.length;h++)for(b in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],b)&&y[b]===void 0&&(y[b]=arguments[h][b]);return y},s.prepareContent=function(h,b,y,x,C){return a.Promise.resolve(b).then(function(M){return o.blob&&(M instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(M))!==-1)&&typeof FileReader<"u"?new a.Promise(function(B,I){var w=new FileReader;w.onload=function(N){B(N.target.result)},w.onerror=function(N){I(N.target.error)},w.readAsArrayBuffer(M)}):M}).then(function(M){var B=s.getTypeOf(M);return B?(B==="arraybuffer"?M=s.transformTo("uint8array",M):B==="string"&&(C?M=l.decode(M):y&&x!==!0&&(M=(function(I){return d(I,o.uint8array?new Uint8Array(I.length):new Array(I.length))})(M))),M):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(p)+")")}},isSignature:function(p,g){var u=this.reader.index;this.reader.setIndex(p);var m=this.reader.readString(4)===g;return this.reader.setIndex(u),m},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,g,u,m=this.zip64EndOfCentralSize-44;0<m;)p=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[p]={id:p,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,g;for(p=0;p<this.files.length;p++)g=this.files[p],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var g=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var m=g-u;if(0<m)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=m);else if(m<0)throw new Error("Corrupted zip: missing "+Math.abs(m)+" bytes.")},prepareReader:function(p){this.reader=o(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function g(u,m){this.options=u,this.loadOptions=m}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var m,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((m=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,m,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var m=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(m),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var m,h,b,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)m=u.readInt(2),h=u.readInt(2),b=u.readData(h),this.extraFields[m]={id:m,length:h,value:b};u.setIndex(y)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var m=this.findExtraFieldUnicodePath();if(m!==null)this.fileNameStr=m;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var m=o(u.value);return m.readInt(1)!==1||a(this.fileName)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var m=o(u.value);return m.readInt(1)!==1||a(this.fileComment)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(m,h,b){this.name=m,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=h,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(m){var h=null,b="string";try{if(!m)throw new Error("No output type specified.");var y=(b=m.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),h=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(h=h.pipe(new a.Utf8EncodeWorker)),!x&&y&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(C){(h=new d("error")).error(C)}return new l(h,b,"")},async:function(m,h){return this.internalStream(m).accumulate(h)},nodeStream:function(m,h){return this.internalStream(m||"nodebuffer").toNodejsStream(h)},_compressWorker:function(m,h){if(this._data instanceof c&&this._data.compression.magic===m.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,m,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)o.prototype[p[u]]=g;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(m),p=o.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var h=o.document.createElement("script");h.onreadystatechange=function(){m(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},o.document.documentElement.appendChild(h)}:function(){setTimeout(m,0)};else{var g=new o.MessageChannel;g.port1.onmessage=m,l=function(){g.port2.postMessage(0)}}var u=[];function m(){var h,b;r=!0;for(var y=u.length;y;){for(b=u,u=[],h=-1;++h<y;)b[h]();y=u.length}r=!1}n.exports=function(h){u.push(h)!==1||r||l()}}).call(this,typeof Qn<"u"?Qn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&h(this,y)}function g(y,x,C){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof C=="function"&&(this.onRejected=C,this.callRejected=this.otherCallRejected)}function u(y,x,C){o(function(){var M;try{M=x(C)}catch(B){return r.reject(y,B)}M===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,M)})}function m(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function h(y,x){var C=!1;function M(w){C||(C=!0,r.reject(y,w))}function B(w){C||(C=!0,r.resolve(y,w))}var I=b(function(){x(B,M)});I.status==="error"&&M(I.value)}function b(y,x){var C={};try{C.value=y(x),C.status="success"}catch(M){C.status="error",C.value=M}return C}(n.exports=p).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(C){return x.resolve(y()).then(function(){return C})},function(C){return x.resolve(y()).then(function(){throw C})})},p.prototype.catch=function(y){return this.then(null,y)},p.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var C=new this.constructor(l);return this.state!==d?u(C,this.state===c?y:x,this.outcome):this.queue.push(new g(C,y,x)),C},g.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},g.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},g.prototype.callRejected=function(y){r.reject(this.promise,y)},g.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,x){var C=b(m,x);if(C.status==="error")return r.reject(y,C.value);var M=C.value;if(M)h(y,M);else{y.state=c,y.outcome=x;for(var B=-1,I=y.queue.length;++B<I;)y.queue[B].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var C=-1,M=y.queue.length;++C<M;)y.queue[C].callRejected(x);return y},p.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},p.reject=function(y){var x=new this(l);return r.reject(x,y)},p.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=y.length,M=!1;if(!C)return this.resolve([]);for(var B=new Array(C),I=0,w=-1,N=new this(l);++w<C;)R(y[w],w);return N;function R(z,V){x.resolve(z).then(function(S){B[V]=S,++I!==C||M||(M=!0,r.resolve(N,B))},function(S){M||(M=!0,r.reject(N,S))})}},p.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=y.length,M=!1;if(!C)return this.resolve([]);for(var B=-1,I=new this(l);++B<C;)w=y[B],x.resolve(w).then(function(N){M||(M=!0,r.resolve(I,N))},function(N){M||(M=!0,r.reject(I,N))});var w;return I}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,g=-1,u=0,m=8;function h(y){if(!(this instanceof h))return new h(y);this.options=l.assign({level:g,method:m,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var C=o.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(C!==p)throw new Error(a[C]);if(x.header&&o.deflateSetHeader(this.strm,x.header),x.dictionary){var M;if(M=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(C=o.deflateSetDictionary(this.strm,M))!==p)throw new Error(a[C]);this._dict_set=!0}}function b(y,x){var C=new h(x);if(C.push(y,!0),C.err)throw C.msg||a[C.err];return C.result}h.prototype.push=function(y,x){var C,M,B=this.strm,I=this.options.chunkSize;if(this.ended)return!1;M=x===~~x?x:x===!0?4:0,typeof y=="string"?B.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?B.input=new Uint8Array(y):B.input=y,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new l.Buf8(I),B.next_out=0,B.avail_out=I),(C=o.deflate(B,M))!==1&&C!==p)return this.onEnd(C),!(this.ended=!0);B.avail_out!==0&&(B.avail_in!==0||M!==4&&M!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(B.output,B.next_out))):this.onData(l.shrinkBuf(B.output,B.next_out)))}while((0<B.avail_in||B.avail_out===0)&&C!==1);return M===4?(C=o.deflateEnd(this.strm),this.onEnd(C),this.ended=!0,C===p):M!==2||(this.onEnd(p),!(B.avail_out=0))},h.prototype.onData=function(y){this.chunks.push(y)},h.prototype.onEnd=function(y){y===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=h,s.deflate=b,s.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},s.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||h&&h.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new p,o.inflateGetHeader(this.strm,this.header)}function m(h,b){var y=new u(b);if(y.push(h,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(h,b){var y,x,C,M,B,I,w=this.strm,N=this.options.chunkSize,R=this.options.dictionary,z=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?w.input=r.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?w.input=new Uint8Array(h):w.input=h,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(N),w.next_out=0,w.avail_out=N),(y=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&R&&(I=typeof R=="string"?r.string2buf(R):g.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,y=o.inflateSetDictionary(this.strm,I)),y===a.Z_BUF_ERROR&&z===!0&&(y=a.Z_OK,z=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(C=r.utf8border(w.output,w.next_out),M=w.next_out-C,B=r.buf2string(w.output,C),w.next_out=M,w.avail_out=N-M,M&&l.arraySet(w.output,w.output,C,M,0),this.onData(B)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(z=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},s.Inflate=u,s.inflate=m,s.inflateRaw=function(h,b){return(b=b||{}).raw=!0,m(h,b)},s.ungzip=m},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),g);else for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,p,g,u,m;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(m=new Uint8Array(p),c=g=0,d=a.length;c<d;c++)u=a[c],m.set(u,g),g+=u.length;return m}},r={arraySet:function(a,c,d,p,g){for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,g){if(g<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(p,g));for(var u="",m=0;m<g;m++)u+=String.fromCharCode(p[m]);return u}a[254]=a[254]=1,s.string2buf=function(p){var g,u,m,h,b,y=p.length,x=0;for(h=0;h<y;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<y&&(64512&(m=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),h++),x+=u<128?1:u<2048?2:u<65536?3:4;for(g=new o.Buf8(x),h=b=0;b<x;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<y&&(64512&(m=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),h++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},s.buf2binstring=function(p){return d(p,p.length)},s.binstring2buf=function(p){for(var g=new o.Buf8(p.length),u=0,m=g.length;u<m;u++)g[u]=p.charCodeAt(u);return g},s.buf2string=function(p,g){var u,m,h,b,y=g||p.length,x=new Array(2*y);for(u=m=0;u<y;)if((h=p[u++])<128)x[m++]=h;else if(4<(b=a[h]))x[m++]=65533,u+=b-1;else{for(h&=b===2?31:b===3?15:7;1<b&&u<y;)h=h<<6|63&p[u++],b--;1<b?x[m++]=65533:h<65536?x[m++]=h:(h-=65536,x[m++]=55296|h>>10&1023,x[m++]=56320|1023&h)}return d(x,m)},s.utf8border=function(p,g){var u;for((g=g||p.length)>p.length&&(g=p.length),u=g-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?g:u+a[p[u]]>g?u:g}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,p=c+a;l^=-1;for(var g=c;g<p;g++)l=l>>>8^d[255&(l^r[g])];return-1^l}},{}],46:[function(i,n,s){var o,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,g=4,u=0,m=-2,h=-1,b=4,y=2,x=8,C=9,M=286,B=30,I=19,w=2*M+1,N=15,R=3,z=258,V=z+R+1,S=42,F=113,k=1,A=2,H=3,E=4;function D(v,W){return v.msg=d[W],W}function O(v){return(v<<1)-(4<v?9:0)}function J(v){for(var W=v.length;0<=--W;)v[W]=0}function U(v){var W=v.state,T=W.pending;T>v.avail_out&&(T=v.avail_out),T!==0&&(l.arraySet(v.output,W.pending_buf,W.pending_out,T,v.next_out),v.next_out+=T,W.pending_out+=T,v.total_out+=T,v.avail_out-=T,W.pending-=T,W.pending===0&&(W.pending_out=0))}function K(v,W){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,W),v.block_start=v.strstart,U(v.strm)}function se(v,W){v.pending_buf[v.pending++]=W}function ae(v,W){v.pending_buf[v.pending++]=W>>>8&255,v.pending_buf[v.pending++]=255&W}function ce(v,W){var T,_,$=v.max_chain_length,L=v.strstart,Z=v.prev_length,G=v.nice_match,q=v.strstart>v.w_size-V?v.strstart-(v.w_size-V):0,ee=v.window,le=v.w_mask,oe=v.prev,pe=v.strstart+z,ie=ee[L+Z-1],ne=ee[L+Z];v.prev_length>=v.good_match&&($>>=2),G>v.lookahead&&(G=v.lookahead);do if(ee[(T=W)+Z]===ne&&ee[T+Z-1]===ie&&ee[T]===ee[L]&&ee[++T]===ee[L+1]){L+=2,T++;do;while(ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&ee[++L]===ee[++T]&&L<pe);if(_=z-(pe-L),L=pe-z,Z<_){if(v.match_start=W,G<=(Z=_))break;ie=ee[L+Z-1],ne=ee[L+Z]}}while((W=oe[W&le])>q&&--$!=0);return Z<=v.lookahead?Z:v.lookahead}function ge(v){var W,T,_,$,L,Z,G,q,ee,le,oe=v.w_size;do{if($=v.window_size-v.lookahead-v.strstart,v.strstart>=oe+(oe-V)){for(l.arraySet(v.window,v.window,oe,oe,0),v.match_start-=oe,v.strstart-=oe,v.block_start-=oe,W=T=v.hash_size;_=v.head[--W],v.head[W]=oe<=_?_-oe:0,--T;);for(W=T=oe;_=v.prev[--W],v.prev[W]=oe<=_?_-oe:0,--T;);$+=oe}if(v.strm.avail_in===0)break;if(Z=v.strm,G=v.window,q=v.strstart+v.lookahead,ee=$,le=void 0,le=Z.avail_in,ee<le&&(le=ee),T=le===0?0:(Z.avail_in-=le,l.arraySet(G,Z.input,Z.next_in,le,q),Z.state.wrap===1?Z.adler=a(Z.adler,G,le,q):Z.state.wrap===2&&(Z.adler=c(Z.adler,G,le,q)),Z.next_in+=le,Z.total_in+=le,le),v.lookahead+=T,v.lookahead+v.insert>=R)for(L=v.strstart-v.insert,v.ins_h=v.window[L],v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+R-1])&v.hash_mask,v.prev[L&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=L,L++,v.insert--,!(v.lookahead+v.insert<R)););}while(v.lookahead<V&&v.strm.avail_in!==0)}function Te(v,W){for(var T,_;;){if(v.lookahead<V){if(ge(v),v.lookahead<V&&W===p)return k;if(v.lookahead===0)break}if(T=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,T=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),T!==0&&v.strstart-T<=v.w_size-V&&(v.match_length=ce(v,T)),v.match_length>=R)if(_=r._tr_tally(v,v.strstart-v.match_start,v.match_length-R),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=R){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,T=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else _=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(_&&(K(v,!1),v.strm.avail_out===0))return k}return v.insert=v.strstart<R-1?v.strstart:R-1,W===g?(K(v,!0),v.strm.avail_out===0?H:E):v.last_lit&&(K(v,!1),v.strm.avail_out===0)?k:A}function we(v,W){for(var T,_,$;;){if(v.lookahead<V){if(ge(v),v.lookahead<V&&W===p)return k;if(v.lookahead===0)break}if(T=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,T=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=R-1,T!==0&&v.prev_length<v.max_lazy_match&&v.strstart-T<=v.w_size-V&&(v.match_length=ce(v,T),v.match_length<=5&&(v.strategy===1||v.match_length===R&&4096<v.strstart-v.match_start)&&(v.match_length=R-1)),v.prev_length>=R&&v.match_length<=v.prev_length){for($=v.strstart+v.lookahead-R,_=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-R),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=$&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,T=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=R-1,v.strstart++,_&&(K(v,!1),v.strm.avail_out===0))return k}else if(v.match_available){if((_=r._tr_tally(v,0,v.window[v.strstart-1]))&&K(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return k}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(_=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<R-1?v.strstart:R-1,W===g?(K(v,!0),v.strm.avail_out===0?H:E):v.last_lit&&(K(v,!1),v.strm.avail_out===0)?k:A}function ue(v,W,T,_,$){this.good_length=v,this.max_lazy=W,this.nice_length=T,this.max_chain=_,this.func=$}function Y(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*B+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),J(this.dyn_ltree),J(this.dyn_dtree),J(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*M+1),J(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*M+1),J(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function fe(v){var W;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=y,(W=v.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?S:F,v.adler=W.wrap===2?0:1,W.last_flush=p,r._tr_init(W),u):D(v,m)}function P(v){var W=fe(v);return W===u&&(function(T){T.window_size=2*T.w_size,J(T.head),T.max_lazy_match=o[T.level].max_lazy,T.good_match=o[T.level].good_length,T.nice_match=o[T.level].nice_length,T.max_chain_length=o[T.level].max_chain,T.strstart=0,T.block_start=0,T.lookahead=0,T.insert=0,T.match_length=T.prev_length=R-1,T.match_available=0,T.ins_h=0})(v.state),W}function j(v,W,T,_,$,L){if(!v)return m;var Z=1;if(W===h&&(W=6),_<0?(Z=0,_=-_):15<_&&(Z=2,_-=16),$<1||C<$||T!==x||_<8||15<_||W<0||9<W||L<0||b<L)return D(v,m);_===8&&(_=9);var G=new Y;return(v.state=G).strm=v,G.wrap=Z,G.gzhead=null,G.w_bits=_,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=$+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+R-1)/R),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<$+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=W,G.strategy=L,G.method=T,P(v)}o=[new ue(0,0,0,0,function(v,W){var T=65535;for(T>v.pending_buf_size-5&&(T=v.pending_buf_size-5);;){if(v.lookahead<=1){if(ge(v),v.lookahead===0&&W===p)return k;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var _=v.block_start+T;if((v.strstart===0||v.strstart>=_)&&(v.lookahead=v.strstart-_,v.strstart=_,K(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-V&&(K(v,!1),v.strm.avail_out===0))return k}return v.insert=0,W===g?(K(v,!0),v.strm.avail_out===0?H:E):(v.strstart>v.block_start&&(K(v,!1),v.strm.avail_out),k)}),new ue(4,4,8,4,Te),new ue(4,5,16,8,Te),new ue(4,6,32,32,Te),new ue(4,4,16,16,we),new ue(8,16,32,32,we),new ue(8,16,128,128,we),new ue(8,32,128,256,we),new ue(32,128,258,1024,we),new ue(32,258,258,4096,we)],s.deflateInit=function(v,W){return j(v,W,x,15,8,0)},s.deflateInit2=j,s.deflateReset=P,s.deflateResetKeep=fe,s.deflateSetHeader=function(v,W){return v&&v.state?v.state.wrap!==2?m:(v.state.gzhead=W,u):m},s.deflate=function(v,W){var T,_,$,L;if(!v||!v.state||5<W||W<0)return v?D(v,m):m;if(_=v.state,!v.output||!v.input&&v.avail_in!==0||_.status===666&&W!==g)return D(v,v.avail_out===0?-5:m);if(_.strm=v,T=_.last_flush,_.last_flush=W,_.status===S)if(_.wrap===2)v.adler=0,se(_,31),se(_,139),se(_,8),_.gzhead?(se(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),se(_,255&_.gzhead.time),se(_,_.gzhead.time>>8&255),se(_,_.gzhead.time>>16&255),se(_,_.gzhead.time>>24&255),se(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),se(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(se(_,255&_.gzhead.extra.length),se(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(v.adler=c(v.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(se(_,0),se(_,0),se(_,0),se(_,0),se(_,0),se(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),se(_,3),_.status=F);else{var Z=x+(_.w_bits-8<<4)<<8;Z|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(Z|=32),Z+=31-Z%31,_.status=F,ae(_,Z),_.strstart!==0&&(ae(_,v.adler>>>16),ae(_,65535&v.adler)),v.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),U(v),$=_.pending,_.pending!==_.pending_buf_size));)se(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),U(v),$=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,se(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),L===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),U(v),$=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,se(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>$&&(v.adler=c(v.adler,_.pending_buf,_.pending-$,$)),L===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&U(v),_.pending+2<=_.pending_buf_size&&(se(_,255&v.adler),se(_,v.adler>>8&255),v.adler=0,_.status=F)):_.status=F),_.pending!==0){if(U(v),v.avail_out===0)return _.last_flush=-1,u}else if(v.avail_in===0&&O(W)<=O(T)&&W!==g)return D(v,-5);if(_.status===666&&v.avail_in!==0)return D(v,-5);if(v.avail_in!==0||_.lookahead!==0||W!==p&&_.status!==666){var G=_.strategy===2?(function(q,ee){for(var le;;){if(q.lookahead===0&&(ge(q),q.lookahead===0)){if(ee===p)return k;break}if(q.match_length=0,le=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++,le&&(K(q,!1),q.strm.avail_out===0))return k}return q.insert=0,ee===g?(K(q,!0),q.strm.avail_out===0?H:E):q.last_lit&&(K(q,!1),q.strm.avail_out===0)?k:A})(_,W):_.strategy===3?(function(q,ee){for(var le,oe,pe,ie,ne=q.window;;){if(q.lookahead<=z){if(ge(q),q.lookahead<=z&&ee===p)return k;if(q.lookahead===0)break}if(q.match_length=0,q.lookahead>=R&&0<q.strstart&&(oe=ne[pe=q.strstart-1])===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]){ie=q.strstart+z;do;while(oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&oe===ne[++pe]&&pe<ie);q.match_length=z-(ie-pe),q.match_length>q.lookahead&&(q.match_length=q.lookahead)}if(q.match_length>=R?(le=r._tr_tally(q,1,q.match_length-R),q.lookahead-=q.match_length,q.strstart+=q.match_length,q.match_length=0):(le=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++),le&&(K(q,!1),q.strm.avail_out===0))return k}return q.insert=0,ee===g?(K(q,!0),q.strm.avail_out===0?H:E):q.last_lit&&(K(q,!1),q.strm.avail_out===0)?k:A})(_,W):o[_.level].func(_,W);if(G!==H&&G!==E||(_.status=666),G===k||G===H)return v.avail_out===0&&(_.last_flush=-1),u;if(G===A&&(W===1?r._tr_align(_):W!==5&&(r._tr_stored_block(_,0,0,!1),W===3&&(J(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),U(v),v.avail_out===0))return _.last_flush=-1,u}return W!==g?u:_.wrap<=0?1:(_.wrap===2?(se(_,255&v.adler),se(_,v.adler>>8&255),se(_,v.adler>>16&255),se(_,v.adler>>24&255),se(_,255&v.total_in),se(_,v.total_in>>8&255),se(_,v.total_in>>16&255),se(_,v.total_in>>24&255)):(ae(_,v.adler>>>16),ae(_,65535&v.adler)),U(v),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?u:1)},s.deflateEnd=function(v){var W;return v&&v.state?(W=v.state.status)!==S&&W!==69&&W!==73&&W!==91&&W!==103&&W!==F&&W!==666?D(v,m):(v.state=null,W===F?D(v,-3):u):m},s.deflateSetDictionary=function(v,W){var T,_,$,L,Z,G,q,ee,le=W.length;if(!v||!v.state||(L=(T=v.state).wrap)===2||L===1&&T.status!==S||T.lookahead)return m;for(L===1&&(v.adler=a(v.adler,W,le,0)),T.wrap=0,le>=T.w_size&&(L===0&&(J(T.head),T.strstart=0,T.block_start=0,T.insert=0),ee=new l.Buf8(T.w_size),l.arraySet(ee,W,le-T.w_size,T.w_size,0),W=ee,le=T.w_size),Z=v.avail_in,G=v.next_in,q=v.input,v.avail_in=le,v.next_in=0,v.input=W,ge(T);T.lookahead>=R;){for(_=T.strstart,$=T.lookahead-(R-1);T.ins_h=(T.ins_h<<T.hash_shift^T.window[_+R-1])&T.hash_mask,T.prev[_&T.w_mask]=T.head[T.ins_h],T.head[T.ins_h]=_,_++,--$;);T.strstart=_,T.lookahead=R-1,ge(T)}return T.strstart+=T.lookahead,T.block_start=T.strstart,T.insert=T.lookahead,T.lookahead=0,T.match_length=T.prev_length=R-1,T.match_available=0,v.next_in=G,v.input=q,v.avail_in=Z,T.wrap=L,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,l){var r,a,c,d,p,g,u,m,h,b,y,x,C,M,B,I,w,N,R,z,V,S,F,k,A;r=o.state,a=o.next_in,k=o.input,c=a+(o.avail_in-5),d=o.next_out,A=o.output,p=d-(l-o.avail_out),g=d+(o.avail_out-257),u=r.dmax,m=r.wsize,h=r.whave,b=r.wnext,y=r.window,x=r.hold,C=r.bits,M=r.lencode,B=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{C<15&&(x+=k[a++]<<C,C+=8,x+=k[a++]<<C,C+=8),N=M[x&I];t:for(;;){if(x>>>=R=N>>>24,C-=R,(R=N>>>16&255)===0)A[d++]=65535&N;else{if(!(16&R)){if((64&R)==0){N=M[(65535&N)+(x&(1<<R)-1)];continue t}if(32&R){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}z=65535&N,(R&=15)&&(C<R&&(x+=k[a++]<<C,C+=8),z+=x&(1<<R)-1,x>>>=R,C-=R),C<15&&(x+=k[a++]<<C,C+=8,x+=k[a++]<<C,C+=8),N=B[x&w];i:for(;;){if(x>>>=R=N>>>24,C-=R,!(16&(R=N>>>16&255))){if((64&R)==0){N=B[(65535&N)+(x&(1<<R)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(V=65535&N,C<(R&=15)&&(x+=k[a++]<<C,(C+=8)<R&&(x+=k[a++]<<C,C+=8)),u<(V+=x&(1<<R)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=R,C-=R,(R=d-p)<V){if(h<(R=V-R)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(F=y,(S=0)===b){if(S+=m-R,R<z){for(z-=R;A[d++]=y[S++],--R;);S=d-V,F=A}}else if(b<R){if(S+=m+b-R,(R-=b)<z){for(z-=R;A[d++]=y[S++],--R;);if(S=0,b<z){for(z-=R=b;A[d++]=y[S++],--R;);S=d-V,F=A}}}else if(S+=b-R,R<z){for(z-=R;A[d++]=y[S++],--R;);S=d-V,F=A}for(;2<z;)A[d++]=F[S++],A[d++]=F[S++],A[d++]=F[S++],z-=3;z&&(A[d++]=F[S++],1<z&&(A[d++]=F[S++]))}else{for(S=d-V;A[d++]=A[S++],A[d++]=A[S++],A[d++]=A[S++],2<(z-=3););z&&(A[d++]=A[S++],1<z&&(A[d++]=A[S++]))}break}}break}}while(a<c&&d<g);a-=z=C>>3,x&=(1<<(C-=z<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<g?g-d+257:257-(d-g),r.hold=x,r.bits=C}},{}],49:[function(i,n,s){var o=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,p=2,g=0,u=-2,m=1,h=852,b=592;function y(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function C(S){var F;return S&&S.state?(F=S.state,S.total_in=S.total_out=F.total=0,S.msg="",F.wrap&&(S.adler=1&F.wrap),F.mode=m,F.last=0,F.havedict=0,F.dmax=32768,F.head=null,F.hold=0,F.bits=0,F.lencode=F.lendyn=new o.Buf32(h),F.distcode=F.distdyn=new o.Buf32(b),F.sane=1,F.back=-1,g):u}function M(S){var F;return S&&S.state?((F=S.state).wsize=0,F.whave=0,F.wnext=0,C(S)):u}function B(S,F){var k,A;return S&&S.state?(A=S.state,F<0?(k=0,F=-F):(k=1+(F>>4),F<48&&(F&=15)),F&&(F<8||15<F)?u:(A.window!==null&&A.wbits!==F&&(A.window=null),A.wrap=k,A.wbits=F,M(S))):u}function I(S,F){var k,A;return S?(A=new x,(S.state=A).window=null,(k=B(S,F))!==g&&(S.state=null),k):u}var w,N,R=!0;function z(S){if(R){var F;for(w=new o.Buf32(512),N=new o.Buf32(32),F=0;F<144;)S.lens[F++]=8;for(;F<256;)S.lens[F++]=9;for(;F<280;)S.lens[F++]=7;for(;F<288;)S.lens[F++]=8;for(c(d,S.lens,0,288,w,0,S.work,{bits:9}),F=0;F<32;)S.lens[F++]=5;c(p,S.lens,0,32,N,0,S.work,{bits:5}),R=!1}S.lencode=w,S.lenbits=9,S.distcode=N,S.distbits=5}function V(S,F,k,A){var H,E=S.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new o.Buf8(E.wsize)),A>=E.wsize?(o.arraySet(E.window,F,k-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(A<(H=E.wsize-E.wnext)&&(H=A),o.arraySet(E.window,F,k-A,H,E.wnext),(A-=H)?(o.arraySet(E.window,F,k-A,A,0),E.wnext=A,E.whave=E.wsize):(E.wnext+=H,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=H))),0}s.inflateReset=M,s.inflateReset2=B,s.inflateResetKeep=C,s.inflateInit=function(S){return I(S,15)},s.inflateInit2=I,s.inflate=function(S,F){var k,A,H,E,D,O,J,U,K,se,ae,ce,ge,Te,we,ue,Y,fe,P,j,v,W,T,_,$=0,L=new o.Buf8(4),Z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return u;(k=S.state).mode===12&&(k.mode=13),D=S.next_out,H=S.output,J=S.avail_out,E=S.next_in,A=S.input,O=S.avail_in,U=k.hold,K=k.bits,se=O,ae=J,W=g;e:for(;;)switch(k.mode){case m:if(k.wrap===0){k.mode=13;break}for(;K<16;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(2&k.wrap&&U===35615){L[k.check=0]=255&U,L[1]=U>>>8&255,k.check=r(k.check,L,2,0),K=U=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&U)<<8)+(U>>8))%31){S.msg="incorrect header check",k.mode=30;break}if((15&U)!=8){S.msg="unknown compression method",k.mode=30;break}if(K-=4,v=8+(15&(U>>>=4)),k.wbits===0)k.wbits=v;else if(v>k.wbits){S.msg="invalid window size",k.mode=30;break}k.dmax=1<<v,S.adler=k.check=1,k.mode=512&U?10:12,K=U=0;break;case 2:for(;K<16;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(k.flags=U,(255&k.flags)!=8){S.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){S.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=U>>8&1),512&k.flags&&(L[0]=255&U,L[1]=U>>>8&255,k.check=r(k.check,L,2,0)),K=U=0,k.mode=3;case 3:for(;K<32;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.head&&(k.head.time=U),512&k.flags&&(L[0]=255&U,L[1]=U>>>8&255,L[2]=U>>>16&255,L[3]=U>>>24&255,k.check=r(k.check,L,4,0)),K=U=0,k.mode=4;case 4:for(;K<16;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.head&&(k.head.xflags=255&U,k.head.os=U>>8),512&k.flags&&(L[0]=255&U,L[1]=U>>>8&255,k.check=r(k.check,L,2,0)),K=U=0,k.mode=5;case 5:if(1024&k.flags){for(;K<16;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.length=U,k.head&&(k.head.extra_len=U),512&k.flags&&(L[0]=255&U,L[1]=U>>>8&255,k.check=r(k.check,L,2,0)),K=U=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(O<(ce=k.length)&&(ce=O),ce&&(k.head&&(v=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,A,E,ce,v)),512&k.flags&&(k.check=r(k.check,A,ce,E)),O-=ce,E+=ce,k.length-=ce),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(O===0)break e;for(ce=0;v=A[E+ce++],k.head&&v&&k.length<65536&&(k.head.name+=String.fromCharCode(v)),v&&ce<O;);if(512&k.flags&&(k.check=r(k.check,A,ce,E)),O-=ce,E+=ce,v)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(O===0)break e;for(ce=0;v=A[E+ce++],k.head&&v&&k.length<65536&&(k.head.comment+=String.fromCharCode(v)),v&&ce<O;);if(512&k.flags&&(k.check=r(k.check,A,ce,E)),O-=ce,E+=ce,v)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;K<16;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(U!==(65535&k.check)){S.msg="header crc mismatch",k.mode=30;break}K=U=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),S.adler=k.check=0,k.mode=12;break;case 10:for(;K<32;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}S.adler=k.check=y(U),K=U=0,k.mode=11;case 11:if(k.havedict===0)return S.next_out=D,S.avail_out=J,S.next_in=E,S.avail_in=O,k.hold=U,k.bits=K,2;S.adler=k.check=1,k.mode=12;case 12:if(F===5||F===6)break e;case 13:if(k.last){U>>>=7&K,K-=7&K,k.mode=27;break}for(;K<3;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}switch(k.last=1&U,K-=1,3&(U>>>=1)){case 0:k.mode=14;break;case 1:if(z(k),k.mode=20,F!==6)break;U>>>=2,K-=2;break e;case 2:k.mode=17;break;case 3:S.msg="invalid block type",k.mode=30}U>>>=2,K-=2;break;case 14:for(U>>>=7&K,K-=7&K;K<32;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if((65535&U)!=(U>>>16^65535)){S.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&U,K=U=0,k.mode=15,F===6)break e;case 15:k.mode=16;case 16:if(ce=k.length){if(O<ce&&(ce=O),J<ce&&(ce=J),ce===0)break e;o.arraySet(H,A,E,ce,D),O-=ce,E+=ce,J-=ce,D+=ce,k.length-=ce;break}k.mode=12;break;case 17:for(;K<14;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(k.nlen=257+(31&U),U>>>=5,K-=5,k.ndist=1+(31&U),U>>>=5,K-=5,k.ncode=4+(15&U),U>>>=4,K-=4,286<k.nlen||30<k.ndist){S.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;K<3;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.lens[Z[k.have++]]=7&U,U>>>=3,K-=3}for(;k.have<19;)k.lens[Z[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,T={bits:k.lenbits},W=c(0,k.lens,0,19,k.lencode,0,k.work,T),k.lenbits=T.bits,W){S.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;ue=($=k.lencode[U&(1<<k.lenbits)-1])>>>16&255,Y=65535&$,!((we=$>>>24)<=K);){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(Y<16)U>>>=we,K-=we,k.lens[k.have++]=Y;else{if(Y===16){for(_=we+2;K<_;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(U>>>=we,K-=we,k.have===0){S.msg="invalid bit length repeat",k.mode=30;break}v=k.lens[k.have-1],ce=3+(3&U),U>>>=2,K-=2}else if(Y===17){for(_=we+3;K<_;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}K-=we,v=0,ce=3+(7&(U>>>=we)),U>>>=3,K-=3}else{for(_=we+7;K<_;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}K-=we,v=0,ce=11+(127&(U>>>=we)),U>>>=7,K-=7}if(k.have+ce>k.nlen+k.ndist){S.msg="invalid bit length repeat",k.mode=30;break}for(;ce--;)k.lens[k.have++]=v}}if(k.mode===30)break;if(k.lens[256]===0){S.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,T={bits:k.lenbits},W=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,T),k.lenbits=T.bits,W){S.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,T={bits:k.distbits},W=c(p,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,T),k.distbits=T.bits,W){S.msg="invalid distances set",k.mode=30;break}if(k.mode=20,F===6)break e;case 20:k.mode=21;case 21:if(6<=O&&258<=J){S.next_out=D,S.avail_out=J,S.next_in=E,S.avail_in=O,k.hold=U,k.bits=K,a(S,ae),D=S.next_out,H=S.output,J=S.avail_out,E=S.next_in,A=S.input,O=S.avail_in,U=k.hold,K=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;ue=($=k.lencode[U&(1<<k.lenbits)-1])>>>16&255,Y=65535&$,!((we=$>>>24)<=K);){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(ue&&(240&ue)==0){for(fe=we,P=ue,j=Y;ue=($=k.lencode[j+((U&(1<<fe+P)-1)>>fe)])>>>16&255,Y=65535&$,!(fe+(we=$>>>24)<=K);){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}U>>>=fe,K-=fe,k.back+=fe}if(U>>>=we,K-=we,k.back+=we,k.length=Y,ue===0){k.mode=26;break}if(32&ue){k.back=-1,k.mode=12;break}if(64&ue){S.msg="invalid literal/length code",k.mode=30;break}k.extra=15&ue,k.mode=22;case 22:if(k.extra){for(_=k.extra;K<_;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.length+=U&(1<<k.extra)-1,U>>>=k.extra,K-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;ue=($=k.distcode[U&(1<<k.distbits)-1])>>>16&255,Y=65535&$,!((we=$>>>24)<=K);){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if((240&ue)==0){for(fe=we,P=ue,j=Y;ue=($=k.distcode[j+((U&(1<<fe+P)-1)>>fe)])>>>16&255,Y=65535&$,!(fe+(we=$>>>24)<=K);){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}U>>>=fe,K-=fe,k.back+=fe}if(U>>>=we,K-=we,k.back+=we,64&ue){S.msg="invalid distance code",k.mode=30;break}k.offset=Y,k.extra=15&ue,k.mode=24;case 24:if(k.extra){for(_=k.extra;K<_;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}k.offset+=U&(1<<k.extra)-1,U>>>=k.extra,K-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){S.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(J===0)break e;if(ce=ae-J,k.offset>ce){if((ce=k.offset-ce)>k.whave&&k.sane){S.msg="invalid distance too far back",k.mode=30;break}ge=ce>k.wnext?(ce-=k.wnext,k.wsize-ce):k.wnext-ce,ce>k.length&&(ce=k.length),Te=k.window}else Te=H,ge=D-k.offset,ce=k.length;for(J<ce&&(ce=J),J-=ce,k.length-=ce;H[D++]=Te[ge++],--ce;);k.length===0&&(k.mode=21);break;case 26:if(J===0)break e;H[D++]=k.length,J--,k.mode=21;break;case 27:if(k.wrap){for(;K<32;){if(O===0)break e;O--,U|=A[E++]<<K,K+=8}if(ae-=J,S.total_out+=ae,k.total+=ae,ae&&(S.adler=k.check=k.flags?r(k.check,H,ae,D-ae):l(k.check,H,ae,D-ae)),ae=J,(k.flags?U:y(U))!==k.check){S.msg="incorrect data check",k.mode=30;break}K=U=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;K<32;){if(O===0)break e;O--,U+=A[E++]<<K,K+=8}if(U!==(4294967295&k.total)){S.msg="incorrect length check",k.mode=30;break}K=U=0}k.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return u}return S.next_out=D,S.avail_out=J,S.next_in=E,S.avail_in=O,k.hold=U,k.bits=K,(k.wsize||ae!==S.avail_out&&k.mode<30&&(k.mode<27||F!==4))&&V(S,S.output,S.next_out,ae-S.avail_out)?(k.mode=31,-4):(se-=S.avail_in,ae-=S.avail_out,S.total_in+=se,S.total_out+=ae,k.total+=ae,k.wrap&&ae&&(S.adler=k.check=k.flags?r(k.check,H,ae,S.next_out-ae):l(k.check,H,ae,S.next_out-ae)),S.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(se==0&&ae===0||F===4)&&W===g&&(W=-5),W)},s.inflateEnd=function(S){if(!S||!S.state)return u;var F=S.state;return F.window&&(F.window=null),S.state=null,g},s.inflateGetHeader=function(S,F){var k;return S&&S.state?(2&(k=S.state).wrap)==0?u:((k.head=F).done=!1,g):u},s.inflateSetDictionary=function(S,F){var k,A=F.length;return S&&S.state?(k=S.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,F,A,0)!==k.check?-3:V(S,F,A,A)?(k.mode=31,-4):(k.havedict=1,g):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,g,u,m,h,b,y){var x,C,M,B,I,w,N,R,z,V=y.bits,S=0,F=0,k=0,A=0,H=0,E=0,D=0,O=0,J=0,U=0,K=null,se=0,ae=new o.Buf16(16),ce=new o.Buf16(16),ge=null,Te=0;for(S=0;S<=15;S++)ae[S]=0;for(F=0;F<u;F++)ae[p[g+F]]++;for(H=V,A=15;1<=A&&ae[A]===0;A--);if(A<H&&(H=A),A===0)return m[h++]=20971520,m[h++]=20971520,y.bits=1,0;for(k=1;k<A&&ae[k]===0;k++);for(H<k&&(H=k),S=O=1;S<=15;S++)if(O<<=1,(O-=ae[S])<0)return-1;if(0<O&&(d===0||A!==1))return-1;for(ce[1]=0,S=1;S<15;S++)ce[S+1]=ce[S]+ae[S];for(F=0;F<u;F++)p[g+F]!==0&&(b[ce[p[g+F]]++]=F);if(w=d===0?(K=ge=b,19):d===1?(K=l,se-=257,ge=r,Te-=257,256):(K=a,ge=c,-1),S=k,I=h,D=F=U=0,M=-1,B=(J=1<<(E=H))-1,d===1&&852<J||d===2&&592<J)return 1;for(;;){for(N=S-D,z=b[F]<w?(R=0,b[F]):b[F]>w?(R=ge[Te+b[F]],K[se+b[F]]):(R=96,0),x=1<<S-D,k=C=1<<E;m[I+(U>>D)+(C-=x)]=N<<24|R<<16|z|0,C!==0;);for(x=1<<S-1;U&x;)x>>=1;if(x!==0?(U&=x-1,U+=x):U=0,F++,--ae[S]==0){if(S===A)break;S=p[g+b[F]]}if(H<S&&(U&B)!==M){for(D===0&&(D=H),I+=k,O=1<<(E=S-D);E+D<A&&!((O-=ae[E+D])<=0);)E++,O<<=1;if(J+=1<<E,d===1&&852<J||d===2&&592<J)return 1;m[M=U&B]=H<<24|E<<16|I-h|0}}return U!==0&&(m[I+U]=S-D<<24|64<<16|0),y.bits=H,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),l=0,r=1;function a($){for(var L=$.length;0<=--L;)$[L]=0}var c=0,d=29,p=256,g=p+1+d,u=30,m=19,h=2*g+1,b=15,y=16,x=7,C=256,M=16,B=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],V=new Array(2*(g+2));a(V);var S=new Array(2*u);a(S);var F=new Array(512);a(F);var k=new Array(256);a(k);var A=new Array(d);a(A);var H,E,D,O=new Array(u);function J($,L,Z,G,q){this.static_tree=$,this.extra_bits=L,this.extra_base=Z,this.elems=G,this.max_length=q,this.has_stree=$&&$.length}function U($,L){this.dyn_tree=$,this.max_code=0,this.stat_desc=L}function K($){return $<256?F[$]:F[256+($>>>7)]}function se($,L){$.pending_buf[$.pending++]=255&L,$.pending_buf[$.pending++]=L>>>8&255}function ae($,L,Z){$.bi_valid>y-Z?($.bi_buf|=L<<$.bi_valid&65535,se($,$.bi_buf),$.bi_buf=L>>y-$.bi_valid,$.bi_valid+=Z-y):($.bi_buf|=L<<$.bi_valid&65535,$.bi_valid+=Z)}function ce($,L,Z){ae($,Z[2*L],Z[2*L+1])}function ge($,L){for(var Z=0;Z|=1&$,$>>>=1,Z<<=1,0<--L;);return Z>>>1}function Te($,L,Z){var G,q,ee=new Array(b+1),le=0;for(G=1;G<=b;G++)ee[G]=le=le+Z[G-1]<<1;for(q=0;q<=L;q++){var oe=$[2*q+1];oe!==0&&($[2*q]=ge(ee[oe]++,oe))}}function we($){var L;for(L=0;L<g;L++)$.dyn_ltree[2*L]=0;for(L=0;L<u;L++)$.dyn_dtree[2*L]=0;for(L=0;L<m;L++)$.bl_tree[2*L]=0;$.dyn_ltree[2*C]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function ue($){8<$.bi_valid?se($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function Y($,L,Z,G){var q=2*L,ee=2*Z;return $[q]<$[ee]||$[q]===$[ee]&&G[L]<=G[Z]}function fe($,L,Z){for(var G=$.heap[Z],q=Z<<1;q<=$.heap_len&&(q<$.heap_len&&Y(L,$.heap[q+1],$.heap[q],$.depth)&&q++,!Y(L,G,$.heap[q],$.depth));)$.heap[Z]=$.heap[q],Z=q,q<<=1;$.heap[Z]=G}function P($,L,Z){var G,q,ee,le,oe=0;if($.last_lit!==0)for(;G=$.pending_buf[$.d_buf+2*oe]<<8|$.pending_buf[$.d_buf+2*oe+1],q=$.pending_buf[$.l_buf+oe],oe++,G===0?ce($,q,L):(ce($,(ee=k[q])+p+1,L),(le=w[ee])!==0&&ae($,q-=A[ee],le),ce($,ee=K(--G),Z),(le=N[ee])!==0&&ae($,G-=O[ee],le)),oe<$.last_lit;);ce($,C,L)}function j($,L){var Z,G,q,ee=L.dyn_tree,le=L.stat_desc.static_tree,oe=L.stat_desc.has_stree,pe=L.stat_desc.elems,ie=-1;for($.heap_len=0,$.heap_max=h,Z=0;Z<pe;Z++)ee[2*Z]!==0?($.heap[++$.heap_len]=ie=Z,$.depth[Z]=0):ee[2*Z+1]=0;for(;$.heap_len<2;)ee[2*(q=$.heap[++$.heap_len]=ie<2?++ie:0)]=1,$.depth[q]=0,$.opt_len--,oe&&($.static_len-=le[2*q+1]);for(L.max_code=ie,Z=$.heap_len>>1;1<=Z;Z--)fe($,ee,Z);for(q=pe;Z=$.heap[1],$.heap[1]=$.heap[$.heap_len--],fe($,ee,1),G=$.heap[1],$.heap[--$.heap_max]=Z,$.heap[--$.heap_max]=G,ee[2*q]=ee[2*Z]+ee[2*G],$.depth[q]=($.depth[Z]>=$.depth[G]?$.depth[Z]:$.depth[G])+1,ee[2*Z+1]=ee[2*G+1]=q,$.heap[1]=q++,fe($,ee,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(ne,Ce){var Be,Ne,Re,De,Yt,ot,Je=Ce.dyn_tree,Nt=Ce.max_code,Fi=Ce.stat_desc.static_tree,Hs=Ce.stat_desc.has_stree,js=Ce.stat_desc.extra_bits,Un=Ce.stat_desc.extra_base,xi=Ce.stat_desc.max_length,Hi=0;for(De=0;De<=b;De++)ne.bl_count[De]=0;for(Je[2*ne.heap[ne.heap_max]+1]=0,Be=ne.heap_max+1;Be<h;Be++)xi<(De=Je[2*Je[2*(Ne=ne.heap[Be])+1]+1]+1)&&(De=xi,Hi++),Je[2*Ne+1]=De,Nt<Ne||(ne.bl_count[De]++,Yt=0,Un<=Ne&&(Yt=js[Ne-Un]),ot=Je[2*Ne],ne.opt_len+=ot*(De+Yt),Hs&&(ne.static_len+=ot*(Fi[2*Ne+1]+Yt)));if(Hi!==0){do{for(De=xi-1;ne.bl_count[De]===0;)De--;ne.bl_count[De]--,ne.bl_count[De+1]+=2,ne.bl_count[xi]--,Hi-=2}while(0<Hi);for(De=xi;De!==0;De--)for(Ne=ne.bl_count[De];Ne!==0;)Nt<(Re=ne.heap[--Be])||(Je[2*Re+1]!==De&&(ne.opt_len+=(De-Je[2*Re+1])*Je[2*Re],Je[2*Re+1]=De),Ne--)}})($,L),Te(ee,ie,$.bl_count)}function v($,L,Z){var G,q,ee=-1,le=L[1],oe=0,pe=7,ie=4;for(le===0&&(pe=138,ie=3),L[2*(Z+1)+1]=65535,G=0;G<=Z;G++)q=le,le=L[2*(G+1)+1],++oe<pe&&q===le||(oe<ie?$.bl_tree[2*q]+=oe:q!==0?(q!==ee&&$.bl_tree[2*q]++,$.bl_tree[2*M]++):oe<=10?$.bl_tree[2*B]++:$.bl_tree[2*I]++,ee=q,ie=(oe=0)===le?(pe=138,3):q===le?(pe=6,3):(pe=7,4))}function W($,L,Z){var G,q,ee=-1,le=L[1],oe=0,pe=7,ie=4;for(le===0&&(pe=138,ie=3),G=0;G<=Z;G++)if(q=le,le=L[2*(G+1)+1],!(++oe<pe&&q===le)){if(oe<ie)for(;ce($,q,$.bl_tree),--oe!=0;);else q!==0?(q!==ee&&(ce($,q,$.bl_tree),oe--),ce($,M,$.bl_tree),ae($,oe-3,2)):oe<=10?(ce($,B,$.bl_tree),ae($,oe-3,3)):(ce($,I,$.bl_tree),ae($,oe-11,7));ee=q,ie=(oe=0)===le?(pe=138,3):q===le?(pe=6,3):(pe=7,4)}}a(O);var T=!1;function _($,L,Z,G){ae($,(c<<1)+(G?1:0),3),(function(q,ee,le,oe){ue(q),se(q,le),se(q,~le),o.arraySet(q.pending_buf,q.window,ee,le,q.pending),q.pending+=le})($,L,Z)}s._tr_init=function($){T||((function(){var L,Z,G,q,ee,le=new Array(b+1);for(q=G=0;q<d-1;q++)for(A[q]=G,L=0;L<1<<w[q];L++)k[G++]=q;for(k[G-1]=q,q=ee=0;q<16;q++)for(O[q]=ee,L=0;L<1<<N[q];L++)F[ee++]=q;for(ee>>=7;q<u;q++)for(O[q]=ee<<7,L=0;L<1<<N[q]-7;L++)F[256+ee++]=q;for(Z=0;Z<=b;Z++)le[Z]=0;for(L=0;L<=143;)V[2*L+1]=8,L++,le[8]++;for(;L<=255;)V[2*L+1]=9,L++,le[9]++;for(;L<=279;)V[2*L+1]=7,L++,le[7]++;for(;L<=287;)V[2*L+1]=8,L++,le[8]++;for(Te(V,g+1,le),L=0;L<u;L++)S[2*L+1]=5,S[2*L]=ge(L,5);H=new J(V,w,p+1,g,b),E=new J(S,N,0,u,b),D=new J(new Array(0),R,0,m,x)})(),T=!0),$.l_desc=new U($.dyn_ltree,H),$.d_desc=new U($.dyn_dtree,E),$.bl_desc=new U($.bl_tree,D),$.bi_buf=0,$.bi_valid=0,we($)},s._tr_stored_block=_,s._tr_flush_block=function($,L,Z,G){var q,ee,le=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(oe){var pe,ie=4093624447;for(pe=0;pe<=31;pe++,ie>>>=1)if(1&ie&&oe.dyn_ltree[2*pe]!==0)return l;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(pe=32;pe<p;pe++)if(oe.dyn_ltree[2*pe]!==0)return r;return l})($)),j($,$.l_desc),j($,$.d_desc),le=(function(oe){var pe;for(v(oe,oe.dyn_ltree,oe.l_desc.max_code),v(oe,oe.dyn_dtree,oe.d_desc.max_code),j(oe,oe.bl_desc),pe=m-1;3<=pe&&oe.bl_tree[2*z[pe]+1]===0;pe--);return oe.opt_len+=3*(pe+1)+5+5+4,pe})($),q=$.opt_len+3+7>>>3,(ee=$.static_len+3+7>>>3)<=q&&(q=ee)):q=ee=Z+5,Z+4<=q&&L!==-1?_($,L,Z,G):$.strategy===4||ee===q?(ae($,2+(G?1:0),3),P($,V,S)):(ae($,4+(G?1:0),3),(function(oe,pe,ie,ne){var Ce;for(ae(oe,pe-257,5),ae(oe,ie-1,5),ae(oe,ne-4,4),Ce=0;Ce<ne;Ce++)ae(oe,oe.bl_tree[2*z[Ce]+1],3);W(oe,oe.dyn_ltree,pe-1),W(oe,oe.dyn_dtree,ie-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,le+1),P($,$.dyn_ltree,$.dyn_dtree)),we($),G&&ue($)},s._tr_tally=function($,L,Z){return $.pending_buf[$.d_buf+2*$.last_lit]=L>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&L,$.pending_buf[$.l_buf+$.last_lit]=255&Z,$.last_lit++,L===0?$.dyn_ltree[2*Z]++:($.matches++,L--,$.dyn_ltree[2*(k[Z]+p+1)]++,$.dyn_dtree[2*K(L)]++),$.last_lit===$.lit_bufsize-1},s._tr_align=function($){ae($,2,3),ce($,C,V),(function(L){L.bi_valid===16?(se(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,p,g=1,u={},m=!1,h=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(M){process.nextTick(function(){x(M)})}:(function(){if(l.postMessage&&!l.importScripts){var M=!0,B=l.onmessage;return l.onmessage=function(){M=!1},l.postMessage("","*"),l.onmessage=B,M}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",C,!1):l.attachEvent("onmessage",C),function(M){l.postMessage(p+M,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(M){x(M.data)},function(M){d.port2.postMessage(M)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(M){var B=h.createElement("script");B.onreadystatechange=function(){x(M),B.onreadystatechange=null,c.removeChild(B),B=null},c.appendChild(B)}):function(M){setTimeout(x,0,M)},b.setImmediate=function(M){typeof M!="function"&&(M=new Function(""+M));for(var B=new Array(arguments.length-1),I=0;I<B.length;I++)B[I]=arguments[I+1];var w={callback:M,args:B};return u[g]=w,a(g),g++},b.clearImmediate=y}function y(M){delete u[M]}function x(M){if(m)setTimeout(x,0,M);else{var B=u[M];if(B){m=!0;try{(function(I){var w=I.callback,N=I.args;switch(N.length){case 0:w();break;case 1:w(N[0]);break;case 2:w(N[0],N[1]);break;case 3:w(N[0],N[1],N[2]);break;default:w.apply(r,N)}})(B)}finally{y(M),m=!1}}}}function C(M){M.source===l&&typeof M.data=="string"&&M.data.indexOf(p)===0&&x(+M.data.slice(p.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof Qn<"u"?Qn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(oo)),oo.exports}var h0=p0();const m0=f0(h0),g0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,v0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function b0(e){const t=await m0.loadAsync(e),i={},n=[];let s="",o="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||v0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(g0.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:g})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function y0(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const o=s.pageAttrs["custom-slidev-background"],l=i(o);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const s=e.docRootAttrs["custom-slidev-background"],o=i(s);o&&(e.docRootAttrs["custom-slidev-background"]=o)}return e}function Na(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function k0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[m,h]of Object.entries(a))if(m.endsWith(`/${r}`)||u&&m.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const m=require("path");u.push(m.resolve(t.baseDir,r)),u.push(m.resolve(t.baseDir,o))}catch{}try{const m=require("path");u.push(m.resolve(process.cwd(),r))}catch{}for(const m of u){const h=Na(m);if(h!==null){c=h;break}}}if(!c){const u=Ca||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const m=r.split("/").pop();for(const[h,b]of Object.entries(u))if(h.endsWith(`/${r}`)||m&&h.endsWith(`/${m}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),m=c.match(u);if(m){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+m[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function w0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function ss(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),m=u?u[1].length:0;if(d===-1&&(d=m),m<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=w0(a),!a){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const g=i[c],u=g.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const m=g.match(/^(\s+)/),h=m?m[1].length:0;if(p===-1)if(h>0)p=h;else break;if(h<p)break;d.push(g.slice(p)),c++}if(d.length>0){t[r]=ss(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const x0=/^\s*```ya?ml([\s\S]*?)```/;function Jr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=ss(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(x0);if(s)t=ss(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=ss(l.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function S0(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(l=p)}}return n<t.length&&o(t.length),i}function os(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=S0(d),g={};let u="",m="",h=0;if(p.length>0){const z=p[0],V=Jr(z),S=Object.keys(V.frontmatter).length>0,F=V.content.length>0;S&&!F&&p.length>1?(h=1,b(V.frontmatter)):S&&b(V.frontmatter)}function b(z){u=z.title||"",z.theme&&(g[En]=String(z.theme)),z.aspectRatio&&(g[An]=String(z.aspectRatio)),z.highlighter&&(g[rl]=String(z.highlighter)),z.transition&&(g[Bn]=String(z.transition)),z.colorSchema&&(g[ll]=String(z.colorSchema)),z.layout&&(g[ye]=String(z.layout)),z.background&&(g[et]=String(z.background)),z.image&&(g[Mt]=String(z.image)),z.class&&(g[Ki]=String(z.class));for(const[V,S]of Object.entries(z))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(V)||(g[`custom-slidev-${V}`]=typeof S=="object"?JSON.stringify(S):String(S))}const y=[];let x=0,C=0,M=0,B=0;const I=new Set,w={};let N=1;for(let z=h;z<p.length;z++){const V=p[z],{frontmatter:S,content:F}=Jr(V),k=V.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),A=S.src||(k?k[1]:void 0);if(A){const ue=String(A).trim().replace(/^['"]|['"]$/g,"");let Y=c[ue]||c[ue.replace(/^\.\//,"")]||c[`pages/${ue.replace(/^.*pages\//,"")}`];if(!Y){const P=ue.replace(/^\.\//,""),j=[];if(t.baseDir)try{const v=require("path");j.push(v.resolve(t.baseDir,P)),j.push(v.resolve(t.baseDir,ue))}catch{}try{const v=require("path");j.push(v.resolve(process.cwd(),P)),j.push(v.resolve(process.cwd(),ue))}catch{}for(const v of j){const W=Na(v);if(W!==null){Y=W;break}}}const fe={};S.layout&&(fe[ye]=String(S.layout)),S.transition&&(fe[pt]=String(S.transition)),S.background&&(fe[et]=String(S.background)),S.image&&(fe[Mt]=String(S.image)),S.class&&(fe[Ki]=String(S.class));for(const[P,j]of Object.entries(S))["src","layout","transition","background","image","class"].includes(P)||(fe[`custom-slidev-${P}`]=typeof j=="object"?JSON.stringify(j):String(j));if(Y){const P=os(Y,{...t,virtualFiles:c});for(const j of P.slides){j.pageIndex=N++,j.pageAttrs={...fe,...j.pageAttrs},y.push(j);const v=j.pageAttrs[ye]||"default";w[v]=(w[v]||0)+1}continue}else{y.push({pageIndex:N++,pageAttrs:{...fe,"custom-slidev-src":ue},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${ue}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const P=fe[ye]||"default";w[P]=(w[P]||0)+1;continue}}const H={};S.layout&&(H[ye]=String(S.layout)),S.transition&&(H[pt]=String(S.transition)),S.background&&(H[et]=String(S.background)),S.image&&(H[Mt]=String(S.image)),S.class&&(H[Ki]=String(S.class)),S.mask&&(H[Gi]=String(S.mask)),(S.maskRatio||S["mask-ratio"])&&(H[qi]=String(S.maskRatio||S["mask-ratio"])),(S.maskStyle||S["mask-style"])&&(H[Zi]=String(S.maskStyle||S["mask-style"])),(S.maskInitial||S["mask-initial"])&&(H[Yi]=String(S.maskInitial||S["mask-initial"]));for(const[ue,Y]of Object.entries(S))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(ue)||(H[`custom-slidev-${ue}`]=typeof Y=="object"?JSON.stringify(Y):String(Y));let E=F;const D=[];let O=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,ue=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ue),Y});O=O.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,ue=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ue),Y});let J="";const U=Array.from(O.matchAll(/<!--([\s\S]*?)-->/g));if(U.length>0){const ue=U[U.length-1],Y=O.slice(ue.index+ue[0].length).trim();if(!Y||!Y.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const P=ue[1].trim();P.startsWith("TODO:")||(J=P,x++),i&&(O=O.slice(0,ue.index).trimEnd()+O.slice(ue.index+ue[0].length))}}i&&(O=O.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let ue=0;ue<D.length;ue++)O=O.replace(`__CODE_TOKEN_NOTE_${ue}__`,D[ue]);if(E=O,J){for(let fe=0;fe<D.length;fe++)J=J.replace(`__CODE_TOKEN_NOTE_${fe}__`,D[fe]);const Y=`> [!NOTE] 💡 演讲备注
${J.split(/\r?\n/).map(fe=>`> ${fe}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${Y}`:Y}let K=!1;if(/<style\b/i.test(E)){K=!0;const ue=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(ue){for(const Y of ue){const fe=Y.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();m=m?`${m}

${fe}`:fe}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const se=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);se&&(C+=se.length);const ae=E.match(/```\w+\s+\{[^}]+\}/g);ae&&(M+=ae.length);const ce=E.match(/::\w+::|<template\s+#[^>]+>/g);if(ce&&(B+=ce.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,ue=>k0(ue,{...t,virtualFiles:c})||ue),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=Bf(E)),a){let ue=E.trim(),Y="";const fe=ue.lastIndexOf("> [!NOTE] 💡 演讲备注");if(fe!==-1&&(Y=ue.slice(fe),ue=ue.slice(0,fe).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const P=String(S.image).trim(),j=S.layout==="image-left"?"image-left":"image-right",v=`![配图](${P})
{: custom-slidev-layout="${j}" }`;S.layout==="image-left"?ue=`{{{col

${v}

${ue}

}}}`:ue=`{{{col

${ue}

${v}

}}}`}if(S.background){const j=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;ue=ue?`${j}

${ue}`:j}E=Y?`${ue}

${Y}`:ue}const ge=_0(E);H[et]&&ge.push(H[et]),H[Mt]&&ge.push(H[Mt]);for(const ue of ge)I.add(ue);const Te=/<[A-Z][a-zA-Z0-9]+/.test(E),we=H[ye]||(N===1?g[ye]||"cover":"default");w[we]=(w[we]||0)+1,y.push({pageIndex:N++,pageAttrs:H,notes:J,rawMarkdown:E,hasVueComponent:Te,hasStyleTag:K,assetReferences:ge})}if(!u&&y.length>0){const z=y[0].rawMarkdown.match(/^#\s+(.+)$/m);z&&(u=z[1].trim())}m&&(g["custom-slidev-custom-css"]=m);let R=y.map(z=>`---

${z.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:C,totalShikiHighlights:M,totalSlots:B,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:R,customCss:m}}function _0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function za(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function C0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function $0(e,t,i=je){const n=e.filter(za);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const l=t[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const l=t[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}return s}async function I0(e,t=je){let i=!1,n=0;for(const s of e){if(za(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[$e]:"right"}).catch(()=>{}),n++)}return n}async function T0(e,t,i=il){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&y0(e,n),n}async function E0(e){var M;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||il,d=a.createDocFn||Nc,p=a.setAttrsFn||je,g=a.getChildBlocksFn||ds,u=a.openTabFn||me.openTab,m=a.showMessageFn||me.showMessage;o&&s.length>0&&await T0(t,s,c);const h=C0(n),b=`/${h}`,y=await d(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((M=t.slides[0])==null?void 0:M.pageAttrs)||{};await p(y,{...x,...t.docRootAttrs});const C=await g(y).catch(()=>[]);return Array.isArray(C)&&C.length>0&&(await $0(C,t.slides,p),await I0(C,p)),m(`🎉 成功导入 Slidev 演示文档《${h}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function A0(e){const t=he("file"),i=he(!1),n=he(!1),s=he(""),o=he(null),l=he(null),r=he(""),a=he(0),c=he(""),d=he([]),p=he(null),g=he(""),u=he([]),m=he(""),h=he(!0),b=he(!0),y=he(!0),x=he(!0),C=ke(()=>{const H=a.value;if(H===0)return"0 B";const E=1024,D=["B","KB","MB","GB"],O=Math.floor(Math.log(H)/Math.log(E));return`${(H/E**O).toFixed(1)} ${D[O]}`}),M=ke(()=>{var H;return((H=p.value)==null?void 0:H.docRootAttrs["custom-slidev-theme"])||"default"}),B=ke(()=>{var H;return d.value.length>0?d.value.length:((H=p.value)==null?void 0:H.stats.discoveredAssets.length)||0}),I=ke(()=>{var E;const H=((E=p.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(H).map(([D,O])=>({name:D,count:O}))});async function w(H=Rc){try{const E=await H();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(u.value=E.notebooks.filter(D=>!D.closed),u.value.length>0&&!m.value&&(m.value=u.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function N(){var H;(H=o.value)==null||H.click()}function R(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],s.value=""}async function z(H){s.value="",l.value=H,r.value=H.name,a.value=H.size;try{if(H.name.toLowerCase().endsWith(".zip")){const D=await H.arrayBuffer(),O=await b0(D);if(!O.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=O.assets;const J=os(O.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,virtualFiles:O.virtualFiles});p.value=J,g.value=J.docTitle||H.name.replace(/\.zip$/i,"")}else{const D=await H.text();d.value=[];const O=H.path||"",J=O?O.replace(/[\\/][^\\/]+$/,""):"",U=os(D,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,baseDir:J||void 0});p.value=U,g.value=U.docTitle||H.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),s.value=`解析文件失败: ${E.message||String(E)}`}}function V(){if(s.value="",!c.value.trim()){p.value=null;return}try{const H=os(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1});p.value=H,g.value=H.docTitle||"Slidev 演示文稿"}catch(H){s.value=`解析 Markdown 源码失败: ${H.message||String(H)}`}}async function S(){l.value?await z(l.value):c.value&&V()}async function F(H){const E=H.target;E.files&&E.files[0]&&await z(E.files[0])}async function k(H){var E;i.value=!1,(E=H.dataTransfer)!=null&&E.files&&H.dataTransfer.files[0]&&await z(H.dataTransfer.files[0])}async function A(H=e){if(p.value){if(!m.value&&u.value.length>0&&(m.value=u.value[0].id),!m.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await E0({presentation:p.value,notebookId:m.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:x.value,plugin:H})}catch(E){console.error("导入 Slidev 演示失败:",E),s.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:g,notebooks:u,selectedNotebookId:m,optCleanHtml:h,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:C,currentTheme:M,extractedAssetsCount:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:R,processFile:z,onFileSelected:F,onFileDrop:k,onTextChange:V,reprocessCurrentInput:S,handleConfirmImport:A}}const B0={class:"spm-import-dialog"},M0={class:"spm-tabs-header"},D0={class:"spm-dialog-body"},L0={key:0,class:"spm-file-section"},P0={key:0,class:"spm-dropzone-prompt"},O0={class:"spm-dropzone-icon"},R0={key:1,class:"spm-dropzone-active"},N0={class:"spm-file-badge"},z0={class:"spm-file-size"},F0={key:1,class:"spm-text-section"},H0={key:2,class:"spm-error-banner"},j0={key:3,class:"spm-preview-card"},W0={class:"spm-preview-card__header"},U0={style:{display:"inline-flex","align-items":"center",gap:"4px"}},V0={class:"spm-config-grid"},K0={class:"spm-form-item"},G0={class:"spm-form-item"},q0=["value"],Z0={class:"spm-stats-grid"},Y0={class:"spm-stat-box"},J0={class:"spm-stat-value"},X0={class:"spm-stat-box"},Q0={class:"spm-stat-value"},ek={class:"spm-stat-box"},tk={class:"spm-stat-value"},ik={class:"spm-stat-box"},nk={class:"spm-stat-value"},sk={key:0,class:"spm-chips-row"},ok={class:"spm-options-group"},rk={class:"spm-checkbox-label"},lk={class:"spm-checkbox-label"},ak={class:"spm-checkbox-label"},ck={class:"spm-checkbox-label"},dk={class:"spm-dialog-footer"},uk=["disabled"],fk=["disabled"],pk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},hk={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},mk=It({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Lt("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:g,customDocTitle:u,notebooks:m,selectedNotebookId:h,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:C,formattedFileSize:M,currentTheme:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:R,onFileSelected:z,onFileDrop:V,onTextChange:S,reprocessCurrentInput:F,handleConfirmImport:k}=A0(n);dn(async()=>{await w()});async function A(){const E=await k();E&&(i("success",{docId:E}),i("close"))}function H(){i("close")}return(E,D)=>(Q(),te("div",{class:"spm-modal-overlay",onClick:ii(H,["self"])},[f("div",B0,[f("div",{class:"spm-dialog-header"},[D[18]||(D[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlidev"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:H},"✕")]),f("div",M0,[f("button",{class:_e(["spm-tab-btn",{active:be(s)==="file"}]),onClick:D[0]||(D[0]=O=>s.value="file")},[re(de,{name:"package"}),D[19]||(D[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:_e(["spm-tab-btn",{active:be(s)==="text"}]),onClick:D[1]||(D[1]=O=>s.value="text")},[re(de,{name:"notes"}),D[20]||(D[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",D0,[be(s)==="file"?(Q(),te("div",L0,[f("div",{class:_e(["spm-dropzone",{dragover:be(o),"has-file":!!be(c)}]),onDragover:D[4]||(D[4]=ii(O=>o.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=ii(O=>o.value=!1,["prevent"])),onDrop:D[6]||(D[6]=ii((...O)=>be(V)&&be(V)(...O),["prevent"])),onClick:D[7]||(D[7]=(...O)=>be(N)&&be(N)(...O))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...O)=>be(z)&&be(z)(...O))},null,544),be(c)?(Q(),te("div",R0,[f("span",N0,[re(de,{name:"notes"}),St(" "+xe(be(c)),1)]),f("span",z0,"("+xe(be(M))+")",1),f("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=ii((...O)=>be(R)&&be(R)(...O),["stop"]))},"更换文件")])):(Q(),te("div",P0,[f("span",O0,[re(de,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=f("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(Q(),te("div",F0,[Bt(f("textarea",{"onUpdate:modelValue":D[8]||(D[8]=O=>Ye(d)?d.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...O)=>be(S)&&be(S)(...O))},null,544),[[Co,be(d)]])])),be(r)?(Q(),te("div",H0," ⚠️ "+xe(be(r)),1)):Le("",!0),be(g)?(Q(),te("div",j0,[f("div",W0,[f("span",U0,[re(de,{name:"sparkles"}),D[23]||(D[23]=St(" 演示解析摘要",-1))]),D[24]||(D[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",V0,[f("div",K0,[D[25]||(D[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Bt(f("input",{"onUpdate:modelValue":D[10]||(D[10]=O=>Ye(u)?u.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Co,be(u)]])]),f("div",G0,[D[26]||(D[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Bt(f("select",{"onUpdate:modelValue":D[11]||(D[11]=O=>Ye(h)?h.value=O:null),class:"spm-select"},[(Q(!0),te(Ke,null,kt(be(m),O=>(Q(),te("option",{key:O.id,value:O.id},xe(O.name),9,q0))),128))],512),[[uf,be(h)]])])]),f("div",Z0,[f("div",Y0,[f("span",J0,xe(be(g).totalSlides),1),D[27]||(D[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",X0,[f("span",Q0,xe(be(B)),1),D[28]||(D[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",ek,[f("span",tk,xe(be(g).stats.totalNotes),1),D[29]||(D[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",ik,[f("span",nk,xe(be(p)),1),D[30]||(D[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),be(I).length>0?(Q(),te("div",sk,[D[31]||(D[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(Q(!0),te(Ke,null,kt(be(I),O=>(Q(),te("span",{key:O.name,class:"spm-chip-badge"},xe(O.name)+": "+xe(O.count),1))),128))])):Le("",!0),f("div",ok,[f("label",rk,[Bt(f("input",{"onUpdate:modelValue":D[12]||(D[12]=O=>Ye(b)?b.value=O:null),type:"checkbox",onChange:D[13]||(D[13]=(...O)=>be(F)&&be(F)(...O))},null,544),[[Jn,be(b)]]),D[32]||(D[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",lk,[Bt(f("input",{"onUpdate:modelValue":D[14]||(D[14]=O=>Ye(y)?y.value=O:null),type:"checkbox",onChange:D[15]||(D[15]=(...O)=>be(F)&&be(F)(...O))},null,544),[[Jn,be(y)]]),D[33]||(D[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",ak,[Bt(f("input",{"onUpdate:modelValue":D[16]||(D[16]=O=>Ye(x)?x.value=O:null),type:"checkbox"},null,512),[[Jn,be(x)]]),D[34]||(D[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",ck,[Bt(f("input",{"onUpdate:modelValue":D[17]||(D[17]=O=>Ye(C)?C.value=O:null),type:"checkbox"},null,512),[[Jn,be(C)]]),D[35]||(D[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Le("",!0)]),f("div",dk,[f("button",{class:"spm-btn-secondary",disabled:be(l),onClick:H}," 取消 ",8,uk),f("button",{class:"spm-btn-primary",disabled:!be(g)||be(l),onClick:A},[be(l)?(Q(),te("span",pk,[re(de,{name:"refresh"}),D[36]||(D[36]=St(" 正在导入生成中...",-1))])):(Q(),te("span",hk,[re(de,{name:"rocket"}),D[37]||(D[37]=St(" 确认导入思源笔记",-1))]))],8,fk)])])]))}}),gk=Zt(mk,[["__scopeId","data-v-2eff6f1e"]]);function nr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function vk(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(nr(o)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(s){let a=e.find(c=>c.startBlockId===s);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===s}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===i))||((g=d.allBlockIds)==null?void 0:g.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(g=>g.id===i||g.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[$e];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,g;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function tt(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function bk(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ye}], .protyle-wysiwyg [${qe}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ye),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qe),n.removeAttribute("custom-slidev-role");return}const o=e.get(s),l=(o==null?void 0:o[ye])||(o==null?void 0:o["custom-slidev-layout"])||"",r=n.getAttribute(ye)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ye,l):(n.removeAttribute(ye),n.removeAttribute("custom-slidev-layout")));const a=(o==null?void 0:o[qe])||(o==null?void 0:o["custom-slidev-role"])||"",c=n.getAttribute(qe)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qe,a):(n.removeAttribute(qe),n.removeAttribute("custom-slidev-role")))})}function yk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function kk(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[m,h]of Object.entries(c))e.activeBlockAttrs.value[m]=h;Pe.setBlockAttrOverride(d,c),tt(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,g=!!(p&&yk(d,p));if(Ze in c&&g&&p){const m=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=m),Pe.setBlockAttrOverride(p,{[Ze]:m}),tt(p,{[Ze]:m}),je(p,{[Ze]:m}).catch(()=>{})}if(ye in c){const m=c[ye];e.currentPageDividerLayout.value=m,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=m)}if(yt in c){const m=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=m)}i("保存中...");try{await je(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=o();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Pe.setBlockAttrOverride(p,{[c]:d}),tt(p,{[c]:d}),c===ye&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await je(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=o();if(!p)return;const g={[ye]:c,[yt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[ye]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(p,g),tt(p,g),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await je(p,g),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var g;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Pe.setBlockAttrOverride(p,{[c]:d}),tt(p,{[c]:d}),(g=e.latestDoc.value)!=null&&g.config&&(c===En&&(e.latestDoc.value.config.theme=d),c===An&&(e.latestDoc.value.config.aspectRatio=d),c===Bn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await je(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Xr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function Fa(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:Xr(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:Xr(e),isAiGenerated:!1}}async function wk(e,t){return(await Fa(e,t)).notes}function xk(e,t){const i=he(!1),{triggerSaveNotice:n}=t;async function s(p){var M,B,I,w,N,R,z,V;const m=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(S=>`> ${S}`).join(`
`)}
{: custom-slidev-note="true"}`,h=((M=e.latestDoc.value)==null?void 0:M.slides)||[],b=e.targetSlide.value,y=b?h.findIndex(S=>S===b):-1;let x=null;if(y!==-1&&y<h.length-1){const S=h[y+1];x=await Bi("markdown",m,S.startBlockId)}else{const S=((B=b==null?void 0:b.noteBlocks)==null?void 0:B.slice(-1)[0])||((I=b==null?void 0:b.blocks)==null?void 0:I.slice(-1)[0]),F=(S==null?void 0:S.id)||(b==null?void 0:b.startBlockId);F?x=await Bi("markdown",m,void 0,F):x=await co("markdown",m,e.currentDocId.value)}const C=((R=(N=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:N[0])==null?void 0:R.id)||((z=x==null?void 0:x[0])==null?void 0:z.id);return C&&(await je(C,{[it]:"true"}),Pe.setBlockAttrOverride(C,{[it]:"true"}),Ri(C,(V=e.plugin)==null?void 0:V.app)),e.plugin&&await e.plugin.compileCurrentDocument(),C}async function o(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){n("取消中...");try{await je(p,{[it]:"","slidev-note":""}),Pe.setBlockAttrOverride(p,{[it]:"","slidev-note":""}),tt(p,{[it]:"","slidev-note":""}),delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),me.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 取消讲稿备注失败:",g),n("取消失败"),me.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let g=e.rawSnippet.value;try{const b=await zc(p);b!=null&&b.kramdown&&(g=b.kramdown)}catch{}const h=`> [!NOTE] 💡 演讲备注
${(wa(g)||g.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await cr("markdown",h,p),await je(p,{[it]:"true"}),Pe.setBlockAttrOverride(p,{[it]:"true"}),tt(p,{[it]:"true"}),e.activeBlockAttrs.value[it]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),me.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",g),n("设置失败"),me.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await s(),me.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){me.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var u;const p=e.currentSlideNoteBlockId.value;if(!p){me.showMessage("未找到本页关联的讲稿备注块");return}Ri(p,(u=e.plugin)==null?void 0:u.app)?me.showMessage("已在编辑区定位讲稿备注块"):me.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};me.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const g=await Fa(p,sl);if(g.notes){const m=e.currentSlideNoteBlockId.value;if(m){const h=`> [!NOTE] 💡 演讲备注
${g.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await cr("markdown",h,m),await je(m,{[it]:"true"}),Pe.setBlockAttrOverride(m,{[it]:"true"}),Ri(m,(u=e.plugin)==null?void 0:u.app)}else await s(g.notes);g.isAiGenerated?me.showMessage("思源 AI 演讲提词卡生成成功！"):me.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const p=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const g=p.map((h,b)=>({slide:h,idx:b})).filter(({slide:h})=>{var x;const b=Array.isArray(h.noteBlocks)&&h.noteBlocks.length>0,y=!!((x=h.notes)!=null&&x.trim());return!b&&!y});if(g.length===0){me.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=g.length;me.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,y,x,C,M,B;if(i.value)return;i.value=!0,me.showMessage("正在批量追加讲稿块...");let h=0;try{const N=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(R=>`> ${R}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:R,idx:z}of g)try{let V=null;if(z<p.length-1){const F=p[z+1];V=await Bi("markdown",N,F.startBlockId)}else{const F=((b=R==null?void 0:R.noteBlocks)==null?void 0:b.slice(-1)[0])||((y=R==null?void 0:R.blocks)==null?void 0:y.slice(-1)[0]),k=(F==null?void 0:F.id)||(R==null?void 0:R.startBlockId);k?V=await Bi("markdown",N,void 0,k):V=await co("markdown",N,e.currentDocId.value)}const S=((M=(C=(x=V==null?void 0:V[0])==null?void 0:x.doOperations)==null?void 0:C[0])==null?void 0:M.id)||((B=V==null?void 0:V[0])==null?void 0:B.id);S&&(await je(S,{[it]:"true"}),Pe.setBlockAttrOverride(S,{[it]:"true"})),h++}catch(V){console.error(`[SiYuanSlidev] 为第 ${z+1} 页追加讲稿块失败:`,V)}e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功为 ${h} 页追加讲稿备注块`)}catch(I){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",I),me.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var h;if(i.value)return;const p=((h=e.latestDoc.value)==null?void 0:h.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const g=[];for(const b of p)if(b.noteBlocks&&b.noteBlocks.length>0)for(const y of b.noteBlocks)y.id&&g.push({id:y.id,pageIndex:b.pageIndex});if(g.length===0){me.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(g.map(b=>b.pageIndex)).size,m=g.length;me.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,me.showMessage("正在批量删除讲稿块...");let b=0;try{for(const y of g)try{await nl(y.id),Pe.clearBlockAttrOverride(y.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${y.id} 失败:`,x)}e.activeBlockId.value&&g.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(y){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",y),me.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function Sk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ai]:"true",[Vi]:"true"}),e.activeBlockAttrs.value[Ai]="true",e.activeBlockAttrs.value[Vi]="true"):(await i(Ai,"false"),e.activeBlockAttrs.value[Ai]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(us,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Vi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(fs,w)}async function c(w){var S;const N=e.activeBlockId.value;if(!N)return;const R=e.rawSnippet.value||"",z=ki(R)||"",V=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const F={[qe]:"background",[ye]:""};V&&z&&(e.pageBackground.value=z,await je(V,{[et]:z}).catch(()=>{}),Pe.setBlockAttrOverride(V,{[et]:z}),tt(V,{[et]:z}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=z)),await n(F)}else(w===ps||w===hs)&&await n({[ye]:w,[qe]:""});else{const F={[qe]:"",[ye]:""};if(e.activeBlockAttrs.value[et]==="true"&&(F[et]=""),V&&z&&e.pageBackground.value===z&&(e.pageBackground.value="",await je(V,{[et]:""}).catch(()=>{}),Pe.setBlockAttrOverride(V,{[et]:""}),tt(V,{[et]:""}),(S=e.targetSlide.value)!=null&&S.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(F),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${N}"]`),A=k==null?void 0:k.closest('[data-type="NodeListItem"]'),H=A==null?void 0:A.getAttribute("data-node-id");if(H&&H!==N){const E={[ye]:"",[qe]:""};tt(H,E),Pe.setBlockAttrOverride(H,E),await je(H,E).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function p(w){i(Ze,w)}function g(w){i(Kt,w)}function u(w){(e.activeBlockAttrs.value[$e]||"")===w?i($e,""):i($e,w)}function m(w){e.elemShikiLines.value=w,i(Ni,w)}function h(w){e.elemMaxHeight.value=w,i(Mn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i($e,w?"col-1":"left"),me.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const N={[Ze]:"",[Kt]:"",[$e]:"",[Ni]:"",[Mn]:"",[it]:"","slidev-note":"",[ye]:"",[yt]:"",[qe]:"",[pt]:"",[et]:"",[Mt]:"",[Ai]:"",[us]:"",[Vi]:"",[fs]:""};if(tt(w,N),await je(w,N),Pe.clearBlockAttrOverride(w),typeof document<"u"){const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),z=R==null?void 0:R.closest('[data-type="NodeListItem"]'),V=z==null?void 0:z.getAttribute("data-node-id");V&&V!==w&&(tt(V,N),await je(V,N).catch(()=>{}),Pe.clearBlockAttrOverride(V))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",me.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Bi("markdown","---",e.activeBlockId.value,void 0),me.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function C(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Bi("markdown","---",void 0,w),me.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function M(){if(e.activeBlockId.value)try{await nl(e.activeBlockId.value),me.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("删除失败")}}async function B(){var w,N;try{let R=null;if(typeof document<"u"){const V=e.activeBlockId.value;if(V){const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);S&&(R=S.getAttribute("data-type")==="NodeSuperBlock"?S:S.closest('[data-type="NodeSuperBlock"]'))}if(!R){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(S){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(F){let k=F.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const A=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(A){R=A;break}k=k.nextElementSibling}}}else{const F=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const A of k)if(!F||A.compareDocumentPosition(F)&Node.DOCUMENT_POSITION_FOLLOWING){R=A;break}}}}const z=[];if(R){const V=Array.from(R.querySelectorAll(":scope > [data-node-id]"));for(const S of V){const F=S.getAttribute("data-node-id");F&&(z.push(F),S.removeAttribute("style"))}}else if((N=e.targetSlide.value)!=null&&N.blocks){for(const V of e.targetSlide.value.blocks)if(V.children&&V.children.length>=2){for(const S of V.children)S.id&&z.push(S.id);break}}if(z.length>0)for(const V of z)await je(V,{style:""}).catch(()=>{});await s(yt,""),me.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(R){console.error("[layout-actions] resetSuperBlockWidth error:",R),me.showMessage("重置超级块比例失败")}}async function I(){var w,N,R;try{let z=null;if(typeof document<"u"){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),F=e.activeBlockId.value;let k=[];if(S){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(E){let D=E.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(D),D=D.nextElementSibling}}else{const E=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const O of D)if(!E||O.compareDocumentPosition(E)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(O);else break}const A=[];let H;for(const E of k){const D=E.getAttribute("data-type");D==="NodeHeading"&&(H=E.getAttribute("data-node-id")||void 0);const O=[];D==="NodeSuperBlock"?O.push(E):O.push(...Array.from(E.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const J of O){if((J.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const K=J.getAttribute("data-node-id")||"";let se=[];const ae=Array.from(J.querySelectorAll('[data-type="NodeListItem"]'));if(ae.length===4&&(se=ae.map(ce=>ce.getAttribute("data-node-id")).filter(Boolean)),se.length!==4){const ce=Array.from(J.querySelectorAll(":scope > [data-node-id]"));ce.length===4&&(se=ce.map(ge=>ge.getAttribute("data-node-id")).filter(Boolean))}se.length===4&&A.push({sbId:K,itemIds:se,headerId:H})}}A.length>0&&(F&&(z=A.find(E=>{if(E.sbId===F||E.itemIds.includes(F))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${E.sbId}"]`),O=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`);return!!(D&&O&&D.contains(O))})||null),z||(z=A[0]))}if(!z&&((N=e.targetSlide.value)!=null&&N.blocks)){const S=e.targetSlide.value,F=[];for(const A of S.blocks)A.rawNode?F.push(A.rawNode):F.push({id:A.id,type:A.type,content:A.content,markdown:A.rawMarkdown,children:A.children,ial:A.attributes||A.ial||{}});const k=If(F,e.activeBlockId.value);k&&k.items.length===4&&(z={sbId:k.superBlockNode.id,itemIds:k.items.map(A=>A.id),headerId:(R=k.headerNode)==null?void 0:R.id})}if(!z||z.itemIds.length!==4)return me.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const V=e.currentPageDividerId.value||e.currentDocId.value;V&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(V,{[ye]:"clover"}),tt(V,{[ye]:"clover"}),await je(V,{[ye]:"clover"}).catch(()=>{})),z.headerId&&(Pe.setBlockAttrOverride(z.headerId,{[$e]:"header"}),tt(z.headerId,{[$e]:"header"}),await je(z.headerId,{[$e]:"header"}).catch(()=>{}));for(let S=0;S<4;S++){const F=z.itemIds[S],k=`col-${S+1}`;Pe.setBlockAttrOverride(F,{[$e]:k}),tt(F,{[$e]:k}),await je(F,{[$e]:k}).catch(()=>{})}return me.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(z){return console.error("[layout-actions] applyCloverLayout error:",z),me.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:g,onElemSlotChange:u,onElemShikiLinesChange:m,onElemMaxHeightChange:h,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:C,onDeleteCurrentBlock:M,resetSuperBlockWidth:B,applyCloverLayout:I}}function _k(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l}=kk(e),r=xk(e,{triggerSaveNotice:t}),a=Sk(e,{saveAttr:n,saveAttrs:i,savePageAttr:s});function c(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}const p=Ma(e.latestDoc.value);Da("presentation.html",p)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}La(e.latestDoc.value)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function Ck(e){const t=ke(()=>nr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return ke(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Pe.getBlockAttrOverride(a);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}const $k={class:"spm-slidev-inspector"},Ik={class:"spm-inspector-topbar"},Tk={class:"spm-inspector-title"},Ek={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Ak={class:"spm-inspector-topbar-actions"},Bk={class:"spm-target-banner"},Mk={class:"spm-target-info"},Dk=["aria-label"],Lk={key:0,class:"spm-save-status"},Pk=["title"],Ok={class:"spm-inspector-body"},Rk=It({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=Lt("plugin"),n=he(!1);function s(X){n.value=!1,c.value=X.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(X.docId)}const o=he(""),l=he(""),r=he({}),a=he(""),c=he(""),d=he(""),p=he(""),g=he(""),u=he(""),m=he(""),h=he(""),b=he(null),y=he(""),x=he("");function C(){var ve;const X=o.value||c.value;X&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(X).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const M=ke(()=>nr(l.value)),B=ke(()=>l.value==="NodeCodeBlock"),I=he(!1),w=ke(()=>{if(I.value||Be.value)return!0;const X=a.value||"";return!!ki(X)}),N=ke(()=>{const X=l.value||"";if(X==="NodeVideo"||X==="video")return!0;const ve=a.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),R=ke(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),z=ke(()=>{const X=o.value||c.value||"";return X.length>8?X.slice(-8):X||"无"}),V=ke(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=ke(()=>{if(M.value)return"分页符 (---)";if(R.value)return"全局文档";if(N.value)return"视频块";let X="内容块";switch(l.value){case"NodeHeading":X="标题块";break;case"NodeParagraph":X="段落块";break;case"NodeCodeBlock":X="代码块";break;case"NodeVideo":X="视频块";break;case"NodeList":case"NodeListItem":X="列表项";break;case"NodeBlockquote":X="引述块";break;case"NodeTable":X="表格块";break;case"NodeSuperBlock":case"s":case"sb":X="超级块";break;default:X="内容块";break}return u.value?m.value?`${m.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${X}`:`分栏容器 › ${X}`:X}),F=ke(()=>M.value?"tag-divider":R.value?"tag-doc":"tag-block"),k=ke(()=>r.value[ye]||"default"),A=ke(()=>r.value[pt]||"slide-left"),H=he(""),E=he(""),D=ke(()=>r.value[kn]||"inherit"),O=ke(()=>{var X;return vk((X=b.value)==null?void 0:X.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),J=ke(()=>{var X;return((X=O.value)==null?void 0:X.notes)||""}),U=ke(()=>{var X,ve,Ee;return((Ee=(ve=(X=O.value)==null?void 0:X.noteBlocks)==null?void 0:ve[0])==null?void 0:Ee.id)||""}),K=ke(()=>{var He,We,Oe,dt,Vn,ui;if(M.value){const Xe=r.value[ye]||r.value["custom-slidev-layout"];if(Xe)return Xe}const X=r.value[$e]||r.value["custom-slidev-slot"];if(X&&(["col-1","col-2","col-3"].includes(X)||/^col-\d+$/.test(X)))return"cols-header";if(g.value)return g.value;const ve=p.value||(M.value?o.value:"");if(ve){const Xe=Pe.getBlockAttrOverride(ve);if(Xe!=null&&Xe[ye])return Xe[ye]}if(ve&&((He=b.value)!=null&&He.slides)){const Xe=b.value.slides.find(ji=>ji.startBlockId===ve);if((We=Xe==null?void 0:Xe.frontmatter)!=null&&We.layout)return Xe.frontmatter.layout}if((dt=(Oe=O.value)==null?void 0:Oe.frontmatter)!=null&&dt.layout)return O.value.frontmatter.layout;if((ui=(Vn=O.value)==null?void 0:Vn.blocks)!=null&&ui.some(Xe=>Xe.slot&&(["col-1","col-2","col-3"].includes(Xe.slot)||/^col-\d+$/.test(Xe.slot))))return"cols-header";const Ee=Pe.getBlockAttrOverride(c.value);return Ee!=null&&Ee[ye]?Ee[ye]:"default"}),se=Ck({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),ae=se.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var X,ve;return((ve=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:ve.layoutRatio)||""}}),ce=se.resolvePageAttr({attrKey:Gi,fallback:()=>{var X,ve;return((ve=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:ve.mask)||""}}),ge=se.resolvePageAttr({attrKey:qi,fallback:()=>{var X,ve;return((ve=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:ve.maskRatio)||""}}),Te=se.resolvePageAttr({attrKey:Zi,fallback:()=>{var X,ve;return((ve=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),we=se.resolvePageAttr({attrKey:Yi,fallback:()=>{var X,ve;return((ve=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function ue(X){if(!X||(X.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(X.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const He=Ee.length,We=Ee.map(ui=>{const Xe=ui.getAttribute("style")||"",ji=Xe.match(/calc\(\s*([\d.]+)%/);if(ji)return parseFloat(ji[1]);const pn=Xe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return pn?parseFloat(pn[1]):null});let Oe="",dt=!1;if(We.some(ui=>ui!==null)){dt=!0;const ui=We.reduce((Me,ut)=>Me+(ut||0),0),Xe=We.filter(Me=>Me===null).length,ji=Xe>0?Math.max(0,100-ui)/Xe:100/Ee.length,pn=We.map(Me=>Me!==null?Me:ji),Ec=pn.reduce((Me,ut)=>Me+ut,0)||1,hn=pn.map(Me=>Me/Ec*100);if(hn.length===2){const[Me]=hn;if(Me>=48&&Me<=52)Oe="1:1";else if(Me>=31&&Me<=35)Oe="1:2";else if(Me>=65&&Me<=69)Oe="2:1";else if(Me>=28&&Me<=32)Oe="3:7";else if(Me>=68&&Me<=72)Oe="7:3";else if(Me>=38&&Me<=42)Oe="4:6";else if(Me>=58&&Me<=62)Oe="6:4";else{const ut=Math.round(Me);Oe=`${ut}:${100-ut}`}}else if(hn.length===3){const[Me,ut,fi]=hn;if(Me>=31&&Me<=35&&ut>=31&&ut<=35&&fi>=31&&fi<=35)Oe="1:1:1";else if(Me>=23&&Me<=27&&ut>=48&&ut<=52&&fi>=23&&fi<=27)Oe="1:2:1";else if(Me>=48&&Me<=52&&ut>=23&&ut<=27&&fi>=23&&fi<=27)Oe="2:1:1";else if(Me>=23&&Me<=27&&ut>=23&&ut<=27&&fi>=48&&fi<=52)Oe="1:1:2";else{const lr=Math.round(Me),ar=Math.round(ut);Oe=`${lr}:${ar}:${100-lr-ar}`}}else Oe=hn.map(Me=>Math.round(Me)).join(":")}else dt=!1,Oe=Array.from({length:He},()=>1).join(":");const Vn=He>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:He,ratio:Oe,isCustomWidth:dt,recommendedLayout:Vn}}function Y(X){if(!(X!=null&&X.blocks))return null;for(const ve of X.blocks){const Ee=ve.rawNode;if(Ee&&st(Ee)&&qt(Ee)){const We=un(Ee).length,Oe=Qo(Ee);return{hasSuperBlock:!0,colCount:We,ratio:Oe||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const fe=ke(()=>{var X;if(typeof document<"u"){const ve=o.value;if(ve){const He=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(He){const We=He.getAttribute("data-type")==="NodeSuperBlock"?He:He.closest('[data-type="NodeSuperBlock"]');if(We){const Oe=ue(We);if(Oe)return Oe}}}const Ee=p.value||(M.value?o.value:"");if(Ee){const He=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(He){let We=He.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(X=We.classList)!=null&&X.contains("protyle-wysiwyg__block--hr"));){const Oe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const dt=ue(Oe);if(dt)return dt}We=We.nextElementSibling}}}else{const He=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of We)if(!He||Oe.compareDocumentPosition(He)&Node.DOCUMENT_POSITION_FOLLOWING){const dt=ue(Oe);if(dt)return dt}}}return Y(O.value)}),P=ke(()=>{var X;return((X=fe.value)==null?void 0:X.ratio)||""}),j=ke(()=>{const X=l.value||"";if(X==="NodeSuperBlock"||X==="s"||X==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ke(()=>{var X;return((X=O.value)==null?void 0:X.pageIndex)||1}),W=ke(()=>!!(r.value[it]||r.value["slidev-note"]));function T(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const X=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!X)return!1;const ve=X.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const _=ke(()=>{var ve;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&T())return h.value||"";if(u.value)return"";const X=o.value;if(X&&((ve=O.value)!=null&&ve.blocks)){const Ee=O.value.blocks.find(He=>He.id===X);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),$=ke(()=>{var ve;if(r.value[Kt])return r.value[Kt];const X=o.value;if(X&&((ve=O.value)!=null&&ve.blocks)){const Ee=O.value.blocks.find(He=>He.id===X);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),L=ke(()=>{var ve;if(r.value[$e])return r.value[$e];const X=o.value;if(X&&((ve=O.value)!=null&&ve.blocks)){const Ee=O.value.blocks.find(He=>He.id===X);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),Z=he(""),G=he(""),q=ke(()=>r.value[Ai]==="true"),ee=ke(()=>r.value[us]==="true"),le=ke(()=>r.value[Vi]==="true"),oe=ke(()=>r.value[fs]!=="false"),pe=ke(()=>{var X,ve;return((ve=(X=b.value)==null?void 0:X.config)==null?void 0:ve.theme)||r.value[En]||"default"}),ie=ke(()=>{var X,ve;return((ve=(X=b.value)==null?void 0:X.config)==null?void 0:ve.aspectRatio)||r.value[An]||"16/9"}),ne=ke(()=>{var X,ve;return((ve=(X=b.value)==null?void 0:X.config)==null?void 0:ve.defaultTransition)||r.value[Bn]||"slide-left"}),Ce=ke(()=>{var X,ve;return((ve=(X=b.value)==null?void 0:X.config)==null?void 0:ve.spacing)||r.value[fo]||"normal"}),Be=ke(()=>{var We,Oe;if((r.value[qe]||r.value["slidev-role"])===al||r.value[et]==="true")return"background";const ve=r.value[ye]||r.value["slidev-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ee=a.value||"",He=ki(Ee);if(He&&((Oe=(We=O.value)==null?void 0:We.frontmatter)!=null&&Oe.background)){const dt=O.value.frontmatter.background;if(dt===He||dt.endsWith(He)||He.endsWith(dt))return"background"}return""}),Ne=ke(()=>!!(r.value[Ze]||r.value[Kt]||r.value[$e]||r.value[Ni]||r.value[it]||r.value["slidev-note"]||r.value[qe]||r.value[ye]||r.value[Ai]||r.value[us]||r.value[Vi]||r.value[fs])),{saveAttr:Re,savePageAttr:De,applyPageLayoutAndRatio:Yt,applyCloverLayout:ot,resetSuperBlockWidth:Je,saveDocAttr:Nt,onToggleVideoAutoplay:Fi,onToggleVideoLoop:Hs,onToggleVideoMuted:js,onToggleVideoControls:Un,onImageRoleChange:xi,onToggleNoteBlock:Hi,onAddNoteBlock:Ga,onLocateNoteBlock:qa,onGenerateNotesWithAI:Za,isBatchProcessing:Ya,onBatchAppendNotes:Ja,onBatchDeleteNotes:Xa,toggleElemClick:Qa,onElemClickStepChange:ec,onElemMotionChange:tc,onElemSlotChange:ic,onElemShikiLinesChange:nc,onElemMaxHeightChange:sc,onSetTwoColsContrast:oc,onClearBlockAttrs:rc,onInsertDividerBefore:lc,onInsertDividerAfter:sr,onDeleteCurrentBlock:ac,onExportHtml:cc,onExportPdf:dc}=_k({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:g,parentContainerId:u,parentContainerClicks:h,latestDoc:b,targetSlide:O,currentSlideNoteBlockId:U,currentSlideLayout:K,isNoteBlock:W,elemClick:_,videoAutoplay:q,videoLoop:ee,videoMuted:le,videoControls:oe,pageBackground:H,pageImage:E,elemShikiLines:Z,elemMaxHeight:G,saveStatus:y,plugin:i});async function uc(X){if(X==="clover"){if(!await ot())return}else Re(ye,X)}function fc(X){De(yt,X)}function pc(X){De(Gi,X)}function hc(X){De(qi,X)}function mc(X){De(Zi,X)}function gc(X){De(Yi,X)}function or(X){if(!X)return;const ve=X.recommendedLayout||(X.colCount&&X.colCount>=2?"cols-header":"two-cols"),Ee=X.ratio||(X.colCount?Array(X.colCount).fill(1).join(":"):"1:1");Yt(ve,Ee)}function vc(X){De(yt,X)}async function bc(){await Je()}function yc(X){Re(pt,X)}function kc(X){H.value=X,Re(et,X)}function wc(X){E.value=X,Re(Mt,X)}function xc(X){Re(kn,X==="inherit"?"":X)}function Sc(X){Nt(En,X)}function _c(X){Nt(An,X)}function Cc(X){Nt(Bn,X)}function $c(X){Nt(fo,X)}function rr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Ic(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Tc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(X){o.value=X.id,l.value=X.type,r.value={...X.attrs},a.value=X.content||X.markdown||"",d.value=X.topBlockId||X.id,p.value=X.pageDividerId||"",g.value=X.pageDividerLayout||"",u.value=X.parentContainerId||"",m.value=X.parentContainerSlot||"",h.value=X.parentContainerClicks||"",X.rootId?c.value=X.rootId:(X.type==="doc"||X.type==="NodeDocument")&&X.id&&(c.value=X.id),H.value=X.attrs[et]||"",E.value=X.attrs[Mt]||"",Z.value=X.attrs[Ni]||"",G.value=X.attrs[Mn]||"",I.value=!!X.isImage},updateDocument(X){b.value=X,c.value=X.docId},openImportDialog(){n.value=!0},setCurrentDocId(X){c.value=X}}),(X,ve)=>(Q(),te("div",$k,[f("div",Ik,[f("div",Tk,[(Q(),te("svg",Ek,[...ve[2]||(ve[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=f("span",null,"演示配置",-1))]),f("div",Ak,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ee=>n.value=!0)},[re(de,{name:"import"}),ve[4]||(ve[4]=f("span",null,"导入",-1))]),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:rr},[re(de,{name:"split-preview"}),ve[5]||(ve[5]=f("span",null,"分屏预览",-1))])])]),f("div",Bk,[f("div",Mk,[f("span",{class:_e(["spm-target-tag",F.value])},xe(S.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(o.value||c.value),onClick:C},[re(de,{name:"copy"}),f("span",null,"#"+xe(z.value),1)],8,Dk)]),y.value?(Q(),te("span",Lk,"● "+xe(y.value),1)):Le("",!0)]),V.value?(Q(),te("div",{key:0,class:"spm-context-quote",title:a.value},xe(V.value),9,Pk)):Le("",!0),f("div",Ok,[M.value?(Q(),Vt(Wb,{key:0,"page-layout":k.value,"page-layout-ratio":be(ae),"page-mask":be(ce),"page-mask-ratio":be(ge),"page-mask-style":be(Te),"page-mask-initial":be(we),"detected-sb-ratio":P.value,"detected-sb-info":fe.value,"page-transition":A.value,"page-background":H.value,"page-spacing":D.value,"page-image":E.value,"page-notes":J.value,"page-index":v.value,"onUpdate:pageLayout":uc,"onUpdate:pageLayoutRatio":fc,"onUpdate:pageMask":pc,"onUpdate:pageMaskRatio":hc,"onUpdate:pageMaskStyle":mc,"onUpdate:pageMaskInitial":gc,onApplySuperBlockLayout:or,onResetSuperblockRatio:bc,"onUpdate:pageTransition":yc,"onUpdate:pageBackground":kc,"onUpdate:pageSpacing":xc,"onUpdate:pageImage":wc,onAddNoteBlock:be(Ga),onLocateNoteBlock:be(qa),onGenerateNotes:be(Za),onBatchAppendNotes:be(Ja),onBatchDeleteNotes:be(Xa),"is-batch-processing":be(Ya),onInsertDividerAfter:be(sr),onDeleteDivider:be(ac)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!R.value?(Q(),Vt(Iy,{key:1,"elem-click":_.value,"elem-motion":$.value,"elem-slot":L.value,"elem-shiki-lines":Z.value,"elem-max-height":G.value,"is-code-block":B.value,"is-image":w.value,"is-video":N.value,"is-super-block":j.value,"detected-sb-info":fe.value,"video-autoplay":q.value,"video-loop":ee.value,"video-muted":le.value,"video-controls":oe.value,"has-block-attrs":Ne.value,"is-note":W.value,"image-role":Be.value,"current-slide-layout":K.value,"parent-elem-click":h.value,"parent-container-slot":m.value,"parent-container-id":u.value,onToggleNote:be(Hi),onToggleElemClick:be(Qa),onToggleVideoAutoplay:be(Fi),onToggleVideoLoop:be(Hs),onToggleVideoMuted:be(js),onToggleVideoControls:be(Un),"onUpdate:imageRole":be(xi),"onUpdate:elemClick":be(ec),"onUpdate:elemMotion":be(tc),"onUpdate:elemSlot":be(ic),"onUpdate:elemShikiLines":be(nc),"onUpdate:elemMaxHeight":be(sc),onApplySuperBlockLayout:or,onApplySuperBlockRatio:vc,onInsertDividerBefore:be(lc),onInsertDividerAfter:be(sr),onSetTwoColsContrast:be(oc),onClearBlockAttrs:be(rc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(Q(),Vt(u0,{key:2,"doc-theme":pe.value,"doc-aspect-ratio":ie.value,"doc-default-transition":ne.value,"doc-spacing":Ce.value,"onUpdate:docTheme":Sc,"onUpdate:docAspectRatio":_c,"onUpdate:docDefaultTransition":Cc,"onUpdate:docSpacing":$c,onOpenBottomPreview:rr,onOpenPresenter:Ic,onAiAutoSplit:Tc,onExportHtml:be(cc),onExportPdf:be(dc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(Q(),Vt(gk,{key:1,onClose:ve[1]||(ve[1]=Ee=>n.value=!1),onSuccess:s})):Le("",!0)]))}}),Nk=2e3,zk=600;function Fk(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ro(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Qr(e))return!0;const t=e.firstElementChild;return!!(t&&Qr(t))}function Qr(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Hk(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class jk{constructor(){Se(this,"consumers",new Map);Se(this,"seq",0);Se(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=Hk(),l={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=ro(i),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ro(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Fk(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&ro(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Nk))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const rs=new jk,fn=new Fs;function Ha(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=rs.register(e,t,n);return n(),s}let vi=null,Et=null,ls=null;function Wk(){return Et}function Uk(e,t){vi&&ja(),vi=Jo(ig),vi.provide("plugin",t),vi.provide("sandboxBridge",fn);const i=vi.mount(e);return Et=i,ls=Ha("preview",e,t),i}function ja(e){ls&&(ls(),ls=null),vi&&(vi.unmount(),vi=null,Et=null)}function Vk(){return Et!==null}let bi=null,Di=null;function Kk(e,t){return bi&&Wa(),bi=Jo(fv),bi.provide("plugin",t),bi.provide("sandboxBridge",fn),Di=bi.mount(e),Di}function Wa(e){bi&&(bi.unmount(),bi=null,Di=null)}function Gk(e){try{const t=new BroadcastChannel("siyuan-slidev-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let yi=null,_t=null,as=null;function qk(e,t){yi&&Ua(),yi=Jo(Rk),yi.provide("plugin",t),yi.provide("sandboxBridge",fn);const i=yi.mount(e);return _t=i,as=Ha("dock",e,t),i}function Ua(e){as&&(as(),as=null),yi&&(yi.unmount(),yi=null,_t=null)}function Zk(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),Et!=null&&Et.updateDocument?Et.updateDocument(e,t):(fn.updateSlides(e.slides,e.config,e.fullMarkdown),Gk(e)),Di!=null&&Di.updateDocument&&Di.updateDocument(e)}function Bo(e){Et!=null&&Et.navigateToBlock?Et.navigateToBlock(e):fn.highlightElement(e)}function cs(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function Yk(){return _t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}function Jk(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const l=e[o];if(_s(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];_s(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}const Xk=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ei,value:"true"},{key:ye,value:"cover"},{key:pt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ei,value:"true"},{key:ye,value:"two-cols"},{key:pt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ei,value:"true"},{key:ye,value:"fact"},{key:pt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ei,value:"true"},{key:ye,value:"intro"},{key:pt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ei,value:"true"},{key:ye,value:"quote"},{key:pt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:$e,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class lo{getPresetTemplates(){return Xk}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${pt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${pt}' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[pt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Qk(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Yk()||me.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await je(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),me.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}const t=await ds(e.currentDocId).catch(()=>[]);if(!t||t.length===0){me.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Jk(i);if(n.length===0){me.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}me.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Bi("markdown","---",void 0,o.blockId),await je(o.blockId,{"custom-slidev-layout":o.recommendedLayout}),s++}catch(l){console.warn("Failed to insert divider:",l)}me.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!e.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}me.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await ds(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await wk(i,sl)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await co("markdown",o,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await je(r,{"custom-slidev-note":"true"}),Pe.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Ri(r,e.app)),me.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new lo,i=t.buildTransitionStatsSql(),n=await nn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);me.showMessage(s)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new lo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),me.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):me.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new lo().batchUpdateTransitions("fade","slide-left",n=>nn(n).catch(()=>[]),(n,s)=>je(n,s));me.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&me.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{me.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?me.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):me.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",uo);t.success?me.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):me.showMessage(`同步失败：${t.error}`)}})}function Va(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ka(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const o=await nn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function ew(e,t,i){var c,d,p;const n=Wk(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&i&&i!==o)return;const l=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ka(e,l));const a=Va(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const g=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of g){const m=u.querySelector(".item__text"),h=((p=m==null?void 0:m.textContent)==null?void 0:p.trim())||"";if(h.includes("Slidev 演示预览")||h.startsWith("即现")){m&&(m.textContent=a),u.setAttribute("title",a);break}}}}class tw{constructor(t=400){Se(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function iw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class nw{constructor(t=150){Se(this,"lastBlockId","");Se(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class sw{constructor(){Se(this,"attrCache",new tw);Se(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Pe.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const l=await Mo(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:iw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);cs({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Bo(t)}handleBlockClickedFromSlide(t,i,n,s){var a;if(!t)return!1;const o=Ri(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,s);else{let c="",d="";if(s!=null&&s.slides){const p=s.slides.find(g=>{var u,m,h;return g.startBlockId===t||((u=g.blocks)==null?void 0:u.some(b=>b.id===t))||((m=g.allBlockIds)==null?void 0:m.includes(t))||((h=g.noteBlocks)==null?void 0:h.some(b=>b.id===t))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async p=>{if(c&&!d){const g=Pe.getBlockAttrOverride(c);if(g!=null&&g[ye]||g!=null&&g["custom-slidev-layout"])d=g[ye]||g["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,s);d=u[ye]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Pe.setBlockAttrOverride(c,u)}}cs({id:t,rootId:n,type:r||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return o}async syncInspectorBlock(t,i,n,s,o){var A,H,E,D,O,J,U,K;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const se=c.getAttribute("data-node-id");if(se){const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ge={...ae,...ce};(ge[it]||ge["slidev-note"])&&(l=c,r=se,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((A=d==null?void 0:d.classList)!=null&&A.contains("hr")),u=a==="NodeCodeBlock",m=((H=l.innerText)==null?void 0:H.trim())||"",h=await this.resolveBlockAttrs(r,o),b=Pe.getBlockAttrOverride(r)||{},y={...h,...b};let x="",C="";if(g)x=r,C=y[ye]||y["custom-slidev-layout"]||"";else{let se=d.previousElementSibling;for(;se;){const ae=se.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(E=se.classList)!=null&&E.contains("hr")){x=se.getAttribute("data-node-id")||"";break}se=se.previousElementSibling}}if(o!=null&&o.slides){const se=[r,p];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const ge=ae.getAttribute("data-node-id");ge&&!se.includes(ge)&&se.push(ge),ae=ae.parentElement}const ce=o.slides.find(ge=>{var Te,we,ue;return se.includes(ge.startBlockId)||((Te=ge.blocks)==null?void 0:Te.some(Y=>se.includes(Y.id)))||((we=ge.allBlockIds)==null?void 0:we.some(Y=>se.includes(Y)))||((ue=ge.noteBlocks)==null?void 0:ue.some(Y=>se.includes(Y.id)))});ce&&(!x&&ce.startBlockId&&(x=ce.startBlockId),!C&&((D=ce.frontmatter)!=null&&D.layout)&&(C=ce.frontmatter.layout))}if(x){const se=Pe.getBlockAttrOverride(x);if(se&&(ye in se||"custom-slidev-layout"in se)&&(C=se[ye]||se["custom-slidev-layout"]||""),!C&&(o!=null&&o.slides)){const ae=o.slides.find(ce=>ce.startBlockId===x);(O=ae==null?void 0:ae.frontmatter)!=null&&O.layout&&(C=ae.frontmatter.layout)}if(!C){const ae=await this.resolveBlockAttrs(x,o);C=ae[ye]||ae["custom-slidev-layout"]||"",ae&&Object.keys(ae).length>0&&Pe.setBlockAttrOverride(x,ae)}tt(x,{[ye]:C||""})}else if(s){const se=Pe.getBlockAttrOverride(s);se&&(ye in se||"custom-slidev-layout"in se)?C=se[ye]||se["custom-slidev-layout"]||"":!C&&((K=(U=(J=o==null?void 0:o.slides)==null?void 0:J[0])==null?void 0:U.frontmatter)!=null&&K.layout)&&(C=o.slides[0].frontmatter.layout)}const M=l.getAttribute(ye)||l.getAttribute("custom-slidev-layout"),B=y[ye]||y["custom-slidev-layout"]||"";M&&M!==B&&tt(r,{[ye]:B});const I=l.getAttribute(qe)||l.getAttribute("custom-slidev-role"),w=y[qe]||y["custom-slidev-role"]||"";I&&I!==w&&tt(r,{[qe]:w});let N="",R="",z="";const V=l.closest('[data-type="NodeListItem"]');if(V&&V!==l){const se=V.getAttribute("data-node-id");if(se){N=se;const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ge={...ae,...ce};R=ge[$e]||"",z=ge[Ze]||"";const Te=ge[ye]||ge["custom-slidev-layout"]||"",we=V.getAttribute(ye)||V.getAttribute("custom-slidev-layout");we&&we!==Te&&tt(se,{[ye]:Te});const ue=ge[qe]||ge["custom-slidev-role"]||"",Y=V.getAttribute(qe)||V.getAttribute("custom-slidev-role");Y&&Y!==ue&&tt(se,{[qe]:ue})}}const S=!!l.querySelector("img, span[data-type='img']"),F=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=S&&F.length<=50;cs({id:r,rootId:s,type:a,content:m,attrs:y,isDivider:g,isCode:u,isImage:k,topBlockId:p,pageDividerId:x,pageDividerLayout:C,parentContainerId:N,parentContainerSlot:R,parentContainerClicks:z})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");tt(n.id,l),Pe.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var s,o,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[ye]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(o=a.ial)!=null&&o[ye]&&(c[ye]=a.ial[ye]),(l=a.ial)!=null&&l[qe]&&(c[qe]=a.ial[qe]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ye]!==void 0&&(c[ye]=a[ye]),a[qe]!==void 0&&(c[qe]=a[qe]),i.set(r,c)}bk(i)}}const Ii=new sw;class ow{constructor(){Se(this,"inFlightDocId",null);Se(this,"pendingDocId",null);Se(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const rw=150,lw=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,aw="slidev-dock",ao="slidev-preview-tab",el="slidev-presenter-tab",tl=kf;class cw extends me.Plugin{constructor(){super(...arguments);Se(this,"isMobile",!1);Se(this,"currentDocId","");Se(this,"previewTab",null);Se(this,"latestCompiledDoc",null);Se(this,"cliBridge",new er);Se(this,"debounceTimer",null);Se(this,"activeCursorBlockId","");Se(this,"compileScheduler",new ow);Se(this,"dirtyDocId",null);Se(this,"inspectorSyncThrottle",new nw);Se(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Se(this,"onWsMainBound",this.onWsMain.bind(this));Se(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Se(this,"onEditorClickBound",this.onEditorClick.bind(this));Se(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Se(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Se(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=me.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(lw),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Qk(this);const n=this;if(this.addTab({type:ao,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,Uk(o.element,n);const l=(r=o==null?void 0:o.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),ja(this.element)}}),this.addTab({type:el,init(s){Kk((this||s).element,n)},destroy(){Wa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:aw,init(){qk(this.element,n)},destroy(){Ua(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(tl),n=wf(i);return Mi(n),n}catch{return Mi(ln),ln}}async saveGlobalSettings(i){const n=zs(),s=Mi({...n,...i||{}});try{await this.saveData(tl,s)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,rs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),fn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await me.openTab({app:this.app,custom:{id:this.name+ao,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){Vk()||await this.openBottomPreviewTab(),await me.openTab({app:this.app,custom:{id:this.name+el,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=me.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-slidev/slidev-client/index.html","SlidevBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),l=await me.openTab({app:this.app,custom:{id:this.name+ao,title:o,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),me.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const p=await Mo(s).catch(()=>({}));cs({id:s,rootId:s,type:"doc",attrs:p}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,l;const n=i==null?void 0:i.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Va(i)}async fetchDocumentTitle(i){return Ka(this,i)}async updatePreviewTabHeader(i,n){return ew(this,i,n)}getActiveDocumentId(){return Ii.getActiveDocumentId()}resolveDocIdFromElement(i){return Ii.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ii.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ii.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=rw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=rs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,zk);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ii.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Ii.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&rs.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,Zk(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ii.purgeStaleDomSlidevAttrs(i)}}module.exports=cw;
