"use strict";var cd=Object.create;var Qn=Object.defineProperty;var dd=Object.getOwnPropertyDescriptor;var ud=Object.getOwnPropertyNames;var fd=Object.getPrototypeOf,pd=Object.prototype.hasOwnProperty;var hd=(e,t,i)=>t in e?Qn(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var md=(e,t,i,s)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of ud(t))!pd.call(e,n)&&n!==i&&Qn(e,n,{get:()=>t[n],enumerable:!(s=dd(t,n))||s.enumerable});return e};var tn=(e,t,i)=>(i=e!=null?cd(fd(e)):{},md(t||!e||!e.__esModule?Qn(i,"default",{value:e,enumerable:!0}):i,e));var be=(e,t,i)=>hd(e,typeof t!="symbol"?t+"":t,i);const ae=require("siyuan");async function kt(e,t){const i=await ae.fetchSyncPost(e,t);return i.code===0?i.data:null}async function gd(){return kt("/api/notebook/lsNotebooks","")}async function vd(e,t,i){return kt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Ca(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const n of t)i.append("file[]",n);return kt("/api/asset/upload",i)}async function Hi(e,t,i,s,n){return kt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:s,parentID:n})}async function xo(e,t,i){return kt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function So(e,t,i){return kt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function Go(e){return kt("/api/block/deleteBlock",{id:e})}async function bd(e){return kt("/api/block/getBlockKramdown",{id:e})}async function hs(e){return kt("/api/block/getChildBlocks",{id:e})}async function yd(e){return kt("/api/block/getDocBlocksOrders",{id:e})}async function Fe(e,t){return kt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Ko(e){return kt("/api/attr/getBlockAttrs",{id:e})}async function ds(e){return kt("/api/query/sql",{stmt:e})}async function Co(e,t,i){const s=new FormData;return s.append("path",e),s.append("isDir",t.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",i),kt("/api/file/putFile",s)}async function _a(e){const t="/api/ai/chatGPT";try{const i=await kt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function kd(){return kt("/api/storage/getInlineStyles","")}function $r(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function $a(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(i))!==null;){const o=n[1],a=n[2]??n[3]??n[4]??"";t[o]=a}return t}const Ia=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function wd(e){const t=[];if(!e)return t;const i=new RegExp(Ia.source,"g");let s;for(;(s=i.exec(e))!==null;){const n=s[2]??s[3]??s[4];t.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return t}function xd(e,t){if(!e)return"";const i=new RegExp(Ia.source,"g");return e.replace(i,(s,n,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=l||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Ns="custom-slides-theme",zs="custom-slides-aspect-ratio",Ma="custom-slides-highlighter",Hs="custom-slides-default-transition",Ta="custom-slides-color-schema",_o="custom-slides-spacing",wn="custom-slides-background",Ir="custom-slides-show-unordered-list-markers",Mr="custom-slides-show-ordered-list-markers",li="custom-slides-slide",ke="custom-slides-layout",vt="custom-slides-transition",ot="custom-slides-background",Rt="custom-slides-image",eo="custom-slides-notes",es="custom-slides-class",Ms="custom-slides-spacing",bt="custom-slides-layout-ratio",ts="custom-slides-mask",ji="custom-slides-mask-ratio",is="custom-slides-mask-style",ss="custom-slides-mask-initial",Ne="custom-slides-click",Xt="custom-slides-motion",Ki="custom-slides-shiki-lines",Me="custom-slides-slot",qe="custom-slides-note",Ze="custom-slides-role",Fs="custom-slides-max-height",zi="custom-slides-autoplay",xn="custom-slides-loop",Qi="custom-slides-muted",Sn="custom-slides-controls",Ea="background",Cn="image-left",_n="image-right";function ns(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Sd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],s=t===4?4:2;if(!e||typeof e!="string")return{steps:s,breakpoints:i};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:s,breakpoints:i};const o=n.split(":").map(d=>parseFloat(d.trim())).filter(d=>!isNaN(d)&&d>0);if(o.length===0)return{steps:s,breakpoints:i};if(o.length===1){const d=Math.min(100,Math.max(1,o[0]));return d===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(d*100)/100,100]}}const a=o.every((d,p)=>p===0||d>o[p-1]),r=o[o.length-1];if(a&&(r===100||o.some(d=>d>10))){const d=o.map(p=>Math.min(100,Math.round(p*100)/100));return d[d.length-1]<100&&d.push(100),{steps:d.length,breakpoints:d}}const c=o.reduce((d,p)=>d+p,0);if(c<=0)return{steps:s,breakpoints:i};let u=0;const f=[];for(let d=0;d<o.length;d++)u+=o[d],d===o.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function Aa(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ba(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function $t(e,t){if(!Aa(e))return e;const i=Ba(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Cd(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,o)=>{const a=$t(o,t);return`![${n}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,o,a)=>{const r=$t(o,t);return`${n}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,o,a)=>{const r=$t(o,t);return`${n}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function qo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Je={},os=[],Qt=()=>{},Da=()=>!1,On=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Rn=e=>e.startsWith("onUpdate:"),ut=Object.assign,Yo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},_d=Object.prototype.hasOwnProperty,Ve=(e,t)=>_d.call(e,t),Ee=Array.isArray,rs=e=>Ys(e)==="[object Map]",ms=e=>Ys(e)==="[object Set]",Tr=e=>Ys(e)==="[object Date]",Be=e=>typeof e=="function",st=e=>typeof e=="string",Ht=e=>typeof e=="symbol",Ye=e=>e!==null&&typeof e=="object",La=e=>(Ye(e)||Be(e))&&Be(e.then)&&Be(e.catch),Pa=Object.prototype.toString,Ys=e=>Pa.call(e),$d=e=>Ys(e).slice(8,-1),Oa=e=>Ys(e)==="[object Object]",Zo=e=>st(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Ts=qo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Nn=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Id=/-\w/g,Ct=Nn(e=>e.replace(Id,t=>t.slice(1).toUpperCase())),Md=/\B([A-Z])/g,Bi=Nn(e=>e.replace(Md,"-$1").toLowerCase()),zn=Nn(e=>e.charAt(0).toUpperCase()+e.slice(1)),to=Nn(e=>e?`on${zn(e)}`:""),qt=(e,t)=>!Object.is(e,t),un=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Ra=(e,t,i,s=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:s,value:i})},Hn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Er;const Fn=()=>Er||(Er=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Yt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const s=e[i],n=st(s)?Bd(s):Yt(s);if(n)for(const o in n)t[o]=n[o]}return t}else if(st(e)||Ye(e))return e}const Td=/;(?![^(]*\))/g,Ed=/:([^]+)/,Ad=/\/\*[^]*?\*\//g;function Bd(e){const t={};return e.replace(Ad,"").split(Td).forEach(i=>{if(i){const s=i.split(Ed);s.length>1&&(t[s[0].trim()]=s[1].trim())}}),t}function Ce(e){let t="";if(st(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const s=Ce(e[i]);s&&(t+=s+" ")}else if(Ye(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Dd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Ld=qo(Dd);function Na(e){return!!e||e===""}function Pd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let s=0;i&&s<e.length;s++)i=gs(e[s],t[s]);return i}function gs(e,t){if(e===t)return!0;let i=Tr(e),s=Tr(t);if(i||s)return i&&s?e.getTime()===t.getTime():!1;if(i=Ht(e),s=Ht(t),i||s)return e===t;if(i=Ee(e),s=Ee(t),i||s)return i&&s?Pd(e,t):!1;if(i=Ye(e),s=Ye(t),i||s){if(!i||!s)return!1;const n=Object.keys(e).length,o=Object.keys(t).length;if(n!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!gs(e[a],t[a]))return!1}}return String(e)===String(t)}function Jo(e,t){return e.findIndex(i=>gs(i,t))}const za=e=>!!(e&&e.__v_isRef===!0),we=e=>st(e)?e:e==null?"":Ee(e)||Ye(e)&&(e.toString===Pa||!Be(e.toString))?za(e)?we(e.value):JSON.stringify(e,Ha,2):String(e),Ha=(e,t)=>za(t)?Ha(e,t.value):rs(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[s,n],o)=>(i[io(s,o)+" =>"]=n,i),{})}:ms(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>io(i))}:Ht(t)?io(t):Ye(t)&&!Ee(t)&&!Oa(t)?String(t):t,io=(e,t="")=>{var i;return Ht(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ct;class Od{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&ct&&(ct.active?(this.parent=ct,this.index=(ct.scopes||(ct.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}const s=this.effects.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}}run(t){if(this._active){const i=ct;try{return ct=this,t()}finally{ct=i}}}on(){++this._on===1&&(this.prevScope=ct,ct=this)}off(){if(this._on>0&&--this._on===0){if(ct===this)ct=this.prevScope;else{let t=ct;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,s;for(i=0,s=this.effects.length;i<s;i++)this.effects[i].stop();for(this.effects.length=0,i=0,s=this.cleanups.length;i<s;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(i=0,s=n.length;i<s;i++)n[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Rd(){return ct}let Qe;const so=new WeakSet;class Fa{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ct&&(ct.active?ct.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,so.has(this)&&(so.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Wa(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Ar(this),Ua(this);const t=Qe,i=Nt;Qe=this,Nt=!0;try{return this.fn()}finally{Va(this),Qe=t,Nt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)er(t);this.deps=this.depsTail=void 0,Ar(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?so.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){$o(this)&&this.run()}get dirty(){return $o(this)}}let ja=0,Es,As;function Wa(e,t=!1){if(e.flags|=8,t){e.next=As,As=e;return}e.next=Es,Es=e}function Xo(){ja++}function Qo(){if(--ja>0)return;if(As){let t=As;for(As=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Es;){let t=Es;for(Es=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(s){e||(e=s)}t=i}}if(e)throw e}function Ua(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Va(e){let t,i=e.depsTail,s=i;for(;s;){const n=s.prevDep;s.version===-1?(s===i&&(i=n),er(s),Nd(s)):t=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}e.deps=t,e.depsTail=i}function $o(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Ga(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Ga(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===js)||(e.globalVersion=js,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!$o(e))))return;e.flags|=2;const t=e.dep,i=Qe,s=Nt;Qe=e,Nt=!0;try{Ua(e);const n=e.fn(e._value);(t.version===0||qt(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Qe=i,Nt=s,Va(e),e.flags&=-3}}function er(e,t=!1){const{dep:i,prevSub:s,nextSub:n}=e;if(s&&(s.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=s,e.nextSub=void 0),i.subs===e&&(i.subs=s,!s&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)er(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Nd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Nt=!0;const Ka=[];function mi(){Ka.push(Nt),Nt=!1}function gi(){const e=Ka.pop();Nt=e===void 0?!0:e}function Ar(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Qe;Qe=void 0;try{t()}finally{Qe=i}}}let js=0;class zd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class tr{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Qe||!Nt||Qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Qe)i=this.activeLink=new zd(Qe,this),Qe.deps?(i.prevDep=Qe.depsTail,Qe.depsTail.nextDep=i,Qe.depsTail=i):Qe.deps=Qe.depsTail=i,qa(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const s=i.nextDep;s.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=s),i.prevDep=Qe.depsTail,i.nextDep=void 0,Qe.depsTail.nextDep=i,Qe.depsTail=i,Qe.deps===i&&(Qe.deps=s)}return i}trigger(t){this.version++,js++,this.notify(t)}notify(t){Xo();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Qo()}}}function qa(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let s=t.deps;s;s=s.nextDep)qa(s)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const Io=new WeakMap,Wi=Symbol(""),Mo=Symbol(""),Ws=Symbol("");function mt(e,t,i){if(Nt&&Qe){let s=Io.get(e);s||Io.set(e,s=new Map);let n=s.get(i);n||(s.set(i,n=new tr),n.map=s,n.key=i),n.track()}}function ci(e,t,i,s,n,o){const a=Io.get(e);if(!a){js++;return}const r=l=>{l&&l.trigger()};if(Xo(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Zo(i);if(l&&i==="length"){const u=Number(s);a.forEach((f,d)=>{(d==="length"||d===Ws||!Ht(d)&&d>=u)&&r(f)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(Ws)),t){case"add":l?c&&r(a.get("length")):(r(a.get(Wi)),rs(e)&&r(a.get(Mo)));break;case"delete":l||(r(a.get(Wi)),rs(e)&&r(a.get(Mo)));break;case"set":rs(e)&&r(a.get(Wi));break}}Qo()}function Zi(e){const t=Ue(e);return t===e?t:(mt(t,"iterate",Ws),Pt(e)?t:t.map(Ft))}function jn(e){return mt(e=Ue(e),"iterate",Ws),e}function Gt(e,t){return vi(e)?us(Ui(e)?Ft(t):t):Ft(t)}const Hd={__proto__:null,[Symbol.iterator](){return no(this,Symbol.iterator,e=>Gt(this,e))},concat(...e){return Zi(this).concat(...e.map(t=>Ee(t)?Zi(t):t))},entries(){return no(this,"entries",e=>(e[1]=Gt(this,e[1]),e))},every(e,t){return si(this,"every",e,t,void 0,arguments)},filter(e,t){return si(this,"filter",e,t,i=>i.map(s=>Gt(this,s)),arguments)},find(e,t){return si(this,"find",e,t,i=>Gt(this,i),arguments)},findIndex(e,t){return si(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return si(this,"findLast",e,t,i=>Gt(this,i),arguments)},findLastIndex(e,t){return si(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return si(this,"forEach",e,t,void 0,arguments)},includes(...e){return oo(this,"includes",e)},indexOf(...e){return oo(this,"indexOf",e)},join(e){return Zi(this).join(e)},lastIndexOf(...e){return oo(this,"lastIndexOf",e)},map(e,t){return si(this,"map",e,t,void 0,arguments)},pop(){return xs(this,"pop")},push(...e){return xs(this,"push",e)},reduce(e,...t){return Br(this,"reduce",e,t)},reduceRight(e,...t){return Br(this,"reduceRight",e,t)},shift(){return xs(this,"shift")},some(e,t){return si(this,"some",e,t,void 0,arguments)},splice(...e){return xs(this,"splice",e)},toReversed(){return Zi(this).toReversed()},toSorted(e){return Zi(this).toSorted(e)},toSpliced(...e){return Zi(this).toSpliced(...e)},unshift(...e){return xs(this,"unshift",e)},values(){return no(this,"values",e=>Gt(this,e))}};function no(e,t,i){const s=jn(e),n=s[t]();return s!==e&&!Pt(e)&&(n._next=n.next,n.next=()=>{const o=n._next();return o.done||(o.value=i(o.value)),o}),n}const Fd=Array.prototype;function si(e,t,i,s,n,o){const a=jn(e),r=a!==e&&!Pt(e),l=a[t];if(l!==Fd[t]){const f=l.apply(e,o);return r?Ft(f):f}let c=i;a!==e&&(r?c=function(f,d){return i.call(this,Gt(e,f),d,e)}:i.length>2&&(c=function(f,d){return i.call(this,f,d,e)}));const u=l.call(a,c,s);return r&&n?n(u):u}function Br(e,t,i,s){const n=jn(e),o=n!==e&&!Pt(e);let a=i,r=!1;n!==e&&(o?(r=s.length===0,a=function(c,u,f){return r&&(r=!1,c=Gt(e,c)),i.call(this,c,Gt(e,u),f,e)}):i.length>3&&(a=function(c,u,f){return i.call(this,c,u,f,e)}));const l=n[t](a,...s);return r?Gt(e,l):l}function oo(e,t,i){const s=Ue(e);mt(s,"iterate",Ws);const n=s[t](...i);return(n===-1||n===!1)&&nr(i[0])?(i[0]=Ue(i[0]),s[t](...i)):n}function xs(e,t,i=[]){mi(),Xo();const s=Ue(e)[t].apply(e,i);return Qo(),gi(),s}const jd=qo("__proto__,__v_isRef,__isVue"),Ya=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ht));function Wd(e){Ht(e)||(e=String(e));const t=Ue(this);return mt(t,"has",e),t.hasOwnProperty(e)}class Za{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,s){if(i==="__v_skip")return t.__v_skip;const n=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!n;if(i==="__v_isReadonly")return n;if(i==="__v_isShallow")return o;if(i==="__v_raw")return s===(n?o?Qd:el:o?Qa:Xa).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(s)?t:void 0;const a=Ee(t);if(!n){let l;if(a&&(l=Hd[i]))return l;if(i==="hasOwnProperty")return Wd}const r=Reflect.get(t,i,tt(t)?t:s);if((Ht(i)?Ya.has(i):jd(i))||(n||mt(t,"get",i),o))return r;if(tt(r)){const l=a&&Zo(i)?r:r.value;return n&&Ye(l)?Eo(l):l}return Ye(r)?n?Eo(r):Wn(r):r}}class Ja extends Za{constructor(t=!1){super(!1,t)}set(t,i,s,n){let o=t[i];const a=Ee(t)&&Zo(i);if(!this._isShallow){const c=vi(o);if(!Pt(s)&&!vi(s)&&(o=Ue(o),s=Ue(s)),!a&&tt(o)&&!tt(s))return c||(o.value=s),!0}const r=a?Number(i)<t.length:Ve(t,i),l=Reflect.set(t,i,s,tt(t)?t:n);return t===Ue(n)&&l&&(r?qt(s,o)&&ci(t,"set",i,s):ci(t,"add",i,s)),l}deleteProperty(t,i){const s=Ve(t,i);t[i];const n=Reflect.deleteProperty(t,i);return n&&s&&ci(t,"delete",i,void 0),n}has(t,i){const s=Reflect.has(t,i);return(!Ht(i)||!Ya.has(i))&&mt(t,"has",i),s}ownKeys(t){return mt(t,"iterate",Ee(t)?"length":Wi),Reflect.ownKeys(t)}}class Ud extends Za{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Vd=new Ja,Gd=new Ud,Kd=new Ja(!0);const To=e=>e,sn=e=>Reflect.getPrototypeOf(e);function qd(e,t,i){return function(...s){const n=this.__v_raw,o=Ue(n),a=rs(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=n[e](...s),u=i?To:t?us:Ft;return!t&&mt(o,"iterate",l?Mo:Wi),ut(Object.create(c),{next(){const{value:f,done:d}=c.next();return d?{value:f,done:d}:{value:r?[u(f[0]),u(f[1])]:u(f),done:d}}})}}function nn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Yd(e,t){const i={get(n){const o=this.__v_raw,a=Ue(o),r=Ue(n);e||(qt(n,r)&&mt(a,"get",n),mt(a,"get",r));const{has:l}=sn(a),c=t?To:e?us:Ft;if(l.call(a,n))return c(o.get(n));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(n)},get size(){const n=this.__v_raw;return!e&&mt(Ue(n),"iterate",Wi),n.size},has(n){const o=this.__v_raw,a=Ue(o),r=Ue(n);return e||(qt(n,r)&&mt(a,"has",n),mt(a,"has",r)),n===r?o.has(n):o.has(n)||o.has(r)},forEach(n,o){const a=this,r=a.__v_raw,l=Ue(r),c=t?To:e?us:Ft;return!e&&mt(l,"iterate",Wi),r.forEach((u,f)=>n.call(o,c(u),c(f),a))}};return ut(i,e?{add:nn("add"),set:nn("set"),delete:nn("delete"),clear:nn("clear")}:{add(n){const o=Ue(this),a=sn(o),r=Ue(n),l=!t&&!Pt(n)&&!vi(n)?r:n;return a.has.call(o,l)||qt(n,l)&&a.has.call(o,n)||qt(r,l)&&a.has.call(o,r)||(o.add(l),ci(o,"add",l,l)),this},set(n,o){!t&&!Pt(o)&&!vi(o)&&(o=Ue(o));const a=Ue(this),{has:r,get:l}=sn(a);let c=r.call(a,n);c||(n=Ue(n),c=r.call(a,n));const u=l.call(a,n);return a.set(n,o),c?qt(o,u)&&ci(a,"set",n,o):ci(a,"add",n,o),this},delete(n){const o=Ue(this),{has:a,get:r}=sn(o);let l=a.call(o,n);l||(n=Ue(n),l=a.call(o,n)),r&&r.call(o,n);const c=o.delete(n);return l&&ci(o,"delete",n,void 0),c},clear(){const n=Ue(this),o=n.size!==0,a=n.clear();return o&&ci(n,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(n=>{i[n]=qd(n,e,t)}),i}function ir(e,t){const i=Yd(e,t);return(s,n,o)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?s:Reflect.get(Ve(i,n)&&n in s?i:s,n,o)}const Zd={get:ir(!1,!1)},Jd={get:ir(!1,!0)},Xd={get:ir(!0,!1)};const Xa=new WeakMap,Qa=new WeakMap,el=new WeakMap,Qd=new WeakMap;function eu(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Wn(e){return vi(e)?e:sr(e,!1,Vd,Zd,Xa)}function tu(e){return sr(e,!1,Kd,Jd,Qa)}function Eo(e){return sr(e,!0,Gd,Xd,el)}function sr(e,t,i,s,n){if(!Ye(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=n.get(e);if(o)return o;const a=eu($d(e));if(a===0)return e;const r=new Proxy(e,a===2?s:i);return n.set(e,r),r}function Ui(e){return vi(e)?Ui(e.__v_raw):!!(e&&e.__v_isReactive)}function vi(e){return!!(e&&e.__v_isReadonly)}function Pt(e){return!!(e&&e.__v_isShallow)}function nr(e){return e?!!e.__v_raw:!1}function Ue(e){const t=e&&e.__v_raw;return t?Ue(t):e}function iu(e){return!Ve(e,"__v_skip")&&Object.isExtensible(e)&&Ra(e,"__v_skip",!0),e}const Ft=e=>Ye(e)?Wn(e):e,us=e=>Ye(e)?Eo(e):e;function tt(e){return e?e.__v_isRef===!0:!1}function ge(e){return su(e,!1)}function su(e,t){return tt(e)?e:new nu(e,t)}class nu{constructor(t,i){this.dep=new tr,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Ue(t),this._value=i?t:Ft(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,s=this.__v_isShallow||Pt(t)||vi(t);t=s?t:Ue(t),qt(t,i)&&(this._rawValue=t,this._value=s?t:Ft(t),this.dep.trigger())}}function he(e){return tt(e)?e.value:e}const ou={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,s)=>{const n=e[t];return tt(n)&&!tt(i)?(n.value=i,!0):Reflect.set(e,t,i,s)}};function tl(e){return Ui(e)?e:new Proxy(e,ou)}class ru{constructor(t,i,s){this.fn=t,this.setter=i,this._value=void 0,this.dep=new tr(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=js-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Qe!==this)return Wa(this,!0),!0}get value(){const t=this.dep.track();return Ga(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function au(e,t,i=!1){let s,n;return Be(e)?s=e:(s=e.get,n=e.set),new ru(s,n,i)}const on={},$n=new WeakMap;let Ni;function lu(e,t=!1,i=Ni){if(i){let s=$n.get(i);s||$n.set(i,s=[]),s.push(e)}}function cu(e,t,i=Je){const{immediate:s,deep:n,once:o,scheduler:a,augmentJob:r,call:l}=i,c=S=>n?S:Pt(S)||n===!1||n===0?di(S,1):di(S);let u,f,d,p,k=!1,m=!1;if(tt(e)?(f=()=>e.value,k=Pt(e)):Ui(e)?(f=()=>c(e),k=!0):Ee(e)?(m=!0,k=e.some(S=>Ui(S)||Pt(S)),f=()=>e.map(S=>{if(tt(S))return S.value;if(Ui(S))return c(S);if(Be(S))return l?l(S,2):S()})):Be(e)?t?f=l?()=>l(e,2):e:f=()=>{if(d){mi();try{d()}finally{gi()}}const S=Ni;Ni=u;try{return l?l(e,3,[p]):e(p)}finally{Ni=S}}:f=Qt,t&&n){const S=f,B=n===!0?1/0:n;f=()=>di(S(),B)}const b=Rd(),y=()=>{u.stop(),b&&b.active&&Yo(b.effects,u)};if(o&&t){const S=t;t=(...B)=>{const A=S(...B);return y(),A}}let v=m?new Array(e.length).fill(on):on;const w=S=>{if(!(!(u.flags&1)||!u.dirty&&!S))if(t){const B=u.run();if(S||n||k||(m?B.some((A,C)=>qt(A,v[C])):qt(B,v))){d&&d();const A=Ni;Ni=u;try{const C=[B,v===on?void 0:m&&v[0]===on?[]:v,p];v=B,l?l(t,3,C):t(...C)}finally{Ni=A}}}else u.run()};return r&&r(w),u=new Fa(f),u.scheduler=a?()=>a(w,!1):w,p=S=>lu(S,!1,u),d=u.onStop=()=>{const S=$n.get(u);if(S){if(l)l(S,4);else for(const B of S)B();$n.delete(u)}},t?s?w(!0):v=u.run():a?a(w.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function di(e,t=1/0,i){if(t<=0||!Ye(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,tt(e))di(e.value,t,i);else if(Ee(e))for(let s=0;s<e.length;s++)di(e[s],t,i);else if(ms(e)||rs(e))e.forEach(s=>{di(s,t,i)});else if(Oa(e)){for(const s in e)di(e[s],t,i);for(const s of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,s)&&di(e[s],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Zs(e,t,i,s){try{return s?e(...s):e()}catch(n){Un(n,t,i)}}function jt(e,t,i,s){if(Be(e)){const n=Zs(e,t,i,s);return n&&La(n)&&n.catch(o=>{Un(o,t,i)}),n}if(Ee(e)){const n=[];for(let o=0;o<e.length;o++)n.push(jt(e[o],t,i,s));return n}}function Un(e,t,i,s=!0){const n=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,l,c)===!1)return}r=r.parent}if(o){mi(),Zs(o,null,10,[e,l,c]),gi();return}}du(e,i,n,s,a)}function du(e,t,i,s=!0,n=!1){if(n)throw e;console.error(e)}const xt=[];let Ut=-1;const as=[];let Ci=null,Ji=0;const il=Promise.resolve();let In=null;function Mn(e){const t=In||il;return e?t.then(this?e.bind(this):e):t}function uu(e){let t=Ut+1,i=xt.length;for(;t<i;){const s=t+i>>>1,n=xt[s],o=Us(n);o<e||o===e&&n.flags&2?t=s+1:i=s}return t}function or(e){if(!(e.flags&1)){const t=Us(e),i=xt[xt.length-1];!i||!(e.flags&2)&&t>=Us(i)?xt.push(e):xt.splice(uu(t),0,e),e.flags|=1,sl()}}function sl(){In||(In=il.then(ol))}function fu(e){Ee(e)?as.push(...e):Ci&&e.id===-1?Ci.splice(Ji+1,0,e):e.flags&1||(as.push(e),e.flags|=1),sl()}function Dr(e,t,i=Ut+1){for(;i<xt.length;i++){const s=xt[i];if(s&&s.flags&2){if(e&&s.id!==e.uid)continue;xt.splice(i,1),i--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function nl(e){if(as.length){const t=[...new Set(as)].sort((i,s)=>Us(i)-Us(s));if(as.length=0,Ci){Ci.push(...t);return}for(Ci=t,Ji=0;Ji<Ci.length;Ji++){const i=Ci[Ji];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}Ci=null,Ji=0}}const Us=e=>e.id==null?e.flags&2?-1:1/0:e.id;function ol(e){try{for(Ut=0;Ut<xt.length;Ut++){const t=xt[Ut];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Zs(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ut<xt.length;Ut++){const t=xt[Ut];t&&(t.flags&=-2)}Ut=-1,xt.length=0,nl(),In=null,(xt.length||as.length)&&ol()}}let dt=null,rl=null;function Tn(e){const t=dt;return dt=e,rl=e&&e.type.__scopeId||null,t}function al(e,t=dt,i){if(!t||e._n)return e;const s=(...n)=>{s._d&&Vr(-1);const o=Tn(t),a=fi.length;let r;try{r=e(...n)}finally{for(let l=fi.length;l>a;l--)dr();Tn(o),s._d&&Vr(1)}return r};return s._n=!0,s._c=!0,s._d=!0,s}function Ot(e,t){if(dt===null)return e;const i=Yn(dt),s=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[o,a,r,l=Je]=t[n];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&di(a),s.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Li(e,t,i,s){const n=e.dirs,o=t&&t.dirs;for(let a=0;a<n.length;a++){const r=n[a];o&&(r.oldValue=o[a].value);let l=r.dir[s];l&&(mi(),jt(l,i,8,[e.el,r,e,t]),gi())}}function pu(e,t){if(yt){let i=yt.provides;const s=yt.parent&&yt.parent.provides;s===i&&(i=yt.provides=Object.create(s)),i[e]=t}}function zt(e,t,i=!1){const s=ff();if(s||cs){let n=cs?cs._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return i&&Be(t)?t.call(s&&s.proxy):t}}const hu=Symbol.for("v-scx"),mu=()=>zt(hu);function Vi(e,t,i){return ll(e,t,i)}function ll(e,t,i=Je){const{immediate:s,deep:n,flush:o,once:a}=i,r=ut({},i),l=t&&s||!t&&o!=="post";let c;if(Gs){if(o==="sync"){const p=mu();c=p.__watcherHandles||(p.__watcherHandles=[])}else if(!l){const p=()=>{};return p.stop=Qt,p.resume=Qt,p.pause=Qt,p}}const u=yt;r.call=(p,k,m)=>jt(p,u,k,m);let f=!1;o==="post"?r.scheduler=p=>{_t(p,u&&u.suspense)}:o!=="sync"&&(f=!0,r.scheduler=(p,k)=>{k?p():or(p)}),r.augmentJob=p=>{t&&(p.flags|=4),f&&(p.flags|=2,u&&(p.id=u.uid,p.i=u))};const d=cu(e,t,r);return Gs&&(c?c.push(d):l&&d()),d}function gu(e,t,i){const s=this.proxy,n=st(e)?e.includes(".")?cl(s,e):()=>s[e]:e.bind(s,s);let o;Be(t)?o=t:(o=t.handler,i=t);const a=Js(this),r=ll(n,o.bind(s),i);return a(),r}function cl(e,t){const i=t.split(".");return()=>{let s=e;for(let n=0;n<i.length&&s;n++)s=s[i[n]];return s}}const vu=Symbol("_vte"),bu=e=>e.__isTeleport,ro=Symbol("_leaveCb");function rr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,rr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Dt(e,t){return Be(e)?ut({name:e.name},t,{setup:e}):e}function dl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Lr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const En=new WeakMap;function Bs(e,t,i,s,n=!1){if(Ee(e)){e.forEach((m,b)=>Bs(m,t&&(Ee(t)?t[b]:t),i,s,n));return}if(ls(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&Bs(e,t,i,s.component.subTree);return}const o=s.shapeFlag&4?Yn(s.component):s.el,a=n?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,f=r.setupState,d=Ue(f),p=f===Je?Da:m=>Lr(u,m)?!1:Ve(d,m),k=(m,b)=>!(b&&Lr(u,b));if(c!=null&&c!==l){if(Pr(t),st(c))u[c]=null,p(c)&&(f[c]=null);else if(tt(c)){const m=t;k(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Be(l))Zs(l,r,12,[a,u]);else{const m=st(l),b=tt(l);if(m||b){const y=()=>{if(e.f){const v=m?p(l)?f[l]:u[l]:k()||!e.k?l.value:u[e.k];if(n)Ee(v)&&Yo(v,o);else if(Ee(v))v.includes(o)||v.push(o);else if(m)u[l]=[o],p(l)&&(f[l]=u[l]);else{const w=[o];k(l,e.k)&&(l.value=w),e.k&&(u[e.k]=w)}}else m?(u[l]=a,p(l)&&(f[l]=a)):b&&(k(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const v=()=>{y(),En.delete(e)};v.id=-1,En.set(e,v),_t(v,i)}else Pr(e),y()}}}function Pr(e){const t=En.get(e);t&&(t.flags|=8,En.delete(e))}Fn().requestIdleCallback;Fn().cancelIdleCallback;const ls=e=>!!e.type.__asyncLoader,ul=e=>e.type.__isKeepAlive;function yu(e,t){fl(e,"a",t)}function ku(e,t){fl(e,"da",t)}function fl(e,t,i=yt){const s=e.__wdc||(e.__wdc=()=>{let n=i;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Vn(t,s,i),i){let n=i.parent;for(;n&&n.parent;)ul(n.parent.vnode)&&wu(s,t,i,n),n=n.parent}}function wu(e,t,i,s){const n=Vn(t,e,s,!0);Gn(()=>{Yo(s[t],n)},i)}function Vn(e,t,i=yt,s=!1){if(i){const n=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{mi();const r=Js(i),l=jt(t,i,e,a);return r(),gi(),l});return s?n.unshift(o):n.push(o),o}}const yi=e=>(t,i=yt)=>{(!Gs||e==="sp")&&Vn(e,(...s)=>t(...s),i)},xu=yi("bm"),vs=yi("m"),Su=yi("bu"),Cu=yi("u"),ar=yi("bum"),Gn=yi("um"),_u=yi("sp"),$u=yi("rtg"),Iu=yi("rtc");function Mu(e,t=yt){Vn("ec",e,t)}const Tu="components";function Eu(e,t){return Bu(Tu,e,!0,t)||e}const Au=Symbol.for("v-ndc");function Bu(e,t,i=!0,s=!1){const n=dt||yt;if(n){const o=n.type;{const r=vf(o,!1);if(r&&(r===t||r===Ct(t)||r===zn(Ct(t))))return o}const a=Or(n[e]||o[e],t)||Or(n.appContext[e],t);return!a&&s?o:a}}function Or(e,t){return e&&(e[t]||e[Ct(t)]||e[zn(Ct(t))])}function St(e,t,i,s){let n;const o=i,a=Ee(e);if(a||st(e)){const r=a&&Ui(e);let l=!1,c=!1;r&&(l=!Pt(e),c=vi(e),e=jn(e)),n=new Array(e.length);for(let u=0,f=e.length;u<f;u++)n[u]=t(l?c?us(Ft(e[u])):Ft(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,o)}else if(Ye(e))if(e[Symbol.iterator])n=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);n=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];n[l]=t(e[u],u,l,o)}}else n=[];return n}function rn(e,t,i={},s,n,o){if(dt.ce||dt.parent&&ls(dt.parent)&&dt.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Jt(Xe,null,[oe("slot",c,s&&s())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=fi.length;J();let l;try{const c=a&&pl(a(i)),u=i.key||o||c&&c.key;l=Jt(Xe,{key:(u&&!Ht(u)?u:`_${t}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&e._===1?64:-2)}catch(c){for(let u=fi.length;u>r;u--)dr();throw c}finally{a&&a._c&&(a._d=!0)}return l}function pl(e){return e.some(t=>ur(t)?!(t.type===bi||t.type===Xe&&!pl(t.children)):!0)?e:null}const Ao=e=>e?Dl(e)?Yn(e):Ao(e.parent):null,Ds=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ao(e.parent),$root:e=>Ao(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ml(e),$forceUpdate:e=>e.f||(e.f=()=>{or(e.update)}),$nextTick:e=>e.n||(e.n=Mn.bind(e.proxy)),$watch:e=>gu.bind(e)}),ao=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ve(e,t),Du={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:s,data:n,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const d=a[t];if(d!==void 0)switch(d){case 1:return s[t];case 2:return n[t];case 4:return i[t];case 3:return o[t]}else{if(ao(s,t))return a[t]=1,s[t];if(n!==Je&&Ve(n,t))return a[t]=2,n[t];if(Ve(o,t))return a[t]=3,o[t];if(i!==Je&&Ve(i,t))return a[t]=4,i[t];Bo&&(a[t]=0)}}const c=Ds[t];let u,f;if(c)return t==="$attrs"&&mt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Je&&Ve(i,t))return a[t]=4,i[t];if(f=l.config.globalProperties,Ve(f,t))return f[t]},set({_:e},t,i){const{data:s,setupState:n,ctx:o}=e;return ao(n,t)?(n[t]=i,!0):s!==Je&&Ve(s,t)?(s[t]=i,!0):Ve(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:s,appContext:n,props:o,type:a}},r){let l;return!!(i[r]||e!==Je&&r[0]!=="$"&&Ve(e,r)||ao(t,r)||Ve(o,r)||Ve(s,r)||Ve(Ds,r)||Ve(n.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Ve(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Rr(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Bo=!0;function Lu(e){const t=ml(e),i=e.proxy,s=e.ctx;Bo=!1,t.beforeCreate&&Nr(t.beforeCreate,e,"bc");const{data:n,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:f,mounted:d,beforeUpdate:p,updated:k,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:v,destroyed:w,unmounted:S,render:B,renderTracked:A,renderTriggered:C,errorCaptured:L,serverPrefetch:z,expose:N,inheritAttrs:K,components:_,directives:U,filters:x}=t;if(c&&Pu(c,s,null),a)for(const $ in a){const T=a[$];Be(T)&&(s[$]=T.bind(i))}if(n){const $=n.call(i,i);Ye($)&&(e.data=Wn($))}if(Bo=!0,o)for(const $ in o){const T=o[$],P=Be(T)?T.bind(i,i):Be(T.get)?T.get.bind(i,i):Qt,ne=!Be(T)&&Be(T.set)?T.set.bind(i):Qt,V=ye({get:P,set:ne});Object.defineProperty(s,$,{enumerable:!0,configurable:!0,get:()=>V.value,set:Y=>V.value=Y})}if(r)for(const $ in r)hl(r[$],s,i,$);if(l){const $=Be(l)?l.call(i):l;Reflect.ownKeys($).forEach(T=>{pu(T,$[T])})}u&&Nr(u,e,"c");function O($,T){Ee(T)?T.forEach(P=>$(P.bind(i))):T&&$(T.bind(i))}if(O(xu,f),O(vs,d),O(Su,p),O(Cu,k),O(yu,m),O(ku,b),O(Mu,L),O(Iu,A),O($u,C),O(ar,v),O(Gn,S),O(_u,z),Ee(N))if(N.length){const $=e.exposed||(e.exposed={});N.forEach(T=>{Object.defineProperty($,T,{get:()=>i[T],set:P=>i[T]=P,enumerable:!0})})}else e.exposed||(e.exposed={});B&&e.render===Qt&&(e.render=B),K!=null&&(e.inheritAttrs=K),_&&(e.components=_),U&&(e.directives=U),z&&dl(e)}function Pu(e,t,i=Qt){Ee(e)&&(e=Do(e));for(const s in e){const n=e[s];let o;Ye(n)?"default"in n?o=zt(n.from||s,n.default,!0):o=zt(n.from||s):o=zt(n),tt(o)?Object.defineProperty(t,s,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[s]=o}}function Nr(e,t,i){jt(Ee(e)?e.map(s=>s.bind(t.proxy)):e.bind(t.proxy),t,i)}function hl(e,t,i,s){let n=s.includes(".")?cl(i,s):()=>i[s];if(st(e)){const o=t[e];Be(o)&&Vi(n,o)}else if(Be(e))Vi(n,e.bind(i));else if(Ye(e))if(Ee(e))e.forEach(o=>hl(o,t,i,s));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Vi(n,o,e)}}function ml(e){const t=e.type,{mixins:i,extends:s}=t,{mixins:n,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!n.length&&!i&&!s?l=t:(l={},n.length&&n.forEach(c=>An(l,c,a,!0)),An(l,t,a)),Ye(t)&&o.set(t,l),l}function An(e,t,i,s=!1){const{mixins:n,extends:o}=t;o&&An(e,o,i,!0),n&&n.forEach(a=>An(e,a,i,!0));for(const a in t)if(!(s&&a==="expose")){const r=Ou[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Ou={data:zr,props:Hr,emits:Hr,methods:_s,computed:_s,beforeCreate:wt,created:wt,beforeMount:wt,mounted:wt,beforeUpdate:wt,updated:wt,beforeDestroy:wt,beforeUnmount:wt,destroyed:wt,unmounted:wt,activated:wt,deactivated:wt,errorCaptured:wt,serverPrefetch:wt,components:_s,directives:_s,watch:Nu,provide:zr,inject:Ru};function zr(e,t){return t?e?function(){return ut(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Ru(e,t){return _s(Do(e),Do(t))}function Do(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function wt(e,t){return e?[...new Set([].concat(e,t))]:t}function _s(e,t){return e?ut(Object.create(null),e,t):t}function Hr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:ut(Object.create(null),Rr(e),Rr(t??{})):t}function Nu(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const s in t)i[s]=wt(e[s],t[s]);return i}function gl(){return{app:null,config:{isNativeTag:Da,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let zu=0;function Hu(e,t){return function(s,n=null){Be(s)||(s=ut({},s)),n!=null&&!Ye(n)&&(n=null);const o=gl(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:zu++,_component:s,_props:n,_container:null,_context:o,_instance:null,version:yf,get config(){return o.config},set config(u){},use(u,...f){return a.has(u)||(u&&Be(u.install)?(a.add(u),u.install(c,...f)):Be(u)&&(a.add(u),u(c,...f))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,f){return f?(o.components[u]=f,c):o.components[u]},directive(u,f){return f?(o.directives[u]=f,c):o.directives[u]},mount(u,f,d){if(!l){const p=c._ceVNode||oe(s,n);return p.appContext=o,d===!0?d="svg":d===!1&&(d=void 0),e(p,u,d),l=!0,c._container=u,u.__vue_app__=c,Yn(p.component)}},onUnmount(u){r.push(u)},unmount(){l&&(jt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return o.provides[u]=f,c},runWithContext(u){const f=cs;cs=c;try{return u()}finally{cs=f}}};return c}}let cs=null;const Fu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Ct(t)}Modifiers`]||e[`${Bi(t)}Modifiers`];function ju(e,t,...i){if(e.isUnmounted)return;const s=e.vnode.props||Je;let n=i;const o=t.startsWith("update:"),a=o&&Fu(s,t.slice(7));a&&(a.trim&&(n=i.map(u=>st(u)?u.trim():u)),a.number&&(n=i.map(Hn)));let r,l=s[r=to(t)]||s[r=to(Ct(t))];!l&&o&&(l=s[r=to(Bi(t))]),l&&jt(l,e,6,n);const c=s[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,jt(c,e,6,n)}}const Wu=new WeakMap;function vl(e,t,i=!1){const s=i?Wu:t.emitsCache,n=s.get(e);if(n!==void 0)return n;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const u=vl(c,t,!0);u&&(r=!0,ut(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ye(e)&&s.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):ut(a,o),Ye(e)&&s.set(e,a),a)}function Kn(e,t){return!e||!On(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ve(e,t[0].toLowerCase()+t.slice(1))||Ve(e,Bi(t))||Ve(e,t))}function Fr(e){const{type:t,vnode:i,proxy:s,withProxy:n,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:f,data:d,setupState:p,ctx:k,inheritAttrs:m}=e,b=Tn(e);let y,v;try{if(i.shapeFlag&4){const S=n||s,B=S;y=Kt(c.call(B,S,u,f,p,d,k)),v=r}else{const S=t;y=Kt(S.length>1?S(f,{attrs:r,slots:a,emit:l}):S(f,null)),v=t.props?r:Uu(r)}}catch(S){fi.length=0,Un(S,e,1),y=oe(bi)}let w=y;if(v&&m!==!1){const S=Object.keys(v),{shapeFlag:B}=w;S.length&&B&7&&(o&&S.some(Rn)&&(v=Vu(v,o)),w=fs(w,v,!1,!0))}return i.dirs&&(w=fs(w,null,!1,!0),w.dirs=w.dirs?w.dirs.concat(i.dirs):i.dirs),i.transition&&rr(w,i.transition),y=w,Tn(b),y}const Uu=e=>{let t;for(const i in e)(i==="class"||i==="style"||On(i))&&((t||(t={}))[i]=e[i]);return t},Vu=(e,t)=>{const i={};for(const s in e)(!Rn(s)||!(s.slice(9)in t))&&(i[s]=e[s]);return i};function Gu(e,t,i){const{props:s,children:n,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return s?jr(s,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const d=u[f];if(bl(a,s,d)&&!Kn(c,d))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:s===a?!1:s?a?jr(s,a,c):!0:!!a;return!1}function jr(e,t,i){const s=Object.keys(t);if(s.length!==Object.keys(e).length)return!0;for(let n=0;n<s.length;n++){const o=s[n];if(bl(t,e,o)&&!Kn(i,o))return!0}return!1}function bl(e,t,i){const s=e[i],n=t[i];return i==="style"&&Ye(s)&&Ye(n)?!gs(s,n):s!==n}function Ku({vnode:e,parent:t,suspense:i},s){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=s,e=n),n===e)(e=t.vnode).el=s,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=s)}const yl={},kl=()=>Object.create(yl),wl=e=>Object.getPrototypeOf(e)===yl;function qu(e,t,i,s=!1){const n={},o=kl();e.propsDefaults=Object.create(null),xl(e,t,n,o);for(const a in e.propsOptions[0])a in n||(n[a]=void 0);i?e.props=s?n:tu(n):e.type.props?e.props=n:e.props=o,e.attrs=o}function Yu(e,t,i,s){const{props:n,attrs:o,vnode:{patchFlag:a}}=e,r=Ue(n),[l]=e.propsOptions;let c=!1;if((s||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let d=u[f];if(Kn(e.emitsOptions,d))continue;const p=t[d];if(l)if(Ve(o,d))p!==o[d]&&(o[d]=p,c=!0);else{const k=Ct(d);n[k]=Lo(l,r,k,p,e,!1)}else p!==o[d]&&(o[d]=p,c=!0)}}}else{xl(e,t,n,o)&&(c=!0);let u;for(const f in r)(!t||!Ve(t,f)&&((u=Bi(f))===f||!Ve(t,u)))&&(l?i&&(i[f]!==void 0||i[u]!==void 0)&&(n[f]=Lo(l,r,f,void 0,e,!0)):delete n[f]);if(o!==r)for(const f in o)(!t||!Ve(t,f))&&(delete o[f],c=!0)}c&&ci(e.attrs,"set","")}function xl(e,t,i,s){const[n,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Ts(l))continue;const c=t[l];let u;n&&Ve(n,u=Ct(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Kn(e.emitsOptions,l)||(!(l in s)||c!==s[l])&&(s[l]=c,a=!0)}if(o){const l=Ue(i),c=r||Je;for(let u=0;u<o.length;u++){const f=o[u];i[f]=Lo(n,l,f,c[f],e,!Ve(c,f))}}return a}function Lo(e,t,i,s,n,o){const a=e[i];if(a!=null){const r=Ve(a,"default");if(r&&s===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=n;if(i in c)s=c[i];else{const u=Js(n);s=c[i]=l.call(null,t),u()}}else s=l;n.ce&&n.ce._setProp(i,s)}a[0]&&(o&&!r?s=!1:a[1]&&(s===""||s===Bi(i))&&(s=!0))}return s}const Zu=new WeakMap;function Sl(e,t,i=!1){const s=i?Zu:t.propsCache,n=s.get(e);if(n)return n;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const u=f=>{l=!0;const[d,p]=Sl(f,t,!0);ut(a,d),p&&r.push(...p)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return Ye(e)&&s.set(e,os),os;if(Ee(o))for(let u=0;u<o.length;u++){const f=Ct(o[u]);Wr(f)&&(a[f]=Je)}else if(o)for(const u in o){const f=Ct(u);if(Wr(f)){const d=o[u],p=a[f]=Ee(d)||Be(d)?{type:d}:ut({},d),k=p.type;let m=!1,b=!0;if(Ee(k))for(let y=0;y<k.length;++y){const v=k[y],w=Be(v)&&v.name;if(w==="Boolean"){m=!0;break}else w==="String"&&(b=!1)}else m=Be(k)&&k.name==="Boolean";p[0]=m,p[1]=b,(m||Ve(p,"default"))&&r.push(f)}}const c=[a,r];return Ye(e)&&s.set(e,c),c}function Wr(e){return e[0]!=="$"&&!Ts(e)}const lr=e=>e==="_"||e==="_ctx"||e==="$stable",cr=e=>Ee(e)?e.map(Kt):[Kt(e)],Ju=(e,t,i)=>{if(t._n)return t;const s=al((...n)=>cr(t(...n)),i);return s._c=!1,s},Cl=(e,t,i)=>{const s=e._ctx;for(const n in e){if(lr(n))continue;const o=e[n];if(Be(o))t[n]=Ju(n,o,s);else if(o!=null){const a=cr(o);t[n]=()=>a}}},_l=(e,t)=>{const i=cr(t);e.slots.default=()=>i},$l=(e,t,i)=>{for(const s in t)(i||!lr(s))&&(e[s]=t[s])},Xu=(e,t,i)=>{const s=e.slots=kl();if(e.vnode.shapeFlag&32){const n=t._;n?($l(s,t,i),i&&Ra(s,"_",n,!0)):Cl(t,s)}else t&&_l(e,t)},Qu=(e,t,i)=>{const{vnode:s,slots:n}=e;let o=!0,a=Je;if(s.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:$l(n,t,i):(o=!t.$stable,Cl(t,n)),a=t}else t&&(_l(e,t),a={default:1});if(o)for(const r in n)!lr(r)&&a[r]==null&&delete n[r]},_t=of;function ef(e){return tf(e)}function tf(e,t){const i=Fn();i.__VUE__=!0;const{insert:s,remove:n,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:f,nextSibling:d,setScopeId:p=Qt,insertStaticContent:k}=e,m=(E,F,g,W=null,j=null,M=null,I=void 0,R=null,G=!!F.dynamicChildren)=>{if(E===F)return;E&&!Ss(E,F)&&(W=Ie(E),Y(E,j,M,!0),E=null),F.patchFlag===-2&&(G=!1,F.dynamicChildren=null);const{type:D,ref:H,shapeFlag:Z}=F;switch(D){case qn:b(E,F,g,W);break;case bi:y(E,F,g,W);break;case fn:E==null&&v(F,g,W,I);break;case Xe:_(E,F,g,W,j,M,I,R,G);break;default:Z&1?B(E,F,g,W,j,M,I,R,G):Z&6?U(E,F,g,W,j,M,I,R,G):(Z&64||Z&128)&&D.process(E,F,g,W,j,M,I,R,G,X)}H!=null&&j?Bs(H,E&&E.ref,M,F||E,!F):H==null&&E&&E.ref!=null&&Bs(E.ref,null,M,E,!0)},b=(E,F,g,W)=>{if(E==null)s(F.el=r(F.children),g,W);else{const j=F.el=E.el;F.children!==E.children&&c(j,F.children)}},y=(E,F,g,W)=>{E==null?s(F.el=l(F.children||""),g,W):F.el=E.el},v=(E,F,g,W)=>{[E.el,E.anchor]=k(E.children,F,g,W,E.el,E.anchor)},w=({el:E,anchor:F},g,W)=>{let j;for(;E&&E!==F;)j=d(E),s(E,g,W),E=j;s(F,g,W)},S=({el:E,anchor:F})=>{let g;for(;E&&E!==F;)g=d(E),n(E),E=g;n(F)},B=(E,F,g,W,j,M,I,R,G)=>{if(F.type==="svg"?I="svg":F.type==="math"&&(I="mathml"),E==null)A(F,g,W,j,M,I,R,G);else{const D=E.el&&E.el._isVueCE?E.el:null;try{D&&D._beginPatch(),z(E,F,j,M,I,R,G)}finally{D&&D._endPatch()}}},A=(E,F,g,W,j,M,I,R)=>{let G,D;const{props:H,shapeFlag:Z,transition:te,dirs:se}=E;if(G=E.el=a(E.type,M,H&&H.is,H),Z&8?u(G,E.children):Z&16&&L(E.children,G,null,W,j,lo(E,M),I,R),se&&Li(E,null,W,"created"),C(G,E,E.scopeId,I,W),H){for(const $e in H)$e!=="value"&&!Ts($e)&&o(G,$e,null,H[$e],M,W);"value"in H&&o(G,"value",null,H.value,M),(D=H.onVnodeBeforeMount)&&Wt(D,W,E)}se&&Li(E,null,W,"beforeMount");const me=sf(j,te);me&&te.beforeEnter(G),s(G,F,g),((D=H&&H.onVnodeMounted)||me||se)&&_t(()=>{try{D&&Wt(D,W,E),me&&te.enter(G),se&&Li(E,null,W,"mounted")}finally{}},j)},C=(E,F,g,W,j)=>{if(g&&p(E,g),W)for(let M=0;M<W.length;M++)p(E,W[M]);if(j){let M=j.subTree;if(F===M||El(M.type)&&(M.ssContent===F||M.ssFallback===F)){const I=j.vnode;C(E,I,I.scopeId,I.slotScopeIds,j.parent)}}},L=(E,F,g,W,j,M,I,R,G=0)=>{for(let D=G;D<E.length;D++){const H=E[D]=R?oi(E[D]):Kt(E[D]);m(null,H,F,g,W,j,M,I,R)}},z=(E,F,g,W,j,M,I)=>{const R=F.el=E.el;let{patchFlag:G,dynamicChildren:D,dirs:H}=F;G|=E.patchFlag&16;const Z=E.props||Je,te=F.props||Je;let se;if(g&&Pi(g,!1),(se=te.onVnodeBeforeUpdate)&&Wt(se,g,F,E),H&&Li(F,E,g,"beforeUpdate"),g&&Pi(g,!0),D&&(!E.dynamicChildren||E.dynamicChildren.length!==D.length)&&(G=0,I=!1,D=null),(Z.innerHTML&&te.innerHTML==null||Z.textContent&&te.textContent==null)&&u(R,""),D?N(E.dynamicChildren,D,R,g,W,lo(F,j),M):I||T(E,F,R,null,g,W,lo(F,j),M,!1),G>0){if(G&16)K(R,Z,te,g,j);else if(G&2&&Z.class!==te.class&&o(R,"class",null,te.class,j),G&4&&o(R,"style",Z.style,te.style,j),G&8){const me=F.dynamicProps;for(let $e=0;$e<me.length;$e++){const xe=me[$e],De=Z[xe],je=te[xe];(je!==De||xe==="value")&&o(R,xe,De,je,j,g)}}G&1&&E.children!==F.children&&u(R,F.children)}else!I&&D==null&&K(R,Z,te,g,j);((se=te.onVnodeUpdated)||H)&&_t(()=>{se&&Wt(se,g,F,E),H&&Li(F,E,g,"updated")},W)},N=(E,F,g,W,j,M,I)=>{for(let R=0;R<F.length;R++){const G=E[R],D=F[R],H=G.el&&(G.type===Xe||!Ss(G,D)||G.shapeFlag&198)?f(G.el):g;m(G,D,H,null,W,j,M,I,!0)}},K=(E,F,g,W,j)=>{if(F!==g){if(F!==Je)for(const M in F)!Ts(M)&&!(M in g)&&o(E,M,F[M],null,j,W);for(const M in g){if(Ts(M))continue;const I=g[M],R=F[M];I!==R&&M!=="value"&&o(E,M,R,I,j,W)}"value"in g&&o(E,"value",F.value,g.value,j)}},_=(E,F,g,W,j,M,I,R,G)=>{const D=F.el=E?E.el:r(""),H=F.anchor=E?E.anchor:r("");let{patchFlag:Z,dynamicChildren:te,slotScopeIds:se}=F;se&&(R=R?R.concat(se):se),E==null?(s(D,g,W),s(H,g,W),L(F.children||[],g,H,j,M,I,R,G)):Z>0&&Z&64&&te&&E.dynamicChildren&&E.dynamicChildren.length===te.length?(N(E.dynamicChildren,te,g,j,M,I,R),(F.key!=null||j&&F===j.subTree)&&Il(E,F,!0)):T(E,F,g,H,j,M,I,R,G)},U=(E,F,g,W,j,M,I,R,G)=>{F.slotScopeIds=R,E==null?F.shapeFlag&512?j.ctx.activate(F,g,W,I,G):x(F,g,W,j,M,I,G):q(E,F,G)},x=(E,F,g,W,j,M,I)=>{const R=E.component=uf(E,W,j);if(ul(E)&&(R.ctx.renderer=X),pf(R,!1,I),R.asyncDep){if(j&&j.registerDep(R,O,I),!E.el){const G=R.subTree=oe(bi);y(null,G,F,g),E.placeholder=G.el}}else O(R,E,F,g,j,M,I)},q=(E,F,g)=>{const W=F.component=E.component;if(Gu(E,F,g))if(W.asyncDep&&!W.asyncResolved){$(W,F,g);return}else W.next=F,W.update();else F.el=E.el,W.vnode=F},O=(E,F,g,W,j,M,I)=>{const R=()=>{if(E.isMounted){let{next:Z,bu:te,u:se,parent:me,vnode:$e}=E;{const le=Ml(E);if(le){Z&&(Z.el=$e.el,$(E,Z,I)),le.asyncDep.then(()=>{_t(()=>{E.isUnmounted||D()},j)});return}}let xe=Z,De;Pi(E,!1),Z?(Z.el=$e.el,$(E,Z,I)):Z=$e,te&&un(te),(De=Z.props&&Z.props.onVnodeBeforeUpdate)&&Wt(De,me,Z,$e),Pi(E,!0);const je=Fr(E),ze=E.subTree;E.subTree=je,m(ze,je,f(ze.el),Ie(ze),E,j,M),Z.el=je.el,xe===null&&Ku(E,je.el),se&&_t(se,j),(De=Z.props&&Z.props.onVnodeUpdated)&&_t(()=>Wt(De,me,Z,$e),j)}else{let Z;const{el:te,props:se}=F,{bm:me,m:$e,parent:xe,root:De,type:je}=E,ze=ls(F);Pi(E,!1),me&&un(me),!ze&&(Z=se&&se.onVnodeBeforeMount)&&Wt(Z,xe,F),Pi(E,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(je,E.parent?E.parent.type:void 0);const le=E.subTree=Fr(E);m(null,le,g,W,E,j,M),F.el=le.el}if($e&&_t($e,j),!ze&&(Z=se&&se.onVnodeMounted)){const le=F;_t(()=>Wt(Z,xe,le),j)}(F.shapeFlag&256||xe&&ls(xe.vnode)&&xe.vnode.shapeFlag&256)&&E.a&&_t(E.a,j),E.isMounted=!0,F=g=W=null}};E.scope.on();const G=E.effect=new Fa(R);E.scope.off();const D=E.update=G.run.bind(G),H=E.job=G.runIfDirty.bind(G);H.i=E,H.id=E.uid,G.scheduler=()=>or(H),Pi(E,!0),D()},$=(E,F,g)=>{F.component=E;const W=E.vnode.props;E.vnode=F,E.next=null,Yu(E,F.props,W,g),Qu(E,F.children,g),mi(),Dr(E),gi()},T=(E,F,g,W,j,M,I,R,G=!1)=>{const D=E&&E.children,H=E?E.shapeFlag:0,Z=F.children,{patchFlag:te,shapeFlag:se}=F;if(te>0){if(te&128){ne(D,Z,g,W,j,M,I,R,G);return}else if(te&256){P(D,Z,g,W,j,M,I,R,G);return}}se&8?(H&16&&Se(D,j,M),Z!==D&&u(g,Z)):H&16?se&16?ne(D,Z,g,W,j,M,I,R,G):Se(D,j,M,!0):(H&8&&u(g,""),se&16&&L(Z,g,W,j,M,I,R,G))},P=(E,F,g,W,j,M,I,R,G)=>{E=E||os,F=F||os;const D=E.length,H=F.length,Z=Math.min(D,H);let te;for(te=0;te<Z;te++){const se=F[te]=G?oi(F[te]):Kt(F[te]);m(E[te],se,g,null,j,M,I,R,G)}D>H?Se(E,j,M,!0,!1,Z):L(F,g,W,j,M,I,R,G,Z)},ne=(E,F,g,W,j,M,I,R,G)=>{let D=0;const H=F.length;let Z=E.length-1,te=H-1;for(;D<=Z&&D<=te;){const se=E[D],me=F[D]=G?oi(F[D]):Kt(F[D]);if(Ss(se,me))m(se,me,g,null,j,M,I,R,G);else break;D++}for(;D<=Z&&D<=te;){const se=E[Z],me=F[te]=G?oi(F[te]):Kt(F[te]);if(Ss(se,me))m(se,me,g,null,j,M,I,R,G);else break;Z--,te--}if(D>Z){if(D<=te){const se=te+1,me=se<H?F[se].el:W;for(;D<=te;)m(null,F[D]=G?oi(F[D]):Kt(F[D]),g,me,j,M,I,R,G),D++}}else if(D>te)for(;D<=Z;)Y(E[D],j,M,!0),D++;else{const se=D,me=D,$e=new Map;for(D=me;D<=te;D++){const He=F[D]=G?oi(F[D]):Kt(F[D]);He.key!=null&&$e.set(He.key,D)}let xe,De=0;const je=te-me+1;let ze=!1,le=0;const ue=new Array(je);for(D=0;D<je;D++)ue[D]=0;for(D=se;D<=Z;D++){const He=E[D];if(De>=je){Y(He,j,M,!0);continue}let We;if(He.key!=null)We=$e.get(He.key);else for(xe=me;xe<=te;xe++)if(ue[xe-me]===0&&Ss(He,F[xe])){We=xe;break}We===void 0?Y(He,j,M,!0):(ue[We-me]=D+1,We>=le?le=We:ze=!0,m(He,F[We],g,null,j,M,I,R,G),De++)}const Oe=ze?nf(ue):os;for(xe=Oe.length-1,D=je-1;D>=0;D--){const He=me+D,We=F[He],lt=F[He+1],Et=He+1<H?lt.el||Tl(lt):W;ue[D]===0?m(null,We,g,Et,j,M,I,R,G):ze&&(xe<0||D!==Oe[xe]?V(We,g,Et,2):xe--)}}},V=(E,F,g,W,j=null)=>{const{el:M,type:I,transition:R,children:G,shapeFlag:D}=E;if(D&6){V(E.component.subTree,F,g,W);return}if(D&128){E.suspense.move(F,g,W);return}if(D&64){I.move(E,F,g,X);return}if(I===Xe){s(M,F,g);for(let Z=0;Z<G.length;Z++)V(G[Z],F,g,W);s(E.anchor,F,g);return}if(I===fn){w(E,F,g);return}if(W!==2&&D&1&&R)if(W===0)R.persisted&&!M[ro]?s(M,F,g):(R.beforeEnter(M),s(M,F,g),_t(()=>R.enter(M),j));else{const{leave:Z,delayLeave:te,afterLeave:se}=R,me=()=>{E.ctx.isUnmounted?n(M):s(M,F,g)},$e=()=>{const xe=M._isLeaving||!!M[ro];M._isLeaving&&M[ro](!0),R.persisted&&!xe?me():Z(M,()=>{me(),se&&se()})};te?te(M,me,$e):$e()}else s(M,F,g)},Y=(E,F,g,W=!1,j=!1)=>{const{type:M,props:I,ref:R,children:G,dynamicChildren:D,shapeFlag:H,patchFlag:Z,dirs:te,cacheIndex:se,memo:me}=E;if(Z===-2&&(j=!1),R!=null&&(mi(),Bs(R,null,g,E,!0),gi()),se!=null&&(F.renderCache[se]=void 0),H&256){F.ctx.deactivate(E);return}const $e=H&1&&te,xe=!ls(E);let De;if(xe&&(De=I&&I.onVnodeBeforeUnmount)&&Wt(De,F,E),H&6)re(E.component,g,W);else{if(H&128){E.suspense.unmount(g,W);return}$e&&Li(E,null,F,"beforeUnmount"),H&64?E.type.remove(E,F,g,X,W):D&&!D.hasOnce&&(M!==Xe||Z>0&&Z&64)?Se(D,F,g,!1,!0):(M===Xe&&Z&384||!j&&H&16)&&Se(G,F,g),W&&ce(E)}const je=me!=null&&se==null;(xe&&(De=I&&I.onVnodeUnmounted)||$e||je)&&_t(()=>{De&&Wt(De,F,E),$e&&Li(E,null,F,"unmounted"),je&&(E.el=null)},g)},ce=E=>{const{type:F,el:g,anchor:W,transition:j}=E;if(F===Xe){ie(g,W);return}if(F===fn){S(E);return}const M=()=>{n(g),j&&!j.persisted&&j.afterLeave&&j.afterLeave()};if(E.shapeFlag&1&&j&&!j.persisted){const{leave:I,delayLeave:R}=j,G=()=>I(g,M);R?R(E.el,M,G):G()}else M()},ie=(E,F)=>{let g;for(;E!==F;)g=d(E),n(E),E=g;n(F)},re=(E,F,g)=>{const{bum:W,scope:j,job:M,subTree:I,um:R,m:G,a:D}=E;Ur(G),Ur(D),W&&un(W),j.stop(),M&&(M.flags|=8,Y(I,E,F,g)),R&&_t(R,F),_t(()=>{E.isUnmounted=!0},F)},Se=(E,F,g,W=!1,j=!1,M=0)=>{for(let I=M;I<E.length;I++)Y(E[I],F,g,W,j)},Ie=E=>{if(E.shapeFlag&6)return Ie(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const F=d(E.anchor||E.el),g=F&&F[vu];return g?d(g):F};let _e=!1;const fe=(E,F,g)=>{let W;E==null?F._vnode&&(Y(F._vnode,null,null,!0),W=F._vnode.component):m(F._vnode||null,E,F,null,null,null,g),F._vnode=E,_e||(_e=!0,Dr(W),nl(),_e=!1)},X={p:m,um:Y,m:V,r:ce,mt:x,mc:L,pc:T,pbc:N,n:Ie,o:e};return{render:fe,hydrate:void 0,createApp:Hu(fe)}}function lo({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Pi({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function sf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Il(e,t,i=!1){const s=e.children,n=t.children;if(Ee(s)&&Ee(n))for(let o=0;o<s.length;o++){const a=s[o];let r=n[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[o]=oi(n[o]),r.el=a.el),!i&&r.patchFlag!==-2&&Il(a,r)),r.type===qn&&(r.patchFlag===-1&&(r=n[o]=oi(r)),r.el=a.el),r.type===bi&&!r.el&&(r.el=a.el)}}function nf(e){const t=e.slice(),i=[0];let s,n,o,a,r;const l=e.length;for(s=0;s<l;s++){const c=e[s];if(c!==0){if(n=i[i.length-1],e[n]<c){t[s]=n,i.push(s);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[s]=i[o-1]),i[o]=s)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function Ml(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Ml(t)}function Ur(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Tl(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Tl(t.subTree):null}const El=e=>e.__isSuspense;function of(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):fu(e)}const Xe=Symbol.for("v-fgt"),qn=Symbol.for("v-txt"),bi=Symbol.for("v-cmt"),fn=Symbol.for("v-stc"),fi=[];let Bt=null;function J(e=!1){fi.push(Bt=e?null:[])}function dr(){fi.pop(),Bt=fi[fi.length-1]||null}let Vs=1;function Vr(e,t=!1){Vs+=e,e<0&&Bt&&t&&(Bt.hasOnce=!0)}function Al(e){return e.dynamicChildren=Vs>0?Bt||os:null,dr(),Vs>0&&Bt&&Bt.push(e),e}function ee(e,t,i,s,n,o){return Al(h(e,t,i,s,n,o,!0))}function Jt(e,t,i,s,n){return Al(oe(e,t,i,s,n,!0))}function ur(e){return e?e.__v_isVNode===!0:!1}function Ss(e,t){return e.type===t.type&&e.key===t.key}const Bl=({key:e})=>e??null,pn=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?st(e)||tt(e)||Be(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function h(e,t=null,i=null,s=0,n=null,o=e===Xe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Bl(t),ref:t&&pn(t),scopeId:rl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:dt};return r?(Bn(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=st(i)?8:16),Vs>0&&!a&&Bt&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Bt.push(l),l}const oe=rf;function rf(e,t=null,i=null,s=0,n=null,o=!1){if((!e||e===Au)&&(e=bi),ur(e)){const r=fs(e,t,!0);return i&&Bn(r,i),Vs>0&&!o&&Bt&&(r.shapeFlag&6?Bt[Bt.indexOf(e)]=r:Bt.push(r)),r.patchFlag=-2,r}if(bf(e)&&(e=e.__vccOpts),t){t=af(t);let{class:r,style:l}=t;r&&!st(r)&&(t.class=Ce(r)),Ye(l)&&(nr(l)&&!Ee(l)&&(l=ut({},l)),t.style=Yt(l))}const a=st(e)?1:El(e)?128:bu(e)?64:Ye(e)?4:Be(e)?2:0;return h(e,t,i,s,n,a,o,!0)}function af(e){return e?nr(e)||wl(e)?ut({},e):e:null}function fs(e,t,i=!1,s=!1){const{props:n,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?lf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Bl(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(pn(t)):[o,pn(t)]:pn(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Xe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&fs(e.ssContent),ssFallback:e.ssFallback&&fs(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&s&&rr(u,l.clone(u)),u}function It(e=" ",t=0){return oe(qn,null,e,t)}function ht(e,t){const i=oe(fn,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(J(),Jt(bi,null,e)):oe(bi,null,e)}function Kt(e){return e==null||typeof e=="boolean"?oe(bi):Ee(e)?oe(Xe,null,e.slice()):ur(e)?oi(e):oe(qn,null,String(e))}function oi(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:fs(e)}function Bn(e,t){let i=0;const{shapeFlag:s}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(s&65){const n=t.default;n&&(n._c&&(n._d=!1),Bn(e,n()),n._c&&(n._d=!0));return}else{i=32;const n=t._;!n&&!wl(t)?t._ctx=dt:n===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(s&65){Bn(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),s&64?(i=16,t=[It(t)]):i=8;e.children=t,e.shapeFlag|=i}function lf(...e){const t={};for(let i=0;i<e.length;i++){const s=e[i];for(const n in s)if(n==="class")t.class!==s.class&&(t.class=Ce([t.class,s.class]));else if(n==="style")t.style=Yt([t.style,s.style]);else if(On(n)){const o=t[n],a=s[n];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[n]=o?[].concat(o,a):a:a==null&&o==null&&!Rn(n)&&(t[n]=a)}else n!==""&&(t[n]=s[n])}return t}function Wt(e,t,i,s=null){jt(e,t,7,[i,s])}const cf=gl();let df=0;function uf(e,t,i){const s=e.type,n=(t?t.appContext:e.appContext)||cf,o={uid:df++,vnode:e,type:s,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Od(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Sl(s,n),emitsOptions:vl(s,n),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:s.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=ju.bind(null,o),e.ce&&e.ce(o),o}let yt=null;const ff=()=>yt||dt;let Dn,Po;{const e=Fn(),t=(i,s)=>{let n;return(n=e[i])||(n=e[i]=[]),n.push(s),o=>{n.length>1?n.forEach(a=>a(o)):n[0](o)}};Dn=t("__VUE_INSTANCE_SETTERS__",i=>yt=i),Po=t("__VUE_SSR_SETTERS__",i=>Gs=i)}const Js=e=>{const t=yt;return Dn(e),e.scope.on(),()=>{e.scope.off(),Dn(t)}},Gr=()=>{yt&&yt.scope.off(),Dn(null)};function Dl(e){return e.vnode.shapeFlag&4}let Gs=!1;function pf(e,t=!1,i=!1){t&&Po(t);const{props:s,children:n}=e.vnode,o=Dl(e);qu(e,s,o,t),Xu(e,n,i||t);const a=o?hf(e,t):void 0;return t&&Po(!1),a}function hf(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Du);const{setup:s}=i;if(s){mi();const n=e.setupContext=s.length>1?gf(e):null,o=Js(e),a=Zs(s,e,0,[e.props,n]),r=La(a);if(gi(),o(),(r||e.sp)&&!ls(e)&&dl(e),r){if(a.then(Gr,Gr),t)return a.then(l=>{Kr(e,l)}).catch(l=>{Un(l,e,0)});e.asyncDep=a}else Kr(e,a)}else Ll(e)}function Kr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ye(t)&&(e.setupState=tl(t)),Ll(e)}function Ll(e,t,i){const s=e.type;e.render||(e.render=s.render||Qt);{const n=Js(e);mi();try{Lu(e)}finally{gi(),n()}}}const mf={get(e,t){return mt(e,"get",""),e[t]}};function gf(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,mf),slots:e.slots,emit:e.emit,expose:t}}function Yn(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(tl(iu(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Ds)return Ds[i](e)},has(t,i){return i in t||i in Ds}})):e.proxy}function vf(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function bf(e){return Be(e)&&"__vccOpts"in e}const ye=(e,t)=>au(e,t,Gs),yf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Oo;const qr=typeof window<"u"&&window.trustedTypes;if(qr)try{Oo=qr.createPolicy("vue",{createHTML:e=>e})}catch{}const Pl=Oo?e=>Oo.createHTML(e):e=>e,kf="http://www.w3.org/2000/svg",wf="http://www.w3.org/1998/Math/MathML",ni=typeof document<"u"?document:null,Yr=ni&&ni.createElement("template"),xf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,s)=>{const n=t==="svg"?ni.createElementNS(kf,e):t==="mathml"?ni.createElementNS(wf,e):i?ni.createElement(e,{is:i}):ni.createElement(e);return e==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:e=>ni.createTextNode(e),createComment:e=>ni.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ni.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,s,n,o){const a=i?i.previousSibling:t.lastChild;if(n&&(n===o||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),i),!(n===o||!(n=n.nextSibling)););else{Yr.innerHTML=Pl(s==="svg"?`<svg>${e}</svg>`:s==="mathml"?`<math>${e}</math>`:e);const r=Yr.content;if(s==="svg"||s==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Sf=Symbol("_vtc");function Cf(e,t,i){const s=e[Sf];s&&(t=(t?[t,...s]:[...s]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ln=Symbol("_vod"),Ol=Symbol("_vsh"),Ro={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ln]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):Cs(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:s}){!t!=!i&&(s?t?(s.beforeEnter(e),Cs(e,!0),s.enter(e)):s.leave(e,()=>{Cs(e,!1)}):Cs(e,t))},beforeUnmount(e,{value:t}){Cs(e,t)}};function Cs(e,t){e.style.display=t?e[Ln]:"none",e[Ol]=!t}const _f=Symbol(""),$f=/(?:^|;)\s*display\s*:/;function If(e,t,i){const s=e.style,n=st(i);let o=!1;if(i&&!n){if(t)if(st(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&$s(s,r,"")}else for(const a in t)i[a]==null&&$s(s,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?Tf(e,a,!st(t)&&t?t[a]:void 0,r)||$s(s,a,r):$s(s,a,"")}}else if(n){if(t!==i){const a=s[_f];a&&(i+=";"+a),s.cssText=i,o=$f.test(i)}}else t&&e.removeAttribute("style");Ln in e&&(e[Ln]=o?s.display:"",e[Ol]&&(s.display="none"))}const Zr=/\s*!important$/;function $s(e,t,i){if(Ee(i))i.forEach(s=>$s(e,t,s));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const s=Mf(e,t);Zr.test(i)?e.setProperty(Bi(s),i.replace(Zr,""),"important"):e[s]=i}}const Jr=["Webkit","Moz","ms"],co={};function Mf(e,t){const i=co[t];if(i)return i;let s=Ct(t);if(s!=="filter"&&s in e)return co[t]=s;s=zn(s);for(let n=0;n<Jr.length;n++){const o=Jr[n]+s;if(o in e)return co[t]=o}return t}function Tf(e,t,i,s){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&st(s)&&i===s}const Xr="http://www.w3.org/1999/xlink";function Qr(e,t,i,s,n,o=Ld(t)){s&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Xr,t.slice(6,t.length)):e.setAttributeNS(Xr,t,i):i==null||o&&!Na(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Ht(i)?String(i):i)}function ea(e,t,i,s,n){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Pl(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Na(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(n||t)}function _i(e,t,i,s){e.addEventListener(t,i,s)}function Ef(e,t,i,s){e.removeEventListener(t,i,s)}const ta=Symbol("_vei");function Af(e,t,i,s,n=null){const o=e[ta]||(e[ta]={}),a=o[t];if(s&&a)a.value=s;else{const[r,l]=Lf(t);if(s){const c=o[t]=Rf(s,n);_i(e,r,c,l)}else a&&(Ef(e,r,a,l),o[t]=void 0)}}const Bf=/(Once|Passive|Capture)$/,Df=/^on:?(?:Once|Passive|Capture)$/;function Lf(e){let t,i;for(;(i=e.match(Bf))&&!Df.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Bi(e.slice(2)),t]}let uo=0;const Pf=Promise.resolve(),Of=()=>uo||(Pf.then(()=>uo=0),uo=Date.now());function Rf(e,t){const i=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=i.attached)return;const n=i.value;if(Ee(n)){const o=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{o.call(s),s._stopped=!0};const a=n.slice(),r=[s];for(let l=0;l<a.length&&!s._stopped;l++){const c=a[l];c&&jt(c,t,5,r)}}else jt(n,t,5,[s])};return i.value=e,i.attached=Of(),i}const ia=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Nf=(e,t,i,s,n,o)=>{const a=n==="svg";t==="class"?Cf(e,s,a):t==="style"?If(e,i,s):On(t)?Rn(t)||Af(e,t,i,s,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):zf(e,t,s,a))?(ea(e,t,s),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Qr(e,t,s,a,o,t!=="value")):e._isVueCE&&(Hf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!st(s)))?ea(e,Ct(t),s,o,t):(t==="true-value"?e._trueValue=s:t==="false-value"&&(e._falseValue=s),Qr(e,t,s,a))};function zf(e,t,i,s){if(s)return!!(t==="innerHTML"||t==="textContent"||t in e&&ia(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return ia(t)&&st(i)?!1:t in e}function Hf(e,t){const i=e._def.props;if(!i)return!1;const s=Ct(t);return Array.isArray(i)?i.some(n=>Ct(n)===s):Object.keys(i).some(n=>Ct(n)===s)}const ps=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>un(t,i):t};function Ff(e){e.target.composing=!0}function sa(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const pi=Symbol("_assign");function na(e,t,i){return t&&(e=e.trim()),i&&(e=Hn(e)),e}const No={created(e,{modifiers:{lazy:t,trim:i,number:s}},n){e[pi]=ps(n);const o=s||n.props&&n.props.type==="number";_i(e,t?"change":"input",a=>{a.target.composing||e[pi](na(e.value,i,o))}),(i||o)&&_i(e,"change",()=>{e.value=na(e.value,i,o)}),t||(_i(e,"compositionstart",Ff),_i(e,"compositionend",sa),_i(e,"change",sa))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:s,trim:n,number:o}},a){if(e[pi]=ps(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Hn(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(s&&t===i||n&&e.value.trim()===l)||(e.value=l)}},an={deep:!0,created(e,t,i){e[pi]=ps(i),_i(e,"change",()=>{const s=e._modelValue,n=Ks(e),o=e.checked,a=e[pi];if(Ee(s)){const r=Jo(s,n),l=r!==-1;if(o&&!l)a(s.concat(n));else if(!o&&l){const c=[...s];c.splice(r,1),a(c)}}else if(ms(s)){const r=new Set(s);o?r.add(n):r.delete(n),a(r)}else a(Rl(e,o))})},mounted:oa,beforeUpdate(e,t,i){e[pi]=ps(i),oa(e,t,i)}};function oa(e,{value:t,oldValue:i},s){e._modelValue=t;let n;if(Ee(t))n=Jo(t,s.props.value)>-1;else if(ms(t))n=t.has(s.props.value);else{if(t===i)return;n=gs(t,Rl(e,!0))}e.checked!==n&&(e.checked=n)}const jf={deep:!0,created(e,{value:t,modifiers:{number:i}},s){e._modelValue=t,_i(e,"change",()=>{const n=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Hn(Ks(o)):Ks(o));e[pi](e.multiple?ms(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Mn(()=>{e._assigning=!1})}),e[pi]=ps(s)},mounted(e,{value:t}){ra(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[pi]=ps(i)},updated(e,{value:t}){e._assigning||ra(e,t)}};function ra(e,t){const i=e.multiple,s=Ee(t);if(!(i&&!s&&!ms(t))){for(let n=0,o=e.options.length;n<o;n++){const a=e.options[n],r=Ks(a);if(i)if(s){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Jo(t,r)>-1}else a.selected=t.has(r);else if(gs(Ks(a),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Ks(e){return"_value"in e?e._value:e.value}function Rl(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Wf=["ctrl","shift","alt","meta"],Uf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Wf.some(i=>e[`${i}Key`]&&!t.includes(i))},Zt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),s=t.join(".");return i[s]||(i[s]=((n,...o)=>{for(let a=0;a<t.length;a++){const r=Uf[t[a]];if(r&&r(n,t))return}return e(n,...o)}))},Vf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Gf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),s=t.join(".");return i[s]||(i[s]=(n=>{if(!("key"in n))return;const o=Bi(n.key);if(t.some(a=>a===o||Vf[a]===o))return e(n)}))},Kf=ut({patchProp:Nf},xf);let aa;function qf(){return aa||(aa=ef(Kf))}const fr=((...e)=>{const t=qf().createApp(...e),{mount:i}=t;return t.mount=s=>{const n=Zf(s);if(!n)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const a=i(n,!1,Yf(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),a},t});function Yf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Zf(e){return st(e)?document.querySelector(e):e}const Jf="slides-config.json",Ti={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Vt=Wn({...Ti});function Xf(e){if(!e||typeof e!="object")return{...Ti};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Ti.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Ti.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Ti.showOrderedListMarkers}}function ri(e){if(!e||typeof e!="object")return{...Vt};const t=e;return t.enableWebServeJump!==void 0&&(Vt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Vt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Vt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Vt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Vt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Vt}}function Zn(){return{...Vt}}function Nl(e,t,i){const s=(e||Ti.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(n);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Oi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Qf(e){var n,o,a,r,l,c,u,f;const t=Zn();if(!e)return{...Oi,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[Ir]!==void 0?e[Ir]!=="false":t.showUnorderedListMarkers,s=e[Mr]!==void 0?e[Mr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Ns])==null?void 0:n.trim())||Oi.theme,aspectRatio:((o=e[zs])==null?void 0:o.trim())||Oi.aspectRatio,highlighter:((a=e[Ma])==null?void 0:a.trim())||Oi.highlighter,defaultTransition:((r=e[Hs])==null?void 0:r.trim())||Oi.defaultTransition,colorSchema:((l=e[Ta])==null?void 0:l.trim())||Oi.colorSchema,spacing:((c=e[_o])==null?void 0:c.trim())||Oi.spacing,background:((u=e[wn])==null?void 0:u.trim())||((f=e["slides-background"])==null?void 0:f.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:s}}function ui(e){var i,s,n,o,a;const t=(i=e.ial)==null?void 0:i[li];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((s=e.markdown)==null?void 0:s.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function la(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[vt]&&(t.transition=e[vt].trim()),e[ot]&&(t.background=e[ot].trim()),e[Rt]&&(t.image=e[Rt].trim()),e[es]&&(t.class=e[es].trim()),e[Ms]&&(t.spacing=e[Ms].trim()),e[bt]&&(t.layoutRatio=e[bt].trim()),e[ts]&&(t.mask=e[ts].trim()),e[ji]&&(t.maskRatio=e[ji].trim()),e[is]&&(t.maskStyle=e[is].trim()),e[ss]&&(t.maskInitial=e[ss].trim()),e[eo]&&(i=e[eo].trim());for(const[s,n]of Object.entries(e))if(s.startsWith("custom-slides-")&&![ke,bt,ts,ji,is,ss,vt,ot,Rt,es,Ms,eo,li].includes(s)){const o=s.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(n)}catch{t[o]=n}}return{frontmatter:t,notes:i}}function ca(e){const t={};if(!e)return t;const i=e[qe]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const s=e[Ze]??e["slides-role"],n=e[ot]??e["slides-background"];(s===Ea||n==="true"||n==="1")&&(t.isBackground=!0);const o=e[ke]??e["slides-layout"];o===Cn||o===_n?t.imageLayout=o:(s===Cn||s===_n)&&(t.imageLayout=s);const a=e[Ne]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Xt])try{const r=JSON.parse(e[Xt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Xt].trim()}}return e[Ki]&&(t.shikiLines=e[Ki].trim()),e[Fs]&&(t.maxHeight=e[Fs].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function hi(e,t){const i=(e||t||"").trim();if(!i)return null;const s=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Ls(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],s=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return e;const n=s[1].length,o=s[2].trim(),a=i.length-s[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=a?r.push(c.slice(a)):f>n?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function Ai(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function fo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const n=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(n.length>=2)return n.map(o=>`${o}fr`).join(" ")}const s=i.split(/\s+/).filter(Boolean);return s.length>=2?s.join(" "):`repeat(${t}, 1fr)`}function Ps(e){if(!e)return[];if(at(e)&&ei(e)&&!ti(e)){const s=bs(e),n=[];for(const o of s)n.push(...Ps(o));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Ai);if(a.length>0)return a}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<n.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(n[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:n.length,u=n.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Ai(e)?[e]:[]}function pr(e){var n;if(!e||!at(e)||!ei(e)||ti(e))return null;const t=bs(e);if(t.length===0)return null;if(t.length===1&&at(t[0])&&ei(t[0])){const o=pr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(at(o)){i.push(o);const a=((n=o.children)==null?void 0:n.filter(at))||[];i.push(...a)}const s=t.map(Ps);if(s.length>=2&&s.every(o=>o.length>0)){const o=s.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Ps(t[0]),a=Ps(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function ep(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=pr(e);if(!t)return null;const{items:i,nestedSuperBlocks:s}=t;if(i.length<2||i.length>6)return null;const n=hr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:s,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:n}}function zl(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=bs(e);if(t.length===0)return null;const i=[];for(const s of t){const n=Ps(s);if(n.length===0)return null;i.push(...n)}return i}function tp(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=zl(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function ip(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=pr(e);if(t&&t.items.length===4)return t.items;const i=zl(e);if(i&&i.length===4)return i;const s=bs(e);return s.length===4?s:null}function sp(e,t){if(!e||e.length===0)return null;const i=[];function s(r,l){if(at(r)){const c=ip(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)s(c,l)}for(let r=0;r<e.length;r++)s(e[r],r);if(i.length===0)return null;let n=null;t&&(n=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),n||(n=i[0]);const a=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>Hl(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:a}}function np(e,t,i){var u,f,d,p,k;const s=[],n=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(ui(b)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},a.push(r)}else r.blocks.push(b)}function l(m){const b=[];for(const y of m)at(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...l(y.children));return b}function c(m,b,y){const v={blockId:m,attrs:b,previousAttrs:y};s.push(v),i!=null&&i.onTagChange&&i.onTagChange(v)}for(const m of a){const b=m.pageTargetId,y=t.find(A=>A.id===b),v=o.find(A=>A.pageTargetId===b);if(m.blocks.some(A=>{var C,L;return!!(ti(A)||zo(A)&&(((C=A.ial)==null?void 0:C[ke])==="image-left"||((L=A.ial)==null?void 0:L[ke])==="image-right"))})){if(v){const A=v.headerId;if(A){c(A,{[Me]:""});const C=t.find(L=>L.id===A);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of v.itemIds){c(C,{[Me]:""});const L=t.find(z=>z.id===C);L!=null&&L.ial&&(L.ial[Me]="")}}continue}let S=null,B=-1;for(let A=0;A<m.blocks.length;A++){const C=m.blocks[A],L=at(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const z of L){const N=ep(z);if(N){S=N,B=A;break}}if(S)break}if(S){const{superBlockNode:A,layout:C,items:L,slots:z}=S,K=m.blocks.slice(0,B).find($=>Hl($)),_=K==null?void 0:K.id,U=((u=y==null?void 0:y.ial)==null?void 0:u[ke])||"",x=U==="clover",q=x?"clover":C;if(U!==q&&(c(b,{[ke]:q},{[ke]:U}),y&&(y.ial||(y.ial={}),y.ial[ke]=q)),K){const $=((f=K.ial)==null?void 0:f[Me])||"";$!=="header"&&(c(K.id,{[Me]:"header"},{[Me]:$}),K.ial||(K.ial={}),K.ial[Me]="header")}if(v!=null&&v.headerId&&v.headerId!==_){c(v.headerId,{[Me]:""});const $=t.find(T=>T.id===v.headerId);$&&($.ial||($.ial={}),$.ial[Me]="")}const O=[];for(let $=0;$<L.length;$++){const T=L[$],P=z[$];O.push(T.id);const ne=((d=T.ial)==null?void 0:d[Me])||"";if(ne!==P&&(c(T.id,{[Me]:P},{[Me]:ne}),T.ial||(T.ial={}),T.ial[Me]=P),T.children&&T.children.length>0)for(const V of T.children)V.ial||(V.ial={}),V.ial[Me]!==P&&(V.ial[Me]=P)}if(v!=null&&v.itemIds){for(const $ of v.itemIds)if(!O.includes($)){c($,{[Me]:""});const T=t.find(P=>P.id===$);T&&(T.ial||(T.ial={}),T.ial[Me]="")}}n.push({superBlockId:A.id,nestedSuperBlockIds:(p=S.nestedSuperBlocks)==null?void 0:p.map($=>$.id),pageTargetId:b,headerId:_,itemIds:O,layout:x?"clover":C})}else{let A=!1;const C=[];for(const N of m.blocks){const K=at(N)?[N,...l(N.children||[])]:N.children?l(N.children):[];for(const _ of K){const U=tp(_);if(U){A=!0;for(const x of U.items)C.push(x.id)}}}const L=((k=y==null?void 0:y.ial)==null?void 0:k[ke])||"",z=ns(L);if(v||A&&z){c(b,{[ke]:""},{[ke]:L}),y&&(y.ial||(y.ial={}),y.ial[ke]="");const N=v==null?void 0:v.headerId;if(N){c(N,{[Me]:""});const _=t.find(U=>U.id===N);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const K=new Set([...(v==null?void 0:v.itemIds)||[],...C]);for(const _ of K){c(_,{[Me]:""});const U=t.find(x=>x.id===_);U&&(U.ial||(U.ial={}),U.ial[Me]="")}}}}return{changes:s,newTracked:n}}function at(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function ei(e){if(!at(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const s=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(e.children&&e.children.length>0){for(const s of e.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function zo(e){return!e||Ai(e)||at(e)||!hi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function hr(e){var d;if(!e||!at(e)||!ei(e))return null;const t=bs(e);if(!t||t.length<2)return null;const i=[];let s=!1;for(const p of t){const k=(((d=p.ial)==null?void 0:d.style)||p.style||"").trim();let m=null;if(k){const b=k.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=k.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),s=!0):i.push(null)}if(!s)return null;const n=t.length,o=i.reduce((p,k)=>p+(k||0),0),a=i.filter(p=>p===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/n,c=i.map(p=>p!==null?p:l),u=c.reduce((p,k)=>p+k,0);if(u<=0)return null;const f=c.map(p=>p/u*100);if(f.length===2){const[p]=f;if(p>=48&&p<=52)return"1:1";if(p>=31&&p<=35)return"1:2";if(p>=65&&p<=69)return"2:1";if(p>=28&&p<=32)return"3:7";if(p>=68&&p<=72)return"7:3";if(p>=38&&p<=42)return"4:6";if(p>=58&&p<=62)return"6:4";if(p>=23&&p<=27)return"1:3";if(p>=73&&p<=77)return"3:1";const k=Math.round(p),m=100-k;return`${k}:${m}`}if(f.length===3){const[p,k,m]=f;if(p>=31&&p<=35&&k>=31&&k<=35&&m>=31&&m<=35)return"1:1:1";if(p>=23&&p<=27&&k>=48&&k<=52&&m>=23&&m<=27)return"1:2:1";if(p>=48&&p<=52&&k>=23&&k<=27&&m>=23&&m<=27)return"2:1:1";if(p>=23&&p<=27&&k>=23&&k<=27&&m>=48&&m<=52)return"1:1:2";if(p>=18&&p<=22&&k>=58&&k<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(p),y=Math.round(k),v=100-b-y;return`${b}:${y}:${v}`}return f.map(p=>Math.round(p)).join(":")}function ti(e){if(!e||!at(e)||!ei(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=zo(t[0]),s=zo(t[t.length-1]),n=hr(e)||void 0;if(i&&!s){const o=hi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Cn,contentNodes:t.slice(1),ratio:n}}if(!i&&s){const o=hi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:_n,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function op(e,t){const i=[];function s(n){for(const o of n){const a=ti(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[ke];if(u!==l){const d={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[ke]=l,i.push(d),t&&t(d)}}o.children&&o.children.length>0&&s(o.children)}}return s(e),i}function bs(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const s=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function Hl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ri(e,t,i){let s="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const y=a[1].match(/\bclass=["']([^"']*)["']/i);if(y){const v=y[1];if(typeof t=="string"?v.split(/\s+/).includes(t):t.test(v)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){s+=e.slice(n);break}s+=e.slice(n,l);const u=l+c;let f=1,d=-1,p=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=u;let m;for(;(m=k.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){d=m.index,p=m.index+m[0].length;break}}else f++;if(d!==-1&&p!==-1){const b=e.slice(u,d);s+=i(b),n=p}else s+=e.slice(l,u),n=u}return s}function rp(e){const t=[];let i="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<e.length;){n.lastIndex=s;let o,a=!1,r=-1,l=0;for(;(o=n.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(s);break}i+=e.slice(s,r);const c=r+l;let u=1,f=-1,d=-1;const p=/<\/?div\b[^>]*>/gi;p.lastIndex=c;let k;for(;(k=p.exec(e))!==null;)if(k[0].startsWith("</")){if(u--,u===0){f=k.index,d=k.index+k[0].length;break}}else u++;if(f!==-1&&d!==-1){const m=e.slice(r,d),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,s=d}else i+=e.slice(r,c),s=c}return{text:i,tokens:t}}function ap(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const s=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${s.length}__`;return s.push(r),l});const{text:n,tokens:o}=rp(i);i=n;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ri(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=Ri(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=Ri(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ri(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const d=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${d}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ri(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ri(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ri(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((f,d)=>Math.max(f,d.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,f)=>{const d=f.trim();return d.includes("<")||d.includes(`
`)?r:`[${d}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<s.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Fl(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,s=>(t.push(s),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>t[parseInt(n,10)]||""),i}function lp(e){const t=Object.entries(e).filter(([s,n])=>n!=null&&n!=="");return t.length===0?"":`---
${t.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function cp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const s=e.slice(0,i).trim(),n=e.slice(i);return s.includes("{")?e:`${s} {${t}}${n}`}function jl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function dp(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},s={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},s={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(s={...s,...e.enter});const n={...s.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(n.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(n.delay=e.delay),Object.keys(n).length>0&&(s.transition=n),{initial:i,enter:s}}function Pn(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function ln(e,t,i,s,n){const o=t!=null&&t.trim()!=="",a=dp(i),r=Pn(n),l=r?`max-height:${r};overflow-y:auto`:"",c=[s==null?void 0:s.trim(),l].filter(Boolean).join(";"),u=c!==void 0&&c!=="",f=u?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return u?`<div${f}>

${e}

</div>`:e;if(o&&!a){if(u){const y=t.trim();let v="v-click";return y==="hide"?v="v-click.hide":y!==""&&y!=="+1"&&(v=`v-click="${y}"`),`<div ${v}${f}>

${e}

</div>`}return jl(e,t)}const d=JSON.stringify(a.initial).replace(/"/g,"'"),p=JSON.stringify(a.enter).replace(/"/g,"'"),k=`v-motion :initial="${d}" :enter="${p}"`;if(!o)return`<div ${k}${f}>

${e}

</div>`;const m=t.trim();let b="v-click";return m==="hide"?b="v-click.hide":m!==""&&m!=="+1"&&(b=`v-click="${m}"`),`<div ${b} ${k}${f}>

${e}

</div>`}function mr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function up(e){var s;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(s=e.ial)!=null&&s.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Wl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),f=Math.min(i,c.length),d=Math.floor(c.length/f),p=c.length%f;let k=0;for(let m=0;m<f;m++){const b=d+(m<p?1:0);u[m]=c.slice(k,k+b),k+=b}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),d=f?parseInt(f[1],10):null,p=(c.rawMarkdown||c.content||"").trim(),k=p.split(/\r?\n/),m=[];for(let v=0;v<k.length;v++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(k[v])&&m.push(v);if(m.length>=i){const v=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const B=i-S,A=m.length-w,C=Math.ceil(A/B),L=m[w],z=w+C<m.length?m[w+C]:k.length,N=k.slice(L,z).join(`
`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:N,content:N}],w+=C}return v}const b=p.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const v=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const B=i-S,A=b.length-w,C=Math.ceil(A/B),L=`<ul>
${b.slice(w,w+C).join(`
`)}
</ul>`;v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],w+=C}return v}const y=p.split(/\r?\n\s*\r?\n/).filter(v=>v.trim()!=="");if(y.length>=i){const v=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const B=i-S,A=y.length-w,C=Math.ceil(A/B),L=y.slice(w,w+C).join(`

`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],w+=C}return v}if(d&&d>=1&&d<=i){const v=Array.from({length:i},()=>[]);return v[d-1]=[c],v}return[[c],...Array.from({length:i-1},()=>[])]}const s=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const f=u.match(/^col-(\d+)$/i);if(f){const d=parseInt(f[1],10);if(d>=1&&d<=i)return d}return null},n=e.map(s);if(n.some(c=>c!==null)){if(n.some(p=>p!==null&&p>=2)){const p=Array.from({length:i},()=>[]);let k=1;for(const b of e){const y=s(b);y!==null&&(k=y),p[k-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&p[0].length===0){const b=p.filter(y=>y.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return p}const u=e.filter(p=>s(p)===1),f=e.filter(p=>s(p)===null),d=i-1;if(f.length>=d){const p=Math.floor(f.length/d),k=f.length%d,m=[u];let b=0;for(let y=0;y<d;y++){const v=p+(y<k?1:0);m.push(f.slice(b,b+v)),b+=v}return m}else if(f.length>0){const p=[u];for(let k=0;k<d;k++)p.push(k<f.length?[f[k]]:[]);return p}else return[u,...Array.from({length:d},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const f=r[u],d=u+1<i?r[u+1]:e.length;c[u]=e.slice(f,d)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let f=0;f<i;f++){const d=i-f,p=e.length-u,k=Math.ceil(p/d);c[f]=e.slice(u,u+k),u+=k}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function da(e,t,i,s){var k;const n=Qf(t),o=[],a=la(t),r=n.background?$t(n.background,s):void 0;let l={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,s));const c=m=>{const b=[];for(let y=m;y<i.length&&!(y>m&&ui(i[y]));y++)b.push(i[y]);return b},u=m=>{let b,y,v;const w=S=>{var z;if(b)return;const B=ti(S);if(B){b=B.layout,y=B.imageUrl,v=B.ratio;return}const A=$r(S),C=S.ial?{...S.ial}:{},L=ca(C);if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const N=hi(A,S.content);if(N){b=L.imageLayout,y=N,v=(z=S.ial)==null?void 0:z[bt];return}}if(S.children&&S.children.length>0){for(const N of S.children)if(w(N),b)return}};for(const S of m)if(w(S),b)break;return{foundLayout:b,foundImage:y,foundRatio:v}},f=(m,b)=>{const{foundLayout:y,foundImage:v,foundRatio:w}=u(b);y&&(m.frontmatter.layout=y,v&&(m.frontmatter.image=$t(v,s)),w&&!m.frontmatter.layoutRatio&&(m.frontmatter.layoutRatio=w))};f(l,c(0)),o.push(l);let d=[];for(let m=0;m<i.length;m++){const b=i[m];if(ui(b)){d=[];const v=la(b.ial);if(o.length===1&&l.blocks.length===0){l.startBlockId=b.id,l.allBlockIds||(l.allBlockIds=[]),l.allBlockIds.includes(b.id)||l.allBlockIds.push(b.id),v.frontmatter.layout&&(l.frontmatter.layout=v.frontmatter.layout),Object.assign(l.frontmatter,v.frontmatter),delete l.frontmatter.background,!v.frontmatter.image&&a.frontmatter.image&&(l.frontmatter.image=a.frontmatter.image),r&&(l.frontmatter.background=r),l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,s)),f(l,c(m+1));continue}l={pageIndex:o.length+1,startBlockId:b.id,frontmatter:{layout:v.frontmatter.layout||"default",...v.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete l.frontmatter.background,l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,s)),f(l,c(m+1)),o.push(l);continue}const y=(v,w)=>{var re,Se,Ie,_e,fe,X,pe;if(l.allBlockIds||(l.allBlockIds=[]),v.id&&!l.allBlockIds.includes(v.id)&&l.allBlockIds.push(v.id),v.children&&v.children.length>0){const E=F=>{for(const g of F)g.id&&!l.allBlockIds.includes(g.id)&&l.allBlockIds.push(g.id),g.children&&g.children.length>0&&E(g.children)};E(v.children)}let S=$r(v),B=v.ial?{...v.ial}:{};const A=S.match(/\{:\s*([^}]+)\s*\}\s*$/);A&&(B={...$a(A[0]),...B},S=S.slice(0,A.index).trim()),v.type!=="c"&&!S.startsWith("```")&&(S=Fl(S));let C=S.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(S=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=S.trim());const L=ca(B);if(S=Cd(S,s),S=xd(S,s==null?void 0:s.refContentMap),v.children&&v.children.length>0){const E=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],F=g=>{for(const W of g){if(W.ial)for(const[j,M]of Object.entries(W.ial))E.includes(j)&&!B[j]&&(B[j]=M);W.children&&W.children.length>0&&F(W.children)}};F(v.children)}const z=v.type==="video"||v.type==="NodeVideo"||/<video\b/i.test(S);if(z){const E=B["custom-slides-autoplay"]==="true",F=B["custom-slides-loop"]==="true",g=B["custom-slides-muted"]==="true"||E,W=B["custom-slides-controls"]==="false";S=S.replace(/<video\b([^>]*)>/gi,(j,M)=>{let I=M;return W?I=I.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(I)||(I+=" controls"),E&&!/autoplay/i.test(I)?I+=" autoplay playsinline":!E&&B["custom-slides-autoplay"]==="false"&&(I=I.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),F&&!/loop/i.test(I)?I+=" loop":!F&&B["custom-slides-loop"]==="false"&&(I=I.replace(/\bloop\b/gi,"").trim()),g&&!/muted/i.test(I)?I+=" muted":!g&&B["custom-slides-muted"]==="false"&&(I=I.replace(/\bmuted\b/gi,"").trim()),`<video ${I.trim()}>`})}if(L.isBackground){const E=hi(S,v.content);if(E){l.frontmatter.background=$t(E,s);return}}const N=ti(v);if(N){l.frontmatter.layout=N.layout,l.frontmatter.image=$t(N.imageUrl,s),!l.frontmatter.layoutRatio&&N.ratio&&(l.frontmatter.layoutRatio=N.ratio);for(const E of N.contentNodes)y(E);return}if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const E=hi(S,v.content);if(E){l.frontmatter.layout=L.imageLayout,l.frontmatter.image=$t(E,s),!l.frontmatter.layoutRatio&&((re=v.ial)!=null&&re[bt])&&(l.frontmatter.layoutRatio=v.ial[bt]);return}}if(at(v)&&v.children&&v.children.length>0){for(const E of v.children)y(E);return}const K=!!(L.slot||w!=null&&w.defaultSlot||l.frontmatter.layout==="clover"||ns(l.frontmatter.layout)||l.frontmatter.layout==="two-cols"),_=!!(v.children&&v.children.some(E=>{var F,g;return((F=E.ial)==null?void 0:F[Me])||((g=E.ial)==null?void 0:g[Ne])||E.children&&E.children.length>=2||E.children&&E.children.some(W=>{var j,M,I,R,G,D;return((j=W.ial)==null?void 0:j[Ne])||((M=W.ial)==null?void 0:M[Me])||((I=W.ial)==null?void 0:I[Ze])||((R=W.ial)==null?void 0:R[ke])||((G=W.ial)==null?void 0:G["custom-slides-role"])||((D=W.ial)==null?void 0:D["custom-slides-layout"])})}));if((v.type==="l"||v.type==="NodeList"||v.type==="list")&&v.children&&v.children.length>0&&(_||L.slot||L.clicks||K)){const E=/^\s*\d+\.\s+/m.test(v.markdown||"")||v.subType==="o"||v.subtype==="o";for(let F=0;F<v.children.length;F++){const g=v.children[F];L.slot&&(!g.ial||!g.ial[Me])&&(g.ial||(g.ial={}),g.ial[Me]=L.slot),y(g,{...w,parentClicks:L.clicks||(w==null?void 0:w.parentClicks),defaultSlot:L.slot||(w==null?void 0:w.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:E,itemIndex:F+1}})}return}const U=!!(w!=null&&w.isParentListUnpacked),x=!!(v.children&&v.children.length>=2)||!!L.clicks||!!((Se=v.children)!=null&&Se.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))||U||!v.markdown&&!!(v.children&&v.children.length>0);if(Ai(v)&&v.children&&v.children.length>0&&(K||U||L.clicks||v.children.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))&&x){const E=!!(v.children&&v.children.length>=2),F=v.children.find(G=>!!(G.markdown||G.content||"").trim())||v.children[0],g=((Ie=F==null?void 0:F.ial)==null?void 0:Ie[Ne])||((_e=F==null?void 0:F.ial)==null?void 0:_e["custom-slides-click"]),W=!!(!L.clicks&&E&&g),j=L.clicks||(W?g:void 0)||(w==null?void 0:w.parentClicks),M=v.id||(w==null?void 0:w.parentContainerId),I=L.slot||(w==null?void 0:w.defaultSlot);let R=!0;for(const G of v.children){I&&(!G.ial||!G.ial[Me])&&(G.ial||(G.ial={}),G.ial[Me]=I);const D=!!(G.markdown||G.content||"").trim(),H=R&&D;if(H){if(!(l.frontmatter.layout==="image-right"||l.frontmatter.layout==="image-left")&&!!(l.frontmatter.layout==="clover"||ns(l.frontmatter.layout)||l.frontmatter.layout==="two-cols")&&!!(w!=null&&w.defaultSlot||L.slot||(fe=v.ial)!=null&&fe[Me]))G.markdown&&(G.markdown=Ls(G.markdown)),G.content&&(G.content=Ls(G.content));else{const $e=!!((X=w==null?void 0:w.listContext)!=null&&X.isOrdered),xe=((pe=w==null?void 0:w.listContext)==null?void 0:pe.itemIndex)||1,De=$e?`${xe}. `:"- ",je=ze=>{if(!ze)return De.trim();const le=ze.trim();return/^[-*+]\s+/.test(le)||/^\d+\.\s+/.test(le)?ze:`${De}${ze}`};G.markdown&&(G.markdown=je(G.markdown)),G.content&&(G.content=je(G.content))}R=!1}let Z=G;H&&j&&E?(Z={...G,ial:{...G.ial||{}}},delete Z.ial[Ne],delete Z.ial["custom-slides-click"]):!E&&j&&(Z={...G,ial:{...G.ial||{},[Ne]:j}}),y(Z,{...w,parentClicks:j,parentContainerId:M,defaultSlot:I,isListItem:!0})}return}if(L.isNote){const E=mr(S);E&&(l.notes?l.notes+=`

`+E:l.notes=E),l.noteBlocks||(l.noteBlocks=[]),l.noteBlocks.push({id:v.id,type:v.type,content:E||v.content||"",rawMarkdown:S,isNote:!0,attributes:v.ial});return}L.shikiLines&&(S=cp(S,L.shikiLines)),C=S.trim();const q=(v.content||"").trim();if(C==="::right::"||q==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){l.blocks.push({id:v.id,type:v.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:v.ial});return}const $=up(v);let T=L.slot,P=L.clicks,ne=L.motion,V={...v.ial||{}};if($!==null){for(;d.length>0&&d[d.length-1].level>=$;)d.pop();const E=d.length>0?d[d.length-1]:void 0;!T&&(E!=null&&E.slot)&&(T=E.slot),!P&&(E!=null&&E.clicks)&&!(w!=null&&w.parentContainerId)&&(P=E.clicks),!ne&&(E!=null&&E.motion)&&(ne=E.motion);const F={...(E==null?void 0:E.customAttrs)||{}};if(v.ial)for(const[g,W]of Object.entries(v.ial))g.startsWith("custom-slides-")&&!g.startsWith("custom-slides-slide")&&(F[g]=W);w!=null&&w.parentContainerId||d.push({level:$,slot:T,clicks:P,motion:ne,customAttrs:F})}else{const E=d.length>0?d[d.length-1]:void 0;E&&(!T&&E.slot&&E.slot!=="header"&&(T=E.slot),!P&&E.clicks&&!(w!=null&&w.parentContainerId)&&(P=E.clicks),!ne&&E.motion&&(ne=E.motion),E.customAttrs&&(V={...E.customAttrs,...V}))}!T&&l.blocks.some(E=>E.slot==="slot-divider-right")&&(T="right"),!T&&(w!=null&&w.defaultSlot)&&(T=w.defaultSlot),T&&(V[Me]=T),P&&!V[Ne]&&(V[Ne]=P),ne&&!V[Xt]&&(V[Xt]=JSON.stringify(ne)),(z||B["custom-slides-autoplay"]||B["custom-slides-muted"])&&(B["custom-slides-autoplay"]&&(V["custom-slides-autoplay"]=B["custom-slides-autoplay"],B["custom-slides-autoplay"]==="true"&&!B["custom-slides-muted"]&&(V["custom-slides-muted"]="true")),B["custom-slides-loop"]&&(V["custom-slides-loop"]=B["custom-slides-loop"]),B["custom-slides-muted"]&&(V["custom-slides-muted"]=B["custom-slides-muted"]),B["custom-slides-controls"]&&(V["custom-slides-controls"]=B["custom-slides-controls"]));const Y=L.maxHeight?Pn(L.maxHeight):void 0,ce=!!(w!=null&&w.isListItem||Ai(v)),ie={id:v.id,type:v.type,content:v.content||"",rawMarkdown:S,clicks:P,parentClicks:w==null?void 0:w.parentClicks,parentContainerId:w==null?void 0:w.parentContainerId,motion:ne,shikiLines:L.shikiLines,maxHeight:Y,slot:T,attributes:V,attrs:V,rawNode:v,isListItem:ce};l.blocks.push(ie)};y(b)}for(let m=0;m<o.length;m++){const b=o[m],y=[],v={...b.frontmatter};m===0&&(v.theme=n.theme,v.aspectRatio=n.aspectRatio,v.highlighter=n.highlighter,v.transition=b.frontmatter.transition||n.defaultTransition);const w=lp(v);w&&y.push(w);const S=b.blocks.filter(z=>z.slot!=="slot-divider-right"),B=z=>z.filter(N=>!!(N.rawMarkdown||N.content||"").trim()).map(N=>{var K;return ln(N.rawMarkdown,N.clicks,N.motion,(K=N.attributes)==null?void 0:K.style,N.maxHeight)}).join(`

`),A=z=>{const N=z.filter(x=>!!(x.rawMarkdown||x.content||"").trim());if(N.length===0)return;const K=N[0],_=(K.rawMarkdown||K.content||"").trim();(Ai(K)||/^(?:[-*+]|\d+\.)\s+/.test(_))&&(K.rawMarkdown=Ls(K.rawMarkdown||K.content||""),K.content=K.rawMarkdown)},C=z=>{var x,q;if(z.length===0)return"";A(z);const N=(x=z.find(O=>O.parentClicks))==null?void 0:x.parentClicks;if(!N)return z.filter(O=>!!(O.rawMarkdown||O.content||"").trim()).map(O=>{var $;return ln(O.rawMarkdown,O.clicks,O.motion,($=O.attributes)==null?void 0:$.style,O.maxHeight)}).join(`

`);const K=[];let _=[];const U=()=>{if(_.length===0)return;const O=_.map($=>($.rawMarkdown||$.content||"").trim()).filter(Boolean).join(`

`);O&&K.push(jl(O,N)),_=[]};for(const O of z){if(!(O.rawMarkdown||O.content||"").trim())continue;!!(O.clicks&&O.clicks.trim()!=="")?(U(),K.push(ln(O.rawMarkdown,O.clicks,O.motion,(q=O.attributes)==null?void 0:q.style,O.maxHeight))):_.push(O)}return U(),K.join(`

`)},L=b.frontmatter.layout||"default";if(L==="clover"||ns(L)){let z=[];const N=S.filter(O=>O.slot==="header");if(N.length>0)z=N;else if(S.length>0){const O=S.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));O&&(z=[O])}const K=S.filter(O=>!z.includes(O));let _=2;if(L==="clover")_=4;else if(L==="three-cols-header")_=3;else if(L==="two-cols-header")_=2;else{let O=0;for(const $ of K){const T=($.slot||"").match(/^col-(\d+)$/i);T&&(O=Math.max(O,parseInt(T[1],10)))}if(O>=2)_=O;else if(b.frontmatter.layoutRatio){const $=b.frontmatter.layoutRatio.trim();if($.includes(":")){const T=$.split(":").map(P=>parseFloat(P.trim())).filter(P=>!isNaN(P)&&P>0);T.length>=2&&(_=T.length)}else{const T=$.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else K.length===1&&K[0].children&&K[0].children.length>=2&&(_=Math.min(6,K[0].children.length))}const U=Wl(K,_);U.forEach((O,$)=>{const T=`col-${$+1}`;for(const P of O)(!P.slot||P.slot==="default")&&(P.slot=T);A(O)});const x=U.flat();if(K.length===1&&x.length>1){const O=b.blocks.findIndex($=>$.id===K[0].id);O!==-1&&b.blocks.splice(O,1,...x)}const q=B(z);if(q&&y.push(q),L==="two-cols-header"&&_===2){const O=C(U[0]||[]),$=C(U[1]||[]);O&&y.push(`::left::

${O}`),$&&y.push(`::right::

${$}`)}else U.forEach((O,$)=>{const T=C(O);T&&y.push(`::col-${$+1}::

${T}`)})}else if(L==="two-cols"){const z=S.filter(U=>U.slot==="left"),N=S.filter(U=>U.slot==="right");A(z),A(N);const K=B(z.length>0?z:S.filter(U=>U.slot!=="right")),_=B(N);y.push(K),_&&y.push(`::right::

${_}`)}else for(const z of S)y.push(ln(z.rawMarkdown,z.clicks||z.parentClicks,z.motion,(k=z.attributes)==null?void 0:k.style,z.maxHeight));b.notes&&y.push(`<!--
${b.notes}
-->`),b.rawMarkdown=y.join(`

`).trim()}const p=o.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:n,slides:o,fullMarkdown:p}}const Ho=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function fp(e){var n,o,a,r,l,c,u,f,d,p,k,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(a=b.dark)!=null&&a.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(l=b.light)!=null&&l.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(u=b.dark)!=null&&u.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(d=b.light)!=null&&d.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(p=b.light)!=null&&p.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(k=b.dark)!=null&&k.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const s=[];return t.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),s.join(`

`)}function Os(e){const t=fp(e);return t?`${Ho}

/* Custom Workspace Inline Styles */
${t}`:Ho}const po=$a;function pp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function hp(e,t){const i=new Map,s=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:s};const n=new Map;for(const o of t)o!=null&&o.id&&n.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=n.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(pp(a)?s.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:s}}function mp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Fo(e){return at(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function gp(e,t,i,s=8,n){const o=new Map;for(const d of t)d!=null&&d.id&&o.set(d.id,d);const a=d=>({id:d.id,parent_id:d.parent_id,root_id:d.root_id||e,type:d.type,subType:d.subtype??d.subType??"",content:d.content||"",markdown:d.markdown||"",ial:i(d.id,d.ial),children:[]}),r=d=>{let p=d.parent_id,k=0;for(;p&&p!==e&&k++<16;){const m=o.get(p);if(!m||!mp(m))return p;p=m.parent_id}return p||e},l=new Map;for(const d of t){if(!(d!=null&&d.id)||d.id===e||n&&n.size>0&&!n.has(d.id))continue;const p=r(d),k=l.get(p);k?k.push(d):l.set(p,[d])}if(n&&n.size>0)for(const d of l.values())d.sort((p,k)=>(n.get(p.id)??Number.MAX_SAFE_INTEGER)-(n.get(k.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(d,p)=>{const k=a(d);if(c.set(k.id,k),p>=s||!Fo(k))return k;const m=l.get(k.id);return m&&m.length>0&&(k.children=m.map(b=>u(b,p+1))),k};return{topLevel:(l.get(e)||[]).map(d=>u(d,0)),byId:c}}const vp={getBlockAttrs:Ko,getChildBlocks:hs,getDocBlocksOrders:yd,setBlockAttrs:Fe,sql:ds,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:kd};class bp{constructor(t){be(this,"deps");be(this,"attrOverrides",new Map);be(this,"trackedListSuperBlocks",new Map);be(this,"fallbackWarnedDocId","");this.deps={...vp,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const n={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete n[o]:n[o]=String(a);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const s=this.attrOverrides.get(t);s&&(delete s[i],Object.keys(s).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},s=this.attrOverrides.get(t);s&&Object.assign(i,s);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let O=0;O<o.length;O++)o[O]&&a.set(o[O],O);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=hp(n,c),f=new Map;if(Array.isArray(c))for(const O of c)O.id&&O.ial&&f.set(O.id,po(O.ial));const d=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,p=await this.deps.sql(d).catch(()=>[])||[];if(Array.isArray(p)){for(const O of p)if(O.block_id&&O.name){let $=f.get(O.block_id);$||($={},f.set(O.block_id,$)),$[O.name]=O.value||""}}const k=(O,$)=>{const T={...f.get(O)||($?po($):{})},P=this.attrOverrides.get(O);return P&&Object.assign(T,P),T},m=Array.isArray(c)&&c.length>0?gp(t,c,k,8,a):null,b=n.map(O=>O.id).filter(Boolean),y=O=>({id:O.id,parent_id:O.parent_id,root_id:O.root_id||t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:k(O.id,O.ial),children:O.children}),v=async(O,$=0)=>{if(!O||$>8||!Fo(O))return;const T=await this.deps.getChildBlocks(O.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){O.children=T.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:O.id,root_id:t,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:k(P.id,P.ial),children:[]}));for(const P of O.children)await v(P,$+1)}},w=new Map;for(const O of c)O!=null&&O.id&&w.set(O.id,O);const S=b.every(O=>{const $=w.get(O);return!$||!!$.type});let B=[],A=!1;if(m&&u.usable&&r&&S){this.fallbackWarnedDocId="";for(const[$,T]of u.leafPatch){const P=m.byId.get($);P&&(P.content=T.content,P.markdown=T.markdown)}const O=new Map;for(const $ of n)$!=null&&$.id&&O.set($.id,$);for(const $ of u.rebuildRoots){const T=m.byId.get($),P=O.get($);T&&P&&(T.content=P.content||"",T.markdown=P.markdown||""),await v(T)}for(const $ of n){if(!($!=null&&$.id)||m.byId.has($.id))continue;const T=y($);await v(T),m.byId.set(T.id,T),m.topLevel.push(T)}B=m.topLevel.filter($=>a.has($.id)).sort(($,T)=>(a.get($.id)??0)-(a.get(T.id)??0))}else b.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),B=n.map(O=>y(O))):m&&(B=m.topLevel);const C=async(O,$=0)=>{if(!(!O||O.length===0||$>8))for(const T of O){if(Fo(T)&&(!T.children||T.children.length===0)){let ne=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!ne||ne.length===0){const V=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;ne=await this.deps.sql(V).catch(()=>[])||[]}if(Array.isArray(ne)&&ne.length>0){const V=new Set(B.map(ce=>ce.id)),Y=ne.filter(ce=>ce.id!==T.id&&!V.has(ce.id));Y.length>0&&(T.children=Y.map(ce=>{const ie=f.get(ce.id)||(ce.ial?po(ce.ial):{}),re=this.attrOverrides.get(ce.id);return re&&Object.assign(ie,re),{id:ce.id,parent_id:ce.parent_id||T.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:ie}}))}}T.children&&T.children.length>0&&await C(T.children,$+1)}};A&&await C(B);const L=O=>{var $,T;for(const P of O)if(P.children&&P.children.length>0){L(P.children);for(const ne of P.children)if(ne.ial)for(const[V,Y]of Object.entries(ne.ial))V.startsWith("custom-slides-")&&!(($=P.ial)!=null&&$[V])&&(P.ial||(P.ial={}),P.ial[V]=Y);if(P.ial){for(const[ne,V]of Object.entries(P.ial))if(ne.startsWith("custom-slides-"))for(const Y of P.children)(Y.type==="video"||Y.type==="NodeVideo"||/<video\b/i.test(Y.markdown||Y.content||""))&&!((T=Y.ial)!=null&&T[ne])&&(Y.ial||(Y.ial={}),Y.ial[ne]=V)}}};L(B),op(B,O=>{const $={[ke]:O.layout};this.setBlockAttrOverride(O.blockId,$),(this.deps.setBlockAttrs||Fe)(O.blockId,$).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const z=this.trackedListSuperBlocks.get(t)||[],N=np(t,B,{tracked:z,onTagChange:O=>{this.setBlockAttrOverride(O.blockId,O.attrs),O.blockId===t&&Object.assign(i,O.attrs);const $=P=>{for(const ne of P)ne.id===O.blockId&&(ne.ial||(ne.ial={}),Object.assign(ne.ial,O.attrs)),ne.children&&ne.children.length>0&&$(ne.children)};$(B),(this.deps.setBlockAttrs||Fe)(O.blockId,O.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const K=new Set,_=O=>{for(const $ of O){const T=$.markdown||$.content||"";if(T.includes("((")){const P=wd(T);for(const ne of P)K.add(ne.blockId)}$.children&&$.children.length>0&&_($.children)}};_(B);const U={};if(K.size>0){const O=Array.from(K).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${O})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(U[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",q=da(t,i,B,{baseUrl:x,refContentMap:U});try{const O=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;q.customThemeCss=Os(O)}catch{q.customThemeCss=Os(null)}return q}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const s=da(t,{},[],{});return s.customThemeCss=Os(null),s}}}const Le=new bp;class gr{constructor(t){be(this,"devServerUrl","http://localhost:3030");be(this,"isConnected",!1);be(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,s=setTimeout(()=>i.abort(),t),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,s=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.background&&s.push(`background: ${i.background}`),i.colorSchema&&i.colorSchema!=="auto"&&s.push(`colorSchema: ${i.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},f=[],d=c===0;u.layout&&u.layout!=="default"&&f.push(`layout: ${u.layout}`),u.transition&&f.push(`transition: ${u.transition}`),u.background&&f.push(`background: ${u.background}`),u.class&&f.push(`class: "${u.class}"`);let p="";f.length>0?p=d?"":`---
${f.join(`
`)}
---

`:d||(p=`---

`);let k="";if(u.layout==="two-cols"){const b=l.blocks.filter(S=>S.slot!=="right"),y=l.blocks.filter(S=>S.slot==="right"),v=b.map(S=>S.rawMarkdown||S.content||"").join(`

`),w=y.map(S=>S.rawMarkdown||S.content||"").join(`

`);k=`${v}

::right::

${w}`}else k=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${p}${k}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${n}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",s){const n=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),s)try{const o=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(t),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(n),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const yp={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function ai(e){return yp[e]===!1}function gt(e){return!ai(e)}function kp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Tt(e){const t=kp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function vr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Tt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Ul(){var t,i;const e=vr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const s=Tt("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function wp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qs(){const e=vr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Tt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Vl(){var s,n;const e=vr(),t={...(e==null?void 0:e.env)||{}};if(qs()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=e==null?void 0:e.env)!=null&&s.APPDATA?`${e.env.APPDATA}\\npm`:"",(n=e==null?void 0:e.env)!=null&&n.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function jo(e){var i,s,n;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((n=(s=(i=window.siyuan)==null?void 0:i.config)==null?void 0:s.system)!=null&&n.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function xp(){const e=Tt("os"),t=Tt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class br{constructor(t){be(this,"runner");this.runner=t||br.defaultRunner}static async defaultRunner(t,i){var s;try{let n=(s=Tt("child_process"))==null?void 0:s.execFile;if(!n){const l=await import("node:child_process").catch(()=>({}));n=l==null?void 0:l.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=qs()==="win32",r=Vl();return await new Promise(l=>{n(t,i,{timeout:5e3,shell:a,env:r},(c,u,f)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:f?String(f).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const t=Ul(),i=qs();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(s=!0,n=r.stdout)}catch{}if(s){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class Sp{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pageChangedHandlers",[]);be(this,"readyHandlers",[]);be(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(s,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(i.type==="update-state"&&i.navState){const s=i.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const s of this.pageChangedHandlers)s(i.no,this.currentState.total||1,this.currentState)}}}}class Cp{constructor(t){be(this,"childProcess",null);be(this,"activePort",null);be(this,"isRunning",!1);be(this,"defaultPort");be(this,"maxPortRetries");be(this,"probeTimeoutMs");be(this,"customSpawner");be(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Tt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(s=>{const n=i.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=i+s;if(await this.isPortAvailable(n))return n}return i}async pollServerReady(t,i=8e3,s=300){const n=Date.now();for(;Date.now()-n<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),s),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,s))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(i);this.activePort=s;const o=qs()==="win32"?"npx.cmd":"npx",a=jo(t),r=["@slidev/cli",a,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let f=(l=Tt("child_process"))==null?void 0:l.spawn;if(!f){const k=await import("node:child_process").catch(()=>({}));f=k==null?void 0:k.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const d=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,p=Vl();this.childProcess=f(o,r,{cwd:d,detached:!1,shell:!0,env:{...p,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),qs()==="win32"&&i.pid&&!this.customSpawner){const n=(t=Tt("child_process"))==null?void 0:t.exec;if(n)await new Promise(o=>{const a=setTimeout(o,400);n(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}class Xs{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pendingMessages",[]);be(this,"slideChangedHandlers",[]);be(this,"blockClickedHandlers",[]);be(this,"openInEditorHandlers",[]);be(this,"clientReadyHandlers",[]);be(this,"openPeekDrawerHandlers",[]);be(this,"toggleFullscreenHandlers",[]);be(this,"openPresenterHandlers",[]);be(this,"captureProgressHandlers",[]);be(this,"capturePageDoneHandlers",[]);be(this,"captureCompleteHandlers",[]);be(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var n;const s={source:"siyuan-slides-host",action:t,payload:i};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=s:this.pendingMessages.push(s)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,s,n){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:s,customThemeCss:n})}navigatePage(t,i){const s={pageIndex:t};typeof i=="number"&&(s.step=i),this.postMessage("NAVIGATE_PAGE",s)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var s,n;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((s=this.iframe)!=null&&s.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const Gl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},_p=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,$p=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Ip=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,Mp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Tp=`${Ho}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 幻灯片容器查询支持与代码块换行、弱提示滚动条样式 */
.slidev-page, .slidev-layout {
  container-type: size;
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Ep(e){var n;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=i.exec(e))!==null;){const o=(n=s[1])==null?void 0:n.trim();o&&!t.includes(o)&&t.push(o)}return t}class Ap{constructor(t){be(this,"workspacePath");be(this,"slidesFileName");be(this,"cliBridge",new gr);const i=xp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const s=this.buildSlidesMarkdown(t),n=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=jo(o),l=jo(a),c=Ep(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const w of c){const S=Gl[w]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${w}
// #endregion snippet
`;u.set(w,S)}t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",_p),t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",$p),t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="clover"})&&u.set("layouts/clover.vue",Ip),u.set("setup/root.ts",Mp),u.set("styles/index.css",Tp);const k=Tt("fs"),m=Tt("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",v=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(k&&m&&v)try{k.existsSync(y)||k.mkdirSync(y,{recursive:!0}),k.writeFileSync(l,n,"utf-8"),k.writeFileSync(r,s,"utf-8");for(const[w,S]of u.entries()){const B=m.join(y,w),A=m.dirname(B);k.existsSync(A)||k.mkdirSync(A,{recursive:!0}),k.existsSync(B)||k.writeFileSync(B,S,"utf-8")}b=!0}catch{}if(!b&&i)try{const w=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),S=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await i(a,!1,S),await i(o,!1,w);for(const[B,A]of u.entries()){const C=`${this.workspacePath}/${B}`,L=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await i(C,!1,L).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(w){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(w)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class Bp{constructor(){be(this,"mode","web-sandbox");be(this,"webBridge");be(this,"cliBridge");be(this,"nativeBridge");be(this,"processManager");be(this,"scaffolder");be(this,"envDetector");this.webBridge=new Xs,this.cliBridge=new gr,this.nativeBridge=new Sp,this.processManager=new Cp,this.scaffolder=new Ap,this.envDetector=new br}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(t,i);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const o=n.physicalSlidesPath||n.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Dp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Lp={key:0},Pp={key:1},Op={key:2},Rp={key:3},Np={key:4},zp={key:5},Hp={key:6},Fp={key:7},jp={key:8},Wp={key:9},Up={key:10},Vp={key:11},Gp={key:12},Kp={key:13},qp={key:14},Yp={key:15},Zp={key:16},Jp={key:17},Xp={key:18},Qp={key:19},eh={key:20},th={key:21},ih={key:22},sh={key:23},nh={key:24},oh={key:25},rh={key:26},ah={key:27},lh={key:28},ch={key:29},dh={key:30},uh={key:31},fh={key:32},ph={key:33},hh={key:34},mh={key:35},gh={key:36},vh={key:37},bh={key:38},yh={key:39},kh={key:40},wh={key:41},xh={key:42},Sh={key:43},Ch={key:44},_h={key:45},$h={key:46},Ih={key:47},Mh={key:48},Th={key:49},Eh={key:50},Ah={key:51},Bh={key:52},Dh={key:53},Lh={key:54},Ph={key:55},Oh={key:56},Rh={key:57},Nh={key:58},zh={key:59},Hh={key:60},Fh={key:61},jh={key:62},Wh={key:63},Uh={key:64},Vh={key:65},Gh={key:66},Kh={key:67},qh={key:68},Yh={key:69},Zh={key:70},Jh={key:71},Xh={key:72},Qh=Dt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(J(),ee("svg",Dp,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",Lp,[...i[0]||(i[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",Pp,[...i[1]||(i[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",Op,[...i[2]||(i[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",Rp,[...i[3]||(i[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",Np,[...i[4]||(i[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",zp,[...i[5]||(i[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",Hp,[...i[6]||(i[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Fp,[...i[7]||(i[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",jp,[...i[8]||(i[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",Wp,[...i[9]||(i[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",Up,[...i[10]||(i[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",Vp,[...i[11]||(i[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",Gp,[...i[12]||(i[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",Kp,[...i[13]||(i[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",qp,[...i[14]||(i[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",Yp,[...i[15]||(i[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",Zp,[...i[16]||(i[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",Jp,[...i[17]||(i[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",Xp,[...i[18]||(i[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Qp,[...i[19]||(i[19]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",eh,[...i[20]||(i[20]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",th,[...i[21]||(i[21]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",ih,[...i[22]||(i[22]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",sh,[...i[23]||(i[23]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",nh,[...i[24]||(i[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),ee("g",oh,[...i[25]||(i[25]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",rh,[...i[26]||(i[26]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",ah,[...i[27]||(i[27]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",lh,[...i[28]||(i[28]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",ch,[...i[29]||(i[29]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",dh,[...i[30]||(i[30]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",uh,[...i[31]||(i[31]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",fh,[...i[32]||(i[32]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",ph,[...i[33]||(i[33]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",hh,[...i[34]||(i[34]=[h("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",mh,[...i[35]||(i[35]=[h("polyline",{points:"11 17 6 12 11 7"},null,-1),h("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",gh,[...i[36]||(i[36]=[h("polyline",{points:"13 17 18 12 13 7"},null,-1),h("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",vh,[...i[37]||(i[37]=[h("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",bh,[...i[38]||(i[38]=[h("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),h("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",yh,[...i[39]||(i[39]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",kh,[...i[40]||(i[40]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",wh,[...i[41]||(i[41]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",xh,[...i[42]||(i[42]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",Sh,[...i[43]||(i[43]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",Ch,[...i[44]||(i[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",_h,[...i[45]||(i[45]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",$h,[...i[46]||(i[46]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",Ih,[...i[47]||(i[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",Mh,[...i[48]||(i[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",Th,[...i[49]||(i[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",Eh,[...i[50]||(i[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",Ah,[...i[51]||(i[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",Bh,[...i[52]||(i[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",Dh,[...i[53]||(i[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",Lh,[...i[54]||(i[54]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",Ph,[...i[55]||(i[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",Oh,[...i[56]||(i[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",Rh,[...i[57]||(i[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Nh,[...i[58]||(i[58]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",zh,[...i[59]||(i[59]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",Hh,[...i[60]||(i[60]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Fh,[...i[61]||(i[61]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",jh,[...i[62]||(i[62]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",Wh,[...i[63]||(i[63]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",Uh,[...i[64]||(i[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",Vh,[...i[65]||(i[65]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",Gh,[...i[66]||(i[66]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",Kh,[...i[67]||(i[67]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",qh,[...i[68]||(i[68]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",Yh,[...i[69]||(i[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),ee("g",Zh,[...i[70]||(i[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",Jh,[...i[71]||(i[71]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",Xh,[...i[72]||(i[72]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ii=(e,t)=>{const i=e.__vccOpts||e;for(const[s,n]of t)i[s]=n;return i},de=ii(Qh,[["__scopeId","data-v-af7d02a2"]]),em={class:"spm-immersion-header"},tm={class:"spm-immersion-header__left"},im={class:"spm-immersion-title"},sm={class:"spm-immersion-header__center"},nm={class:"spm-immersion-header__actions"},om=["aria-label"],rm={class:"spm-immersion-body"},am=Dt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,s=t;function n(){s("update:visible",!1),s("close")}function o(){i.closeOnClickMask&&n()}function a(){s("update:isMaximized",!i.isMaximized),s("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),n())}return(l,c)=>Ot((J(),ee("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Zt(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:o}),h("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",em,[h("div",tm,[rn(l.$slots,"header-left",{},()=>[h("span",im,we(e.title),1)])]),h("div",sm,[rn(l.$slots,"header-center",{},void 0)]),h("div",nm,[rn(l.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[oe(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,om),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[oe(de,{name:"close"})])])]),h("div",rm,[rn(l.$slots,"default",{},void 0)])],2)],34)),[[Ro,e.visible]])}}),lm=ii(am,[["__scopeId","data-v-1359fecb"]]),cm={class:"spm-protyle-drawer"},dm={class:"spm-protyle-drawer__subbar"},um={class:"spm-protyle-drawer__nav"},fm=["title"],pm={class:"spm-protyle-drawer__actions"},hm=["aria-label"],mm=["aria-label"],gm=Dt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,s=e,n=ge(s.blockId),o=ge(s.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),u=Vt,f=ge([]),d=ge(null);let p=null;Vi(()=>s.blockId,C=>{C&&C!==n.value&&(n.value=C,o.value=s.title||"",f.value=[],m(C))}),vs(()=>{n.value&&m(n.value)}),ar(()=>{b()});async function k(C){try{const L=await ds(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const z=L[0];c.value=z.root_id||"";const N=z.id===z.root_id||z.type==="d";l.value=N,r.value=!N,!o.value&&z.content&&(o.value=z.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}l.value=!1,r.value=!0}async function m(C,L){if(!d.value||!C)return;b(),await k(C),typeof L=="boolean"&&(r.value=!l.value&&L);let z,N;r.value&&!l.value?(z=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(z=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{p=new ae.Protyle(s.plugin.app,d.value,{blockId:C,action:z,render:N}),!a.value&&p&&typeof p.disable=="function"&&p.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function b(){if(p){try{typeof p.destroy=="function"&&p.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}p=null}d.value&&(d.value.innerHTML="")}function y(){l.value||(r.value=!r.value,m(n.value,r.value))}function v(){a.value=!a.value,p&&(a.value?(typeof p.enable=="function"&&p.enable(),typeof p.focus=="function"&&p.focus()):typeof p.disable=="function"&&p.disable())}function w(){if(n.value)try{ae.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function S(){var z;if(!n.value)return;const C=Zn(),L=Nl(C.webServeUrl,n.value,{focus:!l.value});if(typeof window<"u"){const N=Tt("electron");(z=N==null?void 0:N.shell)!=null&&z.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}i("external-jump",L)}function B(){if(f.value.length>0){const C=f.value.pop();C&&(n.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function A(C){const L=C.target;if(!L)return;const z=L.closest('[data-type="block-ref"]');if(z){const K=z.getAttribute("data-id");if(K&&K!==n.value){C.preventDefault(),C.stopPropagation(),f.value.push({blockId:n.value,title:o.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=K,o.value=z.innerText.trim()||K,m(K);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const K=N.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==n.value&&(f.value.push({blockId:n.value,title:o.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=K,o.value=N.innerText.trim()||K,m(K))}}return(C,L)=>(J(),ee("div",cm,[h("div",dm,[h("div",um,[f.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:B},[oe(de,{name:"arrow-left"}),L[0]||(L[0]=h("span",null,"返回",-1))])):Te("",!0),h("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},we(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:o.value||n.value},we(o.value||n.value),9,fm)]),h("div",pm,[l.value?Te("",!0):(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[oe(de,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,hm)),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:v},[oe(de,{name:a.value?"edit":"eye"},null,8,["name"]),h("span",null,we(a.value?"编辑中":"只读"),1)],10,mm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:w},[oe(de,{name:"window"}),L[1]||(L[1]=h("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:S},[oe(de,{name:"external-link"}),L[2]||(L[2]=h("span",null,"外跳",-1))])):Te("",!0)])]),h("div",{ref_key:"mountEl",ref:d,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:A},null,2)]))}}),vm=ii(gm,[["__scopeId","data-v-0d6e2df3"]]),bm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,ym=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function ua(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const s=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return s?`/plugins/${s[1]}`:null}function Kl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const s=i.indexOf("/");return s>=0?i.slice(s):i}function km(e){const t=e.split(/[/?#]/)[0];return!t||ym.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function wm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",s=t>=0?e.slice(0,t):e,n=s.indexOf("?"),o=n>=0?s.slice(0,n):s,a=n>=0?s.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function ql(e){const t=xm(e);return t.external||!t.url?t:{url:wm(t.url),external:!1}}function xm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Aa(t))return{url:`/${Ba(t)}`,external:!1};if(/^file:/i.test(t)){const s=ua(Kl(t));return s?{url:s,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const s=ua(t);return s?{url:s,external:!1}:{url:t,external:!0}}return bm.test(t)?{url:t,external:!0}:km(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Sm={class:"spm-webview-drawer"},Cm={class:"spm-webview-toolbar"},_m={class:"spm-webview-toolbar__nav"},$m=["disabled"],Im=["disabled"],Mm=["aria-label"],Tm={class:"spm-webview-toolbar__address"},Em=["aria-label"],Am={class:"spm-webview-toolbar__actions"},Bm=["aria-label"],Dm={class:"spm-zoom-controller"},Lm=["disabled"],Pm=["disabled"],Om={key:1,class:"spm-webview-fallback"},Rm=["src"],Nm={key:2,class:"spm-load-error"},zm={class:"spm-load-error__code"},Hm={class:"spm-load-error__code-num"},Fm={class:"spm-load-error__url"},jm={class:"spm-load-error__hint"},Wm={class:"spm-load-error__actions"},fa="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Yl="siyuan-slides-peek-view-mode";let Zl="desktop";function Um(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Yl);if(e==="mobile"||e==="desktop")return e}catch{}return Zl}function Vm(e){if(Zl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Yl,e)}catch{}}function Gm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Km=Dt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,s=e,n=ge(Ul()&&!wp()),o=ge(s.url),a=ge(s.url),r=s.url,l=ge(!1),c=ge(null),u=ge(!1),f=ge(!1),d=ge(1),p=ge(!1),k=ge(Um());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ye(()=>k.value==="mobile"?fa:m||void 0),y=ge(null),v=ge(null);let w=null,S=null,B=null;Vi(()=>s.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,k.value==="mobile"&&N(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X))}),Vi(()=>s.visible,X=>{if(X)ce(),k.value==="mobile"&&N(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),vs(()=>{A(),v.value&&typeof ResizeObserver<"u"&&(w=new ResizeObserver(()=>{const X=y.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),w.observe(v.value)),S=X=>{var E;const pe=X.message||((E=X.error)==null?void 0:E.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),B=X=>{const pe=X.reason,E=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof E=="string"&&E.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",B)}),ar(()=>{if(C(),w&&(w.disconnect(),w=null),S&&(window.removeEventListener("error",S,!0),S=null),B&&(window.removeEventListener("unhandledrejection",B),B=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function A(){const X=y.value;X&&(X.addEventListener("dom-ready",L),X.addEventListener("did-start-loading",K),X.addEventListener("did-stop-loading",x),X.addEventListener("did-navigate",q),X.addEventListener("did-navigate-in-page",O),X.addEventListener("new-window",$),X.addEventListener("did-fail-load",_),X.addEventListener("did-fail-provisional-load",_))}function C(){const X=y.value;if(X)try{X.removeEventListener("dom-ready",L),X.removeEventListener("did-start-loading",K),X.removeEventListener("did-stop-loading",x),X.removeEventListener("did-navigate",q),X.removeEventListener("did-navigate-in-page",O),X.removeEventListener("new-window",$),X.removeEventListener("did-fail-load",_),X.removeEventListener("did-fail-provisional-load",_)}catch{}}function L(){const X=y.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const pe=X.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}k.value==="mobile"&&N(!1),ce(),T()}function z(){const X=k.value==="mobile"?"desktop":"mobile";k.value=X,Vm(X),N(!0)}function N(X=!1){const pe=y.value;if(!pe)return;const E=k.value==="mobile"?fa:m;if(typeof pe.setUserAgent=="function"&&E)try{pe.setUserAgent(E)}catch(F){console.warn("[WebviewPeekDrawer] setUserAgent error:",F)}if(X&&typeof pe.reload=="function")try{pe.reload()}catch(F){console.warn("[WebviewPeekDrawer] reload error:",F)}}function K(){l.value=!0,c.value=null}function _(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const pe=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:pe,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:Gm(pe)},l.value=!1}function U(){c.value=null,V()}function x(){if(l.value=!1,T(),y.value&&typeof y.value.getURL=="function"){const X=y.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function q(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function O(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function $(X){X&&X.url&&(X.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url))}function T(){const X=y.value;X&&(typeof X.canGoBack=="function"&&(u.value=X.canGoBack()),typeof X.canGoForward=="function"&&(f.value=X.canGoForward()))}function P(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function ne(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function V(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function Y(){const X=ql(a.value);if(X.url){if(X.external){o.value=X.url,fe();return}o.value=X.url,a.value=X.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url)}}function ce(){const X=y.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(d.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ie(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),ce()}function re(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),ce()}function Se(){d.value=1,ce()}function Ie(X){X.preventDefault(),X.deltaY<0?ie():X.deltaY>0&&re()}async function _e(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function fe(){var pe;const X=o.value;if(typeof window<"u"){const E=Tt("electron");(pe=E==null?void 0:E.shell)!=null&&pe.openExternal?E.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,pe)=>{const E=Eu("webview");return J(),ee("div",Sm,[h("div",Cm,[h("div",_m,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:P},[oe(de,{name:"arrow-left"})],8,$m),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:ne},[oe(de,{name:"arrow-right"})],8,Im),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:V},[oe(de,{name:"refresh"})],8,Mm)]),h("div",Tm,[Ot(h("input",{"onUpdate:modelValue":pe[0]||(pe[0]=F=>a.value=F),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Gf(Y,["enter"])},null,544),[[No,a.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:_e},[oe(de,{name:"copy"})],8,Em)]),h("div",Am,[h("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":k.value==="mobile"}]),"aria-label":k.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:z},[oe(de,{name:k.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Bm),h("div",Dm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:re},[oe(de,{name:"minus"})],8,Lm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},we(Math.round(d.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:ie},[oe(de,{name:"plus"})],8,Pm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[oe(de,{name:"external-link"}),pe[1]||(pe[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:Ce(["spm-webview-body",{"is-mobile":k.value==="mobile"}]),onWheel:Zt(Ie,["ctrl"])},[h("div",{class:Ce(["spm-webview-viewport",{"is-mobile":k.value==="mobile"}])},[n.value?(J(),Jt(E,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:he(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",Om,[h("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Rm),h("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",Nm,[oe(de,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",zm,[It(we(c.value.description)+" ",1),h("span",Hm,"("+we(c.value.errorCode)+")",1)]),h("div",Fm,we(c.value.validatedURL),1),h("p",jm,we(c.value.hint),1),h("div",Wm,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:U},[oe(de,{name:"refresh"}),pe[3]||(pe[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[oe(de,{name:"external-link"}),pe[4]||(pe[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),qm=ii(Km,[["__scopeId","data-v-6e363f73"]]);class Ym{constructor(){be(this,"timers",new Map)}debounce(t,i,s=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),i()},s);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Zm{constructor(t){be(this,"blockToPageMap",new Map);be(this,"debounceCtrl",new Ym);be(this,"activeBlockId","");be(this,"activePageIndex",1);be(this,"currentDocId","");be(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const s of i.blocks)this.blockToPageMap.set(s.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let At=null,hn=null,mn="";function Rs(){var e,t;if(hn&&(clearTimeout(hn),hn=null),At){try{At.classList.remove("protyle-wysiwyg--select"),mn?At.style.outline=mn:typeof((e=At.style)==null?void 0:e.removeProperty)=="function"?At.style.removeProperty("outline"):At.style&&(At.style.outline=""),typeof((t=At.style)==null?void 0:t.removeProperty)=="function"?At.style.removeProperty("transition"):At.style&&(At.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}At=null,mn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(s=>{var o,a;s.classList.remove("protyle-wysiwyg--select");const n=((o=s.style)==null?void 0:o.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((a=s.style)==null?void 0:a.removeProperty)=="function"?(s.style.removeProperty("outline"),s.style.removeProperty("transition")):s.style&&(s.style.outline="",s.style.transition=""))})}catch{}}function Gi(e,t){var a,r,l,c;if(!e||typeof document>"u")return Rs(),!1;Rs();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!s){if(t)try{return ae.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=s.scrollIntoView)==null||r.call(s)}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}const n=((c=s.style)==null?void 0:c.outline)||"";return mn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,s.classList.add("protyle-wysiwyg--select"),s.style&&(s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.2s ease"),At=s,hn=setTimeout(()=>{Rs()},500),!0}function Jm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>rt(a)).join("<br/>");const s=[];let n=[];const o=()=>{if(n.length>0){const a=n.map(r=>rt(r)).join("<br/>");s.push(`<p class="slide-list-item-desc">${a}</p>`),n=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();s.push(`<h${l} class="slide-list-item-title">${rt(c)}</h${l}>`)}else n.push(a)}return o(),s.join(`
`)}function Xm(e){if(e.length===0)return"";const t=[],i=e[0],s=i.match(/^(#{1,6})\s+(.*)$/);if(s){const n=s[1].length,o=s[2].trim();t.push(`<h${n} class="slide-list-item-title">${rt(o)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const n=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>rt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of n){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Jl(e,t,i){var d,p,k,m;const s=e.split(`
`);if(!s.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return(i!=null&&i.isListItem||(i==null?void 0:i.type)==="i")&&!(i!=null&&i.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${rt(e)}</li>
</ul>`:null;const o=[],a=[];let r=!1;for(let b=0;b<s.length;b++){const y=s[b];if(!y.trim())continue;const v=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(v){const A=v[1].length,C=Math.floor(A/2);a.push({type:"task",level:C,checked:v[2].toLowerCase()==="x",text:v[3],media:[]});continue}const w=y.match(/^(\s*)[-*+]\s+(.*)$/);if(w){const A=w[1].length,C=Math.floor(A/2);a.push({type:"unordered",level:C,text:w[2],media:[]});continue}const S=y.match(/^(\s*)\d+\.\s+(.*)$/);if(S){a.length===0&&(r=!0);const A=S[1].length,C=Math.floor(A/2);a.push({type:"ordered",level:C,text:S[2],media:[]});continue}const B=y.trim();if(!(!B||/^\{:.*?\}$/.test(B)))if(a.length>0){const A=B.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const z=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(A[1])}" src="${A[2]}" class="${z}" /></div>`);continue}if(B.match(/^<img\b[\s\S]*?\/?>$/i)){const L=B.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(B)){let L=B;if(!/<\/video>/i.test(L))for(;b+1<s.length&&!/<\/video>/i.test(L);)b++,L+=" "+s[b].trim();const z=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),N=((p=i==null?void 0:i.attributes)==null?void 0:p["custom-slides-loop"])==="true"||/loop/i.test(L),K=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slides-muted"])==="true"||z||/muted/i.test(L),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",U=L.match(/\bsrc=["']([^"']+)["']/i),x=U?U[1]:"",q=['class="slide-video-player"'];_||q.push("controls"),z&&(q.push("autoplay"),q.push("playsinline")),N&&q.push("loop"),K&&q.push("muted"),q.push('preload="metadata"'),x&&q.push(`src="${x}"`);const O=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=O?O[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${z?"true":"false"}" data-muted="${K?"true":"false"}"><video ${q.join(" ")}>${$}</video></div>`);continue}a[a.length-1].text+=`
`+B}else o.push(B)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(b=>{const y=Jm(b.text),v=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",w=b.level||0,S=w>0?` style="margin-left:${(w*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${w%2===1?"circle":"square"} !important;`:""}"`:"",B=w>0?" slide-list-item--nested":"";if(b.type==="task"){const C=b.checked?' checked=""':"";return`<li class="pdf-task-item${B}"${S}><label><input type="checkbox" disabled=""${C}/> <span>${y}</span></label>${v}</li>`}return`<li${B?` class="${B.trim()}"`:""}${S}>${y}${v}</li>`}).join(`
`);return`${Xm(o)}<${l} class="${c}">
${u}
</${l}>`}function Qm(e,t,i){const s=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<n.length;c++){const u=n[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(!f){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(/<video\b/i.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]);let d=f;if(!/<\/video>/i.test(d))for(;c+1<n.length&&!/<\/video>/i.test(d);)c++,d+=`
`+n[c];o.push(d);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var k,m,b,y;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const v=f[1].length;return`<h${v} class="slide-list-item-title">${rt(f[2].trim())}</h${v}>`}const d=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(d){const v=/\.gif(?:\?|$)/i.test(d[2]),w=(t==null?void 0:t.imageClassName)||(v?"list-item-gif":"pdf-image slide-media-img");return`<div class="${s} ${s}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(d[1])}" src="${d[2]}" class="${w}" /></div>`}if(/<video\b/i.test(u)){const v=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),w=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),S=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||v||/muted/i.test(u),B=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),C=A?A[1]:"",L=['class="slide-video-player"'];B||L.push("controls"),v&&L.push("autoplay playsinline"),w&&L.push("loop"),S&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const z=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=z?z[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${s} ${s}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${S?"true":"false"}"><video ${L.join(" ")}>${N}</video></div>`}const p=Jl(u,t,i);if(p)return r=!1,p;if(r){r=!1;const v=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(v.length===1)return`<p class="slide-list-item-title">${rt(v[0])}</p>`;const w=v[0],B=v.slice(1).map(A=>rt(A)).join("<br/>");return`<p class="slide-list-item-title">${rt(w)}</p>
<p class="slide-list-item-desc">${B}</p>`}return`<p class="slide-list-item-desc">${rt(u)}</p>`}).filter(Boolean).join(`
`)}function ho(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Xl(e,t){var r,l,c,u,f,d,p,k;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:n.find(ho);if(i==="two-cols"){const m=n.some(K=>K.slot==="right");let b=[],y=[];if(m)b=n.filter(K=>K.slot!=="right"),y=n.filter(K=>K.slot==="right");else{const K=Math.ceil(n.length/2);b=n.slice(0,K),y=n.slice(K)}const v=K=>{const _=K.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(_.length>0){const U=_[0],x=(U.rawMarkdown||U.content||"").trim();(Ai(U)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(U.rawMarkdown=Ls(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown)}};v(b),v(y);const w=b.map(K=>xi(K,t)).join(`
`),S=y.map(K=>xi(K,t)).join(`
`),B=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",L=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${fo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${B}${A}" ${N}>
        <div class="${C}">${w}</div>
        <div class="${L}">${S}</div>
      </div>
    `}if(i==="clover"||ns(i)){const m=i==="clover";let b=[];const y=n.filter(q=>q.slot==="header");if(y.length>0)b=y;else if(n.length>0){const q=n.find(O=>O.type==="h"&&(!O.slot||O.slot==="default"));q&&(b=[q])}const v=n.filter(q=>!b.includes(q));let w=2;if(m)w=4;else if(i==="three-cols-header")w=3;else if(i==="two-cols-header")w=2;else{let q=0;for(const O of v){const $=(O.slot||"").match(/^col-(\d+)$/i);$&&(q=Math.max(q,parseInt($[1],10)))}if(q>=2)w=q;else if((u=e.frontmatter)!=null&&u.layoutRatio){const O=e.frontmatter.layoutRatio.trim();if(O.includes(":")){const $=O.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(w=$.length)}else{const $=O.split(/\s+/).filter(Boolean);$.length>=2&&(w=$.length)}}else v.length===1&&v[0].children&&v[0].children.length>=2&&(w=Math.min(6,v[0].children.length))}const S=Wl(v,w),B=v.some(q=>q.slot&&/^(?:col-\d+|left|right)$/i.test(q.slot)),A=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||ns(i)&&B,C=q=>{const O=q.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(A&&O.length>0){const T=O[0],P=(T.rawMarkdown||T.content||"").trim();(Ai(T)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(T.rawMarkdown=Ls(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=A?O.find(ho):null;return O.map(T=>xi(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},L=b.find(ho),z=b.map(q=>xi(q,{...t,extraClassName:q===L?"slides-page-first-heading-block":""})).join(`
`),N=m?"repeat(2, minmax(0, 1fr))":fo((f=e.frontmatter)==null?void 0:f.layoutRatio,w),K=m?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,_=[m?"layout-clover-container":"layout-cols-header-container",w===2?"layout-two-cols-header-container":"",w===3?"layout-three-cols-header-container":"",`layout-${i}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),U=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",w===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",w===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),x=S.map((q,O)=>{const $=O+1;return`<div class="${["pdf-col",w===2&&$===1?"pdf-col--left":"",w===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${C(q)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${z}</div>
        <div class="${U}" ${K}>
          ${x}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=n.map(A=>xi(A,t)).join(`
`),y=((d=e.frontmatter)==null?void 0:d.image)||((p=e.frontmatter)==null?void 0:p.background)||"",v=`<div class="pdf-image-col" style="background-image:url('${nt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,w=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,S=m?`${w}
${v}`:`${v}
${w}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${fo((k=e.frontmatter)==null?void 0:k.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${S}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${n.map(b=>xi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${n.map(b=>xi(b,t)).join(`
`)}</div>`:n.map(m=>xi(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function eg(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const s of i){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[o,a]=n.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(n,10);isNaN(o)||t.add(o)}}return t}const tg=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=Fl(e),i=[],s=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!tg.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let n=nt(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,f)=>{const p=(r??l??c??u??f??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${p}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),n}function ig(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=i[0];let n=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(n=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${s.map((l,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${rt(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function mo(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function pa(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${mo(e)}</span>`;const i=[];function s(o,a){return i.push(`<span class="${o}">${mo(a)}</span>`),`__TOK_${i.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>s("token-string",`${a}${r}${a}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>s("token-keyword",o)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>s("token-type",o)),n=n.replace(/\b(\d+)\b/g,o=>s("token-number",o)),n=mo(n),n=n.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),n}function sg(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let s=(i.title||"").trim(),n=i.level?parseInt(i.level,10):0;if(!s){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){n||(n=l[1].length),s=l[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:s,level:n}):null}function ng(e,t=1,i={}){const s=i.minDepth!==void 0?Number(i.minDepth):1,n=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=sg(c,u+1);f&&o.push(f)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>n)return[];const f=[];for(const d of c){const p=l(d.children,u+1);u>=s?f.push({...d,children:p}):f.push(...p)}return f}return l(a,1)}function og(e,t=1,i={}){const s=ng(e,t,i),n=i.columns?Number(i.columns):1,o=n>1?` style="column-count: ${n};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,d=c.map(p=>{const k=p.active?" slides-toc-item-active":p.hasActiveChild?" slides-toc-item-parent-active":"",m=p.children&&p.children.length>0?r(p.children,u+1):"";let b=rt(p.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${k}" data-page="${p.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${d}</ol>`}const l=r(s,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function xi(e,t){var B,A,C,L,z,N,K,_,U,x,q,O;let i="",s="",n="";const o=[];(B=e.motion)!=null&&B.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((A=e.attributes)==null?void 0:A.style)||"";a&&(o.push(a),n=" slide-styled-block"),o.length>0&&(s=` style="${nt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${i}${n}${l}${u}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${f}"${s}></div>`;if(d.includes('class="slides-block-ref"')||d.includes('class="slides-ref-tag"'))return`<div class="${f}"${s}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const $=d.slice(2,-2).trim();return`<div class="${f} katex-display-container"${s}><div class="katex-display font-math"><em>${nt($)}</em></div></div>`}const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){const $=p[1].length,T=rt(p[2]),ne=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${s}><h${$}${ne}>${T}</h${$}></div>`}if(d.startsWith(":::")){const $=d.split(`
`),P=$[0].replace(/^:::\s*/,"").trim()||"info",ne=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),V=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${s}><div class="${V} ${V}--${P}"><div class="${V}-title">${P.toUpperCase()}</div><div class="${V}-body">${rt(ne)}</div></div></div>`}if(d.startsWith("<<<")){const P=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((ie,re)=>`<span class="code-line shiki-focus"><span class="line-no">${re+1}</span><span class="line-content">${pa(ie,"ts")}</span></span>`).join(`
`),ne=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",V=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((z=e.attributes)==null?void 0:z["custom-slides-max-height"])||e.maxHeight||"",Y=Pn(String(V||"")),ce=Y?` style="max-height:${nt(Y)};overflow-y:auto;"`:"";return`<div class="${f}"${s}><pre class="${ne}"${ce}><span class="lang-badge">TS</span><code>${P}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const $=d.split(`
`),T=$[0].slice(3).trim(),P=T.match(/^([^\s{\[]+)/),ne=P?P[1]:"",V=T.match(/\[([^\]]+)\]/),Y=V?V[1]:"",ce=T.includes("twoslash"),ie=e.shikiLines||((N=T.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",re=eg(ie),Se=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[d.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",_e=Y?`${Ie} has-filename`:Ie,fe=re!=="all",X=Se.map((j,M)=>{const I=M+1,G=re==="all"||re.has(I)?"code-line shiki-focus":fe?"code-line shiki-dimmed":"code-line";let H=(t==null?void 0:t.highlight)===!0?pa(j,ne):nt(j);return ce&&j.includes("doubled.value = 2")?(H=H.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>`}).join(`
`),pe=ne?`<span class="lang-badge">${nt(ne)}</span>`:"",E=Y?`<span class="code-filename">${nt(Y)}</span>`:"",F=((K=e.attrs)==null?void 0:K["custom-slides-max-height"])||((_=e.attributes)==null?void 0:_["custom-slides-max-height"])||e.maxHeight||"",g=Pn(String(F||"")),W=g?` style="max-height:${nt(g)};overflow-y:auto;"`:"";return`<div class="${f}"${s}><pre class="${_e}"${W}>${E}${pe}<code>${X}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=d.split(`
`).filter(P=>P.trim().startsWith("|")),T=ig($,t==null?void 0:t.tableClassName);return`<div class="${f}"${s}>${T}</div>`}if(d.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${s}><blockquote class="${$}"><p>${rt(d.slice(2))}</p></blockquote></div>`}const k=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),b=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(k&&!m&&!b&&!d.includes(`
`)){const $=((U=e.attributes)==null?void 0:U["custom-slides-autoplay"])==="true"||/autoplay/i.test(d),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(d),P=((q=e.attributes)==null?void 0:q["custom-slides-muted"])==="true"||$||/muted/i.test(d),ne=((O=e.attributes)==null?void 0:O["custom-slides-controls"])==="false",V=d.match(/\bsrc=["']([^"']+)["']/i),Y=V?V[1]:"",ce=['class="slide-video-player"'];ne||ce.push("controls"),$&&(ce.push("autoplay"),ce.push("playsinline")),T&&ce.push("loop"),P&&ce.push("muted"),ce.push('preload="auto"'),Y&&ce.push(`src="${Y}"`);const ie=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=ie?ie[1].trim():"";return!re&&Y&&(re=`<source src="${Y}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${P?"true":"false"}"${s}><video ${ce.join(" ")}>${re}</video></div>`}const y=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${s}><img alt="${nt(y[1])}" src="${y[2]}" class="${$}" /></div>`}const v=Jl(d,t,e);if(v)return`<div class="${f} pdf-list-item"${s}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const $=d.match(/minDepth=["']?(\d+)["']?/i),T=d.match(/maxDepth=["']?(\d+)["']?/i),P=d.match(/columns=["']?(\d+)["']?/i),ne=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${s}>${og(ne,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:P?parseInt(P[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||b){const $=Qm(d,t,e);if($)return`<div class="${f}"${s}>${$}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${s}><p${S}>${rt(d)}</p></div>`}function rg(e){return`
    ${Os(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default,
    .slide-viewport[data-theme="light"].slides-theme-default,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default,
    .slide-viewport[data-theme="dark"].slides-theme-default,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-default,
    .slide-viewport[data-theme="light"].slides-theme-default {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-default,
    .slide-viewport[data-theme="dark"].slides-theme-default {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：非 cover 页首标题带科技 Accent 垂直指示条 */
    .slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .slides-theme-default:not(.layout-cover) .cols-header-top h1,
    .slides-theme-default:not(.layout-cover) .cols-header-top h2,
    .slides-theme-default:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-default:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-default:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-default:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border-left: 4px solid var(--slide-accent);
      padding-left: 14px;
      letter-spacing: -0.015em;
    }
    .slides-theme-default blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-default pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅学术风：非 cover 页首标题带典雅细下划线 */
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 6px;
      display: inline-block;
      margin-bottom: 12px;
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：绝对去装饰化，特大字重力量感，无边框与线条 */
    .slides-theme-apple-basic:not(.layout-cover) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border: none !important;
      padding: 0 !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function ag(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function lg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function cg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function dg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function ug(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (['white', '#fff', '#ffffff', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk'].includes(s)) return true;
          if (['black', '#000', '#000000', 'transparent'].includes(s)) return false;
          if (s.startsWith('#')) {
            let hex = s.slice(1);
            if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return (0.299 * r + 0.587 * g + 0.114 * b) > 140;
            }
          }
          const rgbMatch = s.match(/rgba?\\s*\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)/);
          if (rgbMatch) {
            const r = parseInt(rgbMatch[1], 10);
            const g = parseInt(rgbMatch[2], 10);
            const b = parseInt(rgbMatch[3], 10);
            return (0.299 * r + 0.587 * g + 0.114 * b) > 140;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          if (viewport) viewport.removeAttribute("data-theme");
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function fg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function pg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function hg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function mg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function gg(){return[ag(),lg(),cg(),dg(),ug(),fg(),pg(),hg(),mg()].join("")}function Ql(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let s=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const a=t.inlineAssetBase64Map;s=e.slides.map(r=>{let l=r.rawMarkdown;for(const[f,d]of Object.entries(a))l.includes(f)&&(l=l.split(f).join(d));const c=r.blocks.map(f=>{let d=f.rawMarkdown;for(const[p,k]of Object.entries(a))d.includes(p)&&(d=d.split(p).join(k));return{...f,rawMarkdown:d}});let u=r.frontmatter?{...r.frontmatter}:r.frontmatter;if(u){if(typeof u.background=="string")for(const[f,d]of Object.entries(a))u.background.includes(f)&&(u.background=u.background.split(f).join(d));if(typeof u.image=="string")for(const[f,d]of Object.entries(a))u.image.includes(f)&&(u.image=u.image.split(f).join(d))}return{...r,rawMarkdown:l,blocks:c,frontmatter:u}})}const n=JSON.stringify(s),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(i)}</title>
  <style>
${rg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${n},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${gg()}
  <\/script>
</body>
</html>`}function ec(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(i),n=document.createElement("a");return n.href=s,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function vg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function bg(e){const t=vg(e==null?void 0:e.pageRatio);return`
    ${Os(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-default {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-default.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-default.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-default .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-default .pdf-block h1 { color: #10b981; }
    .slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-left: 4px solid #059669;
      padding-left: 12px;
    }
    .theme-dark.slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .theme-dark.slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .theme-dark.slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-left-color: #10b981;
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 6px;
      display: inline-block;
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function yg(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(["white","#fff","#ffffff","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk"].includes(t))return!0;if(["black","#000","#000000","transparent"].includes(t))return!1;if(t.startsWith("#")){let s=t.slice(1);if(s.length===3&&(s=s.split("").map(n=>n+n).join("")),s.length>=6){const n=parseInt(s.substring(0,2),16),o=parseInt(s.substring(2,4),16),a=parseInt(s.substring(4,6),16);if(!isNaN(n)&&!isNaN(o)&&!isNaN(a))return .299*n+.587*o+.114*a>140}}const i=t.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(i){const s=parseInt(i[1],10),n=parseInt(i[2],10),o=parseInt(i[3],10);return .299*s+.587*n+.114*o>140}return null}function kg(e,t){const i="即现演示讲义",s="16:9",n="light",o=e.config.theme||"default",a=e.slides.map((r,l)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,f=u&&u!=="inherit"?u:e.config.spacing||"normal",d=Xl(r),p=`${l+1} / ${e.slides.length}`,k=r.frontmatter.background||e.config.background,m=yg(k),b=m===!0?"light":m===!1?"dark":n,y=k&&!/^(http|\/|data:|assets\/)/.test(k)?`background: ${nt(k)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${b} spacing-${f} slides-theme-${o}" data-slides-theme="${o}" style="${y}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${p}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(i)} - 高保真讲义</title>
  <style>
    ${bg({pageRatio:s,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${a}
</body>
</html>`}function tc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const i=kg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(n=o.contentWindow)==null?void 0:n.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const s=window.open("","_blank");return s?(s.document.write(i),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}var cn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function wg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function dn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var go={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var ha;function xg(){return ha||(ha=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(s,n,o){function a(c,u){if(!n[c]){if(!s[c]){var f=typeof dn=="function"&&dn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var d=new Error("Cannot find module '"+c+"'");throw d.code="MODULE_NOT_FOUND",d}var p=n[c]={exports:{}};s[c][0].call(p.exports,function(k){var m=s[c][1][k];return a(m||k)},p,p.exports,i,s,n,o)}return n[c].exports}for(var r=typeof dn=="function"&&dn,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,s,n){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(l){for(var c,u,f,d,p,k,m,b=[],y=0,v=l.length,w=v,S=o.getTypeOf(l)!=="string";y<l.length;)w=v-y,f=S?(c=l[y++],u=y<v?l[y++]:0,y<v?l[y++]:0):(c=l.charCodeAt(y++),u=y<v?l.charCodeAt(y++):0,y<v?l.charCodeAt(y++):0),d=c>>2,p=(3&c)<<4|u>>4,k=1<w?(15&u)<<2|f>>6:64,m=2<w?63&f:64,b.push(r.charAt(d)+r.charAt(p)+r.charAt(k)+r.charAt(m));return b.join("")},n.decode=function(l){var c,u,f,d,p,k,m=0,b=0,y="data:";if(l.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var v,w=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&w--,l.charAt(l.length-2)===r.charAt(64)&&w--,w%1!=0)throw new Error("Invalid base64 input, bad content length.");for(v=a.uint8array?new Uint8Array(0|w):new Array(0|w);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(d=r.indexOf(l.charAt(m++)))>>4,u=(15&d)<<4|(p=r.indexOf(l.charAt(m++)))>>2,f=(3&p)<<6|(k=r.indexOf(l.charAt(m++))),v[b++]=c,p!==64&&(v[b++]=u),k!==64&&(v[b++]=f);return v}},{"./support":30,"./utils":32}],2:[function(i,s,n){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,f,d,p,k){this.compressedSize=u,this.uncompressedSize=f,this.crc32=d,this.compression=p,this.compressedContent=k}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,d){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(f.compressWorker(d)).pipe(new l("compressedSize")).withStreamInfo("compression",f)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,s,n){var o=i("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},n.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,s,n){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();s.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,f,d){var p=a,k=d+f;c^=-1;for(var m=d;m<k;m++)c=c>>>8^p[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,f,d){var p=a,k=d+f;c^=-1;for(var m=d;m<k;m++)c=c>>>8^p[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(i,s,n){var o=null;o=typeof Promise<"u"?Promise:i("lie"),s.exports={Promise:o}},{lie:37}],7:[function(i,s,n){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(f,d){l.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=d,this.meta={}}n.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(d){f.push({data:d,meta:f.meta})}},n.compressWorker=function(f){return new u("Deflate",f)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,s,n){function o(p,k){var m,b="";for(m=0;m<k;m++)b+=String.fromCharCode(255&p),p>>>=8;return b}function a(p,k,m,b,y,v){var w,S,B=p.file,A=p.compression,C=v!==c.utf8encode,L=r.transformTo("string",v(B.name)),z=r.transformTo("string",c.utf8encode(B.name)),N=B.comment,K=r.transformTo("string",v(N)),_=r.transformTo("string",c.utf8encode(N)),U=z.length!==B.name.length,x=_.length!==N.length,q="",O="",$="",T=B.dir,P=B.date,ne={crc32:0,compressedSize:0,uncompressedSize:0};k&&!m||(ne.crc32=p.crc32,ne.compressedSize=p.compressedSize,ne.uncompressedSize=p.uncompressedSize);var V=0;k&&(V|=8),C||!U&&!x||(V|=2048);var Y=0,ce=0;T&&(Y|=16),y==="UNIX"?(ce=798,Y|=(function(re,Se){var Ie=re;return re||(Ie=Se?16893:33204),(65535&Ie)<<16})(B.unixPermissions,T)):(ce=20,Y|=(function(re){return 63&(re||0)})(B.dosPermissions)),w=P.getUTCHours(),w<<=6,w|=P.getUTCMinutes(),w<<=5,w|=P.getUTCSeconds()/2,S=P.getUTCFullYear()-1980,S<<=4,S|=P.getUTCMonth()+1,S<<=5,S|=P.getUTCDate(),U&&(O=o(1,1)+o(u(L),4)+z,q+="up"+o(O.length,2)+O),x&&($=o(1,1)+o(u(K),4)+_,q+="uc"+o($.length,2)+$);var ie="";return ie+=`
\0`,ie+=o(V,2),ie+=A.magic,ie+=o(w,2),ie+=o(S,2),ie+=o(ne.crc32,4),ie+=o(ne.compressedSize,4),ie+=o(ne.uncompressedSize,4),ie+=o(L.length,2),ie+=o(q.length,2),{fileRecord:f.LOCAL_FILE_HEADER+ie+L+q,dirRecord:f.CENTRAL_FILE_HEADER+o(ce,2)+ie+o(K.length,2)+"\0\0\0\0"+o(Y,4)+o(b,4)+L+q+K}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),f=i("../signature");function d(p,k,m,b){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=p,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(d,l),d.prototype.push=function(p){var k=p.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(p):(this.bytesWritten+=p.data.length,l.prototype.push.call(this,{data:p.data,meta:{currentFile:this.currentFile,percent:m?(k+100*(m-b-1))/m:100}}))},d.prototype.openedSource=function(p){this.currentSourceOffset=this.bytesWritten,this.currentFile=p.file.name;var k=this.streamFiles&&!p.file.dir;if(k){var m=a(p,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},d.prototype.closedSource=function(p){this.accumulate=!1;var k=this.streamFiles&&!p.file.dir,m=a(p,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),k)this.push({data:(function(b){return f.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(p),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},d.prototype.flush=function(){for(var p=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var m=this.bytesWritten-p,b=(function(y,v,w,S,B){var A=r.transformTo("string",B(S));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(v,4)+o(w,4)+o(A.length,2)+A})(this.dirRecords.length,m,p,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},d.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},d.prototype.registerPrevious=function(p){this._sources.push(p);var k=this;return p.on("data",function(m){k.processChunk(m)}),p.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),p.on("error",function(m){k.error(m)}),this},d.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},d.prototype.error=function(p){var k=this._sources;if(!l.prototype.error.call(this,p))return!1;for(var m=0;m<k.length;m++)try{k[m].error(p)}catch{}return!0},d.prototype.lock=function(){l.prototype.lock.call(this);for(var p=this._sources,k=0;k<p.length;k++)p[k].lock()},s.exports=d},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,s,n){var o=i("../compressions"),a=i("./ZipFileWorker");n.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),f=0;try{r.forEach(function(d,p){f++;var k=(function(v,w){var S=v||w,B=o[S];if(!B)throw new Error(S+" is not a valid compression method !");return B})(p.options.compression,l.compression),m=p.options.compressionOptions||l.compressionOptions||{},b=p.dir,y=p.date;p._compressWorker(k,m).withStreamInfo("file",{name:d,dir:b,date:y,comment:p.comment||"",unixPermissions:p.unixPermissions,dosPermissions:p.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(d){u.error(d)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,s,n){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),s.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,s,n){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function f(d){return new a.Promise(function(p,k){var m=d.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){k(b)}).on("end",function(){m.streamInfo.crc32!==d.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):p()}).resume()})}s.exports=function(d,p){var k=this;return p=o.extend(p||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(d)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",d,!0,p.optimizedBinaryString,p.base64).then(function(m){var b=new l(p);return b.load(m),b}).then(function(m){var b=[a.Promise.resolve(m)],y=m.files;if(p.checkCRC32)for(var v=0;v<y.length;v++)b.push(f(y[v]));return a.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,v=0;v<y.length;v++){var w=y[v],S=w.fileNameStr,B=o.resolve(w.fileNameStr);k.file(B,w.decompressed,{binary:!0,optimizedBinaryString:!0,date:w.date,dir:w.dir,comment:w.fileCommentStr.length?w.fileCommentStr:null,unixPermissions:w.unixPermissions,dosPermissions:w.dosPermissions,createFolders:p.createFolders}),w.dir||(k.file(B).unsafeOriginalName=S)}return b.zipComment.length&&(k.comment=b.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,s,n){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,s,n){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(f,d){u.push(f)||u._helper.pause(),c&&c(d)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},s.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,s,n){function o(B,A,C){var L,z=r.getTypeOf(A),N=r.extend(C||{},u);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(B=y(B)),N.createFolders&&(L=b(B))&&v.call(this,L,!0);var K=z==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!K),(A instanceof f&&A.uncompressedSize===0||N.dir||!A||A.length===0)&&(N.base64=!1,N.binary=!0,A="",N.compression="STORE",z="string");var _=null;_=A instanceof f||A instanceof l?A:k.isNode&&k.isStream(A)?new m(B,A):r.prepareContent(B,A,N.binary,N.optimizedBinaryString,N.base64);var U=new d(B,_,N);this.files[B]=U}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),f=i("./compressedObject"),d=i("./zipObject"),p=i("./generate"),k=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function(B){B.slice(-1)==="/"&&(B=B.substring(0,B.length-1));var A=B.lastIndexOf("/");return 0<A?B.substring(0,A):""},y=function(B){return B.slice(-1)!=="/"&&(B+="/"),B},v=function(B,A){return A=A!==void 0?A:u.createFolders,B=y(B),this.files[B]||o.call(this,B,null,{dir:!0,createFolders:A}),this.files[B]};function w(B){return Object.prototype.toString.call(B)==="[object RegExp]"}var S={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(B){var A,C,L;for(A in this.files)L=this.files[A],(C=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&B(C,L)},filter:function(B){var A=[];return this.forEach(function(C,L){B(C,L)&&A.push(L)}),A},file:function(B,A,C){if(arguments.length!==1)return B=this.root+B,o.call(this,B,A,C),this;if(w(B)){var L=B;return this.filter(function(N,K){return!K.dir&&L.test(N)})}var z=this.files[this.root+B];return z&&!z.dir?z:null},folder:function(B){if(!B)return this;if(w(B))return this.filter(function(z,N){return N.dir&&B.test(z)});var A=this.root+B,C=v.call(this,A),L=this.clone();return L.root=C.name,L},remove:function(B){B=this.root+B;var A=this.files[B];if(A||(B.slice(-1)!=="/"&&(B+="/"),A=this.files[B]),A&&!A.dir)delete this.files[B];else for(var C=this.filter(function(z,N){return N.name.slice(0,B.length)===B}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(B){var A,C={};try{if((C=r.extend(B||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";A=p.generateWorker(this,C,L)}catch(z){(A=new l("error")).error(z)}return new c(A,C.type||"string",C.mimeType)},generateAsync:function(B,A){return this.generateInternalStream(B).accumulate(A)},generateNodeStream:function(B,A){return(B=B||{}).type||(B.type="nodebuffer"),this.generateInternalStream(B).toNodejsStream(A)}};s.exports=S},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,s,n){s.exports=i("stream")},{stream:void 0}],17:[function(i,s,n){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),d=this.length-4;0<=d;--d)if(this.data[d]===l&&this.data[d+1]===c&&this.data[d+2]===u&&this.data[d+3]===f)return d-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),d=this.readData(4);return l===d[0]&&c===d[1]&&u===d[2]&&f===d[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,s,n){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},s.exports=a},{"../utils":32}],19:[function(i,s,n){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,s,n){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,s,n){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,s,n){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");s.exports=function(f){var d=o.getTypeOf(f);return o.checkSupport(d),d!=="string"||a.uint8array?d==="nodebuffer"?new c(f):a.uint8array?new u(o.transformTo("uint8array",f)):new r(o.transformTo("array",f)):new l(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,s,n){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},s.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,s,n){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},s.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,s,n){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},s.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,s,n){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,s,n){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},s.exports=o},{}],29:[function(i,s,n){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function d(k,m){return new u.Promise(function(b,y){var v=[],w=k._internalType,S=k._outputType,B=k._mimeType;k.on("data",function(A,C){v.push(A),m&&m(C)}).on("error",function(A){v=[],y(A)}).on("end",function(){try{var A=(function(C,L,z){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",L),z);case"base64":return l.encode(L);default:return o.transformTo(C,L)}})(S,(function(C,L){var z,N=0,K=null,_=0;for(z=0;z<L.length;z++)_+=L[z].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(K=new Uint8Array(_),z=0;z<L.length;z++)K.set(L[z],N),N+=L[z].length;return K;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(w,v),B);b(A)}catch(C){y(C)}v=[]}).resume()})}function p(k,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=k.pipe(new a(y)),k.lock()}catch(v){this._worker=new r("error"),this._worker.error(v)}}p.prototype={accumulate:function(k){return d(this,k)},on:function(k,m){var b=this;return k==="data"?this._worker.on(k,function(y){m.call(b,y.data,y.meta)}):this._worker.on(k,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},k)}},s.exports=p},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var o=new ArrayBuffer(0);try{n.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),n.blob=a.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!i("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(i,s,n){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){l.call(this,"utf-8 decode"),this.leftOver=null}function d(){l.call(this,"utf-8 encode")}n.utf8encode=function(p){return a.nodebuffer?r.newBufferFrom(p,"utf-8"):(function(k){var m,b,y,v,w,S=k.length,B=0;for(v=0;v<S;v++)(64512&(b=k.charCodeAt(v)))==55296&&v+1<S&&(64512&(y=k.charCodeAt(v+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),v++),B+=b<128?1:b<2048?2:b<65536?3:4;for(m=a.uint8array?new Uint8Array(B):new Array(B),v=w=0;w<B;v++)(64512&(b=k.charCodeAt(v)))==55296&&v+1<S&&(64512&(y=k.charCodeAt(v+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),v++),b<128?m[w++]=b:(b<2048?m[w++]=192|b>>>6:(b<65536?m[w++]=224|b>>>12:(m[w++]=240|b>>>18,m[w++]=128|b>>>12&63),m[w++]=128|b>>>6&63),m[w++]=128|63&b);return m})(p)},n.utf8decode=function(p){return a.nodebuffer?o.transformTo("nodebuffer",p).toString("utf-8"):(function(k){var m,b,y,v,w=k.length,S=new Array(2*w);for(m=b=0;m<w;)if((y=k[m++])<128)S[b++]=y;else if(4<(v=c[y]))S[b++]=65533,m+=v-1;else{for(y&=v===2?31:v===3?15:7;1<v&&m<w;)y=y<<6|63&k[m++],v--;1<v?S[b++]=65533:y<65536?S[b++]=y:(y-=65536,S[b++]=55296|y>>10&1023,S[b++]=56320|1023&y)}return S.length!==b&&(S.subarray?S=S.subarray(0,b):S.length=b),o.applyFromCharCode(S)})(p=o.transformTo(a.uint8array?"uint8array":"array",p))},o.inherits(f,l),f.prototype.processChunk=function(p){var k=o.transformTo(a.uint8array?"uint8array":"array",p.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=k;(k=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),k.set(m,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var b=(function(v,w){var S;for((w=w||v.length)>v.length&&(w=v.length),S=w-1;0<=S&&(192&v[S])==128;)S--;return S<0||S===0?w:S+c[v[S]]>w?S:w})(k),y=k;b!==k.length&&(a.uint8array?(y=k.subarray(0,b),this.leftOver=k.subarray(b,k.length)):(y=k.slice(0,b),this.leftOver=k.slice(b,k.length))),this.push({data:n.utf8decode(y),meta:p.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,o.inherits(d,l),d.prototype.processChunk=function(p){this.push({data:n.utf8encode(p.data),meta:p.meta})},n.Utf8EncodeWorker=d},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,s,n){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),n.newBlob=function(m,b){n.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,b,y){var v=[],w=0,S=m.length;if(S<=y)return String.fromCharCode.apply(null,m);for(;w<S;)b==="array"||b==="nodebuffer"?v.push(String.fromCharCode.apply(null,m.slice(w,Math.min(w+y,S)))):v.push(String.fromCharCode.apply(null,m.subarray(w,Math.min(w+y,S)))),w+=y;return v.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function d(m){var b=65536,y=n.getTypeOf(m),v=!0;if(y==="uint8array"?v=f.applyCanBeUsed.uint8array:y==="nodebuffer"&&(v=f.applyCanBeUsed.nodebuffer),v)for(;1<b;)try{return f.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return f.stringifyByChar(m)}function p(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}n.applyFromCharCode=d;var k={};k.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return k.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},k.array={string:d,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},k.arraybuffer={string:function(m){return d(new Uint8Array(m))},array:function(m){return p(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},k.uint8array={string:d,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},k.nodebuffer={string:d,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return k.nodebuffer.uint8array(m).buffer},uint8array:function(m){return p(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,b){if(b=b||"",!m)return b;n.checkSupport(m);var y=n.getTypeOf(b);return k[y][m](b)},n.resolve=function(m){for(var b=m.split("/"),y=[],v=0;v<b.length;v++){var w=b[v];w==="."||w===""&&v!==0&&v!==b.length-1||(w===".."?y.pop():y.push(w))}return y.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var b,y,v="";for(y=0;y<(m||"").length;y++)v+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return v},n.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},n.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},n.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},n.prepareContent=function(m,b,y,v,w){return l.Promise.resolve(b).then(function(S){return o.blob&&(S instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(S))!==-1)&&typeof FileReader<"u"?new l.Promise(function(B,A){var C=new FileReader;C.onload=function(L){B(L.target.result)},C.onerror=function(L){A(L.target.error)},C.readAsArrayBuffer(S)}):S}).then(function(S){var B=n.getTypeOf(S);return B?(B==="arraybuffer"?S=n.transformTo("uint8array",S):B==="string"&&(w?S=a.decode(S):y&&v!==!0&&(S=(function(A){return u(A,o.uint8array?new Uint8Array(A.length):new Array(A.length))})(S))),S):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,s,n){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var d=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(d)+", expected "+a.pretty(f)+")")}},isSignature:function(f,d){var p=this.reader.index;this.reader.setIndex(f);var k=this.reader.readString(4)===d;return this.reader.setIndex(p),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),d=c.uint8array?"uint8array":"array",p=a.transformTo(d,f);this.zipComment=this.loadOptions.decodeFileName(p)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,d,p,k=this.zip64EndOfCentralSize-44;0<k;)f=this.reader.readInt(2),d=this.reader.readInt(4),p=this.reader.readData(d),this.zip64ExtensibleData[f]={id:f,length:d,value:p}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,d;for(f=0;f<this.files.length;f++)d=this.files[f],this.reader.setIndex(d.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),d.readLocalPart(this.reader),d.handleUTF8(),d.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var d=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var p=this.centralDirOffset+this.centralDirSize;this.zip64&&(p+=20,p+=12+this.zip64EndOfCentralSize);var k=d-p;if(0<k)this.isSignature(d,r.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(f){this.reader=o(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,s,n){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),f=i("./support");function d(p,k){this.options=p,this.loadOptions=k}d.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(p){var k,m;if(p.skip(22),this.fileNameLength=p.readInt(2),m=p.readInt(2),this.fileName=p.readData(this.fileNameLength),p.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(b){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===b)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,k,p.readData(this.compressedSize))},readCentralPart:function(p){this.versionMadeBy=p.readInt(2),p.skip(2),this.bitFlag=p.readInt(2),this.compressionMethod=p.readString(2),this.date=p.readDate(),this.crc32=p.readInt(4),this.compressedSize=p.readInt(4),this.uncompressedSize=p.readInt(4);var k=p.readInt(2);if(this.extraFieldsLength=p.readInt(2),this.fileCommentLength=p.readInt(2),this.diskNumberStart=p.readInt(2),this.internalFileAttributes=p.readInt(2),this.externalFileAttributes=p.readInt(4),this.localHeaderOffset=p.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");p.skip(k),this.readExtraFields(p),this.parseZIP64ExtraField(p),this.fileComment=p.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var p=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),p==0&&(this.dosPermissions=63&this.externalFileAttributes),p==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var p=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=p.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=p.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=p.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=p.readInt(4))}},readExtraFields:function(p){var k,m,b,y=p.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});p.index+4<y;)k=p.readInt(2),m=p.readInt(2),b=p.readData(m),this.extraFields[k]={id:k,length:m,value:b};p.setIndex(y)},handleUTF8:function(){var p=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var m=a.transformTo(p,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=a.transformTo(p,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var p=this.extraFields[28789];if(p){var k=o(p.value);return k.readInt(1)!==1||l(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(p.length-5))}return null},findExtraFieldUnicodeComment:function(){var p=this.extraFields[25461];if(p){var k=o(p.value);return k.readInt(1)!==1||l(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(p.length-5))}return null}},s.exports=d},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,s,n){function o(k,m,b){this.name=k,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(k){var m=null,b="string";try{if(!k)throw new Error("No output type specified.");var y=(b=k.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var v=!this._dataBinary;v&&!y&&(m=m.pipe(new l.Utf8EncodeWorker)),!v&&y&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(w){(m=new u("error")).error(w)}return new a(m,b,"")},async:function(k,m){return this.internalStream(k).accumulate(m)},nodeStream:function(k,m){return this.internalStream(k||"nodebuffer").toNodejsStream(m)},_compressWorker:function(k,m){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(b,k,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],d=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},p=0;p<f.length;p++)o.prototype[f[p]]=d;s.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,s,n){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(k),f=o.document.createTextNode("");u.observe(f,{characterData:!0}),a=function(){f.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){k(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(k,0)};else{var d=new o.MessageChannel;d.port1.onmessage=k,a=function(){d.port2.postMessage(0)}}var p=[];function k(){var m,b;r=!0;for(var y=p.length;y;){for(b=p,p=[],m=-1;++m<y;)b[m]();y=p.length}r=!1}s.exports=function(m){p.push(m)!==1||r||a()}}).call(this,typeof cn<"u"?cn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,s,n){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==a&&m(this,y)}function d(y,v,w){this.promise=y,typeof v=="function"&&(this.onFulfilled=v,this.callFulfilled=this.otherCallFulfilled),typeof w=="function"&&(this.onRejected=w,this.callRejected=this.otherCallRejected)}function p(y,v,w){o(function(){var S;try{S=v(w)}catch(B){return r.reject(y,B)}S===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,S)})}function k(y){var v=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof v=="function")return function(){v.apply(y,arguments)}}function m(y,v){var w=!1;function S(C){w||(w=!0,r.reject(y,C))}function B(C){w||(w=!0,r.resolve(y,C))}var A=b(function(){v(B,S)});A.status==="error"&&S(A.value)}function b(y,v){var w={};try{w.value=y(v),w.status="success"}catch(S){w.status="error",w.value=S}return w}(s.exports=f).prototype.finally=function(y){if(typeof y!="function")return this;var v=this.constructor;return this.then(function(w){return v.resolve(y()).then(function(){return w})},function(w){return v.resolve(y()).then(function(){throw w})})},f.prototype.catch=function(y){return this.then(null,y)},f.prototype.then=function(y,v){if(typeof y!="function"&&this.state===c||typeof v!="function"&&this.state===l)return this;var w=new this.constructor(a);return this.state!==u?p(w,this.state===c?y:v,this.outcome):this.queue.push(new d(w,y,v)),w},d.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},d.prototype.otherCallFulfilled=function(y){p(this.promise,this.onFulfilled,y)},d.prototype.callRejected=function(y){r.reject(this.promise,y)},d.prototype.otherCallRejected=function(y){p(this.promise,this.onRejected,y)},r.resolve=function(y,v){var w=b(k,v);if(w.status==="error")return r.reject(y,w.value);var S=w.value;if(S)m(y,S);else{y.state=c,y.outcome=v;for(var B=-1,A=y.queue.length;++B<A;)y.queue[B].callFulfilled(v)}return y},r.reject=function(y,v){y.state=l,y.outcome=v;for(var w=-1,S=y.queue.length;++w<S;)y.queue[w].callRejected(v);return y},f.resolve=function(y){return y instanceof this?y:r.resolve(new this(a),y)},f.reject=function(y){var v=new this(a);return r.reject(v,y)},f.all=function(y){var v=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=y.length,S=!1;if(!w)return this.resolve([]);for(var B=new Array(w),A=0,C=-1,L=new this(a);++C<w;)z(y[C],C);return L;function z(N,K){v.resolve(N).then(function(_){B[K]=_,++A!==w||S||(S=!0,r.resolve(L,B))},function(_){S||(S=!0,r.reject(L,_))})}},f.race=function(y){var v=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=y.length,S=!1;if(!w)return this.resolve([]);for(var B=-1,A=new this(a);++B<w;)C=y[B],v.resolve(C).then(function(L){S||(S=!0,r.resolve(A,L))},function(L){S||(S=!0,r.reject(A,L))});var C;return A}},{immediate:36}],38:[function(i,s,n){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),s.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,s,n){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,f=0,d=-1,p=0,k=8;function m(y){if(!(this instanceof m))return new m(y);this.options=a.assign({level:d,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:p,to:""},y||{});var v=this.options;v.raw&&0<v.windowBits?v.windowBits=-v.windowBits:v.gzip&&0<v.windowBits&&v.windowBits<16&&(v.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var w=o.deflateInit2(this.strm,v.level,v.method,v.windowBits,v.memLevel,v.strategy);if(w!==f)throw new Error(l[w]);if(v.header&&o.deflateSetHeader(this.strm,v.header),v.dictionary){var S;if(S=typeof v.dictionary=="string"?r.string2buf(v.dictionary):u.call(v.dictionary)==="[object ArrayBuffer]"?new Uint8Array(v.dictionary):v.dictionary,(w=o.deflateSetDictionary(this.strm,S))!==f)throw new Error(l[w]);this._dict_set=!0}}function b(y,v){var w=new m(v);if(w.push(y,!0),w.err)throw w.msg||l[w.err];return w.result}m.prototype.push=function(y,v){var w,S,B=this.strm,A=this.options.chunkSize;if(this.ended)return!1;S=v===~~v?v:v===!0?4:0,typeof y=="string"?B.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?B.input=new Uint8Array(y):B.input=y,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new a.Buf8(A),B.next_out=0,B.avail_out=A),(w=o.deflate(B,S))!==1&&w!==f)return this.onEnd(w),!(this.ended=!0);B.avail_out!==0&&(B.avail_in!==0||S!==4&&S!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(B.output,B.next_out))):this.onData(a.shrinkBuf(B.output,B.next_out)))}while((0<B.avail_in||B.avail_out===0)&&w!==1);return S===4?(w=o.deflateEnd(this.strm),this.onEnd(w),this.ended=!0,w===f):S!==2||(this.onEnd(f),!(B.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},n.Deflate=m,n.deflate=b,n.deflateRaw=function(y,v){return(v=v||{}).raw=!0,b(y,v)},n.gzip=function(y,v){return(v=v||{}).gzip=!0,b(y,v)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,s,n){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),f=i("./zlib/gzheader"),d=Object.prototype.toString;function p(m){if(!(this instanceof p))return new p(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==l.Z_OK)throw new Error(c[y]);this.header=new f,o.inflateGetHeader(this.strm,this.header)}function k(m,b){var y=new p(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}p.prototype.push=function(m,b){var y,v,w,S,B,A,C=this.strm,L=this.options.chunkSize,z=this.options.dictionary,N=!1;if(this.ended)return!1;v=b===~~b?b:b===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):d.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(L),C.next_out=0,C.avail_out=L),(y=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&z&&(A=typeof z=="string"?r.string2buf(z):d.call(z)==="[object ArrayBuffer]"?new Uint8Array(z):z,y=o.inflateSetDictionary(this.strm,A)),y===l.Z_BUF_ERROR&&N===!0&&(y=l.Z_OK,N=!1),y!==l.Z_STREAM_END&&y!==l.Z_OK)return this.onEnd(y),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&y!==l.Z_STREAM_END&&(C.avail_in!==0||v!==l.Z_FINISH&&v!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(w=r.utf8border(C.output,C.next_out),S=C.next_out-w,B=r.buf2string(C.output,w),C.next_out=S,C.avail_out=L-S,S&&a.arraySet(C.output,C.output,w,S,0),this.onData(B)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&y!==l.Z_STREAM_END);return y===l.Z_STREAM_END&&(v=l.Z_FINISH),v===l.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===l.Z_OK):v!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},p.prototype.onData=function(m){this.chunks.push(m)},p.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=p,n.inflate=k,n.inflateRaw=function(m,b){return(b=b||{}).raw=!0,k(m,b)},n.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,s,n){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(l[f]=u[f])}}return l},n.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,f,d){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+f),d);else for(var p=0;p<f;p++)l[d+p]=c[u+p]},flattenChunks:function(l){var c,u,f,d,p,k;for(c=f=0,u=l.length;c<u;c++)f+=l[c].length;for(k=new Uint8Array(f),c=d=0,u=l.length;c<u;c++)p=l[c],k.set(p,d),d+=p.length;return k}},r={arraySet:function(l,c,u,f,d){for(var p=0;p<f;p++)l[d+p]=c[u+p]},flattenChunks:function(l){return[].concat.apply([],l)}};n.setTyped=function(l){l?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,a)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(o)},{}],42:[function(i,s,n){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,d){if(d<65537&&(f.subarray&&r||!f.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(f,d));for(var p="",k=0;k<d;k++)p+=String.fromCharCode(f[k]);return p}l[254]=l[254]=1,n.string2buf=function(f){var d,p,k,m,b,y=f.length,v=0;for(m=0;m<y;m++)(64512&(p=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(k=f.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(k-56320),m++),v+=p<128?1:p<2048?2:p<65536?3:4;for(d=new o.Buf8(v),m=b=0;b<v;m++)(64512&(p=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(k=f.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(k-56320),m++),p<128?d[b++]=p:(p<2048?d[b++]=192|p>>>6:(p<65536?d[b++]=224|p>>>12:(d[b++]=240|p>>>18,d[b++]=128|p>>>12&63),d[b++]=128|p>>>6&63),d[b++]=128|63&p);return d},n.buf2binstring=function(f){return u(f,f.length)},n.binstring2buf=function(f){for(var d=new o.Buf8(f.length),p=0,k=d.length;p<k;p++)d[p]=f.charCodeAt(p);return d},n.buf2string=function(f,d){var p,k,m,b,y=d||f.length,v=new Array(2*y);for(p=k=0;p<y;)if((m=f[p++])<128)v[k++]=m;else if(4<(b=l[m]))v[k++]=65533,p+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&p<y;)m=m<<6|63&f[p++],b--;1<b?v[k++]=65533:m<65536?v[k++]=m:(m-=65536,v[k++]=55296|m>>10&1023,v[k++]=56320|1023&m)}return u(v,k)},n.utf8border=function(f,d){var p;for((d=d||f.length)>f.length&&(d=f.length),p=d-1;0<=p&&(192&f[p])==128;)p--;return p<0||p===0?d:p+l[f[p]]>d?p:d}},{"./common":41}],43:[function(i,s,n){s.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,s,n){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();s.exports=function(a,r,l,c){var u=o,f=c+l;a^=-1;for(var d=c;d<f;d++)a=a>>>8^u[255&(a^r[d])];return-1^a}},{}],46:[function(i,s,n){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),f=0,d=4,p=0,k=-2,m=-1,b=4,y=2,v=8,w=9,S=286,B=30,A=19,C=2*S+1,L=15,z=3,N=258,K=N+z+1,_=42,U=113,x=1,q=2,O=3,$=4;function T(g,W){return g.msg=u[W],W}function P(g){return(g<<1)-(4<g?9:0)}function ne(g){for(var W=g.length;0<=--W;)g[W]=0}function V(g){var W=g.state,j=W.pending;j>g.avail_out&&(j=g.avail_out),j!==0&&(a.arraySet(g.output,W.pending_buf,W.pending_out,j,g.next_out),g.next_out+=j,W.pending_out+=j,g.total_out+=j,g.avail_out-=j,W.pending-=j,W.pending===0&&(W.pending_out=0))}function Y(g,W){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,W),g.block_start=g.strstart,V(g.strm)}function ce(g,W){g.pending_buf[g.pending++]=W}function ie(g,W){g.pending_buf[g.pending++]=W>>>8&255,g.pending_buf[g.pending++]=255&W}function re(g,W){var j,M,I=g.max_chain_length,R=g.strstart,G=g.prev_length,D=g.nice_match,H=g.strstart>g.w_size-K?g.strstart-(g.w_size-K):0,Z=g.window,te=g.w_mask,se=g.prev,me=g.strstart+N,$e=Z[R+G-1],xe=Z[R+G];g.prev_length>=g.good_match&&(I>>=2),D>g.lookahead&&(D=g.lookahead);do if(Z[(j=W)+G]===xe&&Z[j+G-1]===$e&&Z[j]===Z[R]&&Z[++j]===Z[R+1]){R+=2,j++;do;while(Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&R<me);if(M=N-(me-R),R=me-N,G<M){if(g.match_start=W,D<=(G=M))break;$e=Z[R+G-1],xe=Z[R+G]}}while((W=se[W&te])>H&&--I!=0);return G<=g.lookahead?G:g.lookahead}function Se(g){var W,j,M,I,R,G,D,H,Z,te,se=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=se+(se-K)){for(a.arraySet(g.window,g.window,se,se,0),g.match_start-=se,g.strstart-=se,g.block_start-=se,W=j=g.hash_size;M=g.head[--W],g.head[W]=se<=M?M-se:0,--j;);for(W=j=se;M=g.prev[--W],g.prev[W]=se<=M?M-se:0,--j;);I+=se}if(g.strm.avail_in===0)break;if(G=g.strm,D=g.window,H=g.strstart+g.lookahead,Z=I,te=void 0,te=G.avail_in,Z<te&&(te=Z),j=te===0?0:(G.avail_in-=te,a.arraySet(D,G.input,G.next_in,te,H),G.state.wrap===1?G.adler=l(G.adler,D,te,H):G.state.wrap===2&&(G.adler=c(G.adler,D,te,H)),G.next_in+=te,G.total_in+=te,te),g.lookahead+=j,g.lookahead+g.insert>=z)for(R=g.strstart-g.insert,g.ins_h=g.window[R],g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+z-1])&g.hash_mask,g.prev[R&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=R,R++,g.insert--,!(g.lookahead+g.insert<z)););}while(g.lookahead<K&&g.strm.avail_in!==0)}function Ie(g,W){for(var j,M;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===f)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),j!==0&&g.strstart-j<=g.w_size-K&&(g.match_length=re(g,j)),g.match_length>=z)if(M=r._tr_tally(g,g.strstart-g.match_start,g.match_length-z),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=z){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else M=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(M&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=g.strstart<z-1?g.strstart:z-1,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function _e(g,W){for(var j,M,I;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===f)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=z-1,j!==0&&g.prev_length<g.max_lazy_match&&g.strstart-j<=g.w_size-K&&(g.match_length=re(g,j),g.match_length<=5&&(g.strategy===1||g.match_length===z&&4096<g.strstart-g.match_start)&&(g.match_length=z-1)),g.prev_length>=z&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-z,M=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-z),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=z-1,g.strstart++,M&&(Y(g,!1),g.strm.avail_out===0))return x}else if(g.match_available){if((M=r._tr_tally(g,0,g.window[g.strstart-1]))&&Y(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return x}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(M=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<z-1?g.strstart:z-1,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function fe(g,W,j,M,I){this.good_length=g,this.max_lazy=W,this.nice_length=j,this.max_chain=M,this.func=I}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=v,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*B+1)),this.bl_tree=new a.Buf16(2*(2*A+1)),ne(this.dyn_ltree),ne(this.dyn_dtree),ne(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(L+1),this.heap=new a.Buf16(2*S+1),ne(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*S+1),ne(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(g){var W;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(W=g.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?_:U,g.adler=W.wrap===2?0:1,W.last_flush=f,r._tr_init(W),p):T(g,k)}function E(g){var W=pe(g);return W===p&&(function(j){j.window_size=2*j.w_size,ne(j.head),j.max_lazy_match=o[j.level].max_lazy,j.good_match=o[j.level].good_length,j.nice_match=o[j.level].nice_length,j.max_chain_length=o[j.level].max_chain,j.strstart=0,j.block_start=0,j.lookahead=0,j.insert=0,j.match_length=j.prev_length=z-1,j.match_available=0,j.ins_h=0})(g.state),W}function F(g,W,j,M,I,R){if(!g)return k;var G=1;if(W===m&&(W=6),M<0?(G=0,M=-M):15<M&&(G=2,M-=16),I<1||w<I||j!==v||M<8||15<M||W<0||9<W||R<0||b<R)return T(g,k);M===8&&(M=9);var D=new X;return(g.state=D).strm=g,D.wrap=G,D.gzhead=null,D.w_bits=M,D.w_size=1<<D.w_bits,D.w_mask=D.w_size-1,D.hash_bits=I+7,D.hash_size=1<<D.hash_bits,D.hash_mask=D.hash_size-1,D.hash_shift=~~((D.hash_bits+z-1)/z),D.window=new a.Buf8(2*D.w_size),D.head=new a.Buf16(D.hash_size),D.prev=new a.Buf16(D.w_size),D.lit_bufsize=1<<I+6,D.pending_buf_size=4*D.lit_bufsize,D.pending_buf=new a.Buf8(D.pending_buf_size),D.d_buf=1*D.lit_bufsize,D.l_buf=3*D.lit_bufsize,D.level=W,D.strategy=R,D.method=j,E(g)}o=[new fe(0,0,0,0,function(g,W){var j=65535;for(j>g.pending_buf_size-5&&(j=g.pending_buf_size-5);;){if(g.lookahead<=1){if(Se(g),g.lookahead===0&&W===f)return x;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var M=g.block_start+j;if((g.strstart===0||g.strstart>=M)&&(g.lookahead=g.strstart-M,g.strstart=M,Y(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-K&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=0,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):(g.strstart>g.block_start&&(Y(g,!1),g.strm.avail_out),x)}),new fe(4,4,8,4,Ie),new fe(4,5,16,8,Ie),new fe(4,6,32,32,Ie),new fe(4,4,16,16,_e),new fe(8,16,32,32,_e),new fe(8,16,128,128,_e),new fe(8,32,128,256,_e),new fe(32,128,258,1024,_e),new fe(32,258,258,4096,_e)],n.deflateInit=function(g,W){return F(g,W,v,15,8,0)},n.deflateInit2=F,n.deflateReset=E,n.deflateResetKeep=pe,n.deflateSetHeader=function(g,W){return g&&g.state?g.state.wrap!==2?k:(g.state.gzhead=W,p):k},n.deflate=function(g,W){var j,M,I,R;if(!g||!g.state||5<W||W<0)return g?T(g,k):k;if(M=g.state,!g.output||!g.input&&g.avail_in!==0||M.status===666&&W!==d)return T(g,g.avail_out===0?-5:k);if(M.strm=g,j=M.last_flush,M.last_flush=W,M.status===_)if(M.wrap===2)g.adler=0,ce(M,31),ce(M,139),ce(M,8),M.gzhead?(ce(M,(M.gzhead.text?1:0)+(M.gzhead.hcrc?2:0)+(M.gzhead.extra?4:0)+(M.gzhead.name?8:0)+(M.gzhead.comment?16:0)),ce(M,255&M.gzhead.time),ce(M,M.gzhead.time>>8&255),ce(M,M.gzhead.time>>16&255),ce(M,M.gzhead.time>>24&255),ce(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),ce(M,255&M.gzhead.os),M.gzhead.extra&&M.gzhead.extra.length&&(ce(M,255&M.gzhead.extra.length),ce(M,M.gzhead.extra.length>>8&255)),M.gzhead.hcrc&&(g.adler=c(g.adler,M.pending_buf,M.pending,0)),M.gzindex=0,M.status=69):(ce(M,0),ce(M,0),ce(M,0),ce(M,0),ce(M,0),ce(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),ce(M,3),M.status=U);else{var G=v+(M.w_bits-8<<4)<<8;G|=(2<=M.strategy||M.level<2?0:M.level<6?1:M.level===6?2:3)<<6,M.strstart!==0&&(G|=32),G+=31-G%31,M.status=U,ie(M,G),M.strstart!==0&&(ie(M,g.adler>>>16),ie(M,65535&g.adler)),g.adler=1}if(M.status===69)if(M.gzhead.extra){for(I=M.pending;M.gzindex<(65535&M.gzhead.extra.length)&&(M.pending!==M.pending_buf_size||(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending!==M.pending_buf_size));)ce(M,255&M.gzhead.extra[M.gzindex]),M.gzindex++;M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),M.gzindex===M.gzhead.extra.length&&(M.gzindex=0,M.status=73)}else M.status=73;if(M.status===73)if(M.gzhead.name){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.name.length?255&M.gzhead.name.charCodeAt(M.gzindex++):0,ce(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.gzindex=0,M.status=91)}else M.status=91;if(M.status===91)if(M.gzhead.comment){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.comment.length?255&M.gzhead.comment.charCodeAt(M.gzindex++):0,ce(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.status=103)}else M.status=103;if(M.status===103&&(M.gzhead.hcrc?(M.pending+2>M.pending_buf_size&&V(g),M.pending+2<=M.pending_buf_size&&(ce(M,255&g.adler),ce(M,g.adler>>8&255),g.adler=0,M.status=U)):M.status=U),M.pending!==0){if(V(g),g.avail_out===0)return M.last_flush=-1,p}else if(g.avail_in===0&&P(W)<=P(j)&&W!==d)return T(g,-5);if(M.status===666&&g.avail_in!==0)return T(g,-5);if(g.avail_in!==0||M.lookahead!==0||W!==f&&M.status!==666){var D=M.strategy===2?(function(H,Z){for(var te;;){if(H.lookahead===0&&(Se(H),H.lookahead===0)){if(Z===f)return x;break}if(H.match_length=0,te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===d?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):M.strategy===3?(function(H,Z){for(var te,se,me,$e,xe=H.window;;){if(H.lookahead<=N){if(Se(H),H.lookahead<=N&&Z===f)return x;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=z&&0<H.strstart&&(se=xe[me=H.strstart-1])===xe[++me]&&se===xe[++me]&&se===xe[++me]){$e=H.strstart+N;do;while(se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&se===xe[++me]&&me<$e);H.match_length=N-($e-me),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=z?(te=r._tr_tally(H,1,H.match_length-z),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===d?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):o[M.level].func(M,W);if(D!==O&&D!==$||(M.status=666),D===x||D===O)return g.avail_out===0&&(M.last_flush=-1),p;if(D===q&&(W===1?r._tr_align(M):W!==5&&(r._tr_stored_block(M,0,0,!1),W===3&&(ne(M.head),M.lookahead===0&&(M.strstart=0,M.block_start=0,M.insert=0))),V(g),g.avail_out===0))return M.last_flush=-1,p}return W!==d?p:M.wrap<=0?1:(M.wrap===2?(ce(M,255&g.adler),ce(M,g.adler>>8&255),ce(M,g.adler>>16&255),ce(M,g.adler>>24&255),ce(M,255&g.total_in),ce(M,g.total_in>>8&255),ce(M,g.total_in>>16&255),ce(M,g.total_in>>24&255)):(ie(M,g.adler>>>16),ie(M,65535&g.adler)),V(g),0<M.wrap&&(M.wrap=-M.wrap),M.pending!==0?p:1)},n.deflateEnd=function(g){var W;return g&&g.state?(W=g.state.status)!==_&&W!==69&&W!==73&&W!==91&&W!==103&&W!==U&&W!==666?T(g,k):(g.state=null,W===U?T(g,-3):p):k},n.deflateSetDictionary=function(g,W){var j,M,I,R,G,D,H,Z,te=W.length;if(!g||!g.state||(R=(j=g.state).wrap)===2||R===1&&j.status!==_||j.lookahead)return k;for(R===1&&(g.adler=l(g.adler,W,te,0)),j.wrap=0,te>=j.w_size&&(R===0&&(ne(j.head),j.strstart=0,j.block_start=0,j.insert=0),Z=new a.Buf8(j.w_size),a.arraySet(Z,W,te-j.w_size,j.w_size,0),W=Z,te=j.w_size),G=g.avail_in,D=g.next_in,H=g.input,g.avail_in=te,g.next_in=0,g.input=W,Se(j);j.lookahead>=z;){for(M=j.strstart,I=j.lookahead-(z-1);j.ins_h=(j.ins_h<<j.hash_shift^j.window[M+z-1])&j.hash_mask,j.prev[M&j.w_mask]=j.head[j.ins_h],j.head[j.ins_h]=M,M++,--I;);j.strstart=M,j.lookahead=z-1,Se(j)}return j.strstart+=j.lookahead,j.block_start=j.strstart,j.insert=j.lookahead,j.lookahead=0,j.match_length=j.prev_length=z-1,j.match_available=0,g.next_in=D,g.input=H,g.avail_in=G,j.wrap=R,p},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,s,n){s.exports=function(o,a){var r,l,c,u,f,d,p,k,m,b,y,v,w,S,B,A,C,L,z,N,K,_,U,x,q;r=o.state,l=o.next_in,x=o.input,c=l+(o.avail_in-5),u=o.next_out,q=o.output,f=u-(a-o.avail_out),d=u+(o.avail_out-257),p=r.dmax,k=r.wsize,m=r.whave,b=r.wnext,y=r.window,v=r.hold,w=r.bits,S=r.lencode,B=r.distcode,A=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{w<15&&(v+=x[l++]<<w,w+=8,v+=x[l++]<<w,w+=8),L=S[v&A];t:for(;;){if(v>>>=z=L>>>24,w-=z,(z=L>>>16&255)===0)q[u++]=65535&L;else{if(!(16&z)){if((64&z)==0){L=S[(65535&L)+(v&(1<<z)-1)];continue t}if(32&z){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&L,(z&=15)&&(w<z&&(v+=x[l++]<<w,w+=8),N+=v&(1<<z)-1,v>>>=z,w-=z),w<15&&(v+=x[l++]<<w,w+=8,v+=x[l++]<<w,w+=8),L=B[v&C];i:for(;;){if(v>>>=z=L>>>24,w-=z,!(16&(z=L>>>16&255))){if((64&z)==0){L=B[(65535&L)+(v&(1<<z)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&L,w<(z&=15)&&(v+=x[l++]<<w,(w+=8)<z&&(v+=x[l++]<<w,w+=8)),p<(K+=v&(1<<z)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(v>>>=z,w-=z,(z=u-f)<K){if(m<(z=K-z)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(U=y,(_=0)===b){if(_+=k-z,z<N){for(N-=z;q[u++]=y[_++],--z;);_=u-K,U=q}}else if(b<z){if(_+=k+b-z,(z-=b)<N){for(N-=z;q[u++]=y[_++],--z;);if(_=0,b<N){for(N-=z=b;q[u++]=y[_++],--z;);_=u-K,U=q}}}else if(_+=b-z,z<N){for(N-=z;q[u++]=y[_++],--z;);_=u-K,U=q}for(;2<N;)q[u++]=U[_++],q[u++]=U[_++],q[u++]=U[_++],N-=3;N&&(q[u++]=U[_++],1<N&&(q[u++]=U[_++]))}else{for(_=u-K;q[u++]=q[_++],q[u++]=q[_++],q[u++]=q[_++],2<(N-=3););N&&(q[u++]=q[_++],1<N&&(q[u++]=q[_++]))}break}}break}}while(l<c&&u<d);l-=N=w>>3,v&=(1<<(w-=N<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<d?d-u+257:257-(u-d),r.hold=v,r.bits=w}},{}],49:[function(i,s,n){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,f=2,d=0,p=-2,k=1,m=852,b=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function v(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function w(_){var U;return _&&_.state?(U=_.state,_.total_in=_.total_out=U.total=0,_.msg="",U.wrap&&(_.adler=1&U.wrap),U.mode=k,U.last=0,U.havedict=0,U.dmax=32768,U.head=null,U.hold=0,U.bits=0,U.lencode=U.lendyn=new o.Buf32(m),U.distcode=U.distdyn=new o.Buf32(b),U.sane=1,U.back=-1,d):p}function S(_){var U;return _&&_.state?((U=_.state).wsize=0,U.whave=0,U.wnext=0,w(_)):p}function B(_,U){var x,q;return _&&_.state?(q=_.state,U<0?(x=0,U=-U):(x=1+(U>>4),U<48&&(U&=15)),U&&(U<8||15<U)?p:(q.window!==null&&q.wbits!==U&&(q.window=null),q.wrap=x,q.wbits=U,S(_))):p}function A(_,U){var x,q;return _?(q=new v,(_.state=q).window=null,(x=B(_,U))!==d&&(_.state=null),x):p}var C,L,z=!0;function N(_){if(z){var U;for(C=new o.Buf32(512),L=new o.Buf32(32),U=0;U<144;)_.lens[U++]=8;for(;U<256;)_.lens[U++]=9;for(;U<280;)_.lens[U++]=7;for(;U<288;)_.lens[U++]=8;for(c(u,_.lens,0,288,C,0,_.work,{bits:9}),U=0;U<32;)_.lens[U++]=5;c(f,_.lens,0,32,L,0,_.work,{bits:5}),z=!1}_.lencode=C,_.lenbits=9,_.distcode=L,_.distbits=5}function K(_,U,x,q){var O,$=_.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new o.Buf8($.wsize)),q>=$.wsize?(o.arraySet($.window,U,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(q<(O=$.wsize-$.wnext)&&(O=q),o.arraySet($.window,U,x-q,O,$.wnext),(q-=O)?(o.arraySet($.window,U,x-q,q,0),$.wnext=q,$.whave=$.wsize):($.wnext+=O,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=O))),0}n.inflateReset=S,n.inflateReset2=B,n.inflateResetKeep=w,n.inflateInit=function(_){return A(_,15)},n.inflateInit2=A,n.inflate=function(_,U){var x,q,O,$,T,P,ne,V,Y,ce,ie,re,Se,Ie,_e,fe,X,pe,E,F,g,W,j,M,I=0,R=new o.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return p;(x=_.state).mode===12&&(x.mode=13),T=_.next_out,O=_.output,ne=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,ce=P,ie=ne,W=d;e:for(;;)switch(x.mode){case k:if(x.wrap===0){x.mode=13;break}for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(2&x.wrap&&V===35615){R[x.check=0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0),Y=V=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&V)<<8)+(V>>8))%31){_.msg="incorrect header check",x.mode=30;break}if((15&V)!=8){_.msg="unknown compression method",x.mode=30;break}if(Y-=4,g=8+(15&(V>>>=4)),x.wbits===0)x.wbits=g;else if(g>x.wbits){_.msg="invalid window size",x.mode=30;break}x.dmax=1<<g,_.adler=x.check=1,x.mode=512&V?10:12,Y=V=0;break;case 2:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.flags=V,(255&x.flags)!=8){_.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){_.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=V>>8&1),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=3;case 3:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.time=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,R[2]=V>>>16&255,R[3]=V>>>24&255,x.check=r(x.check,R,4,0)),Y=V=0,x.mode=4;case 4:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.xflags=255&V,x.head.os=V>>8),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=5;case 5:if(1024&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length=V,x.head&&(x.head.extra_len=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(P<(re=x.length)&&(re=P),re&&(x.head&&(g=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),o.arraySet(x.head.extra,q,$,re,g)),512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,x.length-=re),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(P===0)break e;for(re=0;g=q[$+re++],x.head&&g&&x.length<65536&&(x.head.name+=String.fromCharCode(g)),g&&re<P;);if(512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,g)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(P===0)break e;for(re=0;g=q[$+re++],x.head&&g&&x.length<65536&&(x.head.comment+=String.fromCharCode(g)),g&&re<P;);if(512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,g)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(65535&x.check)){_.msg="header crc mismatch",x.mode=30;break}Y=V=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),_.adler=x.check=0,x.mode=12;break;case 10:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}_.adler=x.check=y(V),Y=V=0,x.mode=11;case 11:if(x.havedict===0)return _.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,2;_.adler=x.check=1,x.mode=12;case 12:if(U===5||U===6)break e;case 13:if(x.last){V>>>=7&Y,Y-=7&Y,x.mode=27;break}for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}switch(x.last=1&V,Y-=1,3&(V>>>=1)){case 0:x.mode=14;break;case 1:if(N(x),x.mode=20,U!==6)break;V>>>=2,Y-=2;break e;case 2:x.mode=17;break;case 3:_.msg="invalid block type",x.mode=30}V>>>=2,Y-=2;break;case 14:for(V>>>=7&Y,Y-=7&Y;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((65535&V)!=(V>>>16^65535)){_.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&V,Y=V=0,x.mode=15,U===6)break e;case 15:x.mode=16;case 16:if(re=x.length){if(P<re&&(re=P),ne<re&&(re=ne),re===0)break e;o.arraySet(O,q,$,re,T),P-=re,$+=re,ne-=re,T+=re,x.length-=re;break}x.mode=12;break;case 17:for(;Y<14;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.nlen=257+(31&V),V>>>=5,Y-=5,x.ndist=1+(31&V),V>>>=5,Y-=5,x.ncode=4+(15&V),V>>>=4,Y-=4,286<x.nlen||30<x.ndist){_.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.lens[G[x.have++]]=7&V,V>>>=3,Y-=3}for(;x.have<19;)x.lens[G[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,j={bits:x.lenbits},W=c(0,x.lens,0,19,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(X<16)V>>>=_e,Y-=_e,x.lens[x.have++]=X;else{if(X===16){for(M=_e+2;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V>>>=_e,Y-=_e,x.have===0){_.msg="invalid bit length repeat",x.mode=30;break}g=x.lens[x.have-1],re=3+(3&V),V>>>=2,Y-=2}else if(X===17){for(M=_e+3;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,re=3+(7&(V>>>=_e)),V>>>=3,Y-=3}else{for(M=_e+7;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,re=11+(127&(V>>>=_e)),V>>>=7,Y-=7}if(x.have+re>x.nlen+x.ndist){_.msg="invalid bit length repeat",x.mode=30;break}for(;re--;)x.lens[x.have++]=g}}if(x.mode===30)break;if(x.lens[256]===0){_.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,j={bits:x.lenbits},W=c(u,x.lens,0,x.nlen,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,j={bits:x.distbits},W=c(f,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,j),x.distbits=j.bits,W){_.msg="invalid distances set",x.mode=30;break}if(x.mode=20,U===6)break e;case 20:x.mode=21;case 21:if(6<=P&&258<=ne){_.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,l(_,ie),T=_.next_out,O=_.output,ne=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(fe&&(240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.lencode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,x.length=X,fe===0){x.mode=26;break}if(32&fe){x.back=-1,x.mode=12;break}if(64&fe){_.msg="invalid literal/length code",x.mode=30;break}x.extra=15&fe,x.mode=22;case 22:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;fe=(I=x.distcode[V&(1<<x.distbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.distcode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,64&fe){_.msg="invalid distance code",x.mode=30;break}x.offset=X,x.extra=15&fe,x.mode=24;case 24:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.offset+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){_.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(ne===0)break e;if(re=ie-ne,x.offset>re){if((re=x.offset-re)>x.whave&&x.sane){_.msg="invalid distance too far back",x.mode=30;break}Se=re>x.wnext?(re-=x.wnext,x.wsize-re):x.wnext-re,re>x.length&&(re=x.length),Ie=x.window}else Ie=O,Se=T-x.offset,re=x.length;for(ne<re&&(re=ne),ne-=re,x.length-=re;O[T++]=Ie[Se++],--re;);x.length===0&&(x.mode=21);break;case 26:if(ne===0)break e;O[T++]=x.length,ne--,x.mode=21;break;case 27:if(x.wrap){for(;Y<32;){if(P===0)break e;P--,V|=q[$++]<<Y,Y+=8}if(ie-=ne,_.total_out+=ie,x.total+=ie,ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,T-ie):a(x.check,O,ie,T-ie)),ie=ne,(x.flags?V:y(V))!==x.check){_.msg="incorrect data check",x.mode=30;break}Y=V=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(4294967295&x.total)){_.msg="incorrect length check",x.mode=30;break}Y=V=0}x.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return p}return _.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,(x.wsize||ie!==_.avail_out&&x.mode<30&&(x.mode<27||U!==4))&&K(_,_.output,_.next_out,ie-_.avail_out)?(x.mode=31,-4):(ce-=_.avail_in,ie-=_.avail_out,_.total_in+=ce,_.total_out+=ie,x.total+=ie,x.wrap&&ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,_.next_out-ie):a(x.check,O,ie,_.next_out-ie)),_.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(ce==0&&ie===0||U===4)&&W===d&&(W=-5),W)},n.inflateEnd=function(_){if(!_||!_.state)return p;var U=_.state;return U.window&&(U.window=null),_.state=null,d},n.inflateGetHeader=function(_,U){var x;return _&&_.state?(2&(x=_.state).wrap)==0?p:((x.head=U).done=!1,d):p},n.inflateSetDictionary=function(_,U){var x,q=U.length;return _&&_.state?(x=_.state).wrap!==0&&x.mode!==11?p:x.mode===11&&a(1,U,q,0)!==x.check?-3:K(_,U,q,q)?(x.mode=31,-4):(x.havedict=1,d):p},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,s,n){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(u,f,d,p,k,m,b,y){var v,w,S,B,A,C,L,z,N,K=y.bits,_=0,U=0,x=0,q=0,O=0,$=0,T=0,P=0,ne=0,V=0,Y=null,ce=0,ie=new o.Buf16(16),re=new o.Buf16(16),Se=null,Ie=0;for(_=0;_<=15;_++)ie[_]=0;for(U=0;U<p;U++)ie[f[d+U]]++;for(O=K,q=15;1<=q&&ie[q]===0;q--);if(q<O&&(O=q),q===0)return k[m++]=20971520,k[m++]=20971520,y.bits=1,0;for(x=1;x<q&&ie[x]===0;x++);for(O<x&&(O=x),_=P=1;_<=15;_++)if(P<<=1,(P-=ie[_])<0)return-1;if(0<P&&(u===0||q!==1))return-1;for(re[1]=0,_=1;_<15;_++)re[_+1]=re[_]+ie[_];for(U=0;U<p;U++)f[d+U]!==0&&(b[re[f[d+U]]++]=U);if(C=u===0?(Y=Se=b,19):u===1?(Y=a,ce-=257,Se=r,Ie-=257,256):(Y=l,Se=c,-1),_=x,A=m,T=U=V=0,S=-1,B=(ne=1<<($=O))-1,u===1&&852<ne||u===2&&592<ne)return 1;for(;;){for(L=_-T,N=b[U]<C?(z=0,b[U]):b[U]>C?(z=Se[Ie+b[U]],Y[ce+b[U]]):(z=96,0),v=1<<_-T,x=w=1<<$;k[A+(V>>T)+(w-=v)]=L<<24|z<<16|N|0,w!==0;);for(v=1<<_-1;V&v;)v>>=1;if(v!==0?(V&=v-1,V+=v):V=0,U++,--ie[_]==0){if(_===q)break;_=f[d+b[U]]}if(O<_&&(V&B)!==S){for(T===0&&(T=O),A+=x,P=1<<($=_-T);$+T<q&&!((P-=ie[$+T])<=0);)$++,P<<=1;if(ne+=1<<$,u===1&&852<ne||u===2&&592<ne)return 1;k[S=V&B]=O<<24|$<<16|A-m|0}}return V!==0&&(k[A+V]=_-T<<24|64<<16|0),y.bits=O,0}},{"../utils/common":41}],51:[function(i,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,s,n){var o=i("../utils/common"),a=0,r=1;function l(I){for(var R=I.length;0<=--R;)I[R]=0}var c=0,u=29,f=256,d=f+1+u,p=30,k=19,m=2*d+1,b=15,y=16,v=7,w=256,S=16,B=17,A=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],z=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(d+2));l(K);var _=new Array(2*p);l(_);var U=new Array(512);l(U);var x=new Array(256);l(x);var q=new Array(u);l(q);var O,$,T,P=new Array(p);function ne(I,R,G,D,H){this.static_tree=I,this.extra_bits=R,this.extra_base=G,this.elems=D,this.max_length=H,this.has_stree=I&&I.length}function V(I,R){this.dyn_tree=I,this.max_code=0,this.stat_desc=R}function Y(I){return I<256?U[I]:U[256+(I>>>7)]}function ce(I,R){I.pending_buf[I.pending++]=255&R,I.pending_buf[I.pending++]=R>>>8&255}function ie(I,R,G){I.bi_valid>y-G?(I.bi_buf|=R<<I.bi_valid&65535,ce(I,I.bi_buf),I.bi_buf=R>>y-I.bi_valid,I.bi_valid+=G-y):(I.bi_buf|=R<<I.bi_valid&65535,I.bi_valid+=G)}function re(I,R,G){ie(I,G[2*R],G[2*R+1])}function Se(I,R){for(var G=0;G|=1&I,I>>>=1,G<<=1,0<--R;);return G>>>1}function Ie(I,R,G){var D,H,Z=new Array(b+1),te=0;for(D=1;D<=b;D++)Z[D]=te=te+G[D-1]<<1;for(H=0;H<=R;H++){var se=I[2*H+1];se!==0&&(I[2*H]=Se(Z[se]++,se))}}function _e(I){var R;for(R=0;R<d;R++)I.dyn_ltree[2*R]=0;for(R=0;R<p;R++)I.dyn_dtree[2*R]=0;for(R=0;R<k;R++)I.bl_tree[2*R]=0;I.dyn_ltree[2*w]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function fe(I){8<I.bi_valid?ce(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function X(I,R,G,D){var H=2*R,Z=2*G;return I[H]<I[Z]||I[H]===I[Z]&&D[R]<=D[G]}function pe(I,R,G){for(var D=I.heap[G],H=G<<1;H<=I.heap_len&&(H<I.heap_len&&X(R,I.heap[H+1],I.heap[H],I.depth)&&H++,!X(R,D,I.heap[H],I.depth));)I.heap[G]=I.heap[H],G=H,H<<=1;I.heap[G]=D}function E(I,R,G){var D,H,Z,te,se=0;if(I.last_lit!==0)for(;D=I.pending_buf[I.d_buf+2*se]<<8|I.pending_buf[I.d_buf+2*se+1],H=I.pending_buf[I.l_buf+se],se++,D===0?re(I,H,R):(re(I,(Z=x[H])+f+1,R),(te=C[Z])!==0&&ie(I,H-=q[Z],te),re(I,Z=Y(--D),G),(te=L[Z])!==0&&ie(I,D-=P[Z],te)),se<I.last_lit;);re(I,w,R)}function F(I,R){var G,D,H,Z=R.dyn_tree,te=R.stat_desc.static_tree,se=R.stat_desc.has_stree,me=R.stat_desc.elems,$e=-1;for(I.heap_len=0,I.heap_max=m,G=0;G<me;G++)Z[2*G]!==0?(I.heap[++I.heap_len]=$e=G,I.depth[G]=0):Z[2*G+1]=0;for(;I.heap_len<2;)Z[2*(H=I.heap[++I.heap_len]=$e<2?++$e:0)]=1,I.depth[H]=0,I.opt_len--,se&&(I.static_len-=te[2*H+1]);for(R.max_code=$e,G=I.heap_len>>1;1<=G;G--)pe(I,Z,G);for(H=me;G=I.heap[1],I.heap[1]=I.heap[I.heap_len--],pe(I,Z,1),D=I.heap[1],I.heap[--I.heap_max]=G,I.heap[--I.heap_max]=D,Z[2*H]=Z[2*G]+Z[2*D],I.depth[H]=(I.depth[G]>=I.depth[D]?I.depth[G]:I.depth[D])+1,Z[2*G+1]=Z[2*D+1]=H,I.heap[1]=H++,pe(I,Z,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xe,De){var je,ze,le,ue,Oe,He,We=De.dyn_tree,lt=De.max_code,Et=De.stat_desc.static_tree,Jn=De.stat_desc.has_stree,Xn=De.stat_desc.extra_bits,Qs=De.stat_desc.extra_base,Di=De.stat_desc.max_length,qi=0;for(ue=0;ue<=b;ue++)xe.bl_count[ue]=0;for(We[2*xe.heap[xe.heap_max]+1]=0,je=xe.heap_max+1;je<m;je++)Di<(ue=We[2*We[2*(ze=xe.heap[je])+1]+1]+1)&&(ue=Di,qi++),We[2*ze+1]=ue,lt<ze||(xe.bl_count[ue]++,Oe=0,Qs<=ze&&(Oe=Xn[ze-Qs]),He=We[2*ze],xe.opt_len+=He*(ue+Oe),Jn&&(xe.static_len+=He*(Et[2*ze+1]+Oe)));if(qi!==0){do{for(ue=Di-1;xe.bl_count[ue]===0;)ue--;xe.bl_count[ue]--,xe.bl_count[ue+1]+=2,xe.bl_count[Di]--,qi-=2}while(0<qi);for(ue=Di;ue!==0;ue--)for(ze=xe.bl_count[ue];ze!==0;)lt<(le=xe.heap[--je])||(We[2*le+1]!==ue&&(xe.opt_len+=(ue-We[2*le+1])*We[2*le],We[2*le+1]=ue),ze--)}})(I,R),Ie(Z,$e,I.bl_count)}function g(I,R,G){var D,H,Z=-1,te=R[1],se=0,me=7,$e=4;for(te===0&&(me=138,$e=3),R[2*(G+1)+1]=65535,D=0;D<=G;D++)H=te,te=R[2*(D+1)+1],++se<me&&H===te||(se<$e?I.bl_tree[2*H]+=se:H!==0?(H!==Z&&I.bl_tree[2*H]++,I.bl_tree[2*S]++):se<=10?I.bl_tree[2*B]++:I.bl_tree[2*A]++,Z=H,$e=(se=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4))}function W(I,R,G){var D,H,Z=-1,te=R[1],se=0,me=7,$e=4;for(te===0&&(me=138,$e=3),D=0;D<=G;D++)if(H=te,te=R[2*(D+1)+1],!(++se<me&&H===te)){if(se<$e)for(;re(I,H,I.bl_tree),--se!=0;);else H!==0?(H!==Z&&(re(I,H,I.bl_tree),se--),re(I,S,I.bl_tree),ie(I,se-3,2)):se<=10?(re(I,B,I.bl_tree),ie(I,se-3,3)):(re(I,A,I.bl_tree),ie(I,se-11,7));Z=H,$e=(se=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4)}}l(P);var j=!1;function M(I,R,G,D){ie(I,(c<<1)+(D?1:0),3),(function(H,Z,te,se){fe(H),ce(H,te),ce(H,~te),o.arraySet(H.pending_buf,H.window,Z,te,H.pending),H.pending+=te})(I,R,G)}n._tr_init=function(I){j||((function(){var R,G,D,H,Z,te=new Array(b+1);for(H=D=0;H<u-1;H++)for(q[H]=D,R=0;R<1<<C[H];R++)x[D++]=H;for(x[D-1]=H,H=Z=0;H<16;H++)for(P[H]=Z,R=0;R<1<<L[H];R++)U[Z++]=H;for(Z>>=7;H<p;H++)for(P[H]=Z<<7,R=0;R<1<<L[H]-7;R++)U[256+Z++]=H;for(G=0;G<=b;G++)te[G]=0;for(R=0;R<=143;)K[2*R+1]=8,R++,te[8]++;for(;R<=255;)K[2*R+1]=9,R++,te[9]++;for(;R<=279;)K[2*R+1]=7,R++,te[7]++;for(;R<=287;)K[2*R+1]=8,R++,te[8]++;for(Ie(K,d+1,te),R=0;R<p;R++)_[2*R+1]=5,_[2*R]=Se(R,5);O=new ne(K,C,f+1,d,b),$=new ne(_,L,0,p,b),T=new ne(new Array(0),z,0,k,v)})(),j=!0),I.l_desc=new V(I.dyn_ltree,O),I.d_desc=new V(I.dyn_dtree,$),I.bl_desc=new V(I.bl_tree,T),I.bi_buf=0,I.bi_valid=0,_e(I)},n._tr_stored_block=M,n._tr_flush_block=function(I,R,G,D){var H,Z,te=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(se){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&se.dyn_ltree[2*me]!==0)return a;if(se.dyn_ltree[18]!==0||se.dyn_ltree[20]!==0||se.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(se.dyn_ltree[2*me]!==0)return r;return a})(I)),F(I,I.l_desc),F(I,I.d_desc),te=(function(se){var me;for(g(se,se.dyn_ltree,se.l_desc.max_code),g(se,se.dyn_dtree,se.d_desc.max_code),F(se,se.bl_desc),me=k-1;3<=me&&se.bl_tree[2*N[me]+1]===0;me--);return se.opt_len+=3*(me+1)+5+5+4,me})(I),H=I.opt_len+3+7>>>3,(Z=I.static_len+3+7>>>3)<=H&&(H=Z)):H=Z=G+5,G+4<=H&&R!==-1?M(I,R,G,D):I.strategy===4||Z===H?(ie(I,2+(D?1:0),3),E(I,K,_)):(ie(I,4+(D?1:0),3),(function(se,me,$e,xe){var De;for(ie(se,me-257,5),ie(se,$e-1,5),ie(se,xe-4,4),De=0;De<xe;De++)ie(se,se.bl_tree[2*N[De]+1],3);W(se,se.dyn_ltree,me-1),W(se,se.dyn_dtree,$e-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,te+1),E(I,I.dyn_ltree,I.dyn_dtree)),_e(I),D&&fe(I)},n._tr_tally=function(I,R,G){return I.pending_buf[I.d_buf+2*I.last_lit]=R>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&R,I.pending_buf[I.l_buf+I.last_lit]=255&G,I.last_lit++,R===0?I.dyn_ltree[2*G]++:(I.matches++,R--,I.dyn_ltree[2*(x[G]+f+1)]++,I.dyn_dtree[2*Y(R)]++),I.last_lit===I.lit_bufsize-1},n._tr_align=function(I){ie(I,2,3),re(I,w,K),(function(R){R.bi_valid===16?(ce(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,s,n){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,f,d=1,p={},k=!1,m=a.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(a);b=b&&b.setTimeout?b:a,l={}.toString.call(a.process)==="[object process]"?function(S){process.nextTick(function(){v(S)})}:(function(){if(a.postMessage&&!a.importScripts){var S=!0,B=a.onmessage;return a.onmessage=function(){S=!1},a.postMessage("","*"),a.onmessage=B,S}})()?(f="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",w,!1):a.attachEvent("onmessage",w),function(S){a.postMessage(f+S,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(S){v(S.data)},function(S){u.port2.postMessage(S)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(S){var B=m.createElement("script");B.onreadystatechange=function(){v(S),B.onreadystatechange=null,c.removeChild(B),B=null},c.appendChild(B)}):function(S){setTimeout(v,0,S)},b.setImmediate=function(S){typeof S!="function"&&(S=new Function(""+S));for(var B=new Array(arguments.length-1),A=0;A<B.length;A++)B[A]=arguments[A+1];var C={callback:S,args:B};return p[d]=C,l(d),d++},b.clearImmediate=y}function y(S){delete p[S]}function v(S){if(k)setTimeout(v,0,S);else{var B=p[S];if(B){k=!0;try{(function(A){var C=A.callback,L=A.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})(B)}finally{y(S),k=!1}}}}function w(S){S.source===a&&typeof S.data=="string"&&S.data.indexOf(f)===0&&v(+S.data.slice(f.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cn<"u"?cn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(go)),go.exports}var Sg=xg();const ic=wg(Sg);function sc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function nc(e,t){var i,s,n;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(s=o==null?void 0:o.blocks)==null?void 0:s.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await ds(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((n=o[0])!=null&&n.content))return String(o[0].content).trim()}catch{}return""}async function Cg(e,t,i){var c,u,f;const s=Jw(),n=!!((c=s==null?void 0:s.isPinned)!=null&&c.value),o=String(((u=s==null?void 0:s.pinnedDocId)==null?void 0:u.value)||"");if(n&&o&&i&&i!==o)return;const a=i||(n&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await nc(e,a));const l=sc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const d=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const p of d){const k=p.querySelector(".item__text"),m=((f=k==null?void 0:k.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){k&&(k.textContent=l),p.setAttribute("title",l);break}}}}function Is(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Ei(e,t,i){var n,o;const s=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&s)try{const a=await i.fetchDocumentTitle(s);if(a&&a.trim())return Is(a)}catch{}if(typeof document<"u")try{const a=(s?document.querySelector(`.protyle-title[data-node-id="${s}"] .protyle-title__input`):null)||(s?document.querySelector(`.protyle[data-doc-id="${s}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return Is(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Is(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return Is(l)}return"presentation"}function _g(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),s=document.createElement("a");return s.href=i,s.download=e,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(i),!0}function ma(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function $g(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Wo(e,t){return new Promise(i=>{let s=[],n=null;const o=()=>{n&&(clearTimeout(n),n=null),s.forEach(l=>l()),s=[]};n=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});s.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});s.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function oc(e,t){const i=[],s=Is((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(p=>p()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(p=>{var k;l(),(k=t==null?void 0:t.onProgress)==null||k.call(t,p.current,p.total,p.pageIndex)});o.push(c);const u=e.onCapturePageDone(p=>{l(),(p.mode==="all"||!p.mode)&&i.push({pageIndex:p.pageIndex,dataUrl:p.dataUrl})});o.push(u);const f=async()=>{r();try{if(i.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const p=new ic,k=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of i){const v=String(y.pageIndex).padStart(2,"0"),w=y.dataUrl.split(",")[1];p.file(`slide-${v}.${k}`,w,{base64:!0})}const m=await p.generateAsync({type:"blob",compression:"DEFLATE"}),b=_g(`${s}.zip`,m);n({success:b,total:i.length})}catch(p){n({success:!1,error:(p==null?void 0:p.message)||String(p)})}};o.push(e.onCaptureComplete(f));const d=e.onCaptureError(p=>{r(),n({success:!1,error:p})});o.push(d),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function rc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const s=new Xs;s.attach(i);try{if(await new Promise((n,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);s.onClientReady(()=>{clearTimeout(a),n()})}),s.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Wo(s,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await Ei(e,e.docId);return await oc(s,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{s.detach(),i.remove()}}const Ig=1500,Mg=500,Tg=4,Eg=new Set(["INPUT","TEXTAREA","SELECT"]);function ac(e){const t=e;return!t||!t.tagName?!1:Eg.has(t.tagName)||t.isContentEditable===!0}function Ag(e){let t="",i=!1,s=null,n=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){s&&(clearTimeout(s),s=null),n&&(clearTimeout(n),n=null)}function r(){a(),t="",i=!1,o()}function l(){s&&clearTimeout(s),s=setTimeout(r,Ig)}function c(){s&&(clearTimeout(s),s=null),i=!0,o(),n&&clearTimeout(n),n=setTimeout(r,Mg)}function u(f){if(e.isEnabled&&!e.isEnabled()||ac(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return i||t.length>=Tg||(t+=f.key,o(),l()),!0;if(f.key==="Enter"){if(!t||i)return!1;const p=parseInt(t,10),k=e.getTotalPages();return!isNaN(p)&&p>=1&&k>0&&p<=k?(r(),e.onJump(p),!0):(c(),!0)}return f.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Bg={class:"spm-slides-tab__toolbar"},Dg={class:"spm-slides-tab__nav"},Lg=["disabled"],Pg={class:"spm-page-badge"},Og=["disabled"],Rg=["aria-label"],Ng=["aria-label"],zg={class:"spm-slides-tab__tools"},Hg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Fg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},jg=["src"],Wg=Dt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=zt("plugin"),s=zt("sandboxBridge",new Xs),n=new Zm(s),o=new Bp,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),u=ge(null),f=ge(1),d=ge(1),p=ge(!1),k=ge(!1),m=ge(!1),b=ge("siyuan"),y=ge(""),v=ge(""),w=ge(""),S=ge(!1),B=ge(!1),A=ge(""),C=ge(""),L=ge(!1),z=Ag({getTotalPages:()=>d.value,isEnabled:()=>!k.value,onJump:D=>_(D),onStateChange:D=>{C.value=D.display,L.value=D.invalid}});function N(D){if(D.key==="o"||D.key==="O"){if(k.value||D.isComposing||D.ctrlKey||D.metaKey||D.altKey||ac(D.target))return;D.preventDefault(),K();return}z.handleKeydown(D)&&D.preventDefault()}function K(){var D,H;if(a.value==="pro-cli"){(D=u.value)==null||D.focus(),ae.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}s.toggleOverview(),(H=u.value)==null||H.focus()}function _(D){var H;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):s.navigatePage(D),(H=u.value)==null||H.focus()}const U=ge("/plugins/siyuan-live-slides/slides-client/index.html");let x=null,q=null,O=null,$=null,T=null,P=null,ne=null,V=null;vs(()=>{u.value&&(s.attach(u.value),o.nativeBridge.attach(u.value)),x=s.onSlideChanged((D,H)=>{f.value=D,d.value=H}),q=s.onBlockClicked((D,H)=>{f.value=H,n.setActiveBlockId(D),D||Rs(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(D,H):D&&Gi(D,i==null?void 0:i.app)}),O=s.onOpenInEditor((D,H)=>{f.value=H,n.setActiveBlockId(D),Gi(D,i==null?void 0:i.app)}),$=o.nativeBridge.onPageChanged((D,H)=>{f.value=D,d.value=H}),T=s.onOpenPeekDrawer(async D=>{const H=Zn();if(D.peekType==="siyuan"&&H.enableWebServeJump){let Z=!1;if(V&&V.docId===D.target)Z=!0;else if(V&&V.slides&&V.slides.some(te=>{var se;return(se=te.blocks)==null?void 0:se.some(me=>me.id===D.target)}))Z=!1;else try{const te=await ds(`SELECT id, root_id, type FROM blocks WHERE id = '${D.target}' LIMIT 1`);te&&te.length>0&&(Z=te[0].type==="d"||te[0].id===te[0].root_id)}catch(te){console.warn("[SlidesPreviewTab] detect block type failed:",te)}b.value="web",S.value=!0,v.value=Nl(H.webServeUrl,D.target,{focus:!Z}),w.value=D.title||`${Z?"思源文档":"思源块"}: ${D.target.slice(0,8)}`,k.value=!0,s.freezeKeyboardNav(!0)}else{if(b.value=D.peekType,D.peekType==="siyuan")y.value=D.target,w.value=D.title||`块速览: ${D.target.slice(0,8)}`;else{const Z=ql(D.target);if(Z.external){pe(D.target);return}S.value=!0,v.value=Z.url,w.value=D.title||Z.url}k.value=!0,s.freezeKeyboardNav(!0)}}),P=s.onRequestToggleFullscreen(()=>{F()}),ne=s.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",E)}),Gn(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",E),T&&T(),P&&P(),ne&&ne(),x&&x(),q&&q(),O&&O(),$&&$(),s.detach(),z.clear(),n.destroy(),o.destroy()});async function Y(){if(a.value==="web-sandbox"){if(!V){ae.showMessage("请先在主编辑区打开演示文档");return}ae.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const D=await o.startProMode(V,Co);if(!D.success){ae.showMessage(`无法启动官方 Pro 模式：${D.error}`);return}a.value="pro-cli",r.value=D.port||3030,U.value=D.url,u.value&&o.nativeBridge.attach(u.value),ae.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",U.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&s.attach(u.value),ae.showMessage("已切回内置高保真沙箱")}function ce(){B.value=!B.value,B.value?(A.value=(V==null?void 0:V.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.value)):(A.value="",_e(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ie=0;function re(D){if(k.value||Math.abs(D.deltaY)<Math.abs(D.deltaX)||Math.abs(D.deltaY)<15)return;const H=Date.now();H-ie<280||(ie=H,D.deltaY>0?Ie():Se())}function Se(){if(f.value>1){const D=f.value-1;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):s.navigatePage(D)}}function Ie(){if(f.value<d.value){const D=f.value+1;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):s.navigatePage(D)}}function _e(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function fe(){k.value=!1,s.freezeKeyboardNav(!1)}function X(){fe()}function pe(D){var se,me;const H=/^file:/i.test(D),Z=H||/^[a-zA-Z]:[\\/]/.test(D),te=Tt("electron");if(Z&&typeof((se=te==null?void 0:te.shell)==null?void 0:se.openPath)=="function"){te.shell.openPath(H?Kl(D):D),ae.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=te==null?void 0:te.shell)==null?void 0:me.openExternal)=="function"?te.shell.openExternal(D).catch(()=>{typeof window<"u"&&window.open(D,"_blank")}):typeof window<"u"&&window.open(D,"_blank"),ae.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function E(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function F(){const D=l.value||u.value;D&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):D.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function W(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const D=await Ei(V,i==null?void 0:i.currentDocId,i),H=Ql(V,{title:D});ec(`${D}.html`,H)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${D}.html)`)}function j(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}tc(V)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const M=ge(!1);async function I(){if(M.value){ae.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}M.value=!0;try{ae.showMessage("正在逐页导出幻灯片图片...",2e3);const D=await Ei(V,i==null?void 0:i.currentDocId,i),H=await oc(s,{title:D,onProgress:(Z,te)=>{ae.showMessage(`正在导出幻灯片图片 (${Z} / ${te})...`,1500)}});H.success?ae.showMessage(`🎉 成功导出 ${H.total||0} 张高清图片并保存为 ${D}.zip！`,4e3):ae.showMessage(`导出图片失败：${H.error||"未知异常"}`)}finally{M.value=!1}}async function R(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在导出当前幻灯片图片...",1500);const D=await Wo(s);if(D.success&&D.dataUrl){const H=await Ei(V,i==null?void 0:i.currentDocId,i),Z=f.value||1,se=(d.value||1)>1?`${H}-${Z}.png`:`${H}.png`;ma(se,D.dataUrl),ae.showMessage(`已下载当前页高清图片 (${se})`)}else ae.showMessage(`导出当前页图片失败：${D.error||"未知异常"}`)}async function G(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const D=await Wo(s);if(D.success&&D.dataUrl)if(await $g(D.dataUrl))ae.showMessage(`已成功将第 ${f.value||1} 页幻灯片复制到剪贴板！`);else{const Z=await Ei(V,i==null?void 0:i.currentDocId,i),te=f.value||1,me=(d.value||1)>1?`${Z}-${te}.png`:`${Z}.png`;ma(me,D.dataUrl),ae.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else ae.showMessage(`复制失败：${D.error||"未知异常"}`)}return t({updateDocument(D,H){B.value&&A.value&&H&&H!==A.value||(V=D,B.value&&!A.value&&(A.value=D.docId),d.value=D.slides.length,n.setDocId(D.docId),n.updateSlidesIndex(D.slides),a.value==="pro-cli"?o.scaffolder.scaffold(D,Co).catch(()=>{}):s.updateSlides(D.slides,D.config,D.fullMarkdown,D.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",D.docId))},navigateToBlock(D){n.onCursorFocusBlock(D)},isPinned:B,pinnedDocId:A,engineMode:a,toggleEngineMode:Y}),(D,H)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:N},[h("div",Bg,[h("div",Dg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:Se},[oe(de,{name:"chevron-left"})],8,Lg),h("span",Pg,we(f.value)+" / "+we(d.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=d.value,"aria-label":"下一页",onClick:Ie},[oe(de,{name:"chevron-right"})],8,Og),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":B.value}]),"aria-label":B.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ce},[oe(de,{name:"pin"}),h("span",null,we(B.value?"已锁定":"跟随"),1)],10,Rg),he(gt)("proMode")?(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[oe(de,{name:"rocket"}),h("span",null,we(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Ng)):Te("",!0)]),h("div",zg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[oe(de,{name:"columns"})]),he(gt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[oe(de,{name:"presenter"})])):Te("",!0),he(gt)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:W},[oe(de,{name:"export-html"})])):Te("",!0),he(gt)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:j},[oe(de,{name:"export-pdf"})])):Te("",!0),he(gt)("exportImage")?(J(),ee("div",Hg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:I},[oe(de,{name:"export-image"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:H[0]||(H[0]=Zt(Z=>p.value=!p.value,["stop"]))},[oe(de,{name:"chevron-down"})]),p.value?(J(),ee("div",Fg,[h("button",{class:"b3-menu__item",onClick:H[1]||(H[1]=Z=>{I(),p.value=!1})},[...H[6]||(H[6]=[h("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[2]||(H[2]=Z=>{R(),p.value=!1})},[...H[7]||(H[7]=[h("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[3]||(H[3]=Z=>{G(),p.value=!1})},[...H[8]||(H[8]=[h("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:_e},[oe(de,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:F},[oe(de,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:re},[h("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:U.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,jg),oe(lm,{visible:k.value,"onUpdate:visible":H[4]||(H[4]=Z=>k.value=Z),"is-maximized":m.value,"onUpdate:isMaximized":H[5]||(H[5]=Z=>m.value=Z),title:w.value,onClose:fe},{default:al(()=>[b.value==="siyuan"&&y.value?(J(),Jt(vm,{key:0,"block-id":y.value,title:w.value,plugin:he(i),onExternalJump:X},null,8,["block-id","title","plugin"])):Te("",!0),S.value?Ot((J(),Jt(qm,{key:1,visible:k.value&&b.value==="web",url:v.value,title:w.value,onExternalJump:X},null,8,["visible","url","title"])),[[Ro,b.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ot(h("div",{class:Ce(["spm-jump-badge",{"is-invalid":L.value}])},we(C.value),3),[[Ro,C.value]])],544)],32))}}),Ug=ii(Wg,[["__scopeId","data-v-2bf44815"]]);function lc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,s=new Map;let n=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!s.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const d=parseInt(f,10);n=Math.max(n,d),s.set(r.parentContainerId,d)}else n+=1,s.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&s.has(r.parentContainerId)){const f=s.get(r.parentContainerId);o(r,{type:"step",step:f})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,o(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const d=Math.min(Number(f[0]),Number(f[1])),p=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(d)&&!isNaN(p)){n=Math.max(n,p),o(r,{type:"range",min:d,max:p});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,o(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;n+=f,o(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;n=Math.max(1,n-f),o(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){n=Math.max(n,f),o(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),o(r,{type:"step",step:u})):(n+=1,o(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:i}}function Vg(e,t,i){if(!e)return"v-click-visible";const s=e.id||e.blockId,n=i.blockMap.get(e)||(s?i.idMap.get(s):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Uo=980;function Gg(e){if(!e)return 0;const i=lc(e.blocks||[]).maxStep||0,s=e.frontmatter||{},n=s.mask;if(n!=="down"&&n!=="right")return i;const o=Sd(s.maskRatio),r=s.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Kg(e,t=Uo){const i=(e||"16/9").trim();let s=16/9;if(i==="4/3"||i==="4:3")s=4/3;else if(i==="16/10"||i==="16:10")s=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(s=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(s=o)}const n=Math.ceil(t/s);return{baseWidth:t,baseHeight:n,ratio:s}}function ga(e,t,i=Uo,s=552,n=16){const o=i>0?i:Uo,a=s>0?s:552,r=Math.max(0,e-n),l=Math.max(0,t-n);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function qg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function va(e,t){if(!e)return"";const i=qg(e),s=i.frontmatter||{},n=s.layout||"default",o=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!s.image&&!s.background&&o.image&&(s.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?lc(i.blocks||[]):null,u=Xl(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?w=>{if(Vg(w,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const B=w.id||w.blockId,A=l.blockMap.get(w)||(B?l.idMap.get(B):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(w,S)=>{let B=S.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(B)||(B+=" muted"),`<video ${B.trim()}>`}),f=s.spacing,d=f&&f!=="inherit"?f:o.spacing||"normal",p=["slide-content",`layout-${n}`,`spacing-${d}`,s.class||"",s.layoutClass||""].filter(Boolean).join(" "),k=[],m=(s.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const w=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;k.push(`background-image:url('${nt(w)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else k.push(`background:${nt(m)};`);const b=typeof s.zoom=="number"?s.zoom:typeof s.zoom=="string"?parseFloat(s.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&k.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const v=k.length>0?` style="${k.join("")}"`:"";return`<div class="${nt(p)}"${v}>${u}</div>`}const Yg={class:"presenter-header"},Zg={class:"presenter-title-area"},Jg={class:"presenter-brand"},Xg={class:"header-pills"},Qg={class:"pill pill-page"},ev={key:0,class:"pill pill-step"},tv={class:"header-toolbar"},iv={class:"timer-capsule"},sv={class:"timer-digits"},nv={class:"timer-actions"},ov=["aria-label"],rv={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},av={key:0,class:"presenter-grid"},lv={class:"slide-panels"},cv={class:"panel-box current-slide-panel"},dv={class:"panel-header"},uv={class:"panel-header-left"},fv={class:"panel-page-num"},pv={class:"panel-header-meta"},hv={key:0,class:"panel-step-pill"},mv={class:"panel-layout-pill"},gv=["aria-label"],vv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],bv={key:1,class:"panel-fallback"},yv=["aria-label"],kv={class:"panel-header"},wv={class:"panel-header-left"},xv={key:0,class:"panel-page-num"},Sv={class:"panel-header-meta"},Cv={key:0,class:"panel-end-pill"},_v={key:1,class:"panel-layout-pill"},$v=["aria-label"],Iv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Mv={key:1,class:"panel-fallback"},Tv={class:"notes-panel"},Ev={class:"panel-header"},Av={class:"panel-header-left"},Bv={class:"notes-size-controls"},Dv=["disabled"],Lv={class:"notes-size-value"},Pv=["disabled"],Ov={key:1,class:"presenter-empty"},Rv={class:"empty-icon-wrap"},Nv={class:"empty-actions"},zv={class:"presenter-actions"},Hv={class:"nav-btn-group"},Fv=["disabled"],jv=["disabled"],Wv={class:"actions-center"},Uv={class:"center-meta"},Vv={class:"progress-pill"},Gv={class:"nav-btn-group"},Kv=["aria-label"],qv={class:"step-dots-text"},Yv=["disabled"],Zv=["disabled"],Jv=280,Xv=15,Qv=Dt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=zt("plugin"),s=zt("sandboxBridge",new Xs),n=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),u=ye(()=>n.value.length||l.value),f=ge(null),d=ge(null),p=ge({width:0,height:0}),k=ge({width:0,height:0}),m=ye(()=>{var le;return Kg((le=o.value)==null?void 0:le.aspectRatio)}),b=ye(()=>{var le;return((le=o.value)==null?void 0:le.theme)||"default"}),y=ye(()=>{var le;return((le=o.value)==null?void 0:le.colorSchema)==="light"?"light":"dark"}),v=ye(()=>{var le;return!!((le=o.value)!=null&&le.normalizeHeadingSizes)}),w=ye(()=>{var le;return((le=o.value)==null?void 0:le.showUnorderedListMarkers)===!1}),S=ye(()=>{var le;return((le=o.value)==null?void 0:le.showOrderedListMarkers)===!1}),B=ye(()=>ga(p.value.width,p.value.height,m.value.baseWidth,m.value.baseHeight,14)),A=ye(()=>ga(k.value.width,k.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){f.value&&(p.value={width:f.value.clientWidth,height:f.value.clientHeight}),d.value&&(k.value={width:d.value.clientWidth,height:d.value.clientHeight})}let L=null;function z(){typeof window>"u"||typeof window.ResizeObserver!="function"||(L||(L=new window.ResizeObserver(()=>{C()})),L.disconnect(),f.value&&L.observe(f.value),d.value&&L.observe(d.value))}Vi([f,d,u],()=>{Mn(()=>{z(),C()})},{flush:"post"});const N=ge(0),K=ge(!0);let _=null,U=Date.now(),x=0;const q=ye(()=>{const le=String(Math.floor(N.value/60)).padStart(2,"0"),ue=String(N.value%60).padStart(2,"0");return`${le}:${ue}`});function O(){if(K.value){const le=x+(Date.now()-U);N.value=Math.floor(le/1e3)}}function $(){K.value?(x+=Date.now()-U,K.value=!1):(U=Date.now(),K.value=!0,O())}function T(){U=Date.now(),x=0,N.value=0}const P=ge("");let ne=null;function V(){const le=new Date,ue=String(le.getHours()).padStart(2,"0"),Oe=String(le.getMinutes()).padStart(2,"0");P.value=`${ue}:${Oe}`}const Y=ye(()=>n.value.length===0?null:n.value[a.value-1]||null),ce=ye(()=>a.value>=n.value.length?null:n.value[a.value]||null),ie=ye(()=>Y.value?Gg(Y.value):c.value),re=ye(()=>a.value>1||r.value>0),Se=ye(()=>a.value<u.value||r.value<ie.value),Ie=ye(()=>va(Y.value,{config:o.value,allSlides:n.value,pageIndex:a.value,currentStep:r.value})),_e=ye(()=>va(ce.value,{config:o.value,allSlides:n.value,pageIndex:a.value+1})),fe=ye(()=>{var ue;if(!Y.value)return"无内容";const le=(ue=Y.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value} 页`});function X(le){return(le||[]).slice(1).map(ue=>(ue.content||ue.rawMarkdown||"").trim()).filter(ue=>ue&&!/^(image\s+)?assets\/\S*$/i.test(ue)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ue)).join(" | ").slice(0,120)}const pe=ye(()=>{var le;return X((le=Y.value)==null?void 0:le.blocks)}),E=ye(()=>{var ue;if(!ce.value)return"演示结束";const le=(ue=ce.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value+1} 页`}),F=ye(()=>ce.value?X(ce.value.blocks):"这是最后一页"),g=ye(()=>{var le;return((le=Y.value)==null?void 0:le.notes)||""}),W=ge(20);function j(){W.value<36&&(W.value+=2)}function M(){W.value>14&&(W.value-=2)}const I=ye(()=>u.value<=1?100:Math.round(a.value/u.value*100));let R=null;try{R=new BroadcastChannel("siyuan-slides-sync"),R.onmessage=le=>{const ue=le.data;if(ue&&(ue.type==="SYNC_PAGE"&&typeof ue.page=="number"&&(a.value=ue.page,r.value=typeof ue.step=="number"?Math.max(0,ue.step):0,typeof ue.maxStep=="number"&&(c.value=Math.max(0,ue.maxStep))),ue.type==="SYNC_SLIDES"&&Array.isArray(ue.slides)&&(n.value=ue.slides,ue.config&&typeof ue.config=="object"&&(o.value=ue.config)),ue.type==="REQUEST_SYNC"&&n.value.length>0))try{R==null||R.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),R==null||R.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:ie.value})}catch{}}}catch{R=null}function G(le,ue=0){const Oe=Number(le)||1,He=Math.max(0,Number(ue)||0);s.navigatePage(Oe,He);try{R==null||R.postMessage({type:"SYNC_PAGE",page:Oe,step:He,maxStep:ie.value})}catch{}}function D(){if(r.value<ie.value){r.value++,G(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,G(a.value,0))}function H(){if(r.value>0){r.value--,G(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,G(a.value,0))}function Z(){a.value<u.value&&(a.value++,r.value=0,G(a.value,0))}function te(){a.value>1&&(a.value--,r.value=0,G(a.value,0))}function se(){a.value=1,r.value=0,T(),G(1,0)}function me(){const le=i;typeof(le==null?void 0:le.openBottomPreviewTab)=="function"&&le.openBottomPreviewTab()}function $e(){const le=i;typeof(le==null?void 0:le.openStandalonePreviewWindow)=="function"&&le.openStandalonePreviewWindow()}function xe(le){var ue,Oe;if(!(le.key===" "&&((Oe=(ue=le.target)==null?void 0:ue.closest)!=null&&Oe.call(ue,"button")))){if(le.shiftKey&&le.key==="ArrowRight"||le.key==="ArrowDown"){le.preventDefault(),Z();return}if(le.shiftKey&&le.key==="ArrowLeft"||le.key==="ArrowUp"){le.preventDefault(),te();return}le.key==="ArrowRight"||le.key===" "||le.key==="PageDown"?(le.preventDefault(),D()):(le.key==="ArrowLeft"||le.key==="PageUp")&&(le.preventDefault(),H())}}let De=0;function je(le){var He,We;if(Math.abs(le.deltaY)<Xv)return;const ue=(We=(He=le.target)==null?void 0:He.closest)==null?void 0:We.call(He,".notes-content");if(ue){const lt=ue.scrollHeight-ue.clientHeight;if(lt>2&&(le.deltaY>0&&ue.scrollTop<lt-1||le.deltaY<0&&ue.scrollTop>1))return}const Oe=Date.now();Oe-De<Jv||(De=Oe,le.deltaY>0?D():H())}let ze=null;return vs(()=>{var ue;U=Date.now(),x=0,_=window.setInterval(O,500),typeof document<"u"&&document.addEventListener("visibilitychange",O),V(),ne=window.setInterval(V,1e3),ze=s.onSlideChanged((Oe,He,We,lt,Et)=>{a.value=Oe,He>0&&(l.value=He),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof Et=="number"&&(c.value=Math.max(0,Et))});try{R==null||R.postMessage({type:"REQUEST_SYNC"})}catch{}const le=i==null?void 0:i.latestCompiledDoc;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(n.value=le.slides,le.config&&(o.value=le.config)),typeof window<"u"&&window.addEventListener("resize",C),Mn(()=>{z(),C()})}),Gn(()=>{_&&(window.clearInterval(_),_=null),typeof document<"u"&&document.removeEventListener("visibilitychange",O),ne&&(window.clearInterval(ne),ne=null),ze&&ze(),typeof window<"u"&&window.removeEventListener("resize",C),L&&(L.disconnect(),L=null);try{R==null||R.close()}catch{}R=null}),t({updateDocument(le){var ue;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(n.value=le.slides),le!=null&&le.config&&(o.value=le.config)}}),(le,ue)=>{var Oe,He,We;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:xe,onWheel:je},[h("header",Yg,[h("div",Zg,[h("div",Jg,[oe(de,{name:"presenter",class:"brand-icon"}),ue[1]||(ue[1]=h("span",{class:"title-name"},"演讲者控制台",-1))]),h("div",Xg,[h("span",Qg,"P."+we(a.value)+" / "+we(u.value||1),1),ie.value>0?(J(),ee("span",ev,[oe(de,{name:"step",class:"pill-icon"}),It(" 步进 "+we(r.value)+" / "+we(ie.value),1)])):Te("",!0)])]),h("div",tv,[h("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:$e},[oe(de,{name:"window"}),ue[2]||(ue[2]=h("span",{class:"btn-tool-label"},"独立放映",-1))]),h("div",iv,[oe(de,{name:"clock",class:"timer-icon"}),h("span",sv,we(q.value),1),h("div",nv,[h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":K.value?"暂停计时":"继续计时",onClick:$},[oe(de,{name:K.value?"pause":"play"},null,8,["name"])],8,ov),h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:T},[oe(de,{name:"reset"})])])]),h("div",rv,[h("span",null,we(P.value),1)])])]),u.value>0?(J(),ee("main",av,[h("section",lv,[h("div",cv,[h("div",dv,[h("div",uv,[ue[3]||(ue[3]=h("span",{class:"panel-tag is-current"},"当前放映",-1)),h("span",fv,"P."+we(a.value),1)]),h("div",pv,[ie.value>0?(J(),ee("span",hv," 步进 "+we(r.value)+" / "+we(ie.value),1)):Te("",!0),h("span",mv,we(((He=(Oe=Y.value)==null?void 0:Oe.frontmatter)==null?void 0:He.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":fe.value},[Y.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:B.value.boxWidth+"px",height:B.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":w.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+B.value.scale+")"}),innerHTML:Ie.value},null,14,vv)],4)):(J(),ee("div",bv,[h("h2",null,we(fe.value),1),h("p",null,we(pe.value),1)]))],8,gv)]),h("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!ce.value,"b3-tooltips b3-tooltips__n":!!ce.value}]),"aria-label":ce.value?"点击直接跳至下一页":"",onClick:ue[0]||(ue[0]=lt=>ce.value&&Z())},[h("div",kv,[h("div",wv,[ue[4]||(ue[4]=h("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(J(),ee("span",xv,"P."+we(a.value+1),1)):Te("",!0)]),h("div",Sv,[a.value>=u.value?(J(),ee("span",Cv,"已到尾页")):ce.value?(J(),ee("span",_v,we(((We=ce.value.frontmatter)==null?void 0:We.layout)||"default"),1)):Te("",!0)])]),h("div",{ref_key:"nextPreviewRef",ref:d,class:"panel-preview panel-preview--dim","aria-label":E.value},[ce.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":w.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:_e.value},null,14,Iv)],4)):(J(),ee("div",Mv,[h("h2",null,we(E.value),1),h("p",null,we(F.value),1)]))],8,$v)],10,yv)]),h("section",Tv,[h("div",Ev,[h("div",Av,[oe(de,{name:"notes",class:"panel-title-icon"}),ue[5]||(ue[5]=h("span",null,"讲稿备忘",-1))]),h("div",Bv,[h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:W.value<=14,onClick:M},[oe(de,{name:"minus"})],8,Dv),h("span",Lv,we(W.value)+"px",1),h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:W.value>=36,onClick:j},[oe(de,{name:"plus"})],8,Pv)])]),h("div",{class:Ce(["notes-content",{"is-empty":!g.value}]),style:Yt({fontSize:W.value+"px"})},we(g.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Ov,[h("div",Rv,[oe(de,{name:"refresh",class:"empty-icon"})]),ue[8]||(ue[8]=h("h2",null,"等待大屏放映数据",-1)),ue[9]||(ue[9]=h("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),h("div",Nv,[h("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:me},[oe(de,{name:"presenter"}),ue[6]||(ue[6]=h("span",null,"打开大屏放映页签",-1))]),h("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:$e},[oe(de,{name:"window"}),ue[7]||(ue[7]=h("span",null,"弹出独立放映窗口",-1))])])])),h("footer",zv,[h("div",Hv,[h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:te},[oe(de,{name:"chevrons-left"}),ue[10]||(ue[10]=h("span",null,"上一页",-1))],8,Fv),h("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!re.value,"aria-label":"回退一步 (←)",onClick:H},[oe(de,{name:"chevron-left"}),ue[11]||(ue[11]=h("span",null,"上一步",-1))],8,jv)]),h("div",Wv,[h("div",Uv,[h("span",Vv,we(I.value)+"%",1)]),h("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:se},[oe(de,{name:"reset"}),ue[12]||(ue[12]=h("span",null,"重头放映",-1))])]),h("div",Gv,[ie.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ie.value}`},[(J(!0),ee(Xe,null,St(ie.value,lt=>(J(),ee("span",{key:lt,class:Ce(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),h("span",qv,we(r.value)+"/"+we(ie.value),1)],8,Kv)):Te("",!0),h("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!Se.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:D},[ue[13]||(ue[13]=h("span",null,"下一步",-1)),oe(de,{name:"chevron-right"})],8,Yv),h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Z},[ue[14]||(ue[14]=h("span",null,"下一页",-1)),oe(de,{name:"chevrons-right"})],8,Zv)])])],32)}}}),eb=ii(Qv,[["__scopeId","data-v-a333656f"]]),tb={class:"spm-layout-picker"},ib={class:"spm-layout-picker__grid"},sb=["title","onClick"],nb={class:"spm-layout-icon"},ob={class:"spm-layout-label"},rb=Dt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,s=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){s("update:modelValue",r),s("change",r)}return(r,l)=>(J(),ee("div",tb,[l[0]||(l[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",ib,[(J(),ee(Xe,null,St(n,c=>h("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[h("div",nb,[oe(de,{name:"layout-"+c.name},null,8,["name"])]),h("span",ob,we(c.label),1)],10,sb)),64))])]))}}),ab=ii(rb,[["__scopeId","data-v-96c8a248"]]),lb={key:0,class:"spm-transition-selector__header"},cb={class:"spm-transition-list"},db=["onClick"],ub={class:"spm-transition-meta"},fb={class:"spm-transition-label"},pb={class:"spm-transition-preview-box"},hb=Dt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(J(),ee("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",lb,we(e.title||"转场动效"),1)),h("div",cb,[(J(),ee(Xe,null,St(s,r=>h("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>n(r.name)},[h("div",ub,[h("span",fb,we(r.label),1)]),h("div",pb,[h("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,db)),64))])],2))}}),cc=ii(hb,[["__scopeId","data-v-b5051f69"]]),mb={class:"spm-section spm-section--page"},gb={class:"spm-section-header"},vb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},bb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},yb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},kb={key:1,class:"spm-card-control"},wb={class:"spm-control-header"},xb={class:"spm-control-title-group"},Sb={class:"spm-control-title"},Cb={class:"spm-quick-chips"},_b=["onClick"],$b={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ib=["value"],Mb=["aria-label"],Tb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Eb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Ab={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Bb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Db={class:"spm-card-control"},Lb={class:"spm-control-header"},Pb={class:"spm-control-title-group"},Ob={class:"spm-control-title"},Rb={class:"spm-segmented-group"},Nb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},zb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Hb=["aria-label"],Fb={class:"spm-quick-chips"},jb=["onClick"],Wb=["value"],Ub={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Vb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Gb={style:{flex:"1"}},Kb={class:"spm-segmented-group"},qb={style:{flex:"1"}},Yb={class:"spm-segmented-group"},Zb={class:"spm-card-control"},Jb={class:"spm-control-header"},Xb={class:"spm-control-title-group"},Qb={class:"spm-control-title"},e1={class:"spm-segmented-group"},t1={key:2,class:"spm-card-control"},i1={class:"spm-control-header"},s1={class:"spm-control-title-group"},n1={class:"spm-control-title"},o1={class:"spm-quick-chips"},r1=["onClick"],a1=["value"],l1={class:"spm-card-control"},c1={class:"spm-control-header"},d1={class:"spm-control-title-group"},u1={class:"spm-control-title"},f1={key:0,class:"spm-note-status-box"},p1=["title"],h1={class:"spm-action-grid",style:{"margin-top":"6px"}},m1={key:1,class:"spm-note-empty-box"},g1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},v1={class:"spm-action-grid"},b1=["disabled"],y1=["disabled"],k1={class:"spm-card-control"},w1={class:"spm-action-grid"},x1=Dt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,s=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const v=i.pageMask;return v==="clockwise"||v==="counter-clockwise"||v==="cw"||v==="ccw"}),a=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||a.value);function l(v){s("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&s("update:pageMaskRatio","1:1:1:1")}function c(v){s("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&s("update:pageMaskRatio","1:1")}const u=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),d=ye(()=>{var S,B;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const v=(i.pageLayoutRatio||"").trim();if(v.includes(":")){const A=v.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const w=(i.detectedSbRatio||"").trim();if(w.includes(":")){const A=w.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((S=i.detectedSbInfo)!=null&&S.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((B=i.detectedSbInfo)!=null&&B.slots&&Array.isArray(i.detectedSbInfo.slots)){const A=i.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),p=ye(()=>{const v=d.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),k=ye(()=>i.pageLayoutRatio||"");function m(){const v=d.value||2,w=Array(v).fill("1").join(":");s("update:pageLayoutRatio",w),s("resetSuperblockRatio")}const b=ye(()=>{if(!i.pageNotes)return"";const v=i.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),y=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,w)=>(J(),ee("div",mb,[h("div",gb,[h("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),oe(ab,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=S=>v.$emit("update:pageLayout",S))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",vb,[h("div",bb,[h("div",yb,[oe(de,{name:"sparkles"}),h("span",null,[w[31]||(w[31]=It("检测到本页横向超级块列宽比例：",-1)),h("b",null,we(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=S=>v.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[oe(de,{name:"columns"}),w[32]||(w[32]=h("span",null,"设为分栏",-1))])])])):Te("",!0),f.value?(J(),ee("div",kb,[h("div",wb,[h("div",xb,[h("div",Sb,[oe(de,{name:"ratio"}),w[33]||(w[33]=h("span",null,"分栏比例",-1))]),w[34]||(w[34]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",Cb,[(J(!0),ee(Xe,null,St(p.value,S=>(J(),ee("button",{key:S.value,class:Ce(["spm-chip",{active:k.value===S.value}]),onClick:B=>v.$emit("update:pageLayoutRatio",S.value)},we(S.label),11,_b))),128))]),h("div",$b,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=S=>v.$emit("update:pageLayoutRatio",S.target.value)),onChange:w[3]||(w[3]=S=>v.$emit("update:pageLayoutRatio",S.target.value))},null,40,Ib),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=S=>v.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[oe(de,{name:"sparkles"}),w[35]||(w[35]=h("span",null,"读取",-1))],8,Mb)):(J(),ee("button",Tb,[oe(de,{name:"sparkles"}),w[36]||(w[36]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[oe(de,{name:"reset"}),w[37]||(w[37]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",Eb,[oe(de,{name:"ratio"}),w[38]||(w[38]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Ab,we(e.detectedSbRatio),1)])):(J(),ee("div",Bb,[oe(de,{name:"ratio"}),w[39]||(w[39]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),oe(cc,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=S=>v.$emit("update:pageTransition",S))},null,8,["model-value"]),h("div",Db,[h("div",Lb,[h("div",Pb,[h("div",Ob,[oe(de,{name:"sparkles"}),w[40]||(w[40]=h("span",null,"页面动态蒙版",-1))]),w[41]||(w[41]=h("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),h("div",Rb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=S=>v.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=S=>c("down"))}," 从上至下 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=S=>c("right"))}," 从左至右 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=S=>l("clockwise"))}," 顺时针 ↻ ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=S=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",Nb,[h("div",zb,[w[43]||(w[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[oe(de,{name:"help"}),w[42]||(w[42]=h("span",null,"输入规则",-1))],8,Hb)]),h("div",Fb,[(J(),ee(Xe,null,St(n,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:r.value===S.value}]),onClick:B=>v.$emit("update:pageMaskRatio",S.value)},we(S.label),11,jb)),64))]),h("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=S=>v.$emit("update:pageMaskRatio",S.target.value)),onChange:w[12]||(w[12]=S=>v.$emit("update:pageMaskRatio",S.target.value))},null,40,Wb),h("div",Ub,we(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),h("div",Vb,[h("div",Gb,[w[44]||(w[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",Kb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=S=>v.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=S=>v.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",qb,[w[45]||(w[45]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",Yb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=S=>v.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=S=>v.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),h("div",Zb,[h("div",Jb,[h("div",Xb,[h("div",Qb,[oe(de,{name:"ratio"}),w[46]||(w[46]=h("span",null,"页面间距",-1))]),w[47]||(w[47]=h("span",{class:"spm-control-desc"},"覆盖本页内衬、内容间隙与正文行距",-1))])]),h("div",e1,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=S=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[18]||(w[18]=S=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:w[19]||(w[19]=S=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[20]||(w[20]=S=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",t1,[h("div",i1,[h("div",s1,[h("div",n1,[oe(de,{name:"image"}),w[48]||(w[48]=h("span",null,"页面图片",-1))]),w[49]||(w[49]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",o1,[(J(),ee(Xe,null,St(y,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:e.pageImage===S.value}]),onClick:B=>v.$emit("update:pageImage",S.value)},we(S.label),11,r1)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:w[21]||(w[21]=S=>v.$emit("update:pageImage",S.target.value)),onChange:w[22]||(w[22]=S=>v.$emit("update:pageImage",S.target.value))},null,40,a1)])):Te("",!0),h("div",l1,[h("div",c1,[h("div",d1,[h("div",u1,[oe(de,{name:"presenter"}),w[50]||(w[50]=h("span",null,"演讲者提词",-1))]),w[51]||(w[51]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(gt)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[23]||(w[23]=S=>v.$emit("generateNotes"))},[oe(de,{name:"sparkles"}),w[52]||(w[52]=h("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",f1,[w[55]||(w[55]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},we(b.value),9,p1),h("div",h1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[24]||(w[24]=S=>v.$emit("locateNoteBlock"))},[oe(de,{name:"search"}),w[53]||(w[53]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[25]||(w[25]=S=>v.$emit("addNoteBlock"))},[oe(de,{name:"insert-below"}),w[54]||(w[54]=h("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",m1,[w[57]||(w[57]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[26]||(w[26]=S=>v.$emit("addNoteBlock"))},[oe(de,{name:"insert-below"}),w[56]||(w[56]=h("span",null,"添加讲稿备注块",-1))])])),h("div",g1,[h("div",v1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:w[27]||(w[27]=S=>v.$emit("batchAppendNotes"))},[oe(de,{name:"insert-below"}),w[58]||(w[58]=h("span",null,"全部追加",-1))],12,b1),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:w[28]||(w[28]=S=>v.$emit("batchDeleteNotes"))},[oe(de,{name:"trash"}),w[59]||(w[59]=h("span",null,"全部删除",-1))],12,y1)])])]),h("div",k1,[w[62]||(w[62]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",w1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[29]||(w[29]=S=>v.$emit("insertDividerAfter"))},[oe(de,{name:"insert-below"}),w[60]||(w[60]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[30]||(w[30]=S=>v.$emit("deleteDivider"))},[oe(de,{name:"trash"}),w[61]||(w[61]=h("span",null,"删除此页",-1))])])])]))}}),S1=ii(x1,[["__scopeId","data-v-b11d7c22"]]),C1={class:"spm-section spm-section--block"},_1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},$1={class:"spm-control-header"},I1={class:"spm-control-title-group"},M1={class:"spm-control-title"},T1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},E1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},A1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},B1={key:0},D1={key:1},L1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},P1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},O1={class:"spm-action-grid"},R1={class:"spm-card-control"},N1={class:"spm-control-header"},z1={class:"spm-control-title-group"},H1={class:"spm-control-title"},F1=["aria-label"],j1=["checked"],W1={key:1,class:"spm-card-control"},U1={class:"spm-control-header"},V1={class:"spm-control-title-group"},G1={class:"spm-control-title"},K1={class:"spm-quick-chips"},q1={key:2,class:"spm-card-control"},Y1={class:"spm-control-header"},Z1={class:"spm-control-title-group"},J1={class:"spm-control-title"},X1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Q1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ey={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ty=["aria-label"],iy=["checked"],sy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ny={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},oy=["aria-label"],ry=["checked"],ay={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ly={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},cy=["aria-label"],dy=["checked"],uy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},fy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},py=["aria-label"],hy=["checked"],my={class:"spm-card-control"},gy={class:"spm-control-header"},vy={class:"spm-control-title-group"},by={class:"spm-control-title"},yy=["aria-label"],ky=["checked"],wy={key:0,class:"spm-quick-chips"},xy=["onClick"],Sy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Cy={class:"spm-card-control"},_y={class:"spm-control-header"},$y={class:"spm-control-title-group"},Iy={class:"spm-control-title"},My=["aria-label"],Ty=["checked"],Ey={key:0,class:"spm-quick-chips"},Ay=["onClick"],By={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Dy={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Ly={style:{display:"flex",gap:"6px"}},Py=["value"],Oy=["value"],Ry={key:3,class:"spm-card-control"},Ny={class:"spm-control-header"},zy={class:"spm-control-title-group"},Hy={class:"spm-control-title"},Fy={class:"spm-control-desc"},jy={class:"spm-segmented-group"},Wy=["onClick"],Uy={key:4,class:"spm-card-control"},Vy={class:"spm-control-header"},Gy={class:"spm-control-title-group"},Ky={class:"spm-control-title"},qy={class:"spm-quick-chips"},Yy=["onClick"],Zy=["value"],Jy={key:5,class:"spm-card-control"},Xy={class:"spm-control-header"},Qy={class:"spm-control-title-group"},e0={class:"spm-control-title"},t0={class:"spm-quick-chips"},i0=["onClick"],s0=["value"],n0={class:"spm-card-control"},o0={class:"spm-action-grid"},r0=["aria-label"],a0=Dt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,s=ye(()=>{const A=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":A}),n=ye(()=>{const A=s.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),o=ye(()=>{var C,L,z,N;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const A=(L=i.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(A){const K=parseInt(A[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(z=i.detectedSbInfo)==null?void 0:z.ratio)!=null&&N.includes(":")){const K=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),a=ye(()=>{const A=s.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=s.value;return A==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const A=s.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let z=1;z<=C;z++)L.push({value:`col-${z}`,label:`第 ${z} 栏`});return L});function c(A){const C=i.elemSlot||"";return A?C===A||A==="col-1"&&C==="left"||A==="col-2"&&C==="center"||A==="col-3"&&C==="right"&&o.value===3||A==="col-2"&&C==="right"&&o.value===2||A==="left"&&C==="col-1"||A==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],d=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const A=JSON.parse(i.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),p=ye(()=>!!d.value),k=ye(()=>{var A;return((A=d.value)==null?void 0:A.preset)||"slide-up"}),m=ye(()=>{var A;return((A=d.value)==null?void 0:A.duration)||0}),b=ye(()=>{var A;return((A=d.value)==null?void 0:A.delay)||0});function y(){p.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function v(A){B(A,m.value,b.value)}function w(A){B(k.value,A,b.value)}function S(A){B(k.value,m.value,A)}function B(A,C,L){if(!A||A==="none"){u("update:elemMotion","");return}if(!C&&!L){u("update:elemMotion",A);return}const z={preset:A};C>0&&(z.duration=C),L>0&&(z.delay=L),u("update:elemMotion",JSON.stringify(z))}return(A,C)=>{var L,z,N,K,_,U;return J(),ee("div",C1,[C[62]||(C[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(J(),ee("div",_1,[h("div",$1,[h("div",I1,[h("div",M1,[oe(de,{name:"ratio"}),C[24]||(C[24]=h("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",T1,[h("div",E1,[h("div",A1,[oe(de,{name:"ratio"}),(z=e.detectedSbInfo)!=null&&z.isCustomWidth?(J(),ee("span",B1,"已识别自定义列宽比例")):(J(),ee("span",D1,"识别到 "+we(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),h("code",L1,we(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),h("div",P1,we((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",O1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=x=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[oe(de,{name:"sparkles"}),C[26]||(C[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=x=>{var q;return A.$emit("applySuperBlockRatio",((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1")})},[oe(de,{name:"check"}),h("span",null,"应用比例 ("+we(((U=e.detectedSbInfo)==null?void 0:U.ratio)||"1:1")+")",1)])])])):Te("",!0),h("div",R1,[h("div",N1,[h("div",z1,[h("div",H1,[oe(de,{name:"presenter"}),C[27]||(C[27]=h("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=x=>A.$emit("toggleNote"))},null,40,j1),C[29]||(C[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,F1)])]),e.isImage||e.imageRole?(J(),ee("div",W1,[h("div",U1,[h("div",V1,[h("div",G1,[oe(de,{name:"image"}),C[30]||(C[30]=h("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",K1,[h("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=x=>A.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=x=>A.$emit("update:imageRole","background"))},[oe(de,{name:"image"}),C[32]||(C[32]=h("span",null,"背景图",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=x=>A.$emit("update:imageRole","image-left"))},[oe(de,{name:"image-left"}),C[33]||(C[33]=h("span",null,"图左",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=x=>A.$emit("update:imageRole","image-right"))},[oe(de,{name:"image-right"}),C[34]||(C[34]=h("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",q1,[h("div",Y1,[h("div",Z1,[h("div",J1,[oe(de,{name:"video"}),C[35]||(C[35]=h("span",null,"视频播放设置",-1))]),C[36]||(C[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",X1,[h("div",Q1,[h("span",ey,[oe(de,{name:"sliders"}),C[37]||(C[37]=It(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=x=>A.$emit("toggleVideoControls"))},null,40,iy),C[38]||(C[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,ty)]),h("div",sy,[h("span",ny,[oe(de,{name:"video"}),C[39]||(C[39]=It(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=x=>A.$emit("toggleVideoAutoplay"))},null,40,ry),C[40]||(C[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,oy)]),h("div",ay,[h("span",ly,[oe(de,{name:"repeat"}),C[41]||(C[41]=It(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=x=>A.$emit("toggleVideoLoop"))},null,40,dy),C[42]||(C[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,cy)]),h("div",uy,[h("span",fy,[oe(de,{name:"volume-x"}),C[43]||(C[43]=It(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=x=>A.$emit("toggleVideoMuted"))},null,40,hy),C[44]||(C[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,py)])])])):Te("",!0),h("div",my,[h("div",gy,[h("div",vy,[h("div",by,[oe(de,{name:"step"}),C[45]||(C[45]=h("span",null,"逐步呈现",-1))]),C[46]||(C[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=x=>A.$emit("toggleElemClick"))},null,40,ky),C[47]||(C[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,yy)]),e.elemClick?(J(),ee("div",wy,[(J(),ee(Xe,null,St(["+1","1","2","hide"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemClick===x}]),onClick:q=>A.$emit("update:elemClick",x)},we(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,xy)),64))])):e.parentElemClick?(J(),ee("div",Sy,[oe(de,{name:"check"}),C[48]||(C[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),h("div",Cy,[h("div",_y,[h("div",$y,[h("div",Iy,[oe(de,{name:"motion"}),C[49]||(C[49]=h("span",null,"入场微动效",-1))]),C[50]||(C[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":p.value?"关闭微动效":"开启微动效"},[h("input",{type:"checkbox",checked:p.value,onChange:y},null,40,Ty),C[51]||(C[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,My)]),p.value?(J(),ee("div",Ey,[(J(),ee(Xe,null,St(f,x=>h("button",{key:x.value,class:Ce(["spm-chip",{active:k.value===x.value}]),onClick:q=>v(x.value)},we(x.label),11,Ay)),64))])):Te("",!0),p.value?(J(),ee("div",By,[h("div",Dy,[h("span",null,"时长: "+we(m.value?m.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+we(b.value?b.value+"ms":"0ms"),1)]),h("div",Ly,[h("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=x=>w(Number(x.target.value)))},[...C[52]||(C[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,Py),h("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:C[13]||(C[13]=x=>S(Number(x.target.value)))},[...C[53]||(C[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Oy)])])):Te("",!0)]),n.value||e.elemSlot?(J(),ee("div",Ry,[h("div",Ny,[h("div",zy,[h("div",Hy,[oe(de,{name:"columns"}),h("span",null,we(a.value),1)]),h("span",Fy,we(r.value),1)])]),h("div",jy,[(J(!0),ee(Xe,null,St(l.value,x=>(J(),ee("button",{key:x.value,class:Ce(["spm-segmented-item",{active:c(x.value)}]),onClick:q=>A.$emit("update:elemSlot",x.value)},we(x.label),11,Wy))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",Uy,[h("div",Vy,[h("div",Gy,[h("div",Ky,[oe(de,{name:"code"}),C[54]||(C[54]=h("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",qy,[(J(),ee(Xe,null,St(["1-3","all","1|2|3","2-5"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemShikiLines===x}]),onClick:q=>A.$emit("update:elemShikiLines",x)},we(x),11,Yy)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=x=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=x=>A.$emit("update:elemShikiLines",x.target.value)),onChange:C[16]||(C[16]=x=>A.$emit("update:elemShikiLines",x.target.value))},null,40,Zy)])):Te("",!0),e.isCodeBlock?(J(),ee("div",Jy,[h("div",Xy,[h("div",Qy,[h("div",e0,[oe(de,{name:"code"}),C[56]||(C[56]=h("span",null,"代码块限高",-1))]),C[57]||(C[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",t0,[(J(),ee(Xe,null,St(["240px","320px","400px","50%"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemMaxHeight===x||x==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:q=>A.$emit("update:elemMaxHeight",x)},we(x),11,i0)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=x=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:C[18]||(C[18]=x=>A.$emit("update:elemMaxHeight",x.target.value)),onChange:C[19]||(C[19]=x=>A.$emit("update:elemMaxHeight",x.target.value))},null,40,s0)])):Te("",!0),h("div",n0,[C[61]||(C[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",o0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=x=>A.$emit("insertDividerBefore"))},[oe(de,{name:"insert-above"}),C[58]||(C[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=x=>A.$emit("insertDividerAfter"))},[oe(de,{name:"insert-below"}),C[59]||(C[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=x=>A.$emit("setTwoColsContrast"))},[oe(de,{name:"columns"}),h("span",null,we(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,r0),e.hasBlockAttrs?(J(),ee("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=x=>A.$emit("clearBlockAttrs"))},[oe(de,{name:"broom"}),C[60]||(C[60]=h("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),l0={class:"spm-section spm-section--doc"},c0={class:"spm-card-control"},d0={class:"spm-control-header"},u0={class:"spm-control-title-group"},f0={class:"spm-control-title"},p0={class:"spm-segmented-group"},h0=["aria-label","onClick"],m0={class:"spm-card-control"},g0={class:"spm-control-header"},v0={class:"spm-control-title-group"},b0={class:"spm-control-title"},y0={class:"spm-quick-chips"},k0=["onClick"],w0=["value"],x0={class:"spm-card-control"},S0={class:"spm-control-header"},C0={class:"spm-control-title-group"},_0={class:"spm-control-title"},$0={class:"spm-segmented-group"},I0={class:"spm-card-control"},M0={class:"spm-control-header"},T0={class:"spm-control-title-group"},E0={class:"spm-control-title"},A0={class:"spm-segmented-group"},B0={class:"spm-card-control"},D0={class:"spm-control-header"},L0={class:"spm-control-title-group"},P0={class:"spm-control-title"},O0={class:"spm-card-control"},R0={class:"spm-control-header"},N0={class:"spm-control-title-group"},z0={class:"spm-control-title"},H0=["aria-label"],F0=["checked"],j0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},W0=["value"],U0={class:"spm-card-control"},V0={class:"spm-control-header"},G0={class:"spm-control-title-group"},K0={class:"spm-control-title"},q0=["aria-label"],Y0=["checked"],Z0={class:"spm-card-control"},J0={class:"spm-control-header"},X0={class:"spm-control-title-group"},Q0={class:"spm-control-title"},ek={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},tk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},ik=["aria-label"],sk=["checked"],nk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},ok=["aria-label"],rk=["checked"],ak={class:"spm-card-control"},lk={class:"spm-action-grid"},ck=["disabled"],dk=["disabled"],uk=["disabled","aria-label"],fk=Dt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","clearDividers","exportHtml","exportPdf","exportImages"],setup(e){const t=zt("plugin"),i=Vt,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(f){ri({enableWebServeJump:f}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:f})}async function o(f){var d;ri({normalizeHeadingSizes:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(f){var d;ri({showUnorderedListMarkers:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(f){var d;ri({showOrderedListMarkers:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(f){ri({webServeUrl:f})}function c(f){ri({webServeUrl:f}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:f})}const u=[{label:"默认",value:""},{label:"极简白",value:"#ffffff"},{label:"柔和灰",value:"#f8fafc"},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"雅蓝渐变",value:"linear-gradient(135deg, #1e293b 0%, #0f172a 100%)"},{label:"极光渐变",value:"linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)"},{label:"晨雾渐变",value:"linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)"}];return(f,d)=>(J(),ee("div",l0,[d[58]||(d[58]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",c0,[h("div",d0,[h("div",u0,[h("div",f0,[oe(de,{name:"palette"}),d[26]||(d[26]=h("span",null,"幻灯片主题",-1))]),d[27]||(d[27]=h("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),h("div",p0,[(J(),ee(Xe,null,St(s,p=>h("button",{key:p.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===p.value}]),"aria-label":p.desc,onClick:k=>f.$emit("update:docTheme",p.value)},we(p.label),11,h0)),64))])]),h("div",m0,[h("div",g0,[h("div",v0,[h("div",b0,[oe(de,{name:"palette"}),d[28]||(d[28]=h("span",null,"演示背景",-1))]),d[29]||(d[29]=h("span",{class:"spm-control-desc"},"全篇幻灯片统一底色、微渐变或壁纸",-1))])]),h("div",y0,[(J(),ee(Xe,null,St(u,p=>h("button",{key:p.value,class:Ce(["spm-chip",{active:(e.docBackground||"")===p.value}]),onClick:k=>f.$emit("update:docBackground",p.value)},we(p.label),11,k0)),64))]),h("input",{value:e.docBackground||"",class:"spm-input",placeholder:"自定义颜色 (#1e1e24)、渐变或资源路径 (assets/...)",onInput:d[0]||(d[0]=p=>f.$emit("update:docBackground",p.target.value)),onChange:d[1]||(d[1]=p=>f.$emit("update:docBackground",p.target.value))},null,40,w0)]),h("div",x0,[h("div",S0,[h("div",C0,[h("div",_0,[oe(de,{name:"ratio"}),d[30]||(d[30]=h("span",null,"画幅比例",-1))]),d[31]||(d[31]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",$0,[h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[2]||(d[2]=p=>f.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[3]||(d[3]=p=>f.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[4]||(d[4]=p=>f.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",I0,[h("div",M0,[h("div",T0,[h("div",E0,[oe(de,{name:"ratio"}),d[32]||(d[32]=h("span",null,"间距风格",-1))]),d[33]||(d[33]=h("span",{class:"spm-control-desc"},"内衬、内容间隙与正文行距预设",-1))])]),h("div",A0,[h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:d[5]||(d[5]=p=>f.$emit("update:docSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:d[6]||(d[6]=p=>f.$emit("update:docSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:d[7]||(d[7]=p=>f.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),h("div",B0,[h("div",D0,[h("div",L0,[h("div",P0,[oe(de,{name:"transition"}),d[34]||(d[34]=h("span",null,"全局默认转场",-1))]),d[35]||(d[35]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),oe(cc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[8]||(d[8]=p=>f.$emit("update:docDefaultTransition",p))},null,8,["model-value"])]),h("div",O0,[h("div",R0,[h("div",N0,[h("div",z0,[oe(de,{name:"external-link"}),d[36]||(d[36]=h("span",null,"本地网络伺服预览",-1))]),d[37]||(d[37]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:d[9]||(d[9]=p=>n(p.target.checked))},null,40,F0),d[38]||(d[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,H0)]),he(i).enableWebServeJump?(J(),ee("div",j0,[h("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[10]||(d[10]=Zt(()=>{},["stop"])),onKeyup:d[11]||(d[11]=Zt(()=>{},["stop"])),onInput:d[12]||(d[12]=p=>l(p.target.value)),onChange:d[13]||(d[13]=p=>c(p.target.value))},null,40,W0),d[39]||(d[39]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),h("div",U0,[h("div",V0,[h("div",G0,[h("div",K0,[oe(de,{name:"type"}),d[40]||(d[40]=h("span",null,"固定特定标题大小",-1))]),d[41]||(d[41]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:d[14]||(d[14]=p=>o(p.target.checked))},null,40,Y0),d[42]||(d[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,q0)])]),h("div",Z0,[h("div",J0,[h("div",X0,[h("div",Q0,[oe(de,{name:"list"}),d[43]||(d[43]=h("span",null,"列表前缀标记",-1))]),d[44]||(d[44]=h("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),h("div",ek,[h("div",tk,[d[46]||(d[46]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[h("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:d[15]||(d[15]=p=>a(p.target.checked))},null,40,sk),d[45]||(d[45]=h("span",{class:"spm-switch-slider"},null,-1))],8,ik)]),h("div",nk,[d[48]||(d[48]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[h("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:d[16]||(d[16]=p=>r(p.target.checked))},null,40,rk),d[47]||(d[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,ok)])])]),h("div",ak,[d[57]||(d[57]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",lk,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[17]||(d[17]=p=>f.$emit("openBottomPreview"))},[oe(de,{name:"split-preview"}),d[49]||(d[49]=h("span",null,"分屏预览",-1))]),he(gt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[18]||(d[18]=p=>f.$emit("openPresenter"))},[oe(de,{name:"presenter"}),d[50]||(d[50]=h("span",null,"演讲者视图",-1))])):Te("",!0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[19]||(d[19]=p=>f.$emit("identifyNotes"))},[oe(de,{name:"notes"}),d[51]||(d[51]=h("span",null,"识别讲稿块",-1))],8,ck),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[20]||(d[20]=p=>f.$emit("autoAnimate"))},[oe(de,{name:"step"}),d[52]||(d[52]=h("span",null,"智能动效",-1))],8,dk),he(gt)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:d[21]||(d[21]=p=>f.$emit("aiAutoSplit"))},[oe(de,{name:"sparkles"}),d[53]||(d[53]=h("span",null,"智能分页",-1))])):Te("",!0),he(gt)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线",onClick:d[22]||(d[22]=p=>f.$emit("clearDividers"))},[oe(de,{name:"trash"}),d[54]||(d[54]=h("span",null,"清除分页",-1))])):Te("",!0),he(gt)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[23]||(d[23]=p=>f.$emit("exportHtml"))},[oe(de,{name:"export-html"}),d[55]||(d[55]=h("span",null,"导出 HTML",-1))])):Te("",!0),he(gt)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[24]||(d[24]=p=>f.$emit("exportPdf"))},[oe(de,{name:"export-pdf"}),d[56]||(d[56]=h("span",null,"导出 PDF",-1))])):Te("",!0),he(gt)("exportImage")?(J(),ee("button",{key:5,class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[25]||(d[25]=p=>f.$emit("exportImages"))},[oe(de,{name:"export-image"}),h("span",null,we(e.isExportingImages?"正在导出...":"导出图片"),1)],10,uk)):Te("",!0)])])]))}}),pk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,hk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function mk(e){const t=await ic.loadAsync(e),i={},s=[];let n="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||hk.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=u)}else if(pk.test(c)){const u=await l.file.async("uint8array"),f=c.split("/").pop()||c,d=typeof Blob<"u"?new Blob([u]):void 0;s.push({zipPath:c,fileName:f,data:u,blob:d})}}return{entryMarkdown:n,entryMarkdownPath:o,virtualFiles:i,assets:s}}function gk(e,t){if(Object.keys(t).length===0)return e;function i(n){const o=n.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function s(n){let o=n;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const n of e.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const o=n.pageAttrs["custom-slides-background"],a=i(o);a&&(n.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=s(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],o=i(n);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function dc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function vk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const s=i[1].trim(),n=s.indexOf("#"),o=n!==-1?s.slice(0,n):s,a=n!==-1?s.slice(n+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const p=r.split("/").pop();for(const[k,m]of Object.entries(l))if(k.endsWith(`/${r}`)||p&&k.endsWith(`/${p}`)){c=m;break}}if(!c){const p=[];if(t!=null&&t.baseDir)try{const k=require("path");p.push(k.resolve(t.baseDir,r)),p.push(k.resolve(t.baseDir,o))}catch{}try{const k=require("path");p.push(k.resolve(process.cwd(),r))}catch{}for(const k of p){const m=dc(k);if(m!==null){c=m;break}}}if(!c){const p=Gl||{};if(c=p[o]||p[r]||p[`snippets/${r}`],!c){const k=r.split("/").pop();for(const[m,b]of Object.entries(p))if(m.endsWith(`/${r}`)||k&&m.endsWith(`/${k}`)){c=b;break}}}if(!c)return null;let u=c;if(a){const p=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),k=c.match(p);if(k){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+k[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function bk(e){let t=!1,i=!1;for(let s=0;s<e.length;s++){const n=e[s];if(n==="'"&&!i)t=!t;else if(n==='"'&&!t)i=!i;else if(n==="#"&&!t&&!i)return e.slice(0,s).trim()}return e.trim()}function gn(e){const t={},i=e.split(/\r?\n/);let s=0;for(;s<i.length;){const n=i[s],o=n.trim();if(!o||o.startsWith("#")){s++;continue}const a=n.indexOf(":");if(a>0){const r=n.slice(0,a).trim();let l=n.slice(a+1).trim();if(l==="|"||l===">"){s++;const c=[];let u=-1;for(;s<i.length;){const f=i[s];if(!f.trim()){c.push(""),s++;continue}const p=f.match(/^(\s+)/),k=p?p[1].length:0;if(u===-1&&(u=k),k<u)break;c.push(f.slice(u)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=bk(l),!l){let c=s+1;const u=[];let f=-1;for(;c<i.length;){const d=i[c],p=d.trim();if(!p||p.startsWith("#")){f!==-1&&u.push(""),c++;continue}const k=d.match(/^(\s+)/),m=k?k[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(d.slice(f)),c++}if(u.length>0){t[r]=gn(u.join(`
`)),s=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}s++}return t}const yk=/^\s*```ya?ml([\s\S]*?)```/;function ba(e){let t={},i=e.trim();const s=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const o=gn(s[1]);if(Object.keys(o).length>0||!s[1].trim())return t=o,i=i.slice(s[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const n=i.match(yk);if(n)t=gn(n[1]),i=i.slice(n[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gn(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function kk(e){const t=e.split(/\r?\n/),i=[];let s=0,n=!1;function o(a){if(s>=a)return;const r=t.slice(s,a).join(`
`).trim();r&&i.push(r),s=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(n){l.includes("-->")&&(n=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(n=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let u=!1,f=-1;const d=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&d.length>0){for(let p=a+1;p<t.length;p++){const k=t[p].trimEnd();if(k.startsWith("```"))break;if(k==="---"){f=p;break}}f!==-1&&f-a<=60&&t.slice(a+1,f).some(m=>{const b=m.trim();return b.length>0&&!b.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(b)})&&(u=!0)}u&&f!==-1&&(s=a,a=f)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let f=a+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(a=f)}}return s<t.length&&o(t.length),i}function vn(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=kk(u),d={};let p="",k="",m=0;if(f.length>0){const N=f[0],K=ba(N),_=Object.keys(K.frontmatter).length>0,U=K.content.length>0;_&&!U&&f.length>1?(m=1,b(K.frontmatter)):_&&b(K.frontmatter)}function b(N){p=N.title||"",N.theme&&(d[Ns]=String(N.theme)),N.aspectRatio&&(d[zs]=String(N.aspectRatio)),N.highlighter&&(d[Ma]=String(N.highlighter)),N.transition&&(d[Hs]=String(N.transition)),N.colorSchema&&(d[Ta]=String(N.colorSchema)),N.layout&&(d[ke]=String(N.layout)),N.background&&(d[ot]=String(N.background)),N.image&&(d[Rt]=String(N.image)),N.class&&(d[es]=String(N.class));for(const[K,_]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(d[`custom-slides-${K}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let v=0,w=0,S=0,B=0;const A=new Set,C={};let L=1;for(let N=m;N<f.length;N++){const K=f[N],{frontmatter:_,content:U}=ba(K),x=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),q=_.src||(x?x[1]:void 0);if(q){const fe=String(q).trim().replace(/^['"]|['"]$/g,"");let X=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!X){const E=fe.replace(/^\.\//,""),F=[];if(t.baseDir)try{const g=require("path");F.push(g.resolve(t.baseDir,E)),F.push(g.resolve(t.baseDir,fe))}catch{}try{const g=require("path");F.push(g.resolve(process.cwd(),E)),F.push(g.resolve(process.cwd(),fe))}catch{}for(const g of F){const W=dc(g);if(W!==null){X=W;break}}}const pe={};_.layout&&(pe[ke]=String(_.layout)),_.transition&&(pe[vt]=String(_.transition)),_.background&&(pe[ot]=String(_.background)),_.image&&(pe[Rt]=String(_.image)),_.class&&(pe[es]=String(_.class));for(const[E,F]of Object.entries(_))["src","layout","transition","background","image","class"].includes(E)||(pe[`custom-slides-${E}`]=typeof F=="object"?JSON.stringify(F):String(F));if(X){const E=vn(X,{...t,virtualFiles:c});for(const F of E.slides){F.pageIndex=L++,F.pageAttrs={...pe,...F.pageAttrs},y.push(F);const g=F.pageAttrs[ke]||"default";C[g]=(C[g]||0)+1}continue}else{y.push({pageIndex:L++,pageAttrs:{...pe,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=pe[ke]||"default";C[E]=(C[E]||0)+1;continue}}const O={};_.layout&&(O[ke]=String(_.layout)),_.transition&&(O[vt]=String(_.transition)),_.background&&(O[ot]=String(_.background)),_.image&&(O[Rt]=String(_.image)),_.class&&(O[es]=String(_.class)),_.mask&&(O[ts]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(O[ji]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(O[is]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(O[ss]=String(_.maskInitial||_["mask-initial"]));for(const[fe,X]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(O[`custom-slides-${fe}`]=typeof X=="object"?JSON.stringify(X):String(X));let $=U;const T=[];let P=$.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});let ne="";const V=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const fe=V[V.length-1],X=P.slice(fe.index+fe[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=fe[1].trim();E.startsWith("TODO:")||(ne=E,v++),i&&(P=P.slice(0,fe.index).trimEnd()+P.slice(fe.index+fe[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<T.length;fe++)P=P.replace(`__CODE_TOKEN_NOTE_${fe}__`,()=>T[fe]);if($=P,ne){for(let pe=0;pe<T.length;pe++)ne=ne.replace(`__CODE_TOKEN_NOTE_${pe}__`,()=>T[pe]);const X=`> [!NOTE] 💡 演讲备注
${ne.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slides-note="true"}`;$=$?`${$}

${X}`:X}let Y=!1;if(/<style\b/i.test($)){Y=!0;const fe=$.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const X of fe){const pe=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${pe}`:pe}a&&($=$.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ce=$.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ce&&(w+=ce.length);const ie=$.match(/```\w+\s+\{[^}]+\}/g);ie&&(S+=ie.length);const re=$.match(/::\w+::|<template\s+#[^>]+>/g);if(re&&(B+=re.length),$=$.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>vk(fe,{...t,virtualFiles:c})||fe),s&&($=$.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&($=$.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),$=$.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&($=$.replace(/^::\w+::\s*$/gm,"")),r&&($=ap($)),l){let fe=$.trim(),X="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(X=fe.slice(pe),fe=fe.slice(0,pe).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const E=String(_.image).trim(),F=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${E})
{: custom-slides-layout="${F}" }`;_.layout==="image-left"?fe=`{{{col

${g}

${fe}

}}}`:fe=`{{{col

${fe}

${g}

}}}`}if(_.background){const F=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${F}

${fe}`:F}$=X?`${fe}

${X}`:fe}const Se=wk($);O[ot]&&Se.push(O[ot]),O[Rt]&&Se.push(O[Rt]);for(const fe of Se)A.add(fe);const Ie=/<[A-Z][a-zA-Z0-9]+/.test($),_e=O[ke]||(L===1?d[ke]||"cover":"default");C[_e]=(C[_e]||0)+1,y.push({pageIndex:L++,pageAttrs:O,notes:ne,rawMarkdown:$,hasVueComponent:Ie,hasStyleTag:Y,assetReferences:Se})}if(!p&&y.length>0){const N=y[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(p=N[1].trim())}k&&(d["custom-slides-custom-css"]=k);let z=y.map(N=>`---

${N.rawMarkdown}`).join(`

`);return z.trimStart().startsWith("---")||(z=`---

${z.trimStart()}`),{docTitle:p||"Slidev 演示文稿",docRootAttrs:d,slides:y,totalSlides:y.length,stats:{totalNotes:v,totalVClicks:w,totalShikiHighlights:S,totalSlots:B,discoveredAssets:Array.from(A),layoutDistribution:C},flattenedMarkdown:z,customCss:k}}function wk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=i.exec(e))!==null;){const o=s[1].split(/\s+/)[0].trim();o&&t.push(o)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(e))!==null;){const o=s[1].trim();o&&t.push(o)}return t}function uc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),s=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||s==="---"||s==="***"}function xk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Sk(e,t,i=Fe){const s=e.filter(uc);let n=0;if(s.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=s[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),n++)}else for(let o=1;o<t.length;o++){const a=t[o],r=s[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),n++)}return n}async function Ck(e,t=Fe){let i=!1,s=0;for(const n of e){if(uc(n)){i=!1;continue}const o=(n.markdown||n.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&n.id&&(await t(n.id,{[Me]:"right"}).catch(()=>{}),s++)}return s}async function _k(e,t,i=Ca){const s={};if(!t||t.length===0)return s;const n=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});n.push(a)}try{const o=await i("/data/assets",n);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))s[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(s).length>0&&gk(e,s),s}async function $k(e){var v;const{presentation:t,notebookId:i,docTitle:s,extractedAssets:n=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||Ca,u=l.createDocFn||vd,f=l.setAttrsFn||Fe,d=l.getChildBlocksFn||hs,p=l.openTabFn||ae.openTab,k=l.showMessageFn||ae.showMessage;o&&n.length>0&&await _k(t,n,c);const m=xk(s),b=`/${m}`,y=await u(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const w=((v=t.slides[0])==null?void 0:v.pageAttrs)||{};await f(y,{...w,...t.docRootAttrs});const S=await d(y).catch(()=>[]);Array.isArray(S)&&S.length>0&&(await Sk(S,t.slides,f),await Ck(S,f))}catch(w){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",w),k(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${w.message||String(w)}`,6e3)}return k(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=y,await p({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function Ik(e){const t=ge("file"),i=ge(!1),s=ge(!1),n=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),u=ge([]),f=ge(null),d=ge(""),p=ge([]),k=ge(""),m=ge(!0),b=ge(!0),y=ge(!0),v=ge(!0),w=ye(()=>{const $=l.value;if($===0)return"0 B";const T=1024,P=["B","KB","MB","GB"],ne=Math.floor(Math.log($)/Math.log(T));return`${($/T**ne).toFixed(1)} ${P[ne]}`}),S=ye(()=>{var $;return(($=f.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),B=ye(()=>{var $;return u.value.length>0?u.value.length:(($=f.value)==null?void 0:$.stats.discoveredAssets.length)||0}),A=ye(()=>{var T;const $=((T=f.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([P,ne])=>({name:P,count:ne}))});async function C($=gd){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(p.value=T.notebooks.filter(P=>!P.closed),p.value.length>0&&!k.value&&(k.value=p.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function L(){var $;($=o.value)==null||$.click()}function z(){a.value=null,r.value="",l.value=0,f.value=null,u.value=[],n.value=""}let N=0;async function K($){const T=++N;n.value="",a.value=$,r.value=$.name,l.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const ne=await $.arrayBuffer();if(T!==N)return;const V=await mk(ne);if(T!==N)return;if(!V.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const Y=vn(V.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:V.virtualFiles});if(T!==N)return;f.value=Y,d.value=Y.docTitle||$.name.replace(/\.zip$/i,"")}else{const ne=await $.text();if(T!==N)return;u.value=[];const V=$.path||"",Y=V?V.replace(/[\\/][^\\/]+$/,""):"",ce=vn(ne,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Y||void 0});if(T!==N)return;f.value=ce,d.value=ce.docTitle||$.name.replace(/\.md$/i,"")}}catch(P){if(T!==N)return;console.error("解析文件失败:",P),n.value=`解析文件失败: ${P.message||String(P)}`}}function _(){if(n.value="",!c.value.trim()){f.value=null;return}try{const $=vn(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=$,d.value=$.docTitle||"Slidev 演示文稿"}catch($){n.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function U(){a.value?await K(a.value):c.value&&_()}async function x($){const T=$.target;T.files&&T.files[0]&&await K(T.files[0])}async function q($){var T;i.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await K($.dataTransfer.files[0])}async function O($=e){if(f.value){if(!k.value&&p.value.length>0&&(k.value=p.value[0].id),!k.value){n.value="请先选择目标笔记本";return}s.value=!0,n.value="";try{return await $k({presentation:f.value,notebookId:k.value,docTitle:d.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:v.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),n.value=`导入执行失败: ${T.message||String(T)}`}finally{s.value=!1}}}return{inputMode:t,isDragging:i,isImporting:s,errorMessage:n,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:d,notebooks:p,selectedNotebookId:k,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:v,formattedFileSize:w,currentTheme:S,extractedAssetsCount:B,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,processFile:K,onFileSelected:x,onFileDrop:q,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:O}}const Mk={class:"spm-import-dialog"},Tk={class:"spm-tabs-header"},Ek={class:"spm-dialog-body"},Ak={key:0,class:"spm-file-section"},Bk={key:0,class:"spm-dropzone-prompt"},Dk={class:"spm-dropzone-icon"},Lk={key:1,class:"spm-dropzone-active"},Pk={class:"spm-file-badge"},Ok={class:"spm-file-size"},Rk={key:1,class:"spm-text-section"},Nk={key:2,class:"spm-error-banner"},zk={key:3,class:"spm-preview-card"},Hk={class:"spm-preview-card__header"},Fk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},jk={class:"spm-config-grid"},Wk={class:"spm-form-item"},Uk={class:"spm-form-item"},Vk=["value"],Gk={class:"spm-stats-grid"},Kk={class:"spm-stat-box"},qk={class:"spm-stat-value"},Yk={class:"spm-stat-box"},Zk={class:"spm-stat-value"},Jk={class:"spm-stat-box"},Xk={class:"spm-stat-value"},Qk={class:"spm-stat-box"},ew={class:"spm-stat-value"},tw={key:0,class:"spm-chips-row"},iw={class:"spm-options-group"},sw={class:"spm-checkbox-label"},nw={class:"spm-checkbox-label"},ow={class:"spm-checkbox-label"},rw={class:"spm-checkbox-label"},aw={class:"spm-dialog-footer"},lw=["disabled"],cw=["disabled"],dw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},uw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},fw=Dt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,s=zt("plugin"),{inputMode:n,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:d,customDocTitle:p,notebooks:k,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:v,optAutoPreview:w,formattedFileSize:S,currentTheme:B,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,onFileSelected:N,onFileDrop:K,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:x}=Ik(s);vs(async()=>{await C()});async function q(){const $=await x();$&&(i("success",{docId:$}),i("close"))}function O(){i("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:Zt(O,["self"])},[h("div",Mk,[h("div",{class:"spm-dialog-header"},[T[18]||(T[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlides"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:O},"✕")]),h("div",Tk,[h("button",{class:Ce(["spm-tab-btn",{active:he(n)==="file"}]),onClick:T[0]||(T[0]=P=>n.value="file")},[oe(de,{name:"package"}),T[19]||(T[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:Ce(["spm-tab-btn",{active:he(n)==="text"}]),onClick:T[1]||(T[1]=P=>n.value="text")},[oe(de,{name:"notes"}),T[20]||(T[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",Ek,[he(n)==="file"?(J(),ee("div",Ak,[h("div",{class:Ce(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=Zt(P=>o.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=Zt(P=>o.value=!1,["prevent"])),onDrop:T[6]||(T[6]=Zt((...P)=>he(K)&&he(K)(...P),["prevent"])),onClick:T[7]||(T[7]=(...P)=>he(L)&&he(L)(...P))},[h("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...P)=>he(N)&&he(N)(...P))},null,544),he(c)?(J(),ee("div",Lk,[h("span",Pk,[oe(de,{name:"notes"}),It(" "+we(he(c)),1)]),h("span",Ok,"("+we(he(S))+")",1),h("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=Zt((...P)=>he(z)&&he(z)(...P),["stop"]))},"更换文件")])):(J(),ee("div",Bk,[h("span",Dk,[oe(de,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=h("p",{class:"spm-dropzone-hint"},[It(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),It("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(J(),ee("div",Rk,[Ot(h("textarea",{"onUpdate:modelValue":T[8]||(T[8]=P=>tt(u)?u.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...P)=>he(_)&&he(_)(...P))},null,544),[[No,he(u)]])])),he(r)?(J(),ee("div",Nk," ⚠️ "+we(he(r)),1)):Te("",!0),he(d)?(J(),ee("div",zk,[h("div",Hk,[h("span",Fk,[oe(de,{name:"sparkles"}),T[23]||(T[23]=It(" 演示解析摘要",-1))]),T[24]||(T[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",jk,[h("div",Wk,[T[25]||(T[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ot(h("input",{"onUpdate:modelValue":T[10]||(T[10]=P=>tt(p)?p.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[No,he(p)]])]),h("div",Uk,[T[26]||(T[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ot(h("select",{"onUpdate:modelValue":T[11]||(T[11]=P=>tt(m)?m.value=P:null),class:"spm-select"},[(J(!0),ee(Xe,null,St(he(k),P=>(J(),ee("option",{key:P.id,value:P.id},we(P.name),9,Vk))),128))],512),[[jf,he(m)]])])]),h("div",Gk,[h("div",Kk,[h("span",qk,we(he(d).totalSlides),1),T[27]||(T[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",Yk,[h("span",Zk,we(he(B)),1),T[28]||(T[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Jk,[h("span",Xk,we(he(d).stats.totalNotes),1),T[29]||(T[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Qk,[h("span",ew,we(he(f)),1),T[30]||(T[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(A).length>0?(J(),ee("div",tw,[T[31]||(T[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Xe,null,St(he(A),P=>(J(),ee("span",{key:P.name,class:"spm-chip-badge"},we(P.name)+": "+we(P.count),1))),128))])):Te("",!0),h("div",iw,[h("label",sw,[Ot(h("input",{"onUpdate:modelValue":T[12]||(T[12]=P=>tt(b)?b.value=P:null),type:"checkbox",onChange:T[13]||(T[13]=(...P)=>he(U)&&he(U)(...P))},null,544),[[an,he(b)]]),T[32]||(T[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",nw,[Ot(h("input",{"onUpdate:modelValue":T[14]||(T[14]=P=>tt(y)?y.value=P:null),type:"checkbox",onChange:T[15]||(T[15]=(...P)=>he(U)&&he(U)(...P))},null,544),[[an,he(y)]]),T[33]||(T[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",ow,[Ot(h("input",{"onUpdate:modelValue":T[16]||(T[16]=P=>tt(v)?v.value=P:null),type:"checkbox"},null,512),[[an,he(v)]]),T[34]||(T[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",rw,[Ot(h("input",{"onUpdate:modelValue":T[17]||(T[17]=P=>tt(w)?w.value=P:null),type:"checkbox"},null,512),[[an,he(w)]]),T[35]||(T[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),h("div",aw,[h("button",{class:"spm-btn-secondary",disabled:he(a),onClick:O}," 取消 ",8,lw),h("button",{class:"spm-btn-primary",disabled:!he(d)||he(a),onClick:q},[he(a)?(J(),ee("span",dw,[oe(de,{name:"refresh"}),T[36]||(T[36]=It(" 正在导入生成中...",-1))])):(J(),ee("span",uw,[oe(de,{name:"rocket"}),T[37]||(T[37]=It(" 确认导入思源笔记",-1))]))],8,cw)])])]))}}),pw=ii(fw,[["__scopeId","data-v-c56a3d7e"]]);function yr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function hw(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",s=t.currentTopBlockId||i,n=t.currentPageDividerId||"",o=t.activeBlockType||"";if(yr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(n){let l=e.find(c=>c.startBlockId===n);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===n}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var f,d;return((f=u.blocks)==null?void 0:f.some(p=>p.id===i))||((d=u.allBlockIds)==null?void 0:d.includes(i))}),l)||s&&s!==i&&(l=e.find(u=>{var f,d;return((f=u.blocks)==null?void 0:f.some(p=>p.id===s))||((d=u.allBlockIds)==null?void 0:d.includes(s))}),l)||(l=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(d=>d.id===i||d.id===s)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var f,d;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((d=u.blocks)==null?void 0:d.some(p=>p.slot==="col-1"||p.slot==="col-2"||p.slot==="col-3"))}),l))return l}return e[0]||null}function et(e,t){var n;if(typeof document>"u"||!e)return;const i=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${i}"]`);!s||s.length===0||s.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function mw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ke),s.removeAttribute("custom-slides-layout"),s.removeAttribute(Ze),s.removeAttribute("custom-slides-role");return}const o=e.get(n),a=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slides-layout"])||"",r=s.getAttribute(ke)||s.getAttribute("custom-slides-layout");r&&r!==a&&(a?s.setAttribute(ke,a):(s.removeAttribute(ke),s.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=s.getAttribute(Ze)||s.getAttribute("custom-slides-role");c&&c!==l&&(l?s.setAttribute(Ze,l):(s.removeAttribute(Ze),s.removeAttribute("custom-slides-role")))})}function gw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const s=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(s==null?void 0:s.getAttribute("data-node-id"))===e}function vw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function s(c){var p;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[k,m]of Object.entries(c))e.activeBlockAttrs.value[k]=m;Le.setBlockAttrOverride(u,c),et(u,c);const f=(p=e.parentContainerId)==null?void 0:p.value,d=!!(f&&gw(u,f));if(Ne in c&&d&&f){const k=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=k),Le.setBlockAttrOverride(f,{[Ne]:k}),et(f,{[Ne]:k}),Fe(f,{[Ne]:k}).catch(()=>{})}if(ke in c){const k=c[ke];e.currentPageDividerLayout.value=k,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=k)}if(bt in c){const k=c[bt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=k)}i("保存中...");try{await Fe(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function n(c,u){await s({[c]:u})}function o(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const f=o();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Le.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),c===ke&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===bt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await Fe(f,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const f=o();if(!f)return;const d={[ke]:c,[bt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[bt]=u),e.currentPageDividerLayout.value=c,Le.setBlockAttrOverride(f,d),et(f,d),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await Fe(f,d),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var d;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Le.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),(d=e.latestDoc.value)!=null&&d.config&&(c===Ns&&(e.latestDoc.value.config.theme=u),c===zs&&(e.latestDoc.value.config.aspectRatio=u),c===Hs&&(e.latestDoc.value.config.defaultTransition=u),c===wn&&(e.latestDoc.value.config.background=u)),i("更新中...");try{await Fe(f,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:s,saveAttr:n,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function ya(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],s=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):s.push(a.slice(0,50)))}const n=[];return i.length>0&&n.push(`【核心重点】：${i.join("、")}`),s.length>0&&(n.push("【口播要点】："),s.slice(0,3).forEach((o,a)=>{n.push(`${a+1}. 讲解 ${o}`)})),n.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),n.join(`
`)}async function fc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const n=await t(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:ya(e),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:ya(e),isAiGenerated:!1}}async function bw(e,t){return(await fc(e,t)).notes}function yw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function kw(e,t){if(!((t==null?void 0:t[qe])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const s=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(s)}async function ww(e,t){const s=await((t==null?void 0:t.getChildBlocksFn)||hs)(e).catch(()=>[]);if(!Array.isArray(s)||s.length===0)return[];const n=[];let o=[];for(const r of s){if(ui({...r,ial:{...r.ial||{},...Le.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&o.length===0)continue;n.push(o),o=[];continue}o.push(r)}n.push(o);const a=[];for(let r=0;r<n.length;r++){const l=n[r];if(!l||l.length===0)continue;let c=null;for(let k=l.length-1;k>=0;k--){const m=l[k];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!yw(c))continue;const u=Le.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[qe]&&!f["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const k=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...k,...u}}let d=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const k=await t.getBlockKramdownFn(c.id);k!=null&&k.kramdown&&(d=k.kramdown)}catch{}if(kw(d,f))continue;const p=mr(d)||d.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:d,cleanContent:p||"在此输入本页讲稿提词..."})}return a}async function xw(e,t,i){const s=(i==null?void 0:i.updateBlockFn)||So,n=(i==null?void 0:i.setBlockAttrsFn)||Fe,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${qe}="true"}`;await s("markdown",r,e),await n(e,{[qe]:"true"}),Le.setBlockAttrOverride(e,{[qe]:"true"}),o(e,{[qe]:"true"})}async function pc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,s=(t==null?void 0:t.confirmFn)||ae.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await ww(e,t);if(n.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=n.length;return new Promise(a=>{s("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of n)try{await xw(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function Sw(e,t){const i=ge(!1),{triggerSaveNotice:s}=t;async function n(d){var B,A,C,L,z,N,K,_;const m=`> [!NOTE] 💡 演讲备注
${(d||"在此输入本页讲稿提词...").split(/\r?\n/).map(U=>`> ${U}`).join(`
`)}
{: custom-slides-note="true"}`,b=((B=e.latestDoc.value)==null?void 0:B.slides)||[],y=e.targetSlide.value,v=y?b.findIndex(U=>U===y):-1;let w=null;if(v!==-1&&v<b.length-1){const U=b[v+1];w=await Hi("markdown",m,U.startBlockId)}else{const U=((A=y==null?void 0:y.noteBlocks)==null?void 0:A.slice(-1)[0])||((C=y==null?void 0:y.blocks)==null?void 0:C.slice(-1)[0]),x=(U==null?void 0:U.id)||(y==null?void 0:y.startBlockId);x?w=await Hi("markdown",m,void 0,x):w=await xo("markdown",m,e.currentDocId.value)}const S=((N=(z=(L=w==null?void 0:w[0])==null?void 0:L.doOperations)==null?void 0:z[0])==null?void 0:N.id)||((K=w==null?void 0:w[0])==null?void 0:K.id);return S&&(await Fe(S,{[qe]:"true"}),Le.setBlockAttrOverride(S,{[qe]:"true"}),Gi(S,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),S}async function o(){const d=e.activeBlockId.value;if(d)if(e.isNoteBlock.value){s("取消中...");try{await Fe(d,{[qe]:"","slides-note":""}),Le.setBlockAttrOverride(d,{[qe]:"","slides-note":""}),et(d,{[qe]:"","slides-note":""}),delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"],s("已取消备注"),ae.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",p),s("取消失败"),ae.showMessage("取消讲稿备注失败")}}else{s("转换中...");try{let p=e.rawSnippet.value;try{const y=await bd(d);y!=null&&y.kramdown&&(p=y.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(mr(p)||p.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await So("markdown",b,d),await Fe(d,{[qe]:"true"}),Le.setBlockAttrOverride(d,{[qe]:"true"}),et(d,{[qe]:"true"}),e.activeBlockAttrs.value[qe]="true",e.activeBlockType.value="NodeCallout",s("已设为讲稿备注"),ae.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",p),s("设置失败"),ae.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await n(),ae.showMessage("已在正文末尾插入讲稿备注提示块")}catch(d){ae.showMessage("插入讲稿备注块失败"),console.error(d)}}function r(){var k;const d=e.currentSlideNoteBlockId.value;if(!d){ae.showMessage("未找到本页关联的讲稿备注块");return}Gi(d,(k=e.plugin)==null?void 0:k.app)?ae.showMessage("已在编辑区定位讲稿备注块"):ae.showMessage("定位讲稿备注块失败")}async function l(){var k;if(!e.currentDocId.value)return;const d=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ae.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const p=await fc(d,_a);if(p.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${p.notes.split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await So("markdown",b,m),await Fe(m,{[qe]:"true"}),Le.setBlockAttrOverride(m,{[qe]:"true"}),Gi(m,(k=e.plugin)==null?void 0:k.app)}else await n(p.notes);p.isAiGenerated?ae.showMessage("思源 AI 演讲提词卡生成成功！"):ae.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const d=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(d.length===0){ae.showMessage("当前文档无幻灯片页面");return}const p=d.map((b,y)=>({slide:b,idx:y})).filter(({slide:b})=>{var w;const y=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,v=!!((w=b.notes)!=null&&w.trim());return!y&&!v});if(p.length===0){ae.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const k=p.length;ae.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${k} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var y,v,w,S,B,A;if(i.value)return;i.value=!0,ae.showMessage("正在批量追加讲稿块...");let b=0;try{const z=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:K}of p)try{let _=null;if(K<d.length-1){const x=d[K+1];_=await Hi("markdown",z,x.startBlockId)}else{const x=((y=N==null?void 0:N.noteBlocks)==null?void 0:y.slice(-1)[0])||((v=N==null?void 0:N.blocks)==null?void 0:v.slice(-1)[0]),q=(x==null?void 0:x.id)||(N==null?void 0:N.startBlockId);q?_=await Hi("markdown",z,void 0,q):_=await xo("markdown",z,e.currentDocId.value)}const U=((B=(S=(w=_==null?void 0:_[0])==null?void 0:w.doOperations)==null?void 0:S[0])==null?void 0:B.id)||((A=_==null?void 0:_[0])==null?void 0:A.id);U&&(await Fe(U,{[qe]:"true"}),Le.setBlockAttrOverride(U,{[qe]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${K+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ae.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var b;if(i.value)return;const d=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(d.length===0){ae.showMessage("当前文档无幻灯片页面");return}const p=[];for(const y of d)if(y.noteBlocks&&y.noteBlocks.length>0)for(const v of y.noteBlocks)v.id&&p.push({id:v.id,pageIndex:y.pageIndex});if(p.length===0){ae.showMessage("当前文档中没有讲稿备注块，无需删除");return}const k=new Set(p.map(y=>y.pageIndex)).size,m=p.length;ae.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${k} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ae.showMessage("正在批量删除讲稿块...");let y=0;try{for(const v of p)try{await Go(v.id),Le.clearBlockAttrOverride(v.id),y++}catch(w){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${v.id} 失败:`,w)}e.activeBlockId.value&&p.some(v=>v.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功删除全部 ${y} 个讲稿备注块`)}catch(v){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",v),ae.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function f(){var p;const d=e.currentDocId.value||((p=e.plugin)==null?void 0:p.currentDocId);if(!d){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ae.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await pc(d,{onSuccessNotice:s,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:n,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:f}}function Cw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const s=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(s)}function _w(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function $w(e){const t=[],i=s=>{var n,o,a,r,l,c,u,f,d,p,k;for(const m of s){if(!m||m.isNote||((n=m.attributes)==null?void 0:n[qe])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[qe])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(Cw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Ne])||((c=m.ial)==null?void 0:c[Ne]),rawBlock:m});continue}if(_w(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[Ne])||((f=m.ial)==null?void 0:f[Ne]),rawBlock:m});continue}const b=m.children&&m.children.length>0?m.children:(d=m.rawNode)==null?void 0:d.children;if(Array.isArray(b)&&b.length>0){i(b);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((p=m.attributes)==null?void 0:p[Ne])||((k=m.ial)==null?void 0:k[Ne]),rawBlock:m})}};return i(e||[]),t}function Iw(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=$w(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const s=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&s.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return s}async function Mw(e,t){const s=await((t==null?void 0:t.compileDocFn)||(a=>Le.compile(a)))(e).catch(()=>null);if(!s||!Array.isArray(s.slides)||s.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],o=new Set;for(const a of s.slides){const r=Iw(a);r.length>0&&(n.push(...r),o.add(a.pageIndex))}return{totalPages:s.slides.length,animatedPagesCount:o.size,targets:n}}async function hc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,s=(t==null?void 0:t.confirmFn)||ae.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||Fe,o=(t==null?void 0:t.syncDomFn)||et;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await Mw(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{s("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var d;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const p of a.targets)try{await n(p.blockId,{[Ne]:p.targetClick}),Le.setBlockAttrOverride(p.blockId,{[Ne]:p.targetClick}),o(p.blockId,{[Ne]:p.targetClick}),u++}catch(k){console.error(`[SiYuanLiveSlides] 为块 ${p.blockId} 配置动效失败:`,k),f++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:f})},()=>{c({...a,successCount:0,errorCount:0})})})}function Tw(e,t){const{saveAttr:i,saveAttrs:s,savePageAttr:n}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await s({[zi]:"true",[Qi]:"true"}),e.activeBlockAttrs.value[zi]="true",e.activeBlockAttrs.value[Qi]="true"):(await i(zi,"false"),e.activeBlockAttrs.value[zi]="false")}async function a(){const L=e.videoLoop.value?"false":"true";await i(xn,L)}async function r(){const L=e.videoMuted.value?"false":"true";await i(Qi,L)}async function l(){const L=e.videoControls.value?"false":"true";await i(Sn,L)}async function c(L){var U,x;const z=e.activeBlockId.value;if(!z)return;const N=e.rawSnippet.value||"",K=hi(N)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(L)if(L==="background"){const q={[Ze]:"background",[ke]:""};_&&K&&(e.pageBackground&&(e.pageBackground.value=K),await Fe(_,{[ot]:K}).catch(()=>{}),Le.setBlockAttrOverride(_,{[ot]:K}),et(_,{[ot]:K}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=K)),await s(q)}else(L===Cn||L===_n)&&await s({[ke]:L,[Ze]:""});else{const q={[Ze]:"",[ke]:""};if(e.activeBlockAttrs.value[ot]==="true"&&(q[ot]=""),_&&K&&((U=e.pageBackground)==null?void 0:U.value)===K&&(e.pageBackground&&(e.pageBackground.value=""),await Fe(_,{[ot]:""}).catch(()=>{}),Le.setBlockAttrOverride(_,{[ot]:""}),et(_,{[ot]:""}),(x=e.targetSlide.value)!=null&&x.frontmatter&&delete e.targetSlide.value.frontmatter.background),await s(q),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`),$=O==null?void 0:O.closest('[data-type="NodeListItem"]'),T=$==null?void 0:$.getAttribute("data-node-id");if(T&&T!==z){const P={[ke]:"",[Ze]:""};et(T,P),Le.setBlockAttrOverride(T,P),await Fe(T,P).catch(()=>{})}}}}function u(){e.elemClick.value?i(Ne,""):i(Ne,"+1")}function f(L){i(Ne,L)}function d(L){i(Xt,L)}function p(L){(e.activeBlockAttrs.value[Me]||"")===L?i(Me,""):i(Me,L)}function k(L){e.elemShikiLines.value=L,i(Ki,L)}function m(L){const z=L?L.trim():"",N=/^\d+$/.test(z)?`${z}px`:z;e.elemMaxHeight.value=N,i(Fs,N)}async function b(){const L=e.currentSlideLayout.value==="three-cols-header";await i(Me,L?"col-1":"left"),ae.showMessage(L?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function y(){const L=e.activeBlockId.value;if(!L)return;const z={[Ne]:"",[Xt]:"",[Me]:"",[Ki]:"",[Fs]:"",[qe]:"","slides-note":"",[ke]:"",[bt]:"",[Ze]:"",[vt]:"",[ot]:"",[Rt]:"",[zi]:"",[xn]:"",[Qi]:"",[Sn]:""};if(et(L,z),await Fe(L,z),Le.clearBlockAttrOverride(L),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`),K=N==null?void 0:N.closest('[data-type="NodeListItem"]'),_=K==null?void 0:K.getAttribute("data-node-id");_&&_!==L&&(et(_,z),await Fe(_,z).catch(()=>{}),Le.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ae.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function v(){if(e.activeBlockId.value)try{await Hi("markdown","---",e.activeBlockId.value,void 0),ae.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function w(){const L=e.activeBlockId.value||e.currentDocId.value;if(L)try{await Hi("markdown","---",void 0,L),ae.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function S(){if(e.activeBlockId.value)try{await Go(e.activeBlockId.value),ae.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("删除失败")}}async function B(){var L,z;try{let N=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const U=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);U&&(N=U.getAttribute("data-type")==="NodeSuperBlock"?U:U.closest('[data-type="NodeSuperBlock"]'))}if(!N){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(U){const x=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(x){let q=x.nextElementSibling;for(;q&&!(q.getAttribute("data-type")==="NodeThematicBreak"||(L=q.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));){const O=q.getAttribute("data-type")==="NodeSuperBlock"?q:q.querySelector('[data-type="NodeSuperBlock"]');if(O){N=O;break}q=q.nextElementSibling}}}else{const x=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),q=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const O of q)if(!x||O.compareDocumentPosition(x)&Node.DOCUMENT_POSITION_FOLLOWING){N=O;break}}}}const K=[];if(N){const _=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const U of _){const x=U.getAttribute("data-node-id");x&&(K.push(x),U.removeAttribute("style"))}}else if((z=e.targetSlide.value)!=null&&z.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const U of _.children)U.id&&K.push(U.id);break}}if(K.length>0)for(const _ of K)await Fe(_,{style:""}).catch(()=>{});await n(bt,""),ae.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),ae.showMessage("重置超级块比例失败")}}async function A(){var L,z,N;try{let K=null;if(typeof document<"u"){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),x=e.activeBlockId.value;let q=[];if(U){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(T){let P=T.nextElementSibling;for(;P&&!(P.getAttribute("data-type")==="NodeThematicBreak"||(L=P.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));)q.push(P),P=P.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),P=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const ne of P)if(!T||ne.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)q.push(ne);else break}const O=[];let $;for(const T of q){const P=T.getAttribute("data-type");P==="NodeHeading"&&($=T.getAttribute("data-node-id")||void 0);const ne=[];P==="NodeSuperBlock"?ne.push(T):ne.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const V of ne){if((V.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ce=V.getAttribute("data-node-id")||"";let ie=[];const re=Array.from(V.querySelectorAll('[data-type="NodeListItem"]'));if(re.length===4&&(ie=re.map(Se=>Se.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const Se=Array.from(V.querySelectorAll(":scope > [data-node-id]"));Se.length===4&&(ie=Se.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&O.push({sbId:ce,itemIds:ie,headerId:$})}}O.length>0&&(x&&(K=O.find(T=>{if(T.sbId===x||T.itemIds.includes(x))return!0;const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),ne=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);return!!(P&&ne&&P.contains(ne))})||null),K||(K=O[0]))}if(!K&&((z=e.targetSlide.value)!=null&&z.blocks)){const U=e.targetSlide.value,x=[];for(const O of U.blocks)O.rawNode?x.push(O.rawNode):x.push({id:O.id,type:O.type,content:O.content,markdown:O.rawMarkdown,children:O.children,ial:O.attributes||O.ial||{}});const q=sp(x,e.activeBlockId.value);q&&q.items.length===4&&(K={sbId:q.superBlockNode.id,itemIds:q.items.map(O=>O.id),headerId:(N=q.headerNode)==null?void 0:N.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Le.setBlockAttrOverride(_,{[ke]:"clover"}),et(_,{[ke]:"clover"}),await Fe(_,{[ke]:"clover"}).catch(()=>{})),K&&K.itemIds.length>0){K.headerId&&(Le.setBlockAttrOverride(K.headerId,{[Me]:"header"}),et(K.headerId,{[Me]:"header"}),await Fe(K.headerId,{[Me]:"header"}).catch(()=>{}));const U=Math.min(4,K.itemIds.length);for(let x=0;x<U;x++){const q=K.itemIds[x],O=`col-${x+1}`;Le.setBlockAttrOverride(q,{[Me]:O}),et(q,{[Me]:O}),await Fe(q,{[Me]:O}).catch(()=>{})}}return ae.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(K){return console.error("[layout-actions] applyCloverLayout error:",K),ae.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var z,N;const L=e.currentDocId.value||((z=e.plugin)==null?void 0:z.currentDocId);if(!L){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if((N=t.isBatchProcessing)!=null&&N.value){ae.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await hc(L,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:d,onElemSlotChange:p,onElemShikiLinesChange:k,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:v,onInsertDividerAfter:w,onDeleteCurrentBlock:S,resetSuperBlockWidth:B,applyCloverLayout:A,onAutoAnimateDocument:C}}function Ew(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:s,savePageAttr:n,applyPageLayoutAndRatio:o,saveDocAttr:a}=vw(e),r=Sw(e,{triggerSaveNotice:t}),l=Tw(e,{saveAttr:s,saveAttrs:i,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const p=e.latestDoc.value,k=await Ei(p,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Ql(p,{title:k});ec(`${k}.html`,m)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${k}.html)`)}function u(){if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}tc(e.latestDoc.value)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=ge(!1);async function d(){var p;if(f.value){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const k=e.latestDoc.value,m=await Ei(k,(p=e.currentDocId)==null?void 0:p.value,e.plugin),b=await rc(k,{title:m,onProgress:(y,v)=>{ae.showMessage(`正在导出幻灯片图片 (${y} / ${v})...`,2e3)}});b.success?ae.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ae.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:s,savePageAttr:n,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:d}}function Aw(e){const t=ye(()=>yr(e.activeBlockType.value));function i(s){const{attrKey:n,fallback:o,mode:a="defined"}=s,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Le.getBlockAttrOverride(l);if(r(c==null?void 0:c[n]))return c[n]}return o()})}return{isDivider:t,resolvePageAttr:i}}function vo(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function Bw(e,t){for(let i=t-1;i>=0;i--){const s=e[i];if(ui(s)||(s.content||s.markdown||"").trim())return s}return null}function bo(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const i=(e.markdown||e.content||"").trim();return i?i.includes("![")||i.includes("<img")||i.length>100?2:1:0}function ka(e,t){if(e===1)return"cover";let i=!1,s=-1;for(let r=0;r<t.length;r++){const l=t[r],c=(l.markdown||l.content||"").trim();if(c.includes("![")||c.includes("<img")||l.type==="img"){i=!0,s=r;break}}if(i)return s===0?"image-left":"image-right";let n=0,o=!1,a=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(o=!0),r.type==="b"&&(a=!0);return o||n>=3?"two-cols":a&&t.length<=2?"quote":"default"}function Dw(e,t){const i=[],s=new Set,n=6,o=6;let a=0,r=0,l=0,c=0,u=null;function f(d){const p=[];for(let k=d+1;k<e.length;k++){const m=e[k];if(ui(m))break;const b=vo(m);if(b!==null&&(b===1||b===2||b===3))break;p.push(m)}return p}if(e.length>0){let d=!1,p=-1;for(let k=0;k<e.length;k++){const m=e[k];if(ui(m)){d=!0;break}if((m.content||m.markdown||"").trim()){p=k;break}}if(!d&&p>=0){const k=e[p],m=vo(k);let b=m===1?"cover":"default";if(m!==1){const v=f(p);b=ka(m,v)}const y=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";i.push({blockId:k.id,recommendedLayout:b,reason:y}),s.add(k.id)}}for(let d=0;d<e.length;d++){const p=e[d];if(ui(p)){a=0,r=0,l=0,c=0,u=null;continue}const k=Bw(e,d),m=!k||ui(k),b=vo(p);if(b===1||b===2||b===3){if(!(l===1&&c===0&&u!==null&&!(u===1&&b===2))&&!m&&a>0&&!s.has(p.id)){let B=b===1?"cover":"default";{const C=f(d);B=ka(b,C)}let A=b===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":b===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";B==="image-right"||B==="image-left"?A+=" (推荐图文版式)":B==="two-cols"?A+=" (推荐双栏版式)":B==="quote"&&(A+=" (推荐引言版式)"),i.push({blockId:p.id,recommendedLayout:B,reason:A}),s.add(p.id),a=1,r=bo(p),l=1,c=0,u=b;continue}a++,r+=bo(p),l++,u=b;continue}const v=bo(p);if((a>=n||r+v>o&&a>0)&&!m&&a>0&&!s.has(p.id)){i.push({blockId:p.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s.add(p.id),a=1,r=v,l=0,c=1,u=null;continue}a++,r+=v,c++}return i}async function mc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await hs(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),s=Dw(i);if(s.length===0){ae.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ae.showMessage(`智能分析完毕：发现 ${s.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const o of s)try{await Hi("markdown","---",o.blockId,void 0),await Fe(o.blockId,{"custom-slides-layout":o.recommendedLayout}),n++}catch(a){console.warn("Failed to insert divider:",a)}ae.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function gc(e){var o,a,r,l,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await hs(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容");return}const i=[],s=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((o=f.markdown)==null?void 0:o.trim())==="---"||((a=f.markdown)==null?void 0:a.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((l=f.content)==null?void 0:l.trim())==="---")?i.push(f.id):((c=f.ial)!=null&&c[li]||(u=f.ial)!=null&&u[ke])&&s.push(f.id);if(i.length===0&&s.length===0){ae.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}ae.showMessage(`正在清除文档中的 ${i.length} 处分页线...`);let n=0;for(const f of i)try{await Go(f),n++}catch(d){console.warn("Failed to delete divider block:",d)}for(const f of s)try{await Fe(f,{[li]:"",[ke]:""})}catch(d){console.warn("Failed to clear slide attrs:",d)}ae.showMessage(`已成功清除文档中的 ${n} 处分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Lw={class:"spm-slides-inspector"},Pw={class:"spm-inspector-topbar"},Ow={class:"spm-inspector-title"},Rw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Nw={class:"spm-inspector-topbar-actions"},zw={class:"spm-target-banner"},Hw={class:"spm-target-info"},Fw=["aria-label"],jw={key:0,class:"spm-save-status"},Ww=["title"],Uw={class:"spm-inspector-body"},Vw=Dt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=zt("plugin"),s=ge(!1);function n(Q){s.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),u=ge(""),f=ge(""),d=ge(""),p=ge(""),k=ge(""),m=ge(""),b=ge(null),y=ge(""),v=ge("");function w(){var ve;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(Q).then(()=>{v.value="已复制！",setTimeout(()=>{v.value=""},1500)}).catch(()=>{})}const S=ye(()=>yr(a.value)),B=ye(()=>a.value==="NodeCodeBlock"),A=ge(!1),C=ye(()=>{if(A.value||ze.value)return!0;const Q=l.value||"";return!!hi(Q)}),L=ye(()=>{const Q=a.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ve=l.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),z=ye(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),N=ye(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),K=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(S.value)return"分页符 (---)";if(z.value)return"全局文档";if(L.value)return"视频块";let Q="内容块";switch(a.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return p.value?k.value?`${k.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),U=ye(()=>S.value?"tag-divider":z.value?"tag-doc":"tag-block"),x=ye(()=>r.value[ke]||"default"),q=ye(()=>r.value[vt]||"slide-left"),O=ge(""),$=ge(""),T=ye(()=>r.value[Ms]||"inherit"),P=ye(()=>{var Q;return hw((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),ne=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),V=ye(()=>{var Q,ve,Ae;return((Ae=(ve=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:ve[0])==null?void 0:Ae.id)||""}),Y=ye(()=>{var Ge,Ke,Re,ft,en,ki;if(S.value){const it=r.value[ke]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(d.value)return d.value;const ve=f.value||(S.value?o.value:"");if(ve){const it=Le.getBlockAttrOverride(ve);if(it!=null&&it[ke])return it[ke]}if(ve&&((Ge=b.value)!=null&&Ge.slides)){const it=b.value.slides.find(Yi=>Yi.startBlockId===ve);if((Ke=it==null?void 0:it.frontmatter)!=null&&Ke.layout)return it.frontmatter.layout}if((ft=(Re=P.value)==null?void 0:Re.frontmatter)!=null&&ft.layout)return P.value.frontmatter.layout;if((ki=(en=P.value)==null?void 0:en.blocks)!=null&&ki.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ae=Le.getBlockAttrOverride(c.value);return Ae!=null&&Ae[ke]?Ae[ke]:"default"}),ce=Aw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:f}),ie=ce.resolvePageAttr({attrKey:bt,mode:"truthy",fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.layoutRatio)||""}}),re=ce.resolvePageAttr({attrKey:ts,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.mask)||""}}),Se=ce.resolvePageAttr({attrKey:ji,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskRatio)||""}}),Ie=ce.resolvePageAttr({attrKey:is,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),_e=ce.resolvePageAttr({attrKey:ss,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const Ge=Ae.length,Ke=Ae.map(ki=>{const it=ki.getAttribute("style")||"",Yi=it.match(/calc\(\s*([\d.]+)%/);if(Yi)return parseFloat(Yi[1]);const ks=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return ks?parseFloat(ks[1]):null});let Re="",ft=!1;if(Ke.some(ki=>ki!==null)){ft=!0;const ki=Ke.reduce((Pe,pt)=>Pe+(pt||0),0),it=Ke.filter(Pe=>Pe===null).length,Yi=it>0?Math.max(0,100-ki)/it:100/Ae.length,ks=Ke.map(Pe=>Pe!==null?Pe:Yi),ld=ks.reduce((Pe,pt)=>Pe+pt,0)||1,ws=ks.map(Pe=>Pe/ld*100);if(ws.length===2){const[Pe]=ws;if(Pe>=48&&Pe<=52)Re="1:1";else if(Pe>=31&&Pe<=35)Re="1:2";else if(Pe>=65&&Pe<=69)Re="2:1";else if(Pe>=28&&Pe<=32)Re="3:7";else if(Pe>=68&&Pe<=72)Re="7:3";else if(Pe>=38&&Pe<=42)Re="4:6";else if(Pe>=58&&Pe<=62)Re="6:4";else{const pt=Math.round(Pe);Re=`${pt}:${100-pt}`}}else if(ws.length===3){const[Pe,pt,wi]=ws;if(Pe>=31&&Pe<=35&&pt>=31&&pt<=35&&wi>=31&&wi<=35)Re="1:1:1";else if(Pe>=23&&Pe<=27&&pt>=48&&pt<=52&&wi>=23&&wi<=27)Re="1:2:1";else if(Pe>=48&&Pe<=52&&pt>=23&&pt<=27&&wi>=23&&wi<=27)Re="2:1:1";else if(Pe>=23&&Pe<=27&&pt>=23&&pt<=27&&wi>=48&&wi<=52)Re="1:1:2";else{const Cr=Math.round(Pe),_r=Math.round(pt);Re=`${Cr}:${_r}:${100-Cr-_r}`}}else Re=ws.map(Pe=>Math.round(Pe)).join(":")}else ft=!1,Re=Array.from({length:Ge},()=>1).join(":");const en=Ge>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ge,ratio:Re,isCustomWidth:ft,recommendedLayout:en}}function X(Q){if(!(Q!=null&&Q.blocks))return null;for(const ve of Q.blocks){const Ae=ve.rawNode;if(Ae&&at(Ae)&&ei(Ae)){const Ke=bs(Ae).length,Re=hr(Ae);return{hasSuperBlock:!0,colCount:Ke,ratio:Re||Array.from({length:Ke},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ke>=2?"cols-header":"two-cols"}}}return null}const pe=ye(()=>{var Q;if(typeof document<"u"){const ve=o.value;if(ve){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(Ge){const Ke=Ge.getAttribute("data-type")==="NodeSuperBlock"?Ge:Ge.closest('[data-type="NodeSuperBlock"]');if(Ke){const Re=fe(Ke);if(Re)return Re}}}const Ae=f.value||(S.value?o.value:"");if(Ae){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(Ge){let Ke=Ge.nextElementSibling;for(;Ke&&!(Ke.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ke.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ke.getAttribute("data-type")==="NodeSuperBlock"?Ke:Ke.querySelector('[data-type="NodeSuperBlock"]');if(Re){const ft=fe(Re);if(ft)return ft}Ke=Ke.nextElementSibling}}}else{const Ge=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ke=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ke)if(!Ge||Re.compareDocumentPosition(Ge)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=fe(Re);if(ft)return ft}}}return X(P.value)}),E=ye(()=>{var Q;return((Q=pe.value)==null?void 0:Q.ratio)||""}),F=ye(()=>{const Q=a.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),W=ye(()=>!!(r.value[qe]||r.value["slides-note"]));function j(){if(!p.value)return!1;if(o.value===p.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${p.value}"]`)||document.querySelector(`[data-node-id="${p.value}"]`);if(!Q)return!1;const ve=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const M=ye(()=>{var ve;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(p.value&&j())return m.value||"";if(p.value)return"";const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),I=ye(()=>{var ve;if(r.value[Xt])return r.value[Xt];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),R=ye(()=>{var ve;if(r.value[Me])return r.value[Me];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),G=ge(""),D=ge(""),H=ye(()=>r.value[zi]==="true"),Z=ye(()=>r.value[xn]==="true"),te=ye(()=>r.value[Qi]==="true"),se=ye(()=>r.value[Sn]!=="false"),me=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.theme)||r.value[Ns]||"default"}),$e=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.aspectRatio)||r.value[zs]||"16/9"}),xe=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.defaultTransition)||r.value[Hs]||"slide-left"}),De=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.spacing)||r.value[_o]||"normal"}),je=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.background)||r.value[wn]||""}),ze=ye(()=>{var Ke,Re;if((r.value[Ze]||r.value["slides-role"])===Ea||r.value[ot]==="true")return"background";const ve=r.value[ke]||r.value["slides-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ae=l.value||"",Ge=hi(Ae);if(Ge&&((Re=(Ke=P.value)==null?void 0:Ke.frontmatter)!=null&&Re.background)){const ft=P.value.frontmatter.background;if(ft===Ge||ft.endsWith(Ge)||Ge.endsWith(ft))return"background"}return""}),le=ye(()=>!!(r.value[Ne]||r.value[Xt]||r.value[Me]||r.value[Ki]||r.value[qe]||r.value["slides-note"]||r.value[Ze]||r.value[ke]||r.value[zi]||r.value[xn]||r.value[Qi]||r.value[Sn])),{saveAttr:ue,savePageAttr:Oe,applyPageLayoutAndRatio:He,applyCloverLayout:We,resetSuperBlockWidth:lt,saveDocAttr:Et,onToggleVideoAutoplay:Jn,onToggleVideoLoop:Xn,onToggleVideoMuted:Qs,onToggleVideoControls:Di,onImageRoleChange:qi,onToggleNoteBlock:wc,onAddNoteBlock:xc,onLocateNoteBlock:Sc,onGenerateNotesWithAI:Cc,isBatchProcessing:kr,onBatchAppendNotes:_c,onBatchDeleteNotes:$c,onIdentifyNotesBlocks:Ic,onAutoAnimateDocument:Mc,toggleElemClick:Tc,onElemClickStepChange:Ec,onElemMotionChange:Ac,onElemSlotChange:Bc,onElemShikiLinesChange:Dc,onElemMaxHeightChange:Lc,onSetTwoColsContrast:Pc,onClearBlockAttrs:Oc,onInsertDividerBefore:Rc,onInsertDividerAfter:wr,onDeleteCurrentBlock:Nc,onExportHtml:zc,onExportPdf:Hc,onExportImages:Fc,isExportingImages:jc}=Ew({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:d,parentContainerId:p,parentContainerClicks:m,latestDoc:b,targetSlide:P,currentSlideNoteBlockId:V,currentSlideLayout:Y,isNoteBlock:W,elemClick:M,videoAutoplay:H,videoLoop:Z,videoMuted:te,videoControls:se,pageBackground:O,pageImage:$,elemShikiLines:G,elemMaxHeight:D,saveStatus:y,plugin:i});async function Wc(Q){if(Q==="clover"){if(!await We())return}else Oe(ke,Q)}function Uc(Q){Oe(bt,Q)}async function Vc(Q){await Oe(ts,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Se.value||Se.value==="1:1")&&await Oe(ji,"1:1:1:1")}function Gc(Q){Oe(ji,Q)}function Kc(Q){Oe(is,Q)}function qc(Q){Oe(ss,Q)}function xr(Q){if(!Q)return;const ve=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ae=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");He(ve,Ae)}function Yc(Q){Oe(bt,Q)}async function Zc(){await lt()}function Jc(Q){ue(vt,Q)}function Xc(Q){$.value=Q,ue(Rt,Q)}function Qc(Q){ue(Ms,Q==="inherit"?"":Q)}function ed(Q){Et(Ns,Q)}function td(Q){Et(wn,Q)}function id(Q){Et(zs,Q)}function sd(Q){Et(Hs,Q)}function nd(Q){Et(_o,Q)}function Sr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function od(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function rd(){i&&gt("aiScript")&&mc(i)}function ad(){i&&gt("aiScript")&&gc(i)}return t({setActiveBlock(Q){o.value=Q.id,a.value=Q.type,r.value={...Q.attrs},l.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,f.value=Q.pageDividerId||"",d.value=Q.pageDividerLayout||"",p.value=Q.parentContainerId||"",k.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),O.value=Q.attrs[ot]||"",$.value=Q.attrs[Rt]||"",G.value=Q.attrs[Ki]||"",D.value=Q.attrs[Fs]||"",A.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){s.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ve)=>(J(),ee("div",Lw,[h("div",Pw,[h("div",Ow,[(J(),ee("svg",Rw,[...ve[2]||(ve[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=h("span",null,"演示配置",-1))]),h("div",Nw,[he(gt)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ae=>s.value=!0)},[oe(de,{name:"import"}),ve[4]||(ve[4]=h("span",null,"导入",-1))])):Te("",!0),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Sr},[oe(de,{name:"split-preview"}),ve[5]||(ve[5]=h("span",null,"分屏预览",-1))])])]),h("div",zw,[h("div",Hw,[h("span",{class:Ce(["spm-target-tag",U.value])},we(_.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":v.value||"点击复制 ID: "+(o.value||c.value),onClick:w},[oe(de,{name:"copy"}),h("span",null,"#"+we(N.value),1)],8,Fw)]),y.value?(J(),ee("span",jw,"● "+we(y.value),1)):Te("",!0)]),K.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:l.value},we(K.value),9,Ww)):Te("",!0),h("div",Uw,[S.value?(J(),Jt(S1,{key:0,"page-layout":x.value,"page-layout-ratio":he(ie),"page-mask":he(re),"page-mask-ratio":he(Se),"page-mask-style":he(Ie),"page-mask-initial":he(_e),"detected-sb-ratio":E.value,"detected-sb-info":pe.value,"page-transition":q.value,"page-spacing":T.value,"page-image":$.value,"page-notes":ne.value,"page-index":g.value,"onUpdate:pageLayout":Wc,"onUpdate:pageLayoutRatio":Uc,"onUpdate:pageMask":Vc,"onUpdate:pageMaskRatio":Gc,"onUpdate:pageMaskStyle":Kc,"onUpdate:pageMaskInitial":qc,onApplySuperBlockLayout:xr,onResetSuperblockRatio:Zc,"onUpdate:pageTransition":Jc,"onUpdate:pageSpacing":Qc,"onUpdate:pageImage":Xc,onAddNoteBlock:he(xc),onLocateNoteBlock:he(Sc),onGenerateNotes:he(Cc),onBatchAppendNotes:he(_c),onBatchDeleteNotes:he($c),"is-batch-processing":he(kr),onInsertDividerAfter:he(wr),onDeleteDivider:he(Nc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!z.value?(J(),Jt(a0,{key:1,"elem-click":M.value,"elem-motion":I.value,"elem-slot":R.value,"elem-shiki-lines":G.value,"elem-max-height":D.value,"is-code-block":B.value,"is-image":C.value,"is-video":L.value,"is-super-block":F.value,"detected-sb-info":pe.value,"video-autoplay":H.value,"video-loop":Z.value,"video-muted":te.value,"video-controls":se.value,"has-block-attrs":le.value,"is-note":W.value,"image-role":ze.value,"current-slide-layout":Y.value,"parent-elem-click":m.value,"parent-container-slot":k.value,"parent-container-id":p.value,onToggleNote:he(wc),onToggleElemClick:he(Tc),onToggleVideoAutoplay:he(Jn),onToggleVideoLoop:he(Xn),onToggleVideoMuted:he(Qs),onToggleVideoControls:he(Di),"onUpdate:imageRole":he(qi),"onUpdate:elemClick":he(Ec),"onUpdate:elemMotion":he(Ac),"onUpdate:elemSlot":he(Bc),"onUpdate:elemShikiLines":he(Dc),"onUpdate:elemMaxHeight":he(Lc),onApplySuperBlockLayout:xr,onApplySuperBlockRatio:Yc,onInsertDividerBefore:he(Rc),onInsertDividerAfter:he(wr),onSetTwoColsContrast:he(Pc),onClearBlockAttrs:he(Oc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),Jt(fk,{key:2,"doc-theme":me.value,"doc-background":je.value,"doc-aspect-ratio":$e.value,"doc-default-transition":xe.value,"doc-spacing":De.value,"is-exporting-images":he(jc),"is-batch-processing":he(kr),"onUpdate:docTheme":ed,"onUpdate:docBackground":td,"onUpdate:docAspectRatio":id,"onUpdate:docDefaultTransition":sd,"onUpdate:docSpacing":nd,onOpenBottomPreview:Sr,onOpenPresenter:od,onIdentifyNotes:he(Ic),onAutoAnimate:he(Mc),onAiAutoSplit:rd,onClearDividers:ad,onExportHtml:he(zc),onExportPdf:he(Hc),onExportImages:he(Fc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),s.value&&he(gt)("import")?(J(),Jt(pw,{key:1,onClose:ve[1]||(ve[1]=Ae=>s.value=!1),onSuccess:n})):Te("",!0)]))}}),Gw=2e3,Kw=600;function qw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function yo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(wa(e))return!0;const t=e.firstElementChild;return!!(t&&wa(t))}function wa(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Yw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Zw{constructor(){be(this,"consumers",new Map);be(this,"seq",0);be(this,"verifyTimer",null)}register(t,i,s){if(!i)return()=>{};const n=++this.seq,o=Yw(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:s};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=yo(i),this.consumers.set(n,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?yo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!qw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const s of this.consumers.values())if(!s.visible&&yo(s.element)){s.visible=!0,(i=s.onVisible)==null||i.call(s);return}},Gw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bn=new Zw,ys=new Xs;function vc(e,t,i){const s=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},n=bn.register(e,t,s);return s(),n}let $i=null,Lt=null,yn=null;function Jw(){return Lt}function Xw(e,t){$i&&bc(),$i=fr(Ug),$i.provide("plugin",t),$i.provide("sandboxBridge",ys);const i=$i.mount(e);return Lt=i,yn=vc("preview",e,t),i}function bc(e){yn&&(yn(),yn=null),$i&&($i.unmount(),$i=null,Lt=null)}function Qw(){return Lt!==null}let Ii=null,Fi=null;function e2(e,t){return Ii&&yc(),Ii=fr(eb),Ii.provide("plugin",t),Ii.provide("sandboxBridge",ys),Fi=Ii.mount(e),Fi}function yc(e){Ii&&(Ii.unmount(),Ii=null,Fi=null)}function t2(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:e.config||{}}),t.close()}catch{}}let Mi=null,Mt=null,kn=null;function i2(e,t){Mi&&kc(),Mi=fr(Vw),Mi.provide("plugin",t),Mi.provide("sandboxBridge",ys);const i=Mi.mount(e);return Mt=i,kn=vc("dock",e,t),i}function kc(e){kn&&(kn(),kn=null),Mi&&(Mi.unmount(),Mi=null,Mt=null)}function s2(e,t){Mt!=null&&Mt.updateDocument&&Mt.updateDocument(e),Lt!=null&&Lt.updateDocument?Lt.updateDocument(e,t):(ys.updateSlides(e.slides,e.config,e.fullMarkdown),t2(e)),Fi!=null&&Fi.updateDocument&&Fi.updateDocument(e)}function Vo(e){Lt!=null&&Lt.navigateToBlock?Lt.navigateToBlock(e):ys.highlightElement(e)}function Xi(e){Mt!=null&&Mt.setActiveBlock&&Mt.setActiveBlock(e)}function n2(){return ai("import")?!1:Mt!=null&&Mt.openImportDialog?(Mt.openImportDialog(),!0):!1}const o2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"cover"},{key:vt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"two-cols"},{key:vt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"fact"},{key:vt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"intro"},{key:vt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"quote"},{key:vt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ki,value:"1-3"}]}];class ko{getPresetTemplates(){return o2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${vt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,s,n){const o=`SELECT block_id FROM attributes WHERE name = '${vt}' AND value = '${t}'`,a=await s(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[vt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,s,n){const o=`SELECT block_id FROM attributes WHERE name = '${ke}' AND value = '${t}'`,a=await s(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[ke]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}function r2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ai("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{n2()||ae.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Fe(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ae.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ai("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>mc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>gc(e)})),ai("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,f;if(!e.currentDocId){const d=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(d==null?void 0:d.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}ae.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await hs(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(d=>({id:d.id,type:d.type,content:d.content||"",rawMarkdown:d.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await bw(i,_a)).split(/\r?\n/).map(d=>`> ${d}`).join(`
`)}
{: custom-slides-note="true"}`,a=await xo("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((f=a==null?void 0:a[0])==null?void 0:f.id);r&&(await Fe(r,{"custom-slides-note":"true"}),Le.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Gi(r,e.app)),ae.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await pc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await hc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new ko,i=t.buildTransitionStatsSql(),s=await ds(i).catch(()=>[]),n=t.formatTransitionSummary(s||[]);ae.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new ko().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ae.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ae.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new ko().batchUpdateTransitions("fade","slide-left",s=>ds(s).catch(()=>[]),(s,n)=>Fe(s,n));ae.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ai("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ai("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ae.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ae.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ae.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ae.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",Co);t.success?ae.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ae.showMessage(`同步失败：${t.error}`)}})),!ai("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,s=await Ei(i,e.currentDocId,e),n=await rc(i,{title:s,onProgress:(o,a)=>{ae.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});n.success?ae.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${s}.zip！`,4e3):ae.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class a2{constructor(t=400){be(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const s=this.entries.get(t);if(s){if(i-s.at>this.ttlMs){this.entries.delete(t);return}return s.attrs}}set(t,i,s=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:s})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function l2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=s=>{for(const n of s||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const s of e.slides)i(s.blocks),i(s.noteBlocks);return t}class c2{constructor(t=150){be(this,"lastBlockId","");be(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class d2{constructor(){be(this,"attrCache",new a2);be(this,"compiledIalIndex",{doc:null,map:new Map});be(this,"locatingLockUntil",0);be(this,"lockedTargetBlockId","");be(this,"lastKnownPageDividerId","");be(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const s=Le.getBlockAttrOverride(t),n=this.getCompiledIal(i,t);if(s||n)return{...n||{},...s||{}};const o=this.attrCache.get(t);if(o)return o;const a=await Ko(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:l2(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const s=document.querySelector(".protyle .protyle-title[data-node-id]"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const s=t.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let s=i||"";if(!s&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");s=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const n=await this.resolveBlockAttrs(t,null);Xi({id:t,rootId:t,type:"doc",content:s,attrs:n,isDivider:!1,isCode:!1}),Vo(t)}handleBlockClickedFromSlide(t,i,s,n,o){var c,u,f,d;if(!t){Rs();const p=typeof o=="number"&&o>0?o:1,k=((c=n==null?void 0:n.slides)==null?void 0:c[p-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(k){const m=k.startBlockId||"",b=((f=k.frontmatter)==null?void 0:f.layout)||"",y={"custom-slides-layout":b,...k.frontmatter};return Xi({id:m,rootId:s,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,n).then(v=>{v&&Object.keys(v).length>0&&Xi({id:m,rootId:s,type:"NodeThematicBreak",attrs:{...y,...v},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(s),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Gi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,s,n);else{let p="",k="";if(n!=null&&n.slides){const m=n.slides.find(b=>{var y,v,w;return b.startBlockId===t||((y=b.blocks)==null?void 0:y.some(S=>S.id===t))||((v=b.allBlockIds)==null?void 0:v.includes(t))||((w=b.noteBlocks)==null?void 0:w.some(S=>S.id===t))});m!=null&&m.startBlockId&&(p=m.startBlockId),(d=m==null?void 0:m.frontmatter)!=null&&d.layout&&(k=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(p&&!k){const b=Le.getBlockAttrOverride(p);if(b!=null&&b[ke]||b!=null&&b["custom-slides-layout"])k=b[ke]||b["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(p,n);k=y[ke]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Le.setBlockAttrOverride(p,y)}}Xi({id:t,rootId:s,type:l||"NodeParagraph",attrs:m||{},pageDividerId:p,pageDividerLayout:k})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,s,n,o){var q,O,$,T,P,ne,V,Y,ce;if(this.isLocatingLocked(i))return;let a=t,r=i,l=s;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const re=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...re,...Se};(Ie[qe]||Ie["slides-note"])&&(a=c,r=ie,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,d=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((q=u==null?void 0:u.classList)!=null&&q.contains("hr")),p=l==="NodeCodeBlock",k=((O=a.innerText)==null?void 0:O.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Le.getBlockAttrOverride(r)||{},y={...m,...b};let v="",w="";if(d)v=r,w=y[ke]||y["custom-slides-layout"]||"";else{let ie=u.previousElementSibling;for(;ie;){const re=ie.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||($=ie.classList)!=null&&$.contains("hr")){v=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(o!=null&&o.slides){const ie=[r,f];let re=a.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const Ie=re.getAttribute("data-node-id");Ie&&!ie.includes(Ie)&&ie.push(Ie),re=re.parentElement}const Se=o.slides.find(Ie=>{var _e,fe,X;return ie.includes(Ie.startBlockId)||((_e=Ie.blocks)==null?void 0:_e.some(pe=>ie.includes(pe.id)))||((fe=Ie.allBlockIds)==null?void 0:fe.some(pe=>ie.includes(pe)))||((X=Ie.noteBlocks)==null?void 0:X.some(pe=>ie.includes(pe.id)))});Se&&(!v&&Se.startBlockId&&(v=Se.startBlockId),!w&&((T=Se.frontmatter)!=null&&T.layout)&&(w=Se.frontmatter.layout))}if(v?(this.lastKnownDocId=n,this.lastKnownPageDividerId=v):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((P=u.parentElement)==null?void 0:P.scrollTop)||0)===0||(v=this.lastKnownPageDividerId)),v){const ie=Le.getBlockAttrOverride(v);if(ie&&(ke in ie||"custom-slides-layout"in ie)&&(w=ie[ke]||ie["custom-slides-layout"]||""),!w&&(o!=null&&o.slides)){const re=o.slides.find(Se=>Se.startBlockId===v);(ne=re==null?void 0:re.frontmatter)!=null&&ne.layout&&(w=re.frontmatter.layout)}if(!w){const re=await this.resolveBlockAttrs(v,o);w=re[ke]||re["custom-slides-layout"]||"",re&&Object.keys(re).length>0&&Le.setBlockAttrOverride(v,re)}et(v,{[ke]:w||""})}else if(n){const ie=Le.getBlockAttrOverride(n);ie&&(ke in ie||"custom-slides-layout"in ie)?w=ie[ke]||ie["custom-slides-layout"]||"":!w&&((ce=(Y=(V=o==null?void 0:o.slides)==null?void 0:V[0])==null?void 0:Y.frontmatter)!=null&&ce.layout)&&(w=o.slides[0].frontmatter.layout)}const S=a.getAttribute(ke)||a.getAttribute("custom-slides-layout"),B=y[ke]||y["custom-slides-layout"]||"";S&&S!==B&&et(r,{[ke]:B});const A=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=y[Ze]||y["custom-slides-role"]||"";A&&A!==C&&et(r,{[Ze]:C});let L="",z="",N="";const K=a.closest('[data-type="NodeListItem"]');if(K&&K!==a){const ie=K.getAttribute("data-node-id");if(ie){L=ie;const re=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...re,...Se};z=Ie[Me]||"",N=Ie[Ne]||"";const _e=Ie[ke]||Ie["custom-slides-layout"]||"",fe=K.getAttribute(ke)||K.getAttribute("custom-slides-layout");fe&&fe!==_e&&et(ie,{[ke]:_e});const X=Ie[Ze]||Ie["custom-slides-role"]||"",pe=K.getAttribute(Ze)||K.getAttribute("custom-slides-role");pe&&pe!==X&&et(ie,{[Ze]:X})}}const _=!!a.querySelector("img, span[data-type='img']"),U=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=_&&U.length<=50;Xi({id:r,rootId:n,type:l,content:k,attrs:y,isDivider:d,isCode:p,isImage:x,topBlockId:f,pageDividerId:v,pageDividerLayout:w,parentContainerId:L,parentContainerSlot:z,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const s of i.doOperations)if((s==null?void 0:s.action)==="updateAttrs"&&s.id&&s.data){const n=s.data.old||{},o=s.data.new||{},a={};for(const r of Object.keys(n))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");et(s.id,a),Le.setBlockAttrOverride(s.id,a)}}}}purgeStaleDomSlidesAttrs(t){var n,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(l[ke]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[ke]&&(c[ke]=l.ial[ke]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const s=Le.getAllAttrOverrides();for(const[r,l]of s.entries()){const c=i.get(r)||{};l[ke]!==void 0&&(c[ke]=l[ke]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}mw(i)}}const Si=new d2;class u2{constructor(){be(this,"state","IDLE");be(this,"inFlightDocId",null);be(this,"pendingDocs",new Set);be(this,"lastPendingDocId",null);be(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const f2=150,p2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,h2="slides-dock",wo="slides-preview-tab",xa="slides-presenter-tab",Sa=Jf;class m2 extends ae.Plugin{constructor(){super(...arguments);be(this,"isMobile",!1);be(this,"currentDocId","");be(this,"previewTab",null);be(this,"latestCompiledDoc",null);be(this,"cliBridge",new gr);be(this,"debounceTimer",null);be(this,"activeCursorBlockId","");be(this,"cancelledCursorBlockId","");be(this,"compileScheduler",new u2);be(this,"dirtyDocId",null);be(this,"inspectorSyncThrottle",new c2);be(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));be(this,"onWsMainBound",this.onWsMain.bind(this));be(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));be(this,"onEditorClickBound",this.onEditorClick.bind(this));be(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));be(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));be(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ae.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(p2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),r2(this);const s=this;if(this.addTab({type:wo,init(n){var r;const o=this||n;s.previewTab=(o==null?void 0:o.tab)||null,Xw(o.element,s);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!s.getActiveDocumentId()&&s.compileCurrentDocument(a,{reason:"explicit"}),s.updatePreviewTabHeader()},destroy(){s.previewTab===(this==null?void 0:this.tab)&&(s.previewTab=null),bc(this.element)}}),this.addTab({type:xa,init(n){e2((this||n).element,s)},destroy(){yc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:h2,init(){i2(this.element,s)},destroy(){kc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Sa),s=Xf(i);return ri(s),s}catch{return ri(Ti),Ti}}async saveGlobalSettings(i){const s=Zn(),n=ri({...s,...i||{}});try{await this.saveData(Sa,n)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bn.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),ys.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(i);await ae.openTab({app:this.app,custom:{id:this.name+wo,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ai("presenterMode")||(Qw()||await this.openBottomPreviewTab(),await ae.openTab({app:this.app,custom:{id:this.name+xa,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ae.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let s=this.previewTab;if(!s){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(n),a=await ae.openTab({app:this.app,custom:{id:this.name+wo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});s=this.previewTab||a}s&&(this.currentDocId&&s.model&&(s.model.data={...s.model.data||{},docId:this.currentDocId}),ae.openWindow({tab:s,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const s=(a=i.detail)==null?void 0:a.protyle,n=(r=s==null?void 0:s.block)==null?void 0:r.rootID,o=((u=(c=(l=s==null?void 0:s.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const f=await Ko(n).catch(()=>({}));Xi({id:n,rootId:n,type:"doc",attrs:f}),this.markCompileDirty(n),this.updatePreviewTabHeader(o,n)}}onClickEditorContent(i){var o,a;const s=i==null?void 0:i.detail;if(!s)return;const n=(a=(o=s.protyle)==null?void 0:o.block)==null?void 0:a.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}buildPreviewTabTitle(i){return sc(i)}async fetchDocumentTitle(i){return nc(this,i)}async updatePreviewTabHeader(i,s){return Cg(this,i,s)}getActiveDocumentId(){return Si.getActiveDocumentId()}resolveDocIdFromElement(i){return Si.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,s){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Si.switchToDocGlobalInspector(i,s))}onWsMain(i){const s=i.detail;s&&s.cmd==="transactions"&&(Si.patchThematicBreakTransactions(s),this.markCompileDirty())}markCompileDirty(i){const s=i||this.currentDocId||this.getActiveDocumentId();s&&(this.currentDocId||(this.currentDocId=s),this.dirtyDocId=s,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=f2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const s=bn.getVisibility();if(s==="none")return;const n=s==="visible"?i:Math.max(i,Kw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,s){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Si.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,s)}onBlockClickedFromSlide(i){const s=(i==null?void 0:i.detail)||i;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(i){const s=i.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const f=n||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),d=f==null?void 0:f.querySelector(".protyle-title__input"),p=((d==null?void 0:d.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,Vo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const s=i.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const o=n.closest(".protyle-title");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const f=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),d=f==null?void 0:f.querySelector(".protyle-title__input"),p=((d==null?void 0:d.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(Si.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,Vo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,s,n){this.inspectorSyncThrottle.shouldSkip(s)||await Si.syncInspectorBlock(i,s,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,s){const n=(s==null?void 0:s.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(n==="auto"&&bn.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Le.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,s2(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){Si.purgeStaleDomSlidesAttrs(i)}}module.exports=m2;
