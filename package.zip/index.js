"use strict";var Ea=Object.create;var Eo=Object.defineProperty;var Ma=Object.getOwnPropertyDescriptor;var Da=Object.getOwnPropertyNames;var La=Object.getPrototypeOf,Pa=Object.prototype.hasOwnProperty;var Ra=(t,i,e)=>i in t?Eo(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var Oa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of Da(i))!Pa.call(t,o)&&o!==e&&Eo(t,o,{get:()=>i[o],enumerable:!(n=Ma(i,o))||n.enumerable});return t};var On=(t,i,e)=>(e=t!=null?Ea(La(t)):{},Oa(i||!t||!t.__esModule?Eo(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>Ra(t,typeof i!="symbol"?i+"":i,e);const mt=require("siyuan");async function ve(t,i){const e=await mt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function za(){return ve("/api/notebook/lsNotebooks","")}async function Na(t,i,e){return ve("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function Er(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return ve("/api/asset/upload",e)}async function an(t,i,e,n,o){return ve("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Mr(t,i,e){return ve("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Hs(t,i,e){return ve("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Fa(t){return ve("/api/block/deleteBlock",{id:t})}async function ja(t){return ve("/api/block/getBlockKramdown",{id:t})}async function Xn(t){return ve("/api/block/getChildBlocks",{id:t})}async function Pt(t,i){return ve("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ze(t){return ve("/api/attr/getBlockAttrs",{id:t})}async function bn(t){return ve("/api/query/sql",{stmt:t})}async function Ko(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ve("/api/file/putFile",n)}async function Dr(t){const i="/api/ai/chatGPT";try{const e=await ve(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function Ha(){return ve("/api/storage/getInlineStyles","")}const Lr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ua(t){const i=[];if(!t)return i;const e=new RegExp(Lr.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function Wa(t,i){if(!t)return"";const e=new RegExp(Lr.source,"g");return t.replace(e,(n,o,r,l,s)=>{const a=(r??l??s??"").trim();if(i&&i[o]){const d=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const yn="custom-slidev-theme",kn="custom-slidev-aspect-ratio",Pr="custom-slidev-highlighter",wn="custom-slidev-default-transition",Rr="custom-slidev-color-schema",qo="custom-slidev-spacing",$i="custom-slidev-slide",dt="custom-slidev-layout",Qt="custom-slidev-transition",Ht="custom-slidev-background",Be="custom-slidev-image",ji="custom-slidev-notes",Hi="custom-slidev-class",un="custom-slidev-spacing",Zt="custom-slidev-layout-ratio",$e="custom-slidev-click",Ve="custom-slidev-motion",Li="custom-slidev-shiki-lines",Tt="custom-slidev-slot",se="custom-slidev-note",Vt="custom-slidev-role",xn="custom-slidev-max-height",Ii="custom-slidev-autoplay",Qn="custom-slidev-loop",Fi="custom-slidev-muted",to="custom-slidev-controls",Or="background",eo="image-left",io="image-right";function Va(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Ka(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}function qa(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Ga(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Ce(t,i){if(!qa(t))return t;const e=Ga(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Za(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,r)=>{const l=Ce(r,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,r,l)=>{const s=Ce(r,i);return`${o}${s}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,r,l)=>{const s=Ce(r,i);return`${o}${s}${l}`}),e}const ki={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function Ya(t){var i,e,n,o,r,l;return t?{theme:((i=t[yn])==null?void 0:i.trim())||ki.theme,aspectRatio:((e=t[kn])==null?void 0:e.trim())||ki.aspectRatio,highlighter:((n=t[Pr])==null?void 0:n.trim())||ki.highlighter,defaultTransition:((o=t[wn])==null?void 0:o.trim())||ki.defaultTransition,colorSchema:((r=t[Rr])==null?void 0:r.trim())||ki.colorSchema,spacing:((l=t[qo])==null?void 0:l.trim())||ki.spacing}:{...ki}}function no(t){var e,n,o,r,l;const i=(e=t.ial)==null?void 0:e[$i];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Us(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[dt]&&(i.layout=t[dt].trim()),t[Qt]&&(i.transition=t[Qt].trim()),t[Ht]&&(i.background=t[Ht].trim()),t[Be]&&(i.image=t[Be].trim()),t[Hi]&&(i.class=t[Hi].trim()),t[un]&&(i.spacing=t[un].trim()),t[Zt]&&(i.layoutRatio=t[Zt].trim()),t[ji]&&(e=t[ji].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![dt,Zt,Qt,Ht,Be,Hi,un,ji,$i].includes(n)){const r=n.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(o)}catch{i[r]=o}}return{frontmatter:i,notes:e}}function Ja(t){const i={};if(!t)return i;const e=t[se]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[Vt]??t["slidev-role"],o=t[Ht]??t["slidev-background"];(n===Or||o==="true"||o==="1")&&(i.isBackground=!0);const r=t[dt]??t["slidev-layout"];r===eo||r===io?i.imageLayout=r:(n===eo||n===io)&&(i.imageLayout=n);const l=t[$e]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ve])try{const s=JSON.parse(t[Ve]);typeof s=="object"&&s!==null?i.motion={preset:s.preset||s.type||"fade-in",...s}:i.motion={preset:String(s).trim()}}catch{i.motion={preset:t[Ve].trim()}}return t[Li]&&(i.shikiLines=t[Li].trim()),t[xn]&&(i.maxHeight=t[xn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function mi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function Go(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,r=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return r;const s=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){s.push("");continue}const d=c.match(/^(\s*)/),u=d?d[1].length:0;u>=l?s.push(c.slice(l)):u>o?s.push(c.slice(u)):s.push(c)}return s.join(`
`)}function Zi(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function zn(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(r=>parseFloat(r.trim())).filter(r=>!isNaN(r)&&r>0);if(o.length>=2)return o.map(r=>`${r}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function Ai(t){if(!t)return[];if(oe(t)&&ni(t)&&!gi(t)){const n=Bn(t),o=[];for(const r of n)o.push(...Ai(r));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Zi);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&r.push(l);if(r.length>=2){const l=[];for(let s=0;s<r.length;s++){const a=r[s],c=s+1<r.length?r[s+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${s+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Zi(t)?[t]:[]}function zr(t){var n;if(!t||!oe(t)||!ni(t)||gi(t))return null;const i=Bn(t);if(i.length===0)return null;if(i.length===1&&oe(i[0])&&ni(i[0])){const o=zr(i[0]);return o?{items:o.items,nestedSuperBlocks:[i[0],...o.nestedSuperBlocks]}:null}const e=[];for(const o of i)if(oe(o)){e.push(o);const r=((n=o.children)==null?void 0:n.filter(oe))||[];e.push(...r)}if(i.length===3){const o=Ai(i[0]),r=Ai(i[1]),l=Ai(i[2]);if(o.length===1&&r.length===1&&l.length===1)return{items:[o[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const o=Ai(i[0]),r=Ai(i[1]);if(o.length===2&&r.length===1)return{items:[o[0],o[1],r[0]],nestedSuperBlocks:e};if(o.length===1&&r.length===2)return{items:[o[0],r[0],r[1]],nestedSuperBlocks:e};if(o.length===1&&r.length===1)return{items:[o[0],r[0]],nestedSuperBlocks:e}}return null}function Xa(t){if(!t||!oe(t)||!ni(t)||gi(t))return null;const i=zr(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length!==2&&e.length!==3)return null;const o=ds(t)||void 0;return e.length===2?{superBlockNode:t,nestedSuperBlocks:n,count:2,layout:"two-cols-header",items:e,slots:["left","right"],ratio:o}:{superBlockNode:t,nestedSuperBlocks:n,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"],ratio:o}}function Qa(t){if(!t||!oe(t)||!ni(t)||gi(t))return null;const i=Bn(t);if(i.length===0)return null;const e=[];for(const n of i){const o=Ai(n);if(o.length===0)return null;e.push(...o)}return e}function tc(t){if(!t||!oe(t)||!ni(t)||gi(t))return null;const i=Qa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function ec(t,i,e){var d,u,g,f,y,h;const n=[],o=[],r=(e==null?void 0:e.tracked)||[],l=[];let s={pageTargetId:t,blocks:[]};l.push(s);for(let k=0;k<i.length;k++){const b=i[k];if(no(b)){if(l.length===1&&s.blocks.length===0){s.pageTargetId=b.id,s.blocks.push(b);continue}s={pageTargetId:b.id,blocks:[b]},l.push(s)}else s.blocks.push(b)}function a(k){const b=[];for(const w of k)oe(w)&&b.push(w),w.children&&w.children.length>0&&b.push(...a(w.children));return b}function c(k,b,w){const _={blockId:k,attrs:b,previousAttrs:w};n.push(_),e!=null&&e.onTagChange&&e.onTagChange(_)}for(const k of l){const b=k.pageTargetId,w=i.find(B=>B.id===b),_=r.find(B=>B.pageTargetId===b);if(k.blocks.some(B=>{var D,M;return!!(gi(B)||Zo(B)&&(((D=B.ial)==null?void 0:D[dt])==="image-left"||((M=B.ial)==null?void 0:M[dt])==="image-right"))})){if(_){const B=_.headerId;if(B){c(B,{[Tt]:""});const D=i.find(M=>M.id===B);D!=null&&D.ial&&(D.ial[Tt]="")}for(const D of _.itemIds){c(D,{[Tt]:""});const M=i.find(O=>O.id===D);M!=null&&M.ial&&(M.ial[Tt]="")}}continue}let x=null,S=-1;for(let B=0;B<k.blocks.length;B++){const D=k.blocks[B],M=oe(D)?[D,...a(D.children||[])]:D.children?a(D.children):[];for(const O of M){const Z=Xa(O);if(Z){x=Z,S=B;break}}if(x)break}if(x){const{superBlockNode:B,layout:D,items:M,slots:O}=x,I=k.blocks.slice(0,S).find(j=>nc(j)),P=I==null?void 0:I.id,v=((d=w==null?void 0:w.ial)==null?void 0:d[dt])||"";v!==D&&(c(b,{[dt]:D},{[dt]:v}),w&&(w.ial||(w.ial={}),w.ial[dt]=D));const G=((u=w==null?void 0:w.ial)==null?void 0:u[Zt])||"",A=x.ratio;if(!G&&A&&(c(b,{[Zt]:A}),w&&(w.ial||(w.ial={}),w.ial[Zt]=A)),I){const j=((g=I.ial)==null?void 0:g[Tt])||"";j!=="header"&&(c(I.id,{[Tt]:"header"},{[Tt]:j}),I.ial||(I.ial={}),I.ial[Tt]="header")}if(_!=null&&_.headerId&&_.headerId!==P){c(_.headerId,{[Tt]:""});const j=i.find(N=>N.id===_.headerId);j&&(j.ial||(j.ial={}),j.ial[Tt]="")}const E=[];for(let j=0;j<M.length;j++){const N=M[j],J=O[j];E.push(N.id);const H=((f=N.ial)==null?void 0:f[Tt])||"";if(H!==J&&(c(N.id,{[Tt]:J},{[Tt]:H}),N.ial||(N.ial={}),N.ial[Tt]=J),N.children&&N.children.length>0)for(const K of N.children)K.ial||(K.ial={}),K.ial[Tt]!==J&&(K.ial[Tt]=J)}if(_!=null&&_.itemIds){for(const j of _.itemIds)if(!E.includes(j)){c(j,{[Tt]:""});const N=i.find(J=>J.id===j);N&&(N.ial||(N.ial={}),N.ial[Tt]="")}}o.push({superBlockId:B.id,nestedSuperBlockIds:(y=x.nestedSuperBlocks)==null?void 0:y.map(j=>j.id),pageTargetId:b,headerId:P,itemIds:E,layout:D})}else{let B=!1;const D=[];for(const Z of k.blocks){const I=oe(Z)?[Z,...a(Z.children||[])]:Z.children?a(Z.children):[];for(const P of I){const v=tc(P);if(v){B=!0;for(const G of v.items)D.push(G.id)}}}const M=((h=w==null?void 0:w.ial)==null?void 0:h[dt])||"";if(_||B&&(M==="two-cols-header"||M==="three-cols-header")){c(b,{[dt]:""},{[dt]:M}),w&&(w.ial||(w.ial={}),w.ial[dt]="");const Z=_==null?void 0:_.headerId;if(Z){c(Z,{[Tt]:""});const P=i.find(v=>v.id===Z);P&&(P.ial||(P.ial={}),P.ial[Tt]="")}const I=new Set([...(_==null?void 0:_.itemIds)||[],...D]);for(const P of I){c(P,{[Tt]:""});const v=i.find(G=>G.id===P);v&&(v.ial||(v.ial={}),v.ial[Tt]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function ni(t){if(!oe(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Zo(t){return!t||Zi(t)||oe(t)||!mi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function ds(t){var g;if(!t||!oe(t)||!ni(t))return null;const i=Bn(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const f of i){const y=(((g=f.ial)==null?void 0:g.style)||f.style||"").trim();let h=null;if(y){const k=y.match(/calc\(\s*([\d.]+)%/i);if(k)h=parseFloat(k[1]);else{const b=y.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);b&&(h=parseFloat(b[1]))}}h!==null&&!isNaN(h)&&h>0?(e.push(h),n=!0):e.push(null)}if(!n)return null;const o=i.length,r=e.reduce((f,y)=>f+(y||0),0),l=e.filter(f=>f===null).length,s=Math.max(0,100-r),a=l>0?s/l:100/o,c=e.map(f=>f!==null?f:a),d=c.reduce((f,y)=>f+y,0);if(d<=0)return null;const u=c.map(f=>f/d*100);if(u.length===2){const[f]=u;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const y=Math.round(f),h=100-y;return`${y}:${h}`}if(u.length===3){const[f,y,h]=u;if(f>=31&&f<=35&&y>=31&&y<=35&&h>=31&&h<=35)return"1:1:1";if(f>=23&&f<=27&&y>=48&&y<=52&&h>=23&&h<=27)return"1:2:1";if(f>=48&&f<=52&&y>=23&&y<=27&&h>=23&&h<=27)return"2:1:1";if(f>=23&&f<=27&&y>=23&&y<=27&&h>=48&&h<=52)return"1:1:2";if(f>=18&&f<=22&&y>=58&&y<=62&&h>=18&&h<=22)return"1:3:1";const k=Math.round(f),b=Math.round(y),w=100-k-b;return`${k}:${b}:${w}`}return u.map(f=>Math.round(f)).join(":")}function gi(t){if(!t||!oe(t)||!ni(t))return null;const i=(t.children||[]).filter(r=>{const l=r.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const s=(r.markdown||r.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")});if(i.length<2)return null;const e=Zo(i[0]),n=Zo(i[i.length-1]),o=ds(t)||void 0;if(e&&!n){const r=mi(i[0].markdown,i[0].content);if(r)return{imageNode:i[0],imageUrl:r,layout:eo,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const r=mi(i[i.length-1].markdown,i[i.length-1].content);if(r)return{imageNode:i[i.length-1],imageUrl:r,layout:io,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function ic(t,i){const e=[];function n(o){for(const r of o){const l=gi(r);if(l){const{imageNode:s,layout:a,ratio:c}=l;s.ial||(s.ial={});const d=s.ial[dt],u=s.ial[Zt],g=d!==a,f=!u&&!!c;if(g||f){const y={blockId:s.id,layout:a,previousLayout:d,ratio:c||u};s.ial[dt]=a,f&&c&&(s.ial[Zt]=c),e.push(y),i&&i(y)}}r.children&&r.children.length>0&&n(r.children)}}return n(t),e}function Bn(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function nc(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function wi(t,i,e){let n="",o=0;const r=/<div\b([^>]*)>/gi;for(;o<t.length;){r.lastIndex=o;let l,s=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const w=b[1];if(typeof i=="string"?w.split(/\s+/).includes(i):i.test(w)){s=!0,a=l.index,c=l[0].length;break}}}if(!s){n+=t.slice(o);break}n+=t.slice(o,a);const d=a+c;let u=1,g=-1,f=-1;const y=/<\/?div\b[^>]*>/gi;y.lastIndex=d;let h;for(;(h=y.exec(t))!==null;)if(h[0].startsWith("</")){if(u--,u===0){g=h.index,f=h.index+h[0].length;break}}else u++;if(g!==-1&&f!==-1){const k=t.slice(d,g);n+=e(k),o=f}else n+=t.slice(a,d),o=d}return n}function oc(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let r,l=!1,s=-1,a=0;for(;(r=o.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,s=r.index,a=r[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,s);const c=s+a;let d=1,u=-1,g=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let y;for(;(y=f.exec(t))!==null;)if(y[0].startsWith("</")){if(d--,d===0){u=y.index,g=y.index+y[0].length;break}}else d++;if(u!==-1&&g!==-1){const h=t.slice(s,g),k=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=k,n=g}else e+=t.slice(s,c),n=c}return{text:e,tokens:i}}function sc(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,s=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(s),a});const{text:o,tokens:r}=oc(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(s,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(s,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=wi(e,"diff-grid",s=>{const a=Array.from(s.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),u=c[3].trim();return`**${d}:**
\`\`\`yaml
${u}
\`\`\``}).join(`

`)+`
`:s}),e=wi(e,"before-after",s=>{const a=s.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=s.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:s}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(s,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=wi(e,"timeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let u="-";return d.includes("warn")?u="- ⚠️":d.includes("bad")?u="- ❌":d.includes("ok")&&(u="- ✅"),`${u} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:s}),e=wi(e,"pipeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:s}),e=wi(e,"check-grid",s=>{const a=Array.from(s.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:s}),e=wi(e,"manifesto",s=>{const a=Array.from(s.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:s}),e=wi(e,"split-note",s=>{const a=Array.from(s.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:s}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(s,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(s,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(s,a,c)=>/@|v-|:|class=/i.test(a)?s:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(s,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((u,g)=>Math.max(u,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(s,a,c,d,u)=>{const g=u.trim();return g.includes("<")||g.includes(`
`)?s:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(s,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let s=0;s<l.length;s++)e=e.replace(`__VUE_COMP_TOKEN_${s}__`,l[s]);for(let s=0;s<r.length;s++)e=e.replace(`__VUE_DIV_TOKEN_${s}__`,r[s]);for(let s=0;s<n.length;s++)e=e.replace(`__SCRIPT_TOKEN_${s}__`,n[s]);for(let s=0;s<i.length;s++)e=e.replace(`__CODE_TOKEN_${s}__`,i[s]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Nr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function rc(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function lc(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function ac(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function cc(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Ws(t,i,e,n){const o=i!=null&&i.trim()!=="",r=cc(e),l=n==null?void 0:n.trim(),s=l!==void 0&&l!=="",a=s?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!r)return s?`<div${a}>

${t}

</div>`:t;if(o&&!r){if(s){const y=i.trim();let h="v-click";return y==="hide"?h="v-click.hide":y!==""&&y!=="+1"&&(h=`v-click="${y}"`),`<div ${h}${a}>

${t}

</div>`}return ac(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),u=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${u}${a}>

${t}

</div>`;const g=i.trim();let f="v-click";return g==="hide"?f="v-click.hide":g!==""&&g!=="+1"&&(f=`v-click="${g}"`),`<div ${f} ${u}${a}>

${t}

</div>`}function Fr(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function dc(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function jr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const s=Math.ceil(l.length/3),a=Math.ceil((l.length-s)/2);return{col1:l.slice(0,s),col2:l.slice(s,s+a),col3:l.slice(s+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const s=l.slot||"";return s==="col-1"||s==="left"?1:s==="col-2"||s==="center"?2:s==="col-3"||s==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),s=e.includes(3);if(l||s){const d=[],u=[],g=[];let f=1;for(const y of t){const h=i(y);h!==null&&(f=h),f===1?d.push(y):f===2?u.push(y):g.push(y)}return{col1:d,col2:u,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const o=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const s=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(s)},r=t.map((l,s)=>o(l)?s:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),s=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+s),col3:t.slice(l+s)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],s=(l.rawMarkdown||l.content||"").trim(),a=s.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),f=Math.ceil((c.length-g)/2),y=a.slice(c[0],c[g]).join(`
`),h=a.slice(c[g],c[g+f]).join(`
`),k=a.slice(c[g+f]).join(`
`);return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const d=s.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),f=Math.ceil((d.length-g)/2),y=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,h=`<ul>
${d.slice(g,g+f).join(`
`)}
</ul>`,k=`<ul>
${d.slice(g+f).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const u=s.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(u.length>=3){const g=Math.ceil(u.length/3),f=Math.ceil((u.length-g)/2);return{col1:[{...l,rawMarkdown:u.slice(0,g).join(`

`),content:u.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:u.slice(g,g+f).join(`

`),content:u.slice(g,g+f).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:u.slice(g+f).join(`

`),content:u.slice(g+f).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function Vs(t,i,e,n){var d;const o=Ya(i),r=[],l=Us(i);let s={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};s.frontmatter.background&&(s.frontmatter.background=Ce(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=Ce(s.frontmatter.image,n)),r.push(s);let a=[];for(const u of e){if(no(u)){a=[];const f=Us(u.ial);if(r.length===1&&s.blocks.length===0){s.startBlockId=u.id,s.allBlockIds||(s.allBlockIds=[]),s.allBlockIds.includes(u.id)||s.allBlockIds.push(u.id),f.frontmatter.layout&&(s.frontmatter.layout=f.frontmatter.layout),Object.assign(s.frontmatter,f.frontmatter),!f.frontmatter.image&&l.frontmatter.image&&(s.frontmatter.image=l.frontmatter.image),!f.frontmatter.background&&l.frontmatter.background&&(s.frontmatter.background=l.frontmatter.background),s.frontmatter.background&&(s.frontmatter.background=Ce(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=Ce(s.frontmatter.image,n));continue}s={pageIndex:r.length+1,startBlockId:u.id,frontmatter:{layout:f.frontmatter.layout||"default",...f.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[u.id]},s.frontmatter.background&&(s.frontmatter.background=Ce(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=Ce(s.frontmatter.image,n)),r.push(s);continue}const g=f=>{var P;if(s.allBlockIds||(s.allBlockIds=[]),f.id&&!s.allBlockIds.includes(f.id)&&s.allBlockIds.push(f.id),f.children&&f.children.length>0){const v=G=>{for(const A of G)A.id&&!s.allBlockIds.includes(A.id)&&s.allBlockIds.push(A.id),A.children&&A.children.length>0&&v(A.children)};v(f.children)}let y=Va(f),h=f.ial?{...f.ial}:{};const k=y.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(h={...Ka(k[0]),...h},y=y.slice(0,k.index).trim()),f.type!=="c"&&!y.startsWith("```")&&(y=Nr(y));let b=y.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(b)||b==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(b)&&/\r?\n\}\}\}$/.test(b)&&(y=b.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),b=y.trim());const w=Ja(h);if(y=Za(y,n),y=Wa(y,n==null?void 0:n.refContentMap),f.children&&f.children.length>0){const v=G=>{for(const A of G){if(A.ial)for(const[E,j]of Object.entries(A.ial))E.startsWith("custom-slidev-")&&!h[E]&&(h[E]=j);A.children&&A.children.length>0&&v(A.children)}};v(f.children)}const _=f.type==="video"||f.type==="NodeVideo"||/<video\b/i.test(y);if(_){const v=h["custom-slidev-autoplay"]==="true",G=h["custom-slidev-loop"]==="true",A=h["custom-slidev-muted"]==="true"||v,E=h["custom-slidev-controls"]==="false";y=y.replace(/<video\b([^>]*)>/gi,(j,N)=>{let J=N;return E?J=J.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(J)||(J+=" controls"),v&&!/autoplay/i.test(J)?J+=" autoplay playsinline":!v&&h["custom-slidev-autoplay"]==="false"&&(J=J.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),G&&!/loop/i.test(J)?J+=" loop":!G&&h["custom-slidev-loop"]==="false"&&(J=J.replace(/\bloop\b/gi,"").trim()),A&&!/muted/i.test(J)?J+=" muted":!A&&h["custom-slidev-muted"]==="false"&&(J=J.replace(/\bmuted\b/gi,"").trim()),`<video ${J.trim()}>`})}if(w.isBackground){const v=mi(y,f.content);if(v){s.frontmatter.background=Ce(v,n);return}}const T=gi(f);if(T){s.frontmatter.layout=T.layout,s.frontmatter.image=Ce(T.imageUrl,n),!s.frontmatter.layoutRatio&&T.ratio&&(s.frontmatter.layoutRatio=T.ratio);for(const v of T.contentNodes)g(v);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const v=mi(y,f.content);if(v){s.frontmatter.layout=w.imageLayout,s.frontmatter.image=Ce(v,n),!s.frontmatter.layoutRatio&&((P=f.ial)!=null&&P[Zt])&&(s.frontmatter.layoutRatio=f.ial[Zt]);return}}if(oe(f)&&f.children&&f.children.length>0){for(const v of f.children)g(v);return}if((f.type==="l"||f.type==="NodeList"||f.type==="list")&&f.children&&f.children.length>0&&(f.children.some(v=>{var G;return(G=v.ial)==null?void 0:G[Tt]})||w.slot)){for(const v of f.children)w.slot&&(!v.ial||!v.ial[Tt])&&(v.ial||(v.ial={}),v.ial[Tt]=w.slot),g(v);return}if(w.isNote){const v=Fr(y);v&&(s.notes?s.notes+=`

`+v:s.notes=v),s.noteBlocks||(s.noteBlocks=[]),s.noteBlocks.push({id:f.id,type:f.type,content:v||f.content||"",rawMarkdown:y,isNote:!0,attributes:f.ial});return}w.shikiLines&&(y=lc(y,w.shikiLines)),b=y.trim();const x=(f.content||"").trim();if(b==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(b)||b.startsWith("::right::")){s.blocks.push({id:f.id,type:f.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:f.ial});return}const B=dc(f);let D=w.slot,M=w.clicks,O=w.motion,Z={...f.ial||{}};if(B!==null){for(;a.length>0&&a[a.length-1].level>=B;)a.pop();const v=a.length>0?a[a.length-1]:void 0;!D&&(v!=null&&v.slot)&&(D=v.slot),!M&&(v!=null&&v.clicks)&&(M=v.clicks),!O&&(v!=null&&v.motion)&&(O=v.motion);const G={...(v==null?void 0:v.customAttrs)||{}};if(f.ial)for(const[A,E]of Object.entries(f.ial))A.startsWith("custom-slidev-")&&!A.startsWith("custom-slidev-slide")&&(G[A]=E);a.push({level:B,slot:D,clicks:M,motion:O,customAttrs:G})}else{const v=a.length>0?a[a.length-1]:void 0;v&&(!D&&v.slot&&v.slot!=="header"&&(D=v.slot),!M&&v.clicks&&(M=v.clicks),!O&&v.motion&&(O=v.motion),v.customAttrs&&(Z={...v.customAttrs,...Z}))}!D&&s.blocks.some(v=>v.slot==="slot-divider-right")&&(D="right"),D&&(Z[Tt]=D),M&&!Z[$e]&&(Z[$e]=M),O&&!Z[Ve]&&(Z[Ve]=JSON.stringify(O)),(_||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(Z["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(Z["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(Z["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(Z["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(Z["custom-slidev-controls"]=h["custom-slidev-controls"]));const I={id:f.id,type:f.type,content:f.content||"",rawMarkdown:y,clicks:M,motion:O,shikiLines:w.shikiLines,slot:D,attributes:Z};s.blocks.push(I)};g(u)}for(let u=0;u<r.length;u++){const g=r[u],f=[],y={...g.frontmatter};u===0&&(y.theme=o.theme,y.aspectRatio=o.aspectRatio,y.highlighter=o.highlighter,y.transition=g.frontmatter.transition||o.defaultTransition);const h=rc(y);h&&f.push(h);const k=g.blocks.filter(x=>x.slot!=="slot-divider-right"),b=x=>x.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var B;return Ws(S.rawMarkdown,S.clicks,S.motion,(B=S.attributes)==null?void 0:B.style)}).join(`

`),w=x=>{const S=x.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if(S.length===0)return;const B=S[0],D=(B.rawMarkdown||B.content||"").trim();(Zi(B)||/^(?:[-*+]|\d+\.)\s+/.test(D))&&(B.rawMarkdown=Go(B.rawMarkdown||B.content||""),B.content=B.rawMarkdown)},_=x=>x.length===0?"":(w(x),b(x)),T=g.frontmatter.layout||"default";if(T==="two-cols-header"){let x=[];const S=k.filter(P=>P.slot==="header");if(S.length>0)x=S;else if(k.length>0){const P=k.find(v=>v.type==="h"&&(!v.slot||v.slot==="default"));P&&(x=[P])}const B=k.filter(P=>!x.includes(P)),D=B.filter(P=>P.slot==="right"||P.slot==="col-2"),M=B.filter(P=>!D.includes(P));w(M),w(D);const O=b(x),Z=_(M),I=_(D);O&&f.push(O),Z&&f.push(`::left::

${Z}`),I&&f.push(`::right::

${I}`)}else if(T==="three-cols-header"){let x=[];const S=k.filter(A=>A.slot==="header");if(S.length>0)x=S;else if(k.length>0){const A=k.find(E=>E.type==="h"&&(!E.slot||E.slot==="default"));A&&(x=[A])}const B=k.filter(A=>!x.includes(A)),D=jr(B),M=D.col1,O=D.col2,Z=D.col3;for(const A of M)A.slot||(A.slot="col-1");for(const A of O)A.slot||(A.slot="col-2");for(const A of Z)A.slot||(A.slot="col-3");if(w(M),w(O),w(Z),B.length===1&&(O.length>0||Z.length>0)){const A=g.blocks.findIndex(E=>E.id===B[0].id);A!==-1&&g.blocks.splice(A,1,...M,...O,...Z)}const I=b(x),P=_(M),v=_(O),G=_(Z);I&&f.push(I),P&&f.push(`::col-1::

${P}`),v&&f.push(`::col-2::

${v}`),G&&f.push(`::col-3::

${G}`)}else if(T==="two-cols"){const x=k.filter(M=>M.slot==="left"),S=k.filter(M=>M.slot==="right");w(x),w(S);const B=b(x.length>0?x:k.filter(M=>M.slot!=="right")),D=b(S);f.push(B),D&&f.push(`::right::

${D}`)}else for(const x of k)f.push(Ws(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));g.notes&&f.push(`<!--
${g.notes}
-->`),g.rawMarkdown=f.join(`

`).trim()}const c=r.map(u=>u.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:r,fullMarkdown:c}}const Yo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function uc(t){var o,r,l,s,a,c,d,u,g,f,y,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const k of t.styles){if(!k||!k.id)continue;const b=`--b3-inline-style-${k.id}`;(o=k.light)!=null&&o.color&&i.push(`  ${b}-color: ${k.light.color};`),(r=k.light)!=null&&r.backgroundColor&&i.push(`  ${b}-background-color: ${k.light.backgroundColor};`),(l=k.dark)!=null&&l.color&&e.push(`  ${b}-color: ${k.dark.color};`),(s=k.dark)!=null&&s.backgroundColor&&e.push(`  ${b}-background-color: ${k.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const k of t.builtin.colors){if(!k||typeof k.index!="number")continue;const b=k.index;(a=k.light)!=null&&a.color&&i.push(`  --b3-font-color${b}: ${k.light.color};`),(c=k.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${b}: ${k.light.backgroundColor};`),(d=k.dark)!=null&&d.color&&e.push(`  --b3-font-color${b}: ${k.dark.color};`),(u=k.dark)!=null&&u.backgroundColor&&e.push(`  --b3-font-background${b}: ${k.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const k of t.builtin.styles){if(!k||!k.id)continue;const b=k.id;(g=k.light)!=null&&g.color&&i.push(`  --b3-card-${b}-color: ${k.light.color};`),(f=k.light)!=null&&f.backgroundColor&&i.push(`  --b3-card-${b}-background: ${k.light.backgroundColor};`),(y=k.dark)!=null&&y.color&&e.push(`  --b3-card-${b}-color: ${k.dark.color};`),(h=k.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${b}-background: ${k.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function fn(t){const i=uc(t);return i?`${Yo}

/* Custom Workspace Inline Styles */
${i}`:Yo}function Mo(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}const fc={getBlockAttrs:Ze,getChildBlocks:Xn,setBlockAttrs:Pt,sql:bn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ha};class pc{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...fc,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[r]:o[r]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],s=new Map;if(Array.isArray(l))for(const _ of l)_.id&&_.ial&&s.set(_.id,Mo(_.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const _ of c)if(_.block_id&&_.name){let T=s.get(_.block_id);T||(T={},s.set(_.block_id,T)),T[_.name]=_.value||""}}if(!o||o.length===0){const _=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(_).catch(()=>[])||[]}const d=(o||[]).map(_=>{const T=s.get(_.id)||(_.ial?Mo(_.ial):{}),x=this.attrOverrides.get(_.id);return x&&Object.assign(T,x),{id:_.id,parent_id:_.parent_id,root_id:_.root_id||i,type:_.type,subType:_.subType,content:_.content||"",markdown:_.markdown||"",ial:T,children:_.children}}),u=async(_,T=0)=>{if(!(!_||_.length===0||T>8))for(const x of _){if((oe(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let B=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!B||B.length===0){const D=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;B=await this.deps.sql(D).catch(()=>[])||[]}Array.isArray(B)&&B.length>0&&(x.children=B.map(D=>{const M=s.get(D.id)||(D.ial?Mo(D.ial):{}),O=this.attrOverrides.get(D.id);return O&&Object.assign(M,O),{id:D.id,parent_id:D.parent_id||x.id,root_id:D.root_id||i,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await u(x.children,T+1)}};await u(d);const g=_=>{var T,x;for(const S of _)if(S.children&&S.children.length>0){g(S.children);for(const B of S.children)if(B.ial)for(const[D,M]of Object.entries(B.ial))D.startsWith("custom-slidev-")&&!((T=S.ial)!=null&&T[D])&&(S.ial||(S.ial={}),S.ial[D]=M);if(S.ial){for(const[B,D]of Object.entries(S.ial))if(B.startsWith("custom-slidev-"))for(const M of S.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[B])&&(M.ial||(M.ial={}),M.ial[B]=D)}}};g(d),ic(d,_=>{const T={[dt]:_.layout};_.ratio&&(T[Zt]=_.ratio),this.setBlockAttrOverride(_.blockId,T),(this.deps.setBlockAttrs||Pt)(_.blockId,T).catch(S=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",S)})});const f=this.trackedListSuperBlocks.get(i)||[],y=ec(i,d,{tracked:f,onTagChange:_=>{this.setBlockAttrOverride(_.blockId,_.attrs),_.blockId===i&&Object.assign(e,_.attrs);const T=S=>{for(const B of S)B.id===_.blockId&&(B.ial||(B.ial={}),Object.assign(B.ial,_.attrs)),B.children&&B.children.length>0&&T(B.children)};T(d),(this.deps.setBlockAttrs||Pt)(_.blockId,_.attrs).catch(S=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",S)})}});this.trackedListSuperBlocks.set(i,y.newTracked);const h=new Set;for(const _ of d){const T=_.markdown||_.content||"";if(T.includes("((")){const x=Ua(T);for(const S of x)h.add(S.blockId)}}const k={};if(h.size>0){const _=Array.from(h).map(x=>`'${x}'`).join(","),T=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${_})`).catch(()=>[])||[];if(Array.isArray(T))for(const x of T)x.id&&(k[x.id]=x.markdown||x.content||"")}const b=this.deps.getBaseUrl?this.deps.getBaseUrl():"",w=Vs(i,e,d,{baseUrl:b,refContentMap:k});try{const _=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;w.customThemeCss=fn(_)}catch{w.customThemeCss=fn(null)}return w}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Vs(i,{},[],{});return n.customThemeCss=fn(null),n}}}const Rt=new pc;class us{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),r=i.slides.map((l,s)=>{const a=l.frontmatter||{},c=[],d=s===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let u="";c.length>0?u=d?"":`---
${c.join(`
`)}
---

`:d||(u=`---

`);let g="";if(a.layout==="two-cols"){const y=l.blocks.filter(w=>w.slot!=="right"),h=l.blocks.filter(w=>w.slot==="right"),k=y.map(w=>w.rawMarkdown||w.content||"").join(`

`),b=h.map(w=>w.rawMarkdown||w.content||"").join(`

`);g=`${k}

::right::

${b}`}else g=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let f="";return l.notes&&l.notes.trim()&&(f=`

<!--
${l.notes.trim()}
-->`),`${u}${g}${f}`}).join(`

`);return`${o}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const r=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(o),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function fs(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Ut={},Ui=[],Ke=()=>{},Hr=()=>!1,mo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),go=t=>t.startsWith("onUpdate:"),ce=Object.assign,ps=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},hc=Object.prototype.hasOwnProperty,zt=(t,i)=>hc.call(t,i),Ct=Array.isArray,Wi=t=>En(t)==="[object Map]",tn=t=>En(t)==="[object Set]",Ks=t=>En(t)==="[object Date]",At=t=>typeof t=="function",te=t=>typeof t=="string",Le=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Ur=t=>(jt(t)||At(t))&&At(t.then)&&At(t.catch),Wr=Object.prototype.toString,En=t=>Wr.call(t),mc=t=>En(t).slice(8,-1),Vr=t=>En(t)==="[object Object]",hs=t=>te(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,pn=fs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),vo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},gc=/-\w/g,ge=vo(t=>t.replace(gc,i=>i.slice(1).toUpperCase())),vc=/\B([A-Z])/g,vi=vo(t=>t.replace(vc,"-$1").toLowerCase()),bo=vo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Do=vo(t=>t?`on${bo(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Kn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Kr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},yo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let qs;const ko=()=>qs||(qs=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function ms(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=te(n)?wc(n):ms(n);if(o)for(const r in o)i[r]=o[r]}return i}else if(te(t)||jt(t))return t}const bc=/;(?![^(]*\))/g,yc=/:([^]+)/,kc=/\/\*[^]*?\*\//g;function wc(t){const i={};return t.replace(kc,"").split(bc).forEach(e=>{if(e){const n=e.split(yc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function It(t){let i="";if(te(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=It(t[e]);n&&(i+=n+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const xc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",_c=fs(xc);function qr(t){return!!t||t===""}function Sc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=en(t[n],i[n]);return e}function en(t,i){if(t===i)return!0;let e=Ks(t),n=Ks(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Le(t),n=Le(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?Sc(t,i):!1;if(e=jt(t),n=jt(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,r=Object.keys(i).length;if(o!==r)return!1;for(const l in t){const s=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(s&&!a||!s&&a||!en(t[l],i[l]))return!1}}return String(t)===String(i)}function gs(t,i){return t.findIndex(e=>en(e,i))}const Gr=t=>!!(t&&t.__v_isRef===!0),xt=t=>te(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Wr||!At(t.toString))?Gr(t)?xt(t.value):JSON.stringify(t,Zr,2):String(t),Zr=(t,i)=>Gr(i)?Zr(t,i.value):Wi(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],r)=>(e[Lo(n,r)+" =>"]=o,e),{})}:tn(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>Lo(e))}:Le(i)?Lo(i):jt(i)&&!Ct(i)&&!Vr(i)?String(i):i,Lo=(t,i="")=>{var e;return Le(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let re;class Cc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&re&&(re.active?(this.parent=re,this.index=(re.scopes||(re.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=re;try{return re=this,i()}finally{re=e}}}on(){++this._on===1&&(this.prevScope=re,re=this)}off(){if(this._on>0&&--this._on===0){if(re===this)re=this.prevScope;else{let i=re;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function $c(){return re}let Wt;const Po=new WeakSet;class Yr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,re&&(re.active?re.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Po.has(this)&&(Po.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Xr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Gs(this),Qr(this);const i=Wt,e=De;Wt=this,De=!0;try{return this.fn()}finally{tl(this),Wt=i,De=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)ys(i);this.deps=this.depsTail=void 0,Gs(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Po.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Jo(this)&&this.run()}get dirty(){return Jo(this)}}let Jr=0,hn,mn;function Xr(t,i=!1){if(t.flags|=8,i){t.next=mn,mn=t;return}t.next=hn,hn=t}function vs(){Jr++}function bs(){if(--Jr>0)return;if(mn){let i=mn;for(mn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;hn;){let i=hn;for(hn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function Qr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function tl(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),ys(n),Ic(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function Jo(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(el(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function el(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===_n)||(t.globalVersion=_n,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Jo(t))))return;t.flags|=2;const i=t.dep,e=Wt,n=De;Wt=t,De=!0;try{Qr(t);const o=t.fn(t._value);(i.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{Wt=e,De=n,tl(t),t.flags&=-3}}function ys(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)ys(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function Ic(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let De=!0;const il=[];function oi(){il.push(De),De=!1}function si(){const t=il.pop();De=t===void 0?!0:t}function Gs(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Wt;Wt=void 0;try{i()}finally{Wt=e}}}let _n=0;class Ac{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ks{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Wt||!De||Wt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Wt)e=this.activeLink=new Ac(Wt,this),Wt.deps?(e.prevDep=Wt.depsTail,Wt.depsTail.nextDep=e,Wt.depsTail=e):Wt.deps=Wt.depsTail=e,nl(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Wt.depsTail,e.nextDep=void 0,Wt.depsTail.nextDep=e,Wt.depsTail=e,Wt.deps===e&&(Wt.deps=n)}return e}trigger(i){this.version++,_n++,this.notify(i)}notify(i){vs();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{bs()}}}function nl(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)nl(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Xo=new WeakMap,Bi=Symbol(""),Qo=Symbol(""),Sn=Symbol("");function fe(t,i,e){if(De&&Wt){let n=Xo.get(t);n||Xo.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new ks),o.map=n,o.key=e),o.track()}}function Xe(t,i,e,n,o,r){const l=Xo.get(t);if(!l){_n++;return}const s=a=>{a&&a.trigger()};if(vs(),i==="clear")l.forEach(s);else{const a=Ct(t),c=a&&hs(e);if(a&&e==="length"){const d=Number(n);l.forEach((u,g)=>{(g==="length"||g===Sn||!Le(g)&&g>=d)&&s(u)})}else switch((e!==void 0||l.has(void 0))&&s(l.get(e)),c&&s(l.get(Sn)),i){case"add":a?c&&s(l.get("length")):(s(l.get(Bi)),Wi(t)&&s(l.get(Qo)));break;case"delete":a||(s(l.get(Bi)),Wi(t)&&s(l.get(Qo)));break;case"set":Wi(t)&&s(l.get(Bi));break}}bs()}function zi(t){const i=Ot(t);return i===t?i:(fe(i,"iterate",Sn),Ie(t)?i:i.map(Pe))}function wo(t){return fe(t=Ot(t),"iterate",Sn),t}function je(t,i){return ri(t)?Yi(Ei(t)?Pe(i):i):Pe(i)}const Tc={__proto__:null,[Symbol.iterator](){return Ro(this,Symbol.iterator,t=>je(this,t))},concat(...t){return zi(this).concat(...t.map(i=>Ct(i)?zi(i):i))},entries(){return Ro(this,"entries",t=>(t[1]=je(this,t[1]),t))},every(t,i){return Ge(this,"every",t,i,void 0,arguments)},filter(t,i){return Ge(this,"filter",t,i,e=>e.map(n=>je(this,n)),arguments)},find(t,i){return Ge(this,"find",t,i,e=>je(this,e),arguments)},findIndex(t,i){return Ge(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ge(this,"findLast",t,i,e=>je(this,e),arguments)},findLastIndex(t,i){return Ge(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ge(this,"forEach",t,i,void 0,arguments)},includes(...t){return Oo(this,"includes",t)},indexOf(...t){return Oo(this,"indexOf",t)},join(t){return zi(this).join(t)},lastIndexOf(...t){return Oo(this,"lastIndexOf",t)},map(t,i){return Ge(this,"map",t,i,void 0,arguments)},pop(){return sn(this,"pop")},push(...t){return sn(this,"push",t)},reduce(t,...i){return Zs(this,"reduce",t,i)},reduceRight(t,...i){return Zs(this,"reduceRight",t,i)},shift(){return sn(this,"shift")},some(t,i){return Ge(this,"some",t,i,void 0,arguments)},splice(...t){return sn(this,"splice",t)},toReversed(){return zi(this).toReversed()},toSorted(t){return zi(this).toSorted(t)},toSpliced(...t){return zi(this).toSpliced(...t)},unshift(...t){return sn(this,"unshift",t)},values(){return Ro(this,"values",t=>je(this,t))}};function Ro(t,i,e){const n=wo(t),o=n[i]();return n!==t&&!Ie(t)&&(o._next=o.next,o.next=()=>{const r=o._next();return r.done||(r.value=e(r.value)),r}),o}const Bc=Array.prototype;function Ge(t,i,e,n,o,r){const l=wo(t),s=l!==t&&!Ie(t),a=l[i];if(a!==Bc[i]){const u=a.apply(t,r);return s?Pe(u):u}let c=e;l!==t&&(s?c=function(u,g){return e.call(this,je(t,u),g,t)}:e.length>2&&(c=function(u,g){return e.call(this,u,g,t)}));const d=a.call(l,c,n);return s&&o?o(d):d}function Zs(t,i,e,n){const o=wo(t),r=o!==t&&!Ie(t);let l=e,s=!1;o!==t&&(r?(s=n.length===0,l=function(c,d,u){return s&&(s=!1,c=je(t,c)),e.call(this,c,je(t,d),u,t)}):e.length>3&&(l=function(c,d,u){return e.call(this,c,d,u,t)}));const a=o[i](l,...n);return s?je(t,a):a}function Oo(t,i,e){const n=Ot(t);fe(n,"iterate",Sn);const o=n[i](...e);return(o===-1||o===!1)&&_s(e[0])?(e[0]=Ot(e[0]),n[i](...e)):o}function sn(t,i,e=[]){oi(),vs();const n=Ot(t)[i].apply(t,e);return bs(),si(),n}const Ec=fs("__proto__,__v_isRef,__isVue"),ol=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Le));function Mc(t){Le(t)||(t=String(t));const i=Ot(this);return fe(i,"has",t),i.hasOwnProperty(t)}class sl{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return r;if(e==="__v_raw")return n===(o?r?Hc:cl:r?al:ll).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!o){let a;if(l&&(a=Tc[e]))return a;if(e==="hasOwnProperty")return Mc}const s=Reflect.get(i,e,Yt(i)?i:n);if((Le(e)?ol.has(e):Ec(e))||(o||fe(i,"get",e),r))return s;if(Yt(s)){const a=l&&hs(e)?s:s.value;return o&&jt(a)?es(a):a}return jt(s)?o?es(s):xo(s):s}}class rl extends sl{constructor(i=!1){super(!1,i)}set(i,e,n,o){let r=i[e];const l=Ct(i)&&hs(e);if(!this._isShallow){const c=ri(r);if(!Ie(n)&&!ri(n)&&(r=Ot(r),n=Ot(n)),!l&&Yt(r)&&!Yt(n))return c||(r.value=n),!0}const s=l?Number(e)<i.length:zt(i,e),a=Reflect.set(i,e,n,Yt(i)?i:o);return i===Ot(o)&&a&&(s?Ue(n,r)&&Xe(i,"set",e,n):Xe(i,"add",e,n)),a}deleteProperty(i,e){const n=zt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Xe(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Le(e)||!ol.has(e))&&fe(i,"has",e),n}ownKeys(i){return fe(i,"iterate",Ct(i)?"length":Bi),Reflect.ownKeys(i)}}class Dc extends sl{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Lc=new rl,Pc=new Dc,Rc=new rl(!0);const ts=t=>t,Nn=t=>Reflect.getPrototypeOf(t);function Oc(t,i,e){return function(...n){const o=this.__v_raw,r=Ot(o),l=Wi(r),s=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),d=e?ts:i?Yi:Pe;return!i&&fe(r,"iterate",a?Qo:Bi),ce(Object.create(c),{next(){const{value:u,done:g}=c.next();return g?{value:u,done:g}:{value:s?[d(u[0]),d(u[1])]:d(u),done:g}}})}}function Fn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function zc(t,i){const e={get(o){const r=this.__v_raw,l=Ot(r),s=Ot(o);t||(Ue(o,s)&&fe(l,"get",o),fe(l,"get",s));const{has:a}=Nn(l),c=i?ts:t?Yi:Pe;if(a.call(l,o))return c(r.get(o));if(a.call(l,s))return c(r.get(s));r!==l&&r.get(o)},get size(){const o=this.__v_raw;return!t&&fe(Ot(o),"iterate",Bi),o.size},has(o){const r=this.__v_raw,l=Ot(r),s=Ot(o);return t||(Ue(o,s)&&fe(l,"has",o),fe(l,"has",s)),o===s?r.has(o):r.has(o)||r.has(s)},forEach(o,r){const l=this,s=l.__v_raw,a=Ot(s),c=i?ts:t?Yi:Pe;return!t&&fe(a,"iterate",Bi),s.forEach((d,u)=>o.call(r,c(d),c(u),l))}};return ce(e,t?{add:Fn("add"),set:Fn("set"),delete:Fn("delete"),clear:Fn("clear")}:{add(o){const r=Ot(this),l=Nn(r),s=Ot(o),a=!i&&!Ie(o)&&!ri(o)?s:o;return l.has.call(r,a)||Ue(o,a)&&l.has.call(r,o)||Ue(s,a)&&l.has.call(r,s)||(r.add(a),Xe(r,"add",a,a)),this},set(o,r){!i&&!Ie(r)&&!ri(r)&&(r=Ot(r));const l=Ot(this),{has:s,get:a}=Nn(l);let c=s.call(l,o);c||(o=Ot(o),c=s.call(l,o));const d=a.call(l,o);return l.set(o,r),c?Ue(r,d)&&Xe(l,"set",o,r):Xe(l,"add",o,r),this},delete(o){const r=Ot(this),{has:l,get:s}=Nn(r);let a=l.call(r,o);a||(o=Ot(o),a=l.call(r,o)),s&&s.call(r,o);const c=r.delete(o);return a&&Xe(r,"delete",o,void 0),c},clear(){const o=Ot(this),r=o.size!==0,l=o.clear();return r&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=Oc(o,t,i)}),e}function ws(t,i){const e=zc(t,i);return(n,o,r)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(e,o)&&o in n?e:n,o,r)}const Nc={get:ws(!1,!1)},Fc={get:ws(!1,!0)},jc={get:ws(!0,!1)};const ll=new WeakMap,al=new WeakMap,cl=new WeakMap,Hc=new WeakMap;function Uc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function xo(t){return ri(t)?t:xs(t,!1,Lc,Nc,ll)}function Wc(t){return xs(t,!1,Rc,Fc,al)}function es(t){return xs(t,!0,Pc,jc,cl)}function xs(t,i,e,n,o){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=o.get(t);if(r)return r;const l=Uc(mc(t));if(l===0)return t;const s=new Proxy(t,l===2?n:e);return o.set(t,s),s}function Ei(t){return ri(t)?Ei(t.__v_raw):!!(t&&t.__v_isReactive)}function ri(t){return!!(t&&t.__v_isReadonly)}function Ie(t){return!!(t&&t.__v_isShallow)}function _s(t){return t?!!t.__v_raw:!1}function Ot(t){const i=t&&t.__v_raw;return i?Ot(i):t}function Vc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&Kr(t,"__v_skip",!0),t}const Pe=t=>jt(t)?xo(t):t,Yi=t=>jt(t)?es(t):t;function Yt(t){return t?t.__v_isRef===!0:!1}function ft(t){return Kc(t,!1)}function Kc(t,i){return Yt(t)?t:new qc(t,i)}class qc{constructor(i,e){this.dep=new ks,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Ot(i),this._value=e?i:Pe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Ie(i)||ri(i);i=n?i:Ot(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Pe(i),this.dep.trigger())}}function ht(t){return Yt(t)?t.value:t}const Gc={get:(t,i,e)=>i==="__v_raw"?t:ht(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return Yt(o)&&!Yt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function dl(t){return Ei(t)?t:new Proxy(t,Gc)}class Zc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new ks(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=_n-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Wt!==this)return Xr(this,!0),!0}get value(){const i=this.dep.track();return el(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Yc(t,i,e=!1){let n,o;return At(t)?n=t:(n=t.get,o=t.set),new Zc(n,o,e)}const jn={},oo=new WeakMap;let Ci;function Jc(t,i=!1,e=Ci){if(e){let n=oo.get(e);n||oo.set(e,n=[]),n.push(t)}}function Xc(t,i,e=Ut){const{immediate:n,deep:o,once:r,scheduler:l,augmentJob:s,call:a}=e,c=T=>o?T:Ie(T)||o===!1||o===0?Qe(T,1):Qe(T);let d,u,g,f,y=!1,h=!1;if(Yt(t)?(u=()=>t.value,y=Ie(t)):Ei(t)?(u=()=>c(t),y=!0):Ct(t)?(h=!0,y=t.some(T=>Ei(T)||Ie(T)),u=()=>t.map(T=>{if(Yt(T))return T.value;if(Ei(T))return c(T);if(At(T))return a?a(T,2):T()})):At(t)?i?u=a?()=>a(t,2):t:u=()=>{if(g){oi();try{g()}finally{si()}}const T=Ci;Ci=d;try{return a?a(t,3,[f]):t(f)}finally{Ci=T}}:u=Ke,i&&o){const T=u,x=o===!0?1/0:o;u=()=>Qe(T(),x)}const k=$c(),b=()=>{d.stop(),k&&k.active&&ps(k.effects,d)};if(r&&i){const T=i;i=(...x)=>{const S=T(...x);return b(),S}}let w=h?new Array(t.length).fill(jn):jn;const _=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(i){const x=d.run();if(T||o||y||(h?x.some((S,B)=>Ue(S,w[B])):Ue(x,w))){g&&g();const S=Ci;Ci=d;try{const B=[x,w===jn?void 0:h&&w[0]===jn?[]:w,f];w=x,a?a(i,3,B):i(...B)}finally{Ci=S}}}else d.run()};return s&&s(_),d=new Yr(u),d.scheduler=l?()=>l(_,!1):_,f=T=>Jc(T,!1,d),g=d.onStop=()=>{const T=oo.get(d);if(T){if(a)a(T,4);else for(const x of T)x();oo.delete(d)}},i?n?_(!0):w=d.run():l?l(_.bind(null,!0),!0):d.run(),b.pause=d.pause.bind(d),b.resume=d.resume.bind(d),b.stop=b,b}function Qe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Yt(t))Qe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Qe(t[n],i,e);else if(tn(t)||Wi(t))t.forEach(n=>{Qe(n,i,e)});else if(Vr(t)){for(const n in t)Qe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Mn(t,i,e,n){try{return n?t(...n):t()}catch(o){_o(o,i,e)}}function Re(t,i,e,n){if(At(t)){const o=Mn(t,i,e,n);return o&&Ur(o)&&o.catch(r=>{_o(r,i,e)}),o}if(Ct(t)){const o=[];for(let r=0;r<t.length;r++)o.push(Re(t[r],i,e,n));return o}}function _o(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Ut;if(i){let s=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;s;){const d=s.ec;if(d){for(let u=0;u<d.length;u++)if(d[u](t,a,c)===!1)return}s=s.parent}if(r){oi(),Mn(r,null,10,[t,a,c]),si();return}}Qc(t,e,o,n,l)}function Qc(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const me=[];let Fe=-1;const Vi=[];let ui=null,Ni=0;const ul=Promise.resolve();let so=null;function fl(t){const i=so||ul;return t?i.then(this?t.bind(this):t):i}function td(t){let i=Fe+1,e=me.length;for(;i<e;){const n=i+e>>>1,o=me[n],r=Cn(o);r<t||r===t&&o.flags&2?i=n+1:e=n}return i}function Ss(t){if(!(t.flags&1)){const i=Cn(t),e=me[me.length-1];!e||!(t.flags&2)&&i>=Cn(e)?me.push(t):me.splice(td(i),0,t),t.flags|=1,pl()}}function pl(){so||(so=ul.then(ml))}function ed(t){Ct(t)?Vi.push(...t):ui&&t.id===-1?ui.splice(Ni+1,0,t):t.flags&1||(Vi.push(t),t.flags|=1),pl()}function Ys(t,i,e=Fe+1){for(;e<me.length;e++){const n=me[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;me.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function hl(t){if(Vi.length){const i=[...new Set(Vi)].sort((e,n)=>Cn(e)-Cn(n));if(Vi.length=0,ui){ui.push(...i);return}for(ui=i,Ni=0;Ni<ui.length;Ni++){const e=ui[Ni];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ui=null,Ni=0}}const Cn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function ml(t){try{for(Fe=0;Fe<me.length;Fe++){const i=me[Fe];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Mn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Fe<me.length;Fe++){const i=me[Fe];i&&(i.flags&=-2)}Fe=-1,me.length=0,hl(),so=null,(me.length||Vi.length)&&ml()}}let ae=null,gl=null;function ro(t){const i=ae;return ae=t,gl=t&&t.type.__scopeId||null,i}function vl(t,i=ae,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&ar(-1);const r=ro(i),l=ei.length;let s;try{s=t(...o)}finally{for(let a=ei.length;a>l;a--)Bs();ro(r),n._d&&ar(1)}return s};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,i){if(ae===null)return t;const e=Io(ae),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[r,l,s,a=Ut]=i[o];r&&(At(r)&&(r={mounted:r,updated:r}),r.deep&&Qe(l),n.push({dir:r,instance:e,value:l,oldValue:void 0,arg:s,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,r=i&&i.dirs;for(let l=0;l<o.length;l++){const s=o[l];r&&(s.oldValue=r[l].value);let a=s.dir[n];a&&(oi(),Re(a,e,8,[t.el,s,t,i]),si())}}function id(t,i){if(pe){let e=pe.provides;const n=pe.parent&&pe.parent.provides;n===e&&(e=pe.provides=Object.create(n)),e[t]=i}}function ti(t,i,e=!1){const n=tu();if(n||qi){let o=qi?qi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&At(i)?i.call(n&&n.proxy):i}}const nd=Symbol.for("v-scx"),od=()=>ti(nd);function Mi(t,i,e){return bl(t,i,e)}function bl(t,i,e=Ut){const{immediate:n,deep:o,flush:r,once:l}=e,s=ce({},e),a=i&&n||!i&&r!=="post";let c;if(In){if(r==="sync"){const f=od();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!a){const f=()=>{};return f.stop=Ke,f.resume=Ke,f.pause=Ke,f}}const d=pe;s.call=(f,y,h)=>Re(f,d,y,h);let u=!1;r==="post"?s.scheduler=f=>{be(f,d&&d.suspense)}:r!=="sync"&&(u=!0,s.scheduler=(f,y)=>{y?f():Ss(f)}),s.augmentJob=f=>{i&&(f.flags|=4),u&&(f.flags|=2,d&&(f.id=d.uid,f.i=d))};const g=Xc(t,i,s);return In&&(c?c.push(g):a&&g()),g}function sd(t,i,e){const n=this.proxy,o=te(t)?t.includes(".")?yl(n,t):()=>n[t]:t.bind(n,n);let r;At(i)?r=i:(r=i.handler,e=i);const l=Ln(this),s=bl(o,r.bind(n),e);return l(),s}function yl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const rd=Symbol("_vte"),ld=t=>t.__isTeleport,zo=Symbol("_leaveCb");function Cs(t,i){t.shapeFlag&6&&t.component?(t.transition=i,Cs(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function xe(t,i){return At(t)?ce({name:t.name},i,{setup:t}):t}function kl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Js(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const lo=new WeakMap;function gn(t,i,e,n,o=!1){if(Ct(t)){t.forEach((h,k)=>gn(h,i&&(Ct(i)?i[k]:i),e,n,o));return}if(Ki(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&gn(t,i,e,n.component.subTree);return}const r=n.shapeFlag&4?Io(n.component):n.el,l=o?null:r,{i:s,r:a}=t,c=i&&i.r,d=s.refs===Ut?s.refs={}:s.refs,u=s.setupState,g=Ot(u),f=u===Ut?Hr:h=>Js(d,h)?!1:zt(g,h),y=(h,k)=>!(k&&Js(d,k));if(c!=null&&c!==a){if(Xs(i),te(c))d[c]=null,f(c)&&(u[c]=null);else if(Yt(c)){const h=i;y(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(At(a))Mn(a,s,12,[l,d]);else{const h=te(a),k=Yt(a);if(h||k){const b=()=>{if(t.f){const w=h?f(a)?u[a]:d[a]:y()||!t.k?a.value:d[t.k];if(o)Ct(w)&&ps(w,r);else if(Ct(w))w.includes(r)||w.push(r);else if(h)d[a]=[r],f(a)&&(u[a]=d[a]);else{const _=[r];y(a,t.k)&&(a.value=_),t.k&&(d[t.k]=_)}}else h?(d[a]=l,f(a)&&(u[a]=l)):k&&(y(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const w=()=>{b(),lo.delete(t)};w.id=-1,lo.set(t,w),be(w,e)}else Xs(t),b()}}}function Xs(t){const i=lo.get(t);i&&(i.flags|=8,lo.delete(t))}ko().requestIdleCallback;ko().cancelIdleCallback;const Ki=t=>!!t.type.__asyncLoader,wl=t=>t.type.__isKeepAlive;function ad(t,i){xl(t,"a",i)}function cd(t,i){xl(t,"da",i)}function xl(t,i,e=pe){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(So(i,n,e),e){let o=e.parent;for(;o&&o.parent;)wl(o.parent.vnode)&&dd(n,i,e,o),o=o.parent}}function dd(t,i,e,n){const o=So(i,t,n,!0);Is(()=>{ps(n[i],o)},e)}function So(t,i,e=pe,n=!1){if(e){const o=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{oi();const s=Ln(e),a=Re(i,e,t,l);return s(),si(),a});return n?o.unshift(r):o.push(r),r}}const ai=t=>(i,e=pe)=>{(!In||t==="sp")&&So(t,(...n)=>i(...n),e)},ud=ai("bm"),Dn=ai("m"),fd=ai("bu"),pd=ai("u"),$s=ai("bum"),Is=ai("um"),hd=ai("sp"),md=ai("rtg"),gd=ai("rtc");function vd(t,i=pe){So("ec",t,i)}const bd="components";function yd(t,i){return wd(bd,t,!0,i)||t}const kd=Symbol.for("v-ndc");function wd(t,i,e=!0,n=!1){const o=ae||pe;if(o){const r=o.type;{const s=su(r,!1);if(s&&(s===i||s===ge(i)||s===bo(ge(i))))return r}const l=Qs(o[t]||r[t],i)||Qs(o.appContext[t],i);return!l&&n?r:l}}function Qs(t,i){return t&&(t[i]||t[ge(i)]||t[bo(ge(i))])}function ye(t,i,e,n){let o;const r=e,l=Ct(t);if(l||te(t)){const s=l&&Ei(t);let a=!1,c=!1;s&&(a=!Ie(t),c=ri(t),t=wo(t)),o=new Array(t.length);for(let d=0,u=t.length;d<u;d++)o[d]=i(a?c?Yi(Pe(t[d])):Pe(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){o=new Array(t);for(let s=0;s<t;s++)o[s]=i(s+1,s,void 0,r)}else if(jt(t))if(t[Symbol.iterator])o=Array.from(t,(s,a)=>i(s,a,void 0,r));else{const s=Object.keys(t);o=new Array(s.length);for(let a=0,c=s.length;a<c;a++){const d=s[a];o[a]=i(t[d],d,a,r)}}else o=[];return o}function Hn(t,i,e={},n,o,r){if(ae.ce||ae.parent&&Ki(ae.parent)&&ae.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),Me(Kt,null,[ct("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const s=ei.length;tt();let a;try{const c=l&&_l(l(e)),d=e.key||r||c&&c.key;a=Me(Kt,{key:(d&&!Le(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ei.length;d>s;d--)Bs();throw c}finally{l&&l._c&&(l._d=!0)}return a}function _l(t){return t.some(i=>Es(i)?!(i.type===li||i.type===Kt&&!_l(i.children)):!0)?t:null}const is=t=>t?Ul(t)?Io(t):is(t.parent):null,vn=ce(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>is(t.parent),$root:t=>is(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Cl(t),$forceUpdate:t=>t.f||(t.f=()=>{Ss(t.update)}),$nextTick:t=>t.n||(t.n=fl.bind(t.proxy)),$watch:t=>sd.bind(t)}),No=(t,i)=>t!==Ut&&!t.__isScriptSetup&&zt(t,i),xd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:r,accessCache:l,type:s,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return r[i]}else{if(No(n,i))return l[i]=1,n[i];if(o!==Ut&&zt(o,i))return l[i]=2,o[i];if(zt(r,i))return l[i]=3,r[i];if(e!==Ut&&zt(e,i))return l[i]=4,e[i];ns&&(l[i]=0)}}const c=vn[i];let d,u;if(c)return i==="$attrs"&&fe(t.attrs,"get",""),c(t);if((d=s.__cssModules)&&(d=d[i]))return d;if(e!==Ut&&zt(e,i))return l[i]=4,e[i];if(u=a.config.globalProperties,zt(u,i))return u[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:r}=t;return No(o,i)?(o[i]=e,!0):n!==Ut&&zt(n,i)?(n[i]=e,!0):zt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:r,type:l}},s){let a;return!!(e[s]||t!==Ut&&s[0]!=="$"&&zt(t,s)||No(i,s)||zt(r,s)||zt(n,s)||zt(vn,s)||zt(o.config.globalProperties,s)||(a=l.__cssModules)&&a[s])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:zt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function tr(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let ns=!0;function _d(t){const i=Cl(t),e=t.proxy,n=t.ctx;ns=!1,i.beforeCreate&&er(i.beforeCreate,t,"bc");const{data:o,computed:r,methods:l,watch:s,provide:a,inject:c,created:d,beforeMount:u,mounted:g,beforeUpdate:f,updated:y,activated:h,deactivated:k,beforeDestroy:b,beforeUnmount:w,destroyed:_,unmounted:T,render:x,renderTracked:S,renderTriggered:B,errorCaptured:D,serverPrefetch:M,expose:O,inheritAttrs:Z,components:I,directives:P,filters:v}=i;if(c&&Sd(c,n,null),l)for(const E in l){const j=l[E];At(j)&&(n[E]=j.bind(e))}if(o){const E=o.call(e,e);jt(E)&&(t.data=xo(E))}if(ns=!0,r)for(const E in r){const j=r[E],N=At(j)?j.bind(e,e):At(j.get)?j.get.bind(e,e):Ke,J=!At(j)&&At(j.set)?j.set.bind(e):Ke,H=St({get:N,set:J});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>H.value,set:K=>H.value=K})}if(s)for(const E in s)Sl(s[E],n,e,E);if(a){const E=At(a)?a.call(e):a;Reflect.ownKeys(E).forEach(j=>{id(j,E[j])})}d&&er(d,t,"c");function A(E,j){Ct(j)?j.forEach(N=>E(N.bind(e))):j&&E(j.bind(e))}if(A(ud,u),A(Dn,g),A(fd,f),A(pd,y),A(ad,h),A(cd,k),A(vd,D),A(gd,S),A(md,B),A($s,w),A(Is,T),A(hd,M),Ct(O))if(O.length){const E=t.exposed||(t.exposed={});O.forEach(j=>{Object.defineProperty(E,j,{get:()=>e[j],set:N=>e[j]=N,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===Ke&&(t.render=x),Z!=null&&(t.inheritAttrs=Z),I&&(t.components=I),P&&(t.directives=P),M&&kl(t)}function Sd(t,i,e=Ke){Ct(t)&&(t=os(t));for(const n in t){const o=t[n];let r;jt(o)?"default"in o?r=ti(o.from||n,o.default,!0):r=ti(o.from||n):r=ti(o),Yt(r)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[n]=r}}function er(t,i,e){Re(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function Sl(t,i,e,n){let o=n.includes(".")?yl(e,n):()=>e[n];if(te(t)){const r=i[t];At(r)&&Mi(o,r)}else if(At(t))Mi(o,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(r=>Sl(r,i,e,n));else{const r=At(t.handler)?t.handler.bind(e):i[t.handler];At(r)&&Mi(o,r,t)}}function Cl(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,s=r.get(i);let a;return s?a=s:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>ao(a,c,l,!0)),ao(a,i,l)),jt(i)&&r.set(i,a),a}function ao(t,i,e,n=!1){const{mixins:o,extends:r}=i;r&&ao(t,r,e,!0),o&&o.forEach(l=>ao(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const s=Cd[l]||e&&e[l];t[l]=s?s(t[l],i[l]):i[l]}return t}const Cd={data:ir,props:nr,emits:nr,methods:cn,computed:cn,beforeCreate:he,created:he,beforeMount:he,mounted:he,beforeUpdate:he,updated:he,beforeDestroy:he,beforeUnmount:he,destroyed:he,unmounted:he,activated:he,deactivated:he,errorCaptured:he,serverPrefetch:he,components:cn,directives:cn,watch:Id,provide:ir,inject:$d};function ir(t,i){return i?t?function(){return ce(At(t)?t.call(this,this):t,At(i)?i.call(this,this):i)}:i:t}function $d(t,i){return cn(os(t),os(i))}function os(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function he(t,i){return t?[...new Set([].concat(t,i))]:i}function cn(t,i){return t?ce(Object.create(null),t,i):i}function nr(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:ce(Object.create(null),tr(t),tr(i??{})):i}function Id(t,i){if(!t)return i;if(!i)return t;const e=ce(Object.create(null),t);for(const n in i)e[n]=he(t[n],i[n]);return e}function $l(){return{app:null,config:{isNativeTag:Hr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Ad=0;function Td(t,i){return function(n,o=null){At(n)||(n=ce({},n)),o!=null&&!jt(o)&&(o=null);const r=$l(),l=new WeakSet,s=[];let a=!1;const c=r.app={_uid:Ad++,_component:n,_props:o,_container:null,_context:r,_instance:null,version:lu,get config(){return r.config},set config(d){},use(d,...u){return l.has(d)||(d&&At(d.install)?(l.add(d),d.install(c,...u)):At(d)&&(l.add(d),d(c,...u))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,u){return u?(r.components[d]=u,c):r.components[d]},directive(d,u){return u?(r.directives[d]=u,c):r.directives[d]},mount(d,u,g){if(!a){const f=c._ceVNode||ct(n,o);return f.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(f,d,g),a=!0,c._container=d,d.__vue_app__=c,Io(f.component)}},onUnmount(d){s.push(d)},unmount(){a&&(Re(s,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,u){return r.provides[d]=u,c},runWithContext(d){const u=qi;qi=c;try{return d()}finally{qi=u}}};return c}}let qi=null;const Bd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ge(i)}Modifiers`]||t[`${vi(i)}Modifiers`];function Ed(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Ut;let o=e;const r=i.startsWith("update:"),l=r&&Bd(n,i.slice(7));l&&(l.trim&&(o=e.map(d=>te(d)?d.trim():d)),l.number&&(o=e.map(yo)));let s,a=n[s=Do(i)]||n[s=Do(ge(i))];!a&&r&&(a=n[s=Do(vi(i))]),a&&Re(a,t,6,o);const c=n[s+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[s])return;t.emitted[s]=!0,Re(c,t,6,o)}}const Md=new WeakMap;function Il(t,i,e=!1){const n=e?Md:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const r=t.emits;let l={},s=!1;if(!At(t)){const a=c=>{const d=Il(c,i,!0);d&&(s=!0,ce(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!s?(jt(t)&&n.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):ce(l,r),jt(t)&&n.set(t,l),l)}function Co(t,i){return!t||!mo(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),zt(t,i[0].toLowerCase()+i.slice(1))||zt(t,vi(i))||zt(t,i))}function or(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[r],slots:l,attrs:s,emit:a,render:c,renderCache:d,props:u,data:g,setupState:f,ctx:y,inheritAttrs:h}=t,k=ro(t);let b,w;try{if(e.shapeFlag&4){const T=o||n,x=T;b=He(c.call(x,T,d,u,f,g,y)),w=s}else{const T=i;b=He(T.length>1?T(u,{attrs:s,slots:l,emit:a}):T(u,null)),w=i.props?s:Dd(s)}}catch(T){ei.length=0,_o(T,t,1),b=ct(li)}let _=b;if(w&&h!==!1){const T=Object.keys(w),{shapeFlag:x}=_;T.length&&x&7&&(r&&T.some(go)&&(w=Ld(w,r)),_=Ji(_,w,!1,!0))}return e.dirs&&(_=Ji(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(e.dirs):e.dirs),e.transition&&Cs(_,e.transition),b=_,ro(k),b}const Dd=t=>{let i;for(const e in t)(e==="class"||e==="style"||mo(e))&&((i||(i={}))[e]=t[e]);return i},Ld=(t,i)=>{const e={};for(const n in t)(!go(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function Pd(t,i,e){const{props:n,children:o,component:r}=t,{props:l,children:s,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?sr(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let u=0;u<d.length;u++){const g=d[u];if(Al(l,n,g)&&!Co(c,g))return!0}}}else return(o||s)&&(!s||!s.$stable)?!0:n===l?!1:n?l?sr(n,l,c):!0:!!l;return!1}function sr(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const r=n[o];if(Al(i,t,r)&&!Co(e,r))return!0}return!1}function Al(t,i,e){const n=t[e],o=i[e];return e==="style"&&jt(n)&&jt(o)?!en(n,o):n!==o}function Rd({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const Tl={},Bl=()=>Object.create(Tl),El=t=>Object.getPrototypeOf(t)===Tl;function Od(t,i,e,n=!1){const o={},r=Bl();t.propsDefaults=Object.create(null),Ml(t,i,o,r);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Wc(o):t.type.props?t.props=o:t.props=r,t.attrs=r}function zd(t,i,e,n){const{props:o,attrs:r,vnode:{patchFlag:l}}=t,s=Ot(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let u=0;u<d.length;u++){let g=d[u];if(Co(t.emitsOptions,g))continue;const f=i[g];if(a)if(zt(r,g))f!==r[g]&&(r[g]=f,c=!0);else{const y=ge(g);o[y]=ss(a,s,y,f,t,!1)}else f!==r[g]&&(r[g]=f,c=!0)}}}else{Ml(t,i,o,r)&&(c=!0);let d;for(const u in s)(!i||!zt(i,u)&&((d=vi(u))===u||!zt(i,d)))&&(a?e&&(e[u]!==void 0||e[d]!==void 0)&&(o[u]=ss(a,s,u,void 0,t,!0)):delete o[u]);if(r!==s)for(const u in r)(!i||!zt(i,u))&&(delete r[u],c=!0)}c&&Xe(t.attrs,"set","")}function Ml(t,i,e,n){const[o,r]=t.propsOptions;let l=!1,s;if(i)for(let a in i){if(pn(a))continue;const c=i[a];let d;o&&zt(o,d=ge(a))?!r||!r.includes(d)?e[d]=c:(s||(s={}))[d]=c:Co(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(r){const a=Ot(e),c=s||Ut;for(let d=0;d<r.length;d++){const u=r[d];e[u]=ss(o,a,u,c[u],t,!zt(c,u))}}return l}function ss(t,i,e,n,o,r){const l=t[e];if(l!=null){const s=zt(l,"default");if(s&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&At(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const d=Ln(o);n=c[e]=a.call(null,i),d()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(r&&!s?n=!1:l[1]&&(n===""||n===vi(e))&&(n=!0))}return n}const Nd=new WeakMap;function Dl(t,i,e=!1){const n=e?Nd:i.propsCache,o=n.get(t);if(o)return o;const r=t.props,l={},s=[];let a=!1;if(!At(t)){const d=u=>{a=!0;const[g,f]=Dl(u,i,!0);ce(l,g),f&&s.push(...f)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&n.set(t,Ui),Ui;if(Ct(r))for(let d=0;d<r.length;d++){const u=ge(r[d]);rr(u)&&(l[u]=Ut)}else if(r)for(const d in r){const u=ge(d);if(rr(u)){const g=r[d],f=l[u]=Ct(g)||At(g)?{type:g}:ce({},g),y=f.type;let h=!1,k=!0;if(Ct(y))for(let b=0;b<y.length;++b){const w=y[b],_=At(w)&&w.name;if(_==="Boolean"){h=!0;break}else _==="String"&&(k=!1)}else h=At(y)&&y.name==="Boolean";f[0]=h,f[1]=k,(h||zt(f,"default"))&&s.push(u)}}const c=[l,s];return jt(t)&&n.set(t,c),c}function rr(t){return t[0]!=="$"&&!pn(t)}const As=t=>t==="_"||t==="_ctx"||t==="$stable",Ts=t=>Ct(t)?t.map(He):[He(t)],Fd=(t,i,e)=>{if(i._n)return i;const n=vl((...o)=>Ts(i(...o)),e);return n._c=!1,n},Ll=(t,i,e)=>{const n=t._ctx;for(const o in t){if(As(o))continue;const r=t[o];if(At(r))i[o]=Fd(o,r,n);else if(r!=null){const l=Ts(r);i[o]=()=>l}}},Pl=(t,i)=>{const e=Ts(i);t.slots.default=()=>e},Rl=(t,i,e)=>{for(const n in i)(e||!As(n))&&(t[n]=i[n])},jd=(t,i,e)=>{const n=t.slots=Bl();if(t.vnode.shapeFlag&32){const o=i._;o?(Rl(n,i,e),e&&Kr(n,"_",o,!0)):Ll(i,n)}else i&&Pl(t,i)},Hd=(t,i,e)=>{const{vnode:n,slots:o}=t;let r=!0,l=Ut;if(n.shapeFlag&32){const s=i._;s?e&&s===1?r=!1:Rl(o,i,e):(r=!i.$stable,Ll(i,o)),l=i}else i&&(Pl(t,i),l={default:1});if(r)for(const s in o)!As(s)&&l[s]==null&&delete o[s]},be=qd;function Ud(t){return Wd(t)}function Wd(t,i){const e=ko();e.__VUE__=!0;const{insert:n,remove:o,patchProp:r,createElement:l,createText:s,createComment:a,setText:c,setElementText:d,parentNode:u,nextSibling:g,setScopeId:f=Ke,insertStaticContent:y}=t,h=(L,F,p,U=null,z=null,C=null,$=void 0,R=null,q=!!F.dynamicChildren)=>{if(L===F)return;L&&!rn(L,F)&&(U=pt(L),K(L,z,C,!0),L=null),F.patchFlag===-2&&(q=!1,F.dynamicChildren=null);const{type:W,ref:V,shapeFlag:Y}=F;switch(W){case $o:k(L,F,p,U);break;case li:b(L,F,p,U);break;case qn:L==null&&w(F,p,U,$);break;case Kt:I(L,F,p,U,z,C,$,R,q);break;default:Y&1?x(L,F,p,U,z,C,$,R,q):Y&6?P(L,F,p,U,z,C,$,R,q):(Y&64||Y&128)&&W.process(L,F,p,U,z,C,$,R,q,ut)}V!=null&&z?gn(V,L&&L.ref,C,F||L,!F):V==null&&L&&L.ref!=null&&gn(L.ref,null,C,L,!0)},k=(L,F,p,U)=>{if(L==null)n(F.el=s(F.children),p,U);else{const z=F.el=L.el;F.children!==L.children&&c(z,F.children)}},b=(L,F,p,U)=>{L==null?n(F.el=a(F.children||""),p,U):F.el=L.el},w=(L,F,p,U)=>{[L.el,L.anchor]=y(L.children,F,p,U,L.el,L.anchor)},_=({el:L,anchor:F},p,U)=>{let z;for(;L&&L!==F;)z=g(L),n(L,p,U),L=z;n(F,p,U)},T=({el:L,anchor:F})=>{let p;for(;L&&L!==F;)p=g(L),o(L),L=p;o(F)},x=(L,F,p,U,z,C,$,R,q)=>{if(F.type==="svg"?$="svg":F.type==="math"&&($="mathml"),L==null)S(F,p,U,z,C,$,R,q);else{const W=L.el&&L.el._isVueCE?L.el:null;try{W&&W._beginPatch(),M(L,F,z,C,$,R,q)}finally{W&&W._endPatch()}}},S=(L,F,p,U,z,C,$,R)=>{let q,W;const{props:V,shapeFlag:Y,transition:ot,dirs:et}=L;if(q=L.el=l(L.type,C,V&&V.is,V),Y&8?d(q,L.children):Y&16&&D(L.children,q,null,U,z,Fo(L,C),$,R),et&&xi(L,null,U,"created"),B(q,L,L.scopeId,$,U),V){for(const _t in V)_t!=="value"&&!pn(_t)&&r(q,_t,null,V[_t],C,U);"value"in V&&r(q,"value",null,V.value,C),(W=V.onVnodeBeforeMount)&&ze(W,U,L)}et&&xi(L,null,U,"beforeMount");const at=Vd(z,ot);at&&ot.beforeEnter(q),n(q,F,p),((W=V&&V.onVnodeMounted)||at||et)&&be(()=>{try{W&&ze(W,U,L),at&&ot.enter(q),et&&xi(L,null,U,"mounted")}finally{}},z)},B=(L,F,p,U,z)=>{if(p&&f(L,p),U)for(let C=0;C<U.length;C++)f(L,U[C]);if(z){let C=z.subTree;if(F===C||Fl(C.type)&&(C.ssContent===F||C.ssFallback===F)){const $=z.vnode;B(L,$,$.scopeId,$.slotScopeIds,z.parent)}}},D=(L,F,p,U,z,C,$,R,q=0)=>{for(let W=q;W<L.length;W++){const V=L[W]=R?Je(L[W]):He(L[W]);h(null,V,F,p,U,z,C,$,R)}},M=(L,F,p,U,z,C,$)=>{const R=F.el=L.el;let{patchFlag:q,dynamicChildren:W,dirs:V}=F;q|=L.patchFlag&16;const Y=L.props||Ut,ot=F.props||Ut;let et;if(p&&_i(p,!1),(et=ot.onVnodeBeforeUpdate)&&ze(et,p,F,L),V&&xi(F,L,p,"beforeUpdate"),p&&_i(p,!0),W&&(!L.dynamicChildren||L.dynamicChildren.length!==W.length)&&(q=0,$=!1,W=null),(Y.innerHTML&&ot.innerHTML==null||Y.textContent&&ot.textContent==null)&&d(R,""),W?O(L.dynamicChildren,W,R,p,U,Fo(F,z),C):$||j(L,F,R,null,p,U,Fo(F,z),C,!1),q>0){if(q&16)Z(R,Y,ot,p,z);else if(q&2&&Y.class!==ot.class&&r(R,"class",null,ot.class,z),q&4&&r(R,"style",Y.style,ot.style,z),q&8){const at=F.dynamicProps;for(let _t=0;_t<at.length;_t++){const kt=at[_t],Mt=Y[kt],qt=ot[kt];(qt!==Mt||kt==="value")&&r(R,kt,Mt,qt,z,p)}}q&1&&L.children!==F.children&&d(R,F.children)}else!$&&W==null&&Z(R,Y,ot,p,z);((et=ot.onVnodeUpdated)||V)&&be(()=>{et&&ze(et,p,F,L),V&&xi(F,L,p,"updated")},U)},O=(L,F,p,U,z,C,$)=>{for(let R=0;R<F.length;R++){const q=L[R],W=F[R],V=q.el&&(q.type===Kt||!rn(q,W)||q.shapeFlag&198)?u(q.el):p;h(q,W,V,null,U,z,C,$,!0)}},Z=(L,F,p,U,z)=>{if(F!==p){if(F!==Ut)for(const C in F)!pn(C)&&!(C in p)&&r(L,C,F[C],null,z,U);for(const C in p){if(pn(C))continue;const $=p[C],R=F[C];$!==R&&C!=="value"&&r(L,C,R,$,z,U)}"value"in p&&r(L,"value",F.value,p.value,z)}},I=(L,F,p,U,z,C,$,R,q)=>{const W=F.el=L?L.el:s(""),V=F.anchor=L?L.anchor:s("");let{patchFlag:Y,dynamicChildren:ot,slotScopeIds:et}=F;et&&(R=R?R.concat(et):et),L==null?(n(W,p,U),n(V,p,U),D(F.children||[],p,V,z,C,$,R,q)):Y>0&&Y&64&&ot&&L.dynamicChildren&&L.dynamicChildren.length===ot.length?(O(L.dynamicChildren,ot,p,z,C,$,R),(F.key!=null||z&&F===z.subTree)&&Ol(L,F,!0)):j(L,F,p,V,z,C,$,R,q)},P=(L,F,p,U,z,C,$,R,q)=>{F.slotScopeIds=R,L==null?F.shapeFlag&512?z.ctx.activate(F,p,U,$,q):v(F,p,U,z,C,$,q):G(L,F,q)},v=(L,F,p,U,z,C,$)=>{const R=L.component=Qd(L,U,z);if(wl(L)&&(R.ctx.renderer=ut),eu(R,!1,$),R.asyncDep){if(z&&z.registerDep(R,A,$),!L.el){const q=R.subTree=ct(li);b(null,q,F,p),L.placeholder=q.el}}else A(R,L,F,p,z,C,$)},G=(L,F,p)=>{const U=F.component=L.component;if(Pd(L,F,p))if(U.asyncDep&&!U.asyncResolved){E(U,F,p);return}else U.next=F,U.update();else F.el=L.el,U.vnode=F},A=(L,F,p,U,z,C,$)=>{const R=()=>{if(L.isMounted){let{next:Y,bu:ot,u:et,parent:at,vnode:_t}=L;{const ne=zl(L);if(ne){Y&&(Y.el=_t.el,E(L,Y,$)),ne.asyncDep.then(()=>{be(()=>{L.isUnmounted||W()},z)});return}}let kt=Y,Mt;_i(L,!1),Y?(Y.el=_t.el,E(L,Y,$)):Y=_t,ot&&Kn(ot),(Mt=Y.props&&Y.props.onVnodeBeforeUpdate)&&ze(Mt,at,Y,_t),_i(L,!0);const qt=or(L),Gt=L.subTree;L.subTree=qt,h(Gt,qt,u(Gt.el),pt(Gt),L,z,C),Y.el=qt.el,kt===null&&Rd(L,qt.el),et&&be(et,z),(Mt=Y.props&&Y.props.onVnodeUpdated)&&be(()=>ze(Mt,at,Y,_t),z)}else{let Y;const{el:ot,props:et}=F,{bm:at,m:_t,parent:kt,root:Mt,type:qt}=L,Gt=Ki(F);_i(L,!1),at&&Kn(at),!Gt&&(Y=et&&et.onVnodeBeforeMount)&&ze(Y,kt,F),_i(L,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(qt,L.parent?L.parent.type:void 0);const ne=L.subTree=or(L);h(null,ne,p,U,L,z,C),F.el=ne.el}if(_t&&be(_t,z),!Gt&&(Y=et&&et.onVnodeMounted)){const ne=F;be(()=>ze(Y,kt,ne),z)}(F.shapeFlag&256||kt&&Ki(kt.vnode)&&kt.vnode.shapeFlag&256)&&L.a&&be(L.a,z),L.isMounted=!0,F=p=U=null}};L.scope.on();const q=L.effect=new Yr(R);L.scope.off();const W=L.update=q.run.bind(q),V=L.job=q.runIfDirty.bind(q);V.i=L,V.id=L.uid,q.scheduler=()=>Ss(V),_i(L,!0),W()},E=(L,F,p)=>{F.component=L;const U=L.vnode.props;L.vnode=F,L.next=null,zd(L,F.props,U,p),Hd(L,F.children,p),oi(),Ys(L),si()},j=(L,F,p,U,z,C,$,R,q=!1)=>{const W=L&&L.children,V=L?L.shapeFlag:0,Y=F.children,{patchFlag:ot,shapeFlag:et}=F;if(ot>0){if(ot&128){J(W,Y,p,U,z,C,$,R,q);return}else if(ot&256){N(W,Y,p,U,z,C,$,R,q);return}}et&8?(V&16&&Q(W,z,C),Y!==W&&d(p,Y)):V&16?et&16?J(W,Y,p,U,z,C,$,R,q):Q(W,z,C,!0):(V&8&&d(p,""),et&16&&D(Y,p,U,z,C,$,R,q))},N=(L,F,p,U,z,C,$,R,q)=>{L=L||Ui,F=F||Ui;const W=L.length,V=F.length,Y=Math.min(W,V);let ot;for(ot=0;ot<Y;ot++){const et=F[ot]=q?Je(F[ot]):He(F[ot]);h(L[ot],et,p,null,z,C,$,R,q)}W>V?Q(L,z,C,!0,!1,Y):D(F,p,U,z,C,$,R,q,Y)},J=(L,F,p,U,z,C,$,R,q)=>{let W=0;const V=F.length;let Y=L.length-1,ot=V-1;for(;W<=Y&&W<=ot;){const et=L[W],at=F[W]=q?Je(F[W]):He(F[W]);if(rn(et,at))h(et,at,p,null,z,C,$,R,q);else break;W++}for(;W<=Y&&W<=ot;){const et=L[Y],at=F[ot]=q?Je(F[ot]):He(F[ot]);if(rn(et,at))h(et,at,p,null,z,C,$,R,q);else break;Y--,ot--}if(W>Y){if(W<=ot){const et=ot+1,at=et<V?F[et].el:U;for(;W<=ot;)h(null,F[W]=q?Je(F[W]):He(F[W]),p,at,z,C,$,R,q),W++}}else if(W>ot)for(;W<=Y;)K(L[W],z,C,!0),W++;else{const et=W,at=W,_t=new Map;for(W=at;W<=ot;W++){const ee=F[W]=q?Je(F[W]):He(F[W]);ee.key!=null&&_t.set(ee.key,W)}let kt,Mt=0;const qt=ot-at+1;let Gt=!1,ne=0;const Nt=new Array(qt);for(W=0;W<qt;W++)Nt[W]=0;for(W=et;W<=Y;W++){const ee=L[W];if(Mt>=qt){K(ee,z,C,!0);continue}let Jt;if(ee.key!=null)Jt=_t.get(ee.key);else for(kt=at;kt<=ot;kt++)if(Nt[kt-at]===0&&rn(ee,F[kt])){Jt=kt;break}Jt===void 0?K(ee,z,C,!0):(Nt[Jt-at]=W+1,Jt>=ne?ne=Jt:Gt=!0,h(ee,F[Jt],p,null,z,C,$,R,q),Mt++)}const qe=Gt?Kd(Nt):Ui;for(kt=qe.length-1,W=qt-1;W>=0;W--){const ee=at+W,Jt=F[ee],bi=F[ee+1],Pi=ee+1<V?bi.el||Nl(bi):U;Nt[W]===0?h(null,Jt,p,Pi,z,C,$,R,q):Gt&&(kt<0||W!==qe[kt]?H(Jt,p,Pi,2):kt--)}}},H=(L,F,p,U,z=null)=>{const{el:C,type:$,transition:R,children:q,shapeFlag:W}=L;if(W&6){H(L.component.subTree,F,p,U);return}if(W&128){L.suspense.move(F,p,U);return}if(W&64){$.move(L,F,p,ut);return}if($===Kt){n(C,F,p);for(let Y=0;Y<q.length;Y++)H(q[Y],F,p,U);n(L.anchor,F,p);return}if($===qn){_(L,F,p);return}if(U!==2&&W&1&&R)if(U===0)R.persisted&&!C[zo]?n(C,F,p):(R.beforeEnter(C),n(C,F,p),be(()=>R.enter(C),z));else{const{leave:Y,delayLeave:ot,afterLeave:et}=R,at=()=>{L.ctx.isUnmounted?o(C):n(C,F,p)},_t=()=>{const kt=C._isLeaving||!!C[zo];C._isLeaving&&C[zo](!0),R.persisted&&!kt?at():Y(C,()=>{at(),et&&et()})};ot?ot(C,at,_t):_t()}else n(C,F,p)},K=(L,F,p,U=!1,z=!1)=>{const{type:C,props:$,ref:R,children:q,dynamicChildren:W,shapeFlag:V,patchFlag:Y,dirs:ot,cacheIndex:et,memo:at}=L;if(Y===-2&&(z=!1),R!=null&&(oi(),gn(R,null,p,L,!0),si()),et!=null&&(F.renderCache[et]=void 0),V&256){F.ctx.deactivate(L);return}const _t=V&1&&ot,kt=!Ki(L);let Mt;if(kt&&(Mt=$&&$.onVnodeBeforeUnmount)&&ze(Mt,F,L),V&6)st(L.component,p,U);else{if(V&128){L.suspense.unmount(p,U);return}_t&&xi(L,null,F,"beforeUnmount"),V&64?L.type.remove(L,F,p,ut,U):W&&!W.hasOnce&&(C!==Kt||Y>0&&Y&64)?Q(W,F,p,!1,!0):(C===Kt&&Y&384||!z&&V&16)&&Q(q,F,p),U&&rt(L)}const qt=at!=null&&et==null;(kt&&(Mt=$&&$.onVnodeUnmounted)||_t||qt)&&be(()=>{Mt&&ze(Mt,F,L),_t&&xi(L,null,F,"unmounted"),qt&&(L.el=null)},p)},rt=L=>{const{type:F,el:p,anchor:U,transition:z}=L;if(F===Kt){lt(p,U);return}if(F===qn){T(L);return}const C=()=>{o(p),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(L.shapeFlag&1&&z&&!z.persisted){const{leave:$,delayLeave:R}=z,q=()=>$(p,C);R?R(L.el,C,q):q()}else C()},lt=(L,F)=>{let p;for(;L!==F;)p=g(L),o(L),L=p;o(F)},st=(L,F,p)=>{const{bum:U,scope:z,job:C,subTree:$,um:R,m:q,a:W}=L;lr(q),lr(W),U&&Kn(U),z.stop(),C&&(C.flags|=8,K($,L,F,p)),R&&be(R,F),be(()=>{L.isUnmounted=!0},F)},Q=(L,F,p,U=!1,z=!1,C=0)=>{for(let $=C;$<L.length;$++)K(L[$],F,p,U,z)},pt=L=>{if(L.shapeFlag&6)return pt(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const F=g(L.anchor||L.el),p=F&&F[rd];return p?g(p):F};let bt=!1;const X=(L,F,p)=>{let U;L==null?F._vnode&&(K(F._vnode,null,null,!0),U=F._vnode.component):h(F._vnode||null,L,F,null,null,null,p),F._vnode=L,bt||(bt=!0,Ys(U),hl(),bt=!1)},ut={p:h,um:K,m:H,r:rt,mt:v,mc:D,pc:j,pbc:O,n:pt,o:t};return{render:X,hydrate:void 0,createApp:Td(X)}}function Fo({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function _i({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Vd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Ol(t,i,e=!1){const n=t.children,o=i.children;if(Ct(n)&&Ct(o))for(let r=0;r<n.length;r++){const l=n[r];let s=o[r];s.shapeFlag&1&&!s.dynamicChildren&&((s.patchFlag<=0||s.patchFlag===32)&&(s=o[r]=Je(o[r]),s.el=l.el),!e&&s.patchFlag!==-2&&Ol(l,s)),s.type===$o&&(s.patchFlag===-1&&(s=o[r]=Je(s)),s.el=l.el),s.type===li&&!s.el&&(s.el=l.el)}}function Kd(t){const i=t.slice(),e=[0];let n,o,r,l,s;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(r=0,l=e.length-1;r<l;)s=r+l>>1,t[e[s]]<c?r=s+1:l=s;c<t[e[r]]&&(r>0&&(i[n]=e[r-1]),e[r]=n)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function zl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:zl(i)}function lr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Nl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Nl(i.subTree):null}const Fl=t=>t.__isSuspense;function qd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):ed(t)}const Kt=Symbol.for("v-fgt"),$o=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),qn=Symbol.for("v-stc"),ei=[];let _e=null;function tt(t=!1){ei.push(_e=t?null:[])}function Bs(){ei.pop(),_e=ei[ei.length-1]||null}let $n=1;function ar(t,i=!1){$n+=t,t<0&&_e&&i&&(_e.hasOnce=!0)}function jl(t){return t.dynamicChildren=$n>0?_e||Ui:null,Bs(),$n>0&&_e&&_e.push(t),t}function nt(t,i,e,n,o,r){return jl(m(t,i,e,n,o,r,!0))}function Me(t,i,e,n,o){return jl(ct(t,i,e,n,o,!0))}function Es(t){return t?t.__v_isVNode===!0:!1}function rn(t,i){return t.type===i.type&&t.key===i.key}const Hl=({key:t})=>t??null,Gn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?te(t)||Yt(t)||At(t)?{i:ae,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,n=0,o=null,r=t===Kt?0:1,l=!1,s=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Hl(i),ref:i&&Gn(i),scopeId:gl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ae};return s?(uo(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=te(e)?8:16),$n>0&&!l&&_e&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&_e.push(a),a}const ct=Gd;function Gd(t,i=null,e=null,n=0,o=null,r=!1){if((!t||t===kd)&&(t=li),Es(t)){const s=Ji(t,i,!0);return e&&uo(s,e),$n>0&&!r&&_e&&(s.shapeFlag&6?_e[_e.indexOf(t)]=s:_e.push(s)),s.patchFlag=-2,s}if(ru(t)&&(t=t.__vccOpts),i){i=Zd(i);let{class:s,style:a}=i;s&&!te(s)&&(i.class=It(s)),jt(a)&&(_s(a)&&!Ct(a)&&(a=ce({},a)),i.style=ms(a))}const l=te(t)?1:Fl(t)?128:ld(t)?64:jt(t)?4:At(t)?2:0;return m(t,i,e,n,o,l,r,!0)}function Zd(t){return t?_s(t)||El(t)?ce({},t):t:null}function Ji(t,i,e=!1,n=!1){const{props:o,ref:r,patchFlag:l,children:s,transition:a}=t,c=i?Yd(o||{},i):o,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Hl(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Gn(i)):[r,Gn(i)]:Gn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:s,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ji(t.ssContent),ssFallback:t.ssFallback&&Ji(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&Cs(d,a.clone(d)),d}function co(t=" ",i=0){return ct($o,null,t,i)}function Ae(t,i){const e=ct(qn,null,t);return e.staticCount=i,e}function Lt(t="",i=!1){return i?(tt(),Me(li,null,t)):ct(li,null,t)}function He(t){return t==null||typeof t=="boolean"?ct(li):Ct(t)?ct(Kt,null,t.slice()):Es(t)?Je(t):ct($o,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ji(t)}function uo(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),uo(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!El(i)?i._ctx=ae:o===3&&ae&&(ae.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(At(i)){if(n&65){uo(t,{default:i});return}i={default:i,_ctx:ae},e=32}else i=String(i),n&64?(e=16,i=[co(i)]):e=8;t.children=i,t.shapeFlag|=e}function Yd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=It([i.class,n.class]));else if(o==="style")i.style=ms([i.style,n.style]);else if(mo(o)){const r=i[o],l=n[o];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[o]=r?[].concat(r,l):l:l==null&&r==null&&!go(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function ze(t,i,e,n=null){Re(t,i,7,[e,n])}const Jd=$l();let Xd=0;function Qd(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Jd,r={uid:Xd++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Cc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Dl(n,o),emitsOptions:Il(n,o),emit:null,emitted:null,propsDefaults:Ut,inheritAttrs:n.inheritAttrs,ctx:Ut,data:Ut,props:Ut,attrs:Ut,slots:Ut,refs:Ut,setupState:Ut,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=Ed.bind(null,r),t.ce&&t.ce(r),r}let pe=null;const tu=()=>pe||ae;let fo,rs;{const t=ko(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),r=>{o.length>1?o.forEach(l=>l(r)):o[0](r)}};fo=i("__VUE_INSTANCE_SETTERS__",e=>pe=e),rs=i("__VUE_SSR_SETTERS__",e=>In=e)}const Ln=t=>{const i=pe;return fo(t),t.scope.on(),()=>{t.scope.off(),fo(i)}},cr=()=>{pe&&pe.scope.off(),fo(null)};function Ul(t){return t.vnode.shapeFlag&4}let In=!1;function eu(t,i=!1,e=!1){i&&rs(i);const{props:n,children:o}=t.vnode,r=Ul(t);Od(t,n,r,i),jd(t,o,e||i);const l=r?iu(t,i):void 0;return i&&rs(!1),l}function iu(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,xd);const{setup:n}=e;if(n){oi();const o=t.setupContext=n.length>1?ou(t):null,r=Ln(t),l=Mn(n,t,0,[t.props,o]),s=Ur(l);if(si(),r(),(s||t.sp)&&!Ki(t)&&kl(t),s){if(l.then(cr,cr),i)return l.then(a=>{dr(t,a)}).catch(a=>{_o(a,t,0)});t.asyncDep=l}else dr(t,l)}else Wl(t)}function dr(t,i,e){At(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=dl(i)),Wl(t)}function Wl(t,i,e){const n=t.type;t.render||(t.render=n.render||Ke);{const o=Ln(t);oi();try{_d(t)}finally{si(),o()}}}const nu={get(t,i){return fe(t,"get",""),t[i]}};function ou(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,nu),slots:t.slots,emit:t.emit,expose:i}}function Io(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(dl(Vc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in vn)return vn[e](t)},has(i,e){return e in i||e in vn}})):t.proxy}function su(t,i=!0){return At(t)?t.displayName||t.name:t.name||i&&t.__name}function ru(t){return At(t)&&"__vccOpts"in t}const St=(t,i)=>Yc(t,i,In),lu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ls;const ur=typeof window<"u"&&window.trustedTypes;if(ur)try{ls=ur.createPolicy("vue",{createHTML:t=>t})}catch{}const Vl=ls?t=>ls.createHTML(t):t=>t,au="http://www.w3.org/2000/svg",cu="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,fr=Ye&&Ye.createElement("template"),du={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Ye.createElementNS(au,t):i==="mathml"?Ye.createElementNS(cu,t):e?Ye.createElement(t,{is:e}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,r){const l=e?e.previousSibling:i.lastChild;if(o&&(o===r||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===r||!(o=o.nextSibling)););else{fr.innerHTML=Vl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const s=fr.content;if(n==="svg"||n==="mathml"){const a=s.firstChild;for(;a.firstChild;)s.appendChild(a.firstChild);s.removeChild(a)}i.insertBefore(s,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},uu=Symbol("_vtc");function fu(t,i,e){const n=t[uu];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const po=Symbol("_vod"),Kl=Symbol("_vsh"),ql={name:"show",beforeMount(t,{value:i},{transition:e}){t[po]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):ln(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),ln(t,!0),n.enter(t)):n.leave(t,()=>{ln(t,!1)}):ln(t,i))},beforeUnmount(t,{value:i}){ln(t,i)}};function ln(t,i){t.style.display=i?t[po]:"none",t[Kl]=!i}const pu=Symbol(""),hu=/(?:^|;)\s*display\s*:/;function mu(t,i,e){const n=t.style,o=te(e);let r=!1;if(e&&!o){if(i)if(te(i))for(const l of i.split(";")){const s=l.slice(0,l.indexOf(":")).trim();e[s]==null&&dn(n,s,"")}else for(const l in i)e[l]==null&&dn(n,l,"");for(const l in e){l==="display"&&(r=!0);const s=e[l];s!=null?vu(t,l,!te(i)&&i?i[l]:void 0,s)||dn(n,l,s):dn(n,l,"")}}else if(o){if(i!==e){const l=n[pu];l&&(e+=";"+l),n.cssText=e,r=hu.test(e)}}else i&&t.removeAttribute("style");po in t&&(t[po]=r?n.display:"",t[Kl]&&(n.display="none"))}const pr=/\s*!important$/;function dn(t,i,e){if(Ct(e))e.forEach(n=>dn(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=gu(t,i);pr.test(e)?t.setProperty(vi(n),e.replace(pr,""),"important"):t[n]=e}}const hr=["Webkit","Moz","ms"],jo={};function gu(t,i){const e=jo[i];if(e)return e;let n=ge(i);if(n!=="filter"&&n in t)return jo[i]=n;n=bo(n);for(let o=0;o<hr.length;o++){const r=hr[o]+n;if(r in t)return jo[i]=r}return i}function vu(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&te(n)&&e===n}const mr="http://www.w3.org/1999/xlink";function gr(t,i,e,n,o,r=_c(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(mr,i.slice(6,i.length)):t.setAttributeNS(mr,i,e):e==null||r&&!qr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Le(e)?String(e):e)}function vr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Vl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const s=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(s!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const s=typeof t[i];s==="boolean"?e=qr(e):e==null&&s==="string"?(e="",l=!0):s==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function fi(t,i,e,n){t.addEventListener(i,e,n)}function bu(t,i,e,n){t.removeEventListener(i,e,n)}const br=Symbol("_vei");function yu(t,i,e,n,o=null){const r=t[br]||(t[br]={}),l=r[i];if(n&&l)l.value=n;else{const[s,a]=xu(i);if(n){const c=r[i]=Cu(n,o);fi(t,s,c,a)}else l&&(bu(t,s,l,a),r[i]=void 0)}}const ku=/(Once|Passive|Capture)$/,wu=/^on:?(?:Once|Passive|Capture)$/;function xu(t){let i,e;for(;(e=t.match(ku))&&!wu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):vi(t.slice(2)),i]}let Ho=0;const _u=Promise.resolve(),Su=()=>Ho||(_u.then(()=>Ho=0),Ho=Date.now());function Cu(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(Ct(o)){const r=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{r.call(n),n._stopped=!0};const l=o.slice(),s=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Re(c,i,5,s)}}else Re(o,i,5,[n])};return e.value=t,e.attached=Su(),e}const yr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,$u=(t,i,e,n,o,r)=>{const l=o==="svg";i==="class"?fu(t,n,l):i==="style"?mu(t,e,n):mo(i)?go(i)||yu(t,i,e,n,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):Iu(t,i,n,l))?(vr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&gr(t,i,n,l,r,i!=="value")):t._isVueCE&&(Au(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!te(n)))?vr(t,ge(i),n,r,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),gr(t,i,n,l))};function Iu(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&yr(i)&&At(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return yr(i)&&te(e)?!1:i in t}function Au(t,i){const e=t._def.props;if(!e)return!1;const n=ge(i);return Array.isArray(e)?e.some(o=>ge(o)===n):Object.keys(e).some(o=>ge(o)===n)}const Xi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Kn(i,e):i};function Tu(t){t.target.composing=!0}function kr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function wr(t,i,e){return i&&(t=t.trim()),e&&(t=yo(t)),t}const ho={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ii]=Xi(o);const r=n||o.props&&o.props.type==="number";fi(t,i?"change":"input",l=>{l.target.composing||t[ii](wr(t.value,e,r))}),(e||r)&&fi(t,"change",()=>{t.value=wr(t.value,e,r)}),i||(fi(t,"compositionstart",Tu),fi(t,"compositionend",kr),fi(t,"change",kr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:r}},l){if(t[ii]=Xi(l),t.composing)return;const s=(r||t.type==="number")&&!/^0\d/.test(t.value)?yo(t.value):t.value,a=i??"";if(s===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Un={deep:!0,created(t,i,e){t[ii]=Xi(e),fi(t,"change",()=>{const n=t._modelValue,o=An(t),r=t.checked,l=t[ii];if(Ct(n)){const s=gs(n,o),a=s!==-1;if(r&&!a)l(n.concat(o));else if(!r&&a){const c=[...n];c.splice(s,1),l(c)}}else if(tn(n)){const s=new Set(n);r?s.add(o):s.delete(o),l(s)}else l(Gl(t,r))})},mounted:xr,beforeUpdate(t,i,e){t[ii]=Xi(e),xr(t,i,e)}};function xr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(Ct(i))o=gs(i,n.props.value)>-1;else if(tn(i))o=i.has(n.props.value);else{if(i===e)return;o=en(i,Gl(t,!0))}t.checked!==o&&(t.checked=o)}const Bu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,fi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?yo(An(r)):An(r));t[ii](t.multiple?tn(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,fl(()=>{t._assigning=!1})}),t[ii]=Xi(n)},mounted(t,{value:i}){_r(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ii]=Xi(e)},updated(t,{value:i}){t._assigning||_r(t,i)}};function _r(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!tn(i))){for(let o=0,r=t.options.length;o<r;o++){const l=t.options[o],s=An(l);if(e)if(n){const a=typeof s;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(s)):l.selected=gs(i,s)>-1}else l.selected=i.has(s);else if(en(An(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function An(t){return"_value"in t?t._value:t.value}function Gl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const Eu=["ctrl","shift","alt","meta"],Mu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>Eu.some(e=>t[`${e}Key`]&&!i.includes(e))},Ee=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...r)=>{for(let l=0;l<i.length;l++){const s=Mu[i[l]];if(s&&s(o,i))return}return t(o,...r)}))},Du={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Lu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const r=vi(o.key);if(i.some(l=>l===r||Du[l]===r))return t(o)}))},Pu=ce({patchProp:$u},du);let Sr;function Ru(){return Sr||(Sr=Ud(Pu))}const Zl=((...t)=>{const i=Ru().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=zu(n);if(!o)return;const r=i._component;!At(r)&&!r.render&&!r.template&&(r.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,Ou(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function Ou(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function zu(t){return te(t)?document.querySelector(t):t}function Nu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Se(t){const i=Nu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function Ms(){var i;if(typeof window<"u"&&window.process)return window.process;const t=Se("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Yl(){var i,e;const t=Ms();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Se("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Tn(){const t=Ms();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=Se("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Jl(){var n,o;const t=Ms(),i={...(t==null?void 0:t.env)||{}};if(Tn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function as(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function Fu(){const t=Se("os"),i=Se("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Ds{constructor(i){wt(this,"runner");this.runner=i||Ds.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=Se("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Tn()==="win32",s=Jl();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:s},(c,d,u)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:u?String(u).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=Yl(),e=Tn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,r=!1,l;try{const s=await this.runner("node",["-v"]);s.code===0&&s.stdout.startsWith("v")&&(n=!0,o=s.stdout)}catch{}if(n){try{const s=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(s,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const s=e==="win32"?"npx.cmd":"npx",a=await this.runner(s,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class ju{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class Hu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=Se("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),n),s=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),s)return!0}catch{}await new Promise(r=>setTimeout(r,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const r=Tn()==="win32"?"npx.cmd":"npx",l=as(i),s=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,s,{detached:!1});else{let u=(a=Se("child_process"))==null?void 0:a.spawn;if(!u){const y=await import("node:child_process").catch(()=>({}));u=y==null?void 0:y.spawn}if(!u)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,f=Jl();this.childProcess=u(r,s,{cwd:g,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Tn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=Se("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var r;o(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ls{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const Xl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Uu=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Wu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Vu=`${Yo}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Ku(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const r=(o=n[1])==null?void 0:o.trim();r&&!i.includes(r)&&i.push(r)}return i}class qu{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new us);const e=Fu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,s=as(r),a=as(l),c=Ku(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const b of c){const w=Xl[b]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${b}
// #endregion snippet
`;d.set(b,w)}i.slides.some(b=>{var w;return((w=b.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Uu),d.set("setup/root.ts",Wu),d.set("styles/index.css",Vu);const g=Se("fs"),f=Se("path");let y=!1;const h=f!=null&&f.dirname?f.dirname(s):"",k=/^[a-zA-Z]:[/\\]/.test(s)||s.includes("siyuan-slidev-pro");if(g&&f&&k)try{g.existsSync(h)||g.mkdirSync(h,{recursive:!0}),g.writeFileSync(a,o,"utf-8"),g.writeFileSync(s,n,"utf-8");for(const[b,w]of d.entries()){const _=f.join(h,b),T=f.dirname(_);g.existsSync(T)||g.mkdirSync(T,{recursive:!0}),g.existsSync(_)||g.writeFileSync(_,w,"utf-8")}y=!0}catch{}if(!y&&e)try{const b=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),w=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,w),await e(r,!1,b);for(const[_,T]of d.entries()){const x=`${this.workspacePath}/${_}`,S=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await e(x,!1,S).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}catch(b){return{success:!1,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l,error:String(b)}}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}}class Gu{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new Ls,this.cliBridge=new us,this.nativeBridge=new ju,this.processManager=new Hu,this.scaffolder=new qu,this.envDetector=new Ds}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const r=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Zu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Yu={key:0},Ju={key:1},Xu={key:2},Qu={key:3},tf={key:4},ef={key:5},nf={key:6},of={key:7},sf={key:8},rf={key:9},lf={key:10},af={key:11},cf={key:12},df={key:13},uf={key:14},ff={key:15},pf={key:16},hf={key:17},mf={key:18},gf={key:19},vf={key:20},bf={key:21},yf={key:22},kf={key:23},wf={key:24},xf={key:25},_f={key:26},Sf={key:27},Cf={key:28},$f={key:29},If={key:30},Af={key:31},Tf={key:32},Bf={key:33},Ef={key:34},Mf={key:35},Df={key:36},Lf={key:37},Pf={key:38},Rf={key:39},Of={key:40},zf={key:41},Nf={key:42},Ff={key:43},jf={key:44},Hf={key:45},Uf={key:46},Wf={key:47},Vf={key:48},Kf={key:49},qf={key:50},Gf={key:51},Zf={key:52},Yf=xe({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),nt("svg",Zu,[t.name==="fullscreen"||t.name==="maximize"?(tt(),nt("g",Yu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),nt("g",Ju,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),nt("g",Xu,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),nt("g",Qu,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),nt("g",tf,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),nt("g",ef,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),nt("g",nf,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),nt("g",of,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),nt("g",sf,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),nt("g",rf,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),nt("g",lf,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),nt("g",af,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),nt("g",cf,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),nt("g",df,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),nt("g",uf,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),nt("g",ff,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),nt("g",pf,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),nt("g",hf,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),nt("g",mf,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),nt("g",gf,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),nt("g",vf,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),nt("g",bf,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),nt("g",yf,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),nt("g",kf,[...e[23]||(e[23]=[Ae('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(tt(),nt("g",wf,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),nt("g",xf,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),nt("g",_f,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),nt("g",Sf,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),nt("g",Cf,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),nt("g",$f,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),nt("g",If,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),nt("g",Af,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),nt("g",Tf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),nt("g",Bf,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),nt("g",Ef,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),nt("g",Mf,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),nt("g",Df,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),nt("g",Lf,[...e[37]||(e[37]=[Ae('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),nt("g",Pf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),nt("g",Rf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),nt("g",Of,[...e[40]||(e[40]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),nt("g",zf,[...e[41]||(e[41]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),nt("g",Nf,[...e[42]||(e[42]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),nt("g",Ff,[...e[43]||(e[43]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),nt("g",jf,[...e[44]||(e[44]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),nt("g",Hf,[...e[45]||(e[45]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),nt("g",Uf,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),nt("g",Wf,[...e[47]||(e[47]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),nt("g",Vf,[...e[48]||(e[48]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),nt("g",Kf,[...e[49]||(e[49]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),nt("g",qf,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),nt("g",Gf,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),nt("g",Zf,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Oe=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},gt=Oe(Yf,[["__scopeId","data-v-b8552023"]]);function ie(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(r=>{for(const[l,s]of Object.entries(i))s!=null&&s!==""?r.setAttribute(l,String(s)):r.removeAttribute(l)})}function Jf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${dt}], .protyle-wysiwyg [${Vt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(dt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role");return}const r=t.get(o),l=(r==null?void 0:r[dt])||(r==null?void 0:r["custom-slidev-layout"])||"",s=n.getAttribute(dt)||n.getAttribute("custom-slidev-layout");s&&s!==l&&(l?n.setAttribute(dt,l):(n.removeAttribute(dt),n.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[Vt])||(r==null?void 0:r["custom-slidev-role"])||"",c=n.getAttribute(Vt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Vt,a):(n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role")))})}const Xf={class:"spm-layout-picker"},Qf={class:"spm-layout-picker__grid"},tp=["title","onClick"],ep={class:"spm-layout-icon"},ip={class:"spm-layout-label"},np=xe({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",Xf,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Qf,[(tt(),nt(Kt,null,ye(n,s=>m("div",{key:s.name,class:It(["spm-layout-item",{active:t.modelValue===s.name}]),title:s.desc,onClick:a=>o(s.name)},[m("div",ep,[ct(gt,{name:"layout-"+s.name},null,8,["name"])]),m("span",ip,xt(s.label),1)],10,tp)),64))])]))}}),Ql=Oe(np,[["__scopeId","data-v-c57441d5"]]),op={key:0,class:"spm-transition-selector__header"},sp={class:"spm-transition-list"},rp=["onClick"],lp={class:"spm-transition-meta"},ap={class:"spm-transition-label"},cp={class:"spm-transition-name"},dp={class:"spm-transition-preview-box"},up=xe({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",{class:It(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Lt("",!0):(tt(),nt("div",op,xt(t.title||"转场动效"),1)),m("div",sp,[(tt(),nt(Kt,null,ye(n,s=>m("div",{key:s.name,class:It(["spm-transition-item",{active:t.modelValue===s.name}]),onClick:a=>o(s.name)},[m("div",lp,[m("span",ap,xt(s.label),1),m("span",cp,"("+xt(s.name)+")",1)]),m("div",dp,[m("div",{class:It(["spm-anim-cube","anim-"+s.name])},null,2)])],10,rp)),64))])],2))}}),Ps=Oe(up,[["__scopeId","data-v-b0aa61ff"]]),fp={class:"spm-divider-popover"},pp={class:"spm-divider-popover__title"},hp={class:"spm-form-item"},mp={class:"spm-popover-footer"},gp={class:"spm-save-hint"},vp=xe({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,f,y;const e=t,n=i,o=ft(((g=e.initialAttrs)==null?void 0:g[dt])||"default"),r=ft(((f=e.initialAttrs)==null?void 0:f[Qt])||"slide-left"),l=ft(((y=e.initialAttrs)==null?void 0:y[Ht])||""),s=ft("");Mi(()=>e.initialAttrs,h=>{o.value=(h==null?void 0:h[dt])||"default",r.value=(h==null?void 0:h[Qt])||"slide-left",l.value=(h==null?void 0:h[Ht])||""},{deep:!0});async function a(h,k){if(e.blockId){s.value="正在同步...",Rt.setBlockAttrOverride(e.blockId,{[h]:k}),ie(e.blockId,{[h]:k});try{await Pt(e.blockId,{[h]:k}),s.value="已同步至块属性",n("updated",{[h]:k}),setTimeout(()=>{s.value=""},1500)}catch{s.value="同步失败"}}}function c(h){a(dt,h)}function d(h){a(Qt,h)}function u(){a(Ht,l.value.trim())}return(h,k)=>(tt(),nt("div",fp,[m("div",pp,[k[4]||(k[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:k[0]||(k[0]=b=>n("close"))},"✕")]),ct(Ql,{modelValue:o.value,"onUpdate:modelValue":k[1]||(k[1]=b=>o.value=b),onChange:c},null,8,["modelValue"]),ct(Ps,{modelValue:r.value,"onUpdate:modelValue":k[2]||(k[2]=b=>r.value=b),onChange:d},null,8,["modelValue"]),m("div",hp,[k[5]||(k[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Te(m("input",{"onUpdate:modelValue":k[3]||(k[3]=b=>l.value=b),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:u},null,544),[[ho,l.value]])]),m("div",mp,[m("span",gp,xt(s.value),1)])]))}}),bp=Oe(vp,[["__scopeId","data-v-e4871368"]]),yp={class:"spm-slide-inspector"},kp={class:"spm-inspector-header"},wp={class:"spm-inspector-list"},xp=["onClick"],_p={class:"spm-card-top"},Sp={class:"spm-card-badge"},Cp={class:"spm-card-layout"},$p=["onClick"],Ip={class:"spm-card-preview"},Ap={key:0,class:"spm-card-notes",title:"演讲备忘录"},Tp={class:"spm-inspector-modal-content"},Bp=xe({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=ft(null);function o(c){n.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[dt]=c.frontmatter.layout),c.frontmatter.transition&&(d[Qt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ht]=c.frontmatter.background),c.notes&&(d[ji]=c.notes),d}function l(c){n.value&&(c[dt]&&(n.value.frontmatter.layout=c[dt]),c[Qt]&&(n.value.frontmatter.transition=c[Qt]),c[Ht]&&(n.value.frontmatter.background=c[Ht]),c[ji]&&(n.value.notes=c[ji]),e("refresh"))}function s(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],u=d.content||d.rawMarkdown||"";return u.slice(0,40)+(u.length>40?"...":"")}return(c,d)=>(tt(),nt("div",yp,[m("div",kp,[m("span",null,"幻灯片大纲 ("+xt(t.slides.length)+" 页)",1)]),m("div",wp,[(tt(!0),nt(Kt,null,ye(t.slides,u=>(tt(),nt("div",{key:u.pageIndex,class:It(["spm-card",{active:t.currentActivePage===u.pageIndex}]),onClick:g=>s(u.pageIndex)},[m("div",_p,[m("span",Sp,"P"+xt(u.pageIndex),1),m("span",Cp,xt(u.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Ee(g=>o(u),["stop"])},[ct(gt,{name:"settings"})],8,$p)]),m("div",Ip,xt(a(u)),1),u.notes?(tt(),nt("div",Ap,[ct(gt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,xt(u.notes),1)])):Lt("",!0)],10,xp))),128))]),n.value?(tt(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Ee(u=>n.value=null,["self"]))},[m("div",Tp,[ct(bp,{"block-id":n.value.startBlockId,"initial-attrs":r(n.value),onClose:d[0]||(d[0]=u=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Lt("",!0)]))}}),Ep=Oe(Bp,[["__scopeId","data-v-68b25edd"]]),Mp={class:"spm-immersion-header"},Dp={class:"spm-immersion-header__left"},Lp={class:"spm-immersion-title"},Pp={class:"spm-immersion-header__center"},Rp={class:"spm-immersion-header__actions"},Op=["aria-label"],zp={class:"spm-immersion-body"},Np=xe({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function r(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function s(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((tt(),nt("div",{class:It(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Ee(s,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:It(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",Mp,[m("div",Dp,[Hn(a.$slots,"header-left",{},()=>[m("span",Lp,xt(t.title),1)])]),m("div",Pp,[Hn(a.$slots,"header-center",{},void 0)]),m("div",Rp,[Hn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ct(gt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Op),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[ct(gt,{name:"close"})])])]),m("div",zp,[Hn(a.$slots,"default",{},void 0)])],2)],34)),[[ql,t.visible]])}}),Fp=Oe(Np,[["__scopeId","data-v-3f1665db"]]),jp="slidev-config.json",Qi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ti=xo({...Qi});function Hp(t){if(!t||typeof t!="object")return{...Qi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Qi.webServeUrl}}function Gi(t){if(!t||typeof t!="object")return{...Ti};const i=t;return i.enableWebServeJump!==void 0&&(Ti.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ti.webServeUrl=String(i.webServeUrl)),{...Ti}}function Rs(){return{...Ti}}function ta(t,i,e){const n=(t||Qi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let s=l.pathname.replace(/\/+$/,"");return s.endsWith("/stage/build/desktop")||(s=s?`${s}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${s}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const Up={class:"spm-protyle-drawer"},Wp={class:"spm-protyle-drawer__subbar"},Vp={class:"spm-protyle-drawer__nav"},Kp=["title"],qp={class:"spm-protyle-drawer__actions"},Gp=["aria-label"],Zp=["aria-label"],Yp=xe({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(n.blockId),r=ft(n.title||""),l=ft(!1),s=ft(!0),a=ft(!1),c=ft(""),d=Ti,u=ft([]),g=ft(null);let f=null;Mi(()=>n.blockId,B=>{B&&B!==o.value&&(o.value=B,r.value=n.title||"",u.value=[],h(B))}),Dn(()=>{o.value&&h(o.value)}),$s(()=>{k()});async function y(B){try{const D=await bn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${B}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const M=D[0];c.value=M.root_id||"";const O=M.id===M.root_id||M.type==="d";a.value=O,s.value=!O,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}a.value=!1,s.value=!0}async function h(B,D){if(!g.value||!B)return;k(),await y(B),typeof D=="boolean"&&(s.value=!a.value&&D);let M,O;s.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],O={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],O={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new mt.Protyle(n.plugin.app,g.value,{blockId:B,action:M,render:O}),!l.value&&f&&typeof f.disable=="function"&&f.disable()}catch(Z){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",Z)}}function k(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(B){console.warn("[ProtylePeekDrawer] Error destroying protyle:",B)}f=null}g.value&&(g.value.innerHTML="")}function b(){a.value||(s.value=!s.value,h(o.value,s.value))}function w(){l.value=!l.value,f&&(l.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function _(){if(o.value)try{mt.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(B){console.warn("[ProtylePeekDrawer] openWindow failed:",B)}}function T(){var M;if(!o.value)return;const B=Rs(),D=ta(B.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const O=Se("electron");(M=O==null?void 0:O.shell)!=null&&M.openExternal?O.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}e("external-jump",D)}function x(){if(u.value.length>0){const B=u.value.pop();B&&(o.value=B.blockId,r.value=B.title,s.value=B.isFocusMode,a.value=B.isDoc,h(B.blockId,B.isFocusMode))}}function S(B){const D=B.target;if(!D)return;const M=D.closest('[data-type="block-ref"]');if(M){const Z=M.getAttribute("data-id");if(Z&&Z!==o.value){B.preventDefault(),B.stopPropagation(),u.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=Z,r.value=M.innerText.trim()||Z,h(Z);return}}const O=D.closest("a");if(O&&O.href&&O.href.startsWith("siyuan://blocks/")){B.preventDefault(),B.stopPropagation();const Z=O.href.replace("siyuan://blocks/","").split("?")[0];Z&&Z!==o.value&&(u.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=Z,r.value=O.innerText.trim()||Z,h(Z))}}return(B,D)=>(tt(),nt("div",Up,[m("div",Wp,[m("div",Vp,[u.value.length>0?(tt(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[ct(gt,{name:"arrow-left"}),D[0]||(D[0]=m("span",null,"返回",-1))])):Lt("",!0),m("span",{class:It(["spm-protyle-badge",{"is-focus":s.value&&!a.value}])},xt(s.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||o.value},xt(r.value||o.value),9,Kp)]),m("div",qp,[a.value?Lt("",!0):(tt(),nt("button",{key:0,class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":s.value}]),"aria-label":s.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[ct(gt,{name:s.value?"focus":"file-text"},null,8,["name"]),m("span",null,xt(s.value?"块聚焦":"展开全文"),1)],10,Gp)),m("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[ct(gt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,xt(l.value?"编辑中":"只读"),1)],10,Zp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[ct(gt,{name:"window"}),D[1]||(D[1]=m("span",null,"独立窗口",-1))]),ht(d).enableWebServeJump?(tt(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[ct(gt,{name:"external-link"}),D[2]||(D[2]=m("span",null,"外跳",-1))])):Lt("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:It(["spm-protyle-mount",{"is-focus-mode":s.value&&!a.value}]),onClick:S},null,2)]))}}),Jp=Oe(Yp,[["__scopeId","data-v-7e586ef3"]]),Xp={class:"spm-webview-drawer"},Qp={class:"spm-webview-toolbar"},th={class:"spm-webview-toolbar__nav"},eh=["disabled"],ih=["disabled"],nh=["aria-label"],oh={class:"spm-webview-toolbar__address"},sh=["aria-label"],rh={class:"spm-webview-toolbar__actions"},lh=["aria-label"],ah={class:"spm-zoom-controller"},ch=["disabled"],dh=["disabled"],uh={key:1,class:"spm-webview-fallback"},fh=["src"],Cr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ea="siyuan-slidev-peek-view-mode";let ia="desktop";function ph(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ea);if(t==="mobile"||t==="desktop")return t}catch{}return ia}function hh(t){if(ia=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ea,t)}catch{}}const mh=xe({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(Yl()),r=ft(n.url),l=ft(n.url),s=ft(!1),a=ft(!1),c=ft(!1),d=ft(1),u=ft(!1),g=ft(ph());let f=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=St(()=>g.value==="mobile"?Cr:f||void 0),h=ft(null),k=ft(null);let b=null,w=null,_=null;Mi(()=>n.url,Q=>{Q&&Q!==r.value&&(r.value=Q,l.value=Q,g.value==="mobile"&&D(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q))}),Mi(()=>n.visible,Q=>{if(Q)N(),g.value==="mobile"&&D(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),Dn(()=>{T(),k.value&&typeof ResizeObserver<"u"&&(b=new ResizeObserver(()=>{const Q=h.value;if(Q&&typeof Q.invalidate=="function")try{Q.invalidate()}catch{}}),b.observe(k.value)),w=Q=>{var bt;const pt=Q.message||((bt=Q.error)==null?void 0:bt.message);if(typeof pt=="string"&&pt.includes("Invalid guestInstanceId"))return Q.preventDefault(),Q.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),_=Q=>{const pt=Q.reason,bt=typeof pt=="string"?pt:pt==null?void 0:pt.message;typeof bt=="string"&&bt.includes("Invalid guestInstanceId")&&Q.preventDefault()},window.addEventListener("unhandledrejection",_)}),$s(()=>{if(x(),b&&(b.disconnect(),b=null),w&&(window.removeEventListener("error",w,!0),w=null),_&&(window.removeEventListener("unhandledrejection",_),_=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function T(){const Q=h.value;Q&&(Q.addEventListener("dom-ready",S),Q.addEventListener("did-start-loading",M),Q.addEventListener("did-stop-loading",O),Q.addEventListener("did-navigate",Z),Q.addEventListener("did-navigate-in-page",I),Q.addEventListener("new-window",P))}function x(){const Q=h.value;if(Q)try{Q.removeEventListener("dom-ready",S),Q.removeEventListener("did-start-loading",M),Q.removeEventListener("did-stop-loading",O),Q.removeEventListener("did-navigate",Z),Q.removeEventListener("did-navigate-in-page",I),Q.removeEventListener("new-window",P)}catch{}}function S(){const Q=h.value;if(Q&&typeof Q.getUserAgent=="function"&&!f)try{const pt=Q.getUserAgent();pt&&!pt.includes("iPhone")&&(f=pt)}catch{}g.value==="mobile"&&D(!1),N(),v()}function B(){const Q=g.value==="mobile"?"desktop":"mobile";g.value=Q,hh(Q),D(!0)}function D(Q=!1){const pt=h.value;if(!pt)return;const bt=g.value==="mobile"?Cr:f;if(typeof pt.setUserAgent=="function"&&bt)try{pt.setUserAgent(bt)}catch(X){console.warn("[WebviewPeekDrawer] setUserAgent error:",X)}if(Q&&typeof pt.reload=="function")try{pt.reload()}catch(X){console.warn("[WebviewPeekDrawer] reload error:",X)}}function M(){s.value=!0}function O(){if(s.value=!1,v(),h.value&&typeof h.value.getURL=="function"){const Q=h.value.getURL();Q&&Q!=="about:blank"&&(r.value=Q,l.value=Q)}}function Z(Q){Q!=null&&Q.url&&(r.value=Q.url,l.value=Q.url),v()}function I(Q){Q!=null&&Q.url&&(r.value=Q.url,l.value=Q.url),v()}function P(Q){Q&&Q.url&&(Q.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q.url))}function v(){const Q=h.value;Q&&(typeof Q.canGoBack=="function"&&(a.value=Q.canGoBack()),typeof Q.canGoForward=="function"&&(c.value=Q.canGoForward()))}function G(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function A(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function E(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function j(){let Q=l.value.trim();Q&&(/^https?:\/\//i.test(Q)||(Q=`https://${Q}`),r.value=Q,l.value=Q,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(Q))}function N(){const Q=h.value;if(Q&&typeof Q.setZoomFactor=="function")try{Q.setZoomFactor(d.value)}catch(pt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pt)}}function J(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),N()}function H(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),N()}function K(){d.value=1,N()}function rt(Q){Q.preventDefault(),Q.deltaY<0?J():Q.deltaY>0&&H()}async function lt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Q){console.warn("Copy url failed:",Q)}}function st(){var pt;const Q=r.value;if(typeof window<"u"){const bt=Se("electron");(pt=bt==null?void 0:bt.shell)!=null&&pt.openExternal?bt.shell.openExternal(Q).catch(()=>{window.open(Q,"_blank")}):window.open(Q,"_blank")}e("external-jump",Q)}return(Q,pt)=>{const bt=yd("webview");return tt(),nt("div",Xp,[m("div",Qp,[m("div",th,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:G},[ct(gt,{name:"arrow-left"})],8,eh),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:A},[ct(gt,{name:"arrow-right"})],8,ih),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":s.value?"正在加载...":"刷新页面",onClick:E},[ct(gt,{name:"refresh"})],8,nh)]),m("div",oh,[Te(m("input",{"onUpdate:modelValue":pt[0]||(pt[0]=X=>l.value=X),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Lu(j,["enter"])},null,544),[[ho,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:lt},[ct(gt,{name:"copy"})],8,sh)]),m("div",rh,[m("button",{class:It(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:B},[ct(gt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,lh),m("div",ah,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:H},[ct(gt,{name:"minus"})],8,ch),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:K},xt(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:J},[ct(gt,{name:"plus"})],8,dh)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[ct(gt,{name:"external-link"}),pt[1]||(pt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:k,class:It(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Ee(rt,["ctrl"])},[m("div",{class:It(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[o.value?(tt(),Me(bt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:y.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),nt("div",uh,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,fh),m("div",{class:"spm-fallback-bar"},[pt[2]||(pt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),gh=Oe(mh,[["__scopeId","data-v-40e35375"]]);class vh{constructor(){wt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class bh{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new vh);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Di(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return mt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(s){console.warn("[SelectionMirror] openTab fallback failed:",s)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function yh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return ke(i.join(" "));const n=[];let o=[];const r=()=>{if(o.length>0){const l=o.join(" ");n.push(`<p class="slide-list-item-desc">${ke(l)}</p>`),o=[]}};for(const l of i){const s=l.match(/^(#{1,6})\s+(.*)$/);if(s){r();const a=s[1].length,c=s[2].trim();n.push(`<h${a} class="slide-list-item-title">${ke(c)}</h${a}>`)}else o.push(l)}return r(),n.join(`
`)}function kh(t){if(t.length===0)return"";const i=[];let e=[];const n=r=>{if(e.length>0){const l=e.join(" "),s=r?"slide-list-item-title":"slide-list-item-desc";i.push(`<p class="${s}">${ke(l)}</p>`),e=[]}};let o=!0;for(const r of t){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){n(o);const s=l[1].length,a=l[2].trim();i.push(`<h${s} class="slide-list-item-title">${ke(a)}</h${s}>`),o=!1}else e.push(r)}return n(o),i.join(`
`)+(i.length>0?`
`:"")}function na(t,i,e){var g,f,y,h;const n=t.split(`
`);if(!n.some(k=>/^(\s*)([-*+]|\d+\.)\s+/.test(k)))return null;const r=[],l=[];let s=!1;for(let k=0;k<n.length;k++){const b=n[k];if(!b.trim())continue;const w=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(w){const S=w[1].length,B=Math.floor(S/2);l.push({type:"task",level:B,checked:w[2].toLowerCase()==="x",text:w[3],media:[]});continue}const _=b.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const S=_[1].length,B=Math.floor(S/2);l.push({type:"unordered",level:B,text:_[2],media:[]});continue}const T=b.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(s=!0);const S=T[1].length,B=Math.floor(S/2);l.push({type:"ordered",level:B,text:T[2],media:[]});continue}const x=b.trim();if(!(!x||/^\{:.*?\}$/.test(x)))if(l.length>0){const S=x.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(S){const M=/\.gif(?:\?|$)/i.test(S[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${le(S[1])}" src="${S[2]}" class="${M}" /></div>`);continue}if(x.match(/^<img\b[\s\S]*?\/?>$/i)){const D=x.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${D}</div>`);continue}if(/<video\b/i.test(x)){let D=x;if(!/<\/video>/i.test(D))for(;k+1<n.length&&!/<\/video>/i.test(D);)k++,D+=" "+n[k].trim();const M=((g=e==null?void 0:e.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(D),O=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(D),Z=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-muted"])==="true"||M||/muted/i.test(D),I=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-controls"])==="false",P=D.match(/\bsrc=["']([^"']+)["']/i),v=P?P[1]:"",G=['class="slide-video-player"'];I||G.push("controls"),M&&(G.push("autoplay"),G.push("playsinline")),O&&G.push("loop"),Z&&G.push("muted"),G.push('preload="metadata"'),v&&G.push(`src="${v}"`);const A=D.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=A?A[1].trim():"";!E&&v&&(E=`<source src="${v}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${Z?"true":"false"}"><video ${G.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+x}else r.push(x)}if(l.length===0)return null;const a=s?"ol":"ul",c=s?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",d=l.map(k=>{const b=yh(k.text),w=k.media&&k.media.length>0?`
${k.media.join(`
`)}`:"",_=k.level||0,T=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${k.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",x=_>0?" slide-list-item--nested":"";if(k.type==="task"){const B=k.checked?' checked=""':"";return`<li class="pdf-task-item${x}"${T}><label><input type="checkbox" disabled=""${B}/> <span>${b}</span></label>${w}</li>`}return`<li${x?` class="${x.trim()}"`:""}${T}>${b}${w}</li>`}).join(`
`);return`${kh(r)}<${a} class="${c}">
${d}
</${a}>`}function wh(t,i,e){const n="pdf-block",o=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<o.length;a++){const c=o[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let u=d;if(!/<\/video>/i.test(u))for(;a+1<o.length&&!/<\/video>/i.test(u);)a++,u+=`
`+o[a];r.push(u);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var f,y,h,k;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const b=d[1].length;return`<h${b} class="slide-list-item-title">${ke(d[2].trim())}</h${b}>`}const u=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(u){const w=/\.gif(?:\?|$)/i.test(u[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${le(u[1])}" src="${u[2]}" class="${w}" /></div>`}if(/<video\b/i.test(c)){const b=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),w=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-loop"])==="true"||/loop/i.test(c),_=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||b||/muted/i.test(c),T=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),S=x?x[1]:"",B=['class="slide-video-player"'];T||B.push("controls"),b&&B.push("autoplay playsinline"),w&&B.push("loop"),_&&B.push("muted"),B.push('preload="metadata"'),S&&B.push(`src="${S}"`);const D=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=D?D[1].trim():"";return!M&&S&&(M=`<source src="${S}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${b?"true":"false"}" data-muted="${_?"true":"false"}"><video ${B.join(" ")}>${M}</video></div>`}const g=na(c,i,e);return g||`<p class="slide-list-item-desc">${ke(c)}</p>`}).filter(Boolean).join(`
`)}function xh(t,i){var r,l,s,a,c,d,u,g;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right");if(e==="two-cols"){const f=o.some(D=>D.slot==="right");let y=[],h=[];if(f)y=o.filter(D=>D.slot!=="right"),h=o.filter(D=>D.slot==="right");else{const D=Math.ceil(o.length/2);y=o.slice(0,D),h=o.slice(D)}const k=y.map(D=>Ne(D,i)).join(`
`),b=h.map(D=>Ne(D,i)).join(`
`),w="pdf-two-cols-wrapper layout-two-cols-grid",_=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"",T="pdf-col pdf-col--left",x="pdf-col pdf-col--right",B=`style="grid-template-columns: ${zn((s=t.frontmatter)==null?void 0:s.layoutRatio,2)};"`;return`
      <div class="${w}${_}" ${B}>
        <div class="${T}">${k}</div>
        <div class="${x}">${b}</div>
      </div>
    `}if(e==="two-cols-header"){let f=[];const y=o.filter(D=>D.slot==="header");if(y.length>0)f=y;else if(o.length>0){const D=o.find(M=>M.type==="h"&&(!M.slot||M.slot==="default"));D&&(f=[D])}const h=o.filter(D=>!f.includes(D)),k=h.filter(D=>D.slot==="right"||D.slot==="col-2"),b=h.filter(D=>!k.includes(D)),w=D=>{const M=D.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if(M.length>0){const O=M[0],Z=(O.rawMarkdown||O.content||"").trim();(Zi(O)||/^(?:[-*+]|\d+\.)\s+/.test(Z))&&(O.rawMarkdown=Go(O.rawMarkdown||O.content||""),O.content=O.rawMarkdown)}return M.map(O=>Ne(O,i)).join(`
`)},_=f.map(D=>Ne(D,i)).join(`
`),T=w(b),x=w(k),B=`style="grid-template-columns: ${zn((a=t.frontmatter)==null?void 0:a.layoutRatio,2)};"`;return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${_}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid" ${B}>
          <div class="pdf-col pdf-col--left">${T}</div>
          <div class="pdf-col pdf-col--right">${x}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let f=[];const y=o.filter(O=>O.slot==="header");if(y.length>0)f=y;else if(o.length>0){const O=o.find(Z=>Z.type==="h"&&(!Z.slot||Z.slot==="default"));O&&(f=[O])}const h=o.filter(O=>!f.includes(O)),{col1:k,col2:b,col3:w}=jr(h),_=O=>{const Z=O.filter(I=>!!(I.rawMarkdown||I.content||"").trim());if(Z.length>0){const I=Z[0],P=(I.rawMarkdown||I.content||"").trim();(Zi(I)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(I.rawMarkdown=Go(I.rawMarkdown||I.content||""),I.content=I.rawMarkdown)}return Z.map(I=>Ne(I,i)).join(`
`)},T=f.map(O=>Ne(O,i)).join(`
`),x=_(k),S=_(b),B=_(w),M=`style="grid-template-columns: ${zn((c=t.frontmatter)==null?void 0:c.layoutRatio,3)};"`;return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${T}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid" ${M}>
          <div class="pdf-col pdf-col--1">${x}</div>
          <div class="pdf-col pdf-col--2">${S}</div>
          <div class="pdf-col pdf-col--3">${B}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",y=o.map(T=>Ne(T,i)).join(`
`),h=((d=t.frontmatter)==null?void 0:d.image)||((u=t.frontmatter)==null?void 0:u.background)||"",k=`<div class="pdf-image-col" style="background-image:url('${le(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${le(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,b=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${y}</div>`,w=f?`${b}
${k}`:`${k}
${b}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${zn((g=t.frontmatter)==null?void 0:g.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${w}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(y=>Ne(y,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(y=>Ne(y,i)).join(`
`)}</div>`:o.map(f=>Ne(f,i)).join(`
`)}function le(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function _h(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[r,l]=o.split("-"),s=parseInt(r,10),a=parseInt(l,10);if(!isNaN(s)&&!isNaN(a))for(let c=Math.min(s,a);c<=Math.max(s,a);c++)i.add(c)}else{const r=parseInt(o,10);isNaN(r)||i.add(r)}}return i}const Sh=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ke(t){if(!t)return"";const i=Nr(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const s=l.toLowerCase();if(!Sh.has(s)||/on\w+\s*=|javascript:/i.test(r))return r;if(s==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let o=le(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,s,a,c,d,u)=>{const f=(s??a??c??d??u??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${f}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{const c=/\.gif(?:\?|$)/i.test(s)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${s}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{if(s.startsWith("siyuan://blocks/")){const a=s.replace("siyuan://blocks/","").split("?")[0];return`<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${s}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,s,a)=>`${l}<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${s}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const s=parseInt(l,10);return e[s]||""}),o}function Ch(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${ke(a)}</th>`).join("")}</tr></thead>`,s=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${ke(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${s}</tbody></table>`}function Uo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function $h(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Uo(t)}</span>`;const e=[];function n(r,l){return e.push(`<span class="${r}">${Uo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(r,l,s)=>n("token-string",`${l}${s}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>n("token-keyword",r)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>n("token-type",r)),o=o.replace(/\b(\d+)\b/g,r=>n("token-number",r)),o=Uo(o),o=o.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),o}function Ih(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function Ah(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const u=Ih(c,d+1);u&&r.push(u)});const l=[];let s=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),s=d):s?(d.active&&(s.hasActiveChild=!0),s.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const u=[];for(const g of c){const f=a(g.children,d+1);d>=n?u.push({...g,children:f}):u.push(...f)}return u}return a(l,1)}function Th(t,i=1,e={}){const n=Ah(t,i,e),o=e.columns?Number(e.columns):1,r=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function s(c,d=1){if(!c||c.length===0)return"";const u=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(f=>{const y=f.active?" slidev-toc-item-active":f.hasActiveChild?" slidev-toc-item-parent-active":"",h=f.children&&f.children.length>0?s(f.children,d+1):"";let k=ke(f.title);return k.includes("LaTeX")&&(k=k.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${y}" data-page="${f.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${k}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${u}">${g}</ol>`}const a=s(n,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Ne(t,i){var k,b,w,_,T,x,S,B,D;let e="",n="",o="";const r=[];(k=t.motion)!=null&&k.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),o=" slide-styled-block"),r.length>0&&(n=` style="${le(r.join(";"))}"`);const a=`pdf-block${e}${o}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${n}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${n}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${n}><div class="katex-display font-math"><em>${le(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,O=ke(d[2]);return`<div class="${a}"${n}><h${M}>${O}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),Z=M[0].replace(/^:::\s*/,"").trim()||"info",I=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),P="pdf-callout";return`<div class="${a}"${n}><div class="${P} ${P}--${Z}"><div class="${P}-title">${Z.toUpperCase()}</div><div class="${P}-body">${ke(I)}</div></div></div>`}if(c.startsWith("<<<")){const Z=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((G,A)=>`<span class="code-line shiki-focus"><span class="line-no">${A+1}</span><span class="line-content">${$h(G,"ts")}</span></span>`).join(`
`),I="pdf-code shiki-container",P=((w=t.attrs)==null?void 0:w["custom-slidev-max-height"])||t.maxHeight||"",v=P?` style="max-height:${le(P)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${I}"${v}><span class="lang-badge">TS</span><code>${Z}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),O=M[0].slice(3).trim(),Z=O.match(/^([^\s{\[]+)/),I=Z?Z[1]:"",P=O.match(/\[([^\]]+)\]/),v=P?P[1]:"",G=O.includes("twoslash"),A=t.shikiLines||((_=O.match(/\{([^}]+)\}/))==null?void 0:_[1])||"",E=_h(A),j=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],N="pdf-code shiki-container",J=v?`${N} has-filename`:N,H=E!=="all",K=j.map((pt,bt)=>{const X=bt+1,vt=E==="all"||E.has(X)?"code-line shiki-focus":H?"code-line shiki-dimmed":"code-line";let L=le(pt);return G&&pt.includes("doubled.value = 2")?(L=L.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${vt}"><span class="line-no">${X}</span><span class="line-content">${L}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${vt}"><span class="line-no">${X}</span><span class="line-content">${L}</span></span>`}).join(`
`),rt=I?`<span class="lang-badge">${le(I)}</span>`:"",lt=v?`<span class="code-filename">${le(v)}</span>`:"",st=((T=t.attrs)==null?void 0:T["custom-slidev-max-height"])||t.maxHeight||"",Q=st?` style="max-height:${le(st)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${J}"${Q}>${lt}${rt}<code>${K}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(Z=>Z.trim().startsWith("|")),O=Ch(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${n}>${O}</div>`}if(c.startsWith("> "))return`<div class="${a}"${n}><blockquote class="pdf-quote"><p>${ke(c.slice(2))}</p></blockquote></div>`;const u=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),f=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(u&&!g&&!f&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),O=((S=t.attributes)==null?void 0:S["custom-slidev-loop"])==="true"||/loop/i.test(c),Z=((B=t.attributes)==null?void 0:B["custom-slidev-muted"])==="true"||M||/muted/i.test(c),I=((D=t.attributes)==null?void 0:D["custom-slidev-controls"])==="false",P=c.match(/\bsrc=["']([^"']+)["']/i),v=P?P[1]:"",G=['class="slide-video-player"'];I||G.push("controls"),M&&(G.push("autoplay"),G.push("playsinline")),O&&G.push("loop"),Z&&G.push("muted"),G.push('preload="metadata"'),v&&G.push(`src="${v}"`);const A=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=A?A[1].trim():"";return!E&&v&&(E=`<source src="${v}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${Z?"true":"false"}"${n}><video ${G.join(" ")}>${E}</video></div>`}const y=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(y)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${n}><img alt="${le(y[1])}" src="${y[2]}" class="pdf-image slide-media-img" /></div>`;const h=na(c,i,t);if(h)return`<div class="${a} pdf-list-item"${n}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),O=c.match(/maxDepth=["']?(\d+)["']?/i),Z=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${n}>${Th([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:O?parseInt(O[1],10):1/0,columns:Z?parseInt(Z[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||f){const M=wh(c,i,t);if(M)return`<div class="${a}"${n}>${M}</div>`}return`<div class="${a}"${n}><p>${ke(c)}</p></div>`}function Bh(t){return`
    ${fn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function Eh(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function oa(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${le(e)}</title>
  <style>
${Bh(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Eh()}
  <\/script>
</body>
</html>`}function sa(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Mh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Dh(t){const i=Mh(t==null?void 0:t.pageRatio);return`
    ${fn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function Lh(t,i){const e="Slidev 演示讲义",n="16:9",o="light",r=t.slides.map((l,s)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:t.config.spacing||"normal",u=xh(l),g=`${s+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${le(e)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${u}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${le(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${le(e)} - 高保真讲义</title>
  <style>
    ${Dh({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body>
  ${r}
</body>
</html>`}function ra(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=Lh(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(o=r.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var s,a;try{(s=r.contentWindow)==null||s.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Ph={class:"spm-slidev-preview-tab"},Rh={class:"spm-slidev-tab__toolbar"},Oh={class:"spm-slidev-tab__actions"},zh=["disabled"],Nh={class:"spm-page-badge"},Fh=["disabled"],jh=["aria-label"],Hh=["aria-label"],Uh=["src"],Wh=xe({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ti("plugin"),n=ti("sandboxBridge",new Ls),o=new bh(n),r=new Gu,l=ft("web-sandbox"),s=ft(3030),a=ft(null),c=ft(!1),d=ft(null),u=ft(1),g=ft(1),f=ft([]),y=ft(!1),h=ft(!1),k=ft(!1),b=ft("siyuan"),w=ft(""),_=ft(""),T=ft(""),x=ft(!1),S=ft(!1),B=ft(""),D=ft("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,O=null,Z=null,I=null,P=null,v=null,G=null;Dn(()=>{d.value&&(n.attach(d.value),r.nativeBridge.attach(d.value)),M=n.onSlideChanged((X,ut)=>{u.value=X,g.value=ut}),O=n.onBlockClicked((X,ut)=>{u.value=ut,o.setActiveBlockId(X),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(X,ut):Di(X,e==null?void 0:e.app)}),Z=n.onOpenInEditor((X,ut)=>{u.value=ut,o.setActiveBlockId(X),Di(X,e==null?void 0:e.app)}),I=r.nativeBridge.onPageChanged((X,ut)=>{u.value=X,g.value=ut}),P=n.onOpenPeekDrawer(async X=>{const ut=Rs();if(X.peekType==="siyuan"&&ut.enableWebServeJump){let vt=!1;if(G&&G.docId===X.target)vt=!0;else if(G&&G.slides&&G.slides.some(L=>{var F;return(F=L.blocks)==null?void 0:F.some(p=>p.id===X.target)}))vt=!1;else try{const L=await bn(`SELECT id, root_id, type FROM blocks WHERE id = '${X.target}' LIMIT 1`);L&&L.length>0&&(vt=L[0].type==="d"||L[0].id===L[0].root_id)}catch(L){console.warn("[SlidevPreviewTab] detect block type failed:",L)}b.value="web",x.value=!0,_.value=ta(ut.webServeUrl,X.target,{focus:!vt}),T.value=X.title||`${vt?"思源文档":"思源块"}: ${X.target.slice(0,8)}`,h.value=!0,n.freezeKeyboardNav(!0)}else b.value=X.peekType,X.peekType==="siyuan"?(w.value=X.target,T.value=X.title||`块速览: ${X.target.slice(0,8)}`):(x.value=!0,_.value=X.target,T.value=X.title||X.target),h.value=!0,n.freezeKeyboardNav(!0)}),v=n.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",lt)}),Is(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",lt),P&&P(),v&&v(),M&&M(),O&&O(),Z&&Z(),I&&I(),n.detach(),o.destroy(),r.destroy()});async function A(){if(l.value==="web-sandbox"){if(!G){mt.showMessage("请先在主编辑区打开演示文档");return}mt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const X=await r.startProMode(G,Ko);if(!X.success){mt.showMessage(`无法启动官方 Pro 模式：${X.error}`);return}l.value="pro-cli",s.value=X.port||3030,D.value=X.url,d.value&&r.nativeBridge.attach(d.value),mt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${s.value})`)}else r.stopProMode(),l.value="web-sandbox",D.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),mt.showMessage("已切回内置高保真沙箱")}function E(){S.value=!S.value,S.value?B.value=(G==null?void 0:G.docId)||"":(B.value="",H())}function j(){u.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(u.value-1):n.navigatePage(u.value-1))}function N(){u.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(u.value+1):n.navigatePage(u.value+1))}function J(X){u.value=X,l.value==="pro-cli"?r.nativeBridge.navigateToPage(X):n.navigatePage(X)}function H(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function K(){h.value=!1,n.freezeKeyboardNav(!1)}function rt(){K()}function lt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const X=a.value||d.value;X&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):X.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function Q(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function pt(){if(!G){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const X=oa(G);sa("presentation.html",X)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function bt(){if(!G){mt.showMessage("请先在主编辑区打开幻灯片文档");return}ra(G)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(X,ut){S.value&&B.value&&ut&&ut!==B.value||(G=X,S.value&&!B.value&&(B.value=X.docId),f.value=X.slides,g.value=X.slides.length,o.setDocId(X.docId),o.updateSlidesIndex(X.slides),l.value==="pro-cli"?r.scaffolder.scaffold(X,Ko).catch(()=>{}):n.updateSlides(X.slides,X.config,X.fullMarkdown,X.customThemeCss))},navigateToBlock(X){o.onCursorFocusBlock(X)},isPinned:S,pinnedDocId:B,engineMode:l,toggleEngineMode:A}),(X,ut)=>(tt(),nt("div",Ph,[m("div",Rh,[ut[4]||(ut[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",Oh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value<=1,"aria-label":"上一页",onClick:j},[ct(gt,{name:"chevron-left"})],8,zh),m("span",Nh,xt(u.value)+" / "+xt(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value>=g.value,"aria-label":"下一页",onClick:N},[ct(gt,{name:"chevron-right"})],8,Fh),m("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":S.value}]),"aria-label":S.value?"已锁定当前文档（点击解除）："+B.value:"点击锁定当前文档（不随主编辑区切换）",onClick:E},[ct(gt,{name:"pin"}),m("span",null,xt(S.value?"已锁定":"跟随"),1)],10,jh),m("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+s.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:A},[ct(gt,{name:"step"}),m("span",null,xt(l.value==="pro-cli"?"Pro ("+s.value+")":"沙箱"),1)],10,Hh),ut[3]||(ut[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":y.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ut[0]||(ut[0]=vt=>y.value=!y.value)},[ct(gt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:Q},[ct(gt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:pt},[ct(gt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:bt},[ct(gt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:H},[ct(gt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[ct(gt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:D.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Uh),ct(Fp,{visible:h.value,"onUpdate:visible":ut[1]||(ut[1]=vt=>h.value=vt),"is-maximized":k.value,"onUpdate:isMaximized":ut[2]||(ut[2]=vt=>k.value=vt),title:T.value,onClose:K},{default:vl(()=>[b.value==="siyuan"&&w.value?(tt(),Me(Jp,{key:0,"block-id":w.value,title:T.value,plugin:ht(e),onExternalJump:rt},null,8,["block-id","title","plugin"])):Lt("",!0),x.value?Te((tt(),Me(gh,{key:1,visible:h.value&&b.value==="web",url:_.value,title:T.value,onExternalJump:rt},null,8,["visible","url","title"])),[[ql,b.value==="web"]]):Lt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),y.value&&f.value.length>0?(tt(),Me(Ep,{key:0,slides:f.value,"current-active-page":u.value,onNavigate:J,onRefresh:H},null,8,["slides","current-active-page"])):Lt("",!0)]))}}),Vh=Oe(Wh,[["__scopeId","data-v-2622f6d8"]]),Kh={class:"spm-section spm-section--page"},qh={class:"spm-section-header"},Gh={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Zh={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Yh={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Jh={key:1,class:"spm-card-control"},Xh={class:"spm-control-header"},Qh={class:"spm-control-title-group"},tm={class:"spm-control-title"},em=["aria-label"],im={key:1,class:"spm-btn-text b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed"},"aria-label":"当前页未检测到调整过列宽的横向超级块（默认各列平均分配）"},nm={class:"spm-quick-chips"},om=["onClick"],sm={style:{display:"flex",gap:"8px","align-items":"center","margin-top":"6px"}},rm=["value"],lm={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center","justify-content":"space-between"}},am={style:{display:"flex","align-items":"center",gap:"4px"}},cm={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},dm={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6"}},um={class:"spm-card-control"},fm={class:"spm-control-header"},pm={class:"spm-control-title-group"},hm={class:"spm-control-title"},mm={class:"spm-segmented-group"},gm={class:"spm-card-control"},vm={class:"spm-control-header"},bm={class:"spm-control-title-group"},ym={class:"spm-control-title"},km={class:"spm-quick-chips"},wm=["onClick"],xm=["value"],_m={key:2,class:"spm-card-control"},Sm={class:"spm-control-header"},Cm={class:"spm-control-title-group"},$m={class:"spm-control-title"},Im={class:"spm-quick-chips"},Am=["onClick"],Tm=["value"],Bm={class:"spm-card-control"},Em={class:"spm-control-header"},Mm={class:"spm-control-title-group"},Dm={class:"spm-control-title"},Lm={key:0,class:"spm-note-status-box"},Pm=["title"],Rm={class:"spm-action-grid",style:{"margin-top":"6px"}},Om={key:1,class:"spm-note-empty-box"},zm={class:"spm-card-control"},Nm={class:"spm-action-grid"},Fm=xe({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=St(()=>["two-cols","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),o=St(()=>e.pageLayout==="three-cols-header"),r=St(()=>o.value?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]),l=St(()=>e.pageLayoutRatio||""),s=St(()=>{if(!e.pageNotes)return"";const d=e.pageNotes.replace(/[\r\n]+/g," ").trim();return d.length>50?d.slice(0,50)+"...":d}),a=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],c=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(d,u)=>(tt(),nt("div",Kh,[m("div",qh,[m("span",null,"幻灯片页面设置"+xt(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ct(Ql,{"model-value":t.pageLayout,onChange:u[0]||(u[0]=g=>d.$emit("update:pageLayout",g))},null,8,["model-value"]),!n.value&&t.detectedSbRatio?(tt(),nt("div",Gh,[m("div",Zh,[m("div",Yh,[ct(gt,{name:"sparkles"}),m("span",null,[u[22]||(u[22]=co("检测到本页横向超级块列宽比例：",-1)),m("b",null,xt(t.detectedSbRatio),1)])]),m("button",{class:"spm-btn-action",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff"},onClick:u[1]||(u[1]=g=>d.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))}," 一键设为分栏并应用 ")])])):Lt("",!0),n.value?(tt(),nt("div",Jh,[m("div",Xh,[m("div",Qh,[m("div",tm,[ct(gt,{name:"ratio"}),u[23]||(u[23]=m("span",null,"分栏比例 (Ratio)",-1))]),u[24]||(u[24]=m("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))]),t.detectedSbRatio?(tt(),nt("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio})`,onClick:u[2]||(u[2]=g=>d.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[ct(gt,{name:"sparkles"}),m("span",null,"从超级块读取 ("+xt(t.detectedSbRatio)+")",1)],8,em)):(tt(),nt("button",im,[ct(gt,{name:"sparkles"}),u[25]||(u[25]=m("span",null,"从超级块读取 (未检测到)",-1))]))]),m("div",nm,[(tt(!0),nt(Kt,null,ye(r.value,g=>(tt(),nt("button",{key:g.value,class:It(["spm-chip",{active:l.value===g.value}]),onClick:f=>d.$emit("update:pageLayoutRatio",g.value)},xt(g.label),11,om))),128))]),m("div",sm,[m("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:u[3]||(u[3]=g=>d.$emit("update:pageLayoutRatio",g.target.value)),onChange:u[4]||(u[4]=g=>d.$emit("update:pageLayoutRatio",g.target.value))},null,40,rm),t.pageLayoutRatio?(tt(),nt("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"重置为默认平均分配",style:{"flex-shrink":"0",padding:"0 10px",height:"28px"},onClick:u[5]||(u[5]=g=>d.$emit("update:pageLayoutRatio",""))}," 重置 ")):Lt("",!0)]),t.detectedSbRatio?(tt(),nt("div",lm,[m("div",am,[u[26]||(u[26]=m("span",null,"📐 检测到思源超级块宽度：",-1)),m("code",cm,xt(t.detectedSbRatio),1)]),t.pageLayoutRatio!==t.detectedSbRatio?(tt(),nt("button",{key:0,class:"spm-btn-text",style:{"font-size":"11px",padding:"0 4px"},onClick:u[6]||(u[6]=g=>d.$emit("update:pageLayoutRatio",t.detectedSbRatio))}," 点击应用 ")):Lt("",!0)])):(tt(),nt("div",dm,[...u[27]||(u[27]=[m("span",null,"📐 未检测到调宽超级块（默认各列平均分配）",-1)])]))])):Lt("",!0),ct(Ps,{"model-value":t.pageTransition,onChange:u[7]||(u[7]=g=>d.$emit("update:pageTransition",g))},null,8,["model-value"]),m("div",um,[m("div",fm,[m("div",pm,[m("div",hm,[ct(gt,{name:"ratio"}),u[28]||(u[28]=m("span",null,"页面间距 (Spacing)",-1))]),u[29]||(u[29]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",mm,[m("button",{class:It(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:u[8]||(u[8]=g=>d.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:u[9]||(u[9]=g=>d.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:u[10]||(u[10]=g=>d.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:u[11]||(u[11]=g=>d.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",gm,[m("div",vm,[m("div",bm,[m("div",ym,[ct(gt,{name:"palette"}),u[30]||(u[30]=m("span",null,"页面背景 (Background)",-1))]),u[31]||(u[31]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",km,[(tt(),nt(Kt,null,ye(a,g=>m("button",{key:g.value,class:It(["spm-chip",{active:t.pageBackground===g.value}]),onClick:f=>d.$emit("update:pageBackground",g.value)},xt(g.label),11,wm)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:u[12]||(u[12]=g=>d.$emit("update:pageBackground",g.target.value)),onChange:u[13]||(u[13]=g=>d.$emit("update:pageBackground",g.target.value))},null,40,xm)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),nt("div",_m,[m("div",Sm,[m("div",Cm,[m("div",$m,[ct(gt,{name:"image"}),u[32]||(u[32]=m("span",null,"页面图片 (Image)",-1))]),u[33]||(u[33]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Im,[(tt(),nt(Kt,null,ye(c,g=>m("button",{key:g.value,class:It(["spm-chip",{active:t.pageImage===g.value}]),onClick:f=>d.$emit("update:pageImage",g.value)},xt(g.label),11,Am)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:u[14]||(u[14]=g=>d.$emit("update:pageImage",g.target.value)),onChange:u[15]||(u[15]=g=>d.$emit("update:pageImage",g.target.value))},null,40,Tm)])):Lt("",!0),m("div",Bm,[m("div",Em,[m("div",Mm,[m("div",Dm,[ct(gt,{name:"presenter"}),u[34]||(u[34]=m("span",null,"演讲者提词 (Notes)",-1))]),u[35]||(u[35]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:u[16]||(u[16]=g=>d.$emit("generateNotes"))},[ct(gt,{name:"sparkles"}),u[36]||(u[36]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),nt("div",Lm,[u[39]||(u[39]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},xt(s.value),9,Pm),m("div",Rm,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:u[17]||(u[17]=g=>d.$emit("locateNoteBlock"))},[ct(gt,{name:"search"}),u[37]||(u[37]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:u[18]||(u[18]=g=>d.$emit("addNoteBlock"))},[ct(gt,{name:"insert-below"}),u[38]||(u[38]=m("span",null,"追加讲稿块",-1))])])])):(tt(),nt("div",Om,[u[41]||(u[41]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:u[19]||(u[19]=g=>d.$emit("addNoteBlock"))},[ct(gt,{name:"insert-below"}),u[40]||(u[40]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",zm,[u[44]||(u[44]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",Nm,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:u[20]||(u[20]=g=>d.$emit("insertDividerAfter"))},[ct(gt,{name:"insert-below"}),u[42]||(u[42]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:u[21]||(u[21]=g=>d.$emit("deleteDivider"))},[ct(gt,{name:"trash"}),u[43]||(u[43]=m("span",null,"删除此页",-1))])])])]))}}),jm=Oe(Fm,[["__scopeId","data-v-72aa7048"]]),Hm={class:"spm-section spm-section--block"},Um={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Wm={class:"spm-control-header"},Vm={class:"spm-control-title-group"},Km={class:"spm-control-title"},qm={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Gm={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Zm={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Ym={key:0},Jm={key:1},Xm={style:{background:"var(--b3-theme-primary-lightest)",color:"var(--b3-theme-primary)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Qm={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},tg={class:"spm-action-grid"},eg={class:"spm-card-control"},ig={class:"spm-control-header"},ng={class:"spm-control-title-group"},og={class:"spm-control-title"},sg=["aria-label"],rg=["checked"],lg={key:1,class:"spm-card-control"},ag={class:"spm-control-header"},cg={class:"spm-control-title-group"},dg={class:"spm-control-title"},ug={class:"spm-quick-chips"},fg={key:2,class:"spm-card-control"},pg={class:"spm-control-header"},hg={class:"spm-control-title-group"},mg={class:"spm-control-title"},gg={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},vg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},bg=["aria-label"],yg=["checked"],kg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},wg=["aria-label"],xg=["checked"],_g={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Sg=["aria-label"],Cg=["checked"],$g={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Ig=["aria-label"],Ag=["checked"],Tg={class:"spm-card-control"},Bg={class:"spm-control-header"},Eg={class:"spm-control-title-group"},Mg={class:"spm-control-title"},Dg=["aria-label"],Lg=["checked"],Pg={key:0,class:"spm-quick-chips"},Rg=["onClick"],Og={class:"spm-card-control"},zg={class:"spm-control-header"},Ng={class:"spm-control-title-group"},Fg={class:"spm-control-title"},jg=["aria-label"],Hg=["checked"],Ug={key:0,class:"spm-quick-chips"},Wg=["onClick"],Vg={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Kg={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},qg={style:{display:"flex",gap:"6px"}},Gg=["value"],Zg=["value"],Yg={key:3,class:"spm-card-control"},Jg={class:"spm-control-header"},Xg={class:"spm-control-title-group"},Qg={class:"spm-control-title"},tv={class:"spm-control-desc"},ev={class:"spm-segmented-group"},iv=["onClick"],nv={key:4,class:"spm-card-control"},ov={class:"spm-control-header"},sv={class:"spm-control-title-group"},rv={class:"spm-control-title"},lv={class:"spm-quick-chips"},av=["onClick"],cv=["value"],dv={key:5,class:"spm-card-control"},uv={class:"spm-control-header"},fv={class:"spm-control-title-group"},pv={class:"spm-control-title"},hv={class:"spm-quick-chips"},mv=["onClick"],gv=["value"],vv={class:"spm-card-control"},bv={class:"spm-action-grid"},yv=["aria-label"],kv=xe({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=St(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),o=St(()=>{const x=n.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=St(()=>{const x=n.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=St(()=>{const x=n.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),s=St(()=>{const x=n.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const S=e.elemSlot||"";return x?S===x||x==="col-1"&&S==="left"||x==="col-2"&&S==="center"||x==="col-3"&&S==="right"||x==="left"&&S==="col-1"||x==="right"&&(S==="col-2"||S==="col-3"):!S||S==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],u=St(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=St(()=>!!u.value),f=St(()=>{var x;return((x=u.value)==null?void 0:x.preset)||"slide-up"}),y=St(()=>{var x;return((x=u.value)==null?void 0:x.duration)||0}),h=St(()=>{var x;return((x=u.value)==null?void 0:x.delay)||0});function k(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function b(x){T(x,y.value,h.value)}function w(x){T(f.value,x,h.value)}function _(x){T(f.value,y.value,x)}function T(x,S,B){if(!x||x==="none"){c("update:elemMotion","");return}if(!S&&!B){c("update:elemMotion",x);return}const D={preset:x};S>0&&(D.duration=S),B>0&&(D.delay=B),c("update:elemMotion",JSON.stringify(D))}return(x,S)=>{var B,D,M,O,Z,I;return tt(),nt("div",Hm,[S[58]||(S[58]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(B=t.detectedSbInfo)!=null&&B.hasSuperBlock?(tt(),nt("div",Um,[m("div",Wm,[m("div",Vm,[m("div",Km,[ct(gt,{name:"ratio"}),S[24]||(S[24]=m("span",null,"超级块列宽与布局",-1))]),S[25]||(S[25]=m("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),m("div",qm,[m("div",Gm,[m("div",Zm,[(D=t.detectedSbInfo)!=null&&D.isCustomWidth?(tt(),nt("span",Ym,"📐 已识别自定义列宽比例")):(tt(),nt("span",Jm,"📐 识别到 "+xt(((M=t.detectedSbInfo)==null?void 0:M.colCount)||2)+" 列超级块分栏",1))]),m("code",Xm,xt(((O=t.detectedSbInfo)==null?void 0:O.ratio)||"1:1"),1)]),m("div",Qm,xt((Z=t.detectedSbInfo)!=null&&Z.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),m("div",tg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"var(--b3-theme-primary-lightest)",color:"var(--b3-theme-primary)","font-weight":"500"},onClick:S[0]||(S[0]=P=>x.$emit("applySuperBlockLayout",t.detectedSbInfo))},[ct(gt,{name:"sparkles"}),S[26]||(S[26]=m("span",null,"设为本页排版与比例",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:S[1]||(S[1]=P=>{var v;return x.$emit("applySuperBlockRatio",((v=t.detectedSbInfo)==null?void 0:v.ratio)||"1:1")})},[ct(gt,{name:"check"}),m("span",null,"仅应用比例 ("+xt(((I=t.detectedSbInfo)==null?void 0:I.ratio)||"1:1")+")",1)])])])):Lt("",!0),m("div",eg,[m("div",ig,[m("div",ng,[m("div",og,[ct(gt,{name:"presenter"}),S[27]||(S[27]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),S[28]||(S[28]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:S[2]||(S[2]=P=>x.$emit("toggleNote"))},null,40,rg),S[29]||(S[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,sg)])]),t.isImage||t.imageRole?(tt(),nt("div",lg,[m("div",ag,[m("div",cg,[m("div",dg,[ct(gt,{name:"image"}),S[30]||(S[30]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),S[31]||(S[31]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",ug,[m("button",{class:It(["spm-chip",{active:!t.imageRole}]),onClick:S[3]||(S[3]=P=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:It(["spm-chip",{active:t.imageRole==="background"}]),onClick:S[4]||(S[4]=P=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:It(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:S[5]||(S[5]=P=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:It(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:S[6]||(S[6]=P=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Lt("",!0),t.isVideo?(tt(),nt("div",fg,[m("div",pg,[m("div",hg,[m("div",mg,[ct(gt,{name:"video"}),S[32]||(S[32]=m("span",null,"视频播放设置 (Video Playback)",-1))]),S[33]||(S[33]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",gg,[m("div",vg,[S[35]||(S[35]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:S[7]||(S[7]=P=>x.$emit("toggleVideoControls"))},null,40,yg),S[34]||(S[34]=m("span",{class:"spm-switch-slider"},null,-1))],8,bg)]),m("div",kg,[S[37]||(S[37]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:S[8]||(S[8]=P=>x.$emit("toggleVideoAutoplay"))},null,40,xg),S[36]||(S[36]=m("span",{class:"spm-switch-slider"},null,-1))],8,wg)]),m("div",_g,[S[39]||(S[39]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:S[9]||(S[9]=P=>x.$emit("toggleVideoLoop"))},null,40,Cg),S[38]||(S[38]=m("span",{class:"spm-switch-slider"},null,-1))],8,Sg)]),m("div",$g,[S[41]||(S[41]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:S[10]||(S[10]=P=>x.$emit("toggleVideoMuted"))},null,40,Ag),S[40]||(S[40]=m("span",{class:"spm-switch-slider"},null,-1))],8,Ig)])])])):Lt("",!0),m("div",Tg,[m("div",Bg,[m("div",Eg,[m("div",Mg,[ct(gt,{name:"step"}),S[42]||(S[42]=m("span",null,"逐步呈现 (v-click)",-1))]),S[43]||(S[43]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:S[11]||(S[11]=P=>x.$emit("toggleElemClick"))},null,40,Lg),S[44]||(S[44]=m("span",{class:"spm-switch-slider"},null,-1))],8,Dg)]),t.elemClick?(tt(),nt("div",Pg,[(tt(),nt(Kt,null,ye(["+1","1","2","hide"],P=>m("button",{key:P,class:It(["spm-chip",{active:t.elemClick===P}]),onClick:v=>x.$emit("update:elemClick",P)},xt(P==="+1"?"顺延 (+1)":P==="hide"?"隐藏 (hide)":"第 "+P+" 步"),11,Rg)),64))])):Lt("",!0)]),m("div",Og,[m("div",zg,[m("div",Ng,[m("div",Fg,[ct(gt,{name:"motion"}),S[45]||(S[45]=m("span",null,"入场微动效 (v-motion)",-1))]),S[46]||(S[46]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:k},null,40,Hg),S[47]||(S[47]=m("span",{class:"spm-switch-slider"},null,-1))],8,jg)]),g.value?(tt(),nt("div",Ug,[(tt(),nt(Kt,null,ye(d,P=>m("button",{key:P.value,class:It(["spm-chip",{active:f.value===P.value}]),onClick:v=>b(P.value)},xt(P.label),11,Wg)),64))])):Lt("",!0),g.value?(tt(),nt("div",Vg,[m("div",Kg,[m("span",null,"时长: "+xt(y.value?y.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+xt(h.value?h.value+"ms":"0ms"),1)]),m("div",qg,[m("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:S[12]||(S[12]=P=>w(Number(P.target.value)))},[...S[48]||(S[48]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Gg),m("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:S[13]||(S[13]=P=>_(Number(P.target.value)))},[...S[49]||(S[49]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Zg)])])):Lt("",!0)]),o.value||t.elemSlot?(tt(),nt("div",Yg,[m("div",Jg,[m("div",Xg,[m("div",Qg,[ct(gt,{name:"columns"}),m("span",null,xt(r.value),1)]),m("span",tv,xt(l.value),1)])]),m("div",ev,[(tt(!0),nt(Kt,null,ye(s.value,P=>(tt(),nt("button",{key:P.value,class:It(["spm-segmented-item",{active:a(P.value)}]),onClick:v=>x.$emit("update:elemSlot",P.value)},xt(P.label),11,iv))),128))])])):Lt("",!0),t.isCodeBlock?(tt(),nt("div",nv,[m("div",ov,[m("div",sv,[m("div",rv,[ct(gt,{name:"code"}),S[50]||(S[50]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),S[51]||(S[51]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",lv,[(tt(),nt(Kt,null,ye(["1-3","all","1|2|3","2-5"],P=>m("button",{key:P,class:It(["spm-chip",{active:t.elemShikiLines===P}]),onClick:v=>x.$emit("update:elemShikiLines",P)},xt(P),11,av)),64)),t.elemShikiLines?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:S[14]||(S[14]=P=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Lt("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:S[15]||(S[15]=P=>x.$emit("update:elemShikiLines",P.target.value)),onChange:S[16]||(S[16]=P=>x.$emit("update:elemShikiLines",P.target.value))},null,40,cv)])):Lt("",!0),t.isCodeBlock?(tt(),nt("div",dv,[m("div",uv,[m("div",fv,[m("div",pv,[ct(gt,{name:"code"}),S[52]||(S[52]=m("span",null,"代码块限高 (Max Height)",-1))]),S[53]||(S[53]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",hv,[(tt(),nt(Kt,null,ye(["240px","320px","400px","50vh"],P=>m("button",{key:P,class:It(["spm-chip",{active:t.elemMaxHeight===P}]),onClick:v=>x.$emit("update:elemMaxHeight",P)},xt(P),11,mv)),64)),t.elemMaxHeight?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:S[17]||(S[17]=P=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Lt("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:S[18]||(S[18]=P=>x.$emit("update:elemMaxHeight",P.target.value)),onChange:S[19]||(S[19]=P=>x.$emit("update:elemMaxHeight",P.target.value))},null,40,gv)])):Lt("",!0),m("div",vv,[S[57]||(S[57]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",bv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:S[20]||(S[20]=P=>x.$emit("insertDividerBefore"))},[ct(gt,{name:"insert-above"}),S[54]||(S[54]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:S[21]||(S[21]=P=>x.$emit("insertDividerAfter"))},[ct(gt,{name:"insert-below"}),S[55]||(S[55]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:S[22]||(S[22]=P=>x.$emit("setTwoColsContrast"))},[ct(gt,{name:"columns"}),m("span",null,xt(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,yv),t.hasBlockAttrs?(tt(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:S[23]||(S[23]=P=>x.$emit("clearBlockAttrs"))},[ct(gt,{name:"broom"}),S[56]||(S[56]=m("span",null,"清除属性",-1))])):Lt("",!0)])])])}}}),wv={class:"spm-section spm-section--doc"},xv={class:"spm-card-control"},_v={class:"spm-control-header"},Sv={class:"spm-control-title-group"},Cv={class:"spm-control-title"},$v={class:"spm-segmented-group"},Iv=["aria-label","onClick"],Av={class:"spm-card-control"},Tv={class:"spm-control-header"},Bv={class:"spm-control-title-group"},Ev={class:"spm-control-title"},Mv={class:"spm-segmented-group"},Dv={class:"spm-card-control"},Lv={class:"spm-control-header"},Pv={class:"spm-control-title-group"},Rv={class:"spm-control-title"},Ov={class:"spm-segmented-group"},zv={class:"spm-card-control"},Nv={class:"spm-control-header"},Fv={class:"spm-control-title-group"},jv={class:"spm-control-title"},Hv={class:"spm-card-control"},Uv={class:"spm-control-header"},Wv={class:"spm-control-title-group"},Vv={class:"spm-control-title"},Kv=["aria-label"],qv=["checked"],Gv={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Zv=["value"],Yv={class:"spm-card-control"},Jv={class:"spm-action-grid"},Xv=xe({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ti("plugin"),e=Ti,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(s){Gi({enableWebServeJump:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:s})}function r(s){Gi({webServeUrl:s})}function l(s){Gi({webServeUrl:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:s})}return(s,a)=>(tt(),nt("div",wv,[a[35]||(a[35]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",xv,[m("div",_v,[m("div",Sv,[m("div",Cv,[ct(gt,{name:"palette"}),a[17]||(a[17]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",$v,[(tt(),nt(Kt,null,ye(n,c=>m("button",{key:c.value,class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>s.$emit("update:docTheme",c.value)},xt(c.label),11,Iv)),64))])]),m("div",Av,[m("div",Tv,[m("div",Bv,[m("div",Ev,[ct(gt,{name:"ratio"}),a[19]||(a[19]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Mv,[m("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>s.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>s.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>s.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Dv,[m("div",Lv,[m("div",Pv,[m("div",Rv,[ct(gt,{name:"ratio"}),a[21]||(a[21]=m("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",Ov,[m("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>s.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>s.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>s.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",zv,[m("div",Nv,[m("div",Fv,[m("div",jv,[ct(gt,{name:"transition"}),a[23]||(a[23]=m("span",null,"全局默认转场",-1))]),a[24]||(a[24]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ct(Ps,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>s.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Hv,[m("div",Uv,[m("div",Wv,[m("div",Vv,[ct(gt,{name:"external-link"}),a[25]||(a[25]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ht(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:ht(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>o(c.target.checked))},null,40,qv),a[27]||(a[27]=m("span",{class:"spm-switch-slider"},null,-1))],8,Kv)]),ht(e).enableWebServeJump?(tt(),nt("div",Gv,[m("input",{value:ht(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Ee(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Ee(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>r(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,Zv),a[28]||(a[28]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Lt("",!0)]),m("div",Yv,[a[34]||(a[34]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",Jv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>s.$emit("openBottomPreview"))},[ct(gt,{name:"split-preview"}),a[29]||(a[29]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>s.$emit("openPresenter"))},[ct(gt,{name:"presenter"}),a[30]||(a[30]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>s.$emit("aiAutoSplit"))},[ct(gt,{name:"sparkles"}),a[31]||(a[31]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>s.$emit("exportHtml"))},[ct(gt,{name:"export-html"}),a[32]||(a[32]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>s.$emit("exportPdf"))},[ct(gt,{name:"export-pdf"}),a[33]||(a[33]=m("span",null,"导出 PDF",-1))])])])]))}});var Wn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Qv(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Vn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Wo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var $r;function tb(){return $r||($r=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,r){function l(c,d){if(!o[c]){if(!n[c]){var u=typeof Vn=="function"&&Vn;if(!d&&u)return u(c,!0);if(s)return s(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var f=o[c]={exports:{}};n[c][0].call(f.exports,function(y){var h=n[c][1][y];return l(h||y)},f,f.exports,e,n,o,r)}return o[c].exports}for(var s=typeof Vn=="function"&&Vn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,n,o){var r=e("./utils"),l=e("./support"),s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,u,g,f,y,h,k=[],b=0,w=a.length,_=w,T=r.getTypeOf(a)!=="string";b<a.length;)_=w-b,u=T?(c=a[b++],d=b<w?a[b++]:0,b<w?a[b++]:0):(c=a.charCodeAt(b++),d=b<w?a.charCodeAt(b++):0,b<w?a.charCodeAt(b++):0),g=c>>2,f=(3&c)<<4|d>>4,y=1<_?(15&d)<<2|u>>6:64,h=2<_?63&u:64,k.push(s.charAt(g)+s.charAt(f)+s.charAt(y)+s.charAt(h));return k.join("")},o.decode=function(a){var c,d,u,g,f,y,h=0,k=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var w,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===s.charAt(64)&&_--,a.charAt(a.length-2)===s.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=l.uint8array?new Uint8Array(0|_):new Array(0|_);h<a.length;)c=s.indexOf(a.charAt(h++))<<2|(g=s.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(f=s.indexOf(a.charAt(h++)))>>2,u=(3&f)<<6|(y=s.indexOf(a.charAt(h++))),w[k++]=c,f!==64&&(w[k++]=d),y!==64&&(w[k++]=u);return w}},{"./support":30,"./utils":32}],2:[function(e,n,o){var r=e("./external"),l=e("./stream/DataWorker"),s=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,u,g,f,y){this.compressedSize=d,this.uncompressedSize=u,this.crc32=g,this.compression=f,this.compressedContent=y}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),u=this;return d.on("end",function(){if(this.streamInfo.data_length!==u.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,u,g){return d.pipe(new s).pipe(new a("uncompressedSize")).pipe(u.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",u)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var r=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var r=e("./utils"),l=(function(){for(var s,a=[],c=0;c<256;c++){s=c;for(var d=0;d<8;d++)s=1&s?3988292384^s>>>1:s>>>1;a[c]=s}return a})();n.exports=function(s,a){return s!==void 0&&s.length?r.getTypeOf(s)!=="string"?(function(c,d,u,g){var f=l,y=g+u;c^=-1;for(var h=g;h<y;h++)c=c>>>8^f[255&(c^d[h])];return-1^c})(0|a,s,s.length,0):(function(c,d,u,g){var f=l,y=g+u;c^=-1;for(var h=g;h<y;h++)c=c>>>8^f[255&(c^d.charCodeAt(h))];return-1^c})(0|a,s,s.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var r=null;r=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:r}},{lie:37}],7:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),s=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(u,g){a.call(this,"FlateWorker/"+u),this._pako=null,this._pakoAction=u,this._pakoOptions=g,this.meta={}}o.magic="\b\0",s.inherits(d,a),d.prototype.processChunk=function(u){this.meta=u.meta,this._pako===null&&this._createPako(),this._pako.push(s.transformTo(c,u.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var u=this;this._pako.onData=function(g){u.push({data:g,meta:u.meta})}},o.compressWorker=function(u){return new d("Deflate",u)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function r(f,y){var h,k="";for(h=0;h<y;h++)k+=String.fromCharCode(255&f),f>>>=8;return k}function l(f,y,h,k,b,w){var _,T,x=f.file,S=f.compression,B=w!==c.utf8encode,D=s.transformTo("string",w(x.name)),M=s.transformTo("string",c.utf8encode(x.name)),O=x.comment,Z=s.transformTo("string",w(O)),I=s.transformTo("string",c.utf8encode(O)),P=M.length!==x.name.length,v=I.length!==O.length,G="",A="",E="",j=x.dir,N=x.date,J={crc32:0,compressedSize:0,uncompressedSize:0};y&&!h||(J.crc32=f.crc32,J.compressedSize=f.compressedSize,J.uncompressedSize=f.uncompressedSize);var H=0;y&&(H|=8),B||!P&&!v||(H|=2048);var K=0,rt=0;j&&(K|=16),b==="UNIX"?(rt=798,K|=(function(st,Q){var pt=st;return st||(pt=Q?16893:33204),(65535&pt)<<16})(x.unixPermissions,j)):(rt=20,K|=(function(st){return 63&(st||0)})(x.dosPermissions)),_=N.getUTCHours(),_<<=6,_|=N.getUTCMinutes(),_<<=5,_|=N.getUTCSeconds()/2,T=N.getUTCFullYear()-1980,T<<=4,T|=N.getUTCMonth()+1,T<<=5,T|=N.getUTCDate(),P&&(A=r(1,1)+r(d(D),4)+M,G+="up"+r(A.length,2)+A),v&&(E=r(1,1)+r(d(Z),4)+I,G+="uc"+r(E.length,2)+E);var lt="";return lt+=`
\0`,lt+=r(H,2),lt+=S.magic,lt+=r(_,2),lt+=r(T,2),lt+=r(J.crc32,4),lt+=r(J.compressedSize,4),lt+=r(J.uncompressedSize,4),lt+=r(D.length,2),lt+=r(G.length,2),{fileRecord:u.LOCAL_FILE_HEADER+lt+D+G,dirRecord:u.CENTRAL_FILE_HEADER+r(rt,2)+lt+r(Z.length,2)+"\0\0\0\0"+r(K,4)+r(k,4)+D+G+Z}}var s=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),u=e("../signature");function g(f,y,h,k){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=y,this.zipPlatform=h,this.encodeFileName=k,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}s.inherits(g,a),g.prototype.push=function(f){var y=f.meta.percent||0,h=this.entriesCount,k=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,a.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:h?(y+100*(h-k-1))/h:100}}))},g.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var y=this.streamFiles&&!f.file.dir;if(y){var h=l(f,y,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(f){this.accumulate=!1;var y=this.streamFiles&&!f.file.dir,h=l(f,y,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),y)this.push({data:(function(k){return u.DATA_DESCRIPTOR+r(k.crc32,4)+r(k.compressedSize,4)+r(k.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var f=this.bytesWritten,y=0;y<this.dirRecords.length;y++)this.push({data:this.dirRecords[y],meta:{percent:100}});var h=this.bytesWritten-f,k=(function(b,w,_,T,x){var S=s.transformTo("string",x(T));return u.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(b,2)+r(b,2)+r(w,4)+r(_,4)+r(S.length,2)+S})(this.dirRecords.length,h,f,this.zipComment,this.encodeFileName);this.push({data:k,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(f){this._sources.push(f);var y=this;return f.on("data",function(h){y.processChunk(h)}),f.on("end",function(){y.closedSource(y.previous.streamInfo),y._sources.length?y.prepareNextSource():y.end()}),f.on("error",function(h){y.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(f){var y=this._sources;if(!a.prototype.error.call(this,f))return!1;for(var h=0;h<y.length;h++)try{y[h].error(f)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var f=this._sources,y=0;y<f.length;y++)f[y].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var r=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(s,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),u=0;try{s.forEach(function(g,f){u++;var y=(function(w,_){var T=w||_,x=r[T];if(!x)throw new Error(T+" is not a valid compression method !");return x})(f.options.compression,a.compression),h=f.options.compressionOptions||a.compressionOptions||{},k=f.dir,b=f.date;f._compressWorker(y,h).withStreamInfo("file",{name:g,dir:k,date:b,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(d)}),d.entriesCount=u}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var s in this)typeof this[s]!="function"&&(l[s]=this[s]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,s){return new r().loadAsync(l,s)},r.external=e("./external"),n.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var r=e("./utils"),l=e("./external"),s=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function u(g){return new l.Promise(function(f,y){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(k){y(k)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?y(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(g,f){var y=this;return f=r.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:s.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,f.optimizedBinaryString,f.base64).then(function(h){var k=new a(f);return k.load(h),k}).then(function(h){var k=[l.Promise.resolve(h)],b=h.files;if(f.checkCRC32)for(var w=0;w<b.length;w++)k.push(u(b[w]));return l.Promise.all(k)}).then(function(h){for(var k=h.shift(),b=k.files,w=0;w<b.length;w++){var _=b[w],T=_.fileNameStr,x=r.resolve(_.fileNameStr);y.file(x,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:f.createFolders}),_.dir||(y.file(x).unsafeOriginalName=T)}return k.zipComment.length&&(y.comment=k.zipComment),y})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var r=e("../utils"),l=e("../stream/GenericWorker");function s(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(s,l),s.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},s.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=s},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var r=e("readable-stream").Readable;function l(s,a,c){r.call(this,a),this._helper=s;var d=this;s.on("data",function(u,g){d.push(u)||d._helper.pause(),c&&c(g)}).on("error",function(u){d.emit("error",u)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,n,o){function r(x,S,B){var D,M=s.getTypeOf(S),O=s.extend(B||{},d);O.date=O.date||new Date,O.compression!==null&&(O.compression=O.compression.toUpperCase()),typeof O.unixPermissions=="string"&&(O.unixPermissions=parseInt(O.unixPermissions,8)),O.unixPermissions&&16384&O.unixPermissions&&(O.dir=!0),O.dosPermissions&&16&O.dosPermissions&&(O.dir=!0),O.dir&&(x=b(x)),O.createFolders&&(D=k(x))&&w.call(this,D,!0);var Z=M==="string"&&O.binary===!1&&O.base64===!1;B&&B.binary!==void 0||(O.binary=!Z),(S instanceof u&&S.uncompressedSize===0||O.dir||!S||S.length===0)&&(O.base64=!1,O.binary=!0,S="",O.compression="STORE",M="string");var I=null;I=S instanceof u||S instanceof a?S:y.isNode&&y.isStream(S)?new h(x,S):s.prepareContent(x,S,O.binary,O.optimizedBinaryString,O.base64);var P=new g(x,I,O);this.files[x]=P}var l=e("./utf8"),s=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),u=e("./compressedObject"),g=e("./zipObject"),f=e("./generate"),y=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),k=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var S=x.lastIndexOf("/");return 0<S?x.substring(0,S):""},b=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},w=function(x,S){return S=S!==void 0?S:d.createFolders,x=b(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:S}),this.files[x]};function _(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var S,B,D;for(S in this.files)D=this.files[S],(B=S.slice(this.root.length,S.length))&&S.slice(0,this.root.length)===this.root&&x(B,D)},filter:function(x){var S=[];return this.forEach(function(B,D){x(B,D)&&S.push(D)}),S},file:function(x,S,B){if(arguments.length!==1)return x=this.root+x,r.call(this,x,S,B),this;if(_(x)){var D=x;return this.filter(function(O,Z){return!Z.dir&&D.test(O)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if(_(x))return this.filter(function(M,O){return O.dir&&x.test(M)});var S=this.root+x,B=w.call(this,S),D=this.clone();return D.root=B.name,D},remove:function(x){x=this.root+x;var S=this.files[x];if(S||(x.slice(-1)!=="/"&&(x+="/"),S=this.files[x]),S&&!S.dir)delete this.files[x];else for(var B=this.filter(function(M,O){return O.name.slice(0,x.length)===x}),D=0;D<B.length;D++)delete this.files[B[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var S,B={};try{if((B=s.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=B.type.toLowerCase(),B.compression=B.compression.toUpperCase(),B.type==="binarystring"&&(B.type="string"),!B.type)throw new Error("No output type specified.");s.checkSupport(B.type),B.platform!=="darwin"&&B.platform!=="freebsd"&&B.platform!=="linux"&&B.platform!=="sunos"||(B.platform="UNIX"),B.platform==="win32"&&(B.platform="DOS");var D=B.comment||this.comment||"";S=f.generateWorker(this,B,D)}catch(M){(S=new a("error")).error(M)}return new c(S,B.type||"string",B.mimeType)},generateAsync:function(x,S){return this.generateInternalStream(x).accumulate(S)},generateNodeStream:function(x,S){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(S)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s);for(var a=0;a<this.data.length;a++)s[a]=255&s[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data[this.zero+s]},l.prototype.lastIndexOfSignature=function(s){for(var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),u=s.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===u)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(s){var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),u=s.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&u===g[3]},l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var r=e("../utils");function l(s){this.data=s,this.length=s.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(s){this.checkIndex(this.index+s)},checkIndex:function(s){if(this.length<this.zero+s||s<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+s+"). Corrupted zip ?")},setIndex:function(s){this.checkIndex(s),this.index=s},skip:function(s){this.setIndex(this.index+s)},byteAt:function(){},readInt:function(s){var a,c=0;for(this.checkOffset(s),a=this.index+s-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=s,c},readString:function(s){return r.transformTo("string",this.readData(s))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var s=this.readInt(4);return new Date(Date.UTC(1980+(s>>25&127),(s>>21&15)-1,s>>16&31,s>>11&31,s>>5&63,(31&s)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var r=e("./Uint8ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data.charCodeAt(this.zero+s)},l.prototype.lastIndexOfSignature=function(s){return this.data.lastIndexOf(s)-this.zero},l.prototype.readAndCheckSignature=function(s){return s===this.readData(4)},l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var r=e("./ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var r=e("../utils"),l=e("../support"),s=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(u){var g=r.getTypeOf(u);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(u):l.uint8array?new d(r.transformTo("uint8array",u)):new s(r.transformTo("array",u)):new a(u)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var r=e("./GenericWorker"),l=e("../utils");function s(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(s,r),s.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=s},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var r=e("./GenericWorker"),l=e("../crc32");function s(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(s,r),s.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=s},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(s,l),s.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=s},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(s,l),s.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},s.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},s.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=s},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,s){return this._listeners[l].push(s),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,s){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,s)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var s=this;return l.on("data",function(a){s.processChunk(a)}),l.on("end",function(){s.end()}),l.on("error",function(a){s.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,s){return this.extraStreamInfo[l]=s,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=r},{}],29:[function(e,n,o){var r=e("../utils"),l=e("./ConvertWorker"),s=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),u=null;if(c.nodestream)try{u=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(y,h){return new d.Promise(function(k,b){var w=[],_=y._internalType,T=y._outputType,x=y._mimeType;y.on("data",function(S,B){w.push(S),h&&h(B)}).on("error",function(S){w=[],b(S)}).on("end",function(){try{var S=(function(B,D,M){switch(B){case"blob":return r.newBlob(r.transformTo("arraybuffer",D),M);case"base64":return a.encode(D);default:return r.transformTo(B,D)}})(T,(function(B,D){var M,O=0,Z=null,I=0;for(M=0;M<D.length;M++)I+=D[M].length;switch(B){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(Z=new Uint8Array(I),M=0;M<D.length;M++)Z.set(D[M],O),O+=D[M].length;return Z;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+B+"'")}})(_,w),x);k(S)}catch(B){b(B)}w=[]}).resume()})}function f(y,h,k){var b=h;switch(h){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=h,this._mimeType=k,r.checkSupport(b),this._worker=y.pipe(new l(b)),y.lock()}catch(w){this._worker=new s("error"),this._worker.error(w)}}f.prototype={accumulate:function(y){return g(this,y)},on:function(y,h){var k=this;return y==="data"?this._worker.on(y,function(b){h.call(k,b.data,b.meta)}):this._worker.on(y,function(){r.delay(h,arguments,k)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(y){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new u(this,{objectMode:this._outputType!=="nodebuffer"},y)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var r=new ArrayBuffer(0);try{o.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var r=e("./utils"),l=e("./support"),s=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function u(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(f){return l.nodebuffer?s.newBufferFrom(f,"utf-8"):(function(y){var h,k,b,w,_,T=y.length,x=0;for(w=0;w<T;w++)(64512&(k=y.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=y.charCodeAt(w+1)))==56320&&(k=65536+(k-55296<<10)+(b-56320),w++),x+=k<128?1:k<2048?2:k<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),w=_=0;_<x;w++)(64512&(k=y.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=y.charCodeAt(w+1)))==56320&&(k=65536+(k-55296<<10)+(b-56320),w++),k<128?h[_++]=k:(k<2048?h[_++]=192|k>>>6:(k<65536?h[_++]=224|k>>>12:(h[_++]=240|k>>>18,h[_++]=128|k>>>12&63),h[_++]=128|k>>>6&63),h[_++]=128|63&k);return h})(f)},o.utf8decode=function(f){return l.nodebuffer?r.transformTo("nodebuffer",f).toString("utf-8"):(function(y){var h,k,b,w,_=y.length,T=new Array(2*_);for(h=k=0;h<_;)if((b=y[h++])<128)T[k++]=b;else if(4<(w=c[b]))T[k++]=65533,h+=w-1;else{for(b&=w===2?31:w===3?15:7;1<w&&h<_;)b=b<<6|63&y[h++],w--;1<w?T[k++]=65533:b<65536?T[k++]=b:(b-=65536,T[k++]=55296|b>>10&1023,T[k++]=56320|1023&b)}return T.length!==k&&(T.subarray?T=T.subarray(0,k):T.length=k),r.applyFromCharCode(T)})(f=r.transformTo(l.uint8array?"uint8array":"array",f))},r.inherits(u,a),u.prototype.processChunk=function(f){var y=r.transformTo(l.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=y;(y=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),y.set(h,this.leftOver.length)}else y=this.leftOver.concat(y);this.leftOver=null}var k=(function(w,_){var T;for((_=_||w.length)>w.length&&(_=w.length),T=_-1;0<=T&&(192&w[T])==128;)T--;return T<0||T===0?_:T+c[w[T]]>_?T:_})(y),b=y;k!==y.length&&(l.uint8array?(b=y.subarray(0,k),this.leftOver=y.subarray(k,y.length)):(b=y.slice(0,k),this.leftOver=y.slice(k,y.length))),this.push({data:o.utf8decode(b),meta:f.meta})},u.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=u,r.inherits(g,a),g.prototype.processChunk=function(f){this.push({data:o.utf8encode(f.data),meta:f.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var r=e("./support"),l=e("./base64"),s=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,k){for(var b=0;b<h.length;++b)k[b]=255&h.charCodeAt(b);return k}e("setimmediate"),o.newBlob=function(h,k){o.checkSupport("blob");try{return new Blob([h],{type:k})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(h),b.getBlob(k)}catch{throw new Error("Bug : can't construct the Blob.")}}};var u={stringifyByChunk:function(h,k,b){var w=[],_=0,T=h.length;if(T<=b)return String.fromCharCode.apply(null,h);for(;_<T;)k==="array"||k==="nodebuffer"?w.push(String.fromCharCode.apply(null,h.slice(_,Math.min(_+b,T)))):w.push(String.fromCharCode.apply(null,h.subarray(_,Math.min(_+b,T)))),_+=b;return w.join("")},stringifyByChar:function(h){for(var k="",b=0;b<h.length;b++)k+=String.fromCharCode(h[b]);return k},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,s.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var k=65536,b=o.getTypeOf(h),w=!0;if(b==="uint8array"?w=u.applyCanBeUsed.uint8array:b==="nodebuffer"&&(w=u.applyCanBeUsed.nodebuffer),w)for(;1<k;)try{return u.stringifyByChunk(h,b,k)}catch{k=Math.floor(k/2)}return u.stringifyByChar(h)}function f(h,k){for(var b=0;b<h.length;b++)k[b]=h[b];return k}o.applyFromCharCode=g;var y={};y.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return y.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,s.allocBuffer(h.length))}},y.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(h)}},y.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return f(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(new Uint8Array(h))}},y.uint8array={string:g,array:function(h){return f(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return s.newBufferFrom(h)}},y.nodebuffer={string:g,array:function(h){return f(h,new Array(h.length))},arraybuffer:function(h){return y.nodebuffer.uint8array(h).buffer},uint8array:function(h){return f(h,new Uint8Array(h.length))},nodebuffer:c},o.transformTo=function(h,k){if(k=k||"",!h)return k;o.checkSupport(h);var b=o.getTypeOf(k);return y[b][h](k)},o.resolve=function(h){for(var k=h.split("/"),b=[],w=0;w<k.length;w++){var _=k[w];_==="."||_===""&&w!==0&&w!==k.length-1||(_===".."?b.pop():b.push(_))}return b.join("/")},o.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&s.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(h){var k,b,w="";for(b=0;b<(h||"").length;b++)w+="\\x"+((k=h.charCodeAt(b))<16?"0":"")+k.toString(16).toUpperCase();return w},o.delay=function(h,k,b){setImmediate(function(){h.apply(b||null,k||[])})},o.inherits=function(h,k){function b(){}b.prototype=k.prototype,h.prototype=new b},o.extend=function(){var h,k,b={};for(h=0;h<arguments.length;h++)for(k in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],k)&&b[k]===void 0&&(b[k]=arguments[h][k]);return b},o.prepareContent=function(h,k,b,w,_){return a.Promise.resolve(k).then(function(T){return r.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,S){var B=new FileReader;B.onload=function(D){x(D.target.result)},B.onerror=function(D){S(D.target.error)},B.readAsArrayBuffer(T)}):T}).then(function(T){var x=o.getTypeOf(T);return x?(x==="arraybuffer"?T=o.transformTo("uint8array",T):x==="string"&&(_?T=l.decode(T):b&&w!==!0&&(T=(function(S){return d(S,r.uint8array?new Uint8Array(S.length):new Array(S.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(u){this.files=[],this.loadOptions=u}d.prototype={checkSignature:function(u){if(!this.reader.readAndCheckSignature(u)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(u)+")")}},isSignature:function(u,g){var f=this.reader.index;this.reader.setIndex(u);var y=this.reader.readString(4)===g;return this.reader.setIndex(f),y},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var u=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",f=l.transformTo(g,u);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var u,g,f,y=this.zip64EndOfCentralSize-44;0<y;)u=this.reader.readInt(2),g=this.reader.readInt(4),f=this.reader.readData(g),this.zip64ExtensibleData[u]={id:u,length:g,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var u,g;for(u=0;u<this.files.length;u++)g=this.files[u],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(s.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var u;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);)(u=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(u);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var u=this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);if(u<0)throw this.isSignature(0,s.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(u);var g=u;if(this.checkSignature(s.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(u=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(u),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,s.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var y=g-f;if(0<y)this.isSignature(g,s.CENTRAL_FILE_HEADER)||(this.reader.zero=y);else if(y<0)throw new Error("Corrupted zip: missing "+Math.abs(y)+" bytes.")},prepareReader:function(u){this.reader=r(u)},load:function(u){this.prepareReader(u),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),u=e("./support");function g(f,y){this.options=f,this.loadOptions=y}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var y,h;if(f.skip(22),this.fileNameLength=f.readInt(2),h=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((y=(function(k){for(var b in d)if(Object.prototype.hasOwnProperty.call(d,b)&&d[b].magic===k)return d[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new s(this.compressedSize,this.uncompressedSize,this.crc32,y,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var y=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(y),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var y,h,k,b=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<b;)y=f.readInt(2),h=f.readInt(2),k=f.readData(h),this.extraFields[y]={id:y,length:h,value:k};f.setIndex(b)},handleUTF8:function(){var f=u.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var y=this.findExtraFieldUnicodePath();if(y!==null)this.fileNameStr=y;else{var h=l.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var k=this.findExtraFieldUnicodeComment();if(k!==null)this.fileCommentStr=k;else{var b=l.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var y=r(f.value);return y.readInt(1)!==1||a(this.fileName)!==y.readInt(4)?null:c.utf8decode(y.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var y=r(f.value);return y.readInt(1)!==1||a(this.fileComment)!==y.readInt(4)?null:c.utf8decode(y.readData(f.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function r(y,h,k){this.name=y,this.dir=k.dir,this.date=k.date,this.comment=k.comment,this.unixPermissions=k.unixPermissions,this.dosPermissions=k.dosPermissions,this._data=h,this._dataBinary=k.binary,this.options={compression:k.compression,compressionOptions:k.compressionOptions}}var l=e("./stream/StreamHelper"),s=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(y){var h=null,k="string";try{if(!y)throw new Error("No output type specified.");var b=(k=y.toLowerCase())==="string"||k==="text";k!=="binarystring"&&k!=="text"||(k="string"),h=this._decompressWorker();var w=!this._dataBinary;w&&!b&&(h=h.pipe(new a.Utf8EncodeWorker)),!w&&b&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(_){(h=new d("error")).error(_)}return new l(h,k,"")},async:function(y,h){return this.internalStream(y).accumulate(h)},nodeStream:function(y,h){return this.internalStream(y||"nodebuffer").toNodejsStream(h)},_compressWorker:function(y,h){if(this._data instanceof c&&this._data.compression.magic===y.magic)return this._data.getCompressedWorker();var k=this._decompressWorker();return this._dataBinary||(k=k.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(k,y,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new s(this._data)}};for(var u=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<u.length;f++)r.prototype[u[f]]=g;n.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(r){var l,s,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(y),u=r.document.createTextNode("");d.observe(u,{characterData:!0}),l=function(){u.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){y(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(y,0)};else{var g=new r.MessageChannel;g.port1.onmessage=y,l=function(){g.port2.postMessage(0)}}var f=[];function y(){var h,k;s=!0;for(var b=f.length;b;){for(k=f,f=[],h=-1;++h<b;)k[h]();b=f.length}s=!1}n.exports=function(h){f.push(h)!==1||s||l()}}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var r=e("immediate");function l(){}var s={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function u(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,b!==l&&h(this,b)}function g(b,w,_){this.promise=b,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function f(b,w,_){r(function(){var T;try{T=w(_)}catch(x){return s.reject(b,x)}T===b?s.reject(b,new TypeError("Cannot resolve promise with itself")):s.resolve(b,T)})}function y(b){var w=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof w=="function")return function(){w.apply(b,arguments)}}function h(b,w){var _=!1;function T(B){_||(_=!0,s.reject(b,B))}function x(B){_||(_=!0,s.resolve(b,B))}var S=k(function(){w(x,T)});S.status==="error"&&T(S.value)}function k(b,w){var _={};try{_.value=b(w),_.status="success"}catch(T){_.status="error",_.value=T}return _}(n.exports=u).prototype.finally=function(b){if(typeof b!="function")return this;var w=this.constructor;return this.then(function(_){return w.resolve(b()).then(function(){return _})},function(_){return w.resolve(b()).then(function(){throw _})})},u.prototype.catch=function(b){return this.then(null,b)},u.prototype.then=function(b,w){if(typeof b!="function"&&this.state===c||typeof w!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?f(_,this.state===c?b:w,this.outcome):this.queue.push(new g(_,b,w)),_},g.prototype.callFulfilled=function(b){s.resolve(this.promise,b)},g.prototype.otherCallFulfilled=function(b){f(this.promise,this.onFulfilled,b)},g.prototype.callRejected=function(b){s.reject(this.promise,b)},g.prototype.otherCallRejected=function(b){f(this.promise,this.onRejected,b)},s.resolve=function(b,w){var _=k(y,w);if(_.status==="error")return s.reject(b,_.value);var T=_.value;if(T)h(b,T);else{b.state=c,b.outcome=w;for(var x=-1,S=b.queue.length;++x<S;)b.queue[x].callFulfilled(w)}return b},s.reject=function(b,w){b.state=a,b.outcome=w;for(var _=-1,T=b.queue.length;++_<T;)b.queue[_].callRejected(w);return b},u.resolve=function(b){return b instanceof this?b:s.resolve(new this(l),b)},u.reject=function(b){var w=new this(l);return s.reject(w,b)},u.all=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=b.length,T=!1;if(!_)return this.resolve([]);for(var x=new Array(_),S=0,B=-1,D=new this(l);++B<_;)M(b[B],B);return D;function M(O,Z){w.resolve(O).then(function(I){x[Z]=I,++S!==_||T||(T=!0,s.resolve(D,x))},function(I){T||(T=!0,s.reject(D,I))})}},u.race=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=b.length,T=!1;if(!_)return this.resolve([]);for(var x=-1,S=new this(l);++x<_;)B=b[x],w.resolve(B).then(function(D){T||(T=!0,s.resolve(S,D))},function(D){T||(T=!0,s.reject(S,D))});var B;return S}},{immediate:36}],38:[function(e,n,o){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var r=e("./zlib/deflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,u=0,g=-1,f=0,y=8;function h(b){if(!(this instanceof h))return new h(b);this.options=l.assign({level:g,method:y,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},b||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=r.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if(_!==u)throw new Error(a[_]);if(w.header&&r.deflateSetHeader(this.strm,w.header),w.dictionary){var T;if(T=typeof w.dictionary=="string"?s.string2buf(w.dictionary):d.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,(_=r.deflateSetDictionary(this.strm,T))!==u)throw new Error(a[_]);this._dict_set=!0}}function k(b,w){var _=new h(w);if(_.push(b,!0),_.err)throw _.msg||a[_.err];return _.result}h.prototype.push=function(b,w){var _,T,x=this.strm,S=this.options.chunkSize;if(this.ended)return!1;T=w===~~w?w:w===!0?4:0,typeof b=="string"?x.input=s.string2buf(b):d.call(b)==="[object ArrayBuffer]"?x.input=new Uint8Array(b):x.input=b,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(S),x.next_out=0,x.avail_out=S),(_=r.deflate(x,T))!==1&&_!==u)return this.onEnd(_),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(s.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&_!==1);return T===4?(_=r.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===u):T!==2||(this.onEnd(u),!(x.avail_out=0))},h.prototype.onData=function(b){this.chunks.push(b)},h.prototype.onEnd=function(b){b===u&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},o.Deflate=h,o.deflate=k,o.deflateRaw=function(b,w){return(w=w||{}).raw=!0,k(b,w)},o.gzip=function(b,w){return(w=w||{}).gzip=!0,k(b,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var r=e("./zlib/inflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),u=e("./zlib/gzheader"),g=Object.prototype.toString;function f(h){if(!(this instanceof f))return new f(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var k=this.options;k.raw&&0<=k.windowBits&&k.windowBits<16&&(k.windowBits=-k.windowBits,k.windowBits===0&&(k.windowBits=-15)),!(0<=k.windowBits&&k.windowBits<16)||h&&h.windowBits||(k.windowBits+=32),15<k.windowBits&&k.windowBits<48&&(15&k.windowBits)==0&&(k.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var b=r.inflateInit2(this.strm,k.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new u,r.inflateGetHeader(this.strm,this.header)}function y(h,k){var b=new f(k);if(b.push(h,!0),b.err)throw b.msg||c[b.err];return b.result}f.prototype.push=function(h,k){var b,w,_,T,x,S,B=this.strm,D=this.options.chunkSize,M=this.options.dictionary,O=!1;if(this.ended)return!1;w=k===~~k?k:k===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?B.input=s.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?B.input=new Uint8Array(h):B.input=h,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new l.Buf8(D),B.next_out=0,B.avail_out=D),(b=r.inflate(B,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&(S=typeof M=="string"?s.string2buf(M):g.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,b=r.inflateSetDictionary(this.strm,S)),b===a.Z_BUF_ERROR&&O===!0&&(b=a.Z_OK,O=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);B.next_out&&(B.avail_out!==0&&b!==a.Z_STREAM_END&&(B.avail_in!==0||w!==a.Z_FINISH&&w!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=s.utf8border(B.output,B.next_out),T=B.next_out-_,x=s.buf2string(B.output,_),B.next_out=T,B.avail_out=D-T,T&&l.arraySet(B.output,B.output,_,T,0),this.onData(x)):this.onData(l.shrinkBuf(B.output,B.next_out)))),B.avail_in===0&&B.avail_out===0&&(O=!0)}while((0<B.avail_in||B.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(w=a.Z_FINISH),w===a.Z_FINISH?(b=r.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):w!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(B.avail_out=0))},f.prototype.onData=function(h){this.chunks.push(h)},f.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},o.Inflate=f,o.inflate=y,o.inflateRaw=function(h,k){return(k=k||{}).raw=!0,y(h,k)},o.ungzip=y},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var u in d)d.hasOwnProperty(u)&&(a[u]=d[u])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,u,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+u),g);else for(var f=0;f<u;f++)a[g+f]=c[d+f]},flattenChunks:function(a){var c,d,u,g,f,y;for(c=u=0,d=a.length;c<d;c++)u+=a[c].length;for(y=new Uint8Array(u),c=g=0,d=a.length;c<d;c++)f=a[c],y.set(f,g),g+=f.length;return y}},s={arraySet:function(a,c,d,u,g){for(var f=0;f<u;f++)a[g+f]=c[d+f]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,s))},o.setTyped(r)},{}],42:[function(e,n,o){var r=e("./common"),l=!0,s=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{s=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(u,g){if(g<65537&&(u.subarray&&s||!u.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(u,g));for(var f="",y=0;y<g;y++)f+=String.fromCharCode(u[y]);return f}a[254]=a[254]=1,o.string2buf=function(u){var g,f,y,h,k,b=u.length,w=0;for(h=0;h<b;h++)(64512&(f=u.charCodeAt(h)))==55296&&h+1<b&&(64512&(y=u.charCodeAt(h+1)))==56320&&(f=65536+(f-55296<<10)+(y-56320),h++),w+=f<128?1:f<2048?2:f<65536?3:4;for(g=new r.Buf8(w),h=k=0;k<w;h++)(64512&(f=u.charCodeAt(h)))==55296&&h+1<b&&(64512&(y=u.charCodeAt(h+1)))==56320&&(f=65536+(f-55296<<10)+(y-56320),h++),f<128?g[k++]=f:(f<2048?g[k++]=192|f>>>6:(f<65536?g[k++]=224|f>>>12:(g[k++]=240|f>>>18,g[k++]=128|f>>>12&63),g[k++]=128|f>>>6&63),g[k++]=128|63&f);return g},o.buf2binstring=function(u){return d(u,u.length)},o.binstring2buf=function(u){for(var g=new r.Buf8(u.length),f=0,y=g.length;f<y;f++)g[f]=u.charCodeAt(f);return g},o.buf2string=function(u,g){var f,y,h,k,b=g||u.length,w=new Array(2*b);for(f=y=0;f<b;)if((h=u[f++])<128)w[y++]=h;else if(4<(k=a[h]))w[y++]=65533,f+=k-1;else{for(h&=k===2?31:k===3?15:7;1<k&&f<b;)h=h<<6|63&u[f++],k--;1<k?w[y++]=65533:h<65536?w[y++]=h:(h-=65536,w[y++]=55296|h>>10&1023,w[y++]=56320|1023&h)}return d(w,y)},o.utf8border=function(u,g){var f;for((g=g||u.length)>u.length&&(g=u.length),f=g-1;0<=f&&(192&u[f])==128;)f--;return f<0||f===0?g:f+a[u[f]]>g?f:g}},{"./common":41}],43:[function(e,n,o){n.exports=function(r,l,s,a){for(var c=65535&r|0,d=r>>>16&65535|0,u=0;s!==0;){for(s-=u=2e3<s?2e3:s;d=d+(c=c+l[a++]|0)|0,--u;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var r=(function(){for(var l,s=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;s[a]=l}return s})();n.exports=function(l,s,a,c){var d=r,u=c+a;l^=-1;for(var g=c;g<u;g++)l=l>>>8^d[255&(l^s[g])];return-1^l}},{}],46:[function(e,n,o){var r,l=e("../utils/common"),s=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),u=0,g=4,f=0,y=-2,h=-1,k=4,b=2,w=8,_=9,T=286,x=30,S=19,B=2*T+1,D=15,M=3,O=258,Z=O+M+1,I=42,P=113,v=1,G=2,A=3,E=4;function j(p,U){return p.msg=d[U],U}function N(p){return(p<<1)-(4<p?9:0)}function J(p){for(var U=p.length;0<=--U;)p[U]=0}function H(p){var U=p.state,z=U.pending;z>p.avail_out&&(z=p.avail_out),z!==0&&(l.arraySet(p.output,U.pending_buf,U.pending_out,z,p.next_out),p.next_out+=z,U.pending_out+=z,p.total_out+=z,p.avail_out-=z,U.pending-=z,U.pending===0&&(U.pending_out=0))}function K(p,U){s._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,U),p.block_start=p.strstart,H(p.strm)}function rt(p,U){p.pending_buf[p.pending++]=U}function lt(p,U){p.pending_buf[p.pending++]=U>>>8&255,p.pending_buf[p.pending++]=255&U}function st(p,U){var z,C,$=p.max_chain_length,R=p.strstart,q=p.prev_length,W=p.nice_match,V=p.strstart>p.w_size-Z?p.strstart-(p.w_size-Z):0,Y=p.window,ot=p.w_mask,et=p.prev,at=p.strstart+O,_t=Y[R+q-1],kt=Y[R+q];p.prev_length>=p.good_match&&($>>=2),W>p.lookahead&&(W=p.lookahead);do if(Y[(z=U)+q]===kt&&Y[z+q-1]===_t&&Y[z]===Y[R]&&Y[++z]===Y[R+1]){R+=2,z++;do;while(Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&Y[++R]===Y[++z]&&R<at);if(C=O-(at-R),R=at-O,q<C){if(p.match_start=U,W<=(q=C))break;_t=Y[R+q-1],kt=Y[R+q]}}while((U=et[U&ot])>V&&--$!=0);return q<=p.lookahead?q:p.lookahead}function Q(p){var U,z,C,$,R,q,W,V,Y,ot,et=p.w_size;do{if($=p.window_size-p.lookahead-p.strstart,p.strstart>=et+(et-Z)){for(l.arraySet(p.window,p.window,et,et,0),p.match_start-=et,p.strstart-=et,p.block_start-=et,U=z=p.hash_size;C=p.head[--U],p.head[U]=et<=C?C-et:0,--z;);for(U=z=et;C=p.prev[--U],p.prev[U]=et<=C?C-et:0,--z;);$+=et}if(p.strm.avail_in===0)break;if(q=p.strm,W=p.window,V=p.strstart+p.lookahead,Y=$,ot=void 0,ot=q.avail_in,Y<ot&&(ot=Y),z=ot===0?0:(q.avail_in-=ot,l.arraySet(W,q.input,q.next_in,ot,V),q.state.wrap===1?q.adler=a(q.adler,W,ot,V):q.state.wrap===2&&(q.adler=c(q.adler,W,ot,V)),q.next_in+=ot,q.total_in+=ot,ot),p.lookahead+=z,p.lookahead+p.insert>=M)for(R=p.strstart-p.insert,p.ins_h=p.window[R],p.ins_h=(p.ins_h<<p.hash_shift^p.window[R+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[R+M-1])&p.hash_mask,p.prev[R&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=R,R++,p.insert--,!(p.lookahead+p.insert<M)););}while(p.lookahead<Z&&p.strm.avail_in!==0)}function pt(p,U){for(var z,C;;){if(p.lookahead<Z){if(Q(p),p.lookahead<Z&&U===u)return v;if(p.lookahead===0)break}if(z=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),z!==0&&p.strstart-z<=p.w_size-Z&&(p.match_length=st(p,z)),p.match_length>=M)if(C=s._tr_tally(p,p.strstart-p.match_start,p.match_length-M),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=M){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else C=s._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(C&&(K(p,!1),p.strm.avail_out===0))return v}return p.insert=p.strstart<M-1?p.strstart:M-1,U===g?(K(p,!0),p.strm.avail_out===0?A:E):p.last_lit&&(K(p,!1),p.strm.avail_out===0)?v:G}function bt(p,U){for(var z,C,$;;){if(p.lookahead<Z){if(Q(p),p.lookahead<Z&&U===u)return v;if(p.lookahead===0)break}if(z=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=M-1,z!==0&&p.prev_length<p.max_lazy_match&&p.strstart-z<=p.w_size-Z&&(p.match_length=st(p,z),p.match_length<=5&&(p.strategy===1||p.match_length===M&&4096<p.strstart-p.match_start)&&(p.match_length=M-1)),p.prev_length>=M&&p.match_length<=p.prev_length){for($=p.strstart+p.lookahead-M,C=s._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-M),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=$&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=M-1,p.strstart++,C&&(K(p,!1),p.strm.avail_out===0))return v}else if(p.match_available){if((C=s._tr_tally(p,0,p.window[p.strstart-1]))&&K(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return v}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(C=s._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<M-1?p.strstart:M-1,U===g?(K(p,!0),p.strm.avail_out===0?A:E):p.last_lit&&(K(p,!1),p.strm.avail_out===0)?v:G}function X(p,U,z,C,$){this.good_length=p,this.max_lazy=U,this.nice_length=z,this.max_chain=C,this.func=$}function ut(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*B),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*S+1)),J(this.dyn_ltree),J(this.dyn_dtree),J(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(D+1),this.heap=new l.Buf16(2*T+1),J(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),J(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function vt(p){var U;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=b,(U=p.state).pending=0,U.pending_out=0,U.wrap<0&&(U.wrap=-U.wrap),U.status=U.wrap?I:P,p.adler=U.wrap===2?0:1,U.last_flush=u,s._tr_init(U),f):j(p,y)}function L(p){var U=vt(p);return U===f&&(function(z){z.window_size=2*z.w_size,J(z.head),z.max_lazy_match=r[z.level].max_lazy,z.good_match=r[z.level].good_length,z.nice_match=r[z.level].nice_length,z.max_chain_length=r[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=M-1,z.match_available=0,z.ins_h=0})(p.state),U}function F(p,U,z,C,$,R){if(!p)return y;var q=1;if(U===h&&(U=6),C<0?(q=0,C=-C):15<C&&(q=2,C-=16),$<1||_<$||z!==w||C<8||15<C||U<0||9<U||R<0||k<R)return j(p,y);C===8&&(C=9);var W=new ut;return(p.state=W).strm=p,W.wrap=q,W.gzhead=null,W.w_bits=C,W.w_size=1<<W.w_bits,W.w_mask=W.w_size-1,W.hash_bits=$+7,W.hash_size=1<<W.hash_bits,W.hash_mask=W.hash_size-1,W.hash_shift=~~((W.hash_bits+M-1)/M),W.window=new l.Buf8(2*W.w_size),W.head=new l.Buf16(W.hash_size),W.prev=new l.Buf16(W.w_size),W.lit_bufsize=1<<$+6,W.pending_buf_size=4*W.lit_bufsize,W.pending_buf=new l.Buf8(W.pending_buf_size),W.d_buf=1*W.lit_bufsize,W.l_buf=3*W.lit_bufsize,W.level=U,W.strategy=R,W.method=z,L(p)}r=[new X(0,0,0,0,function(p,U){var z=65535;for(z>p.pending_buf_size-5&&(z=p.pending_buf_size-5);;){if(p.lookahead<=1){if(Q(p),p.lookahead===0&&U===u)return v;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var C=p.block_start+z;if((p.strstart===0||p.strstart>=C)&&(p.lookahead=p.strstart-C,p.strstart=C,K(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-Z&&(K(p,!1),p.strm.avail_out===0))return v}return p.insert=0,U===g?(K(p,!0),p.strm.avail_out===0?A:E):(p.strstart>p.block_start&&(K(p,!1),p.strm.avail_out),v)}),new X(4,4,8,4,pt),new X(4,5,16,8,pt),new X(4,6,32,32,pt),new X(4,4,16,16,bt),new X(8,16,32,32,bt),new X(8,16,128,128,bt),new X(8,32,128,256,bt),new X(32,128,258,1024,bt),new X(32,258,258,4096,bt)],o.deflateInit=function(p,U){return F(p,U,w,15,8,0)},o.deflateInit2=F,o.deflateReset=L,o.deflateResetKeep=vt,o.deflateSetHeader=function(p,U){return p&&p.state?p.state.wrap!==2?y:(p.state.gzhead=U,f):y},o.deflate=function(p,U){var z,C,$,R;if(!p||!p.state||5<U||U<0)return p?j(p,y):y;if(C=p.state,!p.output||!p.input&&p.avail_in!==0||C.status===666&&U!==g)return j(p,p.avail_out===0?-5:y);if(C.strm=p,z=C.last_flush,C.last_flush=U,C.status===I)if(C.wrap===2)p.adler=0,rt(C,31),rt(C,139),rt(C,8),C.gzhead?(rt(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),rt(C,255&C.gzhead.time),rt(C,C.gzhead.time>>8&255),rt(C,C.gzhead.time>>16&255),rt(C,C.gzhead.time>>24&255),rt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),rt(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(rt(C,255&C.gzhead.extra.length),rt(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(p.adler=c(p.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(rt(C,0),rt(C,0),rt(C,0),rt(C,0),rt(C,0),rt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),rt(C,3),C.status=P);else{var q=w+(C.w_bits-8<<4)<<8;q|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(q|=32),q+=31-q%31,C.status=P,lt(C,q),C.strstart!==0&&(lt(C,p.adler>>>16),lt(C,65535&p.adler)),p.adler=1}if(C.status===69)if(C.gzhead.extra){for($=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),H(p),$=C.pending,C.pending!==C.pending_buf_size));)rt(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),H(p),$=C.pending,C.pending===C.pending_buf_size)){R=1;break}R=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,rt(C,R)}while(R!==0);C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),R===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),H(p),$=C.pending,C.pending===C.pending_buf_size)){R=1;break}R=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,rt(C,R)}while(R!==0);C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),R===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&H(p),C.pending+2<=C.pending_buf_size&&(rt(C,255&p.adler),rt(C,p.adler>>8&255),p.adler=0,C.status=P)):C.status=P),C.pending!==0){if(H(p),p.avail_out===0)return C.last_flush=-1,f}else if(p.avail_in===0&&N(U)<=N(z)&&U!==g)return j(p,-5);if(C.status===666&&p.avail_in!==0)return j(p,-5);if(p.avail_in!==0||C.lookahead!==0||U!==u&&C.status!==666){var W=C.strategy===2?(function(V,Y){for(var ot;;){if(V.lookahead===0&&(Q(V),V.lookahead===0)){if(Y===u)return v;break}if(V.match_length=0,ot=s._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++,ot&&(K(V,!1),V.strm.avail_out===0))return v}return V.insert=0,Y===g?(K(V,!0),V.strm.avail_out===0?A:E):V.last_lit&&(K(V,!1),V.strm.avail_out===0)?v:G})(C,U):C.strategy===3?(function(V,Y){for(var ot,et,at,_t,kt=V.window;;){if(V.lookahead<=O){if(Q(V),V.lookahead<=O&&Y===u)return v;if(V.lookahead===0)break}if(V.match_length=0,V.lookahead>=M&&0<V.strstart&&(et=kt[at=V.strstart-1])===kt[++at]&&et===kt[++at]&&et===kt[++at]){_t=V.strstart+O;do;while(et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&et===kt[++at]&&at<_t);V.match_length=O-(_t-at),V.match_length>V.lookahead&&(V.match_length=V.lookahead)}if(V.match_length>=M?(ot=s._tr_tally(V,1,V.match_length-M),V.lookahead-=V.match_length,V.strstart+=V.match_length,V.match_length=0):(ot=s._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++),ot&&(K(V,!1),V.strm.avail_out===0))return v}return V.insert=0,Y===g?(K(V,!0),V.strm.avail_out===0?A:E):V.last_lit&&(K(V,!1),V.strm.avail_out===0)?v:G})(C,U):r[C.level].func(C,U);if(W!==A&&W!==E||(C.status=666),W===v||W===A)return p.avail_out===0&&(C.last_flush=-1),f;if(W===G&&(U===1?s._tr_align(C):U!==5&&(s._tr_stored_block(C,0,0,!1),U===3&&(J(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),H(p),p.avail_out===0))return C.last_flush=-1,f}return U!==g?f:C.wrap<=0?1:(C.wrap===2?(rt(C,255&p.adler),rt(C,p.adler>>8&255),rt(C,p.adler>>16&255),rt(C,p.adler>>24&255),rt(C,255&p.total_in),rt(C,p.total_in>>8&255),rt(C,p.total_in>>16&255),rt(C,p.total_in>>24&255)):(lt(C,p.adler>>>16),lt(C,65535&p.adler)),H(p),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?f:1)},o.deflateEnd=function(p){var U;return p&&p.state?(U=p.state.status)!==I&&U!==69&&U!==73&&U!==91&&U!==103&&U!==P&&U!==666?j(p,y):(p.state=null,U===P?j(p,-3):f):y},o.deflateSetDictionary=function(p,U){var z,C,$,R,q,W,V,Y,ot=U.length;if(!p||!p.state||(R=(z=p.state).wrap)===2||R===1&&z.status!==I||z.lookahead)return y;for(R===1&&(p.adler=a(p.adler,U,ot,0)),z.wrap=0,ot>=z.w_size&&(R===0&&(J(z.head),z.strstart=0,z.block_start=0,z.insert=0),Y=new l.Buf8(z.w_size),l.arraySet(Y,U,ot-z.w_size,z.w_size,0),U=Y,ot=z.w_size),q=p.avail_in,W=p.next_in,V=p.input,p.avail_in=ot,p.next_in=0,p.input=U,Q(z);z.lookahead>=M;){for(C=z.strstart,$=z.lookahead-(M-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[C+M-1])&z.hash_mask,z.prev[C&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=C,C++,--$;);z.strstart=C,z.lookahead=M-1,Q(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=M-1,z.match_available=0,p.next_in=W,p.input=V,p.avail_in=q,z.wrap=R,f},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(r,l){var s,a,c,d,u,g,f,y,h,k,b,w,_,T,x,S,B,D,M,O,Z,I,P,v,G;s=r.state,a=r.next_in,v=r.input,c=a+(r.avail_in-5),d=r.next_out,G=r.output,u=d-(l-r.avail_out),g=d+(r.avail_out-257),f=s.dmax,y=s.wsize,h=s.whave,k=s.wnext,b=s.window,w=s.hold,_=s.bits,T=s.lencode,x=s.distcode,S=(1<<s.lenbits)-1,B=(1<<s.distbits)-1;t:do{_<15&&(w+=v[a++]<<_,_+=8,w+=v[a++]<<_,_+=8),D=T[w&S];e:for(;;){if(w>>>=M=D>>>24,_-=M,(M=D>>>16&255)===0)G[d++]=65535&D;else{if(!(16&M)){if((64&M)==0){D=T[(65535&D)+(w&(1<<M)-1)];continue e}if(32&M){s.mode=12;break t}r.msg="invalid literal/length code",s.mode=30;break t}O=65535&D,(M&=15)&&(_<M&&(w+=v[a++]<<_,_+=8),O+=w&(1<<M)-1,w>>>=M,_-=M),_<15&&(w+=v[a++]<<_,_+=8,w+=v[a++]<<_,_+=8),D=x[w&B];i:for(;;){if(w>>>=M=D>>>24,_-=M,!(16&(M=D>>>16&255))){if((64&M)==0){D=x[(65535&D)+(w&(1<<M)-1)];continue i}r.msg="invalid distance code",s.mode=30;break t}if(Z=65535&D,_<(M&=15)&&(w+=v[a++]<<_,(_+=8)<M&&(w+=v[a++]<<_,_+=8)),f<(Z+=w&(1<<M)-1)){r.msg="invalid distance too far back",s.mode=30;break t}if(w>>>=M,_-=M,(M=d-u)<Z){if(h<(M=Z-M)&&s.sane){r.msg="invalid distance too far back",s.mode=30;break t}if(P=b,(I=0)===k){if(I+=y-M,M<O){for(O-=M;G[d++]=b[I++],--M;);I=d-Z,P=G}}else if(k<M){if(I+=y+k-M,(M-=k)<O){for(O-=M;G[d++]=b[I++],--M;);if(I=0,k<O){for(O-=M=k;G[d++]=b[I++],--M;);I=d-Z,P=G}}}else if(I+=k-M,M<O){for(O-=M;G[d++]=b[I++],--M;);I=d-Z,P=G}for(;2<O;)G[d++]=P[I++],G[d++]=P[I++],G[d++]=P[I++],O-=3;O&&(G[d++]=P[I++],1<O&&(G[d++]=P[I++]))}else{for(I=d-Z;G[d++]=G[I++],G[d++]=G[I++],G[d++]=G[I++],2<(O-=3););O&&(G[d++]=G[I++],1<O&&(G[d++]=G[I++]))}break}}break}}while(a<c&&d<g);a-=O=_>>3,w&=(1<<(_-=O<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),s.hold=w,s.bits=_}},{}],49:[function(e,n,o){var r=e("../utils/common"),l=e("./adler32"),s=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,u=2,g=0,f=-2,y=1,h=852,k=592;function b(I){return(I>>>24&255)+(I>>>8&65280)+((65280&I)<<8)+((255&I)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(I){var P;return I&&I.state?(P=I.state,I.total_in=I.total_out=P.total=0,I.msg="",P.wrap&&(I.adler=1&P.wrap),P.mode=y,P.last=0,P.havedict=0,P.dmax=32768,P.head=null,P.hold=0,P.bits=0,P.lencode=P.lendyn=new r.Buf32(h),P.distcode=P.distdyn=new r.Buf32(k),P.sane=1,P.back=-1,g):f}function T(I){var P;return I&&I.state?((P=I.state).wsize=0,P.whave=0,P.wnext=0,_(I)):f}function x(I,P){var v,G;return I&&I.state?(G=I.state,P<0?(v=0,P=-P):(v=1+(P>>4),P<48&&(P&=15)),P&&(P<8||15<P)?f:(G.window!==null&&G.wbits!==P&&(G.window=null),G.wrap=v,G.wbits=P,T(I))):f}function S(I,P){var v,G;return I?(G=new w,(I.state=G).window=null,(v=x(I,P))!==g&&(I.state=null),v):f}var B,D,M=!0;function O(I){if(M){var P;for(B=new r.Buf32(512),D=new r.Buf32(32),P=0;P<144;)I.lens[P++]=8;for(;P<256;)I.lens[P++]=9;for(;P<280;)I.lens[P++]=7;for(;P<288;)I.lens[P++]=8;for(c(d,I.lens,0,288,B,0,I.work,{bits:9}),P=0;P<32;)I.lens[P++]=5;c(u,I.lens,0,32,D,0,I.work,{bits:5}),M=!1}I.lencode=B,I.lenbits=9,I.distcode=D,I.distbits=5}function Z(I,P,v,G){var A,E=I.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new r.Buf8(E.wsize)),G>=E.wsize?(r.arraySet(E.window,P,v-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(G<(A=E.wsize-E.wnext)&&(A=G),r.arraySet(E.window,P,v-G,A,E.wnext),(G-=A)?(r.arraySet(E.window,P,v-G,G,0),E.wnext=G,E.whave=E.wsize):(E.wnext+=A,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=A))),0}o.inflateReset=T,o.inflateReset2=x,o.inflateResetKeep=_,o.inflateInit=function(I){return S(I,15)},o.inflateInit2=S,o.inflate=function(I,P){var v,G,A,E,j,N,J,H,K,rt,lt,st,Q,pt,bt,X,ut,vt,L,F,p,U,z,C,$=0,R=new r.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!I||!I.state||!I.output||!I.input&&I.avail_in!==0)return f;(v=I.state).mode===12&&(v.mode=13),j=I.next_out,A=I.output,J=I.avail_out,E=I.next_in,G=I.input,N=I.avail_in,H=v.hold,K=v.bits,rt=N,lt=J,U=g;t:for(;;)switch(v.mode){case y:if(v.wrap===0){v.mode=13;break}for(;K<16;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(2&v.wrap&&H===35615){R[v.check=0]=255&H,R[1]=H>>>8&255,v.check=s(v.check,R,2,0),K=H=0,v.mode=2;break}if(v.flags=0,v.head&&(v.head.done=!1),!(1&v.wrap)||(((255&H)<<8)+(H>>8))%31){I.msg="incorrect header check",v.mode=30;break}if((15&H)!=8){I.msg="unknown compression method",v.mode=30;break}if(K-=4,p=8+(15&(H>>>=4)),v.wbits===0)v.wbits=p;else if(p>v.wbits){I.msg="invalid window size",v.mode=30;break}v.dmax=1<<p,I.adler=v.check=1,v.mode=512&H?10:12,K=H=0;break;case 2:for(;K<16;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(v.flags=H,(255&v.flags)!=8){I.msg="unknown compression method",v.mode=30;break}if(57344&v.flags){I.msg="unknown header flags set",v.mode=30;break}v.head&&(v.head.text=H>>8&1),512&v.flags&&(R[0]=255&H,R[1]=H>>>8&255,v.check=s(v.check,R,2,0)),K=H=0,v.mode=3;case 3:for(;K<32;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.head&&(v.head.time=H),512&v.flags&&(R[0]=255&H,R[1]=H>>>8&255,R[2]=H>>>16&255,R[3]=H>>>24&255,v.check=s(v.check,R,4,0)),K=H=0,v.mode=4;case 4:for(;K<16;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.head&&(v.head.xflags=255&H,v.head.os=H>>8),512&v.flags&&(R[0]=255&H,R[1]=H>>>8&255,v.check=s(v.check,R,2,0)),K=H=0,v.mode=5;case 5:if(1024&v.flags){for(;K<16;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.length=H,v.head&&(v.head.extra_len=H),512&v.flags&&(R[0]=255&H,R[1]=H>>>8&255,v.check=s(v.check,R,2,0)),K=H=0}else v.head&&(v.head.extra=null);v.mode=6;case 6:if(1024&v.flags&&(N<(st=v.length)&&(st=N),st&&(v.head&&(p=v.head.extra_len-v.length,v.head.extra||(v.head.extra=new Array(v.head.extra_len)),r.arraySet(v.head.extra,G,E,st,p)),512&v.flags&&(v.check=s(v.check,G,st,E)),N-=st,E+=st,v.length-=st),v.length))break t;v.length=0,v.mode=7;case 7:if(2048&v.flags){if(N===0)break t;for(st=0;p=G[E+st++],v.head&&p&&v.length<65536&&(v.head.name+=String.fromCharCode(p)),p&&st<N;);if(512&v.flags&&(v.check=s(v.check,G,st,E)),N-=st,E+=st,p)break t}else v.head&&(v.head.name=null);v.length=0,v.mode=8;case 8:if(4096&v.flags){if(N===0)break t;for(st=0;p=G[E+st++],v.head&&p&&v.length<65536&&(v.head.comment+=String.fromCharCode(p)),p&&st<N;);if(512&v.flags&&(v.check=s(v.check,G,st,E)),N-=st,E+=st,p)break t}else v.head&&(v.head.comment=null);v.mode=9;case 9:if(512&v.flags){for(;K<16;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(H!==(65535&v.check)){I.msg="header crc mismatch",v.mode=30;break}K=H=0}v.head&&(v.head.hcrc=v.flags>>9&1,v.head.done=!0),I.adler=v.check=0,v.mode=12;break;case 10:for(;K<32;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}I.adler=v.check=b(H),K=H=0,v.mode=11;case 11:if(v.havedict===0)return I.next_out=j,I.avail_out=J,I.next_in=E,I.avail_in=N,v.hold=H,v.bits=K,2;I.adler=v.check=1,v.mode=12;case 12:if(P===5||P===6)break t;case 13:if(v.last){H>>>=7&K,K-=7&K,v.mode=27;break}for(;K<3;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}switch(v.last=1&H,K-=1,3&(H>>>=1)){case 0:v.mode=14;break;case 1:if(O(v),v.mode=20,P!==6)break;H>>>=2,K-=2;break t;case 2:v.mode=17;break;case 3:I.msg="invalid block type",v.mode=30}H>>>=2,K-=2;break;case 14:for(H>>>=7&K,K-=7&K;K<32;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if((65535&H)!=(H>>>16^65535)){I.msg="invalid stored block lengths",v.mode=30;break}if(v.length=65535&H,K=H=0,v.mode=15,P===6)break t;case 15:v.mode=16;case 16:if(st=v.length){if(N<st&&(st=N),J<st&&(st=J),st===0)break t;r.arraySet(A,G,E,st,j),N-=st,E+=st,J-=st,j+=st,v.length-=st;break}v.mode=12;break;case 17:for(;K<14;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(v.nlen=257+(31&H),H>>>=5,K-=5,v.ndist=1+(31&H),H>>>=5,K-=5,v.ncode=4+(15&H),H>>>=4,K-=4,286<v.nlen||30<v.ndist){I.msg="too many length or distance symbols",v.mode=30;break}v.have=0,v.mode=18;case 18:for(;v.have<v.ncode;){for(;K<3;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.lens[q[v.have++]]=7&H,H>>>=3,K-=3}for(;v.have<19;)v.lens[q[v.have++]]=0;if(v.lencode=v.lendyn,v.lenbits=7,z={bits:v.lenbits},U=c(0,v.lens,0,19,v.lencode,0,v.work,z),v.lenbits=z.bits,U){I.msg="invalid code lengths set",v.mode=30;break}v.have=0,v.mode=19;case 19:for(;v.have<v.nlen+v.ndist;){for(;X=($=v.lencode[H&(1<<v.lenbits)-1])>>>16&255,ut=65535&$,!((bt=$>>>24)<=K);){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(ut<16)H>>>=bt,K-=bt,v.lens[v.have++]=ut;else{if(ut===16){for(C=bt+2;K<C;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(H>>>=bt,K-=bt,v.have===0){I.msg="invalid bit length repeat",v.mode=30;break}p=v.lens[v.have-1],st=3+(3&H),H>>>=2,K-=2}else if(ut===17){for(C=bt+3;K<C;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}K-=bt,p=0,st=3+(7&(H>>>=bt)),H>>>=3,K-=3}else{for(C=bt+7;K<C;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}K-=bt,p=0,st=11+(127&(H>>>=bt)),H>>>=7,K-=7}if(v.have+st>v.nlen+v.ndist){I.msg="invalid bit length repeat",v.mode=30;break}for(;st--;)v.lens[v.have++]=p}}if(v.mode===30)break;if(v.lens[256]===0){I.msg="invalid code -- missing end-of-block",v.mode=30;break}if(v.lenbits=9,z={bits:v.lenbits},U=c(d,v.lens,0,v.nlen,v.lencode,0,v.work,z),v.lenbits=z.bits,U){I.msg="invalid literal/lengths set",v.mode=30;break}if(v.distbits=6,v.distcode=v.distdyn,z={bits:v.distbits},U=c(u,v.lens,v.nlen,v.ndist,v.distcode,0,v.work,z),v.distbits=z.bits,U){I.msg="invalid distances set",v.mode=30;break}if(v.mode=20,P===6)break t;case 20:v.mode=21;case 21:if(6<=N&&258<=J){I.next_out=j,I.avail_out=J,I.next_in=E,I.avail_in=N,v.hold=H,v.bits=K,a(I,lt),j=I.next_out,A=I.output,J=I.avail_out,E=I.next_in,G=I.input,N=I.avail_in,H=v.hold,K=v.bits,v.mode===12&&(v.back=-1);break}for(v.back=0;X=($=v.lencode[H&(1<<v.lenbits)-1])>>>16&255,ut=65535&$,!((bt=$>>>24)<=K);){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(X&&(240&X)==0){for(vt=bt,L=X,F=ut;X=($=v.lencode[F+((H&(1<<vt+L)-1)>>vt)])>>>16&255,ut=65535&$,!(vt+(bt=$>>>24)<=K);){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}H>>>=vt,K-=vt,v.back+=vt}if(H>>>=bt,K-=bt,v.back+=bt,v.length=ut,X===0){v.mode=26;break}if(32&X){v.back=-1,v.mode=12;break}if(64&X){I.msg="invalid literal/length code",v.mode=30;break}v.extra=15&X,v.mode=22;case 22:if(v.extra){for(C=v.extra;K<C;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.length+=H&(1<<v.extra)-1,H>>>=v.extra,K-=v.extra,v.back+=v.extra}v.was=v.length,v.mode=23;case 23:for(;X=($=v.distcode[H&(1<<v.distbits)-1])>>>16&255,ut=65535&$,!((bt=$>>>24)<=K);){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if((240&X)==0){for(vt=bt,L=X,F=ut;X=($=v.distcode[F+((H&(1<<vt+L)-1)>>vt)])>>>16&255,ut=65535&$,!(vt+(bt=$>>>24)<=K);){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}H>>>=vt,K-=vt,v.back+=vt}if(H>>>=bt,K-=bt,v.back+=bt,64&X){I.msg="invalid distance code",v.mode=30;break}v.offset=ut,v.extra=15&X,v.mode=24;case 24:if(v.extra){for(C=v.extra;K<C;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}v.offset+=H&(1<<v.extra)-1,H>>>=v.extra,K-=v.extra,v.back+=v.extra}if(v.offset>v.dmax){I.msg="invalid distance too far back",v.mode=30;break}v.mode=25;case 25:if(J===0)break t;if(st=lt-J,v.offset>st){if((st=v.offset-st)>v.whave&&v.sane){I.msg="invalid distance too far back",v.mode=30;break}Q=st>v.wnext?(st-=v.wnext,v.wsize-st):v.wnext-st,st>v.length&&(st=v.length),pt=v.window}else pt=A,Q=j-v.offset,st=v.length;for(J<st&&(st=J),J-=st,v.length-=st;A[j++]=pt[Q++],--st;);v.length===0&&(v.mode=21);break;case 26:if(J===0)break t;A[j++]=v.length,J--,v.mode=21;break;case 27:if(v.wrap){for(;K<32;){if(N===0)break t;N--,H|=G[E++]<<K,K+=8}if(lt-=J,I.total_out+=lt,v.total+=lt,lt&&(I.adler=v.check=v.flags?s(v.check,A,lt,j-lt):l(v.check,A,lt,j-lt)),lt=J,(v.flags?H:b(H))!==v.check){I.msg="incorrect data check",v.mode=30;break}K=H=0}v.mode=28;case 28:if(v.wrap&&v.flags){for(;K<32;){if(N===0)break t;N--,H+=G[E++]<<K,K+=8}if(H!==(4294967295&v.total)){I.msg="incorrect length check",v.mode=30;break}K=H=0}v.mode=29;case 29:U=1;break t;case 30:U=-3;break t;case 31:return-4;case 32:default:return f}return I.next_out=j,I.avail_out=J,I.next_in=E,I.avail_in=N,v.hold=H,v.bits=K,(v.wsize||lt!==I.avail_out&&v.mode<30&&(v.mode<27||P!==4))&&Z(I,I.output,I.next_out,lt-I.avail_out)?(v.mode=31,-4):(rt-=I.avail_in,lt-=I.avail_out,I.total_in+=rt,I.total_out+=lt,v.total+=lt,v.wrap&&lt&&(I.adler=v.check=v.flags?s(v.check,A,lt,I.next_out-lt):l(v.check,A,lt,I.next_out-lt)),I.data_type=v.bits+(v.last?64:0)+(v.mode===12?128:0)+(v.mode===20||v.mode===15?256:0),(rt==0&&lt===0||P===4)&&U===g&&(U=-5),U)},o.inflateEnd=function(I){if(!I||!I.state)return f;var P=I.state;return P.window&&(P.window=null),I.state=null,g},o.inflateGetHeader=function(I,P){var v;return I&&I.state?(2&(v=I.state).wrap)==0?f:((v.head=P).done=!1,g):f},o.inflateSetDictionary=function(I,P){var v,G=P.length;return I&&I.state?(v=I.state).wrap!==0&&v.mode!==11?f:v.mode===11&&l(1,P,G,0)!==v.check?-3:Z(I,P,G,G)?(v.mode=31,-4):(v.havedict=1,g):f},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],s=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,u,g,f,y,h,k,b){var w,_,T,x,S,B,D,M,O,Z=b.bits,I=0,P=0,v=0,G=0,A=0,E=0,j=0,N=0,J=0,H=0,K=null,rt=0,lt=new r.Buf16(16),st=new r.Buf16(16),Q=null,pt=0;for(I=0;I<=15;I++)lt[I]=0;for(P=0;P<f;P++)lt[u[g+P]]++;for(A=Z,G=15;1<=G&&lt[G]===0;G--);if(G<A&&(A=G),G===0)return y[h++]=20971520,y[h++]=20971520,b.bits=1,0;for(v=1;v<G&&lt[v]===0;v++);for(A<v&&(A=v),I=N=1;I<=15;I++)if(N<<=1,(N-=lt[I])<0)return-1;if(0<N&&(d===0||G!==1))return-1;for(st[1]=0,I=1;I<15;I++)st[I+1]=st[I]+lt[I];for(P=0;P<f;P++)u[g+P]!==0&&(k[st[u[g+P]]++]=P);if(B=d===0?(K=Q=k,19):d===1?(K=l,rt-=257,Q=s,pt-=257,256):(K=a,Q=c,-1),I=v,S=h,j=P=H=0,T=-1,x=(J=1<<(E=A))-1,d===1&&852<J||d===2&&592<J)return 1;for(;;){for(D=I-j,O=k[P]<B?(M=0,k[P]):k[P]>B?(M=Q[pt+k[P]],K[rt+k[P]]):(M=96,0),w=1<<I-j,v=_=1<<E;y[S+(H>>j)+(_-=w)]=D<<24|M<<16|O|0,_!==0;);for(w=1<<I-1;H&w;)w>>=1;if(w!==0?(H&=w-1,H+=w):H=0,P++,--lt[I]==0){if(I===G)break;I=u[g+k[P]]}if(A<I&&(H&x)!==T){for(j===0&&(j=A),S+=v,N=1<<(E=I-j);E+j<G&&!((N-=lt[E+j])<=0);)E++,N<<=1;if(J+=1<<E,d===1&&852<J||d===2&&592<J)return 1;y[T=H&x]=A<<24|E<<16|S-h|0}}return H!==0&&(y[S+H]=I-j<<24|64<<16|0),b.bits=A,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var r=e("../utils/common"),l=0,s=1;function a($){for(var R=$.length;0<=--R;)$[R]=0}var c=0,d=29,u=256,g=u+1+d,f=30,y=19,h=2*g+1,k=15,b=16,w=7,_=256,T=16,x=17,S=18,B=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],O=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Z=new Array(2*(g+2));a(Z);var I=new Array(2*f);a(I);var P=new Array(512);a(P);var v=new Array(256);a(v);var G=new Array(d);a(G);var A,E,j,N=new Array(f);function J($,R,q,W,V){this.static_tree=$,this.extra_bits=R,this.extra_base=q,this.elems=W,this.max_length=V,this.has_stree=$&&$.length}function H($,R){this.dyn_tree=$,this.max_code=0,this.stat_desc=R}function K($){return $<256?P[$]:P[256+($>>>7)]}function rt($,R){$.pending_buf[$.pending++]=255&R,$.pending_buf[$.pending++]=R>>>8&255}function lt($,R,q){$.bi_valid>b-q?($.bi_buf|=R<<$.bi_valid&65535,rt($,$.bi_buf),$.bi_buf=R>>b-$.bi_valid,$.bi_valid+=q-b):($.bi_buf|=R<<$.bi_valid&65535,$.bi_valid+=q)}function st($,R,q){lt($,q[2*R],q[2*R+1])}function Q($,R){for(var q=0;q|=1&$,$>>>=1,q<<=1,0<--R;);return q>>>1}function pt($,R,q){var W,V,Y=new Array(k+1),ot=0;for(W=1;W<=k;W++)Y[W]=ot=ot+q[W-1]<<1;for(V=0;V<=R;V++){var et=$[2*V+1];et!==0&&($[2*V]=Q(Y[et]++,et))}}function bt($){var R;for(R=0;R<g;R++)$.dyn_ltree[2*R]=0;for(R=0;R<f;R++)$.dyn_dtree[2*R]=0;for(R=0;R<y;R++)$.bl_tree[2*R]=0;$.dyn_ltree[2*_]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function X($){8<$.bi_valid?rt($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function ut($,R,q,W){var V=2*R,Y=2*q;return $[V]<$[Y]||$[V]===$[Y]&&W[R]<=W[q]}function vt($,R,q){for(var W=$.heap[q],V=q<<1;V<=$.heap_len&&(V<$.heap_len&&ut(R,$.heap[V+1],$.heap[V],$.depth)&&V++,!ut(R,W,$.heap[V],$.depth));)$.heap[q]=$.heap[V],q=V,V<<=1;$.heap[q]=W}function L($,R,q){var W,V,Y,ot,et=0;if($.last_lit!==0)for(;W=$.pending_buf[$.d_buf+2*et]<<8|$.pending_buf[$.d_buf+2*et+1],V=$.pending_buf[$.l_buf+et],et++,W===0?st($,V,R):(st($,(Y=v[V])+u+1,R),(ot=B[Y])!==0&&lt($,V-=G[Y],ot),st($,Y=K(--W),q),(ot=D[Y])!==0&&lt($,W-=N[Y],ot)),et<$.last_lit;);st($,_,R)}function F($,R){var q,W,V,Y=R.dyn_tree,ot=R.stat_desc.static_tree,et=R.stat_desc.has_stree,at=R.stat_desc.elems,_t=-1;for($.heap_len=0,$.heap_max=h,q=0;q<at;q++)Y[2*q]!==0?($.heap[++$.heap_len]=_t=q,$.depth[q]=0):Y[2*q+1]=0;for(;$.heap_len<2;)Y[2*(V=$.heap[++$.heap_len]=_t<2?++_t:0)]=1,$.depth[V]=0,$.opt_len--,et&&($.static_len-=ot[2*V+1]);for(R.max_code=_t,q=$.heap_len>>1;1<=q;q--)vt($,Y,q);for(V=at;q=$.heap[1],$.heap[1]=$.heap[$.heap_len--],vt($,Y,1),W=$.heap[1],$.heap[--$.heap_max]=q,$.heap[--$.heap_max]=W,Y[2*V]=Y[2*q]+Y[2*W],$.depth[V]=($.depth[q]>=$.depth[W]?$.depth[q]:$.depth[W])+1,Y[2*q+1]=Y[2*W+1]=V,$.heap[1]=V++,vt($,Y,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(kt,Mt){var qt,Gt,ne,Nt,qe,ee,Jt=Mt.dyn_tree,bi=Mt.max_code,Pi=Mt.stat_desc.static_tree,Ao=Mt.stat_desc.has_stree,To=Mt.stat_desc.extra_bits,Rn=Mt.stat_desc.extra_base,yi=Mt.stat_desc.max_length,Ri=0;for(Nt=0;Nt<=k;Nt++)kt.bl_count[Nt]=0;for(Jt[2*kt.heap[kt.heap_max]+1]=0,qt=kt.heap_max+1;qt<h;qt++)yi<(Nt=Jt[2*Jt[2*(Gt=kt.heap[qt])+1]+1]+1)&&(Nt=yi,Ri++),Jt[2*Gt+1]=Nt,bi<Gt||(kt.bl_count[Nt]++,qe=0,Rn<=Gt&&(qe=To[Gt-Rn]),ee=Jt[2*Gt],kt.opt_len+=ee*(Nt+qe),Ao&&(kt.static_len+=ee*(Pi[2*Gt+1]+qe)));if(Ri!==0){do{for(Nt=yi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[yi]--,Ri-=2}while(0<Ri);for(Nt=yi;Nt!==0;Nt--)for(Gt=kt.bl_count[Nt];Gt!==0;)bi<(ne=kt.heap[--qt])||(Jt[2*ne+1]!==Nt&&(kt.opt_len+=(Nt-Jt[2*ne+1])*Jt[2*ne],Jt[2*ne+1]=Nt),Gt--)}})($,R),pt(Y,_t,$.bl_count)}function p($,R,q){var W,V,Y=-1,ot=R[1],et=0,at=7,_t=4;for(ot===0&&(at=138,_t=3),R[2*(q+1)+1]=65535,W=0;W<=q;W++)V=ot,ot=R[2*(W+1)+1],++et<at&&V===ot||(et<_t?$.bl_tree[2*V]+=et:V!==0?(V!==Y&&$.bl_tree[2*V]++,$.bl_tree[2*T]++):et<=10?$.bl_tree[2*x]++:$.bl_tree[2*S]++,Y=V,_t=(et=0)===ot?(at=138,3):V===ot?(at=6,3):(at=7,4))}function U($,R,q){var W,V,Y=-1,ot=R[1],et=0,at=7,_t=4;for(ot===0&&(at=138,_t=3),W=0;W<=q;W++)if(V=ot,ot=R[2*(W+1)+1],!(++et<at&&V===ot)){if(et<_t)for(;st($,V,$.bl_tree),--et!=0;);else V!==0?(V!==Y&&(st($,V,$.bl_tree),et--),st($,T,$.bl_tree),lt($,et-3,2)):et<=10?(st($,x,$.bl_tree),lt($,et-3,3)):(st($,S,$.bl_tree),lt($,et-11,7));Y=V,_t=(et=0)===ot?(at=138,3):V===ot?(at=6,3):(at=7,4)}}a(N);var z=!1;function C($,R,q,W){lt($,(c<<1)+(W?1:0),3),(function(V,Y,ot,et){X(V),rt(V,ot),rt(V,~ot),r.arraySet(V.pending_buf,V.window,Y,ot,V.pending),V.pending+=ot})($,R,q)}o._tr_init=function($){z||((function(){var R,q,W,V,Y,ot=new Array(k+1);for(V=W=0;V<d-1;V++)for(G[V]=W,R=0;R<1<<B[V];R++)v[W++]=V;for(v[W-1]=V,V=Y=0;V<16;V++)for(N[V]=Y,R=0;R<1<<D[V];R++)P[Y++]=V;for(Y>>=7;V<f;V++)for(N[V]=Y<<7,R=0;R<1<<D[V]-7;R++)P[256+Y++]=V;for(q=0;q<=k;q++)ot[q]=0;for(R=0;R<=143;)Z[2*R+1]=8,R++,ot[8]++;for(;R<=255;)Z[2*R+1]=9,R++,ot[9]++;for(;R<=279;)Z[2*R+1]=7,R++,ot[7]++;for(;R<=287;)Z[2*R+1]=8,R++,ot[8]++;for(pt(Z,g+1,ot),R=0;R<f;R++)I[2*R+1]=5,I[2*R]=Q(R,5);A=new J(Z,B,u+1,g,k),E=new J(I,D,0,f,k),j=new J(new Array(0),M,0,y,w)})(),z=!0),$.l_desc=new H($.dyn_ltree,A),$.d_desc=new H($.dyn_dtree,E),$.bl_desc=new H($.bl_tree,j),$.bi_buf=0,$.bi_valid=0,bt($)},o._tr_stored_block=C,o._tr_flush_block=function($,R,q,W){var V,Y,ot=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(et){var at,_t=4093624447;for(at=0;at<=31;at++,_t>>>=1)if(1&_t&&et.dyn_ltree[2*at]!==0)return l;if(et.dyn_ltree[18]!==0||et.dyn_ltree[20]!==0||et.dyn_ltree[26]!==0)return s;for(at=32;at<u;at++)if(et.dyn_ltree[2*at]!==0)return s;return l})($)),F($,$.l_desc),F($,$.d_desc),ot=(function(et){var at;for(p(et,et.dyn_ltree,et.l_desc.max_code),p(et,et.dyn_dtree,et.d_desc.max_code),F(et,et.bl_desc),at=y-1;3<=at&&et.bl_tree[2*O[at]+1]===0;at--);return et.opt_len+=3*(at+1)+5+5+4,at})($),V=$.opt_len+3+7>>>3,(Y=$.static_len+3+7>>>3)<=V&&(V=Y)):V=Y=q+5,q+4<=V&&R!==-1?C($,R,q,W):$.strategy===4||Y===V?(lt($,2+(W?1:0),3),L($,Z,I)):(lt($,4+(W?1:0),3),(function(et,at,_t,kt){var Mt;for(lt(et,at-257,5),lt(et,_t-1,5),lt(et,kt-4,4),Mt=0;Mt<kt;Mt++)lt(et,et.bl_tree[2*O[Mt]+1],3);U(et,et.dyn_ltree,at-1),U(et,et.dyn_dtree,_t-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,ot+1),L($,$.dyn_ltree,$.dyn_dtree)),bt($),W&&X($)},o._tr_tally=function($,R,q){return $.pending_buf[$.d_buf+2*$.last_lit]=R>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&R,$.pending_buf[$.l_buf+$.last_lit]=255&q,$.last_lit++,R===0?$.dyn_ltree[2*q]++:($.matches++,R--,$.dyn_ltree[2*(v[q]+u+1)]++,$.dyn_dtree[2*K(R)]++),$.last_lit===$.lit_bufsize-1},o._tr_align=function($){lt($,2,3),st($,_,Z),(function(R){R.bi_valid===16?(rt(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(r){(function(l,s){if(!l.setImmediate){var a,c,d,u,g=1,f={},y=!1,h=l.document,k=Object.getPrototypeOf&&Object.getPrototypeOf(l);k=k&&k.setTimeout?k:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){w(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,x=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=x,T}})()?(u="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(T){l.postMessage(u+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){w(T.data)},function(T){d.port2.postMessage(T)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(T){var x=h.createElement("script");x.onreadystatechange=function(){w(T),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(T){setTimeout(w,0,T)},k.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var x=new Array(arguments.length-1),S=0;S<x.length;S++)x[S]=arguments[S+1];var B={callback:T,args:x};return f[g]=B,a(g),g++},k.clearImmediate=b}function b(T){delete f[T]}function w(T){if(y)setTimeout(w,0,T);else{var x=f[T];if(x){y=!0;try{(function(S){var B=S.callback,D=S.args;switch(D.length){case 0:B();break;case 1:B(D[0]);break;case 2:B(D[0],D[1]);break;case 3:B(D[0],D[1],D[2]);break;default:B.apply(s,D)}})(x)}finally{b(T),y=!1}}}}function _(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(u)===0&&w(+T.data.slice(u.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Wo)),Wo.exports}var eb=tb();const ib=Qv(eb),nb=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,ob=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function sb(t){const i=await ib.loadAsync(t),e={},n=[];let o="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let s=l.find(a=>a.path.toLowerCase()==="slides.md");s||(s=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),s||(s=l.find(a=>a.path.toLowerCase().endsWith(".md"))),s&&(o=await s.file.async("string"),r=s.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||ob.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const u=c.split("/");u.length>1&&(e[u.slice(1).join("/")]=d)}else if(nb.test(c)){const d=await a.file.async("uint8array"),u=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:u,data:d,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:r,virtualFiles:e,assets:n}}function rb(t,i){if(Object.keys(i).length===0)return t;function e(o){const r=o.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const s=r.replace(/^\.?\//,"");return i[s]?i[s]:i[l]?i[l]:null}function n(o){let r=o;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,s,a)=>{const c=e(a);return c?`![${s}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,s)=>{const a=e(s);return a?`src="${a}"`:l}),r}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const r=o.pageAttrs["custom-slidev-background"],l=e(r);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],r=e(o);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function la(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function lb(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),r=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",s=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[s]||a[`./${s}`]||a[`@/${s}`];if(!c&&Object.keys(a).length>0){const f=s.split("/").pop();for(const[y,h]of Object.entries(a))if(y.endsWith(`/${s}`)||f&&y.endsWith(`/${f}`)){c=h;break}}if(!c){const f=[];if(i!=null&&i.baseDir)try{const y=require("path");f.push(y.resolve(i.baseDir,s)),f.push(y.resolve(i.baseDir,r))}catch{}try{const y=require("path");f.push(y.resolve(process.cwd(),s))}catch{}for(const y of f){const h=la(y);if(h!==null){c=h;break}}}if(!c){const f=Xl||{};if(c=f[r]||f[s]||f[`snippets/${s}`],!c){const y=s.split("/").pop();for(const[h,k]of Object.entries(f))if(h.endsWith(`/${s}`)||y&&h.endsWith(`/${y}`)){c=k;break}}}if(!c)return null;let d=c;if(l){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),y=c.match(f);if(y){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+y[1].trimEnd()}}const u=s.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${u?u[1]:""}
${d}
\`\`\``}function ab(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Zn(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],r=o.trim();if(!r||r.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const s=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const u=e[n];if(!u.trim()){c.push(""),n++;continue}const f=u.match(/^(\s+)/),y=f?f[1].length:0;if(d===-1&&(d=y),y<d)break;c.push(u.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[s]=a===">"?c.join(" "):c.join(`
`);continue}if(a=ab(a),!a){let c=n+1;const d=[];let u=-1;for(;c<e.length;){const g=e[c],f=g.trim();if(!f||f.startsWith("#")){u!==-1&&d.push(""),c++;continue}const y=g.match(/^(\s+)/),h=y?y[1].length:0;if(u===-1)if(h>0)u=h;else break;if(h<u)break;d.push(g.slice(u)),c++}if(d.length>0){i[s]=Zn(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[s]=a}n++}return i}const cb=/^\s*```ya?ml([\s\S]*?)```/;function Ir(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const r=Zn(n[1]);if(Object.keys(r).length>0||!n[1].trim())return i=r,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const o=e.match(cb);if(o)i=Zn(o[1]),e=e.slice(o[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let s=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){s=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{s=a;break}}l.length>0&&(i=Zn(l.join(`
`)),e=r.slice(s).join(`
`).trim())}return{frontmatter:i,content:e}}function db(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function r(l){if(n>=l)return;const s=i.slice(n,l).join(`
`).trim();s&&e.push(s),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let u=l+1;for(;u<i.length&&!i[u].trimStart().startsWith(d);u++);u<i.length&&(l=u)}}return n<i.length&&r(i.length),e}function Yn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:s=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const u=db(d),g={};let f="",y="",h=0;if(u.length>0){const O=u[0],Z=Ir(O),I=Object.keys(Z.frontmatter).length>0,P=Z.content.length>0;I&&!P&&u.length>1?(h=1,k(Z.frontmatter)):I&&k(Z.frontmatter)}function k(O){f=O.title||"",O.theme&&(g[yn]=String(O.theme)),O.aspectRatio&&(g[kn]=String(O.aspectRatio)),O.highlighter&&(g[Pr]=String(O.highlighter)),O.transition&&(g[wn]=String(O.transition)),O.colorSchema&&(g[Rr]=String(O.colorSchema)),O.layout&&(g[dt]=String(O.layout)),O.background&&(g[Ht]=String(O.background)),O.image&&(g[Be]=String(O.image)),O.class&&(g[Hi]=String(O.class));for(const[Z,I]of Object.entries(O))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(Z)||(g[`custom-slidev-${Z}`]=typeof I=="object"?JSON.stringify(I):String(I))}const b=[];let w=0,_=0,T=0,x=0;const S=new Set,B={};let D=1;for(let O=h;O<u.length;O++){const Z=u[O],{frontmatter:I,content:P}=Ir(Z),v=Z.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),G=I.src||(v?v[1]:void 0);if(G){const X=String(G).trim().replace(/^['"]|['"]$/g,"");let ut=c[X]||c[X.replace(/^\.\//,"")]||c[`pages/${X.replace(/^.*pages\//,"")}`];if(!ut){const L=X.replace(/^\.\//,""),F=[];if(i.baseDir)try{const p=require("path");F.push(p.resolve(i.baseDir,L)),F.push(p.resolve(i.baseDir,X))}catch{}try{const p=require("path");F.push(p.resolve(process.cwd(),L)),F.push(p.resolve(process.cwd(),X))}catch{}for(const p of F){const U=la(p);if(U!==null){ut=U;break}}}const vt={};I.layout&&(vt[dt]=String(I.layout)),I.transition&&(vt[Qt]=String(I.transition)),I.background&&(vt[Ht]=String(I.background)),I.image&&(vt[Be]=String(I.image)),I.class&&(vt[Hi]=String(I.class));for(const[L,F]of Object.entries(I))["src","layout","transition","background","image","class"].includes(L)||(vt[`custom-slidev-${L}`]=typeof F=="object"?JSON.stringify(F):String(F));if(ut){const L=Yn(ut,{...i,virtualFiles:c});for(const F of L.slides){F.pageIndex=D++,F.pageAttrs={...vt,...F.pageAttrs},b.push(F);const p=F.pageAttrs[dt]||"default";B[p]=(B[p]||0)+1}continue}else{b.push({pageIndex:D++,pageAttrs:{...vt,"custom-slidev-src":X},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${X}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=vt[dt]||"default";B[L]=(B[L]||0)+1;continue}}const A={};I.layout&&(A[dt]=String(I.layout)),I.transition&&(A[Qt]=String(I.transition)),I.background&&(A[Ht]=String(I.background)),I.image&&(A[Be]=String(I.image)),I.class&&(A[Hi]=String(I.class));for(const[X,ut]of Object.entries(I))["layout","transition","background","image","class"].includes(X)||(A[`custom-slidev-${X}`]=typeof ut=="object"?JSON.stringify(ut):String(ut));let E=P;const j=[];let N=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,X=>{const ut=`__CODE_TOKEN_NOTE_${j.length}__`;return j.push(X),ut});N=N.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,X=>{const ut=`__CODE_TOKEN_NOTE_${j.length}__`;return j.push(X),ut});let J="";const H=Array.from(N.matchAll(/<!--([\s\S]*?)-->/g));if(H.length>0){const X=H[H.length-1],ut=N.slice(X.index+X[0].length).trim();if(!ut||!ut.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=X[1].trim();L.startsWith("TODO:")||(J=L,w++),e&&(N=N.slice(0,X.index).trimEnd()+N.slice(X.index+X[0].length))}}e&&(N=N.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let X=0;X<j.length;X++)N=N.replace(`__CODE_TOKEN_NOTE_${X}__`,j[X]);if(E=N,J){for(let vt=0;vt<j.length;vt++)J=J.replace(`__CODE_TOKEN_NOTE_${vt}__`,j[vt]);const ut=`> [!NOTE] 💡 演讲备注
${J.split(/\r?\n/).map(vt=>`> ${vt}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${ut}`:ut}let K=!1;if(/<style\b/i.test(E)){K=!0;const X=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(X){for(const ut of X){const vt=ut.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();y=y?`${y}

${vt}`:vt}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const rt=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);rt&&(_+=rt.length);const lt=E.match(/```\w+\s+\{[^}]+\}/g);lt&&(T+=lt.length);const st=E.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,X=>lb(X,{...i,virtualFiles:c})||X),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(E=E.replace(/^::\w+::\s*$/gm,"")),s&&(E=sc(E)),a){let X=E.trim(),ut="";const vt=X.lastIndexOf("> [!NOTE] 💡 演讲备注");if(vt!==-1&&(ut=X.slice(vt),X=X.slice(0,vt).trim()),(I.layout==="image-left"||I.layout==="image-right")&&I.image){const L=String(I.image).trim(),F=I.layout==="image-left"?"image-left":"image-right",p=`![配图](${L})
{: custom-slidev-layout="${F}" }`;I.layout==="image-left"?X=`{{{col

${p}

${X}

}}}`:X=`{{{col

${X}

${p}

}}}`}if(I.background){const F=`![背景图](${String(I.background).trim()})
{: custom-slidev-role="background" }`;X=X?`${F}

${X}`:F}E=ut?`${X}

${ut}`:X}const Q=ub(E);A[Ht]&&Q.push(A[Ht]),A[Be]&&Q.push(A[Be]);for(const X of Q)S.add(X);const pt=/<[A-Z][a-zA-Z0-9]+/.test(E),bt=A[dt]||(D===1?g[dt]||"cover":"default");B[bt]=(B[bt]||0)+1,b.push({pageIndex:D++,pageAttrs:A,notes:J,rawMarkdown:E,hasVueComponent:pt,hasStyleTag:K,assetReferences:Q})}if(!f&&b.length>0){const O=b[0].rawMarkdown.match(/^#\s+(.+)$/m);O&&(f=O[1].trim())}y&&(g["custom-slidev-custom-css"]=y);let M=b.map(O=>`---

${O.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:g,slides:b,totalSlides:b.length,stats:{totalNotes:w,totalVClicks:_,totalShikiHighlights:T,totalSlots:x,discoveredAssets:Array.from(S),layoutDistribution:B},flattenedMarkdown:M,customCss:y}}function ub(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const r=n[1].split(/\s+/)[0].trim();r&&i.push(r)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const r=n[1].trim();r&&i.push(r)}return i}function aa(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function fb(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function pb(t,i,e=Pt){const n=t.filter(aa);let o=0;if(n.length>=i.length)for(let r=0;r<i.length;r++){const l=i[r],s=n[r];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),o++)}else for(let r=1;r<i.length;r++){const l=i[r],s=n[r-1];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),o++)}return o}async function hb(t,i=Pt){let e=!1,n=0;for(const o of t){if(aa(o)){e=!1;continue}const r=(o.markdown||o.content||"").trim();if(r==="::right::"||r.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[Tt]:"right"}).catch(()=>{}),n++)}return n}async function mb(t,i,e=Er){const n={};if(!i||i.length===0)return n;const o=[];for(const r of i){const l=new File([r.data],r.fileName,{type:"application/octet-stream"});o.push(l)}try{const r=await e("/data/assets",o);if(r!=null&&r.succMap)for(const[l,s]of Object.entries(r.succMap))n[l]=String(s)}catch(r){console.warn("上传本地静态资产失败，保留原路径:",r)}return Object.keys(n).length>0&&rb(t,n),n}async function gb(t){var T;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:r=!0,autoPreview:l=!0,plugin:s,api:a={}}=t,c=a.uploadFn||Er,d=a.createDocFn||Na,u=a.setAttrsFn||Pt,g=a.getChildBlocksFn||Xn,f=a.openTabFn||mt.openTab,y=a.showMessageFn||mt.showMessage;r&&o.length>0&&await mb(i,o,c);const h=fb(n),k=`/${h}`,b=await d(e,k,i.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const w=((T=i.slides[0])==null?void 0:T.pageAttrs)||{};await u(b,{...w,...i.docRootAttrs});const _=await g(b).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await pb(_,i.slides,u),await hb(_,u)),y(`🎉 成功导入 Slidev 演示文档《${h}》！`),l&&s&&(s.currentDocId=b,await f({app:s.app,doc:{id:b}}),s.openBottomPreviewTab&&s.openBottomPreviewTab()),b}function vb(t){const i=ft("file"),e=ft(!1),n=ft(!1),o=ft(""),r=ft(null),l=ft(null),s=ft(""),a=ft(0),c=ft(""),d=ft([]),u=ft(null),g=ft(""),f=ft([]),y=ft(""),h=ft(!0),k=ft(!0),b=ft(!0),w=ft(!0),_=St(()=>{const A=a.value;if(A===0)return"0 B";const E=1024,j=["B","KB","MB","GB"],N=Math.floor(Math.log(A)/Math.log(E));return`${(A/E**N).toFixed(1)} ${j[N]}`}),T=St(()=>{var A;return((A=u.value)==null?void 0:A.docRootAttrs["custom-slidev-theme"])||"default"}),x=St(()=>{var A;return d.value.length>0?d.value.length:((A=u.value)==null?void 0:A.stats.discoveredAssets.length)||0}),S=St(()=>{var E;const A=((E=u.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(A).map(([j,N])=>({name:j,count:N}))});async function B(A=za){try{const E=await A();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(f.value=E.notebooks.filter(j=>!j.closed),f.value.length>0&&!y.value&&(y.value=f.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function D(){var A;(A=r.value)==null||A.click()}function M(){l.value=null,s.value="",a.value=0,u.value=null,d.value=[],o.value=""}async function O(A){o.value="",l.value=A,s.value=A.name,a.value=A.size;try{if(A.name.toLowerCase().endsWith(".zip")){const j=await A.arrayBuffer(),N=await sb(j);if(!N.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=N.assets;const J=Yn(N.entryMarkdown,{stripNotesFromMarkdown:k.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,virtualFiles:N.virtualFiles});u.value=J,g.value=J.docTitle||A.name.replace(/\.zip$/i,"")}else{const j=await A.text();d.value=[];const N=A.path||"",J=N?N.replace(/[\\/][^\\/]+$/,""):"",H=Yn(j,{stripNotesFromMarkdown:k.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,baseDir:J||void 0});u.value=H,g.value=H.docTitle||A.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),o.value=`解析文件失败: ${E.message||String(E)}`}}function Z(){if(o.value="",!c.value.trim()){u.value=null;return}try{const A=Yn(c.value,{stripNotesFromMarkdown:k.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1});u.value=A,g.value=A.docTitle||"Slidev 演示文稿"}catch(A){o.value=`解析 Markdown 源码失败: ${A.message||String(A)}`}}async function I(){l.value?await O(l.value):c.value&&Z()}async function P(A){const E=A.target;E.files&&E.files[0]&&await O(E.files[0])}async function v(A){var E;e.value=!1,(E=A.dataTransfer)!=null&&E.files&&A.dataTransfer.files[0]&&await O(A.dataTransfer.files[0])}async function G(A=t){if(u.value){if(!y.value&&f.value.length>0&&(y.value=f.value[0].id),!y.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await gb({presentation:u.value,notebookId:y.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:b.value,autoPreview:w.value,plugin:A})}catch(E){console.error("导入 Slidev 演示失败:",E),o.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:r,selectedFile:l,selectedFileName:s,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:u,customDocTitle:g,notebooks:f,selectedNotebookId:y,optCleanHtml:h,optStripNotes:k,optUploadAssets:b,optAutoPreview:w,formattedFileSize:_,currentTheme:T,extractedAssetsCount:x,layoutChips:S,fetchNotebooks:B,triggerFileInput:D,clearFile:M,processFile:O,onFileSelected:P,onFileDrop:v,onTextChange:Z,reprocessCurrentInput:I,handleConfirmImport:G}}const bb={class:"spm-import-dialog"},yb={class:"spm-tabs-header"},kb={class:"spm-dialog-body"},wb={key:0,class:"spm-file-section"},xb={key:0,class:"spm-dropzone-prompt"},_b={key:1,class:"spm-dropzone-active"},Sb={class:"spm-file-badge"},Cb={class:"spm-file-size"},$b={key:1,class:"spm-text-section"},Ib={key:2,class:"spm-error-banner"},Ab={key:3,class:"spm-preview-card"},Tb={class:"spm-config-grid"},Bb={class:"spm-form-item"},Eb={class:"spm-form-item"},Mb=["value"],Db={class:"spm-stats-grid"},Lb={class:"spm-stat-box"},Pb={class:"spm-stat-value"},Rb={class:"spm-stat-box"},Ob={class:"spm-stat-value"},zb={class:"spm-stat-box"},Nb={class:"spm-stat-value"},Fb={class:"spm-stat-box"},jb={class:"spm-stat-value"},Hb={key:0,class:"spm-chips-row"},Ub={class:"spm-options-group"},Wb={class:"spm-checkbox-label"},Vb={class:"spm-checkbox-label"},Kb={class:"spm-checkbox-label"},qb={class:"spm-checkbox-label"},Gb={class:"spm-dialog-footer"},Zb=["disabled"],Yb=["disabled"],Jb={key:0},Xb={key:1},Qb=xe({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=ti("plugin"),{inputMode:o,isDragging:r,isImporting:l,errorMessage:s,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:u,parsedPresentation:g,customDocTitle:f,notebooks:y,selectedNotebookId:h,optCleanHtml:k,optStripNotes:b,optUploadAssets:w,optAutoPreview:_,formattedFileSize:T,currentTheme:x,layoutChips:S,fetchNotebooks:B,triggerFileInput:D,clearFile:M,onFileSelected:O,onFileDrop:Z,onTextChange:I,reprocessCurrentInput:P,handleConfirmImport:v}=vb(n);Dn(async()=>{await B()});async function G(){const E=await v();E&&(e("success",{docId:E}),e("close"))}function A(){e("close")}return(E,j)=>(tt(),nt("div",{class:"spm-modal-overlay",onClick:Ee(A,["self"])},[m("div",bb,[m("div",{class:"spm-dialog-header"},[j[18]||(j[18]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:A},"✕")]),m("div",yb,[m("button",{class:It(["spm-tab-btn",{active:ht(o)==="file"}]),onClick:j[0]||(j[0]=N=>o.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:It(["spm-tab-btn",{active:ht(o)==="text"}]),onClick:j[1]||(j[1]=N=>o.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",kb,[ht(o)==="file"?(tt(),nt("div",wb,[m("div",{class:It(["spm-dropzone",{dragover:ht(r),"has-file":!!ht(c)}]),onDragover:j[4]||(j[4]=Ee(N=>r.value=!0,["prevent"])),onDragleave:j[5]||(j[5]=Ee(N=>r.value=!1,["prevent"])),onDrop:j[6]||(j[6]=Ee((...N)=>ht(Z)&&ht(Z)(...N),["prevent"])),onClick:j[7]||(j[7]=(...N)=>ht(D)&&ht(D)(...N))},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:j[2]||(j[2]=(...N)=>ht(O)&&ht(O)(...N))},null,544),ht(c)?(tt(),nt("div",_b,[m("span",Sb,"📄 "+xt(ht(c)),1),m("span",Cb,"("+xt(ht(T))+")",1),m("button",{class:"spm-btn-text",onClick:j[3]||(j[3]=Ee((...N)=>ht(M)&&ht(M)(...N),["stop"]))},"更换文件")])):(tt(),nt("div",xb,[...j[19]||(j[19]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[co(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),co("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(tt(),nt("div",$b,[Te(m("textarea",{"onUpdate:modelValue":j[8]||(j[8]=N=>Yt(d)?d.value=N:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:j[9]||(j[9]=(...N)=>ht(I)&&ht(I)(...N))},null,544),[[ho,ht(d)]])])),ht(s)?(tt(),nt("div",Ib," ⚠️ "+xt(ht(s)),1)):Lt("",!0),ht(g)?(tt(),nt("div",Ab,[j[31]||(j[31]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",Tb,[m("div",Bb,[j[20]||(j[20]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(m("input",{"onUpdate:modelValue":j[10]||(j[10]=N=>Yt(f)?f.value=N:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[ho,ht(f)]])]),m("div",Eb,[j[21]||(j[21]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(m("select",{"onUpdate:modelValue":j[11]||(j[11]=N=>Yt(h)?h.value=N:null),class:"spm-select"},[(tt(!0),nt(Kt,null,ye(ht(y),N=>(tt(),nt("option",{key:N.id,value:N.id},xt(N.name),9,Mb))),128))],512),[[Bu,ht(h)]])])]),m("div",Db,[m("div",Lb,[m("span",Pb,xt(ht(g).totalSlides),1),j[22]||(j[22]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Rb,[m("span",Ob,xt(ht(x)),1),j[23]||(j[23]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",zb,[m("span",Nb,xt(ht(g).stats.totalNotes),1),j[24]||(j[24]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Fb,[m("span",jb,xt(ht(u)),1),j[25]||(j[25]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ht(S).length>0?(tt(),nt("div",Hb,[j[26]||(j[26]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),nt(Kt,null,ye(ht(S),N=>(tt(),nt("span",{key:N.name,class:"spm-chip-badge"},xt(N.name)+": "+xt(N.count),1))),128))])):Lt("",!0),m("div",Ub,[m("label",Wb,[Te(m("input",{"onUpdate:modelValue":j[12]||(j[12]=N=>Yt(k)?k.value=N:null),type:"checkbox",onChange:j[13]||(j[13]=(...N)=>ht(P)&&ht(P)(...N))},null,544),[[Un,ht(k)]]),j[27]||(j[27]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Vb,[Te(m("input",{"onUpdate:modelValue":j[14]||(j[14]=N=>Yt(b)?b.value=N:null),type:"checkbox",onChange:j[15]||(j[15]=(...N)=>ht(P)&&ht(P)(...N))},null,544),[[Un,ht(b)]]),j[28]||(j[28]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Kb,[Te(m("input",{"onUpdate:modelValue":j[16]||(j[16]=N=>Yt(w)?w.value=N:null),type:"checkbox"},null,512),[[Un,ht(w)]]),j[29]||(j[29]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",qb,[Te(m("input",{"onUpdate:modelValue":j[17]||(j[17]=N=>Yt(_)?_.value=N:null),type:"checkbox"},null,512),[[Un,ht(_)]]),j[30]||(j[30]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Lt("",!0)]),m("div",Gb,[m("button",{class:"spm-btn-secondary",disabled:ht(l),onClick:A}," 取消 ",8,Zb),m("button",{class:"spm-btn-primary",disabled:!ht(g)||ht(l),onClick:G},[ht(l)?(tt(),nt("span",Jb,"⏳ 正在导入生成中...")):(tt(),nt("span",Xb,"🚀 确认导入思源笔记"))],8,Yb)])])]))}}),t1=Oe(Qb,[["__scopeId","data-v-59ad789d"]]);function ca(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function e1(t,i){var s;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",r=i.activeBlockType||"";if(ca(r)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===o}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var u,g;return((u=d.blocks)==null?void 0:u.some(f=>f.id===e))||((g=d.allBlockIds)==null?void 0:g.includes(e))}),a)||n&&n!==e&&(a=t.find(d=>{var u,g;return((u=d.blocks)==null?void 0:u.some(f=>f.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=t.find(d=>{var u;return(u=d.noteBlocks)==null?void 0:u.some(g=>g.id===e||g.id===n)}),a))return a;const c=(s=i.activeBlockAttrs)==null?void 0:s[Tt];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var u,g;return((u=d.frontmatter)==null?void 0:u.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),a))return a}return t[0]||null}function Ar(t,i){const e=(t.blocks||[]).filter(l=>{const s=(l.content||l.rawMarkdown||"").trim();return s&&s!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const s=(l.content||l.rawMarkdown||"").trim();s&&(l.type==="h"||s.startsWith("#")?n.push(s.replace(/^#+\s*/,"")):o.push(s.slice(0,50)))}const r=[];return n.length>0&&r.push(`【核心重点】：${n.join("、")}`),o.length>0&&(r.push("【口播要点】："),o.slice(0,3).forEach((l,s)=>{r.push(`${s+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function da(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Ar(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Ar(t),isAiGenerated:!1}}async function i1(t,i){return(await da(t,i)).notes}function n1(t){let i=null;function e(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const E=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(E,1200):i=setTimeout(E,1200)}async function n(A){const E=t.activeBlockId.value||t.currentDocId.value;if(E){for(const[j,N]of Object.entries(A))t.activeBlockAttrs.value[j]=N;if(Rt.setBlockAttrOverride(E,A),ie(E,A),dt in A){const j=A[dt];t.currentPageDividerLayout.value=j,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=j)}if(Zt in A){const j=A[Zt];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=j)}e("保存中...");try{await Pt(E,A),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function o(A,E){const j=t.activeBlockId.value||t.currentDocId.value;if(j){t.activeBlockAttrs.value[A]=E,Rt.setBlockAttrOverride(j,{[A]:E}),ie(j,{[A]:E}),A===dt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),A===Zt&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),e("保存中...");try{await Pt(j,{[A]:E}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}function r(){const A=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(A?t.activeBlockId.value:"")||t.currentDocId.value}async function l(A,E){const j=r();if(j){j===t.activeBlockId.value&&(t.activeBlockAttrs.value[A]=E),Rt.setBlockAttrOverride(j,{[A]:E}),ie(j,{[A]:E}),A===dt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),A===Zt&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),e("保存中...");try{await Pt(j,{[A]:E}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function s(A,E){const j=r();if(!j)return;const N={[dt]:A,[Zt]:E};j===t.activeBlockId.value&&(t.activeBlockAttrs.value[dt]=A,t.activeBlockAttrs.value[Zt]=E),t.currentPageDividerLayout.value=A,Rt.setBlockAttrOverride(j,N),ie(j,N),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=A,t.targetSlide.value.frontmatter.layoutRatio=E),e("应用排版中...");try{await Pt(j,N),e("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("应用失败")}}async function a(A,E){var N;const j=t.currentDocId.value||t.activeBlockId.value;if(j){t.activeBlockAttrs.value[A]=E,Rt.setBlockAttrOverride(j,{[A]:E}),ie(j,{[A]:E}),(N=t.latestDoc.value)!=null&&N.config&&(A===yn&&(t.latestDoc.value.config.theme=E),A===kn&&(t.latestDoc.value.config.aspectRatio=E),A===wn&&(t.latestDoc.value.config.defaultTransition=E)),e("更新中...");try{await Pt(j,{[A]:E}),e("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(j)}catch{e("更新失败")}}}async function c(){(t.videoAutoplay.value?"false":"true")==="true"?(await n({[Ii]:"true",[Fi]:"true"}),t.activeBlockAttrs.value[Ii]="true",t.activeBlockAttrs.value[Fi]="true"):(await o(Ii,"false"),t.activeBlockAttrs.value[Ii]="false")}async function d(){const A=t.videoLoop.value?"false":"true";await o(Qn,A)}async function u(){const A=t.videoMuted.value?"false":"true";await o(Fi,A)}async function g(){const A=t.videoControls.value?"false":"true";await o(to,A)}async function f(A){var H;const E=t.activeBlockId.value;if(!E)return;const j=t.rawSnippet.value||"",N=mi(j)||"",J=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const K={[Vt]:"background",[dt]:""};J&&N&&(t.pageBackground.value=N,await Pt(J,{[Ht]:N}).catch(()=>{}),Rt.setBlockAttrOverride(J,{[Ht]:N}),ie(J,{[Ht]:N}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=N)),await n(K)}else(A===eo||A===io)&&await n({[dt]:A,[Vt]:""});else{const K={[Vt]:"",[dt]:""};if(t.activeBlockAttrs.value[Ht]==="true"&&(K[Ht]=""),J&&N&&t.pageBackground.value===N&&(t.pageBackground.value="",await Pt(J,{[Ht]:""}).catch(()=>{}),Rt.setBlockAttrOverride(J,{[Ht]:""}),ie(J,{[Ht]:""}),(H=t.targetSlide.value)!=null&&H.frontmatter&&delete t.targetSlide.value.frontmatter.background),await n(K),typeof document<"u"){const rt=document.querySelector(`.protyle-wysiwyg [data-node-id="${E}"]`),lt=rt==null?void 0:rt.closest('[data-type="NodeListItem"]'),st=lt==null?void 0:lt.getAttribute("data-node-id");if(st&&st!==E){const Q={[dt]:"",[Vt]:""};ie(st,Q),Rt.setBlockAttrOverride(st,Q),await Pt(st,Q).catch(()=>{})}}}}async function y(A){var st,Q,pt,bt,X,ut,vt,L;const N=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map(F=>`> ${F}`).join(`
`)}
{: custom-slidev-note="true"}`,J=((st=t.latestDoc.value)==null?void 0:st.slides)||[],H=t.targetSlide.value,K=H?J.findIndex(F=>F===H):-1;let rt=null;if(K!==-1&&K<J.length-1){const F=J[K+1];rt=await an("markdown",N,F.startBlockId)}else{const F=((Q=H==null?void 0:H.noteBlocks)==null?void 0:Q.slice(-1)[0])||((pt=H==null?void 0:H.blocks)==null?void 0:pt.slice(-1)[0]),p=(F==null?void 0:F.id)||(H==null?void 0:H.startBlockId);p?rt=await an("markdown",N,void 0,p):rt=await Mr("markdown",N,t.currentDocId.value)}const lt=((ut=(X=(bt=rt==null?void 0:rt[0])==null?void 0:bt.doOperations)==null?void 0:X[0])==null?void 0:ut.id)||((vt=rt==null?void 0:rt[0])==null?void 0:vt.id);return lt&&(await Pt(lt,{[se]:"true"}),Rt.setBlockAttrOverride(lt,{[se]:"true"}),Di(lt,(L=t.plugin)==null?void 0:L.app)),t.plugin&&await t.plugin.compileCurrentDocument(),lt}async function h(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){e("取消中...");try{await Pt(A,{[se]:"","slidev-note":""}),Rt.setBlockAttrOverride(A,{[se]:"","slidev-note":""}),ie(A,{[se]:"","slidev-note":""}),delete t.activeBlockAttrs.value[se],delete t.activeBlockAttrs.value["slidev-note"],e("已取消备注"),mt.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 取消讲稿备注失败:",E),e("取消失败"),mt.showMessage("取消讲稿备注失败")}}else{e("转换中...");try{let E=t.rawSnippet.value;try{const H=await ja(A);H!=null&&H.kramdown&&(E=H.kramdown)}catch{}const J=`> [!NOTE] 💡 演讲备注
${(Fr(E)||E.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slidev-note="true"}`;await Hs("markdown",J,A),await Pt(A,{[se]:"true"}),Rt.setBlockAttrOverride(A,{[se]:"true"}),ie(A,{[se]:"true"}),t.activeBlockAttrs.value[se]="true",t.activeBlockType.value="NodeCallout",e("已设为讲稿备注"),mt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",E),e("设置失败"),mt.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await y(),mt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){mt.showMessage("插入讲稿备注块失败"),console.error(A)}}function b(){var j;const A=t.currentSlideNoteBlockId.value;if(!A){mt.showMessage("未找到本页关联的讲稿备注块");return}Di(A,(j=t.plugin)==null?void 0:j.app)?mt.showMessage("已在编辑区定位讲稿备注块"):mt.showMessage("定位讲稿备注块失败")}async function w(){var j;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};mt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const E=await da(A,Dr);if(E.notes){const N=t.currentSlideNoteBlockId.value;if(N){const J=`> [!NOTE] 💡 演讲备注
${E.notes.split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slidev-note="true"}`;await Hs("markdown",J,N),await Pt(N,{[se]:"true"}),Rt.setBlockAttrOverride(N,{[se]:"true"}),Di(N,(j=t.plugin)==null?void 0:j.app)}else await y(E.notes);E.isAiGenerated?mt.showMessage("思源 AI 演讲提词卡生成成功！"):mt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}function _(){t.elemClick.value?o($e,""):o($e,"+1")}function T(A){o($e,A)}function x(A){o(Ve,A)}function S(A){(t.activeBlockAttrs.value[Tt]||"")===A?o(Tt,""):o(Tt,A)}function B(A){t.elemShikiLines.value=A,o(Li,A)}function D(A){t.elemMaxHeight.value=A,o(xn,A)}async function M(){const A=t.currentSlideLayout.value==="three-cols-header";await o(Tt,A?"col-1":"left"),mt.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function O(){const A=t.activeBlockId.value;if(!A)return;const E={[$e]:"",[Ve]:"",[Tt]:"",[Li]:"",[xn]:"",[se]:"","slidev-note":"",[dt]:"",[Zt]:"",[Vt]:"",[Qt]:"",[Ht]:"",[Be]:"",[Ii]:"",[Qn]:"",[Fi]:"",[to]:""};if(ie(A,E),await Pt(A,E),Rt.clearBlockAttrOverride(A),typeof document<"u"){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),N=j==null?void 0:j.closest('[data-type="NodeListItem"]'),J=N==null?void 0:N.getAttribute("data-node-id");J&&J!==A&&(ie(J,E),await Pt(J,E).catch(()=>{}),Rt.clearBlockAttrOverride(J))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",mt.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function Z(){if(t.activeBlockId.value)try{await an("markdown","---",t.activeBlockId.value,void 0),mt.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function I(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await an("markdown","---",void 0,A),mt.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function P(){if(t.activeBlockId.value)try{await Fa(t.activeBlockId.value),mt.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("删除失败")}}function v(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const A=oa(t.latestDoc.value);sa("presentation.html",A)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function G(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}ra(t.latestDoc.value)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:e,saveAttrs:n,saveAttr:o,savePageAttr:l,applyPageLayoutAndRatio:s,saveDocAttr:a,onToggleVideoAutoplay:c,onToggleVideoLoop:d,onToggleVideoMuted:u,onToggleVideoControls:g,onImageRoleChange:f,onToggleNoteBlock:h,createNoteBlockOnCurrentSlide:y,onAddNoteBlock:k,onLocateNoteBlock:b,onGenerateNotesWithAI:w,toggleElemClick:_,onElemClickStepChange:T,onElemMotionChange:x,onElemSlotChange:S,onElemShikiLinesChange:B,onElemMaxHeightChange:D,onSetTwoColsContrast:M,onClearBlockAttrs:O,onInsertDividerBefore:Z,onInsertDividerAfter:I,onDeleteCurrentBlock:P,onExportHtml:v,onExportPdf:G}}const o1={class:"spm-slidev-inspector"},s1={class:"spm-inspector-topbar"},r1={class:"spm-inspector-title"},l1={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},a1={class:"spm-inspector-topbar-actions"},c1={class:"spm-target-banner"},d1={class:"spm-target-info"},u1=["aria-label"],f1={key:0,class:"spm-save-status"},p1=["title"],h1={class:"spm-inspector-body"},m1=xe({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ti("plugin"),n=ft(!1);function o(it){n.value=!1,c.value=it.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(it.docId)}const r=ft(""),l=ft(""),s=ft({}),a=ft(""),c=ft(""),d=ft(""),u=ft(""),g=ft(""),f=ft(null),y=ft(""),h=ft("");function k(){var yt;const it=r.value||c.value;it&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(it).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const b=St(()=>ca(l.value)),w=St(()=>l.value==="NodeCodeBlock"),_=ft(!1),T=St(()=>{if(_.value||W.value)return!0;const it=a.value||"";return!!mi(it)}),x=St(()=>{const it=l.value||"";if(it==="NodeVideo"||it==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),S=St(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),B=St(()=>{const it=r.value||c.value||"";return it.length>8?it.slice(-8):it||"无"}),D=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),M=St(()=>{if(b.value)return"分页符 (---)";if(S.value)return"全局文档";if(x.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),O=St(()=>b.value?"tag-divider":S.value?"tag-doc":"tag-block"),Z=St(()=>s.value[dt]||"default"),I=St(()=>s.value[Qt]||"slide-left"),P=ft(""),v=ft(""),G=St(()=>s.value[un]||"inherit"),A=St(()=>{var it;return e1((it=f.value)==null?void 0:it.slides,{activeBlockId:r.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:u.value,activeBlockAttrs:s.value})}),E=St(()=>{var it;return((it=A.value)==null?void 0:it.notes)||""}),j=St(()=>{var it,yt,$t;return(($t=(yt=(it=A.value)==null?void 0:it.noteBlocks)==null?void 0:yt[0])==null?void 0:$t.id)||""}),N=St(()=>{var Et,Ft,Dt,de,Bo,ci;if(b.value){const Xt=s.value[dt]||s.value["custom-slidev-layout"];if(Xt)return Xt}const it=s.value[Tt]||s.value["custom-slidev-slot"];if(it&&["col-1","col-2","col-3"].includes(it))return"three-cols-header";if(g.value)return g.value;const yt=u.value||(b.value?r.value:"");if(yt){const Xt=Rt.getBlockAttrOverride(yt);if(Xt!=null&&Xt[dt])return Xt[dt]}if(yt&&((Et=f.value)!=null&&Et.slides)){const Xt=f.value.slides.find(Oi=>Oi.startBlockId===yt);if((Ft=Xt==null?void 0:Xt.frontmatter)!=null&&Ft.layout)return Xt.frontmatter.layout}if((de=(Dt=A.value)==null?void 0:Dt.frontmatter)!=null&&de.layout)return A.value.frontmatter.layout;if((ci=(Bo=A.value)==null?void 0:Bo.blocks)!=null&&ci.some(Xt=>Xt.slot==="col-1"||Xt.slot==="col-2"||Xt.slot==="col-3"))return"three-cols-header";const $t=Rt.getBlockAttrOverride(c.value);return $t!=null&&$t[dt]?$t[dt]:"default"}),J=St(()=>{var yt,$t;if(b.value){const Et=s.value[Zt]||s.value["custom-slidev-layout-ratio"];if(Et)return Et}const it=u.value||(b.value?r.value:"");if(it){const Et=Rt.getBlockAttrOverride(it);if(Et!=null&&Et[Zt])return Et[Zt]}return(($t=(yt=A.value)==null?void 0:yt.frontmatter)==null?void 0:$t.layoutRatio)||""});function H(it){if(!it||(it.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const $t=Array.from(it.querySelectorAll(":scope > [data-node-id]"));if($t.length<2)return null;const Et=$t.length,Ft=$t.map(ci=>{const Xt=ci.getAttribute("style")||"",Oi=Xt.match(/calc\(\s*([\d.]+)%/);if(Oi)return parseFloat(Oi[1]);const nn=Xt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return nn?parseFloat(nn[1]):null});let Dt="",de=!1;if(Ft.some(ci=>ci!==null)){de=!0;const ci=Ft.reduce((Bt,ue)=>Bt+(ue||0),0),Xt=Ft.filter(Bt=>Bt===null).length,Oi=Xt>0?Math.max(0,100-ci)/Xt:100/$t.length,nn=Ft.map(Bt=>Bt!==null?Bt:Oi),Ba=nn.reduce((Bt,ue)=>Bt+ue,0)||1,on=nn.map(Bt=>Bt/Ba*100);if(on.length===2){const[Bt]=on;if(Bt>=48&&Bt<=52)Dt="1:1";else if(Bt>=31&&Bt<=35)Dt="1:2";else if(Bt>=65&&Bt<=69)Dt="2:1";else if(Bt>=28&&Bt<=32)Dt="3:7";else if(Bt>=68&&Bt<=72)Dt="7:3";else if(Bt>=38&&Bt<=42)Dt="4:6";else if(Bt>=58&&Bt<=62)Dt="6:4";else{const ue=Math.round(Bt);Dt=`${ue}:${100-ue}`}}else if(on.length===3){const[Bt,ue,di]=on;if(Bt>=31&&Bt<=35&&ue>=31&&ue<=35&&di>=31&&di<=35)Dt="1:1:1";else if(Bt>=23&&Bt<=27&&ue>=48&&ue<=52&&di>=23&&di<=27)Dt="1:2:1";else if(Bt>=48&&Bt<=52&&ue>=23&&ue<=27&&di>=23&&di<=27)Dt="2:1:1";else if(Bt>=23&&Bt<=27&&ue>=23&&ue<=27&&di>=48&&di<=52)Dt="1:1:2";else{const Fs=Math.round(Bt),js=Math.round(ue);Dt=`${Fs}:${js}:${100-Fs-js}`}}else Dt=on.map(Bt=>Math.round(Bt)).join(":")}else de=!1,Dt=Et===3?"1:1:1":"1:1";return{hasSuperBlock:!0,colCount:Et,ratio:Dt,isCustomWidth:de,recommendedLayout:Et===3?"three-cols-header":"two-cols"}}function K(it){if(!(it!=null&&it.blocks))return null;for(const yt of it.blocks){const $t=yt.rawNode;if($t&&oe($t)&&ni($t)){const Ft=Bn($t).length,Dt=ds($t);return{hasSuperBlock:!0,colCount:Ft,ratio:Dt||(Ft===3?"1:1:1":"1:1"),isCustomWidth:!!Dt,recommendedLayout:Ft===3?"three-cols-header":"two-cols"}}}return null}const rt=St(()=>{var it;if(typeof document<"u"){const yt=r.value;if(yt){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Et){const Ft=Et.getAttribute("data-type")==="NodeSuperBlock"?Et:Et.closest('[data-type="NodeSuperBlock"]');if(Ft){const Dt=H(Ft);if(Dt)return Dt}}}const $t=u.value||(b.value?r.value:"");if($t){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${$t}"]`);if(Et){let Ft=Et.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(it=Ft.classList)!=null&&it.contains("protyle-wysiwyg__block--hr"));){const Dt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Dt){const de=H(Dt);if(de)return de}Ft=Ft.nextElementSibling}}}else{const Et=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Dt of Ft)if(!Et||Dt.compareDocumentPosition(Et)&Node.DOCUMENT_POSITION_FOLLOWING){const de=H(Dt);if(de)return de}}}return K(A.value)}),lt=St(()=>{var it;return((it=rt.value)==null?void 0:it.ratio)||""}),st=St(()=>{const it=l.value||"";if(it==="NodeSuperBlock"||it==="s"||it==="sb")return!0;if(typeof document<"u"&&r.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${r.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),Q=St(()=>{var it;return((it=A.value)==null?void 0:it.pageIndex)||1}),pt=St(()=>!!(s.value[se]||s.value["slidev-note"])),bt=St(()=>{var yt;if(s.value[$e])return s.value[$e];const it=r.value;if(it&&((yt=A.value)!=null&&yt.blocks)){const $t=A.value.blocks.find(Et=>Et.id===it);if($t!=null&&$t.clicks)return $t.clicks}return""}),X=St(()=>{var yt;if(s.value[Ve])return s.value[Ve];const it=r.value;if(it&&((yt=A.value)!=null&&yt.blocks)){const $t=A.value.blocks.find(Et=>Et.id===it);if($t!=null&&$t.motion)return typeof $t.motion=="string"?$t.motion:JSON.stringify($t.motion)}return""}),ut=St(()=>{var yt;if(s.value[Tt])return s.value[Tt];const it=r.value;if(it&&((yt=A.value)!=null&&yt.blocks)){const $t=A.value.blocks.find(Et=>Et.id===it);if($t!=null&&$t.slot)return $t.slot}return""}),vt=ft(""),L=ft(""),F=St(()=>s.value[Ii]==="true"),p=St(()=>s.value[Qn]==="true"),U=St(()=>s.value[Fi]==="true"),z=St(()=>s.value[to]!=="false"),C=St(()=>{var it,yt;return((yt=(it=f.value)==null?void 0:it.config)==null?void 0:yt.theme)||s.value[yn]||"default"}),$=St(()=>{var it,yt;return((yt=(it=f.value)==null?void 0:it.config)==null?void 0:yt.aspectRatio)||s.value[kn]||"16/9"}),R=St(()=>{var it,yt;return((yt=(it=f.value)==null?void 0:it.config)==null?void 0:yt.defaultTransition)||s.value[wn]||"slide-left"}),q=St(()=>{var it,yt;return((yt=(it=f.value)==null?void 0:it.config)==null?void 0:yt.spacing)||s.value[qo]||"normal"}),W=St(()=>{var Ft,Dt;if((s.value[Vt]||s.value["slidev-role"])===Or||s.value[Ht]==="true")return"background";const yt=s.value[dt]||s.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const $t=a.value||"",Et=mi($t);if(Et&&((Dt=(Ft=A.value)==null?void 0:Ft.frontmatter)!=null&&Dt.background)){const de=A.value.frontmatter.background;if(de===Et||de.endsWith(Et)||Et.endsWith(de))return"background"}return""}),V=St(()=>!!(s.value[$e]||s.value[Ve]||s.value[Tt]||s.value[Li]||s.value[se]||s.value["slidev-note"]||s.value[Vt]||s.value[dt]||s.value[Ii]||s.value[Qn]||s.value[Fi]||s.value[to])),{saveAttr:Y,savePageAttr:ot,applyPageLayoutAndRatio:et,saveDocAttr:at,onToggleVideoAutoplay:_t,onToggleVideoLoop:kt,onToggleVideoMuted:Mt,onToggleVideoControls:qt,onImageRoleChange:Gt,onToggleNoteBlock:ne,onAddNoteBlock:Nt,onLocateNoteBlock:qe,onGenerateNotesWithAI:ee,toggleElemClick:Jt,onElemClickStepChange:bi,onElemMotionChange:Pi,onElemSlotChange:Ao,onElemShikiLinesChange:To,onElemMaxHeightChange:Rn,onSetTwoColsContrast:yi,onClearBlockAttrs:Ri,onInsertDividerBefore:pa,onInsertDividerAfter:Os,onDeleteCurrentBlock:ha,onExportHtml:ma,onExportPdf:ga}=n1({activeBlockId:r,activeBlockType:l,activeBlockAttrs:s,rawSnippet:a,currentDocId:c,currentPageDividerId:u,currentPageDividerLayout:g,latestDoc:f,targetSlide:A,currentSlideNoteBlockId:j,currentSlideLayout:N,isNoteBlock:pt,elemClick:bt,videoAutoplay:F,videoLoop:p,videoMuted:U,videoControls:z,pageBackground:P,pageImage:v,elemShikiLines:vt,elemMaxHeight:L,saveStatus:y,plugin:e});function va(it){Y(dt,it)}function ba(it){ot(Zt,it)}function zs(it){if(!it)return;const yt=it.recommendedLayout||(it.colCount===3?"three-cols-header":"two-cols"),$t=it.ratio||(it.colCount===3?"1:1:1":"1:1");et(yt,$t)}function ya(it){ot(Zt,it)}function ka(it){Y(Qt,it)}function wa(it){P.value=it,Y(Ht,it)}function xa(it){v.value=it,Y(Be,it)}function _a(it){Y(un,it==="inherit"?"":it)}function Sa(it){at(yn,it)}function Ca(it){at(kn,it)}function $a(it){at(wn,it)}function Ia(it){at(qo,it)}function Ns(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function Aa(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Ta(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(it){r.value=it.id,l.value=it.type,s.value={...it.attrs},a.value=it.content||it.markdown||"",d.value=it.topBlockId||it.id,u.value=it.pageDividerId||"",g.value=it.pageDividerLayout||"",it.rootId?c.value=it.rootId:(it.type==="doc"||it.type==="NodeDocument")&&it.id&&(c.value=it.id),P.value=it.attrs[Ht]||"",v.value=it.attrs[Be]||"",vt.value=it.attrs[Li]||"",L.value=it.attrs[xn]||"",_.value=!!it.isImage},updateDocument(it){f.value=it,c.value=it.docId},openImportDialog(){n.value=!0},setCurrentDocId(it){c.value=it}}),(it,yt)=>(tt(),nt("div",o1,[m("div",s1,[m("div",r1,[(tt(),nt("svg",l1,[...yt[2]||(yt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=m("span",null,"演示配置",-1))]),m("div",a1,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=$t=>n.value=!0)},[ct(gt,{name:"import"}),yt[4]||(yt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ns},[ct(gt,{name:"split-preview"}),yt[5]||(yt[5]=m("span",null,"分屏预览",-1))])])]),m("div",c1,[m("div",d1,[m("span",{class:It(["spm-target-tag",O.value])},xt(M.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:k},[ct(gt,{name:"copy"}),m("span",null,"#"+xt(B.value),1)],8,u1)]),y.value?(tt(),nt("span",f1,"● "+xt(y.value),1)):Lt("",!0)]),D.value?(tt(),nt("div",{key:0,class:"spm-context-quote",title:a.value},xt(D.value),9,p1)):Lt("",!0),m("div",h1,[b.value?(tt(),Me(jm,{key:0,"page-layout":Z.value,"page-layout-ratio":J.value,"detected-sb-ratio":lt.value,"detected-sb-info":rt.value,"page-transition":I.value,"page-background":P.value,"page-spacing":G.value,"page-image":v.value,"page-notes":E.value,"page-index":Q.value,"onUpdate:pageLayout":va,"onUpdate:pageLayoutRatio":ba,onApplySuperBlockLayout:zs,"onUpdate:pageTransition":ka,"onUpdate:pageBackground":wa,"onUpdate:pageSpacing":_a,"onUpdate:pageImage":xa,onAddNoteBlock:ht(Nt),onLocateNoteBlock:ht(qe),onGenerateNotes:ht(ee),onInsertDividerAfter:ht(Os),onDeleteDivider:ht(ha)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):r.value&&!S.value?(tt(),Me(kv,{key:1,"elem-click":bt.value,"elem-motion":X.value,"elem-slot":ut.value,"elem-shiki-lines":vt.value,"elem-max-height":L.value,"is-code-block":w.value,"is-image":T.value,"is-video":x.value,"is-super-block":st.value,"detected-sb-info":rt.value,"video-autoplay":F.value,"video-loop":p.value,"video-muted":U.value,"video-controls":z.value,"has-block-attrs":V.value,"is-note":pt.value,"image-role":W.value,"current-slide-layout":N.value,onToggleNote:ht(ne),onToggleElemClick:ht(Jt),onToggleVideoAutoplay:ht(_t),onToggleVideoLoop:ht(kt),onToggleVideoMuted:ht(Mt),onToggleVideoControls:ht(qt),"onUpdate:imageRole":ht(Gt),"onUpdate:elemClick":ht(bi),"onUpdate:elemMotion":ht(Pi),"onUpdate:elemSlot":ht(Ao),"onUpdate:elemShikiLines":ht(To),"onUpdate:elemMaxHeight":ht(Rn),onApplySuperBlockLayout:zs,onApplySuperBlockRatio:ya,onInsertDividerBefore:ht(pa),onInsertDividerAfter:ht(Os),onSetTwoColsContrast:ht(yi),onClearBlockAttrs:ht(Ri)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(tt(),Me(Xv,{key:2,"doc-theme":C.value,"doc-aspect-ratio":$.value,"doc-default-transition":R.value,"doc-spacing":q.value,"onUpdate:docTheme":Sa,"onUpdate:docAspectRatio":Ca,"onUpdate:docDefaultTransition":$a,"onUpdate:docSpacing":Ia,onOpenBottomPreview:Ns,onOpenPresenter:Aa,onAiAutoSplit:Ta,onExportHtml:ht(ma),onExportPdf:ht(ga)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(tt(),Me(t1,{key:1,onClose:yt[1]||(yt[1]=$t=>n.value=!1),onSuccess:o})):Lt("",!0)]))}}),Pn=new Ls;let pi=null,We=null;function g1(t,i){pi&&ua(),pi=Zl(Vh),pi.provide("plugin",i),pi.provide("sandboxBridge",Pn);const e=pi.mount(t);return We=e,e}function ua(t){pi&&(pi.unmount(),pi=null,We=null)}let hi=null,we=null;function v1(t,i){hi&&fa(),hi=Zl(m1),hi.provide("plugin",i),hi.provide("sandboxBridge",Pn);const e=hi.mount(t);return we=e,e}function fa(t){hi&&(hi.unmount(),hi=null,we=null)}function b1(t,i){we!=null&&we.updateDocument&&we.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):Pn.updateSlides(t.slides,t.config,t.fullMarkdown)}function cs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):Pn.highlightElement(t)}function Jn(t){we!=null&&we.setActiveBlock&&we.setActiveBlock(t)}function y1(){return we!=null&&we.openImportDialog?(we.openImportDialog(),!0):!1}function k1(t,i){const e=[];let o=0;for(let r=0;r<t.length;r++){const l=t[r];if(no(l)){o=0;continue}const s=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||s.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||s.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&r<t.length-1){const c=t[r+1];no(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const w1=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"cover"},{key:Qt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"two-cols"},{key:Qt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"fact"},{key:Qt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"intro"},{key:Qt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"quote"},{key:Qt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:$e,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:$e,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Li,value:"1-3"}]}];class Vo{getPresetTemplates(){return w1}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Qt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = '${Qt}' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Qt]:e}),s++)}return{updatedCount:s}}async batchUpdateLayout(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),s++)}return{updatedCount:s}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function x1(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{y1()||mt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Pt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const r=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(r==null?void 0:r.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}const i=await Xn(t.currentDocId).catch(()=>[]);if(!i||i.length===0){mt.showMessage("当前文档无内容，无需断页");return}const e=i.map(r=>({id:r.id,type:r.type,subType:r.subType,content:r.content||"",markdown:r.markdown||""})),n=k1(e);if(n.length===0){mt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}mt.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const r of n)try{await an("markdown","---",void 0,r.blockId),await Pt(r.blockId,{"custom-slidev-layout":r.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}mt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,u;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}mt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await Xn(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},r=`> [!NOTE] 💡 演讲备注
${(await i1(e,Dr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Mr("markdown",r,t.currentDocId).catch(()=>null),s=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((u=l==null?void 0:l[0])==null?void 0:u.id);s&&(await Pt(s,{"custom-slidev-note":"true"}),Rt.setBlockAttrOverride(s,{"custom-slidev-note":"true"}),Di(s,t.app)),mt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Vo,e=i.buildTransitionStatsSql(),n=await bn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);mt.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Vo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),mt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):mt.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Vo().batchUpdateTransitions("fade","slide-left",n=>bn(n).catch(()=>[]),(n,o)=>Pt(n,o));mt.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&mt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{mt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?mt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):mt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Ko);i.success?mt.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):mt.showMessage(`同步失败：${i.error}`)}})}class _1{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=document.querySelector("[data-doc-id]"),l=r==null?void 0:r.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=i.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),s=l==null?void 0:l.getAttribute("data-node-id");if(s)return s;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||e}async switchToDocGlobalInspector(i,e){var r;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((r=l==null?void 0:l.innerText)==null?void 0:r.trim())||""}const o=await Ze(i).catch(()=>({}));Jn({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),cs(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const r=Di(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),s=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,s,n,o);else{let c="",d="";if(o!=null&&o.slides){const u=o.slides.find(g=>{var f,y,h;return g.startBlockId===i||((f=g.blocks)==null?void 0:f.some(k=>k.id===i))||((y=g.allBlockIds)==null?void 0:y.includes(i))||((h=g.noteBlocks)==null?void 0:h.some(k=>k.id===i))});u!=null&&u.startBlockId&&(c=u.startBlockId),(a=u==null?void 0:u.frontmatter)!=null&&a.layout&&(d=u.frontmatter.layout)}Ze(i).then(async u=>{if(c&&!d){const g=Rt.getBlockAttrOverride(c);if(g!=null&&g[dt]||g!=null&&g["custom-slidev-layout"])d=g[dt]||g["custom-slidev-layout"]||"";else{const f=await Ze(c).catch(()=>({}))||{};d=f[dt]||f["custom-slidev-layout"]||"",f&&Object.keys(f).length>0&&Rt.setBlockAttrOverride(c,f)}}Jn({id:i,rootId:n,type:s||"NodeParagraph",attrs:u||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return r}async syncInspectorBlock(i,e,n,o,r){var I,P,v,G,A,E,j,N;let l=i,s=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const J=c.getAttribute("data-node-id");if(J){const H=await Ze(J).catch(()=>({}))||{},K=Rt.getBlockAttrOverride(J)||{},rt={...H,...K};(rt[se]||rt["slidev-note"])&&(l=c,s=J,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,u=(d==null?void 0:d.getAttribute("data-node-id"))||s,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((I=d==null?void 0:d.classList)!=null&&I.contains("hr")),f=a==="NodeCodeBlock",y=((P=l.innerText)==null?void 0:P.trim())||"",h=await Ze(s).catch(()=>({}))||{},k=Rt.getBlockAttrOverride(s)||{},b={...h,...k};let w="",_="";if(g)w=s,_=b[dt]||b["custom-slidev-layout"]||"";else{let J=d.previousElementSibling;for(;J;){const H=J.getAttribute("data-type");if(H==="NodeThematicBreak"||H==="tb"||(v=J.classList)!=null&&v.contains("hr")){w=J.getAttribute("data-node-id")||"";break}J=J.previousElementSibling}}if(r!=null&&r.slides){const J=[s,u];let H=l.parentElement;for(;H&&!H.classList.contains("protyle-wysiwyg");){const rt=H.getAttribute("data-node-id");rt&&!J.includes(rt)&&J.push(rt),H=H.parentElement}const K=r.slides.find(rt=>{var lt,st,Q;return J.includes(rt.startBlockId)||((lt=rt.blocks)==null?void 0:lt.some(pt=>J.includes(pt.id)))||((st=rt.allBlockIds)==null?void 0:st.some(pt=>J.includes(pt)))||((Q=rt.noteBlocks)==null?void 0:Q.some(pt=>J.includes(pt.id)))});K&&(!w&&K.startBlockId&&(w=K.startBlockId),!_&&((G=K.frontmatter)!=null&&G.layout)&&(_=K.frontmatter.layout))}if(w){const J=Rt.getBlockAttrOverride(w);if(J&&(dt in J||"custom-slidev-layout"in J)&&(_=J[dt]||J["custom-slidev-layout"]||""),!_&&(r!=null&&r.slides)){const H=r.slides.find(K=>K.startBlockId===w);(A=H==null?void 0:H.frontmatter)!=null&&A.layout&&(_=H.frontmatter.layout)}if(!_){const H=await Ze(w).catch(()=>({}))||{};_=H[dt]||H["custom-slidev-layout"]||"",H&&Object.keys(H).length>0&&Rt.setBlockAttrOverride(w,H)}ie(w,{[dt]:_||""})}else if(o){const J=Rt.getBlockAttrOverride(o);J&&(dt in J||"custom-slidev-layout"in J)?_=J[dt]||J["custom-slidev-layout"]||"":!_&&((N=(j=(E=r==null?void 0:r.slides)==null?void 0:E[0])==null?void 0:j.frontmatter)!=null&&N.layout)&&(_=r.slides[0].frontmatter.layout)}const T=l.getAttribute(dt)||l.getAttribute("custom-slidev-layout"),x=b[dt]||b["custom-slidev-layout"]||"";T&&T!==x&&ie(s,{[dt]:x});const S=l.getAttribute(Vt)||l.getAttribute("custom-slidev-role"),B=b[Vt]||b["custom-slidev-role"]||"";S&&S!==B&&ie(s,{[Vt]:B});const D=l.closest('[data-type="NodeListItem"]');if(D&&D!==l){const J=D.getAttribute("data-node-id");if(J){const H=await Ze(J).catch(()=>({}))||{},K=Rt.getBlockAttrOverride(J)||{},rt={...H,...K},lt=rt[dt]||rt["custom-slidev-layout"]||"",st=D.getAttribute(dt)||D.getAttribute("custom-slidev-layout");st&&st!==lt&&ie(J,{[dt]:lt});const Q=rt[Vt]||rt["custom-slidev-role"]||"",pt=D.getAttribute(Vt)||D.getAttribute("custom-slidev-role");pt&&pt!==Q&&ie(J,{[Vt]:Q})}}const M=!!l.querySelector("img, span[data-type='img']"),O=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),Z=M&&O.length<=50;Jn({id:s,rootId:o,type:a,content:y,attrs:b,isDivider:g,isCode:f,isImage:Z,topBlockId:u,pageDividerId:w,pageDividerLayout:_})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},r=n.data.new||{},l={};for(const s of Object.keys(o))s in r||(l[s]="");for(const[s,a]of Object.entries(r))l[s]=String(a??"");ie(n.id,l),Rt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,r,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const s of i.slides){if(s.startBlockId){const a=e.get(s.startBlockId)||{};(o=s.frontmatter)!=null&&o.layout&&(a[dt]=s.frontmatter.layout),e.set(s.startBlockId,a)}if(Array.isArray(s.blocks)){for(const a of s.blocks)if(a.id){const c=e.get(a.id)||{};(r=a.ial)!=null&&r[dt]&&(c[dt]=a.ial[dt]),(l=a.ial)!=null&&l[Vt]&&(c[Vt]=a.ial[Vt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Rt.getAllAttrOverrides();for(const[s,a]of n.entries()){const c=e.get(s)||{};a[dt]!==void 0&&(c[dt]=a[dt]),a[Vt]!==void 0&&(c[Vt]=a[Vt]),e.set(s,c)}Jf(e)}}const Si=new _1,S1=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,C1="slidev-dock",Tr="slidev-preview-tab",Br=jp;class $1 extends mt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new us);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=mt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(S1),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),x1(this);const n=this;if(this.addTab({type:Tr,init(){g1(this.element,n)},destroy(){ua(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:C1,init(){v1(this.element,n)},destroy(){fa(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Br),n=Hp(e);return Gi(n),n}catch{return Gi(Qi),Qi}}async saveGlobalSettings(e){const n=Rs(),o=Gi({...n,...e||{}});try{await this.saveData(Br,o)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Pn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await mt.openTab({app:this.app,custom:{id:this.name+Tr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,r=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!r||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Pt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Pt(r,{"custom-slidev-theme":"default"}),mt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Pt(r,{"custom-slidev-theme":"seriph"}),mt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Pt(r,{"custom-slidev-theme":"apple-basic"}),mt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Pt(r,{"custom-slidev-aspect-ratio":"16/9"}),mt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Pt(r,{"custom-slidev-aspect-ratio":"4/3"}),mt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const n=(r=e.detail)==null?void 0:r.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const s=await Ze(o).catch(()=>({}));Jn({id:o,rootId:o,type:"doc",attrs:s}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var r,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(r=n.protyle)==null?void 0:r.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return Si.getActiveDocumentId()}resolveDocIdFromElement(e){return Si.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await Si.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&(Si.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,Si.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const u=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=u==null?void 0:u.querySelector(".protyle-title__input"),f=((g==null?void 0:g.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const s=n.closest("[data-node-id]");if(!s)return;const a=s.getAttribute("data-node-id"),c=s.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,cs(a)),this.syncInspectorBlock(s,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const r=o.closest(".protyle-title");if(!!(r||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const u=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=u==null?void 0:u.querySelector(".protyle-title__input"),f=((g==null?void 0:g.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!o.closest(".protyle-wysiwyg"))return;const s=o.closest("[data-node-id]"),a=s==null?void 0:s.getAttribute("data-node-id"),c=(s==null?void 0:s.getAttribute("data-type"))||"";s&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,cs(a)),this.syncInspectorBlock(s,a,c))}async syncInspectorBlock(e,n,o){await Si.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Rt.compile(n);this.latestCompiledDoc=o,b1(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){Si.purgeStaleDomSlidevAttrs(e)}}module.exports=$1;
