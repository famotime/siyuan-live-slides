"use strict";var Xc=Object.create;var Js=Object.defineProperty;var Qc=Object.getOwnPropertyDescriptor;var ed=Object.getOwnPropertyNames;var td=Object.getPrototypeOf,id=Object.prototype.hasOwnProperty;var nd=(e,t,i)=>t in e?Js(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var sd=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of ed(t))!id.call(e,s)&&s!==i&&Js(e,s,{get:()=>t[s],enumerable:!(n=Qc(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?Xc(td(e)):{},sd(t||!e||!e.__esModule?Js(i,"default",{value:e,enumerable:!0}):i,e));var ke=(e,t,i)=>nd(e,typeof t!="symbol"?t+"":t,i);const ue=require("siyuan");async function vt(e,t){const i=await ue.fetchSyncPost(e,t);return i.code===0?i.data:null}async function od(){return vt("/api/notebook/lsNotebooks","")}async function rd(e,t,i){return vt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function ga(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return vt("/api/asset/upload",i)}async function Oi(e,t,i,n,s){return vt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function bo(e,t,i){return vt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function yo(e,t,i){return vt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function va(e){return vt("/api/block/deleteBlock",{id:e})}async function ad(e){return vt("/api/block/getBlockKramdown",{id:e})}async function Yn(e){return vt("/api/block/getChildBlocks",{id:e})}async function ld(e){return vt("/api/block/getDocBlocksOrders",{id:e})}async function He(e,t){return vt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function jo(e){return vt("/api/attr/getBlockAttrs",{id:e})}async function cn(e){return vt("/api/query/sql",{stmt:e})}async function ko(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),vt("/api/file/putFile",n)}async function ba(e){const t="/api/ai/chatGPT";try{const i=await vt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function cd(){return vt("/api/storage/getInlineStyles","")}const ya=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function dd(e){const t=[];if(!e)return t;const i=new RegExp(ya.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function ud(e,t){if(!e)return"";const i=new RegExp(ya.source,"g");return e.replace(i,(n,s,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[s]){const u=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${u}</div>`}const c=l||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const On="custom-slides-theme",Rn="custom-slides-aspect-ratio",ka="custom-slides-highlighter",Nn="custom-slides-default-transition",wa="custom-slides-color-schema",wo="custom-slides-spacing",wr="custom-slides-show-unordered-list-markers",xr="custom-slides-show-ordered-list-markers",Li="custom-slides-slide",we="custom-slides-layout",mt="custom-slides-transition",nt="custom-slides-background",Pt="custom-slides-image",Xs="custom-slides-notes",Qi="custom-slides-class",$n="custom-slides-spacing",kt="custom-slides-layout-ratio",en="custom-slides-mask",Ni="custom-slides-mask-ratio",tn="custom-slides-mask-style",nn="custom-slides-mask-initial",ze="custom-slides-click",Jt="custom-slides-motion",Ui="custom-slides-shiki-lines",Me="custom-slides-slot",Ve="custom-slides-note",Ze="custom-slides-role",zn="custom-slides-max-height",Pi="custom-slides-autoplay",ws="custom-slides-loop",Xi="custom-slides-muted",xs="custom-slides-controls",xa="background",Ss="image-left",Cs="image-right";function Hn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function fd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const a=o.every((h,f)=>f===0||h>o[f-1]),r=o[o.length-1];if(a&&(r===100||o.some(h=>h>10))){const h=o.map(f=>Math.min(100,Math.round(f*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,f)=>h+f,0);if(c<=0)return{steps:n,breakpoints:i};let u=0;const d=[];for(let h=0;h<o.length;h++)u+=o[h],h===o.length-1?d.push(100):d.push(Math.round(u/c*1e4)/100);return{steps:d.length,breakpoints:d}}function pd(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function hd(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}function Sa(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ca(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function At(e,t){if(!Sa(e))return e;const i=Ca(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function md(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const a=At(o,t);return`![${s}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,a)=>{const r=At(o,t);return`${s}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,a)=>{const r=At(o,t);return`${s}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ke={},sn=[],Xt=()=>{},_a=()=>!1,Ls=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ps=e=>e.startsWith("onUpdate:"),dt=Object.assign,Uo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},gd=Object.prototype.hasOwnProperty,je=(e,t)=>gd.call(e,t),Ee=Array.isArray,on=e=>Zn(e)==="[object Map]",pn=e=>Zn(e)==="[object Set]",Sr=e=>Zn(e)==="[object Date]",De=e=>typeof e=="function",it=e=>typeof e=="string",Nt=e=>typeof e=="symbol",Ge=e=>e!==null&&typeof e=="object",$a=e=>(Ge(e)||De(e))&&De(e.then)&&De(e.catch),Ia=Object.prototype.toString,Zn=e=>Ia.call(e),vd=e=>Zn(e).slice(8,-1),Ma=e=>Zn(e)==="[object Object]",Vo=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,In=Wo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Os=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},bd=/-\w/g,xt=Os(e=>e.replace(bd,t=>t.slice(1).toUpperCase())),yd=/\B([A-Z])/g,$i=Os(e=>e.replace(yd,"-$1").toLowerCase()),Rs=Os(e=>e.charAt(0).toUpperCase()+e.slice(1)),Qs=Os(e=>e?`on${Rs(e)}`:""),Kt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Ta=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Ns=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Cr;const zs=()=>Cr||(Cr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function qt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=it(n)?Sd(n):qt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(it(e)||Ge(e))return e}const kd=/;(?![^(]*\))/g,wd=/:([^]+)/,xd=/\/\*[^]*?\*\//g;function Sd(e){const t={};return e.replace(xd,"").split(kd).forEach(i=>{if(i){const n=i.split(wd);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(it(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(Ge(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Cd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",_d=Wo(Cd);function Ea(e){return!!e||e===""}function $d(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=hn(e[n],t[n]);return i}function hn(e,t){if(e===t)return!0;let i=Sr(e),n=Sr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Nt(e),n=Nt(t),i||n)return e===t;if(i=Ee(e),n=Ee(t),i||n)return i&&n?$d(e,t):!1;if(i=Ge(e),n=Ge(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!hn(e[a],t[a]))return!1}}return String(e)===String(t)}function Go(e,t){return e.findIndex(i=>hn(i,t))}const Aa=e=>!!(e&&e.__v_isRef===!0),xe=e=>it(e)?e:e==null?"":Ee(e)||Ge(e)&&(e.toString===Ia||!De(e.toString))?Aa(e)?xe(e.value):JSON.stringify(e,Ba,2):String(e),Ba=(e,t)=>Aa(t)?Ba(e,t.value):on(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[eo(n,o)+" =>"]=s,i),{})}:pn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>eo(i))}:Nt(t)?eo(t):Ge(t)&&!Ee(t)&&!Ma(t)?String(t):t,eo=(e,t="")=>{var i;return Nt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class Id{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Md(){return lt}let Ye;const to=new WeakSet;class Da{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,to.has(this)&&(to.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Pa(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,_r(this),Oa(this);const t=Ye,i=Ot;Ye=this,Ot=!0;try{return this.fn()}finally{Ra(this),Ye=t,Ot=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Yo(t);this.deps=this.depsTail=void 0,_r(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?to.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){xo(this)&&this.run()}get dirty(){return xo(this)}}let La=0,Mn,Tn;function Pa(e,t=!1){if(e.flags|=8,t){e.next=Tn,Tn=e;return}e.next=Mn,Mn=e}function Ko(){La++}function qo(){if(--La>0)return;if(Tn){let t=Tn;for(Tn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Mn;){let t=Mn;for(Mn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Oa(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Ra(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Yo(n),Td(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function xo(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Na(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Na(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Fn)||(e.globalVersion=Fn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!xo(e))))return;e.flags|=2;const t=e.dep,i=Ye,n=Ot;Ye=e,Ot=!0;try{Oa(e);const s=e.fn(e._value);(t.version===0||Kt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Ye=i,Ot=n,Ra(e),e.flags&=-3}}function Yo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Yo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Td(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Ot=!0;const za=[];function di(){za.push(Ot),Ot=!1}function ui(){const e=za.pop();Ot=e===void 0?!0:e}function _r(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ye;Ye=void 0;try{t()}finally{Ye=i}}}let Fn=0;class Ed{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Zo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ye||!Ot||Ye===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ye)i=this.activeLink=new Ed(Ye,this),Ye.deps?(i.prevDep=Ye.depsTail,Ye.depsTail.nextDep=i,Ye.depsTail=i):Ye.deps=Ye.depsTail=i,Ha(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ye.depsTail,i.nextDep=void 0,Ye.depsTail.nextDep=i,Ye.depsTail=i,Ye.deps===i&&(Ye.deps=n)}return i}trigger(t){this.version++,Fn++,this.notify(t)}notify(t){Ko();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{qo()}}}function Ha(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Ha(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const So=new WeakMap,zi=Symbol(""),Co=Symbol(""),jn=Symbol("");function ht(e,t,i){if(Ot&&Ye){let n=So.get(e);n||So.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Zo),s.map=n,s.key=i),s.track()}}function ri(e,t,i,n,s,o){const a=So.get(e);if(!a){Fn++;return}const r=l=>{l&&l.trigger()};if(Ko(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Vo(i);if(l&&i==="length"){const u=Number(n);a.forEach((d,h)=>{(h==="length"||h===jn||!Nt(h)&&h>=u)&&r(d)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(jn)),t){case"add":l?c&&r(a.get("length")):(r(a.get(zi)),on(e)&&r(a.get(Co)));break;case"delete":l||(r(a.get(zi)),on(e)&&r(a.get(Co)));break;case"set":on(e)&&r(a.get(zi));break}}qo()}function Yi(e){const t=Fe(e);return t===e?t:(ht(t,"iterate",jn),Dt(e)?t:t.map(zt))}function Hs(e){return ht(e=Fe(e),"iterate",jn),e}function Vt(e,t){return fi(e)?dn(Hi(e)?zt(t):t):zt(t)}const Ad={__proto__:null,[Symbol.iterator](){return io(this,Symbol.iterator,e=>Vt(this,e))},concat(...e){return Yi(this).concat(...e.map(t=>Ee(t)?Yi(t):t))},entries(){return io(this,"entries",e=>(e[1]=Vt(this,e[1]),e))},every(e,t){return ti(this,"every",e,t,void 0,arguments)},filter(e,t){return ti(this,"filter",e,t,i=>i.map(n=>Vt(this,n)),arguments)},find(e,t){return ti(this,"find",e,t,i=>Vt(this,i),arguments)},findIndex(e,t){return ti(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ti(this,"findLast",e,t,i=>Vt(this,i),arguments)},findLastIndex(e,t){return ti(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ti(this,"forEach",e,t,void 0,arguments)},includes(...e){return no(this,"includes",e)},indexOf(...e){return no(this,"indexOf",e)},join(e){return Yi(this).join(e)},lastIndexOf(...e){return no(this,"lastIndexOf",e)},map(e,t){return ti(this,"map",e,t,void 0,arguments)},pop(){return kn(this,"pop")},push(...e){return kn(this,"push",e)},reduce(e,...t){return $r(this,"reduce",e,t)},reduceRight(e,...t){return $r(this,"reduceRight",e,t)},shift(){return kn(this,"shift")},some(e,t){return ti(this,"some",e,t,void 0,arguments)},splice(...e){return kn(this,"splice",e)},toReversed(){return Yi(this).toReversed()},toSorted(e){return Yi(this).toSorted(e)},toSpliced(...e){return Yi(this).toSpliced(...e)},unshift(...e){return kn(this,"unshift",e)},values(){return io(this,"values",e=>Vt(this,e))}};function io(e,t,i){const n=Hs(e),s=n[t]();return n!==e&&!Dt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Bd=Array.prototype;function ti(e,t,i,n,s,o){const a=Hs(e),r=a!==e&&!Dt(e),l=a[t];if(l!==Bd[t]){const d=l.apply(e,o);return r?zt(d):d}let c=i;a!==e&&(r?c=function(d,h){return i.call(this,Vt(e,d),h,e)}:i.length>2&&(c=function(d,h){return i.call(this,d,h,e)}));const u=l.call(a,c,n);return r&&s?s(u):u}function $r(e,t,i,n){const s=Hs(e),o=s!==e&&!Dt(e);let a=i,r=!1;s!==e&&(o?(r=n.length===0,a=function(c,u,d){return r&&(r=!1,c=Vt(e,c)),i.call(this,c,Vt(e,u),d,e)}):i.length>3&&(a=function(c,u,d){return i.call(this,c,u,d,e)}));const l=s[t](a,...n);return r?Vt(e,l):l}function no(e,t,i){const n=Fe(e);ht(n,"iterate",jn);const s=n[t](...i);return(s===-1||s===!1)&&Qo(i[0])?(i[0]=Fe(i[0]),n[t](...i)):s}function kn(e,t,i=[]){di(),Ko();const n=Fe(e)[t].apply(e,i);return qo(),ui(),n}const Dd=Wo("__proto__,__v_isRef,__isVue"),Fa=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Nt));function Ld(e){Nt(e)||(e=String(e));const t=Fe(this);return ht(t,"has",e),t.hasOwnProperty(e)}class ja{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Ud:Ga:o?Va:Ua).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const a=Ee(t);if(!s){let l;if(a&&(l=Ad[i]))return l;if(i==="hasOwnProperty")return Ld}const r=Reflect.get(t,i,Xe(t)?t:n);if((Nt(i)?Fa.has(i):Dd(i))||(s||ht(t,"get",i),o))return r;if(Xe(r)){const l=a&&Vo(i)?r:r.value;return s&&Ge(l)?$o(l):l}return Ge(r)?s?$o(r):Fs(r):r}}class Wa extends ja{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const a=Ee(t)&&Vo(i);if(!this._isShallow){const c=fi(o);if(!Dt(n)&&!fi(n)&&(o=Fe(o),n=Fe(n)),!a&&Xe(o)&&!Xe(n))return c||(o.value=n),!0}const r=a?Number(i)<t.length:je(t,i),l=Reflect.set(t,i,n,Xe(t)?t:s);return t===Fe(s)&&l&&(r?Kt(n,o)&&ri(t,"set",i,n):ri(t,"add",i,n)),l}deleteProperty(t,i){const n=je(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ri(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Nt(i)||!Fa.has(i))&&ht(t,"has",i),n}ownKeys(t){return ht(t,"iterate",Ee(t)?"length":zi),Reflect.ownKeys(t)}}class Pd extends ja{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Od=new Wa,Rd=new Pd,Nd=new Wa(!0);const _o=e=>e,ns=e=>Reflect.getPrototypeOf(e);function zd(e,t,i){return function(...n){const s=this.__v_raw,o=Fe(s),a=on(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=s[e](...n),u=i?_o:t?dn:zt;return!t&&ht(o,"iterate",l?Co:zi),dt(Object.create(c),{next(){const{value:d,done:h}=c.next();return h?{value:d,done:h}:{value:r?[u(d[0]),u(d[1])]:u(d),done:h}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Hd(e,t){const i={get(s){const o=this.__v_raw,a=Fe(o),r=Fe(s);e||(Kt(s,r)&&ht(a,"get",s),ht(a,"get",r));const{has:l}=ns(a),c=t?_o:e?dn:zt;if(l.call(a,s))return c(o.get(s));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(s)},get size(){const s=this.__v_raw;return!e&&ht(Fe(s),"iterate",zi),s.size},has(s){const o=this.__v_raw,a=Fe(o),r=Fe(s);return e||(Kt(s,r)&&ht(a,"has",s),ht(a,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const a=this,r=a.__v_raw,l=Fe(r),c=t?_o:e?dn:zt;return!e&&ht(l,"iterate",zi),r.forEach((u,d)=>s.call(o,c(u),c(d),a))}};return dt(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=Fe(this),a=ns(o),r=Fe(s),l=!t&&!Dt(s)&&!fi(s)?r:s;return a.has.call(o,l)||Kt(s,l)&&a.has.call(o,s)||Kt(r,l)&&a.has.call(o,r)||(o.add(l),ri(o,"add",l,l)),this},set(s,o){!t&&!Dt(o)&&!fi(o)&&(o=Fe(o));const a=Fe(this),{has:r,get:l}=ns(a);let c=r.call(a,s);c||(s=Fe(s),c=r.call(a,s));const u=l.call(a,s);return a.set(s,o),c?Kt(o,u)&&ri(a,"set",s,o):ri(a,"add",s,o),this},delete(s){const o=Fe(this),{has:a,get:r}=ns(o);let l=a.call(o,s);l||(s=Fe(s),l=a.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return l&&ri(o,"delete",s,void 0),c},clear(){const s=Fe(this),o=s.size!==0,a=s.clear();return o&&ri(s,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=zd(s,e,t)}),i}function Jo(e,t){const i=Hd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(je(i,s)&&s in n?i:n,s,o)}const Fd={get:Jo(!1,!1)},jd={get:Jo(!1,!0)},Wd={get:Jo(!0,!1)};const Ua=new WeakMap,Va=new WeakMap,Ga=new WeakMap,Ud=new WeakMap;function Vd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Fs(e){return fi(e)?e:Xo(e,!1,Od,Fd,Ua)}function Gd(e){return Xo(e,!1,Nd,jd,Va)}function $o(e){return Xo(e,!0,Rd,Wd,Ga)}function Xo(e,t,i,n,s){if(!Ge(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const a=Vd(vd(e));if(a===0)return e;const r=new Proxy(e,a===2?n:i);return s.set(e,r),r}function Hi(e){return fi(e)?Hi(e.__v_raw):!!(e&&e.__v_isReactive)}function fi(e){return!!(e&&e.__v_isReadonly)}function Dt(e){return!!(e&&e.__v_isShallow)}function Qo(e){return e?!!e.__v_raw:!1}function Fe(e){const t=e&&e.__v_raw;return t?Fe(t):e}function Kd(e){return!je(e,"__v_skip")&&Object.isExtensible(e)&&Ta(e,"__v_skip",!0),e}const zt=e=>Ge(e)?Fs(e):e,dn=e=>Ge(e)?$o(e):e;function Xe(e){return e?e.__v_isRef===!0:!1}function ge(e){return qd(e,!1)}function qd(e,t){return Xe(e)?e:new Yd(e,t)}class Yd{constructor(t,i){this.dep=new Zo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Fe(t),this._value=i?t:zt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Dt(t)||fi(t);t=n?t:Fe(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:zt(t),this.dep.trigger())}}function he(e){return Xe(e)?e.value:e}const Zd={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return Xe(s)&&!Xe(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Ka(e){return Hi(e)?e:new Proxy(e,Zd)}class Jd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Zo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Fn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ye!==this)return Pa(this,!0),!0}get value(){const t=this.dep.track();return Na(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Xd(e,t,i=!1){let n,s;return De(e)?n=e:(n=e.get,s=e.set),new Jd(n,s,i)}const os={},_s=new WeakMap;let Di;function Qd(e,t=!1,i=Di){if(i){let n=_s.get(i);n||_s.set(i,n=[]),n.push(e)}}function eu(e,t,i=Ke){const{immediate:n,deep:s,once:o,scheduler:a,augmentJob:r,call:l}=i,c=w=>s?w:Dt(w)||s===!1||s===0?ai(w,1):ai(w);let u,d,h,f,v=!1,m=!1;if(Xe(e)?(d=()=>e.value,v=Dt(e)):Hi(e)?(d=()=>c(e),v=!0):Ee(e)?(m=!0,v=e.some(w=>Hi(w)||Dt(w)),d=()=>e.map(w=>{if(Xe(w))return w.value;if(Hi(w))return c(w);if(De(w))return l?l(w,2):w()})):De(e)?t?d=l?()=>l(e,2):e:d=()=>{if(h){di();try{h()}finally{ui()}}const w=Di;Di=u;try{return l?l(e,3,[f]):e(f)}finally{Di=w}}:d=Xt,t&&s){const w=d,$=s===!0?1/0:s;d=()=>ai(w(),$)}const b=Md(),y=()=>{u.stop(),b&&b.active&&Uo(b.effects,u)};if(o&&t){const w=t;t=(...$)=>{const T=w(...$);return y(),T}}let S=m?new Array(e.length).fill(os):os;const x=w=>{if(!(!(u.flags&1)||!u.dirty&&!w))if(t){const $=u.run();if(w||s||v||(m?$.some((T,C)=>Kt(T,S[C])):Kt($,S))){h&&h();const T=Di;Di=u;try{const C=[$,S===os?void 0:m&&S[0]===os?[]:S,f];S=$,l?l(t,3,C):t(...C)}finally{Di=T}}}else u.run()};return r&&r(x),u=new Da(d),u.scheduler=a?()=>a(x,!1):x,f=w=>Qd(w,!1,u),h=u.onStop=()=>{const w=_s.get(u);if(w){if(l)l(w,4);else for(const $ of w)$();_s.delete(u)}},t?n?x(!0):S=u.run():a?a(x.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function ai(e,t=1/0,i){if(t<=0||!Ge(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Xe(e))ai(e.value,t,i);else if(Ee(e))for(let n=0;n<e.length;n++)ai(e[n],t,i);else if(pn(e)||on(e))e.forEach(n=>{ai(n,t,i)});else if(Ma(e)){for(const n in e)ai(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ai(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){js(s,t,i)}}function Ht(e,t,i,n){if(De(e)){const s=Jn(e,t,i,n);return s&&$a(s)&&s.catch(o=>{js(o,t,i)}),s}if(Ee(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Ht(e[o],t,i,n));return s}}function js(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Ke;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let d=0;d<u.length;d++)if(u[d](e,l,c)===!1)return}r=r.parent}if(o){di(),Jn(o,null,10,[e,l,c]),ui();return}}tu(e,i,s,n,a)}function tu(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const yt=[];let Wt=-1;const rn=[];let yi=null,Zi=0;const qa=Promise.resolve();let $s=null;function Is(e){const t=$s||qa;return e?t.then(this?e.bind(this):e):t}function iu(e){let t=Wt+1,i=yt.length;for(;t<i;){const n=t+i>>>1,s=yt[n],o=Wn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function er(e){if(!(e.flags&1)){const t=Wn(e),i=yt[yt.length-1];!i||!(e.flags&2)&&t>=Wn(i)?yt.push(e):yt.splice(iu(t),0,e),e.flags|=1,Ya()}}function Ya(){$s||($s=qa.then(Ja))}function nu(e){Ee(e)?rn.push(...e):yi&&e.id===-1?yi.splice(Zi+1,0,e):e.flags&1||(rn.push(e),e.flags|=1),Ya()}function Ir(e,t,i=Wt+1){for(;i<yt.length;i++){const n=yt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;yt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Za(e){if(rn.length){const t=[...new Set(rn)].sort((i,n)=>Wn(i)-Wn(n));if(rn.length=0,yi){yi.push(...t);return}for(yi=t,Zi=0;Zi<yi.length;Zi++){const i=yi[Zi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}yi=null,Zi=0}}const Wn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Ja(e){try{for(Wt=0;Wt<yt.length;Wt++){const t=yt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<yt.length;Wt++){const t=yt[Wt];t&&(t.flags&=-2)}Wt=-1,yt.length=0,Za(),$s=null,(yt.length||rn.length)&&Ja()}}let ct=null,Xa=null;function Ms(e){const t=ct;return ct=e,Xa=e&&e.type.__scopeId||null,t}function Qa(e,t=ct,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&zr(-1);const o=Ms(t),a=li.length;let r;try{r=e(...s)}finally{for(let l=li.length;l>a;l--)or();Ms(o),n._d&&zr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Lt(e,t){if(ct===null)return e;const i=Ks(ct),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,a,r,l=Ke]=t[s];o&&(De(o)&&(o={mounted:o,updated:o}),o.deep&&ai(a),n.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Mi(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let a=0;a<s.length;a++){const r=s[a];o&&(r.oldValue=o[a].value);let l=r.dir[n];l&&(di(),Ht(l,i,8,[e.el,r,e,t]),ui())}}function su(e,t){if(gt){let i=gt.provides;const n=gt.parent&&gt.parent.provides;n===i&&(i=gt.provides=Object.create(n)),i[e]=t}}function Rt(e,t,i=!1){const n=nf();if(n||ln){let s=ln?ln._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&De(t)?t.call(n&&n.proxy):t}}const ou=Symbol.for("v-scx"),ru=()=>Rt(ou);function Fi(e,t,i){return el(e,t,i)}function el(e,t,i=Ke){const{immediate:n,deep:s,flush:o,once:a}=i,r=dt({},i),l=t&&n||!t&&o!=="post";let c;if(Vn){if(o==="sync"){const f=ru();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!l){const f=()=>{};return f.stop=Xt,f.resume=Xt,f.pause=Xt,f}}const u=gt;r.call=(f,v,m)=>Ht(f,u,v,m);let d=!1;o==="post"?r.scheduler=f=>{St(f,u&&u.suspense)}:o!=="sync"&&(d=!0,r.scheduler=(f,v)=>{v?f():er(f)}),r.augmentJob=f=>{t&&(f.flags|=4),d&&(f.flags|=2,u&&(f.id=u.uid,f.i=u))};const h=eu(e,t,r);return Vn&&(c?c.push(h):l&&h()),h}function au(e,t,i){const n=this.proxy,s=it(e)?e.includes(".")?tl(n,e):()=>n[e]:e.bind(n,n);let o;De(t)?o=t:(o=t.handler,i=t);const a=Xn(this),r=el(s,o.bind(n),i);return a(),r}function tl(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const lu=Symbol("_vte"),cu=e=>e.__isTeleport,so=Symbol("_leaveCb");function tr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,tr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Et(e,t){return De(e)?dt({name:e.name},t,{setup:e}):e}function il(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Mr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Ts=new WeakMap;function En(e,t,i,n,s=!1){if(Ee(e)){e.forEach((m,b)=>En(m,t&&(Ee(t)?t[b]:t),i,n,s));return}if(an(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&En(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Ks(n.component):n.el,a=s?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Ke?r.refs={}:r.refs,d=r.setupState,h=Fe(d),f=d===Ke?_a:m=>Mr(u,m)?!1:je(h,m),v=(m,b)=>!(b&&Mr(u,b));if(c!=null&&c!==l){if(Tr(t),it(c))u[c]=null,f(c)&&(d[c]=null);else if(Xe(c)){const m=t;v(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(De(l))Jn(l,r,12,[a,u]);else{const m=it(l),b=Xe(l);if(m||b){const y=()=>{if(e.f){const S=m?f(l)?d[l]:u[l]:v()||!e.k?l.value:u[e.k];if(s)Ee(S)&&Uo(S,o);else if(Ee(S))S.includes(o)||S.push(o);else if(m)u[l]=[o],f(l)&&(d[l]=u[l]);else{const x=[o];v(l,e.k)&&(l.value=x),e.k&&(u[e.k]=x)}}else m?(u[l]=a,f(l)&&(d[l]=a)):b&&(v(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const S=()=>{y(),Ts.delete(e)};S.id=-1,Ts.set(e,S),St(S,i)}else Tr(e),y()}}}function Tr(e){const t=Ts.get(e);t&&(t.flags|=8,Ts.delete(e))}zs().requestIdleCallback;zs().cancelIdleCallback;const an=e=>!!e.type.__asyncLoader,nl=e=>e.type.__isKeepAlive;function du(e,t){sl(e,"a",t)}function uu(e,t){sl(e,"da",t)}function sl(e,t,i=gt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ws(t,n,i),i){let s=i.parent;for(;s&&s.parent;)nl(s.parent.vnode)&&fu(n,t,i,s),s=s.parent}}function fu(e,t,i,n){const s=Ws(t,e,n,!0);Us(()=>{Uo(n[t],s)},i)}function Ws(e,t,i=gt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{di();const r=Xn(i),l=Ht(t,i,e,a);return r(),ui(),l});return n?s.unshift(o):s.push(o),o}}const hi=e=>(t,i=gt)=>{(!Vn||e==="sp")&&Ws(e,(...n)=>t(...n),i)},pu=hi("bm"),mn=hi("m"),hu=hi("bu"),mu=hi("u"),ir=hi("bum"),Us=hi("um"),gu=hi("sp"),vu=hi("rtg"),bu=hi("rtc");function yu(e,t=gt){Ws("ec",e,t)}const ku="components";function wu(e,t){return Su(ku,e,!0,t)||e}const xu=Symbol.for("v-ndc");function Su(e,t,i=!0,n=!1){const s=ct||gt;if(s){const o=s.type;{const r=lf(o,!1);if(r&&(r===t||r===xt(t)||r===Rs(xt(t))))return o}const a=Er(s[e]||o[e],t)||Er(s.appContext[e],t);return!a&&n?o:a}}function Er(e,t){return e&&(e[t]||e[xt(t)]||e[Rs(xt(t))])}function wt(e,t,i,n){let s;const o=i,a=Ee(e);if(a||it(e)){const r=a&&Hi(e);let l=!1,c=!1;r&&(l=!Dt(e),c=fi(e),e=Hs(e)),s=new Array(e.length);for(let u=0,d=e.length;u<d;u++)s[u]=t(l?c?dn(zt(e[u])):zt(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ge(e))if(e[Symbol.iterator])s=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];s[l]=t(e[u],u,l,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(ct.ce||ct.parent&&an(ct.parent)&&ct.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),Q(),Zt(qe,null,[ae("slot",c,n&&n())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=li.length;Q();let l;try{const c=a&&ol(a(i)),u=i.key||o||c&&c.key;l=Zt(qe,{key:(u&&!Nt(u)?u:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let u=li.length;u>r;u--)or();throw c}finally{a&&a._c&&(a._d=!0)}return l}function ol(e){return e.some(t=>rr(t)?!(t.type===pi||t.type===qe&&!ol(t.children)):!0)?e:null}const Io=e=>e?_l(e)?Ks(e):Io(e.parent):null,An=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Io(e.parent),$root:e=>Io(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>al(e),$forceUpdate:e=>e.f||(e.f=()=>{er(e.update)}),$nextTick:e=>e.n||(e.n=Is.bind(e.proxy)),$watch:e=>au.bind(e)}),oo=(e,t)=>e!==Ke&&!e.__isScriptSetup&&je(e,t),Cu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const h=a[t];if(h!==void 0)switch(h){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(oo(n,t))return a[t]=1,n[t];if(s!==Ke&&je(s,t))return a[t]=2,s[t];if(je(o,t))return a[t]=3,o[t];if(i!==Ke&&je(i,t))return a[t]=4,i[t];Mo&&(a[t]=0)}}const c=An[t];let u,d;if(c)return t==="$attrs"&&ht(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Ke&&je(i,t))return a[t]=4,i[t];if(d=l.config.globalProperties,je(d,t))return d[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return oo(s,t)?(s[t]=i,!0):n!==Ke&&je(n,t)?(n[t]=i,!0):je(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:a}},r){let l;return!!(i[r]||e!==Ke&&r[0]!=="$"&&je(e,r)||oo(t,r)||je(o,r)||je(n,r)||je(An,r)||je(s.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:je(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Ar(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Mo=!0;function _u(e){const t=al(e),i=e.proxy,n=e.ctx;Mo=!1,t.beforeCreate&&Br(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:d,mounted:h,beforeUpdate:f,updated:v,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:S,destroyed:x,unmounted:w,render:$,renderTracked:T,renderTriggered:C,errorCaptured:D,serverPrefetch:F,expose:W,inheritAttrs:K,components:_,directives:j,filters:k}=t;if(c&&$u(c,n,null),a)for(const B in a){const L=a[B];De(L)&&(n[B]=L.bind(i))}if(s){const B=s.call(i,i);Ge(B)&&(e.data=Fs(B))}if(Mo=!0,o)for(const B in o){const L=o[B],R=De(L)?L.bind(i,i):De(L.get)?L.get.bind(i,i):Xt,de=!De(L)&&De(L.set)?L.set.bind(i):Xt,V=be({get:R,set:de});Object.defineProperty(n,B,{enumerable:!0,configurable:!0,get:()=>V.value,set:Y=>V.value=Y})}if(r)for(const B in r)rl(r[B],n,i,B);if(l){const B=De(l)?l.call(i):l;Reflect.ownKeys(B).forEach(L=>{su(L,B[L])})}u&&Br(u,e,"c");function N(B,L){Ee(L)?L.forEach(R=>B(R.bind(i))):L&&B(L.bind(i))}if(N(pu,d),N(mn,h),N(hu,f),N(mu,v),N(du,m),N(uu,b),N(yu,D),N(bu,T),N(vu,C),N(ir,S),N(Us,w),N(gu,F),Ee(W))if(W.length){const B=e.exposed||(e.exposed={});W.forEach(L=>{Object.defineProperty(B,L,{get:()=>i[L],set:R=>i[L]=R,enumerable:!0})})}else e.exposed||(e.exposed={});$&&e.render===Xt&&(e.render=$),K!=null&&(e.inheritAttrs=K),_&&(e.components=_),j&&(e.directives=j),F&&il(e)}function $u(e,t,i=Xt){Ee(e)&&(e=To(e));for(const n in e){const s=e[n];let o;Ge(s)?"default"in s?o=Rt(s.from||n,s.default,!0):o=Rt(s.from||n):o=Rt(s),Xe(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[n]=o}}function Br(e,t,i){Ht(Ee(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function rl(e,t,i,n){let s=n.includes(".")?tl(i,n):()=>i[n];if(it(e)){const o=t[e];De(o)&&Fi(s,o)}else if(De(e))Fi(s,e.bind(i));else if(Ge(e))if(Ee(e))e.forEach(o=>rl(o,t,i,n));else{const o=De(e.handler)?e.handler.bind(i):t[e.handler];De(o)&&Fi(s,o,e)}}function al(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!s.length&&!i&&!n?l=t:(l={},s.length&&s.forEach(c=>Es(l,c,a,!0)),Es(l,t,a)),Ge(t)&&o.set(t,l),l}function Es(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&Es(e,o,i,!0),s&&s.forEach(a=>Es(e,a,i,!0));for(const a in t)if(!(n&&a==="expose")){const r=Iu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Iu={data:Dr,props:Lr,emits:Lr,methods:Sn,computed:Sn,beforeCreate:bt,created:bt,beforeMount:bt,mounted:bt,beforeUpdate:bt,updated:bt,beforeDestroy:bt,beforeUnmount:bt,destroyed:bt,unmounted:bt,activated:bt,deactivated:bt,errorCaptured:bt,serverPrefetch:bt,components:Sn,directives:Sn,watch:Tu,provide:Dr,inject:Mu};function Dr(e,t){return t?e?function(){return dt(De(e)?e.call(this,this):e,De(t)?t.call(this,this):t)}:t:e}function Mu(e,t){return Sn(To(e),To(t))}function To(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function bt(e,t){return e?[...new Set([].concat(e,t))]:t}function Sn(e,t){return e?dt(Object.create(null),e,t):t}function Lr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:dt(Object.create(null),Ar(e),Ar(t??{})):t}function Tu(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=bt(e[n],t[n]);return i}function ll(){return{app:null,config:{isNativeTag:_a,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Eu=0;function Au(e,t){return function(n,s=null){De(n)||(n=dt({},n)),s!=null&&!Ge(s)&&(s=null);const o=ll(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Eu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:df,get config(){return o.config},set config(u){},use(u,...d){return a.has(u)||(u&&De(u.install)?(a.add(u),u.install(c,...d)):De(u)&&(a.add(u),u(c,...d))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,d){return d?(o.components[u]=d,c):o.components[u]},directive(u,d){return d?(o.directives[u]=d,c):o.directives[u]},mount(u,d,h){if(!l){const f=c._ceVNode||ae(n,s);return f.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(f,u,h),l=!0,c._container=u,u.__vue_app__=c,Ks(f.component)}},onUnmount(u){r.push(u)},unmount(){l&&(Ht(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,d){return o.provides[u]=d,c},runWithContext(u){const d=ln;ln=c;try{return u()}finally{ln=d}}};return c}}let ln=null;const Bu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${xt(t)}Modifiers`]||e[`${$i(t)}Modifiers`];function Du(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ke;let s=i;const o=t.startsWith("update:"),a=o&&Bu(n,t.slice(7));a&&(a.trim&&(s=i.map(u=>it(u)?u.trim():u)),a.number&&(s=i.map(Ns)));let r,l=n[r=Qs(t)]||n[r=Qs(xt(t))];!l&&o&&(l=n[r=Qs($i(t))]),l&&Ht(l,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ht(c,e,6,s)}}const Lu=new WeakMap;function cl(e,t,i=!1){const n=i?Lu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let a={},r=!1;if(!De(e)){const l=c=>{const u=cl(c,t,!0);u&&(r=!0,dt(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ge(e)&&n.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):dt(a,o),Ge(e)&&n.set(e,a),a)}function Vs(e,t){return!e||!Ls(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),je(e,t[0].toLowerCase()+t.slice(1))||je(e,$i(t))||je(e,t))}function Pr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:d,data:h,setupState:f,ctx:v,inheritAttrs:m}=e,b=Ms(e);let y,S;try{if(i.shapeFlag&4){const w=s||n,$=w;y=Gt(c.call($,w,u,d,f,h,v)),S=r}else{const w=t;y=Gt(w.length>1?w(d,{attrs:r,slots:a,emit:l}):w(d,null)),S=t.props?r:Pu(r)}}catch(w){li.length=0,js(w,e,1),y=ae(pi)}let x=y;if(S&&m!==!1){const w=Object.keys(S),{shapeFlag:$}=x;w.length&&$&7&&(o&&w.some(Ps)&&(S=Ou(S,o)),x=un(x,S,!1,!0))}return i.dirs&&(x=un(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(i.dirs):i.dirs),i.transition&&tr(x,i.transition),y=x,Ms(b),y}const Pu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ls(i))&&((t||(t={}))[i]=e[i]);return t},Ou=(e,t)=>{const i={};for(const n in e)(!Ps(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Ru(e,t,i){const{props:n,children:s,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return n?Or(n,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let d=0;d<u.length;d++){const h=u[d];if(dl(a,n,h)&&!Vs(c,h))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===a?!1:n?a?Or(n,a,c):!0:!!a;return!1}function Or(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(dl(t,e,o)&&!Vs(i,o))return!0}return!1}function dl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ge(n)&&Ge(s)?!hn(n,s):n!==s}function Nu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const ul={},fl=()=>Object.create(ul),pl=e=>Object.getPrototypeOf(e)===ul;function zu(e,t,i,n=!1){const s={},o=fl();e.propsDefaults=Object.create(null),hl(e,t,s,o);for(const a in e.propsOptions[0])a in s||(s[a]=void 0);i?e.props=n?s:Gd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Hu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:a}}=e,r=Fe(s),[l]=e.propsOptions;let c=!1;if((n||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let d=0;d<u.length;d++){let h=u[d];if(Vs(e.emitsOptions,h))continue;const f=t[h];if(l)if(je(o,h))f!==o[h]&&(o[h]=f,c=!0);else{const v=xt(h);s[v]=Eo(l,r,v,f,e,!1)}else f!==o[h]&&(o[h]=f,c=!0)}}}else{hl(e,t,s,o)&&(c=!0);let u;for(const d in r)(!t||!je(t,d)&&((u=$i(d))===d||!je(t,u)))&&(l?i&&(i[d]!==void 0||i[u]!==void 0)&&(s[d]=Eo(l,r,d,void 0,e,!0)):delete s[d]);if(o!==r)for(const d in o)(!t||!je(t,d))&&(delete o[d],c=!0)}c&&ri(e.attrs,"set","")}function hl(e,t,i,n){const[s,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(In(l))continue;const c=t[l];let u;s&&je(s,u=xt(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Vs(e.emitsOptions,l)||(!(l in n)||c!==n[l])&&(n[l]=c,a=!0)}if(o){const l=Fe(i),c=r||Ke;for(let u=0;u<o.length;u++){const d=o[u];i[d]=Eo(s,l,d,c[d],e,!je(c,d))}}return a}function Eo(e,t,i,n,s,o){const a=e[i];if(a!=null){const r=je(a,"default");if(r&&n===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&De(l)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const u=Xn(s);n=c[i]=l.call(null,t),u()}}else n=l;s.ce&&s.ce._setProp(i,n)}a[0]&&(o&&!r?n=!1:a[1]&&(n===""||n===$i(i))&&(n=!0))}return n}const Fu=new WeakMap;function ml(e,t,i=!1){const n=i?Fu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,a={},r=[];let l=!1;if(!De(e)){const u=d=>{l=!0;const[h,f]=ml(d,t,!0);dt(a,h),f&&r.push(...f)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return Ge(e)&&n.set(e,sn),sn;if(Ee(o))for(let u=0;u<o.length;u++){const d=xt(o[u]);Rr(d)&&(a[d]=Ke)}else if(o)for(const u in o){const d=xt(u);if(Rr(d)){const h=o[u],f=a[d]=Ee(h)||De(h)?{type:h}:dt({},h),v=f.type;let m=!1,b=!0;if(Ee(v))for(let y=0;y<v.length;++y){const S=v[y],x=De(S)&&S.name;if(x==="Boolean"){m=!0;break}else x==="String"&&(b=!1)}else m=De(v)&&v.name==="Boolean";f[0]=m,f[1]=b,(m||je(f,"default"))&&r.push(d)}}const c=[a,r];return Ge(e)&&n.set(e,c),c}function Rr(e){return e[0]!=="$"&&!In(e)}const nr=e=>e==="_"||e==="_ctx"||e==="$stable",sr=e=>Ee(e)?e.map(Gt):[Gt(e)],ju=(e,t,i)=>{if(t._n)return t;const n=Qa((...s)=>sr(t(...s)),i);return n._c=!1,n},gl=(e,t,i)=>{const n=e._ctx;for(const s in e){if(nr(s))continue;const o=e[s];if(De(o))t[s]=ju(s,o,n);else if(o!=null){const a=sr(o);t[s]=()=>a}}},vl=(e,t)=>{const i=sr(t);e.slots.default=()=>i},bl=(e,t,i)=>{for(const n in t)(i||!nr(n))&&(e[n]=t[n])},Wu=(e,t,i)=>{const n=e.slots=fl();if(e.vnode.shapeFlag&32){const s=t._;s?(bl(n,t,i),i&&Ta(n,"_",s,!0)):gl(t,n)}else t&&vl(e,t)},Uu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,a=Ke;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:bl(s,t,i):(o=!t.$stable,gl(t,s)),a=t}else t&&(vl(e,t),a={default:1});if(o)for(const r in s)!nr(r)&&a[r]==null&&delete s[r]},St=Yu;function Vu(e){return Gu(e)}function Gu(e,t){const i=zs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:d,nextSibling:h,setScopeId:f=Xt,insertStaticContent:v}=e,m=(P,U,g,G=null,H=null,I=null,M=void 0,O=null,q=!!U.dynamicChildren)=>{if(P===U)return;P&&!wn(P,U)&&(G=Ie(P),Y(P,H,I,!0),P=null),U.patchFlag===-2&&(q=!1,U.dynamicChildren=null);const{type:A,ref:z,shapeFlag:J}=U;switch(A){case Gs:b(P,U,g,G);break;case pi:y(P,U,g,G);break;case fs:P==null&&S(U,g,G,M);break;case qe:_(P,U,g,G,H,I,M,O,q);break;default:J&1?$(P,U,g,G,H,I,M,O,q):J&6?j(P,U,g,G,H,I,M,O,q):(J&64||J&128)&&A.process(P,U,g,G,H,I,M,O,q,X)}z!=null&&H?En(z,P&&P.ref,I,U||P,!U):z==null&&P&&P.ref!=null&&En(P.ref,null,I,P,!0)},b=(P,U,g,G)=>{if(P==null)n(U.el=r(U.children),g,G);else{const H=U.el=P.el;U.children!==P.children&&c(H,U.children)}},y=(P,U,g,G)=>{P==null?n(U.el=l(U.children||""),g,G):U.el=P.el},S=(P,U,g,G)=>{[P.el,P.anchor]=v(P.children,U,g,G,P.el,P.anchor)},x=({el:P,anchor:U},g,G)=>{let H;for(;P&&P!==U;)H=h(P),n(P,g,G),P=H;n(U,g,G)},w=({el:P,anchor:U})=>{let g;for(;P&&P!==U;)g=h(P),s(P),P=g;s(U)},$=(P,U,g,G,H,I,M,O,q)=>{if(U.type==="svg"?M="svg":U.type==="math"&&(M="mathml"),P==null)T(U,g,G,H,I,M,O,q);else{const A=P.el&&P.el._isVueCE?P.el:null;try{A&&A._beginPatch(),F(P,U,H,I,M,O,q)}finally{A&&A._endPatch()}}},T=(P,U,g,G,H,I,M,O)=>{let q,A;const{props:z,shapeFlag:J,transition:ie,dirs:se}=P;if(q=P.el=a(P.type,I,z&&z.is,z),J&8?u(q,P.children):J&16&&D(P.children,q,null,G,H,ro(P,I),M,O),se&&Mi(P,null,G,"created"),C(q,P,P.scopeId,M,G),z){for(const $e in z)$e!=="value"&&!In($e)&&o(q,$e,null,z[$e],I,G);"value"in z&&o(q,"value",null,z.value,I),(A=z.onVnodeBeforeMount)&&jt(A,G,P)}se&&Mi(P,null,G,"beforeMount");const me=Ku(H,ie);me&&ie.beforeEnter(q),n(q,U,g),((A=z&&z.onVnodeMounted)||me||se)&&St(()=>{try{A&&jt(A,G,P),me&&ie.enter(q),se&&Mi(P,null,G,"mounted")}finally{}},H)},C=(P,U,g,G,H)=>{if(g&&f(P,g),G)for(let I=0;I<G.length;I++)f(P,G[I]);if(H){let I=H.subTree;if(U===I||xl(I.type)&&(I.ssContent===U||I.ssFallback===U)){const M=H.vnode;C(P,M,M.scopeId,M.slotScopeIds,H.parent)}}},D=(P,U,g,G,H,I,M,O,q=0)=>{for(let A=q;A<P.length;A++){const z=P[A]=O?ni(P[A]):Gt(P[A]);m(null,z,U,g,G,H,I,M,O)}},F=(P,U,g,G,H,I,M)=>{const O=U.el=P.el;let{patchFlag:q,dynamicChildren:A,dirs:z}=U;q|=P.patchFlag&16;const J=P.props||Ke,ie=U.props||Ke;let se;if(g&&Ti(g,!1),(se=ie.onVnodeBeforeUpdate)&&jt(se,g,U,P),z&&Mi(U,P,g,"beforeUpdate"),g&&Ti(g,!0),A&&(!P.dynamicChildren||P.dynamicChildren.length!==A.length)&&(q=0,M=!1,A=null),(J.innerHTML&&ie.innerHTML==null||J.textContent&&ie.textContent==null)&&u(O,""),A?W(P.dynamicChildren,A,O,g,G,ro(U,H),I):M||L(P,U,O,null,g,G,ro(U,H),I,!1),q>0){if(q&16)K(O,J,ie,g,H);else if(q&2&&J.class!==ie.class&&o(O,"class",null,ie.class,H),q&4&&o(O,"style",J.style,ie.style,H),q&8){const me=U.dynamicProps;for(let $e=0;$e<me.length;$e++){const Se=me[$e],re=J[Se],pe=ie[Se];(pe!==re||Se==="value")&&o(O,Se,re,pe,H,g)}}q&1&&P.children!==U.children&&u(O,U.children)}else!M&&A==null&&K(O,J,ie,g,H);((se=ie.onVnodeUpdated)||z)&&St(()=>{se&&jt(se,g,U,P),z&&Mi(U,P,g,"updated")},G)},W=(P,U,g,G,H,I,M)=>{for(let O=0;O<U.length;O++){const q=P[O],A=U[O],z=q.el&&(q.type===qe||!wn(q,A)||q.shapeFlag&198)?d(q.el):g;m(q,A,z,null,G,H,I,M,!0)}},K=(P,U,g,G,H)=>{if(U!==g){if(U!==Ke)for(const I in U)!In(I)&&!(I in g)&&o(P,I,U[I],null,H,G);for(const I in g){if(In(I))continue;const M=g[I],O=U[I];M!==O&&I!=="value"&&o(P,I,O,M,H,G)}"value"in g&&o(P,"value",U.value,g.value,H)}},_=(P,U,g,G,H,I,M,O,q)=>{const A=U.el=P?P.el:r(""),z=U.anchor=P?P.anchor:r("");let{patchFlag:J,dynamicChildren:ie,slotScopeIds:se}=U;se&&(O=O?O.concat(se):se),P==null?(n(A,g,G),n(z,g,G),D(U.children||[],g,z,H,I,M,O,q)):J>0&&J&64&&ie&&P.dynamicChildren&&P.dynamicChildren.length===ie.length?(W(P.dynamicChildren,ie,g,H,I,M,O),(U.key!=null||H&&U===H.subTree)&&yl(P,U,!0)):L(P,U,g,z,H,I,M,O,q)},j=(P,U,g,G,H,I,M,O,q)=>{U.slotScopeIds=O,P==null?U.shapeFlag&512?H.ctx.activate(U,g,G,M,q):k(U,g,G,H,I,M,q):E(P,U,q)},k=(P,U,g,G,H,I,M)=>{const O=P.component=tf(P,G,H);if(nl(P)&&(O.ctx.renderer=X),sf(O,!1,M),O.asyncDep){if(H&&H.registerDep(O,N,M),!P.el){const q=O.subTree=ae(pi);y(null,q,U,g),P.placeholder=q.el}}else N(O,P,U,g,H,I,M)},E=(P,U,g)=>{const G=U.component=P.component;if(Ru(P,U,g))if(G.asyncDep&&!G.asyncResolved){B(G,U,g);return}else G.next=U,G.update();else U.el=P.el,G.vnode=U},N=(P,U,g,G,H,I,M)=>{const O=()=>{if(P.isMounted){let{next:J,bu:ie,u:se,parent:me,vnode:$e}=P;{const Re=kl(P);if(Re){J&&(J.el=$e.el,B(P,J,M)),Re.asyncDep.then(()=>{St(()=>{P.isUnmounted||A()},H)});return}}let Se=J,re;Ti(P,!1),J?(J.el=$e.el,B(P,J,M)):J=$e,ie&&us(ie),(re=J.props&&J.props.onVnodeBeforeUpdate)&&jt(re,me,J,$e),Ti(P,!0);const pe=Pr(P),Le=P.subTree;P.subTree=pe,m(Le,pe,d(Le.el),Ie(Le),P,H,I),J.el=pe.el,Se===null&&Nu(P,pe.el),se&&St(se,H),(re=J.props&&J.props.onVnodeUpdated)&&St(()=>jt(re,me,J,$e),H)}else{let J;const{el:ie,props:se}=U,{bm:me,m:$e,parent:Se,root:re,type:pe}=P,Le=an(U);Ti(P,!1),me&&us(me),!Le&&(J=se&&se.onVnodeBeforeMount)&&jt(J,Se,U),Ti(P,!0);{re.ce&&re.ce._hasShadowRoot()&&re.ce._injectChildStyle(pe,P.parent?P.parent.type:void 0);const Re=P.subTree=Pr(P);m(null,Re,g,G,P,H,I),U.el=Re.el}if($e&&St($e,H),!Le&&(J=se&&se.onVnodeMounted)){const Re=U;St(()=>jt(J,Se,Re),H)}(U.shapeFlag&256||Se&&an(Se.vnode)&&Se.vnode.shapeFlag&256)&&P.a&&St(P.a,H),P.isMounted=!0,U=g=G=null}};P.scope.on();const q=P.effect=new Da(O);P.scope.off();const A=P.update=q.run.bind(q),z=P.job=q.runIfDirty.bind(q);z.i=P,z.id=P.uid,q.scheduler=()=>er(z),Ti(P,!0),A()},B=(P,U,g)=>{U.component=P;const G=P.vnode.props;P.vnode=U,P.next=null,Hu(P,U.props,G,g),Uu(P,U.children,g),di(),Ir(P),ui()},L=(P,U,g,G,H,I,M,O,q=!1)=>{const A=P&&P.children,z=P?P.shapeFlag:0,J=U.children,{patchFlag:ie,shapeFlag:se}=U;if(ie>0){if(ie&128){de(A,J,g,G,H,I,M,O,q);return}else if(ie&256){R(A,J,g,G,H,I,M,O,q);return}}se&8?(z&16&&ye(A,H,I),J!==A&&u(g,J)):z&16?se&16?de(A,J,g,G,H,I,M,O,q):ye(A,H,I,!0):(z&8&&u(g,""),se&16&&D(J,g,G,H,I,M,O,q))},R=(P,U,g,G,H,I,M,O,q)=>{P=P||sn,U=U||sn;const A=P.length,z=U.length,J=Math.min(A,z);let ie;for(ie=0;ie<J;ie++){const se=U[ie]=q?ni(U[ie]):Gt(U[ie]);m(P[ie],se,g,null,H,I,M,O,q)}A>z?ye(P,H,I,!0,!1,J):D(U,g,G,H,I,M,O,q,J)},de=(P,U,g,G,H,I,M,O,q)=>{let A=0;const z=U.length;let J=P.length-1,ie=z-1;for(;A<=J&&A<=ie;){const se=P[A],me=U[A]=q?ni(U[A]):Gt(U[A]);if(wn(se,me))m(se,me,g,null,H,I,M,O,q);else break;A++}for(;A<=J&&A<=ie;){const se=P[J],me=U[ie]=q?ni(U[ie]):Gt(U[ie]);if(wn(se,me))m(se,me,g,null,H,I,M,O,q);else break;J--,ie--}if(A>J){if(A<=ie){const se=ie+1,me=se<z?U[se].el:G;for(;A<=ie;)m(null,U[A]=q?ni(U[A]):Gt(U[A]),g,me,H,I,M,O,q),A++}}else if(A>ie)for(;A<=J;)Y(P[A],H,I,!0),A++;else{const se=A,me=A,$e=new Map;for(A=me;A<=ie;A++){const Qe=U[A]=q?ni(U[A]):Gt(U[A]);Qe.key!=null&&$e.set(Qe.key,A)}let Se,re=0;const pe=ie-me+1;let Le=!1,Re=0;const Be=new Array(pe);for(A=0;A<pe;A++)Be[A]=0;for(A=se;A<=J;A++){const Qe=P[A];if(re>=pe){Y(Qe,H,I,!0);continue}let et;if(Qe.key!=null)et=$e.get(Qe.key);else for(Se=me;Se<=ie;Se++)if(Be[Se-me]===0&&wn(Qe,U[Se])){et=Se;break}et===void 0?Y(Qe,H,I,!0):(Be[et-me]=A+1,et>=Re?Re=et:Le=!0,m(Qe,U[et],g,null,H,I,M,O,q),re++)}const rt=Le?qu(Be):sn;for(Se=rt.length-1,A=pe-1;A>=0;A--){const Qe=me+A,et=U[Qe],Ft=U[Qe+1],Gi=Qe+1<z?Ft.el||wl(Ft):G;Be[A]===0?m(null,et,g,Gi,H,I,M,O,q):Le&&(Se<0||A!==rt[Se]?V(et,g,Gi,2):Se--)}}},V=(P,U,g,G,H=null)=>{const{el:I,type:M,transition:O,children:q,shapeFlag:A}=P;if(A&6){V(P.component.subTree,U,g,G);return}if(A&128){P.suspense.move(U,g,G);return}if(A&64){M.move(P,U,g,X);return}if(M===qe){n(I,U,g);for(let J=0;J<q.length;J++)V(q[J],U,g,G);n(P.anchor,U,g);return}if(M===fs){x(P,U,g);return}if(G!==2&&A&1&&O)if(G===0)O.persisted&&!I[so]?n(I,U,g):(O.beforeEnter(I),n(I,U,g),St(()=>O.enter(I),H));else{const{leave:J,delayLeave:ie,afterLeave:se}=O,me=()=>{P.ctx.isUnmounted?s(I):n(I,U,g)},$e=()=>{const Se=I._isLeaving||!!I[so];I._isLeaving&&I[so](!0),O.persisted&&!Se?me():J(I,()=>{me(),se&&se()})};ie?ie(I,me,$e):$e()}else n(I,U,g)},Y=(P,U,g,G=!1,H=!1)=>{const{type:I,props:M,ref:O,children:q,dynamicChildren:A,shapeFlag:z,patchFlag:J,dirs:ie,cacheIndex:se,memo:me}=P;if(J===-2&&(H=!1),O!=null&&(di(),En(O,null,g,P,!0),ui()),se!=null&&(U.renderCache[se]=void 0),z&256){U.ctx.deactivate(P);return}const $e=z&1&&ie,Se=!an(P);let re;if(Se&&(re=M&&M.onVnodeBeforeUnmount)&&jt(re,U,P),z&6)oe(P.component,g,G);else{if(z&128){P.suspense.unmount(g,G);return}$e&&Mi(P,null,U,"beforeUnmount"),z&64?P.type.remove(P,U,g,X,G):A&&!A.hasOnce&&(I!==qe||J>0&&J&64)?ye(A,U,g,!1,!0):(I===qe&&J&384||!H&&z&16)&&ye(q,U,g),G&&Z(P)}const pe=me!=null&&se==null;(Se&&(re=M&&M.onVnodeUnmounted)||$e||pe)&&St(()=>{re&&jt(re,U,P),$e&&Mi(P,null,U,"unmounted"),pe&&(P.el=null)},g)},Z=P=>{const{type:U,el:g,anchor:G,transition:H}=P;if(U===qe){ne(g,G);return}if(U===fs){w(P);return}const I=()=>{s(g),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(P.shapeFlag&1&&H&&!H.persisted){const{leave:M,delayLeave:O}=H,q=()=>M(g,I);O?O(P.el,I,q):q()}else I()},ne=(P,U)=>{let g;for(;P!==U;)g=h(P),s(P),P=g;s(U)},oe=(P,U,g)=>{const{bum:G,scope:H,job:I,subTree:M,um:O,m:q,a:A}=P;Nr(q),Nr(A),G&&us(G),H.stop(),I&&(I.flags|=8,Y(M,P,U,g)),O&&St(O,U),St(()=>{P.isUnmounted=!0},U)},ye=(P,U,g,G=!1,H=!1,I=0)=>{for(let M=I;M<P.length;M++)Y(P[M],U,g,G,H)},Ie=P=>{if(P.shapeFlag&6)return Ie(P.component.subTree);if(P.shapeFlag&128)return P.suspense.next();const U=h(P.anchor||P.el),g=U&&U[lu];return g?h(g):U};let Ce=!1;const le=(P,U,g)=>{let G;P==null?U._vnode&&(Y(U._vnode,null,null,!0),G=U._vnode.component):m(U._vnode||null,P,U,null,null,null,g),U._vnode=P,Ce||(Ce=!0,Ir(G),Za(),Ce=!1)},X={p:m,um:Y,m:V,r:Z,mt:k,mc:D,pc:L,pbc:W,n:Ie,o:e};return{render:le,hydrate:void 0,createApp:Au(le)}}function ro({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Ti({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Ku(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function yl(e,t,i=!1){const n=e.children,s=t.children;if(Ee(n)&&Ee(s))for(let o=0;o<n.length;o++){const a=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=ni(s[o]),r.el=a.el),!i&&r.patchFlag!==-2&&yl(a,r)),r.type===Gs&&(r.patchFlag===-1&&(r=s[o]=ni(r)),r.el=a.el),r.type===pi&&!r.el&&(r.el=a.el)}}function qu(e){const t=e.slice(),i=[0];let n,s,o,a,r;const l=e.length;for(n=0;n<l;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function kl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:kl(t)}function Nr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function wl(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?wl(t.subTree):null}const xl=e=>e.__isSuspense;function Yu(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):nu(e)}const qe=Symbol.for("v-fgt"),Gs=Symbol.for("v-txt"),pi=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),li=[];let Tt=null;function Q(e=!1){li.push(Tt=e?null:[])}function or(){li.pop(),Tt=li[li.length-1]||null}let Un=1;function zr(e,t=!1){Un+=e,e<0&&Tt&&t&&(Tt.hasOnce=!0)}function Sl(e){return e.dynamicChildren=Un>0?Tt||sn:null,or(),Un>0&&Tt&&Tt.push(e),e}function te(e,t,i,n,s,o){return Sl(p(e,t,i,n,s,o,!0))}function Zt(e,t,i,n,s){return Sl(ae(e,t,i,n,s,!0))}function rr(e){return e?e.__v_isVNode===!0:!1}function wn(e,t){return e.type===t.type&&e.key===t.key}const Cl=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Xe(e)||De(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,n=0,s=null,o=e===qe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Cl(t),ref:t&&ps(t),scopeId:Xa,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:ct};return r?(As(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=it(i)?8:16),Un>0&&!a&&Tt&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Tt.push(l),l}const ae=Zu;function Zu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===xu)&&(e=pi),rr(e)){const r=un(e,t,!0);return i&&As(r,i),Un>0&&!o&&Tt&&(r.shapeFlag&6?Tt[Tt.indexOf(e)]=r:Tt.push(r)),r.patchFlag=-2,r}if(cf(e)&&(e=e.__vccOpts),t){t=Ju(t);let{class:r,style:l}=t;r&&!it(r)&&(t.class=_e(r)),Ge(l)&&(Qo(l)&&!Ee(l)&&(l=dt({},l)),t.style=qt(l))}const a=it(e)?1:xl(e)?128:cu(e)?64:Ge(e)?4:De(e)?2:0;return p(e,t,i,n,s,a,o,!0)}function Ju(e){return e?Qo(e)||pl(e)?dt({},e):e:null}function un(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?Xu(s||{},t):s,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Cl(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==qe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&un(e.ssContent),ssFallback:e.ssFallback&&un(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&n&&tr(u,l.clone(u)),u}function Ct(e=" ",t=0){return ae(Gs,null,e,t)}function pt(e,t){const i=ae(fs,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(Q(),Zt(pi,null,e)):ae(pi,null,e)}function Gt(e){return e==null||typeof e=="boolean"?ae(pi):Ee(e)?ae(qe,null,e.slice()):rr(e)?ni(e):ae(Gs,null,String(e))}function ni(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:un(e)}function As(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),As(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!pl(t)?t._ctx=ct:s===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(De(t)){if(n&65){As(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[Ct(t)]):i=8;e.children=t,e.shapeFlag|=i}function Xu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(s==="style")t.style=qt([t.style,n.style]);else if(Ls(s)){const o=t[s],a=n[s];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[s]=o?[].concat(o,a):a:a==null&&o==null&&!Ps(s)&&(t[s]=a)}else s!==""&&(t[s]=n[s])}return t}function jt(e,t,i,n=null){Ht(e,t,7,[i,n])}const Qu=ll();let ef=0;function tf(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Qu,o={uid:ef++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Id(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ml(n,s),emitsOptions:cl(n,s),emit:null,emitted:null,propsDefaults:Ke,inheritAttrs:n.inheritAttrs,ctx:Ke,data:Ke,props:Ke,attrs:Ke,slots:Ke,refs:Ke,setupState:Ke,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Du.bind(null,o),e.ce&&e.ce(o),o}let gt=null;const nf=()=>gt||ct;let Bs,Ao;{const e=zs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(a=>a(o)):s[0](o)}};Bs=t("__VUE_INSTANCE_SETTERS__",i=>gt=i),Ao=t("__VUE_SSR_SETTERS__",i=>Vn=i)}const Xn=e=>{const t=gt;return Bs(e),e.scope.on(),()=>{e.scope.off(),Bs(t)}},Hr=()=>{gt&&gt.scope.off(),Bs(null)};function _l(e){return e.vnode.shapeFlag&4}let Vn=!1;function sf(e,t=!1,i=!1){t&&Ao(t);const{props:n,children:s}=e.vnode,o=_l(e);zu(e,n,o,t),Wu(e,s,i||t);const a=o?of(e,t):void 0;return t&&Ao(!1),a}function of(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Cu);const{setup:n}=i;if(n){di();const s=e.setupContext=n.length>1?af(e):null,o=Xn(e),a=Jn(n,e,0,[e.props,s]),r=$a(a);if(ui(),o(),(r||e.sp)&&!an(e)&&il(e),r){if(a.then(Hr,Hr),t)return a.then(l=>{Fr(e,l)}).catch(l=>{js(l,e,0)});e.asyncDep=a}else Fr(e,a)}else $l(e)}function Fr(e,t,i){De(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ge(t)&&(e.setupState=Ka(t)),$l(e)}function $l(e,t,i){const n=e.type;e.render||(e.render=n.render||Xt);{const s=Xn(e);di();try{_u(e)}finally{ui(),s()}}}const rf={get(e,t){return ht(e,"get",""),e[t]}};function af(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,rf),slots:e.slots,emit:e.emit,expose:t}}function Ks(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ka(Kd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in An)return An[i](e)},has(t,i){return i in t||i in An}})):e.proxy}function lf(e,t=!0){return De(e)?e.displayName||e.name:e.name||t&&e.__name}function cf(e){return De(e)&&"__vccOpts"in e}const be=(e,t)=>Xd(e,t,Vn),df="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Bo;const jr=typeof window<"u"&&window.trustedTypes;if(jr)try{Bo=jr.createPolicy("vue",{createHTML:e=>e})}catch{}const Il=Bo?e=>Bo.createHTML(e):e=>e,uf="http://www.w3.org/2000/svg",ff="http://www.w3.org/1998/Math/MathML",ii=typeof document<"u"?document:null,Wr=ii&&ii.createElement("template"),pf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?ii.createElementNS(uf,e):t==="mathml"?ii.createElementNS(ff,e):i?ii.createElement(e,{is:i}):ii.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>ii.createTextNode(e),createComment:e=>ii.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ii.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const a=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Wr.innerHTML=Il(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Wr.content;if(n==="svg"||n==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},hf=Symbol("_vtc");function mf(e,t,i){const n=e[hf];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ds=Symbol("_vod"),Ml=Symbol("_vsh"),Do={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ds]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):xn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),xn(e,!0),n.enter(e)):n.leave(e,()=>{xn(e,!1)}):xn(e,t))},beforeUnmount(e,{value:t}){xn(e,t)}};function xn(e,t){e.style.display=t?e[Ds]:"none",e[Ml]=!t}const gf=Symbol(""),vf=/(?:^|;)\s*display\s*:/;function bf(e,t,i){const n=e.style,s=it(i);let o=!1;if(i&&!s){if(t)if(it(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&Cn(n,r,"")}else for(const a in t)i[a]==null&&Cn(n,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?kf(e,a,!it(t)&&t?t[a]:void 0,r)||Cn(n,a,r):Cn(n,a,"")}}else if(s){if(t!==i){const a=n[gf];a&&(i+=";"+a),n.cssText=i,o=vf.test(i)}}else t&&e.removeAttribute("style");Ds in e&&(e[Ds]=o?n.display:"",e[Ml]&&(n.display="none"))}const Ur=/\s*!important$/;function Cn(e,t,i){if(Ee(i))i.forEach(n=>Cn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=yf(e,t);Ur.test(i)?e.setProperty($i(n),i.replace(Ur,""),"important"):e[n]=i}}const Vr=["Webkit","Moz","ms"],ao={};function yf(e,t){const i=ao[t];if(i)return i;let n=xt(t);if(n!=="filter"&&n in e)return ao[t]=n;n=Rs(n);for(let s=0;s<Vr.length;s++){const o=Vr[s]+n;if(o in e)return ao[t]=o}return t}function kf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Gr="http://www.w3.org/1999/xlink";function Kr(e,t,i,n,s,o=_d(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Gr,t.slice(6,t.length)):e.setAttributeNS(Gr,t,i):i==null||o&&!Ea(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Nt(i)?String(i):i)}function qr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Il(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Ea(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(s||t)}function ki(e,t,i,n){e.addEventListener(t,i,n)}function wf(e,t,i,n){e.removeEventListener(t,i,n)}const Yr=Symbol("_vei");function xf(e,t,i,n,s=null){const o=e[Yr]||(e[Yr]={}),a=o[t];if(n&&a)a.value=n;else{const[r,l]=_f(t);if(n){const c=o[t]=Mf(n,s);ki(e,r,c,l)}else a&&(wf(e,r,a,l),o[t]=void 0)}}const Sf=/(Once|Passive|Capture)$/,Cf=/^on:?(?:Once|Passive|Capture)$/;function _f(e){let t,i;for(;(i=e.match(Sf))&&!Cf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):$i(e.slice(2)),t]}let lo=0;const $f=Promise.resolve(),If=()=>lo||($f.then(()=>lo=0),lo=Date.now());function Mf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ee(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const a=s.slice(),r=[n];for(let l=0;l<a.length&&!n._stopped;l++){const c=a[l];c&&Ht(c,t,5,r)}}else Ht(s,t,5,[n])};return i.value=e,i.attached=If(),i}const Zr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Tf=(e,t,i,n,s,o)=>{const a=s==="svg";t==="class"?mf(e,n,a):t==="style"?bf(e,i,n):Ls(t)?Ps(t)||xf(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Ef(e,t,n,a))?(qr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Kr(e,t,n,a,o,t!=="value")):e._isVueCE&&(Af(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?qr(e,xt(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Kr(e,t,n,a))};function Ef(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Zr(t)&&De(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Zr(t)&&it(i)?!1:t in e}function Af(e,t){const i=e._def.props;if(!i)return!1;const n=xt(t);return Array.isArray(i)?i.some(s=>xt(s)===n):Object.keys(i).some(s=>xt(s)===n)}const fn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>us(t,i):t};function Bf(e){e.target.composing=!0}function Jr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ci=Symbol("_assign");function Xr(e,t,i){return t&&(e=e.trim()),i&&(e=Ns(e)),e}const Lo={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[ci]=fn(s);const o=n||s.props&&s.props.type==="number";ki(e,t?"change":"input",a=>{a.target.composing||e[ci](Xr(e.value,i,o))}),(i||o)&&ki(e,"change",()=>{e.value=Xr(e.value,i,o)}),t||(ki(e,"compositionstart",Bf),ki(e,"compositionend",Jr),ki(e,"change",Jr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},a){if(e[ci]=fn(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Ns(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===l)||(e.value=l)}},as={deep:!0,created(e,t,i){e[ci]=fn(i),ki(e,"change",()=>{const n=e._modelValue,s=Gn(e),o=e.checked,a=e[ci];if(Ee(n)){const r=Go(n,s),l=r!==-1;if(o&&!l)a(n.concat(s));else if(!o&&l){const c=[...n];c.splice(r,1),a(c)}}else if(pn(n)){const r=new Set(n);o?r.add(s):r.delete(s),a(r)}else a(Tl(e,o))})},mounted:Qr,beforeUpdate(e,t,i){e[ci]=fn(i),Qr(e,t,i)}};function Qr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ee(t))s=Go(t,n.props.value)>-1;else if(pn(t))s=t.has(n.props.value);else{if(t===i)return;s=hn(t,Tl(e,!0))}e.checked!==s&&(e.checked=s)}const Df={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,ki(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Ns(Gn(o)):Gn(o));e[ci](e.multiple?pn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Is(()=>{e._assigning=!1})}),e[ci]=fn(n)},mounted(e,{value:t}){ea(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ci]=fn(i)},updated(e,{value:t}){e._assigning||ea(e,t)}};function ea(e,t){const i=e.multiple,n=Ee(t);if(!(i&&!n&&!pn(t))){for(let s=0,o=e.options.length;s<o;s++){const a=e.options[s],r=Gn(a);if(i)if(n){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Go(t,r)>-1}else a.selected=t.has(r);else if(hn(Gn(a),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Gn(e){return"_value"in e?e._value:e.value}function Tl(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Lf=["ctrl","shift","alt","meta"],Pf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Lf.some(i=>e[`${i}Key`]&&!t.includes(i))},Yt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let a=0;a<t.length;a++){const r=Pf[t[a]];if(r&&r(s,t))return}return e(s,...o)}))},Of={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Rf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=$i(s.key);if(t.some(a=>a===o||Of[a]===o))return e(s)}))},Nf=dt({patchProp:Tf},pf);let ta;function zf(){return ta||(ta=Vu(Nf))}const ar=((...e)=>{const t=zf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Ff(n);if(!s)return;const o=t._component;!De(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const a=i(s,!1,Hf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),a},t});function Hf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Ff(e){return it(e)?document.querySelector(e):e}const jf="slides-config.json",Ci={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Ut=Fs({...Ci});function Wf(e){if(!e||typeof e!="object")return{...Ci};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Ci.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Ci.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Ci.showOrderedListMarkers}}function si(e){if(!e||typeof e!="object")return{...Ut};const t=e;return t.enableWebServeJump!==void 0&&(Ut.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ut.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ut.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ut.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ut.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Ut}}function qs(){return{...Ut}}function El(e,t,i){const n=(e||Ci.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(s);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Ei={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Uf(e){var s,o,a,r,l,c;const t=qs();if(!e)return{...Ei,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[wr]!==void 0?e[wr]!=="false":t.showUnorderedListMarkers,n=e[xr]!==void 0?e[xr]!=="false":t.showOrderedListMarkers;return{theme:((s=e[On])==null?void 0:s.trim())||Ei.theme,aspectRatio:((o=e[Rn])==null?void 0:o.trim())||Ei.aspectRatio,highlighter:((a=e[ka])==null?void 0:a.trim())||Ei.highlighter,defaultTransition:((r=e[Nn])==null?void 0:r.trim())||Ei.defaultTransition,colorSchema:((l=e[wa])==null?void 0:l.trim())||Ei.colorSchema,spacing:((c=e[wo])==null?void 0:c.trim())||Ei.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:n}}function Kn(e){var i,n,s,o,a;const t=(i=e.ial)==null?void 0:i[Li];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function ia(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[we]&&(t.layout=e[we].trim()),e[mt]&&(t.transition=e[mt].trim()),e[nt]&&(t.background=e[nt].trim()),e[Pt]&&(t.image=e[Pt].trim()),e[Qi]&&(t.class=e[Qi].trim()),e[$n]&&(t.spacing=e[$n].trim()),e[kt]&&(t.layoutRatio=e[kt].trim()),e[en]&&(t.mask=e[en].trim()),e[Ni]&&(t.maskRatio=e[Ni].trim()),e[tn]&&(t.maskStyle=e[tn].trim()),e[nn]&&(t.maskInitial=e[nn].trim()),e[Xs]&&(i=e[Xs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![we,kt,en,Ni,tn,nn,mt,nt,Pt,Qi,$n,Xs,Li].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function Vf(e){const t={};if(!e)return t;const i=e[Ve]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slides-role"],s=e[nt]??e["slides-background"];(n===xa||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[we]??e["slides-layout"];o===Ss||o===Cs?t.imageLayout=o:(n===Ss||n===Cs)&&(t.imageLayout=n);const a=e[ze]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Jt])try{const r=JSON.parse(e[Jt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Jt].trim()}}return e[Ui]&&(t.shikiLines=e[Ui].trim()),e[zn]&&(t.maxHeight=e[zn].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function _i(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Bn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),a=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),d=u?u[1].length:0;d>=a?r.push(c.slice(a)):d>s?r.push(c.slice(d)):r.push(c)}return r.join(`
`)}function Vi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function co(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Dn(e){if(!e)return[];if(ot(e)&&Qt(e)&&!mi(e)){const n=gn(e),s=[];for(const o of n)s.push(...Dn(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Vi);if(a.length>0)return a}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<s.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(s[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:s.length,u=s.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Vi(e)?[e]:[]}function lr(e){var s;if(!e||!ot(e)||!Qt(e)||mi(e))return null;const t=gn(e);if(t.length===0)return null;if(t.length===1&&ot(t[0])&&Qt(t[0])){const o=lr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(ot(o)){i.push(o);const a=((s=o.children)==null?void 0:s.filter(ot))||[];i.push(...a)}const n=t.map(Dn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Dn(t[0]),a=Dn(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function Gf(e){if(!e||!ot(e)||!Qt(e)||mi(e))return null;const t=lr(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=cr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:s}}function Al(e){if(!e||!ot(e)||!Qt(e)||mi(e))return null;const t=gn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Dn(n);if(s.length===0)return null;i.push(...s)}return i}function Kf(e){if(!e||!ot(e)||!Qt(e)||mi(e))return null;const t=Al(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function qf(e){if(!e||!ot(e)||!Qt(e)||mi(e))return null;const t=lr(e);if(t&&t.items.length===4)return t.items;const i=Al(e);if(i&&i.length===4)return i;const n=gn(e);return n.length===4?n:null}function Yf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,l){if(ot(r)){const c=qf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,l)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),s||(s=i[0]);const a=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>Bl(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:a}}function Zf(e,t,i){var u,d,h,f,v;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(Kn(b)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},a.push(r)}else r.blocks.push(b)}function l(m){const b=[];for(const y of m)ot(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...l(y.children));return b}function c(m,b,y){const S={blockId:m,attrs:b,previousAttrs:y};n.push(S),i!=null&&i.onTagChange&&i.onTagChange(S)}for(const m of a){const b=m.pageTargetId,y=t.find(T=>T.id===b),S=o.find(T=>T.pageTargetId===b);if(m.blocks.some(T=>{var C,D;return!!(mi(T)||Po(T)&&(((C=T.ial)==null?void 0:C[we])==="image-left"||((D=T.ial)==null?void 0:D[we])==="image-right"))})){if(S){const T=S.headerId;if(T){c(T,{[Me]:""});const C=t.find(D=>D.id===T);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of S.itemIds){c(C,{[Me]:""});const D=t.find(F=>F.id===C);D!=null&&D.ial&&(D.ial[Me]="")}}continue}let w=null,$=-1;for(let T=0;T<m.blocks.length;T++){const C=m.blocks[T],D=ot(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const F of D){const W=Gf(F);if(W){w=W,$=T;break}}if(w)break}if(w){const{superBlockNode:T,layout:C,items:D,slots:F}=w,K=m.blocks.slice(0,$).find(B=>Bl(B)),_=K==null?void 0:K.id,j=((u=y==null?void 0:y.ial)==null?void 0:u[we])||"",k=j==="clover",E=k?"clover":C;if(j!==E&&(c(b,{[we]:E},{[we]:j}),y&&(y.ial||(y.ial={}),y.ial[we]=E)),K){const B=((d=K.ial)==null?void 0:d[Me])||"";B!=="header"&&(c(K.id,{[Me]:"header"},{[Me]:B}),K.ial||(K.ial={}),K.ial[Me]="header")}if(S!=null&&S.headerId&&S.headerId!==_){c(S.headerId,{[Me]:""});const B=t.find(L=>L.id===S.headerId);B&&(B.ial||(B.ial={}),B.ial[Me]="")}const N=[];for(let B=0;B<D.length;B++){const L=D[B],R=F[B];N.push(L.id);const de=((h=L.ial)==null?void 0:h[Me])||"";if(de!==R&&(c(L.id,{[Me]:R},{[Me]:de}),L.ial||(L.ial={}),L.ial[Me]=R),L.children&&L.children.length>0)for(const V of L.children)V.ial||(V.ial={}),V.ial[Me]!==R&&(V.ial[Me]=R)}if(S!=null&&S.itemIds){for(const B of S.itemIds)if(!N.includes(B)){c(B,{[Me]:""});const L=t.find(R=>R.id===B);L&&(L.ial||(L.ial={}),L.ial[Me]="")}}s.push({superBlockId:T.id,nestedSuperBlockIds:(f=w.nestedSuperBlocks)==null?void 0:f.map(B=>B.id),pageTargetId:b,headerId:_,itemIds:N,layout:k?"clover":C})}else{let T=!1;const C=[];for(const W of m.blocks){const K=ot(W)?[W,...l(W.children||[])]:W.children?l(W.children):[];for(const _ of K){const j=Kf(_);if(j){T=!0;for(const k of j.items)C.push(k.id)}}}const D=((v=y==null?void 0:y.ial)==null?void 0:v[we])||"",F=Hn(D);if(S||T&&F){c(b,{[we]:""},{[we]:D}),y&&(y.ial||(y.ial={}),y.ial[we]="");const W=S==null?void 0:S.headerId;if(W){c(W,{[Me]:""});const _=t.find(j=>j.id===W);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const K=new Set([...(S==null?void 0:S.itemIds)||[],...C]);for(const _ of K){c(_,{[Me]:""});const j=t.find(k=>k.id===_);j&&(j.ial||(j.ial={}),j.ial[Me]="")}}}}return{changes:n,newTracked:s}}function ot(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Qt(e){if(!ot(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Po(e){return!e||Vi(e)||ot(e)||!_i(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function cr(e){var h;if(!e||!ot(e)||!Qt(e))return null;const t=gn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const f of t){const v=(((h=f.ial)==null?void 0:h.style)||f.style||"").trim();let m=null;if(v){const b=v.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=v.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((f,v)=>f+(v||0),0),a=i.filter(f=>f===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/s,c=i.map(f=>f!==null?f:l),u=c.reduce((f,v)=>f+v,0);if(u<=0)return null;const d=c.map(f=>f/u*100);if(d.length===2){const[f]=d;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const v=Math.round(f),m=100-v;return`${v}:${m}`}if(d.length===3){const[f,v,m]=d;if(f>=31&&f<=35&&v>=31&&v<=35&&m>=31&&m<=35)return"1:1:1";if(f>=23&&f<=27&&v>=48&&v<=52&&m>=23&&m<=27)return"1:2:1";if(f>=48&&f<=52&&v>=23&&v<=27&&m>=23&&m<=27)return"2:1:1";if(f>=23&&f<=27&&v>=23&&v<=27&&m>=48&&m<=52)return"1:1:2";if(f>=18&&f<=22&&v>=58&&v<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(f),y=Math.round(v),S=100-b-y;return`${b}:${y}:${S}`}return d.map(f=>Math.round(f)).join(":")}function mi(e){if(!e||!ot(e)||!Qt(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Po(t[0]),n=Po(t[t.length-1]),s=cr(e)||void 0;if(i&&!n){const o=_i(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Ss,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=_i(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:Cs,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Jf(e,t){const i=[];function n(s){for(const o of s){const a=mi(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[we];if(u!==l){const h={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[we]=l,i.push(h),t&&t(h)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function gn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Bl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ai(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const y=a[1].match(/\bclass=["']([^"']*)["']/i);if(y){const S=y[1];if(typeof t=="string"?S.split(/\s+/).includes(t):t.test(S)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,l);const u=l+c;let d=1,h=-1,f=-1;const v=/<\/?div\b[^>]*>/gi;v.lastIndex=u;let m;for(;(m=v.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){h=m.index,f=m.index+m[0].length;break}}else d++;if(h!==-1&&f!==-1){const b=e.slice(u,h);n+=i(b),s=f}else n+=e.slice(l,u),s=u}return n}function Xf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,a=!1,r=-1,l=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+l;let u=1,d=-1,h=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let v;for(;(v=f.exec(e))!==null;)if(v[0].startsWith("</")){if(u--,u===0){d=v.index,h=v.index+v[0].length;break}}else u++;if(d!==-1&&h!==-1){const m=e.slice(r,h),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,n=h}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Qf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),l});const{text:s,tokens:o}=Xf(i);i=s;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ai(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),d=c[3].trim();return`**${u}:**
\`\`\`yaml
${d}
\`\`\``}).join(`

`)+`
`:r}),i=Ai(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=Ai(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let d="-";return u.includes("warn")?d="- ⚠️":u.includes("bad")?d="- ❌":u.includes("ok")&&(d="- ✅"),`${d} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ai(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ai(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ai(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ai(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((d,h)=>Math.max(d,h.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,d)=>{const h=d.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Dl(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function ep(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function tp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Ll(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function ip(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function ls(e,t,i,n){const s=t!=null&&t.trim()!=="",o=ip(i),a=n==null?void 0:n.trim(),r=a!==void 0&&a!=="",l=r?` style="${a.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${l}>

${e}

</div>`:e;if(s&&!o){if(r){const v=t.trim();let m="v-click";return v==="hide"?m="v-click.hide":v!==""&&v!=="+1"&&(m=`v-click="${v}"`),`<div ${m}${l}>

${e}

</div>`}return Ll(e,t)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),u=JSON.stringify(o.enter).replace(/"/g,"'"),d=`v-motion :initial="${c}" :enter="${u}"`;if(!s)return`<div ${d}${l}>

${e}

</div>`;const h=t.trim();let f="v-click";return h==="hide"?f="v-click.hide":h!==""&&h!=="+1"&&(f=`v-click="${h}"`),`<div ${f} ${d}${l}>

${e}

</div>`}function dr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function np(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Pl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),d=Math.min(i,c.length),h=Math.floor(c.length/d),f=c.length%d;let v=0;for(let m=0;m<d;m++){const b=h+(m<f?1:0);u[m]=c.slice(v,v+b),v+=b}return u}if(e.length===1){const c=e[0],d=(c.slot||"").trim().match(/^col-(\d+)$/i),h=d?parseInt(d[1],10):null,f=(c.rawMarkdown||c.content||"").trim(),v=f.split(/\r?\n/),m=[];for(let S=0;S<v.length;S++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(v[S])&&m.push(S);if(m.length>=i){const S=Array.from({length:i},()=>[]);let x=0;for(let w=0;w<i;w++){const $=i-w,T=m.length-x,C=Math.ceil(T/$),D=m[x],F=x+C<m.length?m[x+C]:v.length,W=v.slice(D,F).join(`
`);S[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:W,content:W}],x+=C}return S}const b=f.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const S=Array.from({length:i},()=>[]);let x=0;for(let w=0;w<i;w++){const $=i-w,T=b.length-x,C=Math.ceil(T/$),D=`<ul>
${b.slice(x,x+C).join(`
`)}
</ul>`;S[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:D,content:D}],x+=C}return S}const y=f.split(/\r?\n\s*\r?\n/).filter(S=>S.trim()!=="");if(y.length>=i){const S=Array.from({length:i},()=>[]);let x=0;for(let w=0;w<i;w++){const $=i-w,T=y.length-x,C=Math.ceil(T/$),D=y.slice(x,x+C).join(`

`);S[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:D,content:D}],x+=C}return S}if(h&&h>=1&&h<=i){const S=Array.from({length:i},()=>[]);return S[h-1]=[c],S}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const d=u.match(/^col-(\d+)$/i);if(d){const h=parseInt(d[1],10);if(h>=1&&h<=i)return h}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(f=>f!==null&&f>=2)){const f=Array.from({length:i},()=>[]);let v=1;for(const b of e){const y=n(b);y!==null&&(v=y),f[v-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&f[0].length===0){const b=f.filter(y=>y.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return f}const u=e.filter(f=>n(f)===1),d=e.filter(f=>n(f)===null),h=i-1;if(d.length>=h){const f=Math.floor(d.length/h),v=d.length%h,m=[u];let b=0;for(let y=0;y<h;y++){const S=f+(y<v?1:0);m.push(d.slice(b,b+S)),b+=S}return m}else if(d.length>0){const f=[u];for(let v=0;v<h;v++)f.push(v<d.length?[d[v]]:[]);return f}else return[u,...Array.from({length:h},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const d=r[u],h=u+1<i?r[u+1]:e.length;c[u]=e.slice(d,h)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let d=0;d<i;d++){const h=i-d,f=e.length-u,v=Math.ceil(f/h);c[d]=e.slice(u,u+v),u+=v}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function na(e,t,i,n){var u;const s=Uf(t),o=[],a=ia(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=At(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=At(r.frontmatter.image,n)),o.push(r);let l=[];for(const d of i){if(Kn(d)){l=[];const f=ia(d.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=d.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(d.id)||r.allBlockIds.push(d.id),f.frontmatter.layout&&(r.frontmatter.layout=f.frontmatter.layout),Object.assign(r.frontmatter,f.frontmatter),!f.frontmatter.image&&a.frontmatter.image&&(r.frontmatter.image=a.frontmatter.image),!f.frontmatter.background&&a.frontmatter.background&&(r.frontmatter.background=a.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=At(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=At(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:d.id,frontmatter:{layout:f.frontmatter.layout||"default",...f.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[d.id]},r.frontmatter.background&&(r.frontmatter.background=At(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=At(r.frontmatter.image,n)),o.push(r);continue}const h=(f,v)=>{var B,L,R,de,V,Y;if(r.allBlockIds||(r.allBlockIds=[]),f.id&&!r.allBlockIds.includes(f.id)&&r.allBlockIds.push(f.id),f.children&&f.children.length>0){const Z=ne=>{for(const oe of ne)oe.id&&!r.allBlockIds.includes(oe.id)&&r.allBlockIds.push(oe.id),oe.children&&oe.children.length>0&&Z(oe.children)};Z(f.children)}let m=pd(f),b=f.ial?{...f.ial}:{};const y=m.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...hd(y[0]),...b},m=m.slice(0,y.index).trim()),f.type!=="c"&&!m.startsWith("```")&&(m=Dl(m));let S=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(S)||S==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(S)&&/\r?\n\}\}\}$/.test(S)&&(m=S.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),S=m.trim());const x=Vf(b);if(m=md(m,n),m=ud(m,n==null?void 0:n.refContentMap),f.children&&f.children.length>0){const Z=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ne=oe=>{for(const ye of oe){if(ye.ial)for(const[Ie,Ce]of Object.entries(ye.ial))Z.includes(Ie)&&!b[Ie]&&(b[Ie]=Ce);ye.children&&ye.children.length>0&&ne(ye.children)}};ne(f.children)}const w=f.type==="video"||f.type==="NodeVideo"||/<video\b/i.test(m);if(w){const Z=b["custom-slides-autoplay"]==="true",ne=b["custom-slides-loop"]==="true",oe=b["custom-slides-muted"]==="true"||Z,ye=b["custom-slides-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(Ie,Ce)=>{let le=Ce;return ye?le=le.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(le)||(le+=" controls"),Z&&!/autoplay/i.test(le)?le+=" autoplay playsinline":!Z&&b["custom-slides-autoplay"]==="false"&&(le=le.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ne&&!/loop/i.test(le)?le+=" loop":!ne&&b["custom-slides-loop"]==="false"&&(le=le.replace(/\bloop\b/gi,"").trim()),oe&&!/muted/i.test(le)?le+=" muted":!oe&&b["custom-slides-muted"]==="false"&&(le=le.replace(/\bmuted\b/gi,"").trim()),`<video ${le.trim()}>`})}if(x.isBackground){const Z=_i(m,f.content);if(Z){r.frontmatter.background=At(Z,n);return}}const $=mi(f);if($){r.frontmatter.layout=$.layout,r.frontmatter.image=At($.imageUrl,n),!r.frontmatter.layoutRatio&&$.ratio&&(r.frontmatter.layoutRatio=$.ratio);for(const Z of $.contentNodes)h(Z);return}if(x.imageLayout==="image-left"||x.imageLayout==="image-right"){const Z=_i(m,f.content);if(Z){r.frontmatter.layout=x.imageLayout,r.frontmatter.image=At(Z,n),!r.frontmatter.layoutRatio&&((B=f.ial)!=null&&B[kt])&&(r.frontmatter.layoutRatio=f.ial[kt]);return}}if(ot(f)&&f.children&&f.children.length>0){for(const Z of f.children)h(Z);return}const T=!!(x.slot||v!=null&&v.defaultSlot||r.frontmatter.layout==="clover"||Hn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((f.type==="l"||f.type==="NodeList"||f.type==="list")&&f.children&&f.children.length>0&&(f.children.some(Z=>{var ne,oe;return((ne=Z.ial)==null?void 0:ne[Me])||((oe=Z.ial)==null?void 0:oe[ze])})||x.slot||x.clicks||T)){const Z=/^\s*\d+\.\s+/m.test(f.markdown||"")||f.subType==="o"||f.subtype==="o";for(let ne=0;ne<f.children.length;ne++){const oe=f.children[ne];x.slot&&(!oe.ial||!oe.ial[Me])&&(oe.ial||(oe.ial={}),oe.ial[Me]=x.slot),h(oe,{...v,parentClicks:x.clicks||(v==null?void 0:v.parentClicks),defaultSlot:x.slot||(v==null?void 0:v.defaultSlot),isParentListUnpacked:!0,listContext:{isOrdered:Z,itemIndex:ne+1}})}return}const C=!!(v!=null&&v.isParentListUnpacked),D=!!(f.children&&f.children.length>=2)||!!x.clicks||!!((L=f.children)!=null&&L.some(Z=>{var ne;return(ne=Z.ial)==null?void 0:ne[ze]}))||C||!f.markdown&&!!(f.children&&f.children.length>0);if(Vi(f)&&f.children&&f.children.length>0&&(T||C||x.clicks||f.children.some(Z=>{var ne;return(ne=Z.ial)==null?void 0:ne[ze]}))&&D){const Z=!!(f.children&&f.children.length>=2),ne=f.children.find(ce=>!!(ce.markdown||ce.content||"").trim())||f.children[0],oe=((R=ne==null?void 0:ne.ial)==null?void 0:R[ze])||((de=ne==null?void 0:ne.ial)==null?void 0:de["custom-slides-click"]),ye=!!(!x.clicks&&Z&&oe),Ie=x.clicks||(ye?oe:void 0)||(v==null?void 0:v.parentClicks),Ce=f.id||(v==null?void 0:v.parentContainerId),le=x.slot||(v==null?void 0:v.defaultSlot);let X=!0;for(const ce of f.children){le&&(!ce.ial||!ce.ial[Me])&&(ce.ial||(ce.ial={}),ce.ial[Me]=le);const P=!!(ce.markdown||ce.content||"").trim(),U=X&&P;if(U){if(T)ce.markdown&&(ce.markdown=Bn(ce.markdown)),ce.content&&(ce.content=Bn(ce.content));else{const G=!!((V=v==null?void 0:v.listContext)!=null&&V.isOrdered),H=((Y=v==null?void 0:v.listContext)==null?void 0:Y.itemIndex)||1,I=G?`${H}. `:"- ",M=O=>{if(!O)return I.trim();const q=O.trim();return/^[-*+]\s+/.test(q)||/^\d+\.\s+/.test(q)?O:`${I}${O}`};ce.markdown&&(ce.markdown=M(ce.markdown)),ce.content&&(ce.content=M(ce.content))}X=!1}let g=ce;U&&Ie&&Z?(g={...ce,ial:{...ce.ial||{}}},delete g.ial[ze],delete g.ial["custom-slides-click"]):!Z&&Ie&&(g={...ce,ial:{...ce.ial||{},[ze]:Ie}}),h(g,{parentClicks:Ie,parentContainerId:Ce,defaultSlot:le})}return}if(x.isNote){const Z=dr(m);Z&&(r.notes?r.notes+=`

`+Z:r.notes=Z),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:f.id,type:f.type,content:Z||f.content||"",rawMarkdown:m,isNote:!0,attributes:f.ial});return}x.shikiLines&&(m=tp(m,x.shikiLines)),S=m.trim();const F=(f.content||"").trim();if(S==="::right::"||F==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(S)||S.startsWith("::right::")){r.blocks.push({id:f.id,type:f.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:f.ial});return}const K=np(f);let _=x.slot,j=x.clicks,k=x.motion,E={...f.ial||{}};if(K!==null){for(;l.length>0&&l[l.length-1].level>=K;)l.pop();const Z=l.length>0?l[l.length-1]:void 0;!_&&(Z!=null&&Z.slot)&&(_=Z.slot),!j&&(Z!=null&&Z.clicks)&&!(v!=null&&v.parentContainerId)&&(j=Z.clicks),!k&&(Z!=null&&Z.motion)&&(k=Z.motion);const ne={...(Z==null?void 0:Z.customAttrs)||{}};if(f.ial)for(const[oe,ye]of Object.entries(f.ial))oe.startsWith("custom-slides-")&&!oe.startsWith("custom-slides-slide")&&(ne[oe]=ye);v!=null&&v.parentContainerId||l.push({level:K,slot:_,clicks:j,motion:k,customAttrs:ne})}else{const Z=l.length>0?l[l.length-1]:void 0;Z&&(!_&&Z.slot&&Z.slot!=="header"&&(_=Z.slot),!j&&Z.clicks&&!(v!=null&&v.parentContainerId)&&(j=Z.clicks),!k&&Z.motion&&(k=Z.motion),Z.customAttrs&&(E={...Z.customAttrs,...E}))}!_&&r.blocks.some(Z=>Z.slot==="slot-divider-right")&&(_="right"),!_&&(v!=null&&v.defaultSlot)&&(_=v.defaultSlot),_&&(E[Me]=_),j&&!E[ze]&&(E[ze]=j),k&&!E[Jt]&&(E[Jt]=JSON.stringify(k)),(w||b["custom-slides-autoplay"]||b["custom-slides-muted"])&&(b["custom-slides-autoplay"]&&(E["custom-slides-autoplay"]=b["custom-slides-autoplay"],b["custom-slides-autoplay"]==="true"&&!b["custom-slides-muted"]&&(E["custom-slides-muted"]="true")),b["custom-slides-loop"]&&(E["custom-slides-loop"]=b["custom-slides-loop"]),b["custom-slides-muted"]&&(E["custom-slides-muted"]=b["custom-slides-muted"]),b["custom-slides-controls"]&&(E["custom-slides-controls"]=b["custom-slides-controls"]));const N={id:f.id,type:f.type,content:f.content||"",rawMarkdown:m,clicks:j,parentClicks:v==null?void 0:v.parentClicks,parentContainerId:v==null?void 0:v.parentContainerId,motion:k,shikiLines:x.shikiLines,slot:_,attributes:E,rawNode:f};r.blocks.push(N)};h(d)}for(let d=0;d<o.length;d++){const h=o[d],f=[],v={...h.frontmatter};d===0&&(v.theme=s.theme,v.aspectRatio=s.aspectRatio,v.highlighter=s.highlighter,v.transition=h.frontmatter.transition||s.defaultTransition);const m=ep(v);m&&f.push(m);const b=h.blocks.filter($=>$.slot!=="slot-divider-right"),y=$=>$.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var C;return ls(T.rawMarkdown,T.clicks,T.motion,(C=T.attributes)==null?void 0:C.style)}).join(`

`),S=$=>{const T=$.filter(W=>!!(W.rawMarkdown||W.content||"").trim());if(T.length===0)return;const C=T[0],D=(C.rawMarkdown||C.content||"").trim();(Vi(C)||/^(?:[-*+]|\d+\.)\s+/.test(D))&&(C.rawMarkdown=Bn(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},x=$=>{var W,K;if($.length===0)return"";S($);const T=(W=$.find(_=>_.parentClicks))==null?void 0:W.parentClicks;if(!T)return $.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var j;return ls(_.rawMarkdown,_.clicks,_.motion,(j=_.attributes)==null?void 0:j.style)}).join(`

`);const C=[];let D=[];const F=()=>{if(D.length===0)return;const _=D.map(j=>(j.rawMarkdown||j.content||"").trim()).filter(Boolean).join(`

`);_&&C.push(Ll(_,T)),D=[]};for(const _ of $){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(F(),C.push(ls(_.rawMarkdown,_.clicks,_.motion,(K=_.attributes)==null?void 0:K.style))):D.push(_)}return F(),C.join(`

`)},w=h.frontmatter.layout||"default";if(w==="clover"||Hn(w)){let $=[];const T=b.filter(_=>_.slot==="header");if(T.length>0)$=T;else if(b.length>0){const _=b.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));_&&($=[_])}const C=b.filter(_=>!$.includes(_));let D=2;if(w==="clover")D=4;else if(w==="three-cols-header")D=3;else if(w==="two-cols-header")D=2;else{let _=0;for(const j of C){const k=(j.slot||"").match(/^col-(\d+)$/i);k&&(_=Math.max(_,parseInt(k[1],10)))}if(_>=2)D=_;else if(h.frontmatter.layoutRatio){const j=h.frontmatter.layoutRatio.trim();if(j.includes(":")){const k=j.split(":").map(E=>parseFloat(E.trim())).filter(E=>!isNaN(E)&&E>0);k.length>=2&&(D=k.length)}else{const k=j.split(/\s+/).filter(Boolean);k.length>=2&&(D=k.length)}}else C.length===1&&C[0].children&&C[0].children.length>=2&&(D=Math.min(6,C[0].children.length))}const F=Pl(C,D);F.forEach((_,j)=>{const k=`col-${j+1}`;for(const E of _)(!E.slot||E.slot==="default")&&(E.slot=k);S(_)});const W=F.flat();if(C.length===1&&W.length>1){const _=h.blocks.findIndex(j=>j.id===C[0].id);_!==-1&&h.blocks.splice(_,1,...W)}const K=y($);if(K&&f.push(K),w==="two-cols-header"&&D===2){const _=x(F[0]||[]),j=x(F[1]||[]);_&&f.push(`::left::

${_}`),j&&f.push(`::right::

${j}`)}else F.forEach((_,j)=>{const k=x(_);k&&f.push(`::col-${j+1}::

${k}`)})}else if(w==="two-cols"){const $=b.filter(F=>F.slot==="left"),T=b.filter(F=>F.slot==="right");S($),S(T);const C=y($.length>0?$:b.filter(F=>F.slot!=="right")),D=y(T);f.push(C),D&&f.push(`::right::

${D}`)}else for(const $ of b)f.push(ls($.rawMarkdown,$.clicks||$.parentClicks,$.motion,(u=$.attributes)==null?void 0:u.style));h.notes&&f.push(`<!--
${h.notes}
-->`),h.rawMarkdown=f.join(`

`).trim()}const c=o.map(d=>d.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Oo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function sp(e){var s,o,a,r,l,c,u,d,h,f,v,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(a=b.dark)!=null&&a.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(l=b.light)!=null&&l.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(u=b.dark)!=null&&u.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(d=b.dark)!=null&&d.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(h=b.light)!=null&&h.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(f=b.light)!=null&&f.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(v=b.dark)!=null&&v.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Ln(e){const t=sp(e);return t?`${Oo}

/* Custom Workspace Inline Styles */
${t}`:Oo}function uo(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}function op(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function rp(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=s.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(op(a)?n.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function ap(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ro(e){return ot(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function lp(e,t,i,n=8,s){const o=new Map;for(const h of t)h!=null&&h.id&&o.set(h.id,h);const a=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:i(h.id,h.ial),children:[]}),r=h=>{let f=h.parent_id,v=0;for(;f&&f!==e&&v++<16;){const m=o.get(f);if(!m||!ap(m))return f;f=m.parent_id}return f||e},l=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||s&&s.size>0&&!s.has(h.id))continue;const f=r(h),v=l.get(f);v?v.push(h):l.set(f,[h])}if(s&&s.size>0)for(const h of l.values())h.sort((f,v)=>(s.get(f.id)??Number.MAX_SAFE_INTEGER)-(s.get(v.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(h,f)=>{const v=a(h);if(c.set(v.id,v),f>=n||!Ro(v))return v;const m=l.get(v.id);return m&&m.length>0&&(v.children=m.map(b=>u(b,f+1))),v};return{topLevel:(l.get(e)||[]).map(h=>u(h,0)),byId:c}}const cp={getBlockAttrs:jo,getChildBlocks:Yn,getDocBlocksOrders:ld,setBlockAttrs:He,sql:cn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:cd};class dp{constructor(t){ke(this,"deps");ke(this,"attrOverrides",new Map);ke(this,"trackedListSuperBlocks",new Map);ke(this,"fallbackWarnedDocId","");this.deps={...cp,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete s[o]:s[o]=String(a);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let E=0;E<o.length;E++)o[E]&&a.set(o[E],E);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=rp(s,c),d=new Map;if(Array.isArray(c))for(const E of c)E.id&&E.ial&&d.set(E.id,uo(E.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,f=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(f)){for(const E of f)if(E.block_id&&E.name){let N=d.get(E.block_id);N||(N={},d.set(E.block_id,N)),N[E.name]=E.value||""}}const v=(E,N)=>{const B={...d.get(E)||(N?uo(N):{})},L=this.attrOverrides.get(E);return L&&Object.assign(B,L),B},m=Array.isArray(c)&&c.length>0?lp(t,c,v,8,a):null,b=s.map(E=>E.id).filter(Boolean),y=E=>({id:E.id,parent_id:E.parent_id,root_id:E.root_id||t,type:E.type,subType:E.subType,content:E.content||"",markdown:E.markdown||"",ial:v(E.id,E.ial),children:E.children}),S=async(E,N=0)=>{if(!E||N>8||!Ro(E))return;const B=await this.deps.getChildBlocks(E.id).catch(()=>[])||[];if(!(!Array.isArray(B)||B.length===0)){E.children=B.filter(L=>L==null?void 0:L.id).map(L=>({id:L.id,parent_id:E.id,root_id:t,type:L.type,subType:L.subType,content:L.content||"",markdown:L.markdown||"",ial:v(L.id,L.ial),children:[]}));for(const L of E.children)await S(L,N+1)}},x=new Map;for(const E of c)E!=null&&E.id&&x.set(E.id,E);const w=b.every(E=>{const N=x.get(E);return!N||!!N.type});let $=[],T=!1;if(m&&u.usable&&r&&w){this.fallbackWarnedDocId="";for(const[N,B]of u.leafPatch){const L=m.byId.get(N);L&&(L.content=B.content,L.markdown=B.markdown)}const E=new Map;for(const N of s)N!=null&&N.id&&E.set(N.id,N);for(const N of u.rebuildRoots){const B=m.byId.get(N),L=E.get(N);B&&L&&(B.content=L.content||"",B.markdown=L.markdown||""),await S(B)}for(const N of s){if(!(N!=null&&N.id)||m.byId.has(N.id))continue;const B=y(N);await S(B),m.byId.set(B.id,B),m.topLevel.push(B)}$=m.topLevel.filter(N=>a.has(N.id)).sort((N,B)=>(a.get(N.id)??0)-(a.get(B.id)??0))}else b.length>0?(T=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),$=s.map(E=>y(E))):m&&($=m.topLevel);const C=async(E,N=0)=>{if(!(!E||E.length===0||N>8))for(const B of E){if(Ro(B)&&(!B.children||B.children.length===0)){let R=await this.deps.getChildBlocks(B.id).catch(()=>[]);if(!R||R.length===0){const de=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${B.id}' ORDER BY sort ASC, created ASC`;R=await this.deps.sql(de).catch(()=>[])||[]}if(Array.isArray(R)&&R.length>0){const de=new Set($.map(Y=>Y.id)),V=R.filter(Y=>Y.id!==B.id&&!de.has(Y.id));V.length>0&&(B.children=V.map(Y=>{const Z=d.get(Y.id)||(Y.ial?uo(Y.ial):{}),ne=this.attrOverrides.get(Y.id);return ne&&Object.assign(Z,ne),{id:Y.id,parent_id:Y.parent_id||B.id,root_id:Y.root_id||t,type:Y.type,subType:Y.subType,content:Y.content||"",markdown:Y.markdown||"",ial:Z}}))}}B.children&&B.children.length>0&&await C(B.children,N+1)}};T&&await C($);const D=E=>{var N,B;for(const L of E)if(L.children&&L.children.length>0){D(L.children);for(const R of L.children)if(R.ial)for(const[de,V]of Object.entries(R.ial))de.startsWith("custom-slides-")&&!((N=L.ial)!=null&&N[de])&&(L.ial||(L.ial={}),L.ial[de]=V);if(L.ial){for(const[R,de]of Object.entries(L.ial))if(R.startsWith("custom-slides-"))for(const V of L.children)(V.type==="video"||V.type==="NodeVideo"||/<video\b/i.test(V.markdown||V.content||""))&&!((B=V.ial)!=null&&B[R])&&(V.ial||(V.ial={}),V.ial[R]=de)}}};D($),Jf($,E=>{const N={[we]:E.layout};this.setBlockAttrOverride(E.blockId,N),(this.deps.setBlockAttrs||He)(E.blockId,N).catch(L=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",L)})});const F=this.trackedListSuperBlocks.get(t)||[],W=Zf(t,$,{tracked:F,onTagChange:E=>{this.setBlockAttrOverride(E.blockId,E.attrs),E.blockId===t&&Object.assign(i,E.attrs);const N=L=>{for(const R of L)R.id===E.blockId&&(R.ial||(R.ial={}),Object.assign(R.ial,E.attrs)),R.children&&R.children.length>0&&N(R.children)};N($),(this.deps.setBlockAttrs||He)(E.blockId,E.attrs).catch(L=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",L)})}});this.trackedListSuperBlocks.set(t,W.newTracked);const K=new Set;for(const E of $){const N=E.markdown||E.content||"";if(N.includes("((")){const B=dd(N);for(const L of B)K.add(L.blockId)}}const _={};if(K.size>0){const E=Array.from(K).map(B=>`'${B}'`).join(","),N=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${E})`).catch(()=>[])||[];if(Array.isArray(N))for(const B of N)B.id&&(_[B.id]=B.markdown||B.content||"")}const j=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=na(t,i,$,{baseUrl:j,refContentMap:_});try{const E=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=Ln(E)}catch{k.customThemeCss=Ln(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=na(t,{},[],{});return n.customThemeCss=Ln(null),n}}}const Pe=new dp;class ur{constructor(t){ke(this,"devServerUrl","http://localhost:3030");ke(this,"isConnected",!1);ke(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},d=[],h=c===0;u.layout&&u.layout!=="default"&&d.push(`layout: ${u.layout}`),u.transition&&d.push(`transition: ${u.transition}`),u.background&&d.push(`background: ${u.background}`),u.class&&d.push(`class: "${u.class}"`);let f="";d.length>0?f=h?"":`---
${d.join(`
`)}
---

`:h||(f=`---

`);let v="";if(u.layout==="two-cols"){const b=l.blocks.filter(w=>w.slot!=="right"),y=l.blocks.filter(w=>w.slot==="right"),S=b.map(w=>w.rawMarkdown||w.content||"").join(`

`),x=y.map(w=>w.rawMarkdown||w.content||"").join(`

`);v=`${S}

::right::

${x}`}else v=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${f}${v}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${s}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const up={proMode:!1,presenterMode:!1,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0};function oi(e){return up[e]===!1}function _t(e){return!oi(e)}function fp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function It(e){const t=fp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function fr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=It("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Ol(){var t,i;const e=fr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=It("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function pp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qn(){const e=fr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=It("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Rl(){var n,s;const e=fr(),t={...(e==null?void 0:e.env)||{}};if(qn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function No(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function hp(){const e=It("os"),t=It("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class pr{constructor(t){ke(this,"runner");this.runner=t||pr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=It("child_process"))==null?void 0:n.execFile;if(!s){const l=await import("node:child_process").catch(()=>({}));s=l==null?void 0:l.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=qn()==="win32",r=Rl();return await new Promise(l=>{s(t,i,{timeout:5e3,shell:a,env:r},(c,u,d)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:d?String(d).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Ol(),i=qn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class mp{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pageChangedHandlers",[]);ke(this,"readyHandlers",[]);ke(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class gp{constructor(t){ke(this,"childProcess",null);ke(this,"activePort",null);ke(this,"isRunning",!1);ke(this,"defaultPort");ke(this,"maxPortRetries");ke(this,"probeTimeoutMs");ke(this,"customSpawner");ke(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=It("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=qn()==="win32"?"npx.cmd":"npx",a=No(t),r=["@slidev/cli",a,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let d=(l=It("child_process"))==null?void 0:l.spawn;if(!d){const v=await import("node:child_process").catch(()=>({}));d=v==null?void 0:v.spawn}if(!d)throw new Error("child_process spawn not available in current runtime");const h=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,f=Rl();this.childProcess=d(o,r,{cwd:h,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),qn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=It("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pendingMessages",[]);ke(this,"slideChangedHandlers",[]);ke(this,"blockClickedHandlers",[]);ke(this,"openInEditorHandlers",[]);ke(this,"clientReadyHandlers",[]);ke(this,"openPeekDrawerHandlers",[]);ke(this,"toggleFullscreenHandlers",[]);ke(this,"openPresenterHandlers",[]);ke(this,"captureProgressHandlers",[]);ke(this,"capturePageDoneHandlers",[]);ke(this,"captureCompleteHandlers",[]);ke(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const Nl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},vp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,bp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,yp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,kp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,wp=`${Oo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function xp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class Sp{constructor(t){ke(this,"workspacePath");ke(this,"slidesFileName");ke(this,"cliBridge",new ur);const i=hp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=No(o),l=No(a),c=xp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const x of c){const w=Nl[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;u.set(x,w)}t.slides.some(x=>{var w;return((w=x.frontmatter)==null?void 0:w.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",vp),t.slides.some(x=>{var w;return((w=x.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",bp),t.slides.some(x=>{var w;return((w=x.frontmatter)==null?void 0:w.layout)==="clover"})&&u.set("layouts/clover.vue",yp),u.set("setup/root.ts",kp),u.set("styles/index.css",wp);const v=It("fs"),m=It("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",S=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(v&&m&&S)try{v.existsSync(y)||v.mkdirSync(y,{recursive:!0}),v.writeFileSync(l,s,"utf-8"),v.writeFileSync(r,n,"utf-8");for(const[x,w]of u.entries()){const $=m.join(y,x),T=m.dirname($);v.existsSync(T)||v.mkdirSync(T,{recursive:!0}),v.existsSync($)||v.writeFileSync($,w,"utf-8")}b=!0}catch{}if(!b&&i)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),w=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(a,!1,w),await i(o,!1,x);for(const[$,T]of u.entries()){const C=`${this.workspacePath}/${$}`,D=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(C,!1,D).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(x){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(x)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class Cp{constructor(){ke(this,"mode","web-sandbox");ke(this,"webBridge");ke(this,"cliBridge");ke(this,"nativeBridge");ke(this,"processManager");ke(this,"scaffolder");ke(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new ur,this.nativeBridge=new mp,this.processManager=new gp,this.scaffolder=new Sp,this.envDetector=new pr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const _p={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},$p={key:0},Ip={key:1},Mp={key:2},Tp={key:3},Ep={key:4},Ap={key:5},Bp={key:6},Dp={key:7},Lp={key:8},Pp={key:9},Op={key:10},Rp={key:11},Np={key:12},zp={key:13},Hp={key:14},Fp={key:15},jp={key:16},Wp={key:17},Up={key:18},Vp={key:19},Gp={key:20},Kp={key:21},qp={key:22},Yp={key:23},Zp={key:24},Jp={key:25},Xp={key:26},Qp={key:27},eh={key:28},th={key:29},ih={key:30},nh={key:31},sh={key:32},oh={key:33},rh={key:34},ah={key:35},lh={key:36},ch={key:37},dh={key:38},uh={key:39},fh={key:40},ph={key:41},hh={key:42},mh={key:43},gh={key:44},vh={key:45},bh={key:46},yh={key:47},kh={key:48},wh={key:49},xh={key:50},Sh={key:51},Ch={key:52},_h={key:53},$h={key:54},Ih={key:55},Mh={key:56},Th={key:57},Eh={key:58},Ah={key:59},Bh={key:60},Dh={key:61},Lh={key:62},Ph={key:63},Oh={key:64},Rh={key:65},Nh={key:66},zh={key:67},Hh={key:68},Fh={key:69},jh={key:70},Wh={key:71},Uh={key:72},Vh=Et({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(Q(),te("svg",_p,[e.name==="fullscreen"||e.name==="maximize"?(Q(),te("g",$p,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(Q(),te("g",Ip,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(Q(),te("g",Mp,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(Q(),te("g",Tp,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(Q(),te("g",Ep,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(Q(),te("g",Ap,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(Q(),te("g",Bp,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(Q(),te("g",Dp,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(Q(),te("g",Lp,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(Q(),te("g",Pp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(Q(),te("g",Op,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(Q(),te("g",Rp,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(Q(),te("g",Np,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(Q(),te("g",zp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(Q(),te("g",Hp,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(Q(),te("g",Fp,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(Q(),te("g",jp,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(Q(),te("g",Wp,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(Q(),te("g",Up,[...i[18]||(i[18]=[pt('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(Q(),te("g",Vp,[...i[19]||(i[19]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(Q(),te("g",Gp,[...i[20]||(i[20]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(Q(),te("g",Kp,[...i[21]||(i[21]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(Q(),te("g",qp,[...i[22]||(i[22]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(Q(),te("g",Yp,[...i[23]||(i[23]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(Q(),te("g",Zp,[...i[24]||(i[24]=[pt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(Q(),te("g",Jp,[...i[25]||(i[25]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(Q(),te("g",Xp,[...i[26]||(i[26]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(Q(),te("g",Qp,[...i[27]||(i[27]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(Q(),te("g",eh,[...i[28]||(i[28]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(Q(),te("g",th,[...i[29]||(i[29]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(Q(),te("g",ih,[...i[30]||(i[30]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(Q(),te("g",nh,[...i[31]||(i[31]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(Q(),te("g",sh,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(Q(),te("g",oh,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(Q(),te("g",rh,[...i[34]||(i[34]=[p("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(Q(),te("g",ah,[...i[35]||(i[35]=[p("polyline",{points:"11 17 6 12 11 7"},null,-1),p("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(Q(),te("g",lh,[...i[36]||(i[36]=[p("polyline",{points:"13 17 18 12 13 7"},null,-1),p("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(Q(),te("g",ch,[...i[37]||(i[37]=[p("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(Q(),te("g",dh,[...i[38]||(i[38]=[p("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),p("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(Q(),te("g",uh,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(Q(),te("g",fh,[...i[40]||(i[40]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(Q(),te("g",ph,[...i[41]||(i[41]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(Q(),te("g",hh,[...i[42]||(i[42]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(Q(),te("g",mh,[...i[43]||(i[43]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(Q(),te("g",gh,[...i[44]||(i[44]=[pt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(Q(),te("g",vh,[...i[45]||(i[45]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(Q(),te("g",bh,[...i[46]||(i[46]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(Q(),te("g",yh,[...i[47]||(i[47]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(Q(),te("g",kh,[...i[48]||(i[48]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(Q(),te("g",wh,[...i[49]||(i[49]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(Q(),te("g",xh,[...i[50]||(i[50]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(Q(),te("g",Sh,[...i[51]||(i[51]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(Q(),te("g",Ch,[...i[52]||(i[52]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(Q(),te("g",_h,[...i[53]||(i[53]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(Q(),te("g",$h,[...i[54]||(i[54]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(Q(),te("g",Ih,[...i[55]||(i[55]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(Q(),te("g",Mh,[...i[56]||(i[56]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(Q(),te("g",Th,[...i[57]||(i[57]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(Q(),te("g",Eh,[...i[58]||(i[58]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(Q(),te("g",Ah,[...i[59]||(i[59]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(Q(),te("g",Bh,[...i[60]||(i[60]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(Q(),te("g",Dh,[...i[61]||(i[61]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(Q(),te("g",Lh,[...i[62]||(i[62]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(Q(),te("g",Ph,[...i[63]||(i[63]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(Q(),te("g",Oh,[...i[64]||(i[64]=[pt('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(Q(),te("g",Rh,[...i[65]||(i[65]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(Q(),te("g",Nh,[...i[66]||(i[66]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(Q(),te("g",zh,[...i[67]||(i[67]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(Q(),te("g",Hh,[...i[68]||(i[68]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(Q(),te("g",Fh,[...i[69]||(i[69]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(Q(),te("g",jh,[...i[70]||(i[70]=[pt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(Q(),te("g",Wh,[...i[71]||(i[71]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(Q(),te("g",Uh,[...i[72]||(i[72]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ei=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},fe=ei(Vh,[["__scopeId","data-v-af7d02a2"]]),Gh={class:"spm-immersion-header"},Kh={class:"spm-immersion-header__left"},qh={class:"spm-immersion-title"},Yh={class:"spm-immersion-header__center"},Zh={class:"spm-immersion-header__actions"},Jh=["aria-label"],Xh={class:"spm-immersion-body"},Qh=Et({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function a(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),s())}return(l,c)=>Lt((Q(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Yt(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:o}),p("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",Gh,[p("div",Kh,[rs(l.$slots,"header-left",{},()=>[p("span",qh,xe(e.title),1)])]),p("div",Yh,[rs(l.$slots,"header-center",{},void 0)]),p("div",Zh,[rs(l.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[ae(fe,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Jh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[ae(fe,{name:"close"})])])]),p("div",Xh,[rs(l.$slots,"default",{},void 0)])],2)],34)),[[Do,e.visible]])}}),em=ei(Qh,[["__scopeId","data-v-1359fecb"]]),tm={class:"spm-protyle-drawer"},im={class:"spm-protyle-drawer__subbar"},nm={class:"spm-protyle-drawer__nav"},sm=["title"],om={class:"spm-protyle-drawer__actions"},rm=["aria-label"],am=["aria-label"],lm=Et({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(n.blockId),o=ge(n.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),u=Ut,d=ge([]),h=ge(null);let f=null;Fi(()=>n.blockId,C=>{C&&C!==s.value&&(s.value=C,o.value=n.title||"",d.value=[],m(C))}),mn(()=>{s.value&&m(s.value)}),ir(()=>{b()});async function v(C){try{const D=await cn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const F=D[0];c.value=F.root_id||"";const W=F.id===F.root_id||F.type==="d";l.value=W,r.value=!W,!o.value&&F.content&&(o.value=F.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}l.value=!1,r.value=!0}async function m(C,D){if(!h.value||!C)return;b(),await v(C),typeof D=="boolean"&&(r.value=!l.value&&D);let F,W;r.value&&!l.value?(F=["cb-get-all","cb-get-hl","cb-get-focus"],W={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(F=["cb-get-context","cb-get-hl"],W={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new ue.Protyle(n.plugin.app,h.value,{blockId:C,action:F,render:W}),!a.value&&f&&typeof f.disable=="function"&&f.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function b(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}f=null}h.value&&(h.value.innerHTML="")}function y(){l.value||(r.value=!r.value,m(s.value,r.value))}function S(){a.value=!a.value,f&&(a.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function x(){if(s.value)try{ue.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function w(){var F;if(!s.value)return;const C=qs(),D=El(C.webServeUrl,s.value,{focus:!l.value});if(typeof window<"u"){const W=It("electron");(F=W==null?void 0:W.shell)!=null&&F.openExternal?W.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}i("external-jump",D)}function $(){if(d.value.length>0){const C=d.value.pop();C&&(s.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function T(C){const D=C.target;if(!D)return;const F=D.closest('[data-type="block-ref"]');if(F){const K=F.getAttribute("data-id");if(K&&K!==s.value){C.preventDefault(),C.stopPropagation(),d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=F.innerText.trim()||K,m(K);return}}const W=D.closest("a");if(W&&W.href&&W.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const K=W.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==s.value&&(d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=W.innerText.trim()||K,m(K))}}return(C,D)=>(Q(),te("div",tm,[p("div",im,[p("div",nm,[d.value.length>0?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:$},[ae(fe,{name:"arrow-left"}),D[0]||(D[0]=p("span",null,"返回",-1))])):Te("",!0),p("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},xe(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:o.value||s.value},xe(o.value||s.value),9,sm)]),p("div",om,[l.value?Te("",!0):(Q(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[ae(fe,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,xe(r.value?"块聚焦":"展开全文"),1)],10,rm)),p("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:S},[ae(fe,{name:a.value?"edit":"eye"},null,8,["name"]),p("span",null,xe(a.value?"编辑中":"只读"),1)],10,am),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[ae(fe,{name:"window"}),D[1]||(D[1]=p("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(Q(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:w},[ae(fe,{name:"external-link"}),D[2]||(D[2]=p("span",null,"外跳",-1))])):Te("",!0)])]),p("div",{ref_key:"mountEl",ref:h,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:T},null,2)]))}}),cm=ei(lm,[["__scopeId","data-v-0d6e2df3"]]),dm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,um=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function sa(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function zl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function fm(e){const t=e.split(/[/?#]/)[0];return!t||um.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function pm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,a=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Hl(e){const t=hm(e);return t.external||!t.url?t:{url:pm(t.url),external:!1}}function hm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Sa(t))return{url:`/${Ca(t)}`,external:!1};if(/^file:/i.test(t)){const n=sa(zl(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=sa(t);return n?{url:n,external:!1}:{url:t,external:!0}}return dm.test(t)?{url:t,external:!0}:fm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const mm={class:"spm-webview-drawer"},gm={class:"spm-webview-toolbar"},vm={class:"spm-webview-toolbar__nav"},bm=["disabled"],ym=["disabled"],km=["aria-label"],wm={class:"spm-webview-toolbar__address"},xm=["aria-label"],Sm={class:"spm-webview-toolbar__actions"},Cm=["aria-label"],_m={class:"spm-zoom-controller"},$m=["disabled"],Im=["disabled"],Mm={key:1,class:"spm-webview-fallback"},Tm=["src"],Em={key:2,class:"spm-load-error"},Am={class:"spm-load-error__code"},Bm={class:"spm-load-error__code-num"},Dm={class:"spm-load-error__url"},Lm={class:"spm-load-error__hint"},Pm={class:"spm-load-error__actions"},oa="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Fl="siyuan-slides-peek-view-mode";let jl="desktop";function Om(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Fl);if(e==="mobile"||e==="desktop")return e}catch{}return jl}function Rm(e){if(jl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Fl,e)}catch{}}function Nm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const zm=Et({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(Ol()&&!pp()),o=ge(n.url),a=ge(n.url),r=n.url,l=ge(!1),c=ge(null),u=ge(!1),d=ge(!1),h=ge(1),f=ge(!1),v=ge(Om());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=be(()=>v.value==="mobile"?oa:m||void 0),y=ge(null),S=ge(null);let x=null,w=null,$=null;Fi(()=>n.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,v.value==="mobile"&&W(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X))}),Fi(()=>n.visible,X=>{if(X)Z(),v.value==="mobile"&&W(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),mn(()=>{T(),S.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const X=y.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),x.observe(S.value)),w=X=>{var P;const ce=X.message||((P=X.error)==null?void 0:P.message);if(typeof ce=="string"&&ce.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),$=X=>{const ce=X.reason,P=typeof ce=="string"?ce:ce==null?void 0:ce.message;typeof P=="string"&&P.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",$)}),ir(()=>{if(C(),x&&(x.disconnect(),x=null),w&&(window.removeEventListener("error",w,!0),w=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function T(){const X=y.value;X&&(X.addEventListener("dom-ready",D),X.addEventListener("did-start-loading",K),X.addEventListener("did-stop-loading",k),X.addEventListener("did-navigate",E),X.addEventListener("did-navigate-in-page",N),X.addEventListener("new-window",B),X.addEventListener("did-fail-load",_),X.addEventListener("did-fail-provisional-load",_))}function C(){const X=y.value;if(X)try{X.removeEventListener("dom-ready",D),X.removeEventListener("did-start-loading",K),X.removeEventListener("did-stop-loading",k),X.removeEventListener("did-navigate",E),X.removeEventListener("did-navigate-in-page",N),X.removeEventListener("new-window",B),X.removeEventListener("did-fail-load",_),X.removeEventListener("did-fail-provisional-load",_)}catch{}}function D(){const X=y.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const ce=X.getUserAgent();ce&&!ce.includes("iPhone")&&(m=ce)}catch{}v.value==="mobile"&&W(!1),Z(),L()}function F(){const X=v.value==="mobile"?"desktop":"mobile";v.value=X,Rm(X),W(!0)}function W(X=!1){const ce=y.value;if(!ce)return;const P=v.value==="mobile"?oa:m;if(typeof ce.setUserAgent=="function"&&P)try{ce.setUserAgent(P)}catch(U){console.warn("[WebviewPeekDrawer] setUserAgent error:",U)}if(X&&typeof ce.reload=="function")try{ce.reload()}catch(U){console.warn("[WebviewPeekDrawer] reload error:",U)}}function K(){l.value=!0,c.value=null}function _(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const ce=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:ce,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:Nm(ce)},l.value=!1}function j(){c.value=null,V()}function k(){if(l.value=!1,L(),y.value&&typeof y.value.getURL=="function"){const X=y.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function E(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),L()}function N(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),L()}function B(X){X&&X.url&&(X.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url))}function L(){const X=y.value;X&&(typeof X.canGoBack=="function"&&(u.value=X.canGoBack()),typeof X.canGoForward=="function"&&(d.value=X.canGoForward()))}function R(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function de(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function V(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function Y(){const X=Hl(a.value);if(X.url){if(X.external){o.value=X.url,le();return}o.value=X.url,a.value=X.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url)}}function Z(){const X=y.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(h.value)}catch(ce){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ce)}}function ne(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),Z()}function oe(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),Z()}function ye(){h.value=1,Z()}function Ie(X){X.preventDefault(),X.deltaY<0?ne():X.deltaY>0&&oe()}async function Ce(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),f.value=!0,setTimeout(()=>{f.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function le(){var ce;const X=o.value;if(typeof window<"u"){const P=It("electron");(ce=P==null?void 0:P.shell)!=null&&ce.openExternal?P.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,ce)=>{const P=wu("webview");return Q(),te("div",mm,[p("div",gm,[p("div",vm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:R},[ae(fe,{name:"arrow-left"})],8,bm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:de},[ae(fe,{name:"arrow-right"})],8,ym),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:V},[ae(fe,{name:"refresh"})],8,km)]),p("div",wm,[Lt(p("input",{"onUpdate:modelValue":ce[0]||(ce[0]=U=>a.value=U),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Rf(Y,["enter"])},null,544),[[Lo,a.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":f.value?"已复制地址！":"复制网址",onClick:Ce},[ae(fe,{name:"copy"})],8,xm)]),p("div",Sm,[p("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":v.value==="mobile"}]),"aria-label":v.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:F},[ae(fe,{name:v.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Cm),p("div",_m,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:oe},[ae(fe,{name:"minus"})],8,$m),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ye},xe(Math.round(h.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:ne},[ae(fe,{name:"plus"})],8,Im)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:le},[ae(fe,{name:"external-link"}),ce[1]||(ce[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:S,class:_e(["spm-webview-body",{"is-mobile":v.value==="mobile"}]),onWheel:Yt(Ie,["ctrl"])},[p("div",{class:_e(["spm-webview-viewport",{"is-mobile":v.value==="mobile"}])},[s.value?(Q(),Zt(P,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:he(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(Q(),te("div",Mm,[p("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Tm),p("div",{class:"spm-fallback-bar"},[ce[2]||(ce[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:le}," 在新标签页中打开 ↗ ")])])),c.value?(Q(),te("div",Em,[ae(fe,{name:"alert",class:"spm-load-error__icon"}),ce[5]||(ce[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",Am,[Ct(xe(c.value.description)+" ",1),p("span",Bm,"("+xe(c.value.errorCode)+")",1)]),p("div",Dm,xe(c.value.validatedURL),1),p("p",Lm,xe(c.value.hint),1),p("div",Pm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:j},[ae(fe,{name:"refresh"}),ce[3]||(ce[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:le},[ae(fe,{name:"external-link"}),ce[4]||(ce[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),Hm=ei(zm,[["__scopeId","data-v-6e363f73"]]);class Fm{constructor(){ke(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class jm{constructor(t){ke(this,"blockToPageMap",new Map);ke(this,"debounceCtrl",new Fm);ke(this,"activeBlockId","");ke(this,"activePageIndex",1);ke(this,"currentDocId","");ke(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Mt=null,hs=null,ms="";function Pn(){var e,t;if(hs&&(clearTimeout(hs),hs=null),Mt){try{Mt.classList.remove("protyle-wysiwyg--select"),ms?Mt.style.outline=ms:typeof((e=Mt.style)==null?void 0:e.removeProperty)=="function"?Mt.style.removeProperty("outline"):Mt.style&&(Mt.style.outline=""),typeof((t=Mt.style)==null?void 0:t.removeProperty)=="function"?Mt.style.removeProperty("transition"):Mt.style&&(Mt.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}Mt=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,a;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((a=n.style)==null?void 0:a.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function ji(e,t){var a,r,l,c;if(!e||typeof document>"u")return Pn(),!1;Pn();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ue.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),Mt=n,hs=setTimeout(()=>{Pn()},500),!0}function Wm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>at(a)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const a=s.map(r=>at(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${a}</p>`),s=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();n.push(`<h${l} class="slide-list-item-title">${at(c)}</h${l}>`)}else s.push(a)}return o(),n.join(`
`)}function Um(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${at(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${at(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>at(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${at(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Wl(e,t,i){var h,f,v,m;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],a=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const S=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(S){const T=S[1].length,C=Math.floor(T/2);a.push({type:"task",level:C,checked:S[2].toLowerCase()==="x",text:S[3],media:[]});continue}const x=y.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const T=x[1].length,C=Math.floor(T/2);a.push({type:"unordered",level:C,text:x[2],media:[]});continue}const w=y.match(/^(\s*)\d+\.\s+(.*)$/);if(w){a.length===0&&(r=!0);const T=w[1].length,C=Math.floor(T/2);a.push({type:"ordered",level:C,text:w[2],media:[]});continue}const $=y.trim();if(!(!$||/^\{:.*?\}$/.test($)))if(a.length>0){const T=$.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const F=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${st(T[1])}" src="${T[2]}" class="${F}" /></div>`);continue}if($.match(/^<img\b[\s\S]*?\/?>$/i)){const D=$.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${D}</div>`);continue}if(/<video\b/i.test($)){let D=$;if(!/<\/video>/i.test(D))for(;b+1<n.length&&!/<\/video>/i.test(D);)b++,D+=" "+n[b].trim();const F=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(D),W=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slides-loop"])==="true"||/loop/i.test(D),K=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-muted"])==="true"||F||/muted/i.test(D),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",j=D.match(/\bsrc=["']([^"']+)["']/i),k=j?j[1]:"",E=['class="slide-video-player"'];_||E.push("controls"),F&&(E.push("autoplay"),E.push("playsinline")),W&&E.push("loop"),K&&E.push("muted"),E.push('preload="metadata"'),k&&E.push(`src="${k}"`);const N=D.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let B=N?N[1].trim():"";!B&&k&&(B=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${F?"true":"false"}" data-muted="${K?"true":"false"}"><video ${E.join(" ")}>${B}</video></div>`);continue}a[a.length-1].text+=`
`+$}else o.push($)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(b=>{const y=Wm(b.text),S=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",x=b.level||0,w=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",$=x>0?" slide-list-item--nested":"";if(b.type==="task"){const C=b.checked?' checked=""':"";return`<li class="pdf-task-item${$}"${w}><label><input type="checkbox" disabled=""${C}/> <span>${y}</span></label>${S}</li>`}return`<li${$?` class="${$.trim()}"`:""}${w}>${y}${S}</li>`}).join(`
`);return`${Um(o)}<${l} class="${c}">
${u}
</${l}>`}function Vm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<s.length;c++){const u=s[c],d=u.trim();if(/^#{1,6}\s+/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(!d){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(/<video\b/i.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]);let h=d;if(!/<\/video>/i.test(h))for(;c+1<s.length&&!/<\/video>/i.test(h);)c++,h+=`
`+s[c];o.push(h);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var v,m,b,y;const u=c.trim();if(!u)return"";const d=u.match(/^(#{1,6})\s+(.*)$/);if(d){r=!1;const S=d[1].length;return`<h${S} class="slide-list-item-title">${at(d[2].trim())}</h${S}>`}const h=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const S=/\.gif(?:\?|$)/i.test(h[2]),x=(t==null?void 0:t.imageClassName)||(S?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(h[1])}" src="${h[2]}" class="${x}" /></div>`}if(/<video\b/i.test(u)){const S=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),x=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),w=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||S||/muted/i.test(u),$=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-controls"])==="false",T=u.match(/\bsrc=["']([^"']+)["']/i),C=T?T[1]:"",D=['class="slide-video-player"'];$||D.push("controls"),S&&D.push("autoplay playsinline"),x&&D.push("loop"),w&&D.push("muted"),D.push('preload="metadata"'),C&&D.push(`src="${C}"`);const F=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let W=F?F[1].trim():"";return!W&&C&&(W=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${S?"true":"false"}" data-muted="${w?"true":"false"}"><video ${D.join(" ")}>${W}</video></div>`}const f=Wl(u,t,i);if(f)return r=!1,f;if(r){r=!1;const S=u.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(S.length===1)return`<p class="slide-list-item-title">${at(S[0])}</p>`;const x=S[0],$=S.slice(1).map(T=>at(T)).join("<br/>");return`<p class="slide-list-item-title">${at(x)}</p>
<p class="slide-list-item-desc">${$}</p>`}return`<p class="slide-list-item-desc">${at(u)}</p>`}).filter(Boolean).join(`
`)}function fo(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Ul(e,t){var r,l,c,u,d,h,f,v;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:s.find(fo);if(i==="two-cols"){const m=s.some(K=>K.slot==="right");let b=[],y=[];if(m)b=s.filter(K=>K.slot!=="right"),y=s.filter(K=>K.slot==="right");else{const K=Math.ceil(s.length/2);b=s.slice(0,K),y=s.slice(K)}const S=K=>{const _=K.filter(j=>!!(j.rawMarkdown||j.content||"").trim());if(_.length>0){const j=_[0],k=(j.rawMarkdown||j.content||"").trim();(Vi(j)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(j.rawMarkdown=Bn(j.rawMarkdown||j.content||""),j.content=j.rawMarkdown)}};S(b),S(y);const x=b.map(K=>bi(K,t)).join(`
`),w=y.map(K=>bi(K,t)).join(`
`),$=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",D=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",W=`style="grid-template-columns: ${co((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${$}${T}" ${W}>
        <div class="${C}">${x}</div>
        <div class="${D}">${w}</div>
      </div>
    `}if(i==="clover"||Hn(i)){const m=i==="clover";let b=[];const y=s.filter(E=>E.slot==="header");if(y.length>0)b=y;else if(s.length>0){const E=s.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));E&&(b=[E])}const S=s.filter(E=>!b.includes(E));let x=2;if(m)x=4;else if(i==="three-cols-header")x=3;else if(i==="two-cols-header")x=2;else{let E=0;for(const N of S){const B=(N.slot||"").match(/^col-(\d+)$/i);B&&(E=Math.max(E,parseInt(B[1],10)))}if(E>=2)x=E;else if((u=e.frontmatter)!=null&&u.layoutRatio){const N=e.frontmatter.layoutRatio.trim();if(N.includes(":")){const B=N.split(":").map(L=>parseFloat(L.trim())).filter(L=>!isNaN(L)&&L>0);B.length>=2&&(x=B.length)}else{const B=N.split(/\s+/).filter(Boolean);B.length>=2&&(x=B.length)}}else S.length===1&&S[0].children&&S[0].children.length>=2&&(x=Math.min(6,S[0].children.length))}const w=Pl(S,x),$=S.some(E=>E.slot&&/^(?:col-\d+|left|right)$/i.test(E.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Hn(i)&&$,C=E=>{const N=E.filter(L=>!!(L.rawMarkdown||L.content||"").trim());if(T&&N.length>0){const L=N[0],R=(L.rawMarkdown||L.content||"").trim();(Vi(L)||/^(?:[-*+]|\d+\.)\s+/.test(R))&&(L.rawMarkdown=Bn(L.rawMarkdown||L.content||""),L.content=L.rawMarkdown),L.isColFirst=!0}const B=T?N.find(fo):null;return N.map(L=>bi(L,{...t,extraClassName:L===B?"slides-col-first-heading-block":""})).join(`
`)},D=b.find(fo),F=b.map(E=>bi(E,{...t,extraClassName:E===D?"slides-page-first-heading-block":""})).join(`
`),W=m?"repeat(2, minmax(0, 1fr))":co((d=e.frontmatter)==null?void 0:d.layoutRatio,x),K=m?`style="grid-template-columns: ${W}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${W};"`,_=[m?"layout-clover-container":"layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),j=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),k=w.map((E,N)=>{const B=N+1;return`<div class="${["pdf-col",x===2&&B===1?"pdf-col--left":"",x===2&&B===2?"pdf-col--right":"",`pdf-col--${B}`,`col-${B}`].filter(Boolean).join(" ")}">${C(E)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${F}</div>
        <div class="${j}" ${K}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=s.map(T=>bi(T,t)).join(`
`),y=((h=e.frontmatter)==null?void 0:h.image)||((f=e.frontmatter)==null?void 0:f.background)||"",S=`<div class="pdf-image-col" style="background-image:url('${st(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,x=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,w=m?`${x}
${S}`:`${S}
${x}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${co((v=e.frontmatter)==null?void 0:v.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${w}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>bi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>bi(b,t)).join(`
`)}</div>`:s.map(m=>bi(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Gm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,a]=s.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const Km=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function at(e){if(!e)return"";const t=Dl(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!Km.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=st(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,d)=>{const f=(r??l??c??u??d??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${f}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),s}function qm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(s=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${n.map((l,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${at(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${s[u]?` style="text-align: ${s[u]}"`:""}>${at(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function po(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ra(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${po(e)}</span>`;const i=[];function n(o,a){return i.push(`<span class="${o}">${po(a)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>n("token-string",`${a}${r}${a}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=po(s),s=s.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),s}function Ym(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){s||(s=l[1].length),n=l[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Zm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const d=Ym(c,u+1);d&&o.push(d)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>s)return[];const d=[];for(const h of c){const f=l(h.children,u+1);u>=n?d.push({...h,children:f}):d.push(...f)}return d}return l(a,1)}function Jm(e,t=1,i={}){const n=Zm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const d=`slides-toc-list slides-toc-list-level-${u}`,h=c.map(f=>{const v=f.active?" slides-toc-item-active":f.hasActiveChild?" slides-toc-item-parent-active":"",m=f.children&&f.children.length>0?r(f.children,u+1):"";let b=at(f.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${v}" data-page="${f.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${d}">${h}</ol>`}const l=r(n,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function bi(e,t){var $,T,C,D,F,W,K,_,j,k;let i="",n="",s="";const o=[];($=e.motion)!=null&&$.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((T=e.attributes)==null?void 0:T.style)||"";a&&(o.push(a),s=" slide-styled-block"),o.length>0&&(n=` style="${st(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",d=`${r}${i}${s}${l}${u}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${d}"${n}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${d}"${n}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const E=h.slice(2,-2).trim();return`<div class="${d} katex-display-container"${n}><div class="katex-display font-math"><em>${st(E)}</em></div></div>`}const f=h.match(/^(#{1,6})\s+(.*)$/);if(f){const E=f[1].length,N=at(f[2]),L=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><h${E}${L}>${N}</h${E}></div>`}if(h.startsWith(":::")){const E=h.split(`
`),B=E[0].replace(/^:::\s*/,"").trim()||"info",L=E.slice(1,E[E.length-1].startsWith(":::")?-1:void 0).join(`
`),R=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${d}"${n}><div class="${R} ${R}--${B}"><div class="${R}-title">${B.toUpperCase()}</div><div class="${R}-body">${at(L)}</div></div></div>`}if(h.startsWith("<<<")){const B=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((V,Y)=>`<span class="code-line shiki-focus"><span class="line-no">${Y+1}</span><span class="line-content">${ra(V,"ts")}</span></span>`).join(`
`),L=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",R=((D=e.attrs)==null?void 0:D["custom-slides-max-height"])||e.maxHeight||"",de=R?` style="max-height:${st(R)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${L}"${de}><span class="lang-badge">TS</span><code>${B}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const E=h.split(`
`),N=E[0].slice(3).trim(),B=N.match(/^([^\s{\[]+)/),L=B?B[1]:"",R=N.match(/\[([^\]]+)\]/),de=R?R[1]:"",V=N.includes("twoslash"),Y=e.shikiLines||((F=N.match(/\{([^}]+)\}/))==null?void 0:F[1])||"",Z=Gm(Y),ne=E.length>2?E[E.length-1]==="```"?E.slice(1,-1):E.slice(1):[h.slice(3).replace(/```$/,"")],oe=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ye=de?`${oe} has-filename`:oe,Ie=Z!=="all",Ce=ne.map((U,g)=>{const G=g+1,I=Z==="all"||Z.has(G)?"code-line shiki-focus":Ie?"code-line shiki-dimmed":"code-line";let O=(t==null?void 0:t.highlight)===!0?ra(U,L):st(U);return V&&U.includes("doubled.value = 2")?(O=O.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${O}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${O}</span></span>`}).join(`
`),le=L?`<span class="lang-badge">${st(L)}</span>`:"",X=de?`<span class="code-filename">${st(de)}</span>`:"",ce=((W=e.attrs)==null?void 0:W["custom-slides-max-height"])||e.maxHeight||"",P=ce?` style="max-height:${st(ce)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${ye}"${P}>${X}${le}<code>${Ce}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(E=>E.trim().startsWith("|")).length>=2){const E=h.split(`
`).filter(B=>B.trim().startsWith("|")),N=qm(E,t==null?void 0:t.tableClassName);return`<div class="${d}"${n}>${N}</div>`}if(h.startsWith("> ")){const E=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${d}"${n}><blockquote class="${E}"><p>${at(h.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),b=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(v&&!m&&!b&&!h.includes(`
`)){const E=((K=e.attributes)==null?void 0:K["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),N=((_=e.attributes)==null?void 0:_["custom-slides-loop"])==="true"||/loop/i.test(h),B=((j=e.attributes)==null?void 0:j["custom-slides-muted"])==="true"||E||/muted/i.test(h),L=((k=e.attributes)==null?void 0:k["custom-slides-controls"])==="false",R=h.match(/\bsrc=["']([^"']+)["']/i),de=R?R[1]:"",V=['class="slide-video-player"'];L||V.push("controls"),E&&(V.push("autoplay"),V.push("playsinline")),N&&V.push("loop"),B&&V.push("muted"),V.push('preload="auto"'),de&&V.push(`src="${de}"`);const Y=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let Z=Y?Y[1].trim():"";return!Z&&de&&(Z=`<source src="${de}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${d} ${d}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${E?"true":"false"}" data-muted="${B?"true":"false"}"${n}><video ${V.join(" ")}>${Z}</video></div>`}const y=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const E=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${d} ${d}--image slide-media-block slide-media-container"${n}><img alt="${st(y[1])}" src="${y[2]}" class="${E}" /></div>`}const S=Wl(h,t,e);if(S)return`<div class="${d} pdf-list-item"${n}>${S}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const E=h.match(/minDepth=["']?(\d+)["']?/i),N=h.match(/maxDepth=["']?(\d+)["']?/i),B=h.match(/columns=["']?(\d+)["']?/i),L=(t==null?void 0:t.allSlides)||[];return`<div class="${d}"${n}>${Jm(L,(t==null?void 0:t.currentPageIndex)||1,{minDepth:E?parseInt(E[1],10):1,maxDepth:N?parseInt(N[1],10):1/0,columns:B?parseInt(B[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||b){const E=Vm(h,t,e);if(E)return`<div class="${d}"${n}>${E}</div>`}const w=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><p${w}>${at(h)}</p></div>`}function Xm(e){return`
    ${Ln(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function Qm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function eg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function tg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function ig(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function ng(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function sg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function og(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function rg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ag(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function lg(){return[Qm(),eg(),tg(),ig(),ng(),sg(),og(),rg(),ag()].join("")}function Vl(e,t){const i="即现演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(i)}</title>
  <style>
${Xm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${lg()}
  <\/script>
</body>
</html>`}function Gl(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function cg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function dg(e){const t=cg(e==null?void 0:e.pageRatio);return`
    ${Ln(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function ug(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((a,r)=>{const l=a.frontmatter.layout||"default",c=a.frontmatter.spacing,u=c&&c!=="inherit"?c:e.config.spacing||"normal",d=Ul(a),h=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${l} theme-${s} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(i)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(i)} - 高保真讲义</title>
  <style>
    ${dg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${o}
</body>
</html>`}function Kl(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=ug(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(s=o.contentWindow)==null?void 0:s.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function fg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ho={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var aa;function pg(){return aa||(aa=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function a(c,u){if(!s[c]){if(!n[c]){var d=typeof ds=="function"&&ds;if(!u&&d)return d(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var f=s[c]={exports:{}};n[c][0].call(f.exports,function(v){var m=n[c][1][v];return a(m||v)},f,f.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,n,s){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(l){for(var c,u,d,h,f,v,m,b=[],y=0,S=l.length,x=S,w=o.getTypeOf(l)!=="string";y<l.length;)x=S-y,d=w?(c=l[y++],u=y<S?l[y++]:0,y<S?l[y++]:0):(c=l.charCodeAt(y++),u=y<S?l.charCodeAt(y++):0,y<S?l.charCodeAt(y++):0),h=c>>2,f=(3&c)<<4|u>>4,v=1<x?(15&u)<<2|d>>6:64,m=2<x?63&d:64,b.push(r.charAt(h)+r.charAt(f)+r.charAt(v)+r.charAt(m));return b.join("")},s.decode=function(l){var c,u,d,h,f,v,m=0,b=0,y="data:";if(l.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var S,x=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&x--,l.charAt(l.length-2)===r.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(S=a.uint8array?new Uint8Array(0|x):new Array(0|x);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(h=r.indexOf(l.charAt(m++)))>>4,u=(15&h)<<4|(f=r.indexOf(l.charAt(m++)))>>2,d=(3&f)<<6|(v=r.indexOf(l.charAt(m++))),S[b++]=c,f!==64&&(S[b++]=u),v!==64&&(S[b++]=d);return S}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,d,h,f,v){this.compressedSize=u,this.uncompressedSize=d,this.crc32=h,this.compression=f,this.compressedContent=v}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),d=this;return u.on("end",function(){if(this.streamInfo.data_length!==d.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,d,h){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(d.compressWorker(h)).pipe(new l("compressedSize")).withStreamInfo("compression",d)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();n.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,d,h){var f=a,v=h+d;c^=-1;for(var m=h;m<v;m++)c=c>>>8^f[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,d,h){var f=a,v=h+d;c^=-1;for(var m=h;m<v;m++)c=c>>>8^f[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(d,h){l.call(this,"FlateWorker/"+d),this._pako=null,this._pakoAction=d,this._pakoOptions=h,this.meta={}}s.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(d){this.meta=d.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,d.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var d=this;this._pako.onData=function(h){d.push({data:h,meta:d.meta})}},s.compressWorker=function(d){return new u("Deflate",d)},s.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(f,v){var m,b="";for(m=0;m<v;m++)b+=String.fromCharCode(255&f),f>>>=8;return b}function a(f,v,m,b,y,S){var x,w,$=f.file,T=f.compression,C=S!==c.utf8encode,D=r.transformTo("string",S($.name)),F=r.transformTo("string",c.utf8encode($.name)),W=$.comment,K=r.transformTo("string",S(W)),_=r.transformTo("string",c.utf8encode(W)),j=F.length!==$.name.length,k=_.length!==W.length,E="",N="",B="",L=$.dir,R=$.date,de={crc32:0,compressedSize:0,uncompressedSize:0};v&&!m||(de.crc32=f.crc32,de.compressedSize=f.compressedSize,de.uncompressedSize=f.uncompressedSize);var V=0;v&&(V|=8),C||!j&&!k||(V|=2048);var Y=0,Z=0;L&&(Y|=16),y==="UNIX"?(Z=798,Y|=(function(oe,ye){var Ie=oe;return oe||(Ie=ye?16893:33204),(65535&Ie)<<16})($.unixPermissions,L)):(Z=20,Y|=(function(oe){return 63&(oe||0)})($.dosPermissions)),x=R.getUTCHours(),x<<=6,x|=R.getUTCMinutes(),x<<=5,x|=R.getUTCSeconds()/2,w=R.getUTCFullYear()-1980,w<<=4,w|=R.getUTCMonth()+1,w<<=5,w|=R.getUTCDate(),j&&(N=o(1,1)+o(u(D),4)+F,E+="up"+o(N.length,2)+N),k&&(B=o(1,1)+o(u(K),4)+_,E+="uc"+o(B.length,2)+B);var ne="";return ne+=`
\0`,ne+=o(V,2),ne+=T.magic,ne+=o(x,2),ne+=o(w,2),ne+=o(de.crc32,4),ne+=o(de.compressedSize,4),ne+=o(de.uncompressedSize,4),ne+=o(D.length,2),ne+=o(E.length,2),{fileRecord:d.LOCAL_FILE_HEADER+ne+D+E,dirRecord:d.CENTRAL_FILE_HEADER+o(Z,2)+ne+o(K.length,2)+"\0\0\0\0"+o(Y,4)+o(b,4)+D+E+K}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),d=i("../signature");function h(f,v,m,b){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=v,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,l),h.prototype.push=function(f){var v=f.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,l.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:m?(v+100*(m-b-1))/m:100}}))},h.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var v=this.streamFiles&&!f.file.dir;if(v){var m=a(f,v,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(f){this.accumulate=!1;var v=this.streamFiles&&!f.file.dir,m=a(f,v,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),v)this.push({data:(function(b){return d.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var f=this.bytesWritten,v=0;v<this.dirRecords.length;v++)this.push({data:this.dirRecords[v],meta:{percent:100}});var m=this.bytesWritten-f,b=(function(y,S,x,w,$){var T=r.transformTo("string",$(w));return d.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(S,4)+o(x,4)+o(T.length,2)+T})(this.dirRecords.length,m,f,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(f){this._sources.push(f);var v=this;return f.on("data",function(m){v.processChunk(m)}),f.on("end",function(){v.closedSource(v.previous.streamInfo),v._sources.length?v.prepareNextSource():v.end()}),f.on("error",function(m){v.error(m)}),this},h.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(f){var v=this._sources;if(!l.prototype.error.call(this,f))return!1;for(var m=0;m<v.length;m++)try{v[m].error(f)}catch{}return!0},h.prototype.lock=function(){l.prototype.lock.call(this);for(var f=this._sources,v=0;v<f.length;v++)f[v].lock()},n.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),a=i("./ZipFileWorker");s.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),d=0;try{r.forEach(function(h,f){d++;var v=(function(S,x){var w=S||x,$=o[w];if(!$)throw new Error(w+" is not a valid compression method !");return $})(f.options.compression,l.compression),m=f.options.compressionOptions||l.compressionOptions||{},b=f.dir,y=f.date;f._compressWorker(v,m).withStreamInfo("file",{name:h,dir:b,date:y,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(u)}),u.entriesCount=d}catch(h){u.error(h)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function d(h){return new a.Promise(function(f,v){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){v(b)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?v(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(h,f){var v=this;return f=o.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(h)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,f.optimizedBinaryString,f.base64).then(function(m){var b=new l(f);return b.load(m),b}).then(function(m){var b=[a.Promise.resolve(m)],y=m.files;if(f.checkCRC32)for(var S=0;S<y.length;S++)b.push(d(y[S]));return a.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,S=0;S<y.length;S++){var x=y[S],w=x.fileNameStr,$=o.resolve(x.fileNameStr);v.file($,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:f.createFolders}),x.dir||(v.file($).unsafeOriginalName=w)}return b.zipComment.length&&(v.comment=b.zipComment),v})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(d,h){u.push(d)||u._helper.pause(),c&&c(h)}).on("error",function(d){u.emit("error",d)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},n.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o($,T,C){var D,F=r.getTypeOf(T),W=r.extend(C||{},u);W.date=W.date||new Date,W.compression!==null&&(W.compression=W.compression.toUpperCase()),typeof W.unixPermissions=="string"&&(W.unixPermissions=parseInt(W.unixPermissions,8)),W.unixPermissions&&16384&W.unixPermissions&&(W.dir=!0),W.dosPermissions&&16&W.dosPermissions&&(W.dir=!0),W.dir&&($=y($)),W.createFolders&&(D=b($))&&S.call(this,D,!0);var K=F==="string"&&W.binary===!1&&W.base64===!1;C&&C.binary!==void 0||(W.binary=!K),(T instanceof d&&T.uncompressedSize===0||W.dir||!T||T.length===0)&&(W.base64=!1,W.binary=!0,T="",W.compression="STORE",F="string");var _=null;_=T instanceof d||T instanceof l?T:v.isNode&&v.isStream(T)?new m($,T):r.prepareContent($,T,W.binary,W.optimizedBinaryString,W.base64);var j=new h($,_,W);this.files[$]=j}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),d=i("./compressedObject"),h=i("./zipObject"),f=i("./generate"),v=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function($){$.slice(-1)==="/"&&($=$.substring(0,$.length-1));var T=$.lastIndexOf("/");return 0<T?$.substring(0,T):""},y=function($){return $.slice(-1)!=="/"&&($+="/"),$},S=function($,T){return T=T!==void 0?T:u.createFolders,$=y($),this.files[$]||o.call(this,$,null,{dir:!0,createFolders:T}),this.files[$]};function x($){return Object.prototype.toString.call($)==="[object RegExp]"}var w={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function($){var T,C,D;for(T in this.files)D=this.files[T],(C=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&$(C,D)},filter:function($){var T=[];return this.forEach(function(C,D){$(C,D)&&T.push(D)}),T},file:function($,T,C){if(arguments.length!==1)return $=this.root+$,o.call(this,$,T,C),this;if(x($)){var D=$;return this.filter(function(W,K){return!K.dir&&D.test(W)})}var F=this.files[this.root+$];return F&&!F.dir?F:null},folder:function($){if(!$)return this;if(x($))return this.filter(function(F,W){return W.dir&&$.test(F)});var T=this.root+$,C=S.call(this,T),D=this.clone();return D.root=C.name,D},remove:function($){$=this.root+$;var T=this.files[$];if(T||($.slice(-1)!=="/"&&($+="/"),T=this.files[$]),T&&!T.dir)delete this.files[$];else for(var C=this.filter(function(F,W){return W.name.slice(0,$.length)===$}),D=0;D<C.length;D++)delete this.files[C[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function($){var T,C={};try{if((C=r.extend($||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var D=C.comment||this.comment||"";T=f.generateWorker(this,C,D)}catch(F){(T=new l("error")).error(F)}return new c(T,C.type||"string",C.mimeType)},generateAsync:function($,T){return this.generateInternalStream($).accumulate(T)},generateNodeStream:function($,T){return($=$||{}).type||($.type="nodebuffer"),this.generateInternalStream($).toNodejsStream(T)}};n.exports=w},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===l&&this.data[h+1]===c&&this.data[h+2]===u&&this.data[h+3]===d)return h-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.readData(4);return l===h[0]&&c===h[1]&&u===h[2]&&d===h[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=a},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(d){var h=o.getTypeOf(d);return o.checkSupport(h),h!=="string"||a.uint8array?h==="nodebuffer"?new c(d):a.uint8array?new u(o.transformTo("uint8array",d)):new r(o.transformTo("array",d)):new l(d)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),d=null;if(c.nodestream)try{d=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(v,m){return new u.Promise(function(b,y){var S=[],x=v._internalType,w=v._outputType,$=v._mimeType;v.on("data",function(T,C){S.push(T),m&&m(C)}).on("error",function(T){S=[],y(T)}).on("end",function(){try{var T=(function(C,D,F){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",D),F);case"base64":return l.encode(D);default:return o.transformTo(C,D)}})(w,(function(C,D){var F,W=0,K=null,_=0;for(F=0;F<D.length;F++)_+=D[F].length;switch(C){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(K=new Uint8Array(_),F=0;F<D.length;F++)K.set(D[F],W),W+=D[F].length;return K;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+C+"'")}})(x,S),$);b(T)}catch(C){y(C)}S=[]}).resume()})}function f(v,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=v.pipe(new a(y)),v.lock()}catch(S){this._worker=new r("error"),this._worker.error(S)}}f.prototype={accumulate:function(v){return h(this,v)},on:function(v,m){var b=this;return v==="data"?this._worker.on(v,function(y){m.call(b,y.data,y.meta)}):this._worker.on(v,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(v){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new d(this,{objectMode:this._outputType!=="nodebuffer"},v)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),s.blob=a.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function d(){l.call(this,"utf-8 decode"),this.leftOver=null}function h(){l.call(this,"utf-8 encode")}s.utf8encode=function(f){return a.nodebuffer?r.newBufferFrom(f,"utf-8"):(function(v){var m,b,y,S,x,w=v.length,$=0;for(S=0;S<w;S++)(64512&(b=v.charCodeAt(S)))==55296&&S+1<w&&(64512&(y=v.charCodeAt(S+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),S++),$+=b<128?1:b<2048?2:b<65536?3:4;for(m=a.uint8array?new Uint8Array($):new Array($),S=x=0;x<$;S++)(64512&(b=v.charCodeAt(S)))==55296&&S+1<w&&(64512&(y=v.charCodeAt(S+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),S++),b<128?m[x++]=b:(b<2048?m[x++]=192|b>>>6:(b<65536?m[x++]=224|b>>>12:(m[x++]=240|b>>>18,m[x++]=128|b>>>12&63),m[x++]=128|b>>>6&63),m[x++]=128|63&b);return m})(f)},s.utf8decode=function(f){return a.nodebuffer?o.transformTo("nodebuffer",f).toString("utf-8"):(function(v){var m,b,y,S,x=v.length,w=new Array(2*x);for(m=b=0;m<x;)if((y=v[m++])<128)w[b++]=y;else if(4<(S=c[y]))w[b++]=65533,m+=S-1;else{for(y&=S===2?31:S===3?15:7;1<S&&m<x;)y=y<<6|63&v[m++],S--;1<S?w[b++]=65533:y<65536?w[b++]=y:(y-=65536,w[b++]=55296|y>>10&1023,w[b++]=56320|1023&y)}return w.length!==b&&(w.subarray?w=w.subarray(0,b):w.length=b),o.applyFromCharCode(w)})(f=o.transformTo(a.uint8array?"uint8array":"array",f))},o.inherits(d,l),d.prototype.processChunk=function(f){var v=o.transformTo(a.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=v;(v=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),v.set(m,this.leftOver.length)}else v=this.leftOver.concat(v);this.leftOver=null}var b=(function(S,x){var w;for((x=x||S.length)>S.length&&(x=S.length),w=x-1;0<=w&&(192&S[w])==128;)w--;return w<0||w===0?x:w+c[S[w]]>x?w:x})(v),y=v;b!==v.length&&(a.uint8array?(y=v.subarray(0,b),this.leftOver=v.subarray(b,v.length)):(y=v.slice(0,b),this.leftOver=v.slice(b,v.length))),this.push({data:s.utf8decode(y),meta:f.meta})},d.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=d,o.inherits(h,l),h.prototype.processChunk=function(f){this.push({data:s.utf8encode(f.data),meta:f.meta})},s.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(m,b){s.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var d={stringifyByChunk:function(m,b,y){var S=[],x=0,w=m.length;if(w<=y)return String.fromCharCode.apply(null,m);for(;x<w;)b==="array"||b==="nodebuffer"?S.push(String.fromCharCode.apply(null,m.slice(x,Math.min(x+y,w)))):S.push(String.fromCharCode.apply(null,m.subarray(x,Math.min(x+y,w)))),x+=y;return S.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var b=65536,y=s.getTypeOf(m),S=!0;if(y==="uint8array"?S=d.applyCanBeUsed.uint8array:y==="nodebuffer"&&(S=d.applyCanBeUsed.nodebuffer),S)for(;1<b;)try{return d.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return d.stringifyByChar(m)}function f(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}s.applyFromCharCode=h;var v={};v.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return v.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},v.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},v.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return f(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},v.uint8array={string:h,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},v.nodebuffer={string:h,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return v.nodebuffer.uint8array(m).buffer},uint8array:function(m){return f(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,b){if(b=b||"",!m)return b;s.checkSupport(m);var y=s.getTypeOf(b);return v[y][m](b)},s.resolve=function(m){for(var b=m.split("/"),y=[],S=0;S<b.length;S++){var x=b[S];x==="."||x===""&&S!==0&&S!==b.length-1||(x===".."?y.pop():y.push(x))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var b,y,S="";for(y=0;y<(m||"").length;y++)S+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return S},s.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},s.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},s.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},s.prepareContent=function(m,b,y,S,x){return l.Promise.resolve(b).then(function(w){return o.blob&&(w instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(w))!==-1)&&typeof FileReader<"u"?new l.Promise(function($,T){var C=new FileReader;C.onload=function(D){$(D.target.result)},C.onerror=function(D){T(D.target.error)},C.readAsArrayBuffer(w)}):w}).then(function(w){var $=s.getTypeOf(w);return $?($==="arraybuffer"?w=s.transformTo("uint8array",w):$==="string"&&(x?w=a.decode(w):y&&S!==!0&&(w=(function(T){return u(T,o.uint8array?new Uint8Array(T.length):new Array(T.length))})(w))),w):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(d){this.files=[],this.loadOptions=d}u.prototype={checkSignature:function(d){if(!this.reader.readAndCheckSignature(d)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(h)+", expected "+a.pretty(d)+")")}},isSignature:function(d,h){var f=this.reader.index;this.reader.setIndex(d);var v=this.reader.readString(4)===h;return this.reader.setIndex(f),v},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var d=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",f=a.transformTo(h,d);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var d,h,f,v=this.zip64EndOfCentralSize-44;0<v;)d=this.reader.readInt(2),h=this.reader.readInt(4),f=this.reader.readData(h),this.zip64ExtensibleData[d]={id:d,length:h,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var d,h;for(d=0;d<this.files.length;d++)h=this.files[d],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var d;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(d=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(d);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var d=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(d<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(d);var h=d;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(d=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(d),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var v=h-f;if(0<v)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=v);else if(v<0)throw new Error("Corrupted zip: missing "+Math.abs(v)+" bytes.")},prepareReader:function(d){this.reader=o(d)},load:function(d){this.prepareReader(d),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),d=i("./support");function h(f,v){this.options=f,this.loadOptions=v}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var v,m;if(f.skip(22),this.fileNameLength=f.readInt(2),m=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((v=(function(b){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===b)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,v,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var v=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(v),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var v,m,b,y=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<y;)v=f.readInt(2),m=f.readInt(2),b=f.readData(m),this.extraFields[v]={id:v,length:m,value:b};f.setIndex(y)},handleUTF8:function(){var f=d.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var v=this.findExtraFieldUnicodePath();if(v!==null)this.fileNameStr=v;else{var m=a.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=a.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var v=o(f.value);return v.readInt(1)!==1||l(this.fileName)!==v.readInt(4)?null:c.utf8decode(v.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var v=o(f.value);return v.readInt(1)!==1||l(this.fileComment)!==v.readInt(4)?null:c.utf8decode(v.readData(f.length-5))}return null}},n.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(v,m,b){this.name=v,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(v){var m=null,b="string";try{if(!v)throw new Error("No output type specified.");var y=(b=v.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var S=!this._dataBinary;S&&!y&&(m=m.pipe(new l.Utf8EncodeWorker)),!S&&y&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(x){(m=new u("error")).error(x)}return new a(m,b,"")},async:function(v,m){return this.internalStream(v).accumulate(m)},nodeStream:function(v,m){return this.internalStream(v||"nodebuffer").toNodejsStream(m)},_compressWorker:function(v,m){if(this._data instanceof c&&this._data.compression.magic===v.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(b,v,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var d=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<d.length;f++)o.prototype[d[f]]=h;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(v),d=o.document.createTextNode("");u.observe(d,{characterData:!0}),a=function(){d.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){v(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(v,0)};else{var h=new o.MessageChannel;h.port1.onmessage=v,a=function(){h.port2.postMessage(0)}}var f=[];function v(){var m,b;r=!0;for(var y=f.length;y;){for(b=f,f=[],m=-1;++m<y;)b[m]();y=f.length}r=!1}n.exports=function(m){f.push(m)!==1||r||a()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function d(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==a&&m(this,y)}function h(y,S,x){this.promise=y,typeof S=="function"&&(this.onFulfilled=S,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function f(y,S,x){o(function(){var w;try{w=S(x)}catch($){return r.reject(y,$)}w===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,w)})}function v(y){var S=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof S=="function")return function(){S.apply(y,arguments)}}function m(y,S){var x=!1;function w(C){x||(x=!0,r.reject(y,C))}function $(C){x||(x=!0,r.resolve(y,C))}var T=b(function(){S($,w)});T.status==="error"&&w(T.value)}function b(y,S){var x={};try{x.value=y(S),x.status="success"}catch(w){x.status="error",x.value=w}return x}(n.exports=d).prototype.finally=function(y){if(typeof y!="function")return this;var S=this.constructor;return this.then(function(x){return S.resolve(y()).then(function(){return x})},function(x){return S.resolve(y()).then(function(){throw x})})},d.prototype.catch=function(y){return this.then(null,y)},d.prototype.then=function(y,S){if(typeof y!="function"&&this.state===c||typeof S!="function"&&this.state===l)return this;var x=new this.constructor(a);return this.state!==u?f(x,this.state===c?y:S,this.outcome):this.queue.push(new h(x,y,S)),x},h.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},h.prototype.otherCallFulfilled=function(y){f(this.promise,this.onFulfilled,y)},h.prototype.callRejected=function(y){r.reject(this.promise,y)},h.prototype.otherCallRejected=function(y){f(this.promise,this.onRejected,y)},r.resolve=function(y,S){var x=b(v,S);if(x.status==="error")return r.reject(y,x.value);var w=x.value;if(w)m(y,w);else{y.state=c,y.outcome=S;for(var $=-1,T=y.queue.length;++$<T;)y.queue[$].callFulfilled(S)}return y},r.reject=function(y,S){y.state=l,y.outcome=S;for(var x=-1,w=y.queue.length;++x<w;)y.queue[x].callRejected(S);return y},d.resolve=function(y){return y instanceof this?y:r.resolve(new this(a),y)},d.reject=function(y){var S=new this(a);return r.reject(S,y)},d.all=function(y){var S=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=y.length,w=!1;if(!x)return this.resolve([]);for(var $=new Array(x),T=0,C=-1,D=new this(a);++C<x;)F(y[C],C);return D;function F(W,K){S.resolve(W).then(function(_){$[K]=_,++T!==x||w||(w=!0,r.resolve(D,$))},function(_){w||(w=!0,r.reject(D,_))})}},d.race=function(y){var S=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=y.length,w=!1;if(!x)return this.resolve([]);for(var $=-1,T=new this(a);++$<x;)C=y[$],S.resolve(C).then(function(D){w||(w=!0,r.resolve(T,D))},function(D){w||(w=!0,r.reject(T,D))});var C;return T}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,d=0,h=-1,f=0,v=8;function m(y){if(!(this instanceof m))return new m(y);this.options=a.assign({level:h,method:v,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},y||{});var S=this.options;S.raw&&0<S.windowBits?S.windowBits=-S.windowBits:S.gzip&&0<S.windowBits&&S.windowBits<16&&(S.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=o.deflateInit2(this.strm,S.level,S.method,S.windowBits,S.memLevel,S.strategy);if(x!==d)throw new Error(l[x]);if(S.header&&o.deflateSetHeader(this.strm,S.header),S.dictionary){var w;if(w=typeof S.dictionary=="string"?r.string2buf(S.dictionary):u.call(S.dictionary)==="[object ArrayBuffer]"?new Uint8Array(S.dictionary):S.dictionary,(x=o.deflateSetDictionary(this.strm,w))!==d)throw new Error(l[x]);this._dict_set=!0}}function b(y,S){var x=new m(S);if(x.push(y,!0),x.err)throw x.msg||l[x.err];return x.result}m.prototype.push=function(y,S){var x,w,$=this.strm,T=this.options.chunkSize;if(this.ended)return!1;w=S===~~S?S:S===!0?4:0,typeof y=="string"?$.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?$.input=new Uint8Array(y):$.input=y,$.next_in=0,$.avail_in=$.input.length;do{if($.avail_out===0&&($.output=new a.Buf8(T),$.next_out=0,$.avail_out=T),(x=o.deflate($,w))!==1&&x!==d)return this.onEnd(x),!(this.ended=!0);$.avail_out!==0&&($.avail_in!==0||w!==4&&w!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf($.output,$.next_out))):this.onData(a.shrinkBuf($.output,$.next_out)))}while((0<$.avail_in||$.avail_out===0)&&x!==1);return w===4?(x=o.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===d):w!==2||(this.onEnd(d),!($.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===d&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=b,s.deflateRaw=function(y,S){return(S=S||{}).raw=!0,b(y,S)},s.gzip=function(y,S){return(S=S||{}).gzip=!0,b(y,S)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),d=i("./zlib/gzheader"),h=Object.prototype.toString;function f(m){if(!(this instanceof f))return new f(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==l.Z_OK)throw new Error(c[y]);this.header=new d,o.inflateGetHeader(this.strm,this.header)}function v(m,b){var y=new f(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}f.prototype.push=function(m,b){var y,S,x,w,$,T,C=this.strm,D=this.options.chunkSize,F=this.options.dictionary,W=!1;if(this.ended)return!1;S=b===~~b?b:b===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(D),C.next_out=0,C.avail_out=D),(y=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&F&&(T=typeof F=="string"?r.string2buf(F):h.call(F)==="[object ArrayBuffer]"?new Uint8Array(F):F,y=o.inflateSetDictionary(this.strm,T)),y===l.Z_BUF_ERROR&&W===!0&&(y=l.Z_OK,W=!1),y!==l.Z_STREAM_END&&y!==l.Z_OK)return this.onEnd(y),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&y!==l.Z_STREAM_END&&(C.avail_in!==0||S!==l.Z_FINISH&&S!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=r.utf8border(C.output,C.next_out),w=C.next_out-x,$=r.buf2string(C.output,x),C.next_out=w,C.avail_out=D-w,w&&a.arraySet(C.output,C.output,x,w,0),this.onData($)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(W=!0)}while((0<C.avail_in||C.avail_out===0)&&y!==l.Z_STREAM_END);return y===l.Z_STREAM_END&&(S=l.Z_FINISH),S===l.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===l.Z_OK):S!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},f.prototype.onData=function(m){this.chunks.push(m)},f.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=f,s.inflate=v,s.inflateRaw=function(m,b){return(b=b||{}).raw=!0,v(m,b)},s.ungzip=v},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var d in u)u.hasOwnProperty(d)&&(l[d]=u[d])}}return l},s.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,d,h){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+d),h);else for(var f=0;f<d;f++)l[h+f]=c[u+f]},flattenChunks:function(l){var c,u,d,h,f,v;for(c=d=0,u=l.length;c<u;c++)d+=l[c].length;for(v=new Uint8Array(d),c=h=0,u=l.length;c<u;c++)f=l[c],v.set(f,h),h+=f.length;return v}},r={arraySet:function(l,c,u,d,h){for(var f=0;f<d;f++)l[h+f]=c[u+f]},flattenChunks:function(l){return[].concat.apply([],l)}};s.setTyped=function(l){l?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,a)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(d,h){if(h<65537&&(d.subarray&&r||!d.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(d,h));for(var f="",v=0;v<h;v++)f+=String.fromCharCode(d[v]);return f}l[254]=l[254]=1,s.string2buf=function(d){var h,f,v,m,b,y=d.length,S=0;for(m=0;m<y;m++)(64512&(f=d.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=d.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(v-56320),m++),S+=f<128?1:f<2048?2:f<65536?3:4;for(h=new o.Buf8(S),m=b=0;b<S;m++)(64512&(f=d.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=d.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(v-56320),m++),f<128?h[b++]=f:(f<2048?h[b++]=192|f>>>6:(f<65536?h[b++]=224|f>>>12:(h[b++]=240|f>>>18,h[b++]=128|f>>>12&63),h[b++]=128|f>>>6&63),h[b++]=128|63&f);return h},s.buf2binstring=function(d){return u(d,d.length)},s.binstring2buf=function(d){for(var h=new o.Buf8(d.length),f=0,v=h.length;f<v;f++)h[f]=d.charCodeAt(f);return h},s.buf2string=function(d,h){var f,v,m,b,y=h||d.length,S=new Array(2*y);for(f=v=0;f<y;)if((m=d[f++])<128)S[v++]=m;else if(4<(b=l[m]))S[v++]=65533,f+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&f<y;)m=m<<6|63&d[f++],b--;1<b?S[v++]=65533:m<65536?S[v++]=m:(m-=65536,S[v++]=55296|m>>10&1023,S[v++]=56320|1023&m)}return u(S,v)},s.utf8border=function(d,h){var f;for((h=h||d.length)>d.length&&(h=d.length),f=h-1;0<=f&&(192&d[f])==128;)f--;return f<0||f===0?h:f+l[d[f]]>h?f:h}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,d=0;r!==0;){for(r-=d=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--d;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();n.exports=function(a,r,l,c){var u=o,d=c+l;a^=-1;for(var h=c;h<d;h++)a=a>>>8^u[255&(a^r[h])];return-1^a}},{}],46:[function(i,n,s){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),d=0,h=4,f=0,v=-2,m=-1,b=4,y=2,S=8,x=9,w=286,$=30,T=19,C=2*w+1,D=15,F=3,W=258,K=W+F+1,_=42,j=113,k=1,E=2,N=3,B=4;function L(g,G){return g.msg=u[G],G}function R(g){return(g<<1)-(4<g?9:0)}function de(g){for(var G=g.length;0<=--G;)g[G]=0}function V(g){var G=g.state,H=G.pending;H>g.avail_out&&(H=g.avail_out),H!==0&&(a.arraySet(g.output,G.pending_buf,G.pending_out,H,g.next_out),g.next_out+=H,G.pending_out+=H,g.total_out+=H,g.avail_out-=H,G.pending-=H,G.pending===0&&(G.pending_out=0))}function Y(g,G){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,G),g.block_start=g.strstart,V(g.strm)}function Z(g,G){g.pending_buf[g.pending++]=G}function ne(g,G){g.pending_buf[g.pending++]=G>>>8&255,g.pending_buf[g.pending++]=255&G}function oe(g,G){var H,I,M=g.max_chain_length,O=g.strstart,q=g.prev_length,A=g.nice_match,z=g.strstart>g.w_size-K?g.strstart-(g.w_size-K):0,J=g.window,ie=g.w_mask,se=g.prev,me=g.strstart+W,$e=J[O+q-1],Se=J[O+q];g.prev_length>=g.good_match&&(M>>=2),A>g.lookahead&&(A=g.lookahead);do if(J[(H=G)+q]===Se&&J[H+q-1]===$e&&J[H]===J[O]&&J[++H]===J[O+1]){O+=2,H++;do;while(J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&J[++O]===J[++H]&&O<me);if(I=W-(me-O),O=me-W,q<I){if(g.match_start=G,A<=(q=I))break;$e=J[O+q-1],Se=J[O+q]}}while((G=se[G&ie])>z&&--M!=0);return q<=g.lookahead?q:g.lookahead}function ye(g){var G,H,I,M,O,q,A,z,J,ie,se=g.w_size;do{if(M=g.window_size-g.lookahead-g.strstart,g.strstart>=se+(se-K)){for(a.arraySet(g.window,g.window,se,se,0),g.match_start-=se,g.strstart-=se,g.block_start-=se,G=H=g.hash_size;I=g.head[--G],g.head[G]=se<=I?I-se:0,--H;);for(G=H=se;I=g.prev[--G],g.prev[G]=se<=I?I-se:0,--H;);M+=se}if(g.strm.avail_in===0)break;if(q=g.strm,A=g.window,z=g.strstart+g.lookahead,J=M,ie=void 0,ie=q.avail_in,J<ie&&(ie=J),H=ie===0?0:(q.avail_in-=ie,a.arraySet(A,q.input,q.next_in,ie,z),q.state.wrap===1?q.adler=l(q.adler,A,ie,z):q.state.wrap===2&&(q.adler=c(q.adler,A,ie,z)),q.next_in+=ie,q.total_in+=ie,ie),g.lookahead+=H,g.lookahead+g.insert>=F)for(O=g.strstart-g.insert,g.ins_h=g.window[O],g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+F-1])&g.hash_mask,g.prev[O&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=O,O++,g.insert--,!(g.lookahead+g.insert<F)););}while(g.lookahead<K&&g.strm.avail_in!==0)}function Ie(g,G){for(var H,I;;){if(g.lookahead<K){if(ye(g),g.lookahead<K&&G===d)return k;if(g.lookahead===0)break}if(H=0,g.lookahead>=F&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),H!==0&&g.strstart-H<=g.w_size-K&&(g.match_length=oe(g,H)),g.match_length>=F)if(I=r._tr_tally(g,g.strstart-g.match_start,g.match_length-F),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=F){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else I=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(I&&(Y(g,!1),g.strm.avail_out===0))return k}return g.insert=g.strstart<F-1?g.strstart:F-1,G===h?(Y(g,!0),g.strm.avail_out===0?N:B):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?k:E}function Ce(g,G){for(var H,I,M;;){if(g.lookahead<K){if(ye(g),g.lookahead<K&&G===d)return k;if(g.lookahead===0)break}if(H=0,g.lookahead>=F&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=F-1,H!==0&&g.prev_length<g.max_lazy_match&&g.strstart-H<=g.w_size-K&&(g.match_length=oe(g,H),g.match_length<=5&&(g.strategy===1||g.match_length===F&&4096<g.strstart-g.match_start)&&(g.match_length=F-1)),g.prev_length>=F&&g.match_length<=g.prev_length){for(M=g.strstart+g.lookahead-F,I=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-F),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=M&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+F-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=F-1,g.strstart++,I&&(Y(g,!1),g.strm.avail_out===0))return k}else if(g.match_available){if((I=r._tr_tally(g,0,g.window[g.strstart-1]))&&Y(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return k}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(I=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<F-1?g.strstart:F-1,G===h?(Y(g,!0),g.strm.avail_out===0?N:B):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?k:E}function le(g,G,H,I,M){this.good_length=g,this.max_lazy=G,this.nice_length=H,this.max_chain=I,this.func=M}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=S,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*$+1)),this.bl_tree=new a.Buf16(2*(2*T+1)),de(this.dyn_ltree),de(this.dyn_dtree),de(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(D+1),this.heap=new a.Buf16(2*w+1),de(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*w+1),de(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ce(g){var G;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(G=g.state).pending=0,G.pending_out=0,G.wrap<0&&(G.wrap=-G.wrap),G.status=G.wrap?_:j,g.adler=G.wrap===2?0:1,G.last_flush=d,r._tr_init(G),f):L(g,v)}function P(g){var G=ce(g);return G===f&&(function(H){H.window_size=2*H.w_size,de(H.head),H.max_lazy_match=o[H.level].max_lazy,H.good_match=o[H.level].good_length,H.nice_match=o[H.level].nice_length,H.max_chain_length=o[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=F-1,H.match_available=0,H.ins_h=0})(g.state),G}function U(g,G,H,I,M,O){if(!g)return v;var q=1;if(G===m&&(G=6),I<0?(q=0,I=-I):15<I&&(q=2,I-=16),M<1||x<M||H!==S||I<8||15<I||G<0||9<G||O<0||b<O)return L(g,v);I===8&&(I=9);var A=new X;return(g.state=A).strm=g,A.wrap=q,A.gzhead=null,A.w_bits=I,A.w_size=1<<A.w_bits,A.w_mask=A.w_size-1,A.hash_bits=M+7,A.hash_size=1<<A.hash_bits,A.hash_mask=A.hash_size-1,A.hash_shift=~~((A.hash_bits+F-1)/F),A.window=new a.Buf8(2*A.w_size),A.head=new a.Buf16(A.hash_size),A.prev=new a.Buf16(A.w_size),A.lit_bufsize=1<<M+6,A.pending_buf_size=4*A.lit_bufsize,A.pending_buf=new a.Buf8(A.pending_buf_size),A.d_buf=1*A.lit_bufsize,A.l_buf=3*A.lit_bufsize,A.level=G,A.strategy=O,A.method=H,P(g)}o=[new le(0,0,0,0,function(g,G){var H=65535;for(H>g.pending_buf_size-5&&(H=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ye(g),g.lookahead===0&&G===d)return k;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var I=g.block_start+H;if((g.strstart===0||g.strstart>=I)&&(g.lookahead=g.strstart-I,g.strstart=I,Y(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-K&&(Y(g,!1),g.strm.avail_out===0))return k}return g.insert=0,G===h?(Y(g,!0),g.strm.avail_out===0?N:B):(g.strstart>g.block_start&&(Y(g,!1),g.strm.avail_out),k)}),new le(4,4,8,4,Ie),new le(4,5,16,8,Ie),new le(4,6,32,32,Ie),new le(4,4,16,16,Ce),new le(8,16,32,32,Ce),new le(8,16,128,128,Ce),new le(8,32,128,256,Ce),new le(32,128,258,1024,Ce),new le(32,258,258,4096,Ce)],s.deflateInit=function(g,G){return U(g,G,S,15,8,0)},s.deflateInit2=U,s.deflateReset=P,s.deflateResetKeep=ce,s.deflateSetHeader=function(g,G){return g&&g.state?g.state.wrap!==2?v:(g.state.gzhead=G,f):v},s.deflate=function(g,G){var H,I,M,O;if(!g||!g.state||5<G||G<0)return g?L(g,v):v;if(I=g.state,!g.output||!g.input&&g.avail_in!==0||I.status===666&&G!==h)return L(g,g.avail_out===0?-5:v);if(I.strm=g,H=I.last_flush,I.last_flush=G,I.status===_)if(I.wrap===2)g.adler=0,Z(I,31),Z(I,139),Z(I,8),I.gzhead?(Z(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),Z(I,255&I.gzhead.time),Z(I,I.gzhead.time>>8&255),Z(I,I.gzhead.time>>16&255),Z(I,I.gzhead.time>>24&255),Z(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),Z(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(Z(I,255&I.gzhead.extra.length),Z(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(g.adler=c(g.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(Z(I,0),Z(I,0),Z(I,0),Z(I,0),Z(I,0),Z(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),Z(I,3),I.status=j);else{var q=S+(I.w_bits-8<<4)<<8;q|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(q|=32),q+=31-q%31,I.status=j,ne(I,q),I.strstart!==0&&(ne(I,g.adler>>>16),ne(I,65535&g.adler)),g.adler=1}if(I.status===69)if(I.gzhead.extra){for(M=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),V(g),M=I.pending,I.pending!==I.pending_buf_size));)Z(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){M=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),V(g),M=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,Z(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),O===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){M=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),V(g),M=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,Z(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>M&&(g.adler=c(g.adler,I.pending_buf,I.pending-M,M)),O===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&V(g),I.pending+2<=I.pending_buf_size&&(Z(I,255&g.adler),Z(I,g.adler>>8&255),g.adler=0,I.status=j)):I.status=j),I.pending!==0){if(V(g),g.avail_out===0)return I.last_flush=-1,f}else if(g.avail_in===0&&R(G)<=R(H)&&G!==h)return L(g,-5);if(I.status===666&&g.avail_in!==0)return L(g,-5);if(g.avail_in!==0||I.lookahead!==0||G!==d&&I.status!==666){var A=I.strategy===2?(function(z,J){for(var ie;;){if(z.lookahead===0&&(ye(z),z.lookahead===0)){if(J===d)return k;break}if(z.match_length=0,ie=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++,ie&&(Y(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(Y(z,!0),z.strm.avail_out===0?N:B):z.last_lit&&(Y(z,!1),z.strm.avail_out===0)?k:E})(I,G):I.strategy===3?(function(z,J){for(var ie,se,me,$e,Se=z.window;;){if(z.lookahead<=W){if(ye(z),z.lookahead<=W&&J===d)return k;if(z.lookahead===0)break}if(z.match_length=0,z.lookahead>=F&&0<z.strstart&&(se=Se[me=z.strstart-1])===Se[++me]&&se===Se[++me]&&se===Se[++me]){$e=z.strstart+W;do;while(se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&se===Se[++me]&&me<$e);z.match_length=W-($e-me),z.match_length>z.lookahead&&(z.match_length=z.lookahead)}if(z.match_length>=F?(ie=r._tr_tally(z,1,z.match_length-F),z.lookahead-=z.match_length,z.strstart+=z.match_length,z.match_length=0):(ie=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++),ie&&(Y(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(Y(z,!0),z.strm.avail_out===0?N:B):z.last_lit&&(Y(z,!1),z.strm.avail_out===0)?k:E})(I,G):o[I.level].func(I,G);if(A!==N&&A!==B||(I.status=666),A===k||A===N)return g.avail_out===0&&(I.last_flush=-1),f;if(A===E&&(G===1?r._tr_align(I):G!==5&&(r._tr_stored_block(I,0,0,!1),G===3&&(de(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),V(g),g.avail_out===0))return I.last_flush=-1,f}return G!==h?f:I.wrap<=0?1:(I.wrap===2?(Z(I,255&g.adler),Z(I,g.adler>>8&255),Z(I,g.adler>>16&255),Z(I,g.adler>>24&255),Z(I,255&g.total_in),Z(I,g.total_in>>8&255),Z(I,g.total_in>>16&255),Z(I,g.total_in>>24&255)):(ne(I,g.adler>>>16),ne(I,65535&g.adler)),V(g),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?f:1)},s.deflateEnd=function(g){var G;return g&&g.state?(G=g.state.status)!==_&&G!==69&&G!==73&&G!==91&&G!==103&&G!==j&&G!==666?L(g,v):(g.state=null,G===j?L(g,-3):f):v},s.deflateSetDictionary=function(g,G){var H,I,M,O,q,A,z,J,ie=G.length;if(!g||!g.state||(O=(H=g.state).wrap)===2||O===1&&H.status!==_||H.lookahead)return v;for(O===1&&(g.adler=l(g.adler,G,ie,0)),H.wrap=0,ie>=H.w_size&&(O===0&&(de(H.head),H.strstart=0,H.block_start=0,H.insert=0),J=new a.Buf8(H.w_size),a.arraySet(J,G,ie-H.w_size,H.w_size,0),G=J,ie=H.w_size),q=g.avail_in,A=g.next_in,z=g.input,g.avail_in=ie,g.next_in=0,g.input=G,ye(H);H.lookahead>=F;){for(I=H.strstart,M=H.lookahead-(F-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[I+F-1])&H.hash_mask,H.prev[I&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=I,I++,--M;);H.strstart=I,H.lookahead=F-1,ye(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=F-1,H.match_available=0,g.next_in=A,g.input=z,g.avail_in=q,H.wrap=O,f},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,a){var r,l,c,u,d,h,f,v,m,b,y,S,x,w,$,T,C,D,F,W,K,_,j,k,E;r=o.state,l=o.next_in,k=o.input,c=l+(o.avail_in-5),u=o.next_out,E=o.output,d=u-(a-o.avail_out),h=u+(o.avail_out-257),f=r.dmax,v=r.wsize,m=r.whave,b=r.wnext,y=r.window,S=r.hold,x=r.bits,w=r.lencode,$=r.distcode,T=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{x<15&&(S+=k[l++]<<x,x+=8,S+=k[l++]<<x,x+=8),D=w[S&T];t:for(;;){if(S>>>=F=D>>>24,x-=F,(F=D>>>16&255)===0)E[u++]=65535&D;else{if(!(16&F)){if((64&F)==0){D=w[(65535&D)+(S&(1<<F)-1)];continue t}if(32&F){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}W=65535&D,(F&=15)&&(x<F&&(S+=k[l++]<<x,x+=8),W+=S&(1<<F)-1,S>>>=F,x-=F),x<15&&(S+=k[l++]<<x,x+=8,S+=k[l++]<<x,x+=8),D=$[S&C];i:for(;;){if(S>>>=F=D>>>24,x-=F,!(16&(F=D>>>16&255))){if((64&F)==0){D=$[(65535&D)+(S&(1<<F)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&D,x<(F&=15)&&(S+=k[l++]<<x,(x+=8)<F&&(S+=k[l++]<<x,x+=8)),f<(K+=S&(1<<F)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(S>>>=F,x-=F,(F=u-d)<K){if(m<(F=K-F)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(j=y,(_=0)===b){if(_+=v-F,F<W){for(W-=F;E[u++]=y[_++],--F;);_=u-K,j=E}}else if(b<F){if(_+=v+b-F,(F-=b)<W){for(W-=F;E[u++]=y[_++],--F;);if(_=0,b<W){for(W-=F=b;E[u++]=y[_++],--F;);_=u-K,j=E}}}else if(_+=b-F,F<W){for(W-=F;E[u++]=y[_++],--F;);_=u-K,j=E}for(;2<W;)E[u++]=j[_++],E[u++]=j[_++],E[u++]=j[_++],W-=3;W&&(E[u++]=j[_++],1<W&&(E[u++]=j[_++]))}else{for(_=u-K;E[u++]=E[_++],E[u++]=E[_++],E[u++]=E[_++],2<(W-=3););W&&(E[u++]=E[_++],1<W&&(E[u++]=E[_++]))}break}}break}}while(l<c&&u<h);l-=W=x>>3,S&=(1<<(x-=W<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<h?h-u+257:257-(u-h),r.hold=S,r.bits=x}},{}],49:[function(i,n,s){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,d=2,h=0,f=-2,v=1,m=852,b=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function S(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x(_){var j;return _&&_.state?(j=_.state,_.total_in=_.total_out=j.total=0,_.msg="",j.wrap&&(_.adler=1&j.wrap),j.mode=v,j.last=0,j.havedict=0,j.dmax=32768,j.head=null,j.hold=0,j.bits=0,j.lencode=j.lendyn=new o.Buf32(m),j.distcode=j.distdyn=new o.Buf32(b),j.sane=1,j.back=-1,h):f}function w(_){var j;return _&&_.state?((j=_.state).wsize=0,j.whave=0,j.wnext=0,x(_)):f}function $(_,j){var k,E;return _&&_.state?(E=_.state,j<0?(k=0,j=-j):(k=1+(j>>4),j<48&&(j&=15)),j&&(j<8||15<j)?f:(E.window!==null&&E.wbits!==j&&(E.window=null),E.wrap=k,E.wbits=j,w(_))):f}function T(_,j){var k,E;return _?(E=new S,(_.state=E).window=null,(k=$(_,j))!==h&&(_.state=null),k):f}var C,D,F=!0;function W(_){if(F){var j;for(C=new o.Buf32(512),D=new o.Buf32(32),j=0;j<144;)_.lens[j++]=8;for(;j<256;)_.lens[j++]=9;for(;j<280;)_.lens[j++]=7;for(;j<288;)_.lens[j++]=8;for(c(u,_.lens,0,288,C,0,_.work,{bits:9}),j=0;j<32;)_.lens[j++]=5;c(d,_.lens,0,32,D,0,_.work,{bits:5}),F=!1}_.lencode=C,_.lenbits=9,_.distcode=D,_.distbits=5}function K(_,j,k,E){var N,B=_.state;return B.window===null&&(B.wsize=1<<B.wbits,B.wnext=0,B.whave=0,B.window=new o.Buf8(B.wsize)),E>=B.wsize?(o.arraySet(B.window,j,k-B.wsize,B.wsize,0),B.wnext=0,B.whave=B.wsize):(E<(N=B.wsize-B.wnext)&&(N=E),o.arraySet(B.window,j,k-E,N,B.wnext),(E-=N)?(o.arraySet(B.window,j,k-E,E,0),B.wnext=E,B.whave=B.wsize):(B.wnext+=N,B.wnext===B.wsize&&(B.wnext=0),B.whave<B.wsize&&(B.whave+=N))),0}s.inflateReset=w,s.inflateReset2=$,s.inflateResetKeep=x,s.inflateInit=function(_){return T(_,15)},s.inflateInit2=T,s.inflate=function(_,j){var k,E,N,B,L,R,de,V,Y,Z,ne,oe,ye,Ie,Ce,le,X,ce,P,U,g,G,H,I,M=0,O=new o.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return f;(k=_.state).mode===12&&(k.mode=13),L=_.next_out,N=_.output,de=_.avail_out,B=_.next_in,E=_.input,R=_.avail_in,V=k.hold,Y=k.bits,Z=R,ne=de,G=h;e:for(;;)switch(k.mode){case v:if(k.wrap===0){k.mode=13;break}for(;Y<16;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(2&k.wrap&&V===35615){O[k.check=0]=255&V,O[1]=V>>>8&255,k.check=r(k.check,O,2,0),Y=V=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&V)<<8)+(V>>8))%31){_.msg="incorrect header check",k.mode=30;break}if((15&V)!=8){_.msg="unknown compression method",k.mode=30;break}if(Y-=4,g=8+(15&(V>>>=4)),k.wbits===0)k.wbits=g;else if(g>k.wbits){_.msg="invalid window size",k.mode=30;break}k.dmax=1<<g,_.adler=k.check=1,k.mode=512&V?10:12,Y=V=0;break;case 2:for(;Y<16;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(k.flags=V,(255&k.flags)!=8){_.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){_.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=V>>8&1),512&k.flags&&(O[0]=255&V,O[1]=V>>>8&255,k.check=r(k.check,O,2,0)),Y=V=0,k.mode=3;case 3:for(;Y<32;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.head&&(k.head.time=V),512&k.flags&&(O[0]=255&V,O[1]=V>>>8&255,O[2]=V>>>16&255,O[3]=V>>>24&255,k.check=r(k.check,O,4,0)),Y=V=0,k.mode=4;case 4:for(;Y<16;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.head&&(k.head.xflags=255&V,k.head.os=V>>8),512&k.flags&&(O[0]=255&V,O[1]=V>>>8&255,k.check=r(k.check,O,2,0)),Y=V=0,k.mode=5;case 5:if(1024&k.flags){for(;Y<16;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.length=V,k.head&&(k.head.extra_len=V),512&k.flags&&(O[0]=255&V,O[1]=V>>>8&255,k.check=r(k.check,O,2,0)),Y=V=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(R<(oe=k.length)&&(oe=R),oe&&(k.head&&(g=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,E,B,oe,g)),512&k.flags&&(k.check=r(k.check,E,oe,B)),R-=oe,B+=oe,k.length-=oe),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(R===0)break e;for(oe=0;g=E[B+oe++],k.head&&g&&k.length<65536&&(k.head.name+=String.fromCharCode(g)),g&&oe<R;);if(512&k.flags&&(k.check=r(k.check,E,oe,B)),R-=oe,B+=oe,g)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(R===0)break e;for(oe=0;g=E[B+oe++],k.head&&g&&k.length<65536&&(k.head.comment+=String.fromCharCode(g)),g&&oe<R;);if(512&k.flags&&(k.check=r(k.check,E,oe,B)),R-=oe,B+=oe,g)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;Y<16;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(V!==(65535&k.check)){_.msg="header crc mismatch",k.mode=30;break}Y=V=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),_.adler=k.check=0,k.mode=12;break;case 10:for(;Y<32;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}_.adler=k.check=y(V),Y=V=0,k.mode=11;case 11:if(k.havedict===0)return _.next_out=L,_.avail_out=de,_.next_in=B,_.avail_in=R,k.hold=V,k.bits=Y,2;_.adler=k.check=1,k.mode=12;case 12:if(j===5||j===6)break e;case 13:if(k.last){V>>>=7&Y,Y-=7&Y,k.mode=27;break}for(;Y<3;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}switch(k.last=1&V,Y-=1,3&(V>>>=1)){case 0:k.mode=14;break;case 1:if(W(k),k.mode=20,j!==6)break;V>>>=2,Y-=2;break e;case 2:k.mode=17;break;case 3:_.msg="invalid block type",k.mode=30}V>>>=2,Y-=2;break;case 14:for(V>>>=7&Y,Y-=7&Y;Y<32;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if((65535&V)!=(V>>>16^65535)){_.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&V,Y=V=0,k.mode=15,j===6)break e;case 15:k.mode=16;case 16:if(oe=k.length){if(R<oe&&(oe=R),de<oe&&(oe=de),oe===0)break e;o.arraySet(N,E,B,oe,L),R-=oe,B+=oe,de-=oe,L+=oe,k.length-=oe;break}k.mode=12;break;case 17:for(;Y<14;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(k.nlen=257+(31&V),V>>>=5,Y-=5,k.ndist=1+(31&V),V>>>=5,Y-=5,k.ncode=4+(15&V),V>>>=4,Y-=4,286<k.nlen||30<k.ndist){_.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;Y<3;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.lens[q[k.have++]]=7&V,V>>>=3,Y-=3}for(;k.have<19;)k.lens[q[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,H={bits:k.lenbits},G=c(0,k.lens,0,19,k.lencode,0,k.work,H),k.lenbits=H.bits,G){_.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;le=(M=k.lencode[V&(1<<k.lenbits)-1])>>>16&255,X=65535&M,!((Ce=M>>>24)<=Y);){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(X<16)V>>>=Ce,Y-=Ce,k.lens[k.have++]=X;else{if(X===16){for(I=Ce+2;Y<I;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(V>>>=Ce,Y-=Ce,k.have===0){_.msg="invalid bit length repeat",k.mode=30;break}g=k.lens[k.have-1],oe=3+(3&V),V>>>=2,Y-=2}else if(X===17){for(I=Ce+3;Y<I;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}Y-=Ce,g=0,oe=3+(7&(V>>>=Ce)),V>>>=3,Y-=3}else{for(I=Ce+7;Y<I;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}Y-=Ce,g=0,oe=11+(127&(V>>>=Ce)),V>>>=7,Y-=7}if(k.have+oe>k.nlen+k.ndist){_.msg="invalid bit length repeat",k.mode=30;break}for(;oe--;)k.lens[k.have++]=g}}if(k.mode===30)break;if(k.lens[256]===0){_.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,H={bits:k.lenbits},G=c(u,k.lens,0,k.nlen,k.lencode,0,k.work,H),k.lenbits=H.bits,G){_.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,H={bits:k.distbits},G=c(d,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,H),k.distbits=H.bits,G){_.msg="invalid distances set",k.mode=30;break}if(k.mode=20,j===6)break e;case 20:k.mode=21;case 21:if(6<=R&&258<=de){_.next_out=L,_.avail_out=de,_.next_in=B,_.avail_in=R,k.hold=V,k.bits=Y,l(_,ne),L=_.next_out,N=_.output,de=_.avail_out,B=_.next_in,E=_.input,R=_.avail_in,V=k.hold,Y=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;le=(M=k.lencode[V&(1<<k.lenbits)-1])>>>16&255,X=65535&M,!((Ce=M>>>24)<=Y);){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(le&&(240&le)==0){for(ce=Ce,P=le,U=X;le=(M=k.lencode[U+((V&(1<<ce+P)-1)>>ce)])>>>16&255,X=65535&M,!(ce+(Ce=M>>>24)<=Y);){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}V>>>=ce,Y-=ce,k.back+=ce}if(V>>>=Ce,Y-=Ce,k.back+=Ce,k.length=X,le===0){k.mode=26;break}if(32&le){k.back=-1,k.mode=12;break}if(64&le){_.msg="invalid literal/length code",k.mode=30;break}k.extra=15&le,k.mode=22;case 22:if(k.extra){for(I=k.extra;Y<I;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.length+=V&(1<<k.extra)-1,V>>>=k.extra,Y-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;le=(M=k.distcode[V&(1<<k.distbits)-1])>>>16&255,X=65535&M,!((Ce=M>>>24)<=Y);){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if((240&le)==0){for(ce=Ce,P=le,U=X;le=(M=k.distcode[U+((V&(1<<ce+P)-1)>>ce)])>>>16&255,X=65535&M,!(ce+(Ce=M>>>24)<=Y);){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}V>>>=ce,Y-=ce,k.back+=ce}if(V>>>=Ce,Y-=Ce,k.back+=Ce,64&le){_.msg="invalid distance code",k.mode=30;break}k.offset=X,k.extra=15&le,k.mode=24;case 24:if(k.extra){for(I=k.extra;Y<I;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}k.offset+=V&(1<<k.extra)-1,V>>>=k.extra,Y-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){_.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(de===0)break e;if(oe=ne-de,k.offset>oe){if((oe=k.offset-oe)>k.whave&&k.sane){_.msg="invalid distance too far back",k.mode=30;break}ye=oe>k.wnext?(oe-=k.wnext,k.wsize-oe):k.wnext-oe,oe>k.length&&(oe=k.length),Ie=k.window}else Ie=N,ye=L-k.offset,oe=k.length;for(de<oe&&(oe=de),de-=oe,k.length-=oe;N[L++]=Ie[ye++],--oe;);k.length===0&&(k.mode=21);break;case 26:if(de===0)break e;N[L++]=k.length,de--,k.mode=21;break;case 27:if(k.wrap){for(;Y<32;){if(R===0)break e;R--,V|=E[B++]<<Y,Y+=8}if(ne-=de,_.total_out+=ne,k.total+=ne,ne&&(_.adler=k.check=k.flags?r(k.check,N,ne,L-ne):a(k.check,N,ne,L-ne)),ne=de,(k.flags?V:y(V))!==k.check){_.msg="incorrect data check",k.mode=30;break}Y=V=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;Y<32;){if(R===0)break e;R--,V+=E[B++]<<Y,Y+=8}if(V!==(4294967295&k.total)){_.msg="incorrect length check",k.mode=30;break}Y=V=0}k.mode=29;case 29:G=1;break e;case 30:G=-3;break e;case 31:return-4;case 32:default:return f}return _.next_out=L,_.avail_out=de,_.next_in=B,_.avail_in=R,k.hold=V,k.bits=Y,(k.wsize||ne!==_.avail_out&&k.mode<30&&(k.mode<27||j!==4))&&K(_,_.output,_.next_out,ne-_.avail_out)?(k.mode=31,-4):(Z-=_.avail_in,ne-=_.avail_out,_.total_in+=Z,_.total_out+=ne,k.total+=ne,k.wrap&&ne&&(_.adler=k.check=k.flags?r(k.check,N,ne,_.next_out-ne):a(k.check,N,ne,_.next_out-ne)),_.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(Z==0&&ne===0||j===4)&&G===h&&(G=-5),G)},s.inflateEnd=function(_){if(!_||!_.state)return f;var j=_.state;return j.window&&(j.window=null),_.state=null,h},s.inflateGetHeader=function(_,j){var k;return _&&_.state?(2&(k=_.state).wrap)==0?f:((k.head=j).done=!1,h):f},s.inflateSetDictionary=function(_,j){var k,E=j.length;return _&&_.state?(k=_.state).wrap!==0&&k.mode!==11?f:k.mode===11&&a(1,j,E,0)!==k.check?-3:K(_,j,E,E)?(k.mode=31,-4):(k.havedict=1,h):f},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,d,h,f,v,m,b,y){var S,x,w,$,T,C,D,F,W,K=y.bits,_=0,j=0,k=0,E=0,N=0,B=0,L=0,R=0,de=0,V=0,Y=null,Z=0,ne=new o.Buf16(16),oe=new o.Buf16(16),ye=null,Ie=0;for(_=0;_<=15;_++)ne[_]=0;for(j=0;j<f;j++)ne[d[h+j]]++;for(N=K,E=15;1<=E&&ne[E]===0;E--);if(E<N&&(N=E),E===0)return v[m++]=20971520,v[m++]=20971520,y.bits=1,0;for(k=1;k<E&&ne[k]===0;k++);for(N<k&&(N=k),_=R=1;_<=15;_++)if(R<<=1,(R-=ne[_])<0)return-1;if(0<R&&(u===0||E!==1))return-1;for(oe[1]=0,_=1;_<15;_++)oe[_+1]=oe[_]+ne[_];for(j=0;j<f;j++)d[h+j]!==0&&(b[oe[d[h+j]]++]=j);if(C=u===0?(Y=ye=b,19):u===1?(Y=a,Z-=257,ye=r,Ie-=257,256):(Y=l,ye=c,-1),_=k,T=m,L=j=V=0,w=-1,$=(de=1<<(B=N))-1,u===1&&852<de||u===2&&592<de)return 1;for(;;){for(D=_-L,W=b[j]<C?(F=0,b[j]):b[j]>C?(F=ye[Ie+b[j]],Y[Z+b[j]]):(F=96,0),S=1<<_-L,k=x=1<<B;v[T+(V>>L)+(x-=S)]=D<<24|F<<16|W|0,x!==0;);for(S=1<<_-1;V&S;)S>>=1;if(S!==0?(V&=S-1,V+=S):V=0,j++,--ne[_]==0){if(_===E)break;_=d[h+b[j]]}if(N<_&&(V&$)!==w){for(L===0&&(L=N),T+=k,R=1<<(B=_-L);B+L<E&&!((R-=ne[B+L])<=0);)B++,R<<=1;if(de+=1<<B,u===1&&852<de||u===2&&592<de)return 1;v[w=V&$]=N<<24|B<<16|T-m|0}}return V!==0&&(v[T+V]=_-L<<24|64<<16|0),y.bits=N,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),a=0,r=1;function l(M){for(var O=M.length;0<=--O;)M[O]=0}var c=0,u=29,d=256,h=d+1+u,f=30,v=19,m=2*h+1,b=15,y=16,S=7,x=256,w=16,$=17,T=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],F=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],W=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(h+2));l(K);var _=new Array(2*f);l(_);var j=new Array(512);l(j);var k=new Array(256);l(k);var E=new Array(u);l(E);var N,B,L,R=new Array(f);function de(M,O,q,A,z){this.static_tree=M,this.extra_bits=O,this.extra_base=q,this.elems=A,this.max_length=z,this.has_stree=M&&M.length}function V(M,O){this.dyn_tree=M,this.max_code=0,this.stat_desc=O}function Y(M){return M<256?j[M]:j[256+(M>>>7)]}function Z(M,O){M.pending_buf[M.pending++]=255&O,M.pending_buf[M.pending++]=O>>>8&255}function ne(M,O,q){M.bi_valid>y-q?(M.bi_buf|=O<<M.bi_valid&65535,Z(M,M.bi_buf),M.bi_buf=O>>y-M.bi_valid,M.bi_valid+=q-y):(M.bi_buf|=O<<M.bi_valid&65535,M.bi_valid+=q)}function oe(M,O,q){ne(M,q[2*O],q[2*O+1])}function ye(M,O){for(var q=0;q|=1&M,M>>>=1,q<<=1,0<--O;);return q>>>1}function Ie(M,O,q){var A,z,J=new Array(b+1),ie=0;for(A=1;A<=b;A++)J[A]=ie=ie+q[A-1]<<1;for(z=0;z<=O;z++){var se=M[2*z+1];se!==0&&(M[2*z]=ye(J[se]++,se))}}function Ce(M){var O;for(O=0;O<h;O++)M.dyn_ltree[2*O]=0;for(O=0;O<f;O++)M.dyn_dtree[2*O]=0;for(O=0;O<v;O++)M.bl_tree[2*O]=0;M.dyn_ltree[2*x]=1,M.opt_len=M.static_len=0,M.last_lit=M.matches=0}function le(M){8<M.bi_valid?Z(M,M.bi_buf):0<M.bi_valid&&(M.pending_buf[M.pending++]=M.bi_buf),M.bi_buf=0,M.bi_valid=0}function X(M,O,q,A){var z=2*O,J=2*q;return M[z]<M[J]||M[z]===M[J]&&A[O]<=A[q]}function ce(M,O,q){for(var A=M.heap[q],z=q<<1;z<=M.heap_len&&(z<M.heap_len&&X(O,M.heap[z+1],M.heap[z],M.depth)&&z++,!X(O,A,M.heap[z],M.depth));)M.heap[q]=M.heap[z],q=z,z<<=1;M.heap[q]=A}function P(M,O,q){var A,z,J,ie,se=0;if(M.last_lit!==0)for(;A=M.pending_buf[M.d_buf+2*se]<<8|M.pending_buf[M.d_buf+2*se+1],z=M.pending_buf[M.l_buf+se],se++,A===0?oe(M,z,O):(oe(M,(J=k[z])+d+1,O),(ie=C[J])!==0&&ne(M,z-=E[J],ie),oe(M,J=Y(--A),q),(ie=D[J])!==0&&ne(M,A-=R[J],ie)),se<M.last_lit;);oe(M,x,O)}function U(M,O){var q,A,z,J=O.dyn_tree,ie=O.stat_desc.static_tree,se=O.stat_desc.has_stree,me=O.stat_desc.elems,$e=-1;for(M.heap_len=0,M.heap_max=m,q=0;q<me;q++)J[2*q]!==0?(M.heap[++M.heap_len]=$e=q,M.depth[q]=0):J[2*q+1]=0;for(;M.heap_len<2;)J[2*(z=M.heap[++M.heap_len]=$e<2?++$e:0)]=1,M.depth[z]=0,M.opt_len--,se&&(M.static_len-=ie[2*z+1]);for(O.max_code=$e,q=M.heap_len>>1;1<=q;q--)ce(M,J,q);for(z=me;q=M.heap[1],M.heap[1]=M.heap[M.heap_len--],ce(M,J,1),A=M.heap[1],M.heap[--M.heap_max]=q,M.heap[--M.heap_max]=A,J[2*z]=J[2*q]+J[2*A],M.depth[z]=(M.depth[q]>=M.depth[A]?M.depth[q]:M.depth[A])+1,J[2*q+1]=J[2*A+1]=z,M.heap[1]=z++,ce(M,J,1),2<=M.heap_len;);M.heap[--M.heap_max]=M.heap[1],(function(Se,re){var pe,Le,Re,Be,rt,Qe,et=re.dyn_tree,Ft=re.max_code,Gi=re.stat_desc.static_tree,Ys=re.stat_desc.has_stree,Zs=re.stat_desc.extra_bits,es=re.stat_desc.extra_base,Ii=re.stat_desc.max_length,Ki=0;for(Be=0;Be<=b;Be++)Se.bl_count[Be]=0;for(et[2*Se.heap[Se.heap_max]+1]=0,pe=Se.heap_max+1;pe<m;pe++)Ii<(Be=et[2*et[2*(Le=Se.heap[pe])+1]+1]+1)&&(Be=Ii,Ki++),et[2*Le+1]=Be,Ft<Le||(Se.bl_count[Be]++,rt=0,es<=Le&&(rt=Zs[Le-es]),Qe=et[2*Le],Se.opt_len+=Qe*(Be+rt),Ys&&(Se.static_len+=Qe*(Gi[2*Le+1]+rt)));if(Ki!==0){do{for(Be=Ii-1;Se.bl_count[Be]===0;)Be--;Se.bl_count[Be]--,Se.bl_count[Be+1]+=2,Se.bl_count[Ii]--,Ki-=2}while(0<Ki);for(Be=Ii;Be!==0;Be--)for(Le=Se.bl_count[Be];Le!==0;)Ft<(Re=Se.heap[--pe])||(et[2*Re+1]!==Be&&(Se.opt_len+=(Be-et[2*Re+1])*et[2*Re],et[2*Re+1]=Be),Le--)}})(M,O),Ie(J,$e,M.bl_count)}function g(M,O,q){var A,z,J=-1,ie=O[1],se=0,me=7,$e=4;for(ie===0&&(me=138,$e=3),O[2*(q+1)+1]=65535,A=0;A<=q;A++)z=ie,ie=O[2*(A+1)+1],++se<me&&z===ie||(se<$e?M.bl_tree[2*z]+=se:z!==0?(z!==J&&M.bl_tree[2*z]++,M.bl_tree[2*w]++):se<=10?M.bl_tree[2*$]++:M.bl_tree[2*T]++,J=z,$e=(se=0)===ie?(me=138,3):z===ie?(me=6,3):(me=7,4))}function G(M,O,q){var A,z,J=-1,ie=O[1],se=0,me=7,$e=4;for(ie===0&&(me=138,$e=3),A=0;A<=q;A++)if(z=ie,ie=O[2*(A+1)+1],!(++se<me&&z===ie)){if(se<$e)for(;oe(M,z,M.bl_tree),--se!=0;);else z!==0?(z!==J&&(oe(M,z,M.bl_tree),se--),oe(M,w,M.bl_tree),ne(M,se-3,2)):se<=10?(oe(M,$,M.bl_tree),ne(M,se-3,3)):(oe(M,T,M.bl_tree),ne(M,se-11,7));J=z,$e=(se=0)===ie?(me=138,3):z===ie?(me=6,3):(me=7,4)}}l(R);var H=!1;function I(M,O,q,A){ne(M,(c<<1)+(A?1:0),3),(function(z,J,ie,se){le(z),Z(z,ie),Z(z,~ie),o.arraySet(z.pending_buf,z.window,J,ie,z.pending),z.pending+=ie})(M,O,q)}s._tr_init=function(M){H||((function(){var O,q,A,z,J,ie=new Array(b+1);for(z=A=0;z<u-1;z++)for(E[z]=A,O=0;O<1<<C[z];O++)k[A++]=z;for(k[A-1]=z,z=J=0;z<16;z++)for(R[z]=J,O=0;O<1<<D[z];O++)j[J++]=z;for(J>>=7;z<f;z++)for(R[z]=J<<7,O=0;O<1<<D[z]-7;O++)j[256+J++]=z;for(q=0;q<=b;q++)ie[q]=0;for(O=0;O<=143;)K[2*O+1]=8,O++,ie[8]++;for(;O<=255;)K[2*O+1]=9,O++,ie[9]++;for(;O<=279;)K[2*O+1]=7,O++,ie[7]++;for(;O<=287;)K[2*O+1]=8,O++,ie[8]++;for(Ie(K,h+1,ie),O=0;O<f;O++)_[2*O+1]=5,_[2*O]=ye(O,5);N=new de(K,C,d+1,h,b),B=new de(_,D,0,f,b),L=new de(new Array(0),F,0,v,S)})(),H=!0),M.l_desc=new V(M.dyn_ltree,N),M.d_desc=new V(M.dyn_dtree,B),M.bl_desc=new V(M.bl_tree,L),M.bi_buf=0,M.bi_valid=0,Ce(M)},s._tr_stored_block=I,s._tr_flush_block=function(M,O,q,A){var z,J,ie=0;0<M.level?(M.strm.data_type===2&&(M.strm.data_type=(function(se){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&se.dyn_ltree[2*me]!==0)return a;if(se.dyn_ltree[18]!==0||se.dyn_ltree[20]!==0||se.dyn_ltree[26]!==0)return r;for(me=32;me<d;me++)if(se.dyn_ltree[2*me]!==0)return r;return a})(M)),U(M,M.l_desc),U(M,M.d_desc),ie=(function(se){var me;for(g(se,se.dyn_ltree,se.l_desc.max_code),g(se,se.dyn_dtree,se.d_desc.max_code),U(se,se.bl_desc),me=v-1;3<=me&&se.bl_tree[2*W[me]+1]===0;me--);return se.opt_len+=3*(me+1)+5+5+4,me})(M),z=M.opt_len+3+7>>>3,(J=M.static_len+3+7>>>3)<=z&&(z=J)):z=J=q+5,q+4<=z&&O!==-1?I(M,O,q,A):M.strategy===4||J===z?(ne(M,2+(A?1:0),3),P(M,K,_)):(ne(M,4+(A?1:0),3),(function(se,me,$e,Se){var re;for(ne(se,me-257,5),ne(se,$e-1,5),ne(se,Se-4,4),re=0;re<Se;re++)ne(se,se.bl_tree[2*W[re]+1],3);G(se,se.dyn_ltree,me-1),G(se,se.dyn_dtree,$e-1)})(M,M.l_desc.max_code+1,M.d_desc.max_code+1,ie+1),P(M,M.dyn_ltree,M.dyn_dtree)),Ce(M),A&&le(M)},s._tr_tally=function(M,O,q){return M.pending_buf[M.d_buf+2*M.last_lit]=O>>>8&255,M.pending_buf[M.d_buf+2*M.last_lit+1]=255&O,M.pending_buf[M.l_buf+M.last_lit]=255&q,M.last_lit++,O===0?M.dyn_ltree[2*q]++:(M.matches++,O--,M.dyn_ltree[2*(k[q]+d+1)]++,M.dyn_dtree[2*Y(O)]++),M.last_lit===M.lit_bufsize-1},s._tr_align=function(M){ne(M,2,3),oe(M,x,K),(function(O){O.bi_valid===16?(Z(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})(M)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,d,h=1,f={},v=!1,m=a.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(a);b=b&&b.setTimeout?b:a,l={}.toString.call(a.process)==="[object process]"?function(w){process.nextTick(function(){S(w)})}:(function(){if(a.postMessage&&!a.importScripts){var w=!0,$=a.onmessage;return a.onmessage=function(){w=!1},a.postMessage("","*"),a.onmessage=$,w}})()?(d="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",x,!1):a.attachEvent("onmessage",x),function(w){a.postMessage(d+w,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(w){S(w.data)},function(w){u.port2.postMessage(w)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(w){var $=m.createElement("script");$.onreadystatechange=function(){S(w),$.onreadystatechange=null,c.removeChild($),$=null},c.appendChild($)}):function(w){setTimeout(S,0,w)},b.setImmediate=function(w){typeof w!="function"&&(w=new Function(""+w));for(var $=new Array(arguments.length-1),T=0;T<$.length;T++)$[T]=arguments[T+1];var C={callback:w,args:$};return f[h]=C,l(h),h++},b.clearImmediate=y}function y(w){delete f[w]}function S(w){if(v)setTimeout(S,0,w);else{var $=f[w];if($){v=!0;try{(function(T){var C=T.callback,D=T.args;switch(D.length){case 0:C();break;case 1:C(D[0]);break;case 2:C(D[0],D[1]);break;case 3:C(D[0],D[1],D[2]);break;default:C.apply(r,D)}})($)}finally{y(w),v=!1}}}}function x(w){w.source===a&&typeof w.data=="string"&&w.data.indexOf(d)===0&&S(+w.data.slice(d.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ho)),ho.exports}var hg=pg();const ql=fg(hg);function Yl(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Zl(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await cn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function mg(e,t,i){var c,u,d;const n=jw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((u=n==null?void 0:n.pinnedDocId)==null?void 0:u.value)||"");if(s&&o&&i&&i!==o)return;const a=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await Zl(e,a));const l=Yl(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const f of h){const v=f.querySelector(".item__text"),m=((d=v==null?void 0:v.textContent)==null?void 0:d.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){v&&(v.textContent=l),f.setAttribute("title",l);break}}}}function _n(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Wi(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const a=await i.fetchDocumentTitle(n);if(a&&a.trim())return _n(a)}catch{}if(typeof document<"u")try{const a=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return _n(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return _n(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return _n(l)}return"presentation"}function gg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function la(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function vg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function zo(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(l=>l()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});n.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Jl(e,t){const i=[],n=_n((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(f=>f()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(f=>{var v;l(),(v=t==null?void 0:t.onProgress)==null||v.call(t,f.current,f.total,f.pageIndex)});o.push(c);const u=e.onCapturePageDone(f=>{l(),(f.mode==="all"||!f.mode)&&i.push({pageIndex:f.pageIndex,dataUrl:f.dataUrl})});o.push(u);const d=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const f=new ql,v=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of i){const S=String(y.pageIndex).padStart(2,"0"),x=y.dataUrl.split(",")[1];f.file(`slide-${S}.${v}`,x,{base64:!0})}const m=await f.generateAsync({type:"blob",compression:"DEFLATE"}),b=gg(`${n}.zip`,m);s({success:b,total:i.length})}catch(f){s({success:!1,error:(f==null?void 0:f.message)||String(f)})}};o.push(e.onCaptureComplete(d));const h=e.onCaptureError(f=>{r(),s({success:!1,error:f})});o.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Xl(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(a),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await zo(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await Wi(e,e.docId);return await Jl(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const bg=1500,yg=500,kg=4,wg=new Set(["INPUT","TEXTAREA","SELECT"]);function Ql(e){const t=e;return!t||!t.tagName?!1:wg.has(t.tagName)||t.isContentEditable===!0}function xg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){a(),t="",i=!1,o()}function l(){n&&clearTimeout(n),n=setTimeout(r,bg)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,yg)}function u(d){if(e.isEnabled&&!e.isEnabled()||Ql(d.target)||d.isComposing||d.ctrlKey||d.metaKey||d.altKey)return!1;if(/^[0-9]$/.test(d.key))return i||t.length>=kg||(t+=d.key,o(),l()),!0;if(d.key==="Enter"){if(!t||i)return!1;const f=parseInt(t,10),v=e.getTotalPages();return!isNaN(f)&&f>=1&&v>0&&f<=v?(r(),e.onJump(f),!0):(c(),!0)}return d.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Sg={class:"spm-slides-tab__toolbar"},Cg={class:"spm-slides-tab__nav"},_g=["disabled"],$g={class:"spm-page-badge"},Ig=["disabled"],Mg=["aria-label"],Tg=["aria-label"],Eg={class:"spm-slides-tab__tools"},Ag={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Bg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Dg=["src"],Lg=Et({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Qn),s=new jm(n),o=new Cp,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),u=ge(null),d=ge(1),h=ge(1),f=ge(!1),v=ge(!1),m=ge(!1),b=ge("siyuan"),y=ge(""),S=ge(""),x=ge(""),w=ge(!1),$=ge(!1),T=ge(""),C=ge(""),D=ge(!1),F=xg({getTotalPages:()=>h.value,isEnabled:()=>!v.value,onJump:A=>_(A),onStateChange:A=>{C.value=A.display,D.value=A.invalid}});function W(A){if(A.key==="o"||A.key==="O"){if(v.value||A.isComposing||A.ctrlKey||A.metaKey||A.altKey||Ql(A.target))return;A.preventDefault(),K();return}F.handleKeydown(A)&&A.preventDefault()}function K(){var A,z;if(a.value==="pro-cli"){(A=u.value)==null||A.focus(),ue.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(z=u.value)==null||z.focus()}function _(A){var z;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A),(z=u.value)==null||z.focus()}const j=ge("/plugins/siyuan-live-slides/slides-client/index.html");let k=null,E=null,N=null,B=null,L=null,R=null,de=null,V=null;mn(()=>{u.value&&(n.attach(u.value),o.nativeBridge.attach(u.value)),k=n.onSlideChanged((A,z)=>{d.value=A,h.value=z}),E=n.onBlockClicked((A,z)=>{d.value=z,s.setActiveBlockId(A),A||Pn(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(A,z):A&&ji(A,i==null?void 0:i.app)}),N=n.onOpenInEditor((A,z)=>{d.value=z,s.setActiveBlockId(A),ji(A,i==null?void 0:i.app)}),B=o.nativeBridge.onPageChanged((A,z)=>{d.value=A,h.value=z}),L=n.onOpenPeekDrawer(async A=>{const z=qs();if(A.peekType==="siyuan"&&z.enableWebServeJump){let J=!1;if(V&&V.docId===A.target)J=!0;else if(V&&V.slides&&V.slides.some(ie=>{var se;return(se=ie.blocks)==null?void 0:se.some(me=>me.id===A.target)}))J=!1;else try{const ie=await cn(`SELECT id, root_id, type FROM blocks WHERE id = '${A.target}' LIMIT 1`);ie&&ie.length>0&&(J=ie[0].type==="d"||ie[0].id===ie[0].root_id)}catch(ie){console.warn("[SlidesPreviewTab] detect block type failed:",ie)}b.value="web",w.value=!0,S.value=El(z.webServeUrl,A.target,{focus:!J}),x.value=A.title||`${J?"思源文档":"思源块"}: ${A.target.slice(0,8)}`,v.value=!0,n.freezeKeyboardNav(!0)}else{if(b.value=A.peekType,A.peekType==="siyuan")y.value=A.target,x.value=A.title||`块速览: ${A.target.slice(0,8)}`;else{const J=Hl(A.target);if(J.external){ce(A.target);return}w.value=!0,S.value=J.url,x.value=A.title||J.url}v.value=!0,n.freezeKeyboardNav(!0)}}),R=n.onRequestToggleFullscreen(()=>{U()}),de=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",P)}),Us(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",P),L&&L(),R&&R(),de&&de(),k&&k(),E&&E(),N&&N(),B&&B(),n.detach(),F.clear(),s.destroy(),o.destroy()});async function Y(){if(a.value==="web-sandbox"){if(!V){ue.showMessage("请先在主编辑区打开演示文档");return}ue.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const A=await o.startProMode(V,ko);if(!A.success){ue.showMessage(`无法启动官方 Pro 模式：${A.error}`);return}a.value="pro-cli",r.value=A.port||3030,j.value=A.url,u.value&&o.nativeBridge.attach(u.value),ue.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",j.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&n.attach(u.value),ue.showMessage("已切回内置高保真沙箱")}function Z(){$.value=!$.value,$.value?(T.value=(V==null?void 0:V.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",T.value)):(T.value="",Ce(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ne=0;function oe(A){if(v.value||Math.abs(A.deltaY)<Math.abs(A.deltaX)||Math.abs(A.deltaY)<15)return;const z=Date.now();z-ne<280||(ne=z,A.deltaY>0?Ie():ye())}function ye(){if(d.value>1){const A=d.value-1;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A)}}function Ie(){if(d.value<h.value){const A=d.value+1;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A)}}function Ce(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function le(){v.value=!1,n.freezeKeyboardNav(!1)}function X(){le()}function ce(A){var se,me;const z=/^file:/i.test(A),J=z||/^[a-zA-Z]:[\\/]/.test(A),ie=It("electron");if(J&&typeof((se=ie==null?void 0:ie.shell)==null?void 0:se.openPath)=="function"){ie.shell.openPath(z?zl(A):A),ue.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=ie==null?void 0:ie.shell)==null?void 0:me.openExternal)=="function"?ie.shell.openExternal(A).catch(()=>{typeof window<"u"&&window.open(A,"_blank")}):typeof window<"u"&&window.open(A,"_blank"),ue.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function P(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function U(){const A=l.value||u.value;A&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):A.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function G(){if(!V){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const A=Vl(V);Gl("presentation.html",A)&&ue.showMessage("已开始下载单文件离线 HTML 演示包")}function H(){if(!V){ue.showMessage("请先在主编辑区打开幻灯片文档");return}Kl(V)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const I=ge(!1);async function M(){if(I.value){ue.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!V){ue.showMessage("请先在主编辑区打开幻灯片文档");return}I.value=!0;try{ue.showMessage("正在逐页导出幻灯片图片...",2e3);const A=await Wi(V,i==null?void 0:i.currentDocId,i),z=await Jl(n,{title:A,onProgress:(J,ie)=>{ue.showMessage(`正在导出幻灯片图片 (${J} / ${ie})...`,1500)}});z.success?ue.showMessage(`🎉 成功导出 ${z.total||0} 张高清图片并保存为 ${A}.zip！`,4e3):ue.showMessage(`导出图片失败：${z.error||"未知异常"}`)}finally{I.value=!1}}async function O(){if(!V){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在导出当前幻灯片图片...",1500);const A=await zo(n);if(A.success&&A.dataUrl){const z=await Wi(V,i==null?void 0:i.currentDocId,i),J=d.value||1,se=(h.value||1)>1?`${z}-${J}.png`:`${z}.png`;la(se,A.dataUrl),ue.showMessage(`已下载当前页高清图片 (${se})`)}else ue.showMessage(`导出当前页图片失败：${A.error||"未知异常"}`)}async function q(){if(!V){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const A=await zo(n);if(A.success&&A.dataUrl)if(await vg(A.dataUrl))ue.showMessage(`已成功将第 ${d.value||1} 页幻灯片复制到剪贴板！`);else{const J=await Wi(V,i==null?void 0:i.currentDocId,i),ie=d.value||1,me=(h.value||1)>1?`${J}-${ie}.png`:`${J}.png`;la(me,A.dataUrl),ue.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else ue.showMessage(`复制失败：${A.error||"未知异常"}`)}return t({updateDocument(A,z){$.value&&T.value&&z&&z!==T.value||(V=A,$.value&&!T.value&&(T.value=A.docId),h.value=A.slides.length,s.setDocId(A.docId),s.updateSlidesIndex(A.slides),a.value==="pro-cli"?o.scaffolder.scaffold(A,ko).catch(()=>{}):n.updateSlides(A.slides,A.config,A.fullMarkdown,A.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.docId))},navigateToBlock(A){s.onCursorFocusBlock(A)},isPinned:$,pinnedDocId:T,engineMode:a,toggleEngineMode:Y}),(A,z)=>(Q(),te("div",{class:"spm-slides-preview-tab",onKeydown:W},[p("div",Sg,[p("div",Cg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value<=1,"aria-label":"上一页",onClick:ye},[ae(fe,{name:"chevron-left"})],8,_g),p("span",$g,xe(d.value)+" / "+xe(h.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value>=h.value,"aria-label":"下一页",onClick:Ie},[ae(fe,{name:"chevron-right"})],8,Ig),p("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":$.value}]),"aria-label":$.value?"已锁定当前文档（点击解除）："+T.value:"点击锁定当前文档（不随主编辑区切换）",onClick:Z},[ae(fe,{name:"pin"}),p("span",null,xe($.value?"已锁定":"跟随"),1)],10,Mg),he(_t)("proMode")?(Q(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[ae(fe,{name:"rocket"}),p("span",null,xe(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Tg)):Te("",!0)]),p("div",Eg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[ae(fe,{name:"columns"})]),he(_t)("presenterMode")?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[ae(fe,{name:"presenter"})])):Te("",!0),he(_t)("exportHtml")?(Q(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:G},[ae(fe,{name:"export-html"})])):Te("",!0),he(_t)("exportPdf")?(Q(),te("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:H},[ae(fe,{name:"export-pdf"})])):Te("",!0),he(_t)("exportImage")?(Q(),te("div",Ag,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:M},[ae(fe,{name:"export-image"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:z[0]||(z[0]=Yt(J=>f.value=!f.value,["stop"]))},[ae(fe,{name:"chevron-down"})]),f.value?(Q(),te("div",Bg,[p("button",{class:"b3-menu__item",onClick:z[1]||(z[1]=J=>{M(),f.value=!1})},[...z[6]||(z[6]=[p("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),p("button",{class:"b3-menu__item",onClick:z[2]||(z[2]=J=>{O(),f.value=!1})},[...z[7]||(z[7]=[p("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),p("button",{class:"b3-menu__item",onClick:z[3]||(z[3]=J=>{q(),f.value=!1})},[...z[8]||(z[8]=[p("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Ce},[ae(fe,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:U},[ae(fe,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:oe},[p("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:j.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Dg),ae(em,{visible:v.value,"onUpdate:visible":z[4]||(z[4]=J=>v.value=J),"is-maximized":m.value,"onUpdate:isMaximized":z[5]||(z[5]=J=>m.value=J),title:x.value,onClose:le},{default:Qa(()=>[b.value==="siyuan"&&y.value?(Q(),Zt(cm,{key:0,"block-id":y.value,title:x.value,plugin:he(i),onExternalJump:X},null,8,["block-id","title","plugin"])):Te("",!0),w.value?Lt((Q(),Zt(Hm,{key:1,visible:v.value&&b.value==="web",url:S.value,title:x.value,onExternalJump:X},null,8,["visible","url","title"])),[[Do,b.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Lt(p("div",{class:_e(["spm-jump-badge",{"is-invalid":D.value}])},xe(C.value),3),[[Do,C.value]])],544)],32))}}),Pg=ei(Lg,[["__scopeId","data-v-527d6ffd"]]);function ec(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const d=String(r.parentClicks).trim();if(/^\d+$/.test(d)){const h=parseInt(d,10);s=Math.max(s,h),n.set(r.parentContainerId,h)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const d=n.get(r.parentContainerId);o(r,{type:"step",step:d})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const d=JSON.parse(c);if(Array.isArray(d)&&d.length>=2){const h=Math.min(Number(d[0]),Number(d[1])),f=Math.max(Number(d[0]),Number(d[1]));if(!isNaN(h)&&!isNaN(f)){s=Math.max(s,f),o(r,{type:"range",min:h,max:f});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const d=c==="true"?1:parseInt(c.slice(1),10)||1;s+=d,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const d=parseInt(c.slice(1),10)||1;s=Math.max(1,s-d),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const d=parseInt(c,10);if(!isNaN(d)){s=Math.max(s,d),o(r,{type:"step",step:d});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(s=Math.max(s,u),o(r,{type:"step",step:u})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Og(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ho=980;function Rg(e){if(!e)return 0;const i=ec(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=fd(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Ng(e,t=Ho){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(n=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function ca(e,t,i=Ho,n=552,s=16){const o=i>0?i:Ho,a=n>0?n:552,r=Math.max(0,e-s),l=Math.max(0,t-s);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function zg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function da(e,t){if(!e)return"";const i=zg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?ec(i.blocks||[]):null,u=Ul(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?x=>{if(Og(x,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const $=x.id||x.blockId,T=l.blockMap.get(x)||($?l.idMap.get($):void 0);if((T==null?void 0:T.type)==="step"&&T.step===r||(T==null?void 0:T.type)==="range"&&T.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(x,w)=>{let $=w.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test($)||($+=" muted"),`<video ${$.trim()}>`}),d=n.spacing,h=d&&d!=="inherit"?d:o.spacing||"normal",f=["slide-content",`layout-${s}`,`spacing-${h}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),v=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const x=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;v.push(`background-image:url('${st(x)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else v.push(`background:${st(m)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&v.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const S=v.length>0?` style="${v.join("")}"`:"";return`<div class="${st(f)}"${S}>${u}</div>`}const Hg={class:"presenter-header"},Fg={class:"presenter-title-area"},jg={class:"presenter-brand"},Wg={class:"header-pills"},Ug={class:"pill pill-page"},Vg={key:0,class:"pill pill-step"},Gg={class:"header-toolbar"},Kg={class:"timer-capsule"},qg={class:"timer-digits"},Yg={class:"timer-actions"},Zg=["aria-label"],Jg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Xg={key:0,class:"presenter-grid"},Qg={class:"slide-panels"},ev={class:"panel-box current-slide-panel"},tv={class:"panel-header"},iv={class:"panel-header-left"},nv={class:"panel-page-num"},sv={class:"panel-header-meta"},ov={key:0,class:"panel-step-pill"},rv={class:"panel-layout-pill"},av=["aria-label"],lv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],cv={key:1,class:"panel-fallback"},dv=["aria-label"],uv={class:"panel-header"},fv={class:"panel-header-left"},pv={key:0,class:"panel-page-num"},hv={class:"panel-header-meta"},mv={key:0,class:"panel-end-pill"},gv={key:1,class:"panel-layout-pill"},vv=["aria-label"],bv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],yv={key:1,class:"panel-fallback"},kv={class:"notes-panel"},wv={class:"panel-header"},xv={class:"panel-header-left"},Sv={class:"notes-size-controls"},Cv=["disabled"],_v={class:"notes-size-value"},$v=["disabled"],Iv={key:1,class:"presenter-empty"},Mv={class:"empty-icon-wrap"},Tv={class:"empty-actions"},Ev={class:"presenter-actions"},Av={class:"nav-btn-group"},Bv=["disabled"],Dv=["disabled"],Lv={class:"actions-center"},Pv={class:"center-meta"},Ov={class:"progress-pill"},Rv={class:"nav-btn-group"},Nv=["aria-label"],zv={class:"step-dots-text"},Hv=["disabled"],Fv=["disabled"],jv=280,Wv=15,Uv=Et({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Qn),s=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),u=be(()=>s.value.length||l.value),d=ge(null),h=ge(null),f=ge({width:0,height:0}),v=ge({width:0,height:0}),m=be(()=>{var re;return Ng((re=o.value)==null?void 0:re.aspectRatio)}),b=be(()=>{var re;return((re=o.value)==null?void 0:re.theme)||"default"}),y=be(()=>{var re;return((re=o.value)==null?void 0:re.colorSchema)==="light"?"light":"dark"}),S=be(()=>{var re;return!!((re=o.value)!=null&&re.normalizeHeadingSizes)}),x=be(()=>{var re;return((re=o.value)==null?void 0:re.showUnorderedListMarkers)===!1}),w=be(()=>{var re;return((re=o.value)==null?void 0:re.showOrderedListMarkers)===!1}),$=be(()=>ca(f.value.width,f.value.height,m.value.baseWidth,m.value.baseHeight,14)),T=be(()=>ca(v.value.width,v.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){d.value&&(f.value={width:d.value.clientWidth,height:d.value.clientHeight}),h.value&&(v.value={width:h.value.clientWidth,height:h.value.clientHeight})}let D=null;function F(){typeof window>"u"||typeof window.ResizeObserver!="function"||(D||(D=new window.ResizeObserver(()=>{C()})),D.disconnect(),d.value&&D.observe(d.value),h.value&&D.observe(h.value))}Fi([d,h,u],()=>{Is(()=>{F(),C()})},{flush:"post"});const W=ge(0),K=ge(!0);let _=null;const j=be(()=>{const re=String(Math.floor(W.value/60)).padStart(2,"0"),pe=String(W.value%60).padStart(2,"0");return`${re}:${pe}`});function k(){K.value=!K.value}function E(){W.value=0}const N=ge("");let B=null;function L(){const re=new Date,pe=String(re.getHours()).padStart(2,"0"),Le=String(re.getMinutes()).padStart(2,"0");N.value=`${pe}:${Le}`}const R=be(()=>s.value.length===0?null:s.value[a.value-1]||null),de=be(()=>a.value>=s.value.length?null:s.value[a.value]||null),V=be(()=>R.value?Rg(R.value):c.value),Y=be(()=>a.value>1||r.value>0),Z=be(()=>a.value<u.value||r.value<V.value),ne=be(()=>da(R.value,{config:o.value,allSlides:s.value,pageIndex:a.value,currentStep:r.value})),oe=be(()=>da(de.value,{config:o.value,allSlides:s.value,pageIndex:a.value+1})),ye=be(()=>{var pe;if(!R.value)return"无内容";const re=(pe=R.value.blocks)==null?void 0:pe[0];return(re==null?void 0:re.content)||(re==null?void 0:re.rawMarkdown)||`第 ${a.value} 页`});function Ie(re){return(re||[]).slice(1).map(pe=>(pe.content||pe.rawMarkdown||"").trim()).filter(pe=>pe&&!/^(image\s+)?assets\/\S*$/i.test(pe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(pe)).join(" | ").slice(0,120)}const Ce=be(()=>{var re;return Ie((re=R.value)==null?void 0:re.blocks)}),le=be(()=>{var pe;if(!de.value)return"演示结束";const re=(pe=de.value.blocks)==null?void 0:pe[0];return(re==null?void 0:re.content)||(re==null?void 0:re.rawMarkdown)||`第 ${a.value+1} 页`}),X=be(()=>de.value?Ie(de.value.blocks):"这是最后一页"),ce=be(()=>{var re;return((re=R.value)==null?void 0:re.notes)||""}),P=ge(20);function U(){P.value<36&&(P.value+=2)}function g(){P.value>14&&(P.value-=2)}const G=be(()=>u.value<=1?100:Math.round(a.value/u.value*100));let H=null;try{H=new BroadcastChannel("siyuan-slides-sync"),H.onmessage=re=>{const pe=re.data;if(pe&&(pe.type==="SYNC_PAGE"&&typeof pe.page=="number"&&(a.value=pe.page,r.value=typeof pe.step=="number"?Math.max(0,pe.step):0,typeof pe.maxStep=="number"&&(c.value=Math.max(0,pe.maxStep))),pe.type==="SYNC_SLIDES"&&Array.isArray(pe.slides)&&(s.value=pe.slides,pe.config&&typeof pe.config=="object"&&(o.value=pe.config)),pe.type==="REQUEST_SYNC"&&s.value.length>0))try{H==null||H.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),H==null||H.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:V.value})}catch{}}}catch{H=null}function I(re,pe=0){const Le=Number(re)||1,Re=Math.max(0,Number(pe)||0);n.navigatePage(Le,Re);try{H==null||H.postMessage({type:"SYNC_PAGE",page:Le,step:Re,maxStep:V.value})}catch{}}function M(){if(r.value<V.value){r.value++,I(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,I(a.value,0))}function O(){if(r.value>0){r.value--,I(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,I(a.value,0))}function q(){a.value<u.value&&(a.value++,r.value=0,I(a.value,0))}function A(){a.value>1&&(a.value--,r.value=0,I(a.value,0))}function z(){a.value=1,r.value=0,E(),I(1,0)}function J(){const re=i;typeof(re==null?void 0:re.openBottomPreviewTab)=="function"&&re.openBottomPreviewTab()}function ie(){const re=i;typeof(re==null?void 0:re.openStandalonePreviewWindow)=="function"&&re.openStandalonePreviewWindow()}function se(re){var pe,Le;if(!(re.key===" "&&((Le=(pe=re.target)==null?void 0:pe.closest)!=null&&Le.call(pe,"button")))){if(re.shiftKey&&re.key==="ArrowRight"||re.key==="ArrowDown"){re.preventDefault(),q();return}if(re.shiftKey&&re.key==="ArrowLeft"||re.key==="ArrowUp"){re.preventDefault(),A();return}re.key==="ArrowRight"||re.key===" "||re.key==="PageDown"?(re.preventDefault(),M()):(re.key==="ArrowLeft"||re.key==="PageUp")&&(re.preventDefault(),O())}}let me=0;function $e(re){var Re,Be;if(Math.abs(re.deltaY)<Wv)return;const pe=(Be=(Re=re.target)==null?void 0:Re.closest)==null?void 0:Be.call(Re,".notes-content");if(pe){const rt=pe.scrollHeight-pe.clientHeight;if(rt>2&&(re.deltaY>0&&pe.scrollTop<rt-1||re.deltaY<0&&pe.scrollTop>1))return}const Le=Date.now();Le-me<jv||(me=Le,re.deltaY>0?M():O())}let Se=null;return mn(()=>{var pe;_=window.setInterval(()=>{K.value&&W.value++},1e3),L(),B=window.setInterval(L,1e3),Se=n.onSlideChanged((Le,Re,Be,rt,Qe)=>{a.value=Le,Re>0&&(l.value=Re),typeof rt=="number"&&(r.value=Math.max(0,rt)),typeof Qe=="number"&&(c.value=Math.max(0,Qe))});try{H==null||H.postMessage({type:"REQUEST_SYNC"})}catch{}const re=i==null?void 0:i.latestCompiledDoc;(pe=re==null?void 0:re.slides)!=null&&pe.length&&(s.value=re.slides,re.config&&(o.value=re.config)),typeof window<"u"&&window.addEventListener("resize",C),Is(()=>{F(),C()})}),Us(()=>{_&&(window.clearInterval(_),_=null),B&&(window.clearInterval(B),B=null),Se&&Se(),typeof window<"u"&&window.removeEventListener("resize",C),D&&(D.disconnect(),D=null);try{H==null||H.close()}catch{}H=null}),t({updateDocument(re){var pe;(pe=re==null?void 0:re.slides)!=null&&pe.length&&(s.value=re.slides),re!=null&&re.config&&(o.value=re.config)}}),(re,pe)=>{var Le,Re,Be;return Q(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:se,onWheel:$e},[p("header",Hg,[p("div",Fg,[p("div",jg,[ae(fe,{name:"presenter",class:"brand-icon"}),pe[1]||(pe[1]=p("span",{class:"title-name"},"演讲者控制台",-1))]),p("div",Wg,[p("span",Ug,"P."+xe(a.value)+" / "+xe(u.value||1),1),V.value>0?(Q(),te("span",Vg,[ae(fe,{name:"step",class:"pill-icon"}),Ct(" 步进 "+xe(r.value)+" / "+xe(V.value),1)])):Te("",!0)])]),p("div",Gg,[p("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:ie},[ae(fe,{name:"window"}),pe[2]||(pe[2]=p("span",{class:"btn-tool-label"},"独立放映",-1))]),p("div",Kg,[ae(fe,{name:"clock",class:"timer-icon"}),p("span",qg,xe(j.value),1),p("div",Yg,[p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":K.value?"暂停计时":"继续计时",onClick:k},[ae(fe,{name:K.value?"pause":"play"},null,8,["name"])],8,Zg),p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:E},[ae(fe,{name:"reset"})])])]),p("div",Jg,[p("span",null,xe(N.value),1)])])]),u.value>0?(Q(),te("main",Xg,[p("section",Qg,[p("div",ev,[p("div",tv,[p("div",iv,[pe[3]||(pe[3]=p("span",{class:"panel-tag is-current"},"当前放映",-1)),p("span",nv,"P."+xe(a.value),1)]),p("div",sv,[V.value>0?(Q(),te("span",ov," 步进 "+xe(r.value)+" / "+xe(V.value),1)):Te("",!0),p("span",rv,xe(((Re=(Le=R.value)==null?void 0:Le.frontmatter)==null?void 0:Re.layout)||"default"),1)])]),p("div",{ref_key:"currentPreviewRef",ref:d,class:"panel-preview","aria-label":ye.value},[R.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:qt({width:$.value.boxWidth+"px",height:$.value.boxHeight+"px"})},[p("div",{class:_e(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":S.value?"true":"false","data-hide-unordered-markers":x.value?"true":"false","data-hide-ordered-markers":w.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+$.value.scale+")"}),innerHTML:ne.value},null,14,lv)],4)):(Q(),te("div",cv,[p("h2",null,xe(ye.value),1),p("p",null,xe(Ce.value),1)]))],8,av)]),p("div",{class:_e(["panel-box next-slide-panel",{"is-clickable":!!de.value,"b3-tooltips b3-tooltips__n":!!de.value}]),"aria-label":de.value?"点击直接跳至下一页":"",onClick:pe[0]||(pe[0]=rt=>de.value&&q())},[p("div",uv,[p("div",fv,[pe[4]||(pe[4]=p("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(Q(),te("span",pv,"P."+xe(a.value+1),1)):Te("",!0)]),p("div",hv,[a.value>=u.value?(Q(),te("span",mv,"已到尾页")):de.value?(Q(),te("span",gv,xe(((Be=de.value.frontmatter)==null?void 0:Be.layout)||"default"),1)):Te("",!0)])]),p("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":le.value},[de.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:qt({width:T.value.boxWidth+"px",height:T.value.boxHeight+"px"})},[p("div",{class:_e(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":S.value?"true":"false","data-hide-unordered-markers":x.value?"true":"false","data-hide-ordered-markers":w.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+T.value.scale+")"}),innerHTML:oe.value},null,14,bv)],4)):(Q(),te("div",yv,[p("h2",null,xe(le.value),1),p("p",null,xe(X.value),1)]))],8,vv)],10,dv)]),p("section",kv,[p("div",wv,[p("div",xv,[ae(fe,{name:"notes",class:"panel-title-icon"}),pe[5]||(pe[5]=p("span",null,"讲稿备忘",-1))]),p("div",Sv,[p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:P.value<=14,onClick:g},[ae(fe,{name:"minus"})],8,Cv),p("span",_v,xe(P.value)+"px",1),p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:P.value>=36,onClick:U},[ae(fe,{name:"plus"})],8,$v)])]),p("div",{class:_e(["notes-content",{"is-empty":!ce.value}]),style:qt({fontSize:P.value+"px"})},xe(ce.value||"（本页未设置演讲者备忘录）"),7)])])):(Q(),te("main",Iv,[p("div",Mv,[ae(fe,{name:"refresh",class:"empty-icon"})]),pe[8]||(pe[8]=p("h2",null,"等待大屏放映数据",-1)),pe[9]||(pe[9]=p("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),p("div",Tv,[p("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:J},[ae(fe,{name:"presenter"}),pe[6]||(pe[6]=p("span",null,"打开大屏放映页签",-1))]),p("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:ie},[ae(fe,{name:"window"}),pe[7]||(pe[7]=p("span",null,"弹出独立放映窗口",-1))])])])),p("footer",Ev,[p("div",Av,[p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:A},[ae(fe,{name:"chevrons-left"}),pe[10]||(pe[10]=p("span",null,"上一页",-1))],8,Bv),p("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Y.value,"aria-label":"回退一步 (←)",onClick:O},[ae(fe,{name:"chevron-left"}),pe[11]||(pe[11]=p("span",null,"上一步",-1))],8,Dv)]),p("div",Lv,[p("div",Pv,[p("span",Ov,xe(G.value)+"%",1)]),p("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:z},[ae(fe,{name:"reset"}),pe[12]||(pe[12]=p("span",null,"重头放映",-1))])]),p("div",Rv,[V.value>0?(Q(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${V.value}`},[(Q(!0),te(qe,null,wt(V.value,rt=>(Q(),te("span",{key:rt,class:_e(["step-dot",{"is-active":rt<=r.value}])},null,2))),128)),p("span",zv,xe(r.value)+"/"+xe(V.value),1)],8,Nv)):Te("",!0),p("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!Z.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:M},[pe[13]||(pe[13]=p("span",null,"下一步",-1)),ae(fe,{name:"chevron-right"})],8,Hv),p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:q},[pe[14]||(pe[14]=p("span",null,"下一页",-1)),ae(fe,{name:"chevrons-right"})],8,Fv)])])],32)}}}),Vv=ei(Uv,[["__scopeId","data-v-451e119e"]]),Gv={class:"spm-layout-picker"},Kv={class:"spm-layout-picker__grid"},qv=["title","onClick"],Yv={class:"spm-layout-icon"},Zv={class:"spm-layout-label"},Jv=Et({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){n("update:modelValue",r),n("change",r)}return(r,l)=>(Q(),te("div",Gv,[l[0]||(l[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",Kv,[(Q(),te(qe,null,wt(s,c=>p("div",{key:c.name,class:_e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[p("div",Yv,[ae(fe,{name:"layout-"+c.name},null,8,["name"])]),p("span",Zv,xe(c.label),1)],10,qv)),64))])]))}}),Xv=ei(Jv,[["__scopeId","data-v-96c8a248"]]),Qv={key:0,class:"spm-transition-selector__header"},eb={class:"spm-transition-list"},tb=["onClick"],ib={class:"spm-transition-meta"},nb={class:"spm-transition-label"},sb={class:"spm-transition-name"},ob={class:"spm-transition-preview-box"},rb=Et({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(Q(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(Q(),te("div",Qv,xe(e.title||"转场动效"),1)),p("div",eb,[(Q(),te(qe,null,wt(n,r=>p("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>s(r.name)},[p("div",ib,[p("span",nb,xe(r.label),1),p("span",sb,"("+xe(r.name)+")",1)]),p("div",ob,[p("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,tb)),64))])],2))}}),tc=ei(rb,[["__scopeId","data-v-8597e99e"]]),ab={class:"spm-section spm-section--page"},lb={class:"spm-section-header"},cb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},db={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},ub={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},fb={key:1,class:"spm-card-control"},pb={class:"spm-control-header"},hb={class:"spm-control-title-group"},mb={class:"spm-control-title"},gb={class:"spm-quick-chips"},vb=["onClick"],bb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},yb=["value"],kb=["aria-label"],wb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},xb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Sb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Cb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},_b={class:"spm-card-control"},$b={class:"spm-control-header"},Ib={class:"spm-control-title-group"},Mb={class:"spm-control-title"},Tb={class:"spm-segmented-group"},Eb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Ab={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Bb=["aria-label"],Db={class:"spm-quick-chips"},Lb=["onClick"],Pb=["value"],Ob={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Rb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Nb={style:{flex:"1"}},zb={class:"spm-segmented-group"},Hb={style:{flex:"1"}},Fb={class:"spm-segmented-group"},jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Gb={class:"spm-segmented-group"},Kb={class:"spm-card-control"},qb={class:"spm-control-header"},Yb={class:"spm-control-title-group"},Zb={class:"spm-control-title"},Jb={class:"spm-quick-chips"},Xb=["onClick"],Qb=["value"],e1={key:2,class:"spm-card-control"},t1={class:"spm-control-header"},i1={class:"spm-control-title-group"},n1={class:"spm-control-title"},s1={class:"spm-quick-chips"},o1=["onClick"],r1=["value"],a1={class:"spm-card-control"},l1={class:"spm-control-header"},c1={class:"spm-control-title-group"},d1={class:"spm-control-title"},u1={key:0,class:"spm-note-status-box"},f1=["title"],p1={class:"spm-action-grid",style:{"margin-top":"6px"}},h1={key:1,class:"spm-note-empty-box"},m1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},g1={class:"spm-action-grid"},v1=["disabled"],b1=["disabled"],y1={class:"spm-card-control"},k1={class:"spm-action-grid"},w1=Et({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=be(()=>{const x=i.pageMask;return x==="clockwise"||x==="counter-clockwise"||x==="cw"||x==="ccw"}),a=be(()=>o.value?"1:1:1:1":"1:1"),r=be(()=>i.pageMaskRatio||a.value);function l(x){n("update:pageMask",x),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(x){n("update:pageMask",x),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const u=be(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),d=be(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),h=be(()=>{var $,T;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const x=(i.pageLayoutRatio||"").trim();if(x.includes(":")){const C=x.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}const w=(i.detectedSbRatio||"").trim();if(w.includes(":")){const C=w.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}if(($=i.detectedSbInfo)!=null&&$.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((T=i.detectedSbInfo)!=null&&T.slots&&Array.isArray(i.detectedSbInfo.slots)){const C=i.detectedSbInfo.slots.length;if(C>=2&&C<=6)return C}return 2}),f=be(()=>{const x=h.value;return x===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:x===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:x===5?[{label:"默认 1:1:1:1:1",value:""}]:x===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),v=be(()=>i.pageLayoutRatio||"");function m(){const x=h.value||2,w=Array(x).fill("1").join(":");n("update:pageLayoutRatio",w),n("resetSuperblockRatio")}const b=be(()=>{if(!i.pageNotes)return"";const x=i.pageNotes.replace(/[\r\n]+/g," ").trim();return x.length>50?x.slice(0,50)+"...":x}),y=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],S=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(x,w)=>(Q(),te("div",ab,[p("div",lb,[p("span",null,"幻灯片页面设置"+xe(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),ae(Xv,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=$=>x.$emit("update:pageLayout",$))},null,8,["model-value"]),!d.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(Q(),te("div",cb,[p("div",db,[p("div",ub,[ae(fe,{name:"sparkles"}),p("span",null,[w[33]||(w[33]=Ct("检测到本页横向超级块列宽比例：",-1)),p("b",null,xe(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=$=>x.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[ae(fe,{name:"columns"}),w[34]||(w[34]=p("span",null,"设为分栏",-1))])])])):Te("",!0),d.value?(Q(),te("div",fb,[p("div",pb,[p("div",hb,[p("div",mb,[ae(fe,{name:"ratio"}),w[35]||(w[35]=p("span",null,"分栏比例 (Ratio)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",gb,[(Q(!0),te(qe,null,wt(f.value,$=>(Q(),te("button",{key:$.value,class:_e(["spm-chip",{active:v.value===$.value}]),onClick:T=>x.$emit("update:pageLayoutRatio",$.value)},xe($.label),11,vb))),128))]),p("div",bb,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=$=>x.$emit("update:pageLayoutRatio",$.target.value)),onChange:w[3]||(w[3]=$=>x.$emit("update:pageLayoutRatio",$.target.value))},null,40,yb),e.detectedSbRatio?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=$=>x.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[ae(fe,{name:"sparkles"}),w[37]||(w[37]=p("span",null,"读取",-1))],8,kb)):(Q(),te("button",wb,[ae(fe,{name:"sparkles"}),w[38]||(w[38]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[ae(fe,{name:"reset"}),w[39]||(w[39]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(Q(),te("div",xb,[ae(fe,{name:"ratio"}),w[40]||(w[40]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",Sb,xe(e.detectedSbRatio),1)])):(Q(),te("div",Cb,[ae(fe,{name:"ratio"}),w[41]||(w[41]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),ae(tc,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=$=>x.$emit("update:pageTransition",$))},null,8,["model-value"]),p("div",_b,[p("div",$b,[p("div",Ib,[p("div",Mb,[ae(fe,{name:"sparkles"}),w[42]||(w[42]=p("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),w[43]||(w[43]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",Tb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=$=>x.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=$=>c("down"))}," 从上至下 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=$=>c("right"))}," 从左至右 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=$=>l("clockwise"))}," 顺时针 ↻ ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=$=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(Q(),te("div",Eb,[p("div",Ab,[w[45]||(w[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[ae(fe,{name:"help"}),w[44]||(w[44]=p("span",null,"输入规则",-1))],8,Bb)]),p("div",Db,[(Q(),te(qe,null,wt(s,$=>p("button",{key:$.value,class:_e(["spm-chip",{active:r.value===$.value}]),onClick:T=>x.$emit("update:pageMaskRatio",$.value)},xe($.label),11,Lb)),64))]),p("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=$=>x.$emit("update:pageMaskRatio",$.target.value)),onChange:w[12]||(w[12]=$=>x.$emit("update:pageMaskRatio",$.target.value))},null,40,Pb),p("div",Ob,xe(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),p("div",Rb,[p("div",Nb,[w[46]||(w[46]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",zb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=$=>x.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=$=>x.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",Hb,[w[47]||(w[47]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",Fb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=$=>x.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=$=>x.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),p("div",jb,[p("div",Wb,[p("div",Ub,[p("div",Vb,[ae(fe,{name:"ratio"}),w[48]||(w[48]=p("span",null,"页面间距 (Spacing)",-1))]),w[49]||(w[49]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",Gb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=$=>x.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:w[18]||(w[18]=$=>x.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:w[19]||(w[19]=$=>x.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:w[20]||(w[20]=$=>x.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Kb,[p("div",qb,[p("div",Yb,[p("div",Zb,[ae(fe,{name:"palette"}),w[50]||(w[50]=p("span",null,"页面背景 (Background)",-1))]),w[51]||(w[51]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",Jb,[(Q(),te(qe,null,wt(y,$=>p("button",{key:$.value,class:_e(["spm-chip",{active:e.pageBackground===$.value}]),onClick:T=>x.$emit("update:pageBackground",$.value)},xe($.label),11,Xb)),64))]),p("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:w[21]||(w[21]=$=>x.$emit("update:pageBackground",$.target.value)),onChange:w[22]||(w[22]=$=>x.$emit("update:pageBackground",$.target.value))},null,40,Qb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(Q(),te("div",e1,[p("div",t1,[p("div",i1,[p("div",n1,[ae(fe,{name:"image"}),w[52]||(w[52]=p("span",null,"页面图片 (Image)",-1))]),w[53]||(w[53]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",s1,[(Q(),te(qe,null,wt(S,$=>p("button",{key:$.value,class:_e(["spm-chip",{active:e.pageImage===$.value}]),onClick:T=>x.$emit("update:pageImage",$.value)},xe($.label),11,o1)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:w[23]||(w[23]=$=>x.$emit("update:pageImage",$.target.value)),onChange:w[24]||(w[24]=$=>x.$emit("update:pageImage",$.target.value))},null,40,r1)])):Te("",!0),p("div",a1,[p("div",l1,[p("div",c1,[p("div",d1,[ae(fe,{name:"presenter"}),w[54]||(w[54]=p("span",null,"演讲者提词 (Notes)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(_t)("aiScript")?(Q(),te("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[25]||(w[25]=$=>x.$emit("generateNotes"))},[ae(fe,{name:"sparkles"}),w[56]||(w[56]=p("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(Q(),te("div",u1,[w[59]||(w[59]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},xe(b.value),9,f1),p("div",p1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[26]||(w[26]=$=>x.$emit("locateNoteBlock"))},[ae(fe,{name:"search"}),w[57]||(w[57]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[27]||(w[27]=$=>x.$emit("addNoteBlock"))},[ae(fe,{name:"insert-below"}),w[58]||(w[58]=p("span",null,"追加讲稿块",-1))])])])):(Q(),te("div",h1,[w[61]||(w[61]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[28]||(w[28]=$=>x.$emit("addNoteBlock"))},[ae(fe,{name:"insert-below"}),w[60]||(w[60]=p("span",null,"添加讲稿备注块",-1))])])),p("div",m1,[p("div",g1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:w[29]||(w[29]=$=>x.$emit("batchAppendNotes"))},[ae(fe,{name:"insert-below"}),w[62]||(w[62]=p("span",null,"全部追加",-1))],12,v1),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:w[30]||(w[30]=$=>x.$emit("batchDeleteNotes"))},[ae(fe,{name:"trash"}),w[63]||(w[63]=p("span",null,"全部删除",-1))],12,b1)])])]),p("div",y1,[w[66]||(w[66]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",k1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[31]||(w[31]=$=>x.$emit("insertDividerAfter"))},[ae(fe,{name:"insert-below"}),w[64]||(w[64]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[32]||(w[32]=$=>x.$emit("deleteDivider"))},[ae(fe,{name:"trash"}),w[65]||(w[65]=p("span",null,"删除此页",-1))])])])]))}}),x1=ei(w1,[["__scopeId","data-v-87c0bbc3"]]),S1={class:"spm-section spm-section--block"},C1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},_1={class:"spm-control-header"},$1={class:"spm-control-title-group"},I1={class:"spm-control-title"},M1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},T1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},E1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},A1={key:0},B1={key:1},D1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},L1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},P1={class:"spm-action-grid"},O1={class:"spm-card-control"},R1={class:"spm-control-header"},N1={class:"spm-control-title-group"},z1={class:"spm-control-title"},H1=["aria-label"],F1=["checked"],j1={key:1,class:"spm-card-control"},W1={class:"spm-control-header"},U1={class:"spm-control-title-group"},V1={class:"spm-control-title"},G1={class:"spm-quick-chips"},K1={key:2,class:"spm-card-control"},q1={class:"spm-control-header"},Y1={class:"spm-control-title-group"},Z1={class:"spm-control-title"},J1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},X1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Q1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ey=["aria-label"],ty=["checked"],iy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ny={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},sy=["aria-label"],oy=["checked"],ry={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ay={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ly=["aria-label"],cy=["checked"],dy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},uy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},fy=["aria-label"],py=["checked"],hy={class:"spm-card-control"},my={class:"spm-control-header"},gy={class:"spm-control-title-group"},vy={class:"spm-control-title"},by=["aria-label"],yy=["checked"],ky={key:0,class:"spm-quick-chips"},wy=["onClick"],xy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Sy={class:"spm-card-control"},Cy={class:"spm-control-header"},_y={class:"spm-control-title-group"},$y={class:"spm-control-title"},Iy=["aria-label"],My=["checked"],Ty={key:0,class:"spm-quick-chips"},Ey=["onClick"],Ay={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},By={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Dy={style:{display:"flex",gap:"6px"}},Ly=["value"],Py=["value"],Oy={key:3,class:"spm-card-control"},Ry={class:"spm-control-header"},Ny={class:"spm-control-title-group"},zy={class:"spm-control-title"},Hy={class:"spm-control-desc"},Fy={class:"spm-segmented-group"},jy=["onClick"],Wy={key:4,class:"spm-card-control"},Uy={class:"spm-control-header"},Vy={class:"spm-control-title-group"},Gy={class:"spm-control-title"},Ky={class:"spm-quick-chips"},qy=["onClick"],Yy=["value"],Zy={key:5,class:"spm-card-control"},Jy={class:"spm-control-header"},Xy={class:"spm-control-title-group"},Qy={class:"spm-control-title"},e0={class:"spm-quick-chips"},t0=["onClick"],i0=["value"],n0={class:"spm-card-control"},s0={class:"spm-action-grid"},o0=["aria-label"],r0=Et({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=be(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),s=be(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),o=be(()=>{var C,D,F,W;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(D=i.elemSlot)==null?void 0:D.match(/^col-(\d+)$/);if(T){const K=parseInt(T[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((W=(F=i.detectedSbInfo)==null?void 0:F.ratio)!=null&&W.includes(":")){const K=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),a=be(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=be(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=be(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,D=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let F=1;F<=C;F++)D.push({value:`col-${F}`,label:`第 ${F} 栏`});return D});function c(T){const C=i.elemSlot||"";return T?C===T||T==="col-1"&&C==="left"||T==="col-2"&&C==="center"||T==="col-3"&&C==="right"&&o.value===3||T==="col-2"&&C==="right"&&o.value===2||T==="left"&&C==="col-1"||T==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=be(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),f=be(()=>!!h.value),v=be(()=>{var T;return((T=h.value)==null?void 0:T.preset)||"slide-up"}),m=be(()=>{var T;return((T=h.value)==null?void 0:T.duration)||0}),b=be(()=>{var T;return((T=h.value)==null?void 0:T.delay)||0});function y(){f.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function S(T){$(T,m.value,b.value)}function x(T){$(v.value,T,b.value)}function w(T){$(v.value,m.value,T)}function $(T,C,D){if(!T||T==="none"){u("update:elemMotion","");return}if(!C&&!D){u("update:elemMotion",T);return}const F={preset:T};C>0&&(F.duration=C),D>0&&(F.delay=D),u("update:elemMotion",JSON.stringify(F))}return(T,C)=>{var D,F,W,K,_,j;return Q(),te("div",S1,[C[62]||(C[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(D=e.detectedSbInfo)!=null&&D.hasSuperBlock?(Q(),te("div",C1,[p("div",_1,[p("div",$1,[p("div",I1,[ae(fe,{name:"ratio"}),C[24]||(C[24]=p("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",M1,[p("div",T1,[p("div",E1,[ae(fe,{name:"ratio"}),(F=e.detectedSbInfo)!=null&&F.isCustomWidth?(Q(),te("span",A1,"已识别自定义列宽比例")):(Q(),te("span",B1,"识别到 "+xe(((W=e.detectedSbInfo)==null?void 0:W.colCount)||2)+" 列超级块分栏",1))]),p("code",D1,xe(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),p("div",L1,xe((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",P1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=k=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[ae(fe,{name:"sparkles"}),C[26]||(C[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=k=>{var E;return T.$emit("applySuperBlockRatio",((E=e.detectedSbInfo)==null?void 0:E.ratio)||"1:1")})},[ae(fe,{name:"check"}),p("span",null,"应用比例 ("+xe(((j=e.detectedSbInfo)==null?void 0:j.ratio)||"1:1")+")",1)])])])):Te("",!0),p("div",O1,[p("div",R1,[p("div",N1,[p("div",z1,[ae(fe,{name:"presenter"}),C[27]||(C[27]=p("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=k=>T.$emit("toggleNote"))},null,40,F1),C[29]||(C[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,H1)])]),e.isImage||e.imageRole?(Q(),te("div",j1,[p("div",W1,[p("div",U1,[p("div",V1,[ae(fe,{name:"image"}),C[30]||(C[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),C[31]||(C[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",G1,[p("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=k=>T.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=k=>T.$emit("update:imageRole","background"))},[ae(fe,{name:"image"}),C[32]||(C[32]=p("span",null,"背景图",-1))],2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=k=>T.$emit("update:imageRole","image-left"))},[ae(fe,{name:"image-left"}),C[33]||(C[33]=p("span",null,"图左",-1))],2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=k=>T.$emit("update:imageRole","image-right"))},[ae(fe,{name:"image-right"}),C[34]||(C[34]=p("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(Q(),te("div",K1,[p("div",q1,[p("div",Y1,[p("div",Z1,[ae(fe,{name:"video"}),C[35]||(C[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),C[36]||(C[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",J1,[p("div",X1,[p("span",Q1,[ae(fe,{name:"sliders"}),C[37]||(C[37]=Ct(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=k=>T.$emit("toggleVideoControls"))},null,40,ty),C[38]||(C[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,ey)]),p("div",iy,[p("span",ny,[ae(fe,{name:"video"}),C[39]||(C[39]=Ct(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=k=>T.$emit("toggleVideoAutoplay"))},null,40,oy),C[40]||(C[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,sy)]),p("div",ry,[p("span",ay,[ae(fe,{name:"repeat"}),C[41]||(C[41]=Ct(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=k=>T.$emit("toggleVideoLoop"))},null,40,cy),C[42]||(C[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,ly)]),p("div",dy,[p("span",uy,[ae(fe,{name:"volume-x"}),C[43]||(C[43]=Ct(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=k=>T.$emit("toggleVideoMuted"))},null,40,py),C[44]||(C[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,fy)])])])):Te("",!0),p("div",hy,[p("div",my,[p("div",gy,[p("div",vy,[ae(fe,{name:"step"}),C[45]||(C[45]=p("span",null,"逐步呈现 (v-click)",-1))]),C[46]||(C[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=k=>T.$emit("toggleElemClick"))},null,40,yy),C[47]||(C[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,by)]),e.elemClick?(Q(),te("div",ky,[(Q(),te(qe,null,wt(["+1","1","2","hide"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemClick===k}]),onClick:E=>T.$emit("update:elemClick",k)},xe(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,wy)),64))])):e.parentElemClick?(Q(),te("div",xy,[ae(fe,{name:"check"}),C[48]||(C[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),p("div",Sy,[p("div",Cy,[p("div",_y,[p("div",$y,[ae(fe,{name:"motion"}),C[49]||(C[49]=p("span",null,"入场微动效 (v-motion)",-1))]),C[50]||(C[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":f.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:f.value,onChange:y},null,40,My),C[51]||(C[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,Iy)]),f.value?(Q(),te("div",Ty,[(Q(),te(qe,null,wt(d,k=>p("button",{key:k.value,class:_e(["spm-chip",{active:v.value===k.value}]),onClick:E=>S(k.value)},xe(k.label),11,Ey)),64))])):Te("",!0),f.value?(Q(),te("div",Ay,[p("div",By,[p("span",null,"时长: "+xe(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+xe(b.value?b.value+"ms":"0ms"),1)]),p("div",Dy,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=k=>x(Number(k.target.value)))},[...C[52]||(C[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,Ly),p("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:C[13]||(C[13]=k=>w(Number(k.target.value)))},[...C[53]||(C[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,Py)])])):Te("",!0)]),s.value||e.elemSlot?(Q(),te("div",Oy,[p("div",Ry,[p("div",Ny,[p("div",zy,[ae(fe,{name:"columns"}),p("span",null,xe(a.value),1)]),p("span",Hy,xe(r.value),1)])]),p("div",Fy,[(Q(!0),te(qe,null,wt(l.value,k=>(Q(),te("button",{key:k.value,class:_e(["spm-segmented-item",{active:c(k.value)}]),onClick:E=>T.$emit("update:elemSlot",k.value)},xe(k.label),11,jy))),128))])])):Te("",!0),e.isCodeBlock?(Q(),te("div",Wy,[p("div",Uy,[p("div",Vy,[p("div",Gy,[ae(fe,{name:"code"}),C[54]||(C[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),C[55]||(C[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Ky,[(Q(),te(qe,null,wt(["1-3","all","1|2|3","2-5"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:E=>T.$emit("update:elemShikiLines",k)},xe(k),11,qy)),64)),e.elemShikiLines?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=k=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=k=>T.$emit("update:elemShikiLines",k.target.value)),onChange:C[16]||(C[16]=k=>T.$emit("update:elemShikiLines",k.target.value))},null,40,Yy)])):Te("",!0),e.isCodeBlock?(Q(),te("div",Zy,[p("div",Jy,[p("div",Xy,[p("div",Qy,[ae(fe,{name:"code"}),C[56]||(C[56]=p("span",null,"代码块限高 (Max Height)",-1))]),C[57]||(C[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",e0,[(Q(),te(qe,null,wt(["240px","320px","400px","50vh"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:E=>T.$emit("update:elemMaxHeight",k)},xe(k),11,t0)),64)),e.elemMaxHeight?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=k=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[18]||(C[18]=k=>T.$emit("update:elemMaxHeight",k.target.value)),onChange:C[19]||(C[19]=k=>T.$emit("update:elemMaxHeight",k.target.value))},null,40,i0)])):Te("",!0),p("div",n0,[C[61]||(C[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",s0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=k=>T.$emit("insertDividerBefore"))},[ae(fe,{name:"insert-above"}),C[58]||(C[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=k=>T.$emit("insertDividerAfter"))},[ae(fe,{name:"insert-below"}),C[59]||(C[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:C[22]||(C[22]=k=>T.$emit("setTwoColsContrast"))},[ae(fe,{name:"columns"}),p("span",null,xe(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,o0),e.hasBlockAttrs?(Q(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=k=>T.$emit("clearBlockAttrs"))},[ae(fe,{name:"broom"}),C[60]||(C[60]=p("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),a0={class:"spm-section spm-section--doc"},l0={class:"spm-card-control"},c0={class:"spm-control-header"},d0={class:"spm-control-title-group"},u0={class:"spm-control-title"},f0={class:"spm-segmented-group"},p0=["aria-label","onClick"],h0={class:"spm-card-control"},m0={class:"spm-control-header"},g0={class:"spm-control-title-group"},v0={class:"spm-control-title"},b0={class:"spm-segmented-group"},y0={class:"spm-card-control"},k0={class:"spm-control-header"},w0={class:"spm-control-title-group"},x0={class:"spm-control-title"},S0={class:"spm-segmented-group"},C0={class:"spm-card-control"},_0={class:"spm-control-header"},$0={class:"spm-control-title-group"},I0={class:"spm-control-title"},M0={class:"spm-card-control"},T0={class:"spm-control-header"},E0={class:"spm-control-title-group"},A0={class:"spm-control-title"},B0=["aria-label"],D0=["checked"],L0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},P0=["value"],O0={class:"spm-card-control"},R0={class:"spm-control-header"},N0={class:"spm-control-title-group"},z0={class:"spm-control-title"},H0=["aria-label"],F0=["checked"],j0={class:"spm-card-control"},W0={class:"spm-control-header"},U0={class:"spm-control-title-group"},V0={class:"spm-control-title"},G0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},K0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},q0=["aria-label"],Y0=["checked"],Z0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},J0=["aria-label"],X0=["checked"],Q0={class:"spm-card-control"},ek={class:"spm-action-grid"},tk=["disabled"],ik=["disabled"],nk=["disabled","aria-label"],sk=Et({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=Rt("plugin"),i=Ut,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(u){si({enableWebServeJump:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:u})}async function o(u){var d;si({normalizeHeadingSizes:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(u){var d;si({showUnorderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(u){var d;si({showOrderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(u){si({webServeUrl:u})}function c(u){si({webServeUrl:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:u})}return(u,d)=>(Q(),te("div",a0,[d[52]||(d[52]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",l0,[p("div",c0,[p("div",d0,[p("div",u0,[ae(fe,{name:"palette"}),d[23]||(d[23]=p("span",null,"幻灯片主题 (Theme)",-1))]),d[24]||(d[24]=p("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),p("div",f0,[(Q(),te(qe,null,wt(n,h=>p("button",{key:h.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===h.value}]),"aria-label":h.desc,onClick:f=>u.$emit("update:docTheme",h.value)},xe(h.label),11,p0)),64))])]),p("div",h0,[p("div",m0,[p("div",g0,[p("div",v0,[ae(fe,{name:"ratio"}),d[25]||(d[25]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),d[26]||(d[26]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",b0,[p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[0]||(d[0]=h=>u.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[1]||(d[1]=h=>u.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[2]||(d[2]=h=>u.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",y0,[p("div",k0,[p("div",w0,[p("div",x0,[ae(fe,{name:"ratio"}),d[27]||(d[27]=p("span",null,"间距风格 (Spacing)",-1))]),d[28]||(d[28]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",S0,[p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:d[3]||(d[3]=h=>u.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:d[4]||(d[4]=h=>u.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:d[5]||(d[5]=h=>u.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",C0,[p("div",_0,[p("div",$0,[p("div",I0,[ae(fe,{name:"transition"}),d[29]||(d[29]=p("span",null,"全局默认转场",-1))]),d[30]||(d[30]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ae(tc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[6]||(d[6]=h=>u.$emit("update:docDefaultTransition",h))},null,8,["model-value"])]),p("div",M0,[p("div",T0,[p("div",E0,[p("div",A0,[ae(fe,{name:"external-link"}),d[31]||(d[31]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),d[32]||(d[32]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:d[7]||(d[7]=h=>s(h.target.checked))},null,40,D0),d[33]||(d[33]=p("span",{class:"spm-switch-slider"},null,-1))],8,B0)]),he(i).enableWebServeJump?(Q(),te("div",L0,[p("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[8]||(d[8]=Yt(()=>{},["stop"])),onKeyup:d[9]||(d[9]=Yt(()=>{},["stop"])),onInput:d[10]||(d[10]=h=>l(h.target.value)),onChange:d[11]||(d[11]=h=>c(h.target.value))},null,40,P0),d[34]||(d[34]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),p("div",O0,[p("div",R0,[p("div",N0,[p("div",z0,[ae(fe,{name:"type"}),d[35]||(d[35]=p("span",null,"固定特定标题大小",-1))]),d[36]||(d[36]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:d[12]||(d[12]=h=>o(h.target.checked))},null,40,F0),d[37]||(d[37]=p("span",{class:"spm-switch-slider"},null,-1))],8,H0)])]),p("div",j0,[p("div",W0,[p("div",U0,[p("div",V0,[ae(fe,{name:"list"}),d[38]||(d[38]=p("span",null,"列表前缀标记",-1))]),d[39]||(d[39]=p("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),p("div",G0,[p("div",K0,[d[41]||(d[41]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[p("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:d[13]||(d[13]=h=>a(h.target.checked))},null,40,Y0),d[40]||(d[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,q0)]),p("div",Z0,[d[43]||(d[43]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[p("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:d[14]||(d[14]=h=>r(h.target.checked))},null,40,X0),d[42]||(d[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,J0)])])]),p("div",Q0,[d[51]||(d[51]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",ek,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[15]||(d[15]=h=>u.$emit("openBottomPreview"))},[ae(fe,{name:"split-preview"}),d[44]||(d[44]=p("span",null,"分屏预览",-1))]),he(_t)("presenterMode")?(Q(),te("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[16]||(d[16]=h=>u.$emit("openPresenter"))},[ae(fe,{name:"presenter"}),d[45]||(d[45]=p("span",null,"演讲者视图",-1))])):Te("",!0),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[17]||(d[17]=h=>u.$emit("identifyNotes"))},[ae(fe,{name:"notes"}),d[46]||(d[46]=p("span",null,"识别讲稿块",-1))],8,tk),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[18]||(d[18]=h=>u.$emit("autoAnimate"))},[ae(fe,{name:"step"}),d[47]||(d[47]=p("span",null,"智能动效",-1))],8,ik),he(_t)("aiScript")?(Q(),te("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:d[19]||(d[19]=h=>u.$emit("aiAutoSplit"))},[ae(fe,{name:"sparkles"}),d[48]||(d[48]=p("span",null,"AI 智能分页",-1))])):Te("",!0),he(_t)("exportHtml")?(Q(),te("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[20]||(d[20]=h=>u.$emit("exportHtml"))},[ae(fe,{name:"export-html"}),d[49]||(d[49]=p("span",null,"导出 HTML",-1))])):Te("",!0),he(_t)("exportPdf")?(Q(),te("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[21]||(d[21]=h=>u.$emit("exportPdf"))},[ae(fe,{name:"export-pdf"}),d[50]||(d[50]=p("span",null,"导出 PDF",-1))])):Te("",!0),he(_t)("exportImage")?(Q(),te("button",{key:4,class:_e(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[22]||(d[22]=h=>u.$emit("exportImages"))},[ae(fe,{name:"export-image"}),p("span",null,xe(e.isExportingImages?"正在导出...":"导出图片"),1)],10,nk)):Te("",!0)])])]))}}),ok=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,rk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function ak(e){const t=await ql.loadAsync(e),i={},n=[];let s="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||rk.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const d=c.split("/");d.length>1&&(i[d.slice(1).join("/")]=u)}else if(ok.test(c)){const u=await l.file.async("uint8array"),d=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:d,data:u,blob:h})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function lk(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],a=i(o);a&&(s.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function ic(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function ck(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,a=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const f=r.split("/").pop();for(const[v,m]of Object.entries(l))if(v.endsWith(`/${r}`)||f&&v.endsWith(`/${f}`)){c=m;break}}if(!c){const f=[];if(t!=null&&t.baseDir)try{const v=require("path");f.push(v.resolve(t.baseDir,r)),f.push(v.resolve(t.baseDir,o))}catch{}try{const v=require("path");f.push(v.resolve(process.cwd(),r))}catch{}for(const v of f){const m=ic(v);if(m!==null){c=m;break}}}if(!c){const f=Nl||{};if(c=f[o]||f[r]||f[`snippets/${r}`],!c){const v=r.split("/").pop();for(const[m,b]of Object.entries(f))if(m.endsWith(`/${r}`)||v&&m.endsWith(`/${v}`)){c=b;break}}}if(!c)return null;let u=c;if(a){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),v=c.match(f);if(v){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+v[1].trimEnd()}}const d=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${d?d[1]:""}
${u}
\`\`\``}function dk(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const a=s.indexOf(":");if(a>0){const r=s.slice(0,a).trim();let l=s.slice(a+1).trim();if(l==="|"||l===">"){n++;const c=[];let u=-1;for(;n<i.length;){const d=i[n];if(!d.trim()){c.push(""),n++;continue}const f=d.match(/^(\s+)/),v=f?f[1].length:0;if(u===-1&&(u=v),v<u)break;c.push(d.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=dk(l),!l){let c=n+1;const u=[];let d=-1;for(;c<i.length;){const h=i[c],f=h.trim();if(!f||f.startsWith("#")){d!==-1&&u.push(""),c++;continue}const v=h.match(/^(\s+)/),m=v?v[1].length:0;if(d===-1)if(m>0)d=m;else break;if(m<d)break;u.push(h.slice(d)),c++}if(u.length>0){t[r]=gs(u.join(`
`)),n=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}n++}return t}const uk=/^\s*```ya?ml([\s\S]*?)```/;function ua(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(uk);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gs(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function fk(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(a){if(n>=a)return;const r=t.slice(n,a).join(`
`).trim();r&&i.push(r),n=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(s){l.includes("-->")&&(s=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(s=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];if(c&&c.trim()&&l.replace(/^-+/,"").trim()==="")for(n=a,a+=1;a<t.length&&t[a].trimEnd()!=="---";a++);}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let d=a+1;for(;d<t.length&&!t[d].trimStart().startsWith(u);d++);d<t.length&&(a=d)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const d=fk(u),h={};let f="",v="",m=0;if(d.length>0){const W=d[0],K=ua(W),_=Object.keys(K.frontmatter).length>0,j=K.content.length>0;_&&!j&&d.length>1?(m=1,b(K.frontmatter)):_&&b(K.frontmatter)}function b(W){f=W.title||"",W.theme&&(h[On]=String(W.theme)),W.aspectRatio&&(h[Rn]=String(W.aspectRatio)),W.highlighter&&(h[ka]=String(W.highlighter)),W.transition&&(h[Nn]=String(W.transition)),W.colorSchema&&(h[wa]=String(W.colorSchema)),W.layout&&(h[we]=String(W.layout)),W.background&&(h[nt]=String(W.background)),W.image&&(h[Pt]=String(W.image)),W.class&&(h[Qi]=String(W.class));for(const[K,_]of Object.entries(W))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(h[`custom-slides-${K}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let S=0,x=0,w=0,$=0;const T=new Set,C={};let D=1;for(let W=m;W<d.length;W++){const K=d[W],{frontmatter:_,content:j}=ua(K),k=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),E=_.src||(k?k[1]:void 0);if(E){const le=String(E).trim().replace(/^['"]|['"]$/g,"");let X=c[le]||c[le.replace(/^\.\//,"")]||c[`pages/${le.replace(/^.*pages\//,"")}`];if(!X){const P=le.replace(/^\.\//,""),U=[];if(t.baseDir)try{const g=require("path");U.push(g.resolve(t.baseDir,P)),U.push(g.resolve(t.baseDir,le))}catch{}try{const g=require("path");U.push(g.resolve(process.cwd(),P)),U.push(g.resolve(process.cwd(),le))}catch{}for(const g of U){const G=ic(g);if(G!==null){X=G;break}}}const ce={};_.layout&&(ce[we]=String(_.layout)),_.transition&&(ce[mt]=String(_.transition)),_.background&&(ce[nt]=String(_.background)),_.image&&(ce[Pt]=String(_.image)),_.class&&(ce[Qi]=String(_.class));for(const[P,U]of Object.entries(_))["src","layout","transition","background","image","class"].includes(P)||(ce[`custom-slides-${P}`]=typeof U=="object"?JSON.stringify(U):String(U));if(X){const P=vs(X,{...t,virtualFiles:c});for(const U of P.slides){U.pageIndex=D++,U.pageAttrs={...ce,...U.pageAttrs},y.push(U);const g=U.pageAttrs[we]||"default";C[g]=(C[g]||0)+1}continue}else{y.push({pageIndex:D++,pageAttrs:{...ce,"custom-slides-src":le},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${le}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const P=ce[we]||"default";C[P]=(C[P]||0)+1;continue}}const N={};_.layout&&(N[we]=String(_.layout)),_.transition&&(N[mt]=String(_.transition)),_.background&&(N[nt]=String(_.background)),_.image&&(N[Pt]=String(_.image)),_.class&&(N[Qi]=String(_.class)),_.mask&&(N[en]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(N[Ni]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(N[tn]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(N[nn]=String(_.maskInitial||_["mask-initial"]));for(const[le,X]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(le)||(N[`custom-slides-${le}`]=typeof X=="object"?JSON.stringify(X):String(X));let B=j;const L=[];let R=B.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,le=>{const X=`__CODE_TOKEN_NOTE_${L.length}__`;return L.push(le),X});R=R.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,le=>{const X=`__CODE_TOKEN_NOTE_${L.length}__`;return L.push(le),X});let de="";const V=Array.from(R.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const le=V[V.length-1],X=R.slice(le.index+le[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const P=le[1].trim();P.startsWith("TODO:")||(de=P,S++),i&&(R=R.slice(0,le.index).trimEnd()+R.slice(le.index+le[0].length))}}i&&(R=R.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let le=0;le<L.length;le++)R=R.replace(`__CODE_TOKEN_NOTE_${le}__`,L[le]);if(B=R,de){for(let ce=0;ce<L.length;ce++)de=de.replace(`__CODE_TOKEN_NOTE_${ce}__`,L[ce]);const X=`> [!NOTE] 💡 演讲备注
${de.split(/\r?\n/).map(ce=>`> ${ce}`).join(`
`)}
{: custom-slides-note="true"}`;B=B?`${B}

${X}`:X}let Y=!1;if(/<style\b/i.test(B)){Y=!0;const le=B.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(le){for(const X of le){const ce=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();v=v?`${v}

${ce}`:ce}a&&(B=B.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const Z=B.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);Z&&(x+=Z.length);const ne=B.match(/```\w+\s+\{[^}]+\}/g);ne&&(w+=ne.length);const oe=B.match(/::\w+::|<template\s+#[^>]+>/g);if(oe&&($+=oe.length),B=B.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,le=>ck(le,{...t,virtualFiles:c})||le),n&&(B=B.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(B=B.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),B=B.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(B=B.replace(/^::\w+::\s*$/gm,"")),r&&(B=Qf(B)),l){let le=B.trim(),X="";const ce=le.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ce!==-1&&(X=le.slice(ce),le=le.slice(0,ce).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const P=String(_.image).trim(),U=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${P})
{: custom-slides-layout="${U}" }`;_.layout==="image-left"?le=`{{{col

${g}

${le}

}}}`:le=`{{{col

${le}

${g}

}}}`}if(_.background){const U=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;le=le?`${U}

${le}`:U}B=X?`${le}

${X}`:le}const ye=pk(B);N[nt]&&ye.push(N[nt]),N[Pt]&&ye.push(N[Pt]);for(const le of ye)T.add(le);const Ie=/<[A-Z][a-zA-Z0-9]+/.test(B),Ce=N[we]||(D===1?h[we]||"cover":"default");C[Ce]=(C[Ce]||0)+1,y.push({pageIndex:D++,pageAttrs:N,notes:de,rawMarkdown:B,hasVueComponent:Ie,hasStyleTag:Y,assetReferences:ye})}if(!f&&y.length>0){const W=y[0].rawMarkdown.match(/^#\s+(.+)$/m);W&&(f=W[1].trim())}v&&(h["custom-slides-custom-css"]=v);let F=y.map(W=>`---

${W.rawMarkdown}`).join(`

`);return F.trimStart().startsWith("---")||(F=`---

${F.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:h,slides:y,totalSlides:y.length,stats:{totalNotes:S,totalVClicks:x,totalShikiHighlights:w,totalSlots:$,discoveredAssets:Array.from(T),layoutDistribution:C},flattenedMarkdown:F,customCss:v}}function pk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function nc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function hk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function mk(e,t,i=He){const n=e.filter(nc);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=n[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const a=t[o],r=n[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}return s}async function gk(e,t=He){let i=!1,n=0;for(const s of e){if(nc(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[Me]:"right"}).catch(()=>{}),n++)}return n}async function vk(e,t,i=ga){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(a)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))n[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&lk(e,n),n}async function bk(e){var w;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||ga,u=l.createDocFn||rd,d=l.setAttrsFn||He,h=l.getChildBlocksFn||Yn,f=l.openTabFn||ue.openTab,v=l.showMessageFn||ue.showMessage;o&&s.length>0&&await vk(t,s,c);const m=hk(n),b=`/${m}`,y=await u(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const S=((w=t.slides[0])==null?void 0:w.pageAttrs)||{};await d(y,{...S,...t.docRootAttrs});const x=await h(y).catch(()=>[]);return Array.isArray(x)&&x.length>0&&(await mk(x,t.slides,d),await gk(x,d)),v(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=y,await f({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function yk(e){const t=ge("file"),i=ge(!1),n=ge(!1),s=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),u=ge([]),d=ge(null),h=ge(""),f=ge([]),v=ge(""),m=ge(!0),b=ge(!0),y=ge(!0),S=ge(!0),x=be(()=>{const N=l.value;if(N===0)return"0 B";const B=1024,L=["B","KB","MB","GB"],R=Math.floor(Math.log(N)/Math.log(B));return`${(N/B**R).toFixed(1)} ${L[R]}`}),w=be(()=>{var N;return((N=d.value)==null?void 0:N.docRootAttrs["custom-slides-theme"])||"default"}),$=be(()=>{var N;return u.value.length>0?u.value.length:((N=d.value)==null?void 0:N.stats.discoveredAssets.length)||0}),T=be(()=>{var B;const N=((B=d.value)==null?void 0:B.stats.layoutDistribution)||{};return Object.entries(N).map(([L,R])=>({name:L,count:R}))});async function C(N=od){try{const B=await N();B!=null&&B.notebooks&&Array.isArray(B.notebooks)&&(f.value=B.notebooks.filter(L=>!L.closed),f.value.length>0&&!v.value&&(v.value=f.value[0].id))}catch(B){console.warn("获取笔记本列表失败:",B)}}function D(){var N;(N=o.value)==null||N.click()}function F(){a.value=null,r.value="",l.value=0,d.value=null,u.value=[],s.value=""}async function W(N){s.value="",a.value=N,r.value=N.name,l.value=N.size;try{if(N.name.toLowerCase().endsWith(".zip")){const L=await N.arrayBuffer(),R=await ak(L);if(!R.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=R.assets;const de=vs(R.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:R.virtualFiles});d.value=de,h.value=de.docTitle||N.name.replace(/\.zip$/i,"")}else{const L=await N.text();u.value=[];const R=N.path||"",de=R?R.replace(/[\\/][^\\/]+$/,""):"",V=vs(L,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:de||void 0});d.value=V,h.value=V.docTitle||N.name.replace(/\.md$/i,"")}}catch(B){console.error("解析文件失败:",B),s.value=`解析文件失败: ${B.message||String(B)}`}}function K(){if(s.value="",!c.value.trim()){d.value=null;return}try{const N=vs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});d.value=N,h.value=N.docTitle||"Slidev 演示文稿"}catch(N){s.value=`解析 Markdown 源码失败: ${N.message||String(N)}`}}async function _(){a.value?await W(a.value):c.value&&K()}async function j(N){const B=N.target;B.files&&B.files[0]&&await W(B.files[0])}async function k(N){var B;i.value=!1,(B=N.dataTransfer)!=null&&B.files&&N.dataTransfer.files[0]&&await W(N.dataTransfer.files[0])}async function E(N=e){if(d.value){if(!v.value&&f.value.length>0&&(v.value=f.value[0].id),!v.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await bk({presentation:d.value,notebookId:v.value,docTitle:h.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:S.value,plugin:N})}catch(B){console.error("导入 Slidev 演示失败:",B),s.value=`导入执行失败: ${B.message||String(B)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:d,customDocTitle:h,notebooks:f,selectedNotebookId:v,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:S,formattedFileSize:x,currentTheme:w,extractedAssetsCount:$,layoutChips:T,fetchNotebooks:C,triggerFileInput:D,clearFile:F,processFile:W,onFileSelected:j,onFileDrop:k,onTextChange:K,reprocessCurrentInput:_,handleConfirmImport:E}}const kk={class:"spm-import-dialog"},wk={class:"spm-tabs-header"},xk={class:"spm-dialog-body"},Sk={key:0,class:"spm-file-section"},Ck={key:0,class:"spm-dropzone-prompt"},_k={class:"spm-dropzone-icon"},$k={key:1,class:"spm-dropzone-active"},Ik={class:"spm-file-badge"},Mk={class:"spm-file-size"},Tk={key:1,class:"spm-text-section"},Ek={key:2,class:"spm-error-banner"},Ak={key:3,class:"spm-preview-card"},Bk={class:"spm-preview-card__header"},Dk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Lk={class:"spm-config-grid"},Pk={class:"spm-form-item"},Ok={class:"spm-form-item"},Rk=["value"],Nk={class:"spm-stats-grid"},zk={class:"spm-stat-box"},Hk={class:"spm-stat-value"},Fk={class:"spm-stat-box"},jk={class:"spm-stat-value"},Wk={class:"spm-stat-box"},Uk={class:"spm-stat-value"},Vk={class:"spm-stat-box"},Gk={class:"spm-stat-value"},Kk={key:0,class:"spm-chips-row"},qk={class:"spm-options-group"},Yk={class:"spm-checkbox-label"},Zk={class:"spm-checkbox-label"},Jk={class:"spm-checkbox-label"},Xk={class:"spm-checkbox-label"},Qk={class:"spm-dialog-footer"},ew=["disabled"],tw=["disabled"],iw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},nw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},sw=Et({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Rt("plugin"),{inputMode:s,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:d,parsedPresentation:h,customDocTitle:f,notebooks:v,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:S,optAutoPreview:x,formattedFileSize:w,currentTheme:$,layoutChips:T,fetchNotebooks:C,triggerFileInput:D,clearFile:F,onFileSelected:W,onFileDrop:K,onTextChange:_,reprocessCurrentInput:j,handleConfirmImport:k}=yk(n);mn(async()=>{await C()});async function E(){const B=await k();B&&(i("success",{docId:B}),i("close"))}function N(){i("close")}return(B,L)=>(Q(),te("div",{class:"spm-modal-overlay",onClick:Yt(N,["self"])},[p("div",kk,[p("div",{class:"spm-dialog-header"},[L[18]||(L[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlides"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:N},"✕")]),p("div",wk,[p("button",{class:_e(["spm-tab-btn",{active:he(s)==="file"}]),onClick:L[0]||(L[0]=R=>s.value="file")},[ae(fe,{name:"package"}),L[19]||(L[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:_e(["spm-tab-btn",{active:he(s)==="text"}]),onClick:L[1]||(L[1]=R=>s.value="text")},[ae(fe,{name:"notes"}),L[20]||(L[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",xk,[he(s)==="file"?(Q(),te("div",Sk,[p("div",{class:_e(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:L[4]||(L[4]=Yt(R=>o.value=!0,["prevent"])),onDragleave:L[5]||(L[5]=Yt(R=>o.value=!1,["prevent"])),onDrop:L[6]||(L[6]=Yt((...R)=>he(K)&&he(K)(...R),["prevent"])),onClick:L[7]||(L[7]=(...R)=>he(D)&&he(D)(...R))},[p("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:L[2]||(L[2]=(...R)=>he(W)&&he(W)(...R))},null,544),he(c)?(Q(),te("div",$k,[p("span",Ik,[ae(fe,{name:"notes"}),Ct(" "+xe(he(c)),1)]),p("span",Mk,"("+xe(he(w))+")",1),p("button",{class:"spm-btn-text",onClick:L[3]||(L[3]=Yt((...R)=>he(F)&&he(F)(...R),["stop"]))},"更换文件")])):(Q(),te("div",Ck,[p("span",_k,[ae(fe,{name:"folder",style:{"font-size":"32px"}})]),L[21]||(L[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),L[22]||(L[22]=p("p",{class:"spm-dropzone-hint"},[Ct(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),Ct("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(Q(),te("div",Tk,[Lt(p("textarea",{"onUpdate:modelValue":L[8]||(L[8]=R=>Xe(u)?u.value=R:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:L[9]||(L[9]=(...R)=>he(_)&&he(_)(...R))},null,544),[[Lo,he(u)]])])),he(r)?(Q(),te("div",Ek," ⚠️ "+xe(he(r)),1)):Te("",!0),he(h)?(Q(),te("div",Ak,[p("div",Bk,[p("span",Dk,[ae(fe,{name:"sparkles"}),L[23]||(L[23]=Ct(" 演示解析摘要",-1))]),L[24]||(L[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",Lk,[p("div",Pk,[L[25]||(L[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Lt(p("input",{"onUpdate:modelValue":L[10]||(L[10]=R=>Xe(f)?f.value=R:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Lo,he(f)]])]),p("div",Ok,[L[26]||(L[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Lt(p("select",{"onUpdate:modelValue":L[11]||(L[11]=R=>Xe(m)?m.value=R:null),class:"spm-select"},[(Q(!0),te(qe,null,wt(he(v),R=>(Q(),te("option",{key:R.id,value:R.id},xe(R.name),9,Rk))),128))],512),[[Df,he(m)]])])]),p("div",Nk,[p("div",zk,[p("span",Hk,xe(he(h).totalSlides),1),L[27]||(L[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",Fk,[p("span",jk,xe(he($)),1),L[28]||(L[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",Wk,[p("span",Uk,xe(he(h).stats.totalNotes),1),L[29]||(L[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",Vk,[p("span",Gk,xe(he(d)),1),L[30]||(L[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(T).length>0?(Q(),te("div",Kk,[L[31]||(L[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(Q(!0),te(qe,null,wt(he(T),R=>(Q(),te("span",{key:R.name,class:"spm-chip-badge"},xe(R.name)+": "+xe(R.count),1))),128))])):Te("",!0),p("div",qk,[p("label",Yk,[Lt(p("input",{"onUpdate:modelValue":L[12]||(L[12]=R=>Xe(b)?b.value=R:null),type:"checkbox",onChange:L[13]||(L[13]=(...R)=>he(j)&&he(j)(...R))},null,544),[[as,he(b)]]),L[32]||(L[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Zk,[Lt(p("input",{"onUpdate:modelValue":L[14]||(L[14]=R=>Xe(y)?y.value=R:null),type:"checkbox",onChange:L[15]||(L[15]=(...R)=>he(j)&&he(j)(...R))},null,544),[[as,he(y)]]),L[33]||(L[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Jk,[Lt(p("input",{"onUpdate:modelValue":L[16]||(L[16]=R=>Xe(S)?S.value=R:null),type:"checkbox"},null,512),[[as,he(S)]]),L[34]||(L[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Xk,[Lt(p("input",{"onUpdate:modelValue":L[17]||(L[17]=R=>Xe(x)?x.value=R:null),type:"checkbox"},null,512),[[as,he(x)]]),L[35]||(L[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),p("div",Qk,[p("button",{class:"spm-btn-secondary",disabled:he(a),onClick:N}," 取消 ",8,ew),p("button",{class:"spm-btn-primary",disabled:!he(h)||he(a),onClick:E},[he(a)?(Q(),te("span",iw,[ae(fe,{name:"refresh"}),L[36]||(L[36]=Ct(" 正在导入生成中...",-1))])):(Q(),te("span",nw,[ae(fe,{name:"rocket"}),L[37]||(L[37]=Ct(" 确认导入思源笔记",-1))]))],8,tw)])])]))}}),ow=ei(sw,[["__scopeId","data-v-c56a3d7e"]]);function hr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function rw(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(hr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(s){let l=e.find(c=>c.startBlockId===s);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===s}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(f=>f.id===i))||((h=u.allBlockIds)==null?void 0:h.includes(i))}),l)||n&&n!==i&&(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(f=>f.id===n))||((h=u.allBlockIds)==null?void 0:h.includes(n))}),l)||(l=e.find(u=>{var d;return(d=u.noteBlocks)==null?void 0:d.some(h=>h.id===i||h.id===n)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var d,h;return((d=u.frontmatter)==null?void 0:d.layout)==="three-cols-header"||((h=u.blocks)==null?void 0:h.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),l))return l}return e[0]||null}function Je(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function aw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${we}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(we),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slides-role");return}const o=e.get(s),a=(o==null?void 0:o[we])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(we)||n.getAttribute("custom-slides-layout");r&&r!==a&&(a?n.setAttribute(we,a):(n.removeAttribute(we),n.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slides-role");c&&c!==l&&(l?n.setAttribute(Ze,l):(n.removeAttribute(Ze),n.removeAttribute("custom-slides-role")))})}function lw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function cw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function n(c){var f;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[v,m]of Object.entries(c))e.activeBlockAttrs.value[v]=m;Pe.setBlockAttrOverride(u,c),Je(u,c);const d=(f=e.parentContainerId)==null?void 0:f.value,h=!!(d&&lw(u,d));if(ze in c&&h&&d){const v=c[ze];e.parentContainerClicks&&(e.parentContainerClicks.value=v),Pe.setBlockAttrOverride(d,{[ze]:v}),Je(d,{[ze]:v}),He(d,{[ze]:v}).catch(()=>{})}if(we in c){const v=c[we];e.currentPageDividerLayout.value=v,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=v)}if(kt in c){const v=c[kt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=v)}i("保存中...");try{await He(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,u){await n({[c]:u})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function a(c,u){const d=o();if(d){d===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Pe.setBlockAttrOverride(d,{[c]:u}),Je(d,{[c]:u}),c===we&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===kt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await He(d,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const d=o();if(!d)return;const h={[we]:c,[kt]:u};d===e.activeBlockId.value&&(e.activeBlockAttrs.value[we]=c,e.activeBlockAttrs.value[kt]=u),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(d,h),Je(d,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await He(d,h),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var h;const d=e.currentDocId.value||e.activeBlockId.value;if(d){e.activeBlockAttrs.value[c]=u,Pe.setBlockAttrOverride(d,{[c]:u}),Je(d,{[c]:u}),(h=e.latestDoc.value)!=null&&h.config&&(c===On&&(e.latestDoc.value.config.theme=u),c===Rn&&(e.latestDoc.value.config.aspectRatio=u),c===Nn&&(e.latestDoc.value.config.defaultTransition=u)),i("更新中...");try{await He(d,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(d)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function fa(e,t){const i=(e.blocks||[]).filter(a=>{const r=(a.content||a.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const a of i){const r=(a.content||a.rawMarkdown||"").trim();r&&(a.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((a,r)=>{o.push(`${r+1}. 讲解 ${a}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function sc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:fa(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:fa(e),isAiGenerated:!1}}async function dw(e,t){return(await sc(e,t)).notes}function uw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function fw(e,t){if(!((t==null?void 0:t[Ve])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function pw(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||Yn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(Kn({...r,ial:{...r.ial||{},...Pe.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const a=[];for(let r=0;r<s.length;r++){const l=s[r];if(!l||l.length===0)continue;let c=null;for(let v=l.length-1;v>=0;v--){const m=l[v];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!uw(c))continue;const u=Pe.getBlockAttrOverride(c.id)||{};let d={...c.ial||{},...u};if(!d[Ve]&&!d["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const v=await t.getBlockAttrsFn(c.id).catch(()=>({}));d={...d,...v,...u}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const v=await t.getBlockKramdownFn(c.id);v!=null&&v.kramdown&&(h=v.kramdown)}catch{}if(fw(h,d))continue;const f=dr(h)||h.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:f||"在此输入本页讲稿提词..."})}return a}async function hw(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||yo,s=(i==null?void 0:i.setBlockAttrsFn)||He,o=(i==null?void 0:i.syncDomFn)||Je,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${Ve}="true"}`;await n("markdown",r,e),await s(e,{[Ve]:"true"}),Pe.setBlockAttrOverride(e,{[Ve]:"true"}),o(e,{[Ve]:"true"})}async function oc(e,t){const i=(t==null?void 0:t.showMessageFn)||ue.showMessage,n=(t==null?void 0:t.confirmFn)||ue.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await pw(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(a=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of s)try{await hw(u.id,u.cleanContent,t),r++}catch(d){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,d),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function mw(e,t){const i=ge(!1),{triggerSaveNotice:n}=t;async function s(h){var $,T,C,D,F,W,K,_;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(j=>`> ${j}`).join(`
`)}
{: custom-slides-note="true"}`,b=(($=e.latestDoc.value)==null?void 0:$.slides)||[],y=e.targetSlide.value,S=y?b.findIndex(j=>j===y):-1;let x=null;if(S!==-1&&S<b.length-1){const j=b[S+1];x=await Oi("markdown",m,j.startBlockId)}else{const j=((T=y==null?void 0:y.noteBlocks)==null?void 0:T.slice(-1)[0])||((C=y==null?void 0:y.blocks)==null?void 0:C.slice(-1)[0]),k=(j==null?void 0:j.id)||(y==null?void 0:y.startBlockId);k?x=await Oi("markdown",m,void 0,k):x=await bo("markdown",m,e.currentDocId.value)}const w=((W=(F=(D=x==null?void 0:x[0])==null?void 0:D.doOperations)==null?void 0:F[0])==null?void 0:W.id)||((K=x==null?void 0:x[0])==null?void 0:K.id);return w&&(await He(w,{[Ve]:"true"}),Pe.setBlockAttrOverride(w,{[Ve]:"true"}),ji(w,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),w}async function o(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){n("取消中...");try{await He(h,{[Ve]:"","slides-note":""}),Pe.setBlockAttrOverride(h,{[Ve]:"","slides-note":""}),Je(h,{[Ve]:"","slides-note":""}),delete e.activeBlockAttrs.value[Ve],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ue.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",f),n("取消失败"),ue.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let f=e.rawSnippet.value;try{const y=await ad(h);y!=null&&y.kramdown&&(f=y.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(dr(f)||f.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,h),await He(h,{[Ve]:"true"}),Pe.setBlockAttrOverride(h,{[Ve]:"true"}),Je(h,{[Ve]:"true"}),e.activeBlockAttrs.value[Ve]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ue.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",f),n("设置失败"),ue.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await s(),ue.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){ue.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var v;const h=e.currentSlideNoteBlockId.value;if(!h){ue.showMessage("未找到本页关联的讲稿备注块");return}ji(h,(v=e.plugin)==null?void 0:v.app)?ue.showMessage("已在编辑区定位讲稿备注块"):ue.showMessage("定位讲稿备注块失败")}async function l(){var v;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ue.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const f=await sc(h,ba);if(f.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${f.notes.split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,m),await He(m,{[Ve]:"true"}),Pe.setBlockAttrOverride(m,{[Ve]:"true"}),ji(m,(v=e.plugin)==null?void 0:v.app)}else await s(f.notes);f.isAiGenerated?ue.showMessage("思源 AI 演讲提词卡生成成功！"):ue.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){ue.showMessage("当前文档无幻灯片页面");return}const f=h.map((b,y)=>({slide:b,idx:y})).filter(({slide:b})=>{var x;const y=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,S=!!((x=b.notes)!=null&&x.trim());return!y&&!S});if(f.length===0){ue.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const v=f.length;ue.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${v} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var y,S,x,w,$,T;if(i.value)return;i.value=!0,ue.showMessage("正在批量追加讲稿块...");let b=0;try{const F=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(W=>`> ${W}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:W,idx:K}of f)try{let _=null;if(K<h.length-1){const k=h[K+1];_=await Oi("markdown",F,k.startBlockId)}else{const k=((y=W==null?void 0:W.noteBlocks)==null?void 0:y.slice(-1)[0])||((S=W==null?void 0:W.blocks)==null?void 0:S.slice(-1)[0]),E=(k==null?void 0:k.id)||(W==null?void 0:W.startBlockId);E?_=await Oi("markdown",F,void 0,E):_=await bo("markdown",F,e.currentDocId.value)}const j=(($=(w=(x=_==null?void 0:_[0])==null?void 0:x.doOperations)==null?void 0:w[0])==null?void 0:$.id)||((T=_==null?void 0:_[0])==null?void 0:T.id);j&&(await He(j,{[Ve]:"true"}),Pe.setBlockAttrOverride(j,{[Ve]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${K+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ue.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var b;if(i.value)return;const h=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(h.length===0){ue.showMessage("当前文档无幻灯片页面");return}const f=[];for(const y of h)if(y.noteBlocks&&y.noteBlocks.length>0)for(const S of y.noteBlocks)S.id&&f.push({id:S.id,pageIndex:y.pageIndex});if(f.length===0){ue.showMessage("当前文档中没有讲稿备注块，无需删除");return}const v=new Set(f.map(y=>y.pageIndex)).size,m=f.length;ue.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${v} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ue.showMessage("正在批量删除讲稿块...");let y=0;try{for(const S of f)try{await va(S.id),Pe.clearBlockAttrOverride(S.id),y++}catch(x){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${S.id} 失败:`,x)}e.activeBlockId.value&&f.some(S=>S.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ve],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功删除全部 ${y} 个讲稿备注块`)}catch(S){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",S),ue.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var f;const h=e.currentDocId.value||((f=e.plugin)==null?void 0:f.currentDocId);if(!h){ue.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ue.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await oc(h,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:d}}function gw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const n=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(n)}function vw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function bw(e){const t=[],i=n=>{var s,o,a,r,l,c,u,d,h,f,v;for(const m of n){if(!m||m.isNote||((s=m.attributes)==null?void 0:s[Ve])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[Ve])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(gw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[ze])||((c=m.ial)==null?void 0:c[ze]),rawBlock:m});continue}if(vw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[ze])||((d=m.ial)==null?void 0:d[ze]),rawBlock:m});continue}const b=m.children&&m.children.length>0?m.children:(h=m.rawNode)==null?void 0:h.children;if(Array.isArray(b)&&b.length>0){i(b);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((f=m.attributes)==null?void 0:f[ze])||((v=m.ial)==null?void 0:v[ze]),rawBlock:m})}};return i(e||[]),t}function yw(e){var s;if(e.pageIndex===1||((s=e.frontmatter)==null?void 0:s.layout)==="cover")return[];const t=bw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const n=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&n.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return n}async function kw(e,t){const n=await((t==null?void 0:t.compileDocFn)||(a=>Pe.compile(a)))(e).catch(()=>null);if(!n||!Array.isArray(n.slides)||n.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const s=[],o=new Set;for(const a of n.slides){const r=yw(a);r.length>0&&(s.push(...r),o.add(a.pageIndex))}return{totalPages:n.slides.length,animatedPagesCount:o.size,targets:s}}async function rc(e,t){const i=(t==null?void 0:t.showMessageFn)||ue.showMessage,n=(t==null?void 0:t.confirmFn)||ue.confirm,s=(t==null?void 0:t.setBlockAttrsFn)||He,o=(t==null?void 0:t.syncDomFn)||Je;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await kw(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{n("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var h;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,d=0;for(const f of a.targets)try{await s(f.blockId,{[ze]:f.targetClick}),Pe.setBlockAttrOverride(f.blockId,{[ze]:f.targetClick}),o(f.blockId,{[ze]:f.targetClick}),u++}catch(v){console.error(`[SiYuanLiveSlides] 为块 ${f.blockId} 配置动效失败:`,v),d++}(h=t==null?void 0:t.onSuccessNotice)==null||h.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:d})},()=>{c({...a,successCount:0,errorCount:0})})})}function ww(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Pi]:"true",[Xi]:"true"}),e.activeBlockAttrs.value[Pi]="true",e.activeBlockAttrs.value[Xi]="true"):(await i(Pi,"false"),e.activeBlockAttrs.value[Pi]="false")}async function a(){const D=e.videoLoop.value?"false":"true";await i(ws,D)}async function r(){const D=e.videoMuted.value?"false":"true";await i(Xi,D)}async function l(){const D=e.videoControls.value?"false":"true";await i(xs,D)}async function c(D){var j;const F=e.activeBlockId.value;if(!F)return;const W=e.rawSnippet.value||"",K=_i(W)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(D)if(D==="background"){const k={[Ze]:"background",[we]:""};_&&K&&(e.pageBackground.value=K,await He(_,{[nt]:K}).catch(()=>{}),Pe.setBlockAttrOverride(_,{[nt]:K}),Je(_,{[nt]:K}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=K)),await n(k)}else(D===Ss||D===Cs)&&await n({[we]:D,[Ze]:""});else{const k={[Ze]:"",[we]:""};if(e.activeBlockAttrs.value[nt]==="true"&&(k[nt]=""),_&&K&&e.pageBackground.value===K&&(e.pageBackground.value="",await He(_,{[nt]:""}).catch(()=>{}),Pe.setBlockAttrOverride(_,{[nt]:""}),Je(_,{[nt]:""}),(j=e.targetSlide.value)!=null&&j.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(k),typeof document<"u"){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`),N=E==null?void 0:E.closest('[data-type="NodeListItem"]'),B=N==null?void 0:N.getAttribute("data-node-id");if(B&&B!==F){const L={[we]:"",[Ze]:""};Je(B,L),Pe.setBlockAttrOverride(B,L),await He(B,L).catch(()=>{})}}}}function u(){e.elemClick.value?i(ze,""):i(ze,"+1")}function d(D){i(ze,D)}function h(D){i(Jt,D)}function f(D){(e.activeBlockAttrs.value[Me]||"")===D?i(Me,""):i(Me,D)}function v(D){e.elemShikiLines.value=D,i(Ui,D)}function m(D){e.elemMaxHeight.value=D,i(zn,D)}async function b(){const D=e.currentSlideLayout.value==="three-cols-header";await i(Me,D?"col-1":"left"),ue.showMessage(D?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const D=e.activeBlockId.value;if(!D)return;const F={[ze]:"",[Jt]:"",[Me]:"",[Ui]:"",[zn]:"",[Ve]:"","slides-note":"",[we]:"",[kt]:"",[Ze]:"",[mt]:"",[nt]:"",[Pt]:"",[Pi]:"",[ws]:"",[Xi]:"",[xs]:""};if(Je(D,F),await He(D,F),Pe.clearBlockAttrOverride(D),typeof document<"u"){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${D}"]`),K=W==null?void 0:W.closest('[data-type="NodeListItem"]'),_=K==null?void 0:K.getAttribute("data-node-id");_&&_!==D&&(Je(_,F),await He(_,F).catch(()=>{}),Pe.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",ue.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function S(){if(e.activeBlockId.value)try{await Oi("markdown","---",e.activeBlockId.value,void 0),ue.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function x(){const D=e.activeBlockId.value||e.currentDocId.value;if(D)try{await Oi("markdown","---",void 0,D),ue.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function w(){if(e.activeBlockId.value)try{await va(e.activeBlockId.value),ue.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("删除失败")}}async function $(){var D,F;try{let W=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);j&&(W=j.getAttribute("data-type")==="NodeSuperBlock"?j:j.closest('[data-type="NodeSuperBlock"]'))}if(!W){const j=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(j){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);if(k){let E=k.nextElementSibling;for(;E&&!(E.getAttribute("data-type")==="NodeThematicBreak"||(D=E.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));){const N=E.getAttribute("data-type")==="NodeSuperBlock"?E:E.querySelector('[data-type="NodeSuperBlock"]');if(N){W=N;break}E=E.nextElementSibling}}}else{const k=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),E=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const N of E)if(!k||N.compareDocumentPosition(k)&Node.DOCUMENT_POSITION_FOLLOWING){W=N;break}}}}const K=[];if(W){const _=Array.from(W.querySelectorAll(":scope > [data-node-id]"));for(const j of _){const k=j.getAttribute("data-node-id");k&&(K.push(k),j.removeAttribute("style"))}}else if((F=e.targetSlide.value)!=null&&F.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const j of _.children)j.id&&K.push(j.id);break}}if(K.length>0)for(const _ of K)await He(_,{style:""}).catch(()=>{});await s(kt,""),ue.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(W){console.error("[layout-actions] resetSuperBlockWidth error:",W),ue.showMessage("重置超级块比例失败")}}async function T(){var D,F,W;try{let K=null;if(typeof document<"u"){const j=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),k=e.activeBlockId.value;let E=[];if(j){const L=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);if(L){let R=L.nextElementSibling;for(;R&&!(R.getAttribute("data-type")==="NodeThematicBreak"||(D=R.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));)E.push(R),R=R.nextElementSibling}}else{const L=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),R=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const de of R)if(!L||de.compareDocumentPosition(L)&Node.DOCUMENT_POSITION_FOLLOWING)E.push(de);else break}const N=[];let B;for(const L of E){const R=L.getAttribute("data-type");R==="NodeHeading"&&(B=L.getAttribute("data-node-id")||void 0);const de=[];R==="NodeSuperBlock"?de.push(L):de.push(...Array.from(L.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const V of de){if((V.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const Z=V.getAttribute("data-node-id")||"";let ne=[];const oe=Array.from(V.querySelectorAll('[data-type="NodeListItem"]'));if(oe.length===4&&(ne=oe.map(ye=>ye.getAttribute("data-node-id")).filter(Boolean)),ne.length!==4){const ye=Array.from(V.querySelectorAll(":scope > [data-node-id]"));ye.length===4&&(ne=ye.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}ne.length===4&&N.push({sbId:Z,itemIds:ne,headerId:B})}}N.length>0&&(k&&(K=N.find(L=>{if(L.sbId===k||L.itemIds.includes(k))return!0;const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${L.sbId}"]`),de=document.querySelector(`.protyle-wysiwyg [data-node-id="${k}"]`);return!!(R&&de&&R.contains(de))})||null),K||(K=N[0]))}if(!K&&((F=e.targetSlide.value)!=null&&F.blocks)){const j=e.targetSlide.value,k=[];for(const N of j.blocks)N.rawNode?k.push(N.rawNode):k.push({id:N.id,type:N.type,content:N.content,markdown:N.rawMarkdown,children:N.children,ial:N.attributes||N.ial||{}});const E=Yf(k,e.activeBlockId.value);E&&E.items.length===4&&(K={sbId:E.superBlockNode.id,itemIds:E.items.map(N=>N.id),headerId:(W=E.headerNode)==null?void 0:W.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(_,{[we]:"clover"}),Je(_,{[we]:"clover"}),await He(_,{[we]:"clover"}).catch(()=>{})),K&&K.itemIds.length>0){K.headerId&&(Pe.setBlockAttrOverride(K.headerId,{[Me]:"header"}),Je(K.headerId,{[Me]:"header"}),await He(K.headerId,{[Me]:"header"}).catch(()=>{}));const j=Math.min(4,K.itemIds.length);for(let k=0;k<j;k++){const E=K.itemIds[k],N=`col-${k+1}`;Pe.setBlockAttrOverride(E,{[Me]:N}),Je(E,{[Me]:N}),await He(E,{[Me]:N}).catch(()=>{})}}return ue.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(K){return console.error("[layout-actions] applyCloverLayout error:",K),ue.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var F,W;const D=e.currentDocId.value||((F=e.plugin)==null?void 0:F.currentDocId);if(!D){ue.showMessage("请先在主编辑区打开幻灯片文档");return}if((W=t.isBatchProcessing)!=null&&W.value){ue.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await rc(D,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:d,onElemMotionChange:h,onElemSlotChange:f,onElemShikiLinesChange:v,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:S,onInsertDividerAfter:x,onDeleteCurrentBlock:w,resetSuperBlockWidth:$,applyCloverLayout:T,onAutoAnimateDocument:C}}function xw(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a}=cw(e),r=mw(e,{triggerSaveNotice:t}),l=ww(e,{saveAttr:n,saveAttrs:i,savePageAttr:s,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const f=e.latestDoc.value,v=await Wi(f,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Vl(f);Gl(`${v}.html`,m)&&ue.showMessage(`已开始下载单文件离线 HTML 演示包 (${v}.html)`)}function u(){if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}Kl(e.latestDoc.value)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const d=ge(!1);async function h(){var f;if(d.value){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}d.value=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const v=e.latestDoc.value,m=await Wi(v,(f=e.currentDocId)==null?void 0:f.value,e.plugin),b=await Xl(v,{title:m,onProgress:(y,S)=>{ue.showMessage(`正在导出幻灯片图片 (${y} / ${S})...`,2e3)}});b.success?ue.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ue.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{d.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:d,onExportHtml:c,onExportPdf:u,onExportImages:h}}function Sw(e){const t=be(()=>hr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:a="defined"}=n,r=l=>a==="truthy"?l:l!==void 0;return be(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Pe.getBlockAttrOverride(l);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function Cw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const a=e[o];if(Kn(a)){s=0;continue}const r=a.markdown||a.content||"";if(!(o===0)){if(a.type==="h"&&(a.subType==="h1"||r.startsWith("# "))){i.push({blockId:a.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(a.type==="h"&&(a.subType==="h2"||r.startsWith("## "))){i.push({blockId:a.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];Kn(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}async function ac(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}const t=await Yn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ue.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Cw(i);if(n.length===0){ue.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ue.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Oi("markdown","---",void 0,o.blockId),await He(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(a){console.warn("Failed to insert divider:",a)}ue.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const _w={class:"spm-slides-inspector"},$w={class:"spm-inspector-topbar"},Iw={class:"spm-inspector-title"},Mw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Tw={class:"spm-inspector-topbar-actions"},Ew={class:"spm-target-banner"},Aw={class:"spm-target-info"},Bw=["aria-label"],Dw={key:0,class:"spm-save-status"},Lw=["title"],Pw={class:"spm-inspector-body"},Ow=Et({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=Rt("plugin"),n=ge(!1);function s(ee){n.value=!1,c.value=ee.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(ee.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),u=ge(""),d=ge(""),h=ge(""),f=ge(""),v=ge(""),m=ge(""),b=ge(null),y=ge(""),S=ge("");function x(){var ve;const ee=o.value||c.value;ee&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(ee).then(()=>{S.value="已复制！",setTimeout(()=>{S.value=""},1500)}).catch(()=>{})}const w=be(()=>hr(a.value)),$=be(()=>a.value==="NodeCodeBlock"),T=ge(!1),C=be(()=>{if(T.value||pe.value)return!0;const ee=l.value||"";return!!_i(ee)}),D=be(()=>{const ee=a.value||"";if(ee==="NodeVideo"||ee==="video")return!0;const ve=l.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),F=be(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),W=be(()=>{const ee=o.value||c.value||"";return ee.length>8?ee.slice(-8):ee||"无"}),K=be(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=be(()=>{if(w.value)return"分页符 (---)";if(F.value)return"全局文档";if(D.value)return"视频块";let ee="内容块";switch(a.value){case"NodeHeading":ee="标题块";break;case"NodeParagraph":ee="段落块";break;case"NodeCodeBlock":ee="代码块";break;case"NodeVideo":ee="视频块";break;case"NodeList":case"NodeListItem":ee="列表项";break;case"NodeBlockquote":ee="引述块";break;case"NodeTable":ee="表格块";break;case"NodeSuperBlock":case"s":case"sb":ee="超级块";break;default:ee="内容块";break}return f.value?v.value?`${v.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ee}`:`分栏容器 › ${ee}`:ee}),j=be(()=>w.value?"tag-divider":F.value?"tag-doc":"tag-block"),k=be(()=>r.value[we]||"default"),E=be(()=>r.value[mt]||"slide-left"),N=ge(""),B=ge(""),L=be(()=>r.value[$n]||"inherit"),R=be(()=>{var ee;return rw((ee=b.value)==null?void 0:ee.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:d.value,activeBlockAttrs:r.value})}),de=be(()=>{var ee;return((ee=R.value)==null?void 0:ee.notes)||""}),V=be(()=>{var ee,ve,Ae;return((Ae=(ve=(ee=R.value)==null?void 0:ee.noteBlocks)==null?void 0:ve[0])==null?void 0:Ae.id)||""}),Y=be(()=>{var We,Ue,Ne,ut,ts,gi;if(w.value){const tt=r.value[we]||r.value["custom-slides-layout"];if(tt)return tt}const ee=r.value[Me]||r.value["custom-slides-slot"];if(ee&&(["col-1","col-2","col-3"].includes(ee)||/^col-\d+$/.test(ee)))return"cols-header";if(h.value)return h.value;const ve=d.value||(w.value?o.value:"");if(ve){const tt=Pe.getBlockAttrOverride(ve);if(tt!=null&&tt[we])return tt[we]}if(ve&&((We=b.value)!=null&&We.slides)){const tt=b.value.slides.find(qi=>qi.startBlockId===ve);if((Ue=tt==null?void 0:tt.frontmatter)!=null&&Ue.layout)return tt.frontmatter.layout}if((ut=(Ne=R.value)==null?void 0:Ne.frontmatter)!=null&&ut.layout)return R.value.frontmatter.layout;if((gi=(ts=R.value)==null?void 0:ts.blocks)!=null&&gi.some(tt=>tt.slot&&(["col-1","col-2","col-3"].includes(tt.slot)||/^col-\d+$/.test(tt.slot))))return"cols-header";const Ae=Pe.getBlockAttrOverride(c.value);return Ae!=null&&Ae[we]?Ae[we]:"default"}),Z=Sw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:d}),ne=Z.resolvePageAttr({attrKey:kt,mode:"truthy",fallback:()=>{var ee,ve;return((ve=(ee=R.value)==null?void 0:ee.frontmatter)==null?void 0:ve.layoutRatio)||""}}),oe=Z.resolvePageAttr({attrKey:en,fallback:()=>{var ee,ve;return((ve=(ee=R.value)==null?void 0:ee.frontmatter)==null?void 0:ve.mask)||""}}),ye=Z.resolvePageAttr({attrKey:Ni,fallback:()=>{var ee,ve;return((ve=(ee=R.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskRatio)||""}}),Ie=Z.resolvePageAttr({attrKey:tn,fallback:()=>{var ee,ve;return((ve=(ee=R.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),Ce=Z.resolvePageAttr({attrKey:nn,fallback:()=>{var ee,ve;return((ve=(ee=R.value)==null?void 0:ee.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function le(ee){if(!ee||(ee.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(ee.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const We=Ae.length,Ue=Ae.map(gi=>{const tt=gi.getAttribute("style")||"",qi=tt.match(/calc\(\s*([\d.]+)%/);if(qi)return parseFloat(qi[1]);const bn=tt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return bn?parseFloat(bn[1]):null});let Ne="",ut=!1;if(Ue.some(gi=>gi!==null)){ut=!0;const gi=Ue.reduce((Oe,ft)=>Oe+(ft||0),0),tt=Ue.filter(Oe=>Oe===null).length,qi=tt>0?Math.max(0,100-gi)/tt:100/Ae.length,bn=Ue.map(Oe=>Oe!==null?Oe:qi),Jc=bn.reduce((Oe,ft)=>Oe+ft,0)||1,yn=bn.map(Oe=>Oe/Jc*100);if(yn.length===2){const[Oe]=yn;if(Oe>=48&&Oe<=52)Ne="1:1";else if(Oe>=31&&Oe<=35)Ne="1:2";else if(Oe>=65&&Oe<=69)Ne="2:1";else if(Oe>=28&&Oe<=32)Ne="3:7";else if(Oe>=68&&Oe<=72)Ne="7:3";else if(Oe>=38&&Oe<=42)Ne="4:6";else if(Oe>=58&&Oe<=62)Ne="6:4";else{const ft=Math.round(Oe);Ne=`${ft}:${100-ft}`}}else if(yn.length===3){const[Oe,ft,vi]=yn;if(Oe>=31&&Oe<=35&&ft>=31&&ft<=35&&vi>=31&&vi<=35)Ne="1:1:1";else if(Oe>=23&&Oe<=27&&ft>=48&&ft<=52&&vi>=23&&vi<=27)Ne="1:2:1";else if(Oe>=48&&Oe<=52&&ft>=23&&ft<=27&&vi>=23&&vi<=27)Ne="2:1:1";else if(Oe>=23&&Oe<=27&&ft>=23&&ft<=27&&vi>=48&&vi<=52)Ne="1:1:2";else{const yr=Math.round(Oe),kr=Math.round(ft);Ne=`${yr}:${kr}:${100-yr-kr}`}}else Ne=yn.map(Oe=>Math.round(Oe)).join(":")}else ut=!1,Ne=Array.from({length:We},()=>1).join(":");const ts=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Ne,isCustomWidth:ut,recommendedLayout:ts}}function X(ee){if(!(ee!=null&&ee.blocks))return null;for(const ve of ee.blocks){const Ae=ve.rawNode;if(Ae&&ot(Ae)&&Qt(Ae)){const Ue=gn(Ae).length,Ne=cr(Ae);return{hasSuperBlock:!0,colCount:Ue,ratio:Ne||Array.from({length:Ue},()=>1).join(":"),isCustomWidth:!!Ne,recommendedLayout:Ue>=2?"cols-header":"two-cols"}}}return null}const ce=be(()=>{var ee;if(typeof document<"u"){const ve=o.value;if(ve){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(We){const Ue=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(Ue){const Ne=le(Ue);if(Ne)return Ne}}}const Ae=d.value||(w.value?o.value:"");if(Ae){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(We){let Ue=We.nextElementSibling;for(;Ue&&!(Ue.getAttribute("data-type")==="NodeThematicBreak"||(ee=Ue.classList)!=null&&ee.contains("protyle-wysiwyg__block--hr"));){const Ne=Ue.getAttribute("data-type")==="NodeSuperBlock"?Ue:Ue.querySelector('[data-type="NodeSuperBlock"]');if(Ne){const ut=le(Ne);if(ut)return ut}Ue=Ue.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ue=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Ne of Ue)if(!We||Ne.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=le(Ne);if(ut)return ut}}}return X(R.value)}),P=be(()=>{var ee;return((ee=ce.value)==null?void 0:ee.ratio)||""}),U=be(()=>{const ee=a.value||"";if(ee==="NodeSuperBlock"||ee==="s"||ee==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=be(()=>{var ee;return((ee=R.value)==null?void 0:ee.pageIndex)||1}),G=be(()=>!!(r.value[Ve]||r.value["slides-note"]));function H(){if(!f.value)return!1;if(o.value===f.value||typeof document>"u")return!0;const ee=document.querySelector(`.protyle-wysiwyg [data-node-id="${f.value}"]`)||document.querySelector(`[data-node-id="${f.value}"]`);if(!ee)return!1;const ve=ee.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const I=be(()=>{var ve;if(r.value[ze]!==void 0)return r.value[ze]||"";if(f.value&&H())return m.value||"";if(f.value)return"";const ee=o.value;if(ee&&((ve=R.value)!=null&&ve.blocks)){const Ae=R.value.blocks.find(We=>We.id===ee);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),M=be(()=>{var ve;if(r.value[Jt])return r.value[Jt];const ee=o.value;if(ee&&((ve=R.value)!=null&&ve.blocks)){const Ae=R.value.blocks.find(We=>We.id===ee);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),O=be(()=>{var ve;if(r.value[Me])return r.value[Me];const ee=o.value;if(ee&&((ve=R.value)!=null&&ve.blocks)){const Ae=R.value.blocks.find(We=>We.id===ee);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),q=ge(""),A=ge(""),z=be(()=>r.value[Pi]==="true"),J=be(()=>r.value[ws]==="true"),ie=be(()=>r.value[Xi]==="true"),se=be(()=>r.value[xs]!=="false"),me=be(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.theme)||r.value[On]||"default"}),$e=be(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.aspectRatio)||r.value[Rn]||"16/9"}),Se=be(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.defaultTransition)||r.value[Nn]||"slide-left"}),re=be(()=>{var ee,ve;return((ve=(ee=b.value)==null?void 0:ee.config)==null?void 0:ve.spacing)||r.value[wo]||"normal"}),pe=be(()=>{var Ue,Ne;if((r.value[Ze]||r.value["slides-role"])===xa||r.value[nt]==="true")return"background";const ve=r.value[we]||r.value["slides-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ae=l.value||"",We=_i(Ae);if(We&&((Ne=(Ue=R.value)==null?void 0:Ue.frontmatter)!=null&&Ne.background)){const ut=R.value.frontmatter.background;if(ut===We||ut.endsWith(We)||We.endsWith(ut))return"background"}return""}),Le=be(()=>!!(r.value[ze]||r.value[Jt]||r.value[Me]||r.value[Ui]||r.value[Ve]||r.value["slides-note"]||r.value[Ze]||r.value[we]||r.value[Pi]||r.value[ws]||r.value[Xi]||r.value[xs])),{saveAttr:Re,savePageAttr:Be,applyPageLayoutAndRatio:rt,applyCloverLayout:Qe,resetSuperBlockWidth:et,saveDocAttr:Ft,onToggleVideoAutoplay:Gi,onToggleVideoLoop:Ys,onToggleVideoMuted:Zs,onToggleVideoControls:es,onImageRoleChange:Ii,onToggleNoteBlock:Ki,onAddNoteBlock:fc,onLocateNoteBlock:pc,onGenerateNotesWithAI:hc,isBatchProcessing:mr,onBatchAppendNotes:mc,onBatchDeleteNotes:gc,onIdentifyNotesBlocks:vc,onAutoAnimateDocument:bc,toggleElemClick:yc,onElemClickStepChange:kc,onElemMotionChange:wc,onElemSlotChange:xc,onElemShikiLinesChange:Sc,onElemMaxHeightChange:Cc,onSetTwoColsContrast:_c,onClearBlockAttrs:$c,onInsertDividerBefore:Ic,onInsertDividerAfter:gr,onDeleteCurrentBlock:Mc,onExportHtml:Tc,onExportPdf:Ec,onExportImages:Ac,isExportingImages:Bc}=xw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:d,currentPageDividerLayout:h,parentContainerId:f,parentContainerClicks:m,latestDoc:b,targetSlide:R,currentSlideNoteBlockId:V,currentSlideLayout:Y,isNoteBlock:G,elemClick:I,videoAutoplay:z,videoLoop:J,videoMuted:ie,videoControls:se,pageBackground:N,pageImage:B,elemShikiLines:q,elemMaxHeight:A,saveStatus:y,plugin:i});async function Dc(ee){if(ee==="clover"){if(!await Qe())return}else Re(we,ee)}function Lc(ee){Be(kt,ee)}async function Pc(ee){await Be(en,ee),(ee==="clockwise"||ee==="counter-clockwise"||ee==="cw"||ee==="ccw")&&(!ye.value||ye.value==="1:1")&&await Be(Ni,"1:1:1:1")}function Oc(ee){Be(Ni,ee)}function Rc(ee){Be(tn,ee)}function Nc(ee){Be(nn,ee)}function vr(ee){if(!ee)return;const ve=ee.recommendedLayout||(ee.colCount&&ee.colCount>=2?"cols-header":"two-cols"),Ae=ee.ratio||(ee.colCount?Array(ee.colCount).fill(1).join(":"):"1:1");rt(ve,Ae)}function zc(ee){Be(kt,ee)}async function Hc(){await et()}function Fc(ee){Re(mt,ee)}function jc(ee){N.value=ee,Re(nt,ee)}function Wc(ee){B.value=ee,Re(Pt,ee)}function Uc(ee){Re($n,ee==="inherit"?"":ee)}function Vc(ee){Ft(On,ee)}function Gc(ee){Ft(Rn,ee)}function Kc(ee){Ft(Nn,ee)}function qc(ee){Ft(wo,ee)}function br(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Yc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Zc(){i&&_t("aiScript")&&ac(i)}return t({setActiveBlock(ee){o.value=ee.id,a.value=ee.type,r.value={...ee.attrs},l.value=ee.content||ee.markdown||"",u.value=ee.topBlockId||ee.id,d.value=ee.pageDividerId||"",h.value=ee.pageDividerLayout||"",f.value=ee.parentContainerId||"",v.value=ee.parentContainerSlot||"",m.value=ee.parentContainerClicks||"",ee.rootId?c.value=ee.rootId:(ee.type==="doc"||ee.type==="NodeDocument")&&ee.id&&(c.value=ee.id),N.value=ee.attrs[nt]||"",B.value=ee.attrs[Pt]||"",q.value=ee.attrs[Ui]||"",A.value=ee.attrs[zn]||"",T.value=!!ee.isImage},updateDocument(ee){b.value=ee,c.value=ee.docId},openImportDialog(){n.value=!0},setCurrentDocId(ee){c.value=ee}}),(ee,ve)=>(Q(),te("div",_w,[p("div",$w,[p("div",Iw,[(Q(),te("svg",Mw,[...ve[2]||(ve[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=p("span",null,"演示配置",-1))]),p("div",Tw,[he(_t)("import")?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ae=>n.value=!0)},[ae(fe,{name:"import"}),ve[4]||(ve[4]=p("span",null,"导入",-1))])):Te("",!0),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:br},[ae(fe,{name:"split-preview"}),ve[5]||(ve[5]=p("span",null,"分屏预览",-1))])])]),p("div",Ew,[p("div",Aw,[p("span",{class:_e(["spm-target-tag",j.value])},xe(_.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":S.value||"点击复制 ID: "+(o.value||c.value),onClick:x},[ae(fe,{name:"copy"}),p("span",null,"#"+xe(W.value),1)],8,Bw)]),y.value?(Q(),te("span",Dw,"● "+xe(y.value),1)):Te("",!0)]),K.value?(Q(),te("div",{key:0,class:"spm-context-quote",title:l.value},xe(K.value),9,Lw)):Te("",!0),p("div",Pw,[w.value?(Q(),Zt(x1,{key:0,"page-layout":k.value,"page-layout-ratio":he(ne),"page-mask":he(oe),"page-mask-ratio":he(ye),"page-mask-style":he(Ie),"page-mask-initial":he(Ce),"detected-sb-ratio":P.value,"detected-sb-info":ce.value,"page-transition":E.value,"page-background":N.value,"page-spacing":L.value,"page-image":B.value,"page-notes":de.value,"page-index":g.value,"onUpdate:pageLayout":Dc,"onUpdate:pageLayoutRatio":Lc,"onUpdate:pageMask":Pc,"onUpdate:pageMaskRatio":Oc,"onUpdate:pageMaskStyle":Rc,"onUpdate:pageMaskInitial":Nc,onApplySuperBlockLayout:vr,onResetSuperblockRatio:Hc,"onUpdate:pageTransition":Fc,"onUpdate:pageBackground":jc,"onUpdate:pageSpacing":Uc,"onUpdate:pageImage":Wc,onAddNoteBlock:he(fc),onLocateNoteBlock:he(pc),onGenerateNotes:he(hc),onBatchAppendNotes:he(mc),onBatchDeleteNotes:he(gc),"is-batch-processing":he(mr),onInsertDividerAfter:he(gr),onDeleteDivider:he(Mc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!F.value?(Q(),Zt(r0,{key:1,"elem-click":I.value,"elem-motion":M.value,"elem-slot":O.value,"elem-shiki-lines":q.value,"elem-max-height":A.value,"is-code-block":$.value,"is-image":C.value,"is-video":D.value,"is-super-block":U.value,"detected-sb-info":ce.value,"video-autoplay":z.value,"video-loop":J.value,"video-muted":ie.value,"video-controls":se.value,"has-block-attrs":Le.value,"is-note":G.value,"image-role":pe.value,"current-slide-layout":Y.value,"parent-elem-click":m.value,"parent-container-slot":v.value,"parent-container-id":f.value,onToggleNote:he(Ki),onToggleElemClick:he(yc),onToggleVideoAutoplay:he(Gi),onToggleVideoLoop:he(Ys),onToggleVideoMuted:he(Zs),onToggleVideoControls:he(es),"onUpdate:imageRole":he(Ii),"onUpdate:elemClick":he(kc),"onUpdate:elemMotion":he(wc),"onUpdate:elemSlot":he(xc),"onUpdate:elemShikiLines":he(Sc),"onUpdate:elemMaxHeight":he(Cc),onApplySuperBlockLayout:vr,onApplySuperBlockRatio:zc,onInsertDividerBefore:he(Ic),onInsertDividerAfter:he(gr),onSetTwoColsContrast:he(_c),onClearBlockAttrs:he($c)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(Q(),Zt(sk,{key:2,"doc-theme":me.value,"doc-aspect-ratio":$e.value,"doc-default-transition":Se.value,"doc-spacing":re.value,"is-exporting-images":he(Bc),"is-batch-processing":he(mr),"onUpdate:docTheme":Vc,"onUpdate:docAspectRatio":Gc,"onUpdate:docDefaultTransition":Kc,"onUpdate:docSpacing":qc,onOpenBottomPreview:br,onOpenPresenter:Yc,onIdentifyNotes:he(vc),onAutoAnimate:he(bc),onAiAutoSplit:Zc,onExportHtml:he(Tc),onExportPdf:he(Ec),onExportImages:he(Ac)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&he(_t)("import")?(Q(),Zt(ow,{key:1,onClose:ve[1]||(ve[1]=Ae=>n.value=!1),onSuccess:s})):Te("",!0)]))}}),Rw=2e3,Nw=600;function zw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function mo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(pa(e))return!0;const t=e.firstElementChild;return!!(t&&pa(t))}function pa(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Hw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Fw{constructor(){ke(this,"consumers",new Map);ke(this,"seq",0);ke(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=Hw(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=mo(i),this.consumers.set(s,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?mo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!zw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&mo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Rw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new Fw,vn=new Qn;function lc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let wi=null,Bt=null,ys=null;function jw(){return Bt}function Ww(e,t){wi&&cc(),wi=ar(Pg),wi.provide("plugin",t),wi.provide("sandboxBridge",vn);const i=wi.mount(e);return Bt=i,ys=lc("preview",e,t),i}function cc(e){ys&&(ys(),ys=null),wi&&(wi.unmount(),wi=null,Bt=null)}function Uw(){return Bt!==null}let xi=null,Ri=null;function Vw(e,t){return xi&&dc(),xi=ar(Vv),xi.provide("plugin",t),xi.provide("sandboxBridge",vn),Ri=xi.mount(e),Ri}function dc(e){xi&&(xi.unmount(),xi=null,Ri=null)}function Gw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let Si=null,$t=null,ks=null;function Kw(e,t){Si&&uc(),Si=ar(Ow),Si.provide("plugin",t),Si.provide("sandboxBridge",vn);const i=Si.mount(e);return $t=i,ks=lc("dock",e,t),i}function uc(e){ks&&(ks(),ks=null),Si&&(Si.unmount(),Si=null,$t=null)}function qw(e,t){$t!=null&&$t.updateDocument&&$t.updateDocument(e),Bt!=null&&Bt.updateDocument?Bt.updateDocument(e,t):(vn.updateSlides(e.slides,e.config,e.fullMarkdown),Gw(e)),Ri!=null&&Ri.updateDocument&&Ri.updateDocument(e)}function Fo(e){Bt!=null&&Bt.navigateToBlock?Bt.navigateToBlock(e):vn.highlightElement(e)}function Ji(e){$t!=null&&$t.setActiveBlock&&$t.setActiveBlock(e)}function Yw(){return oi("import")?!1:$t!=null&&$t.openImportDialog?($t.openImportDialog(),!0):!1}const Zw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Li,value:"true"},{key:we,value:"cover"},{key:mt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Li,value:"true"},{key:we,value:"two-cols"},{key:mt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Li,value:"true"},{key:we,value:"fact"},{key:mt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Li,value:"true"},{key:we,value:"intro"},{key:mt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Li,value:"true"},{key:we,value:"quote"},{key:mt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:ze,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:ze,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ui,value:"1-3"}]}];class go{getPresetTemplates(){return Zw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${mt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${mt}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[mt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slides-layout' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{"custom-slides-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Jw(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),oi("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Yw()||ue.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await He(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ue.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),oi("aiScript")||e.addCommand({langKey:"slidesAiSplit",langText:"即现 AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>ac(e)}),oi("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,d;if(!e.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}ue.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Yn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await dw(i,ba)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slides-note="true"}`,a=await bo("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((d=a==null?void 0:a[0])==null?void 0:d.id);r&&(await He(r,{"custom-slides-note":"true"}),Pe.setBlockAttrOverride(r,{"custom-slides-note":"true"}),ji(r,e.app)),ue.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ue.showMessage("请先在主编辑区打开幻灯片文档");return}await oc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ue.showMessage("请先在主编辑区打开幻灯片文档");return}await rc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new go,i=t.buildTransitionStatsSql(),n=await cn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ue.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new go().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ue.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ue.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new go().batchUpdateTransitions("fade","slide-left",n=>cn(n).catch(()=>[]),(n,s)=>He(n,s));ue.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),oi("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),oi("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ue.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ue.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ue.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ue.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",ko);t.success?ue.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ue.showMessage(`同步失败：${t.error}`)}})),!oi("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await Wi(i,e.currentDocId,e),s=await Xl(i,{title:n,onProgress:(o,a)=>{ue.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});s.success?ue.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ue.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class Xw{constructor(t=400){ke(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Qw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class e2{constructor(t=150){ke(this,"lastBlockId","");ke(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class t2{constructor(){ke(this,"attrCache",new Xw);ke(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Pe.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const a=await jo(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Qw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Ji({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Fo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,u,d,h;if(!t){Pn();const f=typeof o=="number"&&o>0?o:1,v=((c=s==null?void 0:s.slides)==null?void 0:c[f-1])||((u=s==null?void 0:s.slides)==null?void 0:u[0]);if(v){const m=v.startBlockId||"",b=((d=v.frontmatter)==null?void 0:d.layout)||"",y={"custom-slides-layout":b,...v.frontmatter};return Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,s).then(S=>{S&&Object.keys(S).length>0&&Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...y,...S},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(n),!0}const a=ji(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,n,s);else{let f="",v="";if(s!=null&&s.slides){const m=s.slides.find(b=>{var y,S,x;return b.startBlockId===t||((y=b.blocks)==null?void 0:y.some(w=>w.id===t))||((S=b.allBlockIds)==null?void 0:S.includes(t))||((x=b.noteBlocks)==null?void 0:x.some(w=>w.id===t))});m!=null&&m.startBlockId&&(f=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(v=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(f&&!v){const b=Pe.getBlockAttrOverride(f);if(b!=null&&b[we]||b!=null&&b["custom-slides-layout"])v=b[we]||b["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(f,s);v=y[we]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Pe.setBlockAttrOverride(f,y)}}Ji({id:t,rootId:n,type:l||"NodeParagraph",attrs:m||{},pageDividerId:f,pageDividerLayout:v})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,n,s,o){var E,N,B,L,R,de,V,Y;let a=t,r=i,l=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const Z=c.getAttribute("data-node-id");if(Z){const ne=await this.resolveBlockAttrs(Z,o),oe=Pe.getBlockAttrOverride(Z)||{},ye={...ne,...oe};(ye[Ve]||ye["slides-note"])&&(a=c,r=Z,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,d=(u==null?void 0:u.getAttribute("data-node-id"))||r,h=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((E=u==null?void 0:u.classList)!=null&&E.contains("hr")),f=l==="NodeCodeBlock",v=((N=a.innerText)==null?void 0:N.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Pe.getBlockAttrOverride(r)||{},y={...m,...b};let S="",x="";if(h)S=r,x=y[we]||y["custom-slides-layout"]||"";else{let Z=u.previousElementSibling;for(;Z;){const ne=Z.getAttribute("data-type");if(ne==="NodeThematicBreak"||ne==="tb"||(B=Z.classList)!=null&&B.contains("hr")){S=Z.getAttribute("data-node-id")||"";break}Z=Z.previousElementSibling}}if(o!=null&&o.slides){const Z=[r,d];let ne=a.parentElement;for(;ne&&!ne.classList.contains("protyle-wysiwyg");){const ye=ne.getAttribute("data-node-id");ye&&!Z.includes(ye)&&Z.push(ye),ne=ne.parentElement}const oe=o.slides.find(ye=>{var Ie,Ce,le;return Z.includes(ye.startBlockId)||((Ie=ye.blocks)==null?void 0:Ie.some(X=>Z.includes(X.id)))||((Ce=ye.allBlockIds)==null?void 0:Ce.some(X=>Z.includes(X)))||((le=ye.noteBlocks)==null?void 0:le.some(X=>Z.includes(X.id)))});oe&&(!S&&oe.startBlockId&&(S=oe.startBlockId),!x&&((L=oe.frontmatter)!=null&&L.layout)&&(x=oe.frontmatter.layout))}if(S){const Z=Pe.getBlockAttrOverride(S);if(Z&&(we in Z||"custom-slides-layout"in Z)&&(x=Z[we]||Z["custom-slides-layout"]||""),!x&&(o!=null&&o.slides)){const ne=o.slides.find(oe=>oe.startBlockId===S);(R=ne==null?void 0:ne.frontmatter)!=null&&R.layout&&(x=ne.frontmatter.layout)}if(!x){const ne=await this.resolveBlockAttrs(S,o);x=ne[we]||ne["custom-slides-layout"]||"",ne&&Object.keys(ne).length>0&&Pe.setBlockAttrOverride(S,ne)}Je(S,{[we]:x||""})}else if(s){const Z=Pe.getBlockAttrOverride(s);Z&&(we in Z||"custom-slides-layout"in Z)?x=Z[we]||Z["custom-slides-layout"]||"":!x&&((Y=(V=(de=o==null?void 0:o.slides)==null?void 0:de[0])==null?void 0:V.frontmatter)!=null&&Y.layout)&&(x=o.slides[0].frontmatter.layout)}const w=a.getAttribute(we)||a.getAttribute("custom-slides-layout"),$=y[we]||y["custom-slides-layout"]||"";w&&w!==$&&Je(r,{[we]:$});const T=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=y[Ze]||y["custom-slides-role"]||"";T&&T!==C&&Je(r,{[Ze]:C});let D="",F="",W="";const K=a.closest('[data-type="NodeListItem"]');if(K&&K!==a){const Z=K.getAttribute("data-node-id");if(Z){D=Z;const ne=await this.resolveBlockAttrs(Z,o),oe=Pe.getBlockAttrOverride(Z)||{},ye={...ne,...oe};F=ye[Me]||"",W=ye[ze]||"";const Ie=ye[we]||ye["custom-slides-layout"]||"",Ce=K.getAttribute(we)||K.getAttribute("custom-slides-layout");Ce&&Ce!==Ie&&Je(Z,{[we]:Ie});const le=ye[Ze]||ye["custom-slides-role"]||"",X=K.getAttribute(Ze)||K.getAttribute("custom-slides-role");X&&X!==le&&Je(Z,{[Ze]:le})}}const _=!!a.querySelector("img, span[data-type='img']"),j=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=_&&j.length<=50;Ji({id:r,rootId:s,type:l,content:v,attrs:y,isDivider:h,isCode:f,isImage:k,topBlockId:d,pageDividerId:S,pageDividerLayout:x,parentContainerId:D,parentContainerSlot:F,parentContainerClicks:W})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},a={};for(const r of Object.keys(s))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");Je(n.id,a),Pe.setBlockAttrOverride(n.id,a)}}}}purgeStaleDomSlidesAttrs(t){var s,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(l[we]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[we]&&(c[we]=l.ial[we]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,l]of n.entries()){const c=i.get(r)||{};l[we]!==void 0&&(c[we]=l[we]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}aw(i)}}const Bi=new t2;class i2{constructor(){ke(this,"inFlightDocId",null);ke(this,"pendingDocId",null);ke(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const n2=150,s2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,o2="slides-dock",vo="slides-preview-tab",ha="slides-presenter-tab",ma=jf;class r2 extends ue.Plugin{constructor(){super(...arguments);ke(this,"isMobile",!1);ke(this,"currentDocId","");ke(this,"previewTab",null);ke(this,"latestCompiledDoc",null);ke(this,"cliBridge",new ur);ke(this,"debounceTimer",null);ke(this,"activeCursorBlockId","");ke(this,"cancelledCursorBlockId","");ke(this,"compileScheduler",new i2);ke(this,"dirtyDocId",null);ke(this,"inspectorSyncThrottle",new e2);ke(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ke(this,"onWsMainBound",this.onWsMain.bind(this));ke(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ke(this,"onEditorClickBound",this.onEditorClick.bind(this));ke(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ke(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ke(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ue.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(s2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Jw(this);const n=this;if(this.addTab({type:vo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,Ww(o.element,n);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!n.getActiveDocumentId()&&n.compileCurrentDocument(a,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),cc(this.element)}}),this.addTab({type:ha,init(s){Vw((this||s).element,n)},destroy(){dc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:o2,init(){Kw(this.element,n)},destroy(){uc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(ma),n=Wf(i);return si(n),n}catch{return si(Ci),Ci}}async saveGlobalSettings(i){const n=qs(),s=si({...n,...i||{}});try{await this.saveData(ma,s)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),vn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ue.openTab({app:this.app,custom:{id:this.name+vo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){oi("presenterMode")||(Uw()||await this.openBottomPreviewTab(),await ue.openTab({app:this.app,custom:{id:this.name+ha,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ue.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),a=await ue.openTab({app:this.app,custom:{id:this.name+vo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||a}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ue.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const n=(a=i.detail)==null?void 0:a.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((u=(c=(l=n==null?void 0:n.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const d=await jo(s).catch(()=>({}));Ji({id:s,rootId:s,type:"doc",attrs:d}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,a;const n=i==null?void 0:i.detail;if(!n)return;const s=(a=(o=n.protyle)==null?void 0:o.block)==null?void 0:a.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Yl(i)}async fetchDocumentTitle(i){return Zl(this,i)}async updatePreviewTabHeader(i,n){return mg(this,i,n)}getActiveDocumentId(){return Bi.getActiveDocumentId()}resolveDocIdFromElement(i){return Bi.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Bi.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Bi.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=n2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Nw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Bi.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const d=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),f=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,Fo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const d=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),f=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,f)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,Fo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Bi.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,qw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidesAttrs(i){Bi.purgeStaleDomSlidesAttrs(i)}}module.exports=r2;
