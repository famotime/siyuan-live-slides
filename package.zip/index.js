"use strict";var yd=Object.create;var eo=Object.defineProperty;var kd=Object.getOwnPropertyDescriptor;var wd=Object.getOwnPropertyNames;var xd=Object.getPrototypeOf,Sd=Object.prototype.hasOwnProperty;var Cd=(e,t,i)=>t in e?eo(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var _d=(e,t,i,s)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of wd(t))!Sd.call(e,n)&&n!==i&&eo(e,n,{get:()=>t[n],enumerable:!(s=kd(t,n))||s.enumerable});return e};var on=(e,t,i)=>(i=e!=null?yd(xd(e)):{},_d(t||!e||!e.__esModule?eo(i,"default",{value:e,enumerable:!0}):i,e));var be=(e,t,i)=>Cd(e,typeof t!="symbol"?t+"":t,i);const ae=require("siyuan");async function Ct(e,t){const i=await ae.fetchSyncPost(e,t);return i.code===0?i.data:null}async function $d(){return Ct("/api/notebook/lsNotebooks","")}async function Id(e,t,i){return Ct("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Ba(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const n of t)i.append("file[]",n);return Ct("/api/asset/upload",i)}async function Vi(e,t,i,s,n){return Ct("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:s,parentID:n})}async function So(e,t,i){return Ct("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function Co(e,t,i){return Ct("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function Go(e){return Ct("/api/block/deleteBlock",{id:e})}async function Md(e){return Ct("/api/block/getBlockKramdown",{id:e})}async function bs(e){return Ct("/api/block/getChildBlocks",{id:e})}async function Td(e){return Ct("/api/block/getDocBlocksOrders",{id:e})}async function He(e,t){return Ct("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Ko(e){return Ct("/api/attr/getBlockAttrs",{id:e})}async function hs(e){return Ct("/api/query/sql",{stmt:e})}async function _o(e,t,i){const s=new FormData;return s.append("path",e),s.append("isDir",t.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",i),Ct("/api/file/putFile",s)}async function Da(e){const t="/api/ai/chatGPT";try{const i=await Ct(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Ed(){return Ct("/api/storage/getInlineStyles","")}function Tr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function La(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(i))!==null;){const o=n[1],a=n[2]??n[3]??n[4]??"";t[o]=a}return t}const Pa=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ad(e){const t=[];if(!e)return t;const i=new RegExp(Pa.source,"g");let s;for(;(s=i.exec(e))!==null;){const n=s[2]??s[3]??s[4];t.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return t}function Bd(e,t){if(!e)return"";const i=new RegExp(Pa.source,"g");return e.replace(i,(s,n,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=l||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const js="custom-slides-theme",Ws="custom-slides-aspect-ratio",Oa="custom-slides-highlighter",Us="custom-slides-default-transition",Ra="custom-slides-color-schema",$o="custom-slides-spacing",Cn="custom-slides-background",Er="custom-slides-show-unordered-list-markers",Ar="custom-slides-show-ordered-list-markers",pi="custom-slides-slide",ke="custom-slides-layout",wt="custom-slides-transition",ct="custom-slides-background",jt="custom-slides-image",to="custom-slides-notes",ns="custom-slides-class",Bs="custom-slides-spacing",xt="custom-slides-layout-ratio",os="custom-slides-mask",Gi="custom-slides-mask-ratio",rs="custom-slides-mask-style",as="custom-slides-mask-initial",Ne="custom-slides-click",ii="custom-slides-motion",Xi="custom-slides-shiki-lines",Me="custom-slides-slot",qe="custom-slides-note",Ye="custom-slides-role",Vs="custom-slides-max-height",Ui="custom-slides-autoplay",_n="custom-slides-loop",ss="custom-slides-muted",$n="custom-slides-controls",Na="background",In="image-left",Mn="image-right";function ls(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Dd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],s=t===4?4:2;if(!e||typeof e!="string")return{steps:s,breakpoints:i};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:s,breakpoints:i};const o=n.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:s,breakpoints:i};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const a=o.every((h,d)=>d===0||h>o[d-1]),r=o[o.length-1];if(a&&(r===100||o.some(h=>h>10))){const h=o.map(d=>Math.min(100,Math.round(d*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,d)=>h+d,0);if(c<=0)return{steps:s,breakpoints:i};let u=0;const f=[];for(let h=0;h<o.length;h++)u+=o[h],h===o.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function za(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ha(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function At(e,t){if(!za(e))return e;const i=Ha(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Ld(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,o)=>{const a=At(o,t);return`![${n}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,o,a)=>{const r=At(o,t);return`${n}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,o,a)=>{const r=At(o,t);return`${n}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Yo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ze={},cs=[],si=()=>{},Fa=()=>!1,zn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Hn=e=>e.startsWith("onUpdate:"),mt=Object.assign,Zo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Pd=Object.prototype.hasOwnProperty,We=(e,t)=>Pd.call(e,t),Ee=Array.isArray,ds=e=>Qs(e)==="[object Map]",ys=e=>Qs(e)==="[object Set]",Br=e=>Qs(e)==="[object Date]",Be=e=>typeof e=="function",ot=e=>typeof e=="string",Vt=e=>typeof e=="symbol",Ge=e=>e!==null&&typeof e=="object",ja=e=>(Ge(e)||Be(e))&&Be(e.then)&&Be(e.catch),Wa=Object.prototype.toString,Qs=e=>Wa.call(e),Od=e=>Qs(e).slice(8,-1),Ua=e=>Qs(e)==="[object Object]",Jo=e=>ot(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Ds=Yo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Fn=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Rd=/-\w/g,Tt=Fn(e=>e.replace(Rd,t=>t.slice(1).toUpperCase())),Nd=/\B([A-Z])/g,Ni=Fn(e=>e.replace(Nd,"-$1").toLowerCase()),jn=Fn(e=>e.charAt(0).toUpperCase()+e.slice(1)),io=Fn(e=>e?`on${jn(e)}`:""),Qt=(e,t)=>!Object.is(e,t),hn=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Va=(e,t,i,s=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:s,value:i})},Wn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Dr;const Un=()=>Dr||(Dr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Nt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const s=e[i],n=ot(s)?jd(s):Nt(s);if(n)for(const o in n)t[o]=n[o]}return t}else if(ot(e)||Ge(e))return e}const zd=/;(?![^(]*\))/g,Hd=/:([^]+)/,Fd=/\/\*[^]*?\*\//g;function jd(e){const t={};return e.replace(Fd,"").split(zd).forEach(i=>{if(i){const s=i.split(Hd);s.length>1&&(t[s[0].trim()]=s[1].trim())}}),t}function $e(e){let t="";if(ot(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const s=$e(e[i]);s&&(t+=s+" ")}else if(Ge(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Wd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Ud=Yo(Wd);function qa(e){return!!e||e===""}function Vd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let s=0;i&&s<e.length;s++)i=ks(e[s],t[s]);return i}function ks(e,t){if(e===t)return!0;let i=Br(e),s=Br(t);if(i||s)return i&&s?e.getTime()===t.getTime():!1;if(i=Vt(e),s=Vt(t),i||s)return e===t;if(i=Ee(e),s=Ee(t),i||s)return i&&s?Vd(e,t):!1;if(i=Ge(e),s=Ge(t),i||s){if(!i||!s)return!1;const n=Object.keys(e).length,o=Object.keys(t).length;if(n!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!ks(e[a],t[a]))return!1}}return String(e)===String(t)}function Xo(e,t){return e.findIndex(i=>ks(i,t))}const Ga=e=>!!(e&&e.__v_isRef===!0),we=e=>ot(e)?e:e==null?"":Ee(e)||Ge(e)&&(e.toString===Wa||!Be(e.toString))?Ga(e)?we(e.value):JSON.stringify(e,Ka,2):String(e),Ka=(e,t)=>Ga(t)?Ka(e,t.value):ds(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[s,n],o)=>(i[so(s,o)+" =>"]=n,i),{})}:ys(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>so(i))}:Vt(t)?so(t):Ge(t)&&!Ee(t)&&!Ua(t)?String(t):t,so=(e,t="")=>{var i;return Vt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let pt;class qd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&pt&&(pt.active?(this.parent=pt,this.index=(pt.scopes||(pt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}const s=this.effects.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}}run(t){if(this._active){const i=pt;try{return pt=this,t()}finally{pt=i}}}on(){++this._on===1&&(this.prevScope=pt,pt=this)}off(){if(this._on>0&&--this._on===0){if(pt===this)pt=this.prevScope;else{let t=pt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,s;for(i=0,s=this.effects.length;i<s;i++)this.effects[i].stop();for(this.effects.length=0,i=0,s=this.cleanups.length;i<s;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(i=0,s=n.length;i<s;i++)n[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Gd(){return pt}let Xe;const no=new WeakSet;class Ya{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,pt&&(pt.active?pt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,no.has(this)&&(no.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Ja(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Lr(this),Xa(this);const t=Xe,i=Wt;Xe=this,Wt=!0;try{return this.fn()}finally{Qa(this),Xe=t,Wt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)tr(t);this.deps=this.depsTail=void 0,Lr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?no.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Io(this)&&this.run()}get dirty(){return Io(this)}}let Za=0,Ls,Ps;function Ja(e,t=!1){if(e.flags|=8,t){e.next=Ps,Ps=e;return}e.next=Ls,Ls=e}function Qo(){Za++}function er(){if(--Za>0)return;if(Ps){let t=Ps;for(Ps=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Ls;){let t=Ls;for(Ls=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(s){e||(e=s)}t=i}}if(e)throw e}function Xa(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Qa(e){let t,i=e.depsTail,s=i;for(;s;){const n=s.prevDep;s.version===-1?(s===i&&(i=n),tr(s),Kd(s)):t=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}e.deps=t,e.depsTail=i}function Io(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(el(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function el(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===qs)||(e.globalVersion=qs,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!Io(e))))return;e.flags|=2;const t=e.dep,i=Xe,s=Wt;Xe=e,Wt=!0;try{Xa(e);const n=e.fn(e._value);(t.version===0||Qt(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=i,Wt=s,Qa(e),e.flags&=-3}}function tr(e,t=!1){const{dep:i,prevSub:s,nextSub:n}=e;if(s&&(s.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=s,e.nextSub=void 0),i.subs===e&&(i.subs=s,!s&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)tr(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Kd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Wt=!0;const tl=[];function ki(){tl.push(Wt),Wt=!1}function wi(){const e=tl.pop();Wt=e===void 0?!0:e}function Lr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Xe;Xe=void 0;try{t()}finally{Xe=i}}}let qs=0;class Yd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ir{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!Wt||Xe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Xe)i=this.activeLink=new Yd(Xe,this),Xe.deps?(i.prevDep=Xe.depsTail,Xe.depsTail.nextDep=i,Xe.depsTail=i):Xe.deps=Xe.depsTail=i,il(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const s=i.nextDep;s.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=s),i.prevDep=Xe.depsTail,i.nextDep=void 0,Xe.depsTail.nextDep=i,Xe.depsTail=i,Xe.deps===i&&(Xe.deps=s)}return i}trigger(t){this.version++,qs++,this.notify(t)}notify(t){Qo();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{er()}}}function il(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let s=t.deps;s;s=s.nextDep)il(s)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const Mo=new WeakMap,Ki=Symbol(""),To=Symbol(""),Gs=Symbol("");function yt(e,t,i){if(Wt&&Xe){let s=Mo.get(e);s||Mo.set(e,s=new Map);let n=s.get(i);n||(s.set(i,n=new ir),n.map=s,n.key=i),n.track()}}function hi(e,t,i,s,n,o){const a=Mo.get(e);if(!a){qs++;return}const r=l=>{l&&l.trigger()};if(Qo(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Jo(i);if(l&&i==="length"){const u=Number(s);a.forEach((f,h)=>{(h==="length"||h===Gs||!Vt(h)&&h>=u)&&r(f)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(Gs)),t){case"add":l?c&&r(a.get("length")):(r(a.get(Ki)),ds(e)&&r(a.get(To)));break;case"delete":l||(r(a.get(Ki)),ds(e)&&r(a.get(To)));break;case"set":ds(e)&&r(a.get(Ki));break}}er()}function es(e){const t=je(e);return t===e?t:(yt(t,"iterate",Gs),Ht(e)?t:t.map(qt))}function Vn(e){return yt(e=je(e),"iterate",Gs),e}function Jt(e,t){return xi(e)?ms(Yi(e)?qt(t):t):qt(t)}const Zd={__proto__:null,[Symbol.iterator](){return oo(this,Symbol.iterator,e=>Jt(this,e))},concat(...e){return es(this).concat(...e.map(t=>Ee(t)?es(t):t))},entries(){return oo(this,"entries",e=>(e[1]=Jt(this,e[1]),e))},every(e,t){return li(this,"every",e,t,void 0,arguments)},filter(e,t){return li(this,"filter",e,t,i=>i.map(s=>Jt(this,s)),arguments)},find(e,t){return li(this,"find",e,t,i=>Jt(this,i),arguments)},findIndex(e,t){return li(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return li(this,"findLast",e,t,i=>Jt(this,i),arguments)},findLastIndex(e,t){return li(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return li(this,"forEach",e,t,void 0,arguments)},includes(...e){return ro(this,"includes",e)},indexOf(...e){return ro(this,"indexOf",e)},join(e){return es(this).join(e)},lastIndexOf(...e){return ro(this,"lastIndexOf",e)},map(e,t){return li(this,"map",e,t,void 0,arguments)},pop(){return $s(this,"pop")},push(...e){return $s(this,"push",e)},reduce(e,...t){return Pr(this,"reduce",e,t)},reduceRight(e,...t){return Pr(this,"reduceRight",e,t)},shift(){return $s(this,"shift")},some(e,t){return li(this,"some",e,t,void 0,arguments)},splice(...e){return $s(this,"splice",e)},toReversed(){return es(this).toReversed()},toSorted(e){return es(this).toSorted(e)},toSpliced(...e){return es(this).toSpliced(...e)},unshift(...e){return $s(this,"unshift",e)},values(){return oo(this,"values",e=>Jt(this,e))}};function oo(e,t,i){const s=Vn(e),n=s[t]();return s!==e&&!Ht(e)&&(n._next=n.next,n.next=()=>{const o=n._next();return o.done||(o.value=i(o.value)),o}),n}const Jd=Array.prototype;function li(e,t,i,s,n,o){const a=Vn(e),r=a!==e&&!Ht(e),l=a[t];if(l!==Jd[t]){const f=l.apply(e,o);return r?qt(f):f}let c=i;a!==e&&(r?c=function(f,h){return i.call(this,Jt(e,f),h,e)}:i.length>2&&(c=function(f,h){return i.call(this,f,h,e)}));const u=l.call(a,c,s);return r&&n?n(u):u}function Pr(e,t,i,s){const n=Vn(e),o=n!==e&&!Ht(e);let a=i,r=!1;n!==e&&(o?(r=s.length===0,a=function(c,u,f){return r&&(r=!1,c=Jt(e,c)),i.call(this,c,Jt(e,u),f,e)}):i.length>3&&(a=function(c,u,f){return i.call(this,c,u,f,e)}));const l=n[t](a,...s);return r?Jt(e,l):l}function ro(e,t,i){const s=je(e);yt(s,"iterate",Gs);const n=s[t](...i);return(n===-1||n===!1)&&or(i[0])?(i[0]=je(i[0]),s[t](...i)):n}function $s(e,t,i=[]){ki(),Qo();const s=je(e)[t].apply(e,i);return er(),wi(),s}const Xd=Yo("__proto__,__v_isRef,__isVue"),sl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Vt));function Qd(e){Vt(e)||(e=String(e));const t=je(this);return yt(t,"has",e),t.hasOwnProperty(e)}class nl{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,s){if(i==="__v_skip")return t.__v_skip;const n=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!n;if(i==="__v_isReadonly")return n;if(i==="__v_isShallow")return o;if(i==="__v_raw")return s===(n?o?cu:ll:o?al:rl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(s)?t:void 0;const a=Ee(t);if(!n){let l;if(a&&(l=Zd[i]))return l;if(i==="hasOwnProperty")return Qd}const r=Reflect.get(t,i,st(t)?t:s);if((Vt(i)?sl.has(i):Xd(i))||(n||yt(t,"get",i),o))return r;if(st(r)){const l=a&&Jo(i)?r:r.value;return n&&Ge(l)?Ao(l):l}return Ge(r)?n?Ao(r):qn(r):r}}class ol extends nl{constructor(t=!1){super(!1,t)}set(t,i,s,n){let o=t[i];const a=Ee(t)&&Jo(i);if(!this._isShallow){const c=xi(o);if(!Ht(s)&&!xi(s)&&(o=je(o),s=je(s)),!a&&st(o)&&!st(s))return c||(o.value=s),!0}const r=a?Number(i)<t.length:We(t,i),l=Reflect.set(t,i,s,st(t)?t:n);return t===je(n)&&l&&(r?Qt(s,o)&&hi(t,"set",i,s):hi(t,"add",i,s)),l}deleteProperty(t,i){const s=We(t,i);t[i];const n=Reflect.deleteProperty(t,i);return n&&s&&hi(t,"delete",i,void 0),n}has(t,i){const s=Reflect.has(t,i);return(!Vt(i)||!sl.has(i))&&yt(t,"has",i),s}ownKeys(t){return yt(t,"iterate",Ee(t)?"length":Ki),Reflect.ownKeys(t)}}class eu extends nl{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const tu=new ol,iu=new eu,su=new ol(!0);const Eo=e=>e,rn=e=>Reflect.getPrototypeOf(e);function nu(e,t,i){return function(...s){const n=this.__v_raw,o=je(n),a=ds(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=n[e](...s),u=i?Eo:t?ms:qt;return!t&&yt(o,"iterate",l?To:Ki),mt(Object.create(c),{next(){const{value:f,done:h}=c.next();return h?{value:f,done:h}:{value:r?[u(f[0]),u(f[1])]:u(f),done:h}}})}}function an(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function ou(e,t){const i={get(n){const o=this.__v_raw,a=je(o),r=je(n);e||(Qt(n,r)&&yt(a,"get",n),yt(a,"get",r));const{has:l}=rn(a),c=t?Eo:e?ms:qt;if(l.call(a,n))return c(o.get(n));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(n)},get size(){const n=this.__v_raw;return!e&&yt(je(n),"iterate",Ki),n.size},has(n){const o=this.__v_raw,a=je(o),r=je(n);return e||(Qt(n,r)&&yt(a,"has",n),yt(a,"has",r)),n===r?o.has(n):o.has(n)||o.has(r)},forEach(n,o){const a=this,r=a.__v_raw,l=je(r),c=t?Eo:e?ms:qt;return!e&&yt(l,"iterate",Ki),r.forEach((u,f)=>n.call(o,c(u),c(f),a))}};return mt(i,e?{add:an("add"),set:an("set"),delete:an("delete"),clear:an("clear")}:{add(n){const o=je(this),a=rn(o),r=je(n),l=!t&&!Ht(n)&&!xi(n)?r:n;return a.has.call(o,l)||Qt(n,l)&&a.has.call(o,n)||Qt(r,l)&&a.has.call(o,r)||(o.add(l),hi(o,"add",l,l)),this},set(n,o){!t&&!Ht(o)&&!xi(o)&&(o=je(o));const a=je(this),{has:r,get:l}=rn(a);let c=r.call(a,n);c||(n=je(n),c=r.call(a,n));const u=l.call(a,n);return a.set(n,o),c?Qt(o,u)&&hi(a,"set",n,o):hi(a,"add",n,o),this},delete(n){const o=je(this),{has:a,get:r}=rn(o);let l=a.call(o,n);l||(n=je(n),l=a.call(o,n)),r&&r.call(o,n);const c=o.delete(n);return l&&hi(o,"delete",n,void 0),c},clear(){const n=je(this),o=n.size!==0,a=n.clear();return o&&hi(n,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(n=>{i[n]=nu(n,e,t)}),i}function sr(e,t){const i=ou(e,t);return(s,n,o)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?s:Reflect.get(We(i,n)&&n in s?i:s,n,o)}const ru={get:sr(!1,!1)},au={get:sr(!1,!0)},lu={get:sr(!0,!1)};const rl=new WeakMap,al=new WeakMap,ll=new WeakMap,cu=new WeakMap;function du(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function qn(e){return xi(e)?e:nr(e,!1,tu,ru,rl)}function uu(e){return nr(e,!1,su,au,al)}function Ao(e){return nr(e,!0,iu,lu,ll)}function nr(e,t,i,s,n){if(!Ge(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=n.get(e);if(o)return o;const a=du(Od(e));if(a===0)return e;const r=new Proxy(e,a===2?s:i);return n.set(e,r),r}function Yi(e){return xi(e)?Yi(e.__v_raw):!!(e&&e.__v_isReactive)}function xi(e){return!!(e&&e.__v_isReadonly)}function Ht(e){return!!(e&&e.__v_isShallow)}function or(e){return e?!!e.__v_raw:!1}function je(e){const t=e&&e.__v_raw;return t?je(t):e}function fu(e){return!We(e,"__v_skip")&&Object.isExtensible(e)&&Va(e,"__v_skip",!0),e}const qt=e=>Ge(e)?qn(e):e,ms=e=>Ge(e)?Ao(e):e;function st(e){return e?e.__v_isRef===!0:!1}function ge(e){return pu(e,!1)}function pu(e,t){return st(e)?e:new hu(e,t)}class hu{constructor(t,i){this.dep=new ir,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:je(t),this._value=i?t:qt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,s=this.__v_isShallow||Ht(t)||xi(t);t=s?t:je(t),Qt(t,i)&&(this._rawValue=t,this._value=s?t:qt(t),this.dep.trigger())}}function he(e){return st(e)?e.value:e}const mu={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,s)=>{const n=e[t];return st(n)&&!st(i)?(n.value=i,!0):Reflect.set(e,t,i,s)}};function cl(e){return Yi(e)?e:new Proxy(e,mu)}class gu{constructor(t,i,s){this.fn=t,this.setter=i,this._value=void 0,this.dep=new ir(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=qs-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return Ja(this,!0),!0}get value(){const t=this.dep.track();return el(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function vu(e,t,i=!1){let s,n;return Be(e)?s=e:(s=e.get,n=e.set),new gu(s,n,i)}const ln={},Tn=new WeakMap;let Wi;function bu(e,t=!1,i=Wi){if(i){let s=Tn.get(i);s||Tn.set(i,s=[]),s.push(e)}}function yu(e,t,i=Ze){const{immediate:s,deep:n,once:o,scheduler:a,augmentJob:r,call:l}=i,c=S=>n?S:Ht(S)||n===!1||n===0?mi(S,1):mi(S);let u,f,h,d,g=!1,m=!1;if(st(e)?(f=()=>e.value,g=Ht(e)):Yi(e)?(f=()=>c(e),g=!0):Ee(e)?(m=!0,g=e.some(S=>Yi(S)||Ht(S)),f=()=>e.map(S=>{if(st(S))return S.value;if(Yi(S))return c(S);if(Be(S))return l?l(S,2):S()})):Be(e)?t?f=l?()=>l(e,2):e:f=()=>{if(h){ki();try{h()}finally{wi()}}const S=Wi;Wi=u;try{return l?l(e,3,[d]):e(d)}finally{Wi=S}}:f=si,t&&n){const S=f,D=n===!0?1/0:n;f=()=>mi(S(),D)}const b=Gd(),k=()=>{u.stop(),b&&b.active&&Zo(b.effects,u)};if(o&&t){const S=t;t=(...D)=>{const A=S(...D);return k(),A}}let y=m?new Array(e.length).fill(ln):ln;const w=S=>{if(!(!(u.flags&1)||!u.dirty&&!S))if(t){const D=u.run();if(S||n||g||(m?D.some((A,C)=>Qt(A,y[C])):Qt(D,y))){h&&h();const A=Wi;Wi=u;try{const C=[D,y===ln?void 0:m&&y[0]===ln?[]:y,d];y=D,l?l(t,3,C):t(...C)}finally{Wi=A}}}else u.run()};return r&&r(w),u=new Ya(f),u.scheduler=a?()=>a(w,!1):w,d=S=>bu(S,!1,u),h=u.onStop=()=>{const S=Tn.get(u);if(S){if(l)l(S,4);else for(const D of S)D();Tn.delete(u)}},t?s?w(!0):y=u.run():a?a(w.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function mi(e,t=1/0,i){if(t<=0||!Ge(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,st(e))mi(e.value,t,i);else if(Ee(e))for(let s=0;s<e.length;s++)mi(e[s],t,i);else if(ys(e)||ds(e))e.forEach(s=>{mi(s,t,i)});else if(Ua(e)){for(const s in e)mi(e[s],t,i);for(const s of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,s)&&mi(e[s],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function en(e,t,i,s){try{return s?e(...s):e()}catch(n){Gn(n,t,i)}}function Gt(e,t,i,s){if(Be(e)){const n=en(e,t,i,s);return n&&ja(n)&&n.catch(o=>{Gn(o,t,i)}),n}if(Ee(e)){const n=[];for(let o=0;o<e.length;o++)n.push(Gt(e[o],t,i,s));return n}}function Gn(e,t,i,s=!0){const n=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Ze;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,l,c)===!1)return}r=r.parent}if(o){ki(),en(o,null,10,[e,l,c]),wi();return}}ku(e,i,n,s,a)}function ku(e,t,i,s=!0,n=!1){if(n)throw e;console.error(e)}const It=[];let Yt=-1;const us=[];let Ti=null,ts=0;const dl=Promise.resolve();let En=null;function An(e){const t=En||dl;return e?t.then(this?e.bind(this):e):t}function wu(e){let t=Yt+1,i=It.length;for(;t<i;){const s=t+i>>>1,n=It[s],o=Ks(n);o<e||o===e&&n.flags&2?t=s+1:i=s}return t}function rr(e){if(!(e.flags&1)){const t=Ks(e),i=It[It.length-1];!i||!(e.flags&2)&&t>=Ks(i)?It.push(e):It.splice(wu(t),0,e),e.flags|=1,ul()}}function ul(){En||(En=dl.then(pl))}function xu(e){Ee(e)?us.push(...e):Ti&&e.id===-1?Ti.splice(ts+1,0,e):e.flags&1||(us.push(e),e.flags|=1),ul()}function Or(e,t,i=Yt+1){for(;i<It.length;i++){const s=It[i];if(s&&s.flags&2){if(e&&s.id!==e.uid)continue;It.splice(i,1),i--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function fl(e){if(us.length){const t=[...new Set(us)].sort((i,s)=>Ks(i)-Ks(s));if(us.length=0,Ti){Ti.push(...t);return}for(Ti=t,ts=0;ts<Ti.length;ts++){const i=Ti[ts];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}Ti=null,ts=0}}const Ks=e=>e.id==null?e.flags&2?-1:1/0:e.id;function pl(e){try{for(Yt=0;Yt<It.length;Yt++){const t=It[Yt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),en(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Yt<It.length;Yt++){const t=It[Yt];t&&(t.flags&=-2)}Yt=-1,It.length=0,fl(),En=null,(It.length||us.length)&&pl()}}let ht=null,hl=null;function Bn(e){const t=ht;return ht=e,hl=e&&e.type.__scopeId||null,t}function ml(e,t=ht,i){if(!t||e._n)return e;const s=(...n)=>{s._d&&Kr(-1);const o=Bn(t),a=vi.length;let r;try{r=e(...n)}finally{for(let l=vi.length;l>a;l--)ur();Bn(o),s._d&&Kr(1)}return r};return s._n=!0,s._c=!0,s._d=!0,s}function Ft(e,t){if(ht===null)return e;const i=Xn(ht),s=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[o,a,r,l=Ze]=t[n];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&mi(a),s.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function zi(e,t,i,s){const n=e.dirs,o=t&&t.dirs;for(let a=0;a<n.length;a++){const r=n[a];o&&(r.oldValue=o[a].value);let l=r.dir[s];l&&(ki(),Gt(l,i,8,[e.el,r,e,t]),wi())}}function Su(e,t){if(St){let i=St.provides;const s=St.parent&&St.parent.provides;s===i&&(i=St.provides=Object.create(s)),i[e]=t}}function Ut(e,t,i=!1){const s=xf();if(s||ps){let n=ps?ps._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return i&&Be(t)?t.call(s&&s.proxy):t}}const Cu=Symbol.for("v-scx"),_u=()=>Ut(Cu);function Zi(e,t,i){return gl(e,t,i)}function gl(e,t,i=Ze){const{immediate:s,deep:n,flush:o,once:a}=i,r=mt({},i),l=t&&s||!t&&o!=="post";let c;if(Zs){if(o==="sync"){const d=_u();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!l){const d=()=>{};return d.stop=si,d.resume=si,d.pause=si,d}}const u=St;r.call=(d,g,m)=>Gt(d,u,g,m);let f=!1;o==="post"?r.scheduler=d=>{Et(d,u&&u.suspense)}:o!=="sync"&&(f=!0,r.scheduler=(d,g)=>{g?d():rr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),f&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const h=yu(e,t,r);return Zs&&(c?c.push(h):l&&h()),h}function $u(e,t,i){const s=this.proxy,n=ot(e)?e.includes(".")?vl(s,e):()=>s[e]:e.bind(s,s);let o;Be(t)?o=t:(o=t.handler,i=t);const a=tn(this),r=gl(n,o.bind(s),i);return a(),r}function vl(e,t){const i=t.split(".");return()=>{let s=e;for(let n=0;n<i.length&&s;n++)s=s[i[n]];return s}}const Iu=Symbol("_vte"),Mu=e=>e.__isTeleport,ao=Symbol("_leaveCb");function ar(e,t){e.shapeFlag&6&&e.component?(e.transition=t,ar(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Rt(e,t){return Be(e)?mt({name:e.name},t,{setup:e}):e}function bl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Rr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Dn=new WeakMap;function Os(e,t,i,s,n=!1){if(Ee(e)){e.forEach((m,b)=>Os(m,t&&(Ee(t)?t[b]:t),i,s,n));return}if(fs(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&Os(e,t,i,s.component.subTree);return}const o=s.shapeFlag&4?Xn(s.component):s.el,a=n?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Ze?r.refs={}:r.refs,f=r.setupState,h=je(f),d=f===Ze?Fa:m=>Rr(u,m)?!1:We(h,m),g=(m,b)=>!(b&&Rr(u,b));if(c!=null&&c!==l){if(Nr(t),ot(c))u[c]=null,d(c)&&(f[c]=null);else if(st(c)){const m=t;g(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Be(l))en(l,r,12,[a,u]);else{const m=ot(l),b=st(l);if(m||b){const k=()=>{if(e.f){const y=m?d(l)?f[l]:u[l]:g()||!e.k?l.value:u[e.k];if(n)Ee(y)&&Zo(y,o);else if(Ee(y))y.includes(o)||y.push(o);else if(m)u[l]=[o],d(l)&&(f[l]=u[l]);else{const w=[o];g(l,e.k)&&(l.value=w),e.k&&(u[e.k]=w)}}else m?(u[l]=a,d(l)&&(f[l]=a)):b&&(g(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const y=()=>{k(),Dn.delete(e)};y.id=-1,Dn.set(e,y),Et(y,i)}else Nr(e),k()}}}function Nr(e){const t=Dn.get(e);t&&(t.flags|=8,Dn.delete(e))}Un().requestIdleCallback;Un().cancelIdleCallback;const fs=e=>!!e.type.__asyncLoader,yl=e=>e.type.__isKeepAlive;function Tu(e,t){kl(e,"a",t)}function Eu(e,t){kl(e,"da",t)}function kl(e,t,i=St){const s=e.__wdc||(e.__wdc=()=>{let n=i;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Kn(t,s,i),i){let n=i.parent;for(;n&&n.parent;)yl(n.parent.vnode)&&Au(s,t,i,n),n=n.parent}}function Au(e,t,i,s){const n=Kn(t,e,s,!0);Yn(()=>{Zo(s[t],n)},i)}function Kn(e,t,i=St,s=!1){if(i){const n=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{ki();const r=tn(i),l=Gt(t,i,e,a);return r(),wi(),l});return s?n.unshift(o):n.push(o),o}}const Ci=e=>(t,i=St)=>{(!Zs||e==="sp")&&Kn(e,(...s)=>t(...s),i)},Bu=Ci("bm"),ws=Ci("m"),Du=Ci("bu"),Lu=Ci("u"),lr=Ci("bum"),Yn=Ci("um"),Pu=Ci("sp"),Ou=Ci("rtg"),Ru=Ci("rtc");function Nu(e,t=St){Kn("ec",e,t)}const zu="components";function Hu(e,t){return ju(zu,e,!0,t)||e}const Fu=Symbol.for("v-ndc");function ju(e,t,i=!0,s=!1){const n=ht||St;if(n){const o=n.type;{const r=If(o,!1);if(r&&(r===t||r===Tt(t)||r===jn(Tt(t))))return o}const a=zr(n[e]||o[e],t)||zr(n.appContext[e],t);return!a&&s?o:a}}function zr(e,t){return e&&(e[t]||e[Tt(t)]||e[jn(Tt(t))])}function Mt(e,t,i,s){let n;const o=i,a=Ee(e);if(a||ot(e)){const r=a&&Yi(e);let l=!1,c=!1;r&&(l=!Ht(e),c=xi(e),e=Vn(e)),n=new Array(e.length);for(let u=0,f=e.length;u<f;u++)n[u]=t(l?c?ms(qt(e[u])):qt(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,o)}else if(Ge(e))if(e[Symbol.iterator])n=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);n=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];n[l]=t(e[u],u,l,o)}}else n=[];return n}function cn(e,t,i={},s,n,o){if(ht.ce||ht.parent&&fs(ht.parent)&&ht.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),ti(Je,null,[re("slot",c,s&&s())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=vi.length;J();let l;try{const c=a&&wl(a(i)),u=i.key||o||c&&c.key;l=ti(Je,{key:(u&&!Vt(u)?u:`_${t}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&e._===1?64:-2)}catch(c){for(let u=vi.length;u>r;u--)ur();throw c}finally{a&&a._c&&(a._d=!0)}return l}function wl(e){return e.some(t=>fr(t)?!(t.type===Si||t.type===Je&&!wl(t.children)):!0)?e:null}const Bo=e=>e?Fl(e)?Xn(e):Bo(e.parent):null,Rs=mt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Bo(e.parent),$root:e=>Bo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Sl(e),$forceUpdate:e=>e.f||(e.f=()=>{rr(e.update)}),$nextTick:e=>e.n||(e.n=An.bind(e.proxy)),$watch:e=>$u.bind(e)}),lo=(e,t)=>e!==Ze&&!e.__isScriptSetup&&We(e,t),Wu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:s,data:n,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const h=a[t];if(h!==void 0)switch(h){case 1:return s[t];case 2:return n[t];case 4:return i[t];case 3:return o[t]}else{if(lo(s,t))return a[t]=1,s[t];if(n!==Ze&&We(n,t))return a[t]=2,n[t];if(We(o,t))return a[t]=3,o[t];if(i!==Ze&&We(i,t))return a[t]=4,i[t];Do&&(a[t]=0)}}const c=Rs[t];let u,f;if(c)return t==="$attrs"&&yt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Ze&&We(i,t))return a[t]=4,i[t];if(f=l.config.globalProperties,We(f,t))return f[t]},set({_:e},t,i){const{data:s,setupState:n,ctx:o}=e;return lo(n,t)?(n[t]=i,!0):s!==Ze&&We(s,t)?(s[t]=i,!0):We(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:s,appContext:n,props:o,type:a}},r){let l;return!!(i[r]||e!==Ze&&r[0]!=="$"&&We(e,r)||lo(t,r)||We(o,r)||We(s,r)||We(Rs,r)||We(n.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:We(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Hr(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Do=!0;function Uu(e){const t=Sl(e),i=e.proxy,s=e.ctx;Do=!1,t.beforeCreate&&Fr(t.beforeCreate,e,"bc");const{data:n,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:f,mounted:h,beforeUpdate:d,updated:g,activated:m,deactivated:b,beforeDestroy:k,beforeUnmount:y,destroyed:w,unmounted:S,render:D,renderTracked:A,renderTriggered:C,errorCaptured:L,serverPrefetch:O,expose:N,inheritAttrs:V,components:_,directives:j,filters:x}=t;if(c&&Vu(c,s,null),a)for(const $ in a){const T=a[$];Be(T)&&(s[$]=T.bind(i))}if(n){const $=n.call(i,i);Ge($)&&(e.data=qn($))}if(Do=!0,o)for(const $ in o){const T=o[$],P=Be(T)?T.bind(i,i):Be(T.get)?T.get.bind(i,i):si,ne=!Be(T)&&Be(T.set)?T.set.bind(i):si,Y=ye({get:P,set:ne});Object.defineProperty(s,$,{enumerable:!0,configurable:!0,get:()=>Y.value,set:q=>Y.value=q})}if(r)for(const $ in r)xl(r[$],s,i,$);if(l){const $=Be(l)?l.call(i):l;Reflect.ownKeys($).forEach(T=>{Su(T,$[T])})}u&&Fr(u,e,"c");function R($,T){Ee(T)?T.forEach(P=>$(P.bind(i))):T&&$(T.bind(i))}if(R(Bu,f),R(ws,h),R(Du,d),R(Lu,g),R(Tu,m),R(Eu,b),R(Nu,L),R(Ru,A),R(Ou,C),R(lr,y),R(Yn,S),R(Pu,O),Ee(N))if(N.length){const $=e.exposed||(e.exposed={});N.forEach(T=>{Object.defineProperty($,T,{get:()=>i[T],set:P=>i[T]=P,enumerable:!0})})}else e.exposed||(e.exposed={});D&&e.render===si&&(e.render=D),V!=null&&(e.inheritAttrs=V),_&&(e.components=_),j&&(e.directives=j),O&&bl(e)}function Vu(e,t,i=si){Ee(e)&&(e=Lo(e));for(const s in e){const n=e[s];let o;Ge(n)?"default"in n?o=Ut(n.from||s,n.default,!0):o=Ut(n.from||s):o=Ut(n),st(o)?Object.defineProperty(t,s,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[s]=o}}function Fr(e,t,i){Gt(Ee(e)?e.map(s=>s.bind(t.proxy)):e.bind(t.proxy),t,i)}function xl(e,t,i,s){let n=s.includes(".")?vl(i,s):()=>i[s];if(ot(e)){const o=t[e];Be(o)&&Zi(n,o)}else if(Be(e))Zi(n,e.bind(i));else if(Ge(e))if(Ee(e))e.forEach(o=>xl(o,t,i,s));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Zi(n,o,e)}}function Sl(e){const t=e.type,{mixins:i,extends:s}=t,{mixins:n,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!n.length&&!i&&!s?l=t:(l={},n.length&&n.forEach(c=>Ln(l,c,a,!0)),Ln(l,t,a)),Ge(t)&&o.set(t,l),l}function Ln(e,t,i,s=!1){const{mixins:n,extends:o}=t;o&&Ln(e,o,i,!0),n&&n.forEach(a=>Ln(e,a,i,!0));for(const a in t)if(!(s&&a==="expose")){const r=qu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const qu={data:jr,props:Wr,emits:Wr,methods:Ts,computed:Ts,beforeCreate:$t,created:$t,beforeMount:$t,mounted:$t,beforeUpdate:$t,updated:$t,beforeDestroy:$t,beforeUnmount:$t,destroyed:$t,unmounted:$t,activated:$t,deactivated:$t,errorCaptured:$t,serverPrefetch:$t,components:Ts,directives:Ts,watch:Ku,provide:jr,inject:Gu};function jr(e,t){return t?e?function(){return mt(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Gu(e,t){return Ts(Lo(e),Lo(t))}function Lo(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function $t(e,t){return e?[...new Set([].concat(e,t))]:t}function Ts(e,t){return e?mt(Object.create(null),e,t):t}function Wr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:mt(Object.create(null),Hr(e),Hr(t??{})):t}function Ku(e,t){if(!e)return t;if(!t)return e;const i=mt(Object.create(null),e);for(const s in t)i[s]=$t(e[s],t[s]);return i}function Cl(){return{app:null,config:{isNativeTag:Fa,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Yu=0;function Zu(e,t){return function(s,n=null){Be(s)||(s=mt({},s)),n!=null&&!Ge(n)&&(n=null);const o=Cl(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Yu++,_component:s,_props:n,_container:null,_context:o,_instance:null,version:Tf,get config(){return o.config},set config(u){},use(u,...f){return a.has(u)||(u&&Be(u.install)?(a.add(u),u.install(c,...f)):Be(u)&&(a.add(u),u(c,...f))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,f){return f?(o.components[u]=f,c):o.components[u]},directive(u,f){return f?(o.directives[u]=f,c):o.directives[u]},mount(u,f,h){if(!l){const d=c._ceVNode||re(s,n);return d.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(d,u,h),l=!0,c._container=u,u.__vue_app__=c,Xn(d.component)}},onUnmount(u){r.push(u)},unmount(){l&&(Gt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return o.provides[u]=f,c},runWithContext(u){const f=ps;ps=c;try{return u()}finally{ps=f}}};return c}}let ps=null;const Ju=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Tt(t)}Modifiers`]||e[`${Ni(t)}Modifiers`];function Xu(e,t,...i){if(e.isUnmounted)return;const s=e.vnode.props||Ze;let n=i;const o=t.startsWith("update:"),a=o&&Ju(s,t.slice(7));a&&(a.trim&&(n=i.map(u=>ot(u)?u.trim():u)),a.number&&(n=i.map(Wn)));let r,l=s[r=io(t)]||s[r=io(Tt(t))];!l&&o&&(l=s[r=io(Ni(t))]),l&&Gt(l,e,6,n);const c=s[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Gt(c,e,6,n)}}const Qu=new WeakMap;function _l(e,t,i=!1){const s=i?Qu:t.emitsCache,n=s.get(e);if(n!==void 0)return n;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const u=_l(c,t,!0);u&&(r=!0,mt(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ge(e)&&s.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):mt(a,o),Ge(e)&&s.set(e,a),a)}function Zn(e,t){return!e||!zn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),We(e,t[0].toLowerCase()+t.slice(1))||We(e,Ni(t))||We(e,t))}function Ur(e){const{type:t,vnode:i,proxy:s,withProxy:n,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:f,data:h,setupState:d,ctx:g,inheritAttrs:m}=e,b=Bn(e);let k,y;try{if(i.shapeFlag&4){const S=n||s,D=S;k=Xt(c.call(D,S,u,f,d,h,g)),y=r}else{const S=t;k=Xt(S.length>1?S(f,{attrs:r,slots:a,emit:l}):S(f,null)),y=t.props?r:ef(r)}}catch(S){vi.length=0,Gn(S,e,1),k=re(Si)}let w=k;if(y&&m!==!1){const S=Object.keys(y),{shapeFlag:D}=w;S.length&&D&7&&(o&&S.some(Hn)&&(y=tf(y,o)),w=gs(w,y,!1,!0))}return i.dirs&&(w=gs(w,null,!1,!0),w.dirs=w.dirs?w.dirs.concat(i.dirs):i.dirs),i.transition&&ar(w,i.transition),k=w,Bn(b),k}const ef=e=>{let t;for(const i in e)(i==="class"||i==="style"||zn(i))&&((t||(t={}))[i]=e[i]);return t},tf=(e,t)=>{const i={};for(const s in e)(!Hn(s)||!(s.slice(9)in t))&&(i[s]=e[s]);return i};function sf(e,t,i){const{props:s,children:n,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return s?Vr(s,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const h=u[f];if($l(a,s,h)&&!Zn(c,h))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:s===a?!1:s?a?Vr(s,a,c):!0:!!a;return!1}function Vr(e,t,i){const s=Object.keys(t);if(s.length!==Object.keys(e).length)return!0;for(let n=0;n<s.length;n++){const o=s[n];if($l(t,e,o)&&!Zn(i,o))return!0}return!1}function $l(e,t,i){const s=e[i],n=t[i];return i==="style"&&Ge(s)&&Ge(n)?!ks(s,n):s!==n}function nf({vnode:e,parent:t,suspense:i},s){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=s,e=n),n===e)(e=t.vnode).el=s,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=s)}const Il={},Ml=()=>Object.create(Il),Tl=e=>Object.getPrototypeOf(e)===Il;function of(e,t,i,s=!1){const n={},o=Ml();e.propsDefaults=Object.create(null),El(e,t,n,o);for(const a in e.propsOptions[0])a in n||(n[a]=void 0);i?e.props=s?n:uu(n):e.type.props?e.props=n:e.props=o,e.attrs=o}function rf(e,t,i,s){const{props:n,attrs:o,vnode:{patchFlag:a}}=e,r=je(n),[l]=e.propsOptions;let c=!1;if((s||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let h=u[f];if(Zn(e.emitsOptions,h))continue;const d=t[h];if(l)if(We(o,h))d!==o[h]&&(o[h]=d,c=!0);else{const g=Tt(h);n[g]=Po(l,r,g,d,e,!1)}else d!==o[h]&&(o[h]=d,c=!0)}}}else{El(e,t,n,o)&&(c=!0);let u;for(const f in r)(!t||!We(t,f)&&((u=Ni(f))===f||!We(t,u)))&&(l?i&&(i[f]!==void 0||i[u]!==void 0)&&(n[f]=Po(l,r,f,void 0,e,!0)):delete n[f]);if(o!==r)for(const f in o)(!t||!We(t,f))&&(delete o[f],c=!0)}c&&hi(e.attrs,"set","")}function El(e,t,i,s){const[n,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Ds(l))continue;const c=t[l];let u;n&&We(n,u=Tt(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Zn(e.emitsOptions,l)||(!(l in s)||c!==s[l])&&(s[l]=c,a=!0)}if(o){const l=je(i),c=r||Ze;for(let u=0;u<o.length;u++){const f=o[u];i[f]=Po(n,l,f,c[f],e,!We(c,f))}}return a}function Po(e,t,i,s,n,o){const a=e[i];if(a!=null){const r=We(a,"default");if(r&&s===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=n;if(i in c)s=c[i];else{const u=tn(n);s=c[i]=l.call(null,t),u()}}else s=l;n.ce&&n.ce._setProp(i,s)}a[0]&&(o&&!r?s=!1:a[1]&&(s===""||s===Ni(i))&&(s=!0))}return s}const af=new WeakMap;function Al(e,t,i=!1){const s=i?af:t.propsCache,n=s.get(e);if(n)return n;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const u=f=>{l=!0;const[h,d]=Al(f,t,!0);mt(a,h),d&&r.push(...d)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return Ge(e)&&s.set(e,cs),cs;if(Ee(o))for(let u=0;u<o.length;u++){const f=Tt(o[u]);qr(f)&&(a[f]=Ze)}else if(o)for(const u in o){const f=Tt(u);if(qr(f)){const h=o[u],d=a[f]=Ee(h)||Be(h)?{type:h}:mt({},h),g=d.type;let m=!1,b=!0;if(Ee(g))for(let k=0;k<g.length;++k){const y=g[k],w=Be(y)&&y.name;if(w==="Boolean"){m=!0;break}else w==="String"&&(b=!1)}else m=Be(g)&&g.name==="Boolean";d[0]=m,d[1]=b,(m||We(d,"default"))&&r.push(f)}}const c=[a,r];return Ge(e)&&s.set(e,c),c}function qr(e){return e[0]!=="$"&&!Ds(e)}const cr=e=>e==="_"||e==="_ctx"||e==="$stable",dr=e=>Ee(e)?e.map(Xt):[Xt(e)],lf=(e,t,i)=>{if(t._n)return t;const s=ml((...n)=>dr(t(...n)),i);return s._c=!1,s},Bl=(e,t,i)=>{const s=e._ctx;for(const n in e){if(cr(n))continue;const o=e[n];if(Be(o))t[n]=lf(n,o,s);else if(o!=null){const a=dr(o);t[n]=()=>a}}},Dl=(e,t)=>{const i=dr(t);e.slots.default=()=>i},Ll=(e,t,i)=>{for(const s in t)(i||!cr(s))&&(e[s]=t[s])},cf=(e,t,i)=>{const s=e.slots=Ml();if(e.vnode.shapeFlag&32){const n=t._;n?(Ll(s,t,i),i&&Va(s,"_",n,!0)):Bl(t,s)}else t&&Dl(e,t)},df=(e,t,i)=>{const{vnode:s,slots:n}=e;let o=!0,a=Ze;if(s.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:Ll(n,t,i):(o=!t.$stable,Bl(t,n)),a=t}else t&&(Dl(e,t),a={default:1});if(o)for(const r in n)!cr(r)&&a[r]==null&&delete n[r]},Et=mf;function uf(e){return ff(e)}function ff(e,t){const i=Un();i.__VUE__=!0;const{insert:s,remove:n,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:f,nextSibling:h,setScopeId:d=si,insertStaticContent:g}=e,m=(E,H,v,W=null,F=null,M=null,I=void 0,z=null,G=!!H.dynamicChildren)=>{if(E===H)return;E&&!Is(E,H)&&(W=Ie(E),q(E,F,M,!0),E=null),H.patchFlag===-2&&(G=!1,H.dynamicChildren=null);const{type:Z,ref:B,shapeFlag:U}=H;switch(Z){case Jn:b(E,H,v,W);break;case Si:k(E,H,v,W);break;case mn:E==null&&y(H,v,W,I);break;case Je:_(E,H,v,W,F,M,I,z,G);break;default:U&1?D(E,H,v,W,F,M,I,z,G):U&6?j(E,H,v,W,F,M,I,z,G):(U&64||U&128)&&Z.process(E,H,v,W,F,M,I,z,G,X)}B!=null&&F?Os(B,E&&E.ref,M,H||E,!H):B==null&&E&&E.ref!=null&&Os(E.ref,null,M,E,!0)},b=(E,H,v,W)=>{if(E==null)s(H.el=r(H.children),v,W);else{const F=H.el=E.el;H.children!==E.children&&c(F,H.children)}},k=(E,H,v,W)=>{E==null?s(H.el=l(H.children||""),v,W):H.el=E.el},y=(E,H,v,W)=>{[E.el,E.anchor]=g(E.children,H,v,W,E.el,E.anchor)},w=({el:E,anchor:H},v,W)=>{let F;for(;E&&E!==H;)F=h(E),s(E,v,W),E=F;s(H,v,W)},S=({el:E,anchor:H})=>{let v;for(;E&&E!==H;)v=h(E),n(E),E=v;n(H)},D=(E,H,v,W,F,M,I,z,G)=>{if(H.type==="svg"?I="svg":H.type==="math"&&(I="mathml"),E==null)A(H,v,W,F,M,I,z,G);else{const Z=E.el&&E.el._isVueCE?E.el:null;try{Z&&Z._beginPatch(),O(E,H,F,M,I,z,G)}finally{Z&&Z._endPatch()}}},A=(E,H,v,W,F,M,I,z)=>{let G,Z;const{props:B,shapeFlag:U,transition:ie,dirs:te}=E;if(G=E.el=a(E.type,M,B&&B.is,B),U&8?u(G,E.children):U&16&&L(E.children,G,null,W,F,co(E,M),I,z),te&&zi(E,null,W,"created"),C(G,E,E.scopeId,I,W),B){for(const Se in B)Se!=="value"&&!Ds(Se)&&o(G,Se,null,B[Se],M,W);"value"in B&&o(G,"value",null,B.value,M),(Z=B.onVnodeBeforeMount)&&Kt(Z,W,E)}te&&zi(E,null,W,"beforeMount");const me=pf(F,ie);me&&ie.beforeEnter(G),s(G,H,v),((Z=B&&B.onVnodeMounted)||me||te)&&Et(()=>{try{Z&&Kt(Z,W,E),me&&ie.enter(G),te&&zi(E,null,W,"mounted")}finally{}},F)},C=(E,H,v,W,F)=>{if(v&&d(E,v),W)for(let M=0;M<W.length;M++)d(E,W[M]);if(F){let M=F.subTree;if(H===M||Nl(M.type)&&(M.ssContent===H||M.ssFallback===H)){const I=F.vnode;C(E,I,I.scopeId,I.slotScopeIds,F.parent)}}},L=(E,H,v,W,F,M,I,z,G=0)=>{for(let Z=G;Z<E.length;Z++){const B=E[Z]=z?di(E[Z]):Xt(E[Z]);m(null,B,H,v,W,F,M,I,z)}},O=(E,H,v,W,F,M,I)=>{const z=H.el=E.el;let{patchFlag:G,dynamicChildren:Z,dirs:B}=H;G|=E.patchFlag&16;const U=E.props||Ze,ie=H.props||Ze;let te;if(v&&Hi(v,!1),(te=ie.onVnodeBeforeUpdate)&&Kt(te,v,H,E),B&&zi(H,E,v,"beforeUpdate"),v&&Hi(v,!0),Z&&(!E.dynamicChildren||E.dynamicChildren.length!==Z.length)&&(G=0,I=!1,Z=null),(U.innerHTML&&ie.innerHTML==null||U.textContent&&ie.textContent==null)&&u(z,""),Z?N(E.dynamicChildren,Z,z,v,W,co(H,F),M):I||T(E,H,z,null,v,W,co(H,F),M,!1),G>0){if(G&16)V(z,U,ie,v,F);else if(G&2&&U.class!==ie.class&&o(z,"class",null,ie.class,F),G&4&&o(z,"style",U.style,ie.style,F),G&8){const me=H.dynamicProps;for(let Se=0;Se<me.length;Se++){const Ce=me[Se],De=U[Ce],Fe=ie[Ce];(Fe!==De||Ce==="value")&&o(z,Ce,De,Fe,F,v)}}G&1&&E.children!==H.children&&u(z,H.children)}else!I&&Z==null&&V(z,U,ie,v,F);((te=ie.onVnodeUpdated)||B)&&Et(()=>{te&&Kt(te,v,H,E),B&&zi(H,E,v,"updated")},W)},N=(E,H,v,W,F,M,I)=>{for(let z=0;z<H.length;z++){const G=E[z],Z=H[z],B=G.el&&(G.type===Je||!Is(G,Z)||G.shapeFlag&198)?f(G.el):v;m(G,Z,B,null,W,F,M,I,!0)}},V=(E,H,v,W,F)=>{if(H!==v){if(H!==Ze)for(const M in H)!Ds(M)&&!(M in v)&&o(E,M,H[M],null,F,W);for(const M in v){if(Ds(M))continue;const I=v[M],z=H[M];I!==z&&M!=="value"&&o(E,M,z,I,F,W)}"value"in v&&o(E,"value",H.value,v.value,F)}},_=(E,H,v,W,F,M,I,z,G)=>{const Z=H.el=E?E.el:r(""),B=H.anchor=E?E.anchor:r("");let{patchFlag:U,dynamicChildren:ie,slotScopeIds:te}=H;te&&(z=z?z.concat(te):te),E==null?(s(Z,v,W),s(B,v,W),L(H.children||[],v,B,F,M,I,z,G)):U>0&&U&64&&ie&&E.dynamicChildren&&E.dynamicChildren.length===ie.length?(N(E.dynamicChildren,ie,v,F,M,I,z),(H.key!=null||F&&H===F.subTree)&&Pl(E,H,!0)):T(E,H,v,B,F,M,I,z,G)},j=(E,H,v,W,F,M,I,z,G)=>{H.slotScopeIds=z,E==null?H.shapeFlag&512?F.ctx.activate(H,v,W,I,G):x(H,v,W,F,M,I,G):K(E,H,G)},x=(E,H,v,W,F,M,I)=>{const z=E.component=wf(E,W,F);if(yl(E)&&(z.ctx.renderer=X),Sf(z,!1,I),z.asyncDep){if(F&&F.registerDep(z,R,I),!E.el){const G=z.subTree=re(Si);k(null,G,H,v),E.placeholder=G.el}}else R(z,E,H,v,F,M,I)},K=(E,H,v)=>{const W=H.component=E.component;if(sf(E,H,v))if(W.asyncDep&&!W.asyncResolved){$(W,H,v);return}else W.next=H,W.update();else H.el=E.el,W.vnode=H},R=(E,H,v,W,F,M,I)=>{const z=()=>{if(E.isMounted){let{next:U,bu:ie,u:te,parent:me,vnode:Se}=E;{const et=Ol(E);if(et){U&&(U.el=Se.el,$(E,U,I)),et.asyncDep.then(()=>{Et(()=>{E.isUnmounted||Z()},F)});return}}let Ce=U,De;Hi(E,!1),U?(U.el=Se.el,$(E,U,I)):U=Se,ie&&hn(ie),(De=U.props&&U.props.onVnodeBeforeUpdate)&&Kt(De,me,U,Se),Hi(E,!0);const Fe=Ur(E),ze=E.subTree;E.subTree=Fe,m(ze,Fe,f(ze.el),Ie(ze),E,F,M),U.el=Fe.el,Ce===null&&nf(E,Fe.el),te&&Et(te,F),(De=U.props&&U.props.onVnodeUpdated)&&Et(()=>Kt(De,me,U,Se),F)}else{let U;const{el:ie,props:te}=H,{bm:me,m:Se,parent:Ce,root:De,type:Fe}=E,ze=fs(H);Hi(E,!1),me&&hn(me),!ze&&(U=te&&te.onVnodeBeforeMount)&&Kt(U,Ce,H),Hi(E,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(Fe,E.parent?E.parent.type:void 0);const et=E.subTree=Ur(E);m(null,et,v,W,E,F,M),H.el=et.el}if(Se&&Et(Se,F),!ze&&(U=te&&te.onVnodeMounted)){const et=H;Et(()=>Kt(U,Ce,et),F)}(H.shapeFlag&256||Ce&&fs(Ce.vnode)&&Ce.vnode.shapeFlag&256)&&E.a&&Et(E.a,F),E.isMounted=!0,H=v=W=null}};E.scope.on();const G=E.effect=new Ya(z);E.scope.off();const Z=E.update=G.run.bind(G),B=E.job=G.runIfDirty.bind(G);B.i=E,B.id=E.uid,G.scheduler=()=>rr(B),Hi(E,!0),Z()},$=(E,H,v)=>{H.component=E;const W=E.vnode.props;E.vnode=H,E.next=null,rf(E,H.props,W,v),df(E,H.children,v),ki(),Or(E),wi()},T=(E,H,v,W,F,M,I,z,G=!1)=>{const Z=E&&E.children,B=E?E.shapeFlag:0,U=H.children,{patchFlag:ie,shapeFlag:te}=H;if(ie>0){if(ie&128){ne(Z,U,v,W,F,M,I,z,G);return}else if(ie&256){P(Z,U,v,W,F,M,I,z,G);return}}te&8?(B&16&&_e(Z,F,M),U!==Z&&u(v,U)):B&16?te&16?ne(Z,U,v,W,F,M,I,z,G):_e(Z,F,M,!0):(B&8&&u(v,""),te&16&&L(U,v,W,F,M,I,z,G))},P=(E,H,v,W,F,M,I,z,G)=>{E=E||cs,H=H||cs;const Z=E.length,B=H.length,U=Math.min(Z,B);let ie;for(ie=0;ie<U;ie++){const te=H[ie]=G?di(H[ie]):Xt(H[ie]);m(E[ie],te,v,null,F,M,I,z,G)}Z>B?_e(E,F,M,!0,!1,U):L(H,v,W,F,M,I,z,G,U)},ne=(E,H,v,W,F,M,I,z,G)=>{let Z=0;const B=H.length;let U=E.length-1,ie=B-1;for(;Z<=U&&Z<=ie;){const te=E[Z],me=H[Z]=G?di(H[Z]):Xt(H[Z]);if(Is(te,me))m(te,me,v,null,F,M,I,z,G);else break;Z++}for(;Z<=U&&Z<=ie;){const te=E[U],me=H[ie]=G?di(H[ie]):Xt(H[ie]);if(Is(te,me))m(te,me,v,null,F,M,I,z,G);else break;U--,ie--}if(Z>U){if(Z<=ie){const te=ie+1,me=te<B?H[te].el:W;for(;Z<=ie;)m(null,H[Z]=G?di(H[Z]):Xt(H[Z]),v,me,F,M,I,z,G),Z++}}else if(Z>ie)for(;Z<=U;)q(E[Z],F,M,!0),Z++;else{const te=Z,me=Z,Se=new Map;for(Z=me;Z<=ie;Z++){const tt=H[Z]=G?di(H[Z]):Xt(H[Z]);tt.key!=null&&Se.set(tt.key,Z)}let Ce,De=0;const Fe=ie-me+1;let ze=!1,et=0;const Oe=new Array(Fe);for(Z=0;Z<Fe;Z++)Oe[Z]=0;for(Z=te;Z<=U;Z++){const tt=E[Z];if(De>=Fe){q(tt,F,M,!0);continue}let Ke;if(tt.key!=null)Ke=Se.get(tt.key);else for(Ce=me;Ce<=ie;Ce++)if(Oe[Ce-me]===0&&Is(tt,H[Ce])){Ke=Ce;break}Ke===void 0?q(tt,F,M,!0):(Oe[Ke-me]=Z+1,Ke>=et?et=Ke:ze=!0,m(tt,H[Ke],v,null,F,M,I,z,G),De++)}const ft=ze?hf(Oe):cs;for(Ce=ft.length-1,Z=Fe-1;Z>=0;Z--){const tt=me+Z,Ke=H[tt],de=H[tt+1],pe=tt+1<B?de.el||Rl(de):W;Oe[Z]===0?m(null,Ke,v,pe,F,M,I,z,G):ze&&(Ce<0||Z!==ft[Ce]?Y(Ke,v,pe,2):Ce--)}}},Y=(E,H,v,W,F=null)=>{const{el:M,type:I,transition:z,children:G,shapeFlag:Z}=E;if(Z&6){Y(E.component.subTree,H,v,W);return}if(Z&128){E.suspense.move(H,v,W);return}if(Z&64){I.move(E,H,v,X);return}if(I===Je){s(M,H,v);for(let U=0;U<G.length;U++)Y(G[U],H,v,W);s(E.anchor,H,v);return}if(I===mn){w(E,H,v);return}if(W!==2&&Z&1&&z)if(W===0)z.persisted&&!M[ao]?s(M,H,v):(z.beforeEnter(M),s(M,H,v),Et(()=>z.enter(M),F));else{const{leave:U,delayLeave:ie,afterLeave:te}=z,me=()=>{E.ctx.isUnmounted?n(M):s(M,H,v)},Se=()=>{const Ce=M._isLeaving||!!M[ao];M._isLeaving&&M[ao](!0),z.persisted&&!Ce?me():U(M,()=>{me(),te&&te()})};ie?ie(M,me,Se):Se()}else s(M,H,v)},q=(E,H,v,W=!1,F=!1)=>{const{type:M,props:I,ref:z,children:G,dynamicChildren:Z,shapeFlag:B,patchFlag:U,dirs:ie,cacheIndex:te,memo:me}=E;if(U===-2&&(F=!1),z!=null&&(ki(),Os(z,null,v,E,!0),wi()),te!=null&&(H.renderCache[te]=void 0),B&256){H.ctx.deactivate(E);return}const Se=B&1&&ie,Ce=!fs(E);let De;if(Ce&&(De=I&&I.onVnodeBeforeUnmount)&&Kt(De,H,E),B&6)oe(E.component,v,W);else{if(B&128){E.suspense.unmount(v,W);return}Se&&zi(E,null,H,"beforeUnmount"),B&64?E.type.remove(E,H,v,X,W):Z&&!Z.hasOnce&&(M!==Je||U>0&&U&64)?_e(Z,H,v,!1,!0):(M===Je&&U&384||!F&&B&16)&&_e(G,H,v),W&&le(E)}const Fe=me!=null&&te==null;(Ce&&(De=I&&I.onVnodeUnmounted)||Se||Fe)&&Et(()=>{De&&Kt(De,H,E),Se&&zi(E,null,H,"unmounted"),Fe&&(E.el=null)},v)},le=E=>{const{type:H,el:v,anchor:W,transition:F}=E;if(H===Je){se(v,W);return}if(H===mn){S(E);return}const M=()=>{n(v),F&&!F.persisted&&F.afterLeave&&F.afterLeave()};if(E.shapeFlag&1&&F&&!F.persisted){const{leave:I,delayLeave:z}=F,G=()=>I(v,M);z?z(E.el,M,G):G()}else M()},se=(E,H)=>{let v;for(;E!==H;)v=h(E),n(E),E=v;n(H)},oe=(E,H,v)=>{const{bum:W,scope:F,job:M,subTree:I,um:z,m:G,a:Z}=E;Gr(G),Gr(Z),W&&hn(W),F.stop(),M&&(M.flags|=8,q(I,E,H,v)),z&&Et(z,H),Et(()=>{E.isUnmounted=!0},H)},_e=(E,H,v,W=!1,F=!1,M=0)=>{for(let I=M;I<E.length;I++)q(E[I],H,v,W,F)},Ie=E=>{if(E.shapeFlag&6)return Ie(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const H=h(E.anchor||E.el),v=H&&H[Iu];return v?h(v):H};let xe=!1;const fe=(E,H,v)=>{let W;E==null?H._vnode&&(q(H._vnode,null,null,!0),W=H._vnode.component):m(H._vnode||null,E,H,null,null,null,v),H._vnode=E,xe||(xe=!0,Or(W),fl(),xe=!1)},X={p:m,um:q,m:Y,r:le,mt:x,mc:L,pc:T,pbc:N,n:Ie,o:e};return{render:fe,hydrate:void 0,createApp:Zu(fe)}}function co({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Hi({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function pf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Pl(e,t,i=!1){const s=e.children,n=t.children;if(Ee(s)&&Ee(n))for(let o=0;o<s.length;o++){const a=s[o];let r=n[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[o]=di(n[o]),r.el=a.el),!i&&r.patchFlag!==-2&&Pl(a,r)),r.type===Jn&&(r.patchFlag===-1&&(r=n[o]=di(r)),r.el=a.el),r.type===Si&&!r.el&&(r.el=a.el)}}function hf(e){const t=e.slice(),i=[0];let s,n,o,a,r;const l=e.length;for(s=0;s<l;s++){const c=e[s];if(c!==0){if(n=i[i.length-1],e[n]<c){t[s]=n,i.push(s);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[s]=i[o-1]),i[o]=s)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function Ol(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Ol(t)}function Gr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Rl(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Rl(t.subTree):null}const Nl=e=>e.__isSuspense;function mf(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):xu(e)}const Je=Symbol.for("v-fgt"),Jn=Symbol.for("v-txt"),Si=Symbol.for("v-cmt"),mn=Symbol.for("v-stc"),vi=[];let Ot=null;function J(e=!1){vi.push(Ot=e?null:[])}function ur(){vi.pop(),Ot=vi[vi.length-1]||null}let Ys=1;function Kr(e,t=!1){Ys+=e,e<0&&Ot&&t&&(Ot.hasOnce=!0)}function zl(e){return e.dynamicChildren=Ys>0?Ot||cs:null,ur(),Ys>0&&Ot&&Ot.push(e),e}function ee(e,t,i,s,n,o){return zl(p(e,t,i,s,n,o,!0))}function ti(e,t,i,s,n){return zl(re(e,t,i,s,n,!0))}function fr(e){return e?e.__v_isVNode===!0:!1}function Is(e,t){return e.type===t.type&&e.key===t.key}const Hl=({key:e})=>e??null,gn=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?ot(e)||st(e)||Be(e)?{i:ht,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,s=0,n=null,o=e===Je?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Hl(t),ref:t&&gn(t),scopeId:hl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:ht};return r?(Pn(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=ot(i)?8:16),Ys>0&&!a&&Ot&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Ot.push(l),l}const re=gf;function gf(e,t=null,i=null,s=0,n=null,o=!1){if((!e||e===Fu)&&(e=Si),fr(e)){const r=gs(e,t,!0);return i&&Pn(r,i),Ys>0&&!o&&Ot&&(r.shapeFlag&6?Ot[Ot.indexOf(e)]=r:Ot.push(r)),r.patchFlag=-2,r}if(Mf(e)&&(e=e.__vccOpts),t){t=vf(t);let{class:r,style:l}=t;r&&!ot(r)&&(t.class=$e(r)),Ge(l)&&(or(l)&&!Ee(l)&&(l=mt({},l)),t.style=Nt(l))}const a=ot(e)?1:Nl(e)?128:Mu(e)?64:Ge(e)?4:Be(e)?2:0;return p(e,t,i,s,n,a,o,!0)}function vf(e){return e?or(e)||Tl(e)?mt({},e):e:null}function gs(e,t,i=!1,s=!1){const{props:n,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?bf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Hl(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(gn(t)):[o,gn(t)]:gn(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Je?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&gs(e.ssContent),ssFallback:e.ssFallback&&gs(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&s&&ar(u,l.clone(u)),u}function Bt(e=" ",t=0){return re(Jn,null,e,t)}function bt(e,t){const i=re(mn,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(J(),ti(Si,null,e)):re(Si,null,e)}function Xt(e){return e==null||typeof e=="boolean"?re(Si):Ee(e)?re(Je,null,e.slice()):fr(e)?di(e):re(Jn,null,String(e))}function di(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:gs(e)}function Pn(e,t){let i=0;const{shapeFlag:s}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(s&65){const n=t.default;n&&(n._c&&(n._d=!1),Pn(e,n()),n._c&&(n._d=!0));return}else{i=32;const n=t._;!n&&!Tl(t)?t._ctx=ht:n===3&&ht&&(ht.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(s&65){Pn(e,{default:t});return}t={default:t,_ctx:ht},i=32}else t=String(t),s&64?(i=16,t=[Bt(t)]):i=8;e.children=t,e.shapeFlag|=i}function bf(...e){const t={};for(let i=0;i<e.length;i++){const s=e[i];for(const n in s)if(n==="class")t.class!==s.class&&(t.class=$e([t.class,s.class]));else if(n==="style")t.style=Nt([t.style,s.style]);else if(zn(n)){const o=t[n],a=s[n];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[n]=o?[].concat(o,a):a:a==null&&o==null&&!Hn(n)&&(t[n]=a)}else n!==""&&(t[n]=s[n])}return t}function Kt(e,t,i,s=null){Gt(e,t,7,[i,s])}const yf=Cl();let kf=0;function wf(e,t,i){const s=e.type,n=(t?t.appContext:e.appContext)||yf,o={uid:kf++,vnode:e,type:s,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new qd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Al(s,n),emitsOptions:_l(s,n),emit:null,emitted:null,propsDefaults:Ze,inheritAttrs:s.inheritAttrs,ctx:Ze,data:Ze,props:Ze,attrs:Ze,slots:Ze,refs:Ze,setupState:Ze,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Xu.bind(null,o),e.ce&&e.ce(o),o}let St=null;const xf=()=>St||ht;let On,Oo;{const e=Un(),t=(i,s)=>{let n;return(n=e[i])||(n=e[i]=[]),n.push(s),o=>{n.length>1?n.forEach(a=>a(o)):n[0](o)}};On=t("__VUE_INSTANCE_SETTERS__",i=>St=i),Oo=t("__VUE_SSR_SETTERS__",i=>Zs=i)}const tn=e=>{const t=St;return On(e),e.scope.on(),()=>{e.scope.off(),On(t)}},Yr=()=>{St&&St.scope.off(),On(null)};function Fl(e){return e.vnode.shapeFlag&4}let Zs=!1;function Sf(e,t=!1,i=!1){t&&Oo(t);const{props:s,children:n}=e.vnode,o=Fl(e);of(e,s,o,t),cf(e,n,i||t);const a=o?Cf(e,t):void 0;return t&&Oo(!1),a}function Cf(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Wu);const{setup:s}=i;if(s){ki();const n=e.setupContext=s.length>1?$f(e):null,o=tn(e),a=en(s,e,0,[e.props,n]),r=ja(a);if(wi(),o(),(r||e.sp)&&!fs(e)&&bl(e),r){if(a.then(Yr,Yr),t)return a.then(l=>{Zr(e,l)}).catch(l=>{Gn(l,e,0)});e.asyncDep=a}else Zr(e,a)}else jl(e)}function Zr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ge(t)&&(e.setupState=cl(t)),jl(e)}function jl(e,t,i){const s=e.type;e.render||(e.render=s.render||si);{const n=tn(e);ki();try{Uu(e)}finally{wi(),n()}}}const _f={get(e,t){return yt(e,"get",""),e[t]}};function $f(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,_f),slots:e.slots,emit:e.emit,expose:t}}function Xn(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(cl(fu(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Rs)return Rs[i](e)},has(t,i){return i in t||i in Rs}})):e.proxy}function If(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function Mf(e){return Be(e)&&"__vccOpts"in e}const ye=(e,t)=>vu(e,t,Zs),Tf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Ro;const Jr=typeof window<"u"&&window.trustedTypes;if(Jr)try{Ro=Jr.createPolicy("vue",{createHTML:e=>e})}catch{}const Wl=Ro?e=>Ro.createHTML(e):e=>e,Ef="http://www.w3.org/2000/svg",Af="http://www.w3.org/1998/Math/MathML",ci=typeof document<"u"?document:null,Xr=ci&&ci.createElement("template"),Bf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,s)=>{const n=t==="svg"?ci.createElementNS(Ef,e):t==="mathml"?ci.createElementNS(Af,e):i?ci.createElement(e,{is:i}):ci.createElement(e);return e==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:e=>ci.createTextNode(e),createComment:e=>ci.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ci.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,s,n,o){const a=i?i.previousSibling:t.lastChild;if(n&&(n===o||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),i),!(n===o||!(n=n.nextSibling)););else{Xr.innerHTML=Wl(s==="svg"?`<svg>${e}</svg>`:s==="mathml"?`<math>${e}</math>`:e);const r=Xr.content;if(s==="svg"||s==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Df=Symbol("_vtc");function Lf(e,t,i){const s=e[Df];s&&(t=(t?[t,...s]:[...s]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Rn=Symbol("_vod"),Ul=Symbol("_vsh"),No={name:"show",beforeMount(e,{value:t},{transition:i}){e[Rn]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):Ms(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:s}){!t!=!i&&(s?t?(s.beforeEnter(e),Ms(e,!0),s.enter(e)):s.leave(e,()=>{Ms(e,!1)}):Ms(e,t))},beforeUnmount(e,{value:t}){Ms(e,t)}};function Ms(e,t){e.style.display=t?e[Rn]:"none",e[Ul]=!t}const Pf=Symbol(""),Of=/(?:^|;)\s*display\s*:/;function Rf(e,t,i){const s=e.style,n=ot(i);let o=!1;if(i&&!n){if(t)if(ot(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&Es(s,r,"")}else for(const a in t)i[a]==null&&Es(s,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?zf(e,a,!ot(t)&&t?t[a]:void 0,r)||Es(s,a,r):Es(s,a,"")}}else if(n){if(t!==i){const a=s[Pf];a&&(i+=";"+a),s.cssText=i,o=Of.test(i)}}else t&&e.removeAttribute("style");Rn in e&&(e[Rn]=o?s.display:"",e[Ul]&&(s.display="none"))}const Qr=/\s*!important$/;function Es(e,t,i){if(Ee(i))i.forEach(s=>Es(e,t,s));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const s=Nf(e,t);Qr.test(i)?e.setProperty(Ni(s),i.replace(Qr,""),"important"):e[s]=i}}const ea=["Webkit","Moz","ms"],uo={};function Nf(e,t){const i=uo[t];if(i)return i;let s=Tt(t);if(s!=="filter"&&s in e)return uo[t]=s;s=jn(s);for(let n=0;n<ea.length;n++){const o=ea[n]+s;if(o in e)return uo[t]=o}return t}function zf(e,t,i,s){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&ot(s)&&i===s}const ta="http://www.w3.org/1999/xlink";function ia(e,t,i,s,n,o=Ud(t)){s&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(ta,t.slice(6,t.length)):e.setAttributeNS(ta,t,i):i==null||o&&!qa(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Vt(i)?String(i):i)}function sa(e,t,i,s,n){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Wl(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=qa(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(n||t)}function Ei(e,t,i,s){e.addEventListener(t,i,s)}function Hf(e,t,i,s){e.removeEventListener(t,i,s)}const na=Symbol("_vei");function Ff(e,t,i,s,n=null){const o=e[na]||(e[na]={}),a=o[t];if(s&&a)a.value=s;else{const[r,l]=Uf(t);if(s){const c=o[t]=Gf(s,n);Ei(e,r,c,l)}else a&&(Hf(e,r,a,l),o[t]=void 0)}}const jf=/(Once|Passive|Capture)$/,Wf=/^on:?(?:Once|Passive|Capture)$/;function Uf(e){let t,i;for(;(i=e.match(jf))&&!Wf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ni(e.slice(2)),t]}let fo=0;const Vf=Promise.resolve(),qf=()=>fo||(Vf.then(()=>fo=0),fo=Date.now());function Gf(e,t){const i=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=i.attached)return;const n=i.value;if(Ee(n)){const o=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{o.call(s),s._stopped=!0};const a=n.slice(),r=[s];for(let l=0;l<a.length&&!s._stopped;l++){const c=a[l];c&&Gt(c,t,5,r)}}else Gt(n,t,5,[s])};return i.value=e,i.attached=qf(),i}const oa=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Kf=(e,t,i,s,n,o)=>{const a=n==="svg";t==="class"?Lf(e,s,a):t==="style"?Rf(e,i,s):zn(t)?Hn(t)||Ff(e,t,i,s,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Yf(e,t,s,a))?(sa(e,t,s),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&ia(e,t,s,a,o,t!=="value")):e._isVueCE&&(Zf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!ot(s)))?sa(e,Tt(t),s,o,t):(t==="true-value"?e._trueValue=s:t==="false-value"&&(e._falseValue=s),ia(e,t,s,a))};function Yf(e,t,i,s){if(s)return!!(t==="innerHTML"||t==="textContent"||t in e&&oa(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return oa(t)&&ot(i)?!1:t in e}function Zf(e,t){const i=e._def.props;if(!i)return!1;const s=Tt(t);return Array.isArray(i)?i.some(n=>Tt(n)===s):Object.keys(i).some(n=>Tt(n)===s)}const vs=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>hn(t,i):t};function Jf(e){e.target.composing=!0}function ra(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const bi=Symbol("_assign");function aa(e,t,i){return t&&(e=e.trim()),i&&(e=Wn(e)),e}const zo={created(e,{modifiers:{lazy:t,trim:i,number:s}},n){e[bi]=vs(n);const o=s||n.props&&n.props.type==="number";Ei(e,t?"change":"input",a=>{a.target.composing||e[bi](aa(e.value,i,o))}),(i||o)&&Ei(e,"change",()=>{e.value=aa(e.value,i,o)}),t||(Ei(e,"compositionstart",Jf),Ei(e,"compositionend",ra),Ei(e,"change",ra))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:s,trim:n,number:o}},a){if(e[bi]=vs(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Wn(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(s&&t===i||n&&e.value.trim()===l)||(e.value=l)}},dn={deep:!0,created(e,t,i){e[bi]=vs(i),Ei(e,"change",()=>{const s=e._modelValue,n=Js(e),o=e.checked,a=e[bi];if(Ee(s)){const r=Xo(s,n),l=r!==-1;if(o&&!l)a(s.concat(n));else if(!o&&l){const c=[...s];c.splice(r,1),a(c)}}else if(ys(s)){const r=new Set(s);o?r.add(n):r.delete(n),a(r)}else a(Vl(e,o))})},mounted:la,beforeUpdate(e,t,i){e[bi]=vs(i),la(e,t,i)}};function la(e,{value:t,oldValue:i},s){e._modelValue=t;let n;if(Ee(t))n=Xo(t,s.props.value)>-1;else if(ys(t))n=t.has(s.props.value);else{if(t===i)return;n=ks(t,Vl(e,!0))}e.checked!==n&&(e.checked=n)}const Xf={deep:!0,created(e,{value:t,modifiers:{number:i}},s){e._modelValue=t,Ei(e,"change",()=>{const n=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Wn(Js(o)):Js(o));e[bi](e.multiple?ys(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,An(()=>{e._assigning=!1})}),e[bi]=vs(s)},mounted(e,{value:t}){ca(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[bi]=vs(i)},updated(e,{value:t}){e._assigning||ca(e,t)}};function ca(e,t){const i=e.multiple,s=Ee(t);if(!(i&&!s&&!ys(t))){for(let n=0,o=e.options.length;n<o;n++){const a=e.options[n],r=Js(a);if(i)if(s){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Xo(t,r)>-1}else a.selected=t.has(r);else if(ks(Js(a),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Js(e){return"_value"in e?e._value:e.value}function Vl(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Qf=["ctrl","shift","alt","meta"],ep={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Qf.some(i=>e[`${i}Key`]&&!t.includes(i))},ei=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),s=t.join(".");return i[s]||(i[s]=((n,...o)=>{for(let a=0;a<t.length;a++){const r=ep[t[a]];if(r&&r(n,t))return}return e(n,...o)}))},tp={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},ip=(e,t)=>{const i=e._withKeys||(e._withKeys={}),s=t.join(".");return i[s]||(i[s]=(n=>{if(!("key"in n))return;const o=Ni(n.key);if(t.some(a=>a===o||tp[a]===o))return e(n)}))},sp=mt({patchProp:Kf},Bf);let da;function np(){return da||(da=uf(sp))}const pr=((...e)=>{const t=np().createApp(...e),{mount:i}=t;return t.mount=s=>{const n=rp(s);if(!n)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const a=i(n,!1,op(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),a},t});function op(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function rp(e){return ot(e)?document.querySelector(e):e}const ap="slides-config.json",Li={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Zt=qn({...Li});function lp(e){if(!e||typeof e!="object")return{...Li};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Li.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Li.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Li.showOrderedListMarkers}}function ui(e){if(!e||typeof e!="object")return{...Zt};const t=e;return t.enableWebServeJump!==void 0&&(Zt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Zt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Zt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Zt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Zt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Zt}}function Qn(){return{...Zt}}function ql(e,t,i){const s=(e||Li.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(n);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Fi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function cp(e){var n,o,a,r,l,c,u,f;const t=Qn();if(!e)return{...Fi,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[Er]!==void 0?e[Er]!=="false":t.showUnorderedListMarkers,s=e[Ar]!==void 0?e[Ar]!=="false":t.showOrderedListMarkers;return{theme:((n=e[js])==null?void 0:n.trim())||Fi.theme,aspectRatio:((o=e[Ws])==null?void 0:o.trim())||Fi.aspectRatio,highlighter:((a=e[Oa])==null?void 0:a.trim())||Fi.highlighter,defaultTransition:((r=e[Us])==null?void 0:r.trim())||Fi.defaultTransition,colorSchema:((l=e[Ra])==null?void 0:l.trim())||Fi.colorSchema,spacing:((c=e[$o])==null?void 0:c.trim())||Fi.spacing,background:((u=e[Cn])==null?void 0:u.trim())||((f=e["slides-background"])==null?void 0:f.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:s}}function gi(e){var i,s,n,o,a;const t=(i=e.ial)==null?void 0:i[pi];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((s=e.markdown)==null?void 0:s.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function ua(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[wt]&&(t.transition=e[wt].trim()),e[ct]&&(t.background=e[ct].trim()),e[jt]&&(t.image=e[jt].trim()),e[ns]&&(t.class=e[ns].trim()),e[Bs]&&(t.spacing=e[Bs].trim()),e[xt]&&(t.layoutRatio=e[xt].trim()),e[os]&&(t.mask=e[os].trim()),e[Gi]&&(t.maskRatio=e[Gi].trim()),e[rs]&&(t.maskStyle=e[rs].trim()),e[as]&&(t.maskInitial=e[as].trim()),e[to]&&(i=e[to].trim());for(const[s,n]of Object.entries(e))if(s.startsWith("custom-slides-")&&![ke,xt,os,Gi,rs,as,wt,ct,jt,ns,Bs,to,pi].includes(s)){const o=s.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(n)}catch{t[o]=n}}return{frontmatter:t,notes:i}}function fa(e){const t={};if(!e)return t;const i=e[qe]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const s=e[Ye]??e["slides-role"],n=e[ct]??e["slides-background"];(s===Na||n==="true"||n==="1")&&(t.isBackground=!0);const o=e[ke]??e["slides-layout"];o===In||o===Mn?t.imageLayout=o:(s===In||s===Mn)&&(t.imageLayout=s);const a=e[Ne]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[ii])try{const r=JSON.parse(e[ii]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[ii].trim()}}return e[Xi]&&(t.shikiLines=e[Xi].trim()),e[Vs]&&(t.maxHeight=e[Vs].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function yi(e,t){const i=(e||t||"").trim();if(!i)return null;const s=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Ns(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],s=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return e;const n=s[1].length,o=s[2].trim(),a=i.length-s[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=a?r.push(c.slice(a)):f>n?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function Oi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function po(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const n=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(n.length>=2)return n.map(o=>`${o}fr`).join(" ")}const s=i.split(/\s+/).filter(Boolean);return s.length>=2?s.join(" "):`repeat(${t}, 1fr)`}function zs(e){if(!e)return[];if(ut(e)&&ni(e)&&!oi(e)){const s=xs(e),n=[];for(const o of s)n.push(...zs(o));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Oi);if(a.length>0)return a}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<n.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(n[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:n.length,u=n.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Oi(e)?[e]:[]}function hr(e){var n;if(!e||!ut(e)||!ni(e)||oi(e))return null;const t=xs(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&ni(t[0])){const o=hr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(ut(o)){i.push(o);const a=((n=o.children)==null?void 0:n.filter(ut))||[];i.push(...a)}const s=t.map(zs);if(s.length>=2&&s.every(o=>o.length>0)){const o=s.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=zs(t[0]),a=zs(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function dp(e){if(!e||!ut(e)||!ni(e)||oi(e))return null;const t=hr(e);if(!t)return null;const{items:i,nestedSuperBlocks:s}=t;if(i.length<2||i.length>6)return null;const n=mr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:s,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:n}}function Gl(e){if(!e||!ut(e)||!ni(e)||oi(e))return null;const t=xs(e);if(t.length===0)return null;const i=[];for(const s of t){const n=zs(s);if(n.length===0)return null;i.push(...n)}return i}function up(e){if(!e||!ut(e)||!ni(e)||oi(e))return null;const t=Gl(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function fp(e){if(!e||!ut(e)||!ni(e)||oi(e))return null;const t=hr(e);if(t&&t.items.length===4)return t.items;const i=Gl(e);if(i&&i.length===4)return i;const s=xs(e);return s.length===4?s:null}function pp(e,t){if(!e||e.length===0)return null;const i=[];function s(r,l){if(ut(r)){const c=fp(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)s(c,l)}for(let r=0;r<e.length;r++)s(e[r],r);if(i.length===0)return null;let n=null;t&&(n=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),n||(n=i[0]);const a=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>Kl(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:a}}function hp(e,t,i){var u,f,h,d,g;const s=[],n=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(gi(b)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},a.push(r)}else r.blocks.push(b)}function l(m){const b=[];for(const k of m)ut(k)&&b.push(k),k.children&&k.children.length>0&&b.push(...l(k.children));return b}function c(m,b,k){const y={blockId:m,attrs:b,previousAttrs:k};s.push(y),i!=null&&i.onTagChange&&i.onTagChange(y)}for(const m of a){const b=m.pageTargetId,k=t.find(A=>A.id===b),y=o.find(A=>A.pageTargetId===b);if(m.blocks.some(A=>{var C,L;return!!(oi(A)||Ho(A)&&(((C=A.ial)==null?void 0:C[ke])==="image-left"||((L=A.ial)==null?void 0:L[ke])==="image-right"))})){if(y){const A=y.headerId;if(A){c(A,{[Me]:""});const C=t.find(L=>L.id===A);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of y.itemIds){c(C,{[Me]:""});const L=t.find(O=>O.id===C);L!=null&&L.ial&&(L.ial[Me]="")}}continue}let S=null,D=-1;for(let A=0;A<m.blocks.length;A++){const C=m.blocks[A],L=ut(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const O of L){const N=dp(O);if(N){S=N,D=A;break}}if(S)break}if(S){const{superBlockNode:A,layout:C,items:L,slots:O}=S,V=m.blocks.slice(0,D).find($=>Kl($)),_=V==null?void 0:V.id,j=((u=k==null?void 0:k.ial)==null?void 0:u[ke])||"",x=j==="clover",K=x?"clover":C;if(j!==K&&(c(b,{[ke]:K},{[ke]:j}),k&&(k.ial||(k.ial={}),k.ial[ke]=K)),V){const $=((f=V.ial)==null?void 0:f[Me])||"";$!=="header"&&(c(V.id,{[Me]:"header"},{[Me]:$}),V.ial||(V.ial={}),V.ial[Me]="header")}if(y!=null&&y.headerId&&y.headerId!==_){c(y.headerId,{[Me]:""});const $=t.find(T=>T.id===y.headerId);$&&($.ial||($.ial={}),$.ial[Me]="")}const R=[];for(let $=0;$<L.length;$++){const T=L[$],P=O[$];R.push(T.id);const ne=((h=T.ial)==null?void 0:h[Me])||"";if(ne!==P&&(c(T.id,{[Me]:P},{[Me]:ne}),T.ial||(T.ial={}),T.ial[Me]=P),T.children&&T.children.length>0)for(const Y of T.children)Y.ial||(Y.ial={}),Y.ial[Me]!==P&&(Y.ial[Me]=P)}if(y!=null&&y.itemIds){for(const $ of y.itemIds)if(!R.includes($)){c($,{[Me]:""});const T=t.find(P=>P.id===$);T&&(T.ial||(T.ial={}),T.ial[Me]="")}}n.push({superBlockId:A.id,nestedSuperBlockIds:(d=S.nestedSuperBlocks)==null?void 0:d.map($=>$.id),pageTargetId:b,headerId:_,itemIds:R,layout:x?"clover":C})}else{let A=!1;const C=[];for(const N of m.blocks){const V=ut(N)?[N,...l(N.children||[])]:N.children?l(N.children):[];for(const _ of V){const j=up(_);if(j){A=!0;for(const x of j.items)C.push(x.id)}}}const L=((g=k==null?void 0:k.ial)==null?void 0:g[ke])||"",O=ls(L);if(y||A&&O){c(b,{[ke]:""},{[ke]:L}),k&&(k.ial||(k.ial={}),k.ial[ke]="");const N=y==null?void 0:y.headerId;if(N){c(N,{[Me]:""});const _=t.find(j=>j.id===N);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const V=new Set([...(y==null?void 0:y.itemIds)||[],...C]);for(const _ of V){c(_,{[Me]:""});const j=t.find(x=>x.id===_);j&&(j.ial||(j.ial={}),j.ial[Me]="")}}}}return{changes:s,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function ni(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const s=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(e.children&&e.children.length>0){for(const s of e.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Ho(e){return!e||Oi(e)||ut(e)||!yi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function mr(e){var h;if(!e||!ut(e)||!ni(e))return null;const t=xs(e);if(!t||t.length<2)return null;const i=[];let s=!1;for(const d of t){const g=(((h=d.ial)==null?void 0:h.style)||d.style||"").trim();let m=null;if(g){const b=g.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const k=g.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(m=parseFloat(k[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),s=!0):i.push(null)}if(!s)return null;const n=t.length,o=i.reduce((d,g)=>d+(g||0),0),a=i.filter(d=>d===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/n,c=i.map(d=>d!==null?d:l),u=c.reduce((d,g)=>d+g,0);if(u<=0)return null;const f=c.map(d=>d/u*100);if(f.length===2){const[d]=f;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const g=Math.round(d),m=100-g;return`${g}:${m}`}if(f.length===3){const[d,g,m]=f;if(d>=31&&d<=35&&g>=31&&g<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&g>=48&&g<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&g>=23&&g<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&g>=23&&g<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&g>=58&&g<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(d),k=Math.round(g),y=100-b-k;return`${b}:${k}:${y}`}return f.map(d=>Math.round(d)).join(":")}function oi(e){if(!e||!ut(e)||!ni(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Ho(t[0]),s=Ho(t[t.length-1]),n=mr(e)||void 0;if(i&&!s){const o=yi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:In,contentNodes:t.slice(1),ratio:n}}if(!i&&s){const o=yi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:Mn,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function mp(e,t){const i=[];function s(n){for(const o of n){const a=oi(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[ke];if(u!==l){const h={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[ke]=l,i.push(h),t&&t(h)}}o.children&&o.children.length>0&&s(o.children)}}return s(e),i}function xs(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const s=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function Kl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function ji(e,t,i){let s="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const k=a[1].match(/\bclass=["']([^"']*)["']/i);if(k){const y=k[1];if(typeof t=="string"?y.split(/\s+/).includes(t):t.test(y)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){s+=e.slice(n);break}s+=e.slice(n,l);const u=l+c;let f=1,h=-1,d=-1;const g=/<\/?div\b[^>]*>/gi;g.lastIndex=u;let m;for(;(m=g.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){h=m.index,d=m.index+m[0].length;break}}else f++;if(h!==-1&&d!==-1){const b=e.slice(u,h);s+=i(b),n=d}else s+=e.slice(l,u),n=u}return s}function gp(e){const t=[];let i="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<e.length;){n.lastIndex=s;let o,a=!1,r=-1,l=0;for(;(o=n.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(s);break}i+=e.slice(s,r);const c=r+l;let u=1,f=-1,h=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let g;for(;(g=d.exec(e))!==null;)if(g[0].startsWith("</")){if(u--,u===0){f=g.index,h=g.index+g[0].length;break}}else u++;if(f!==-1&&h!==-1){const m=e.slice(r,h),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,s=h}else i+=e.slice(r,c),s=c}return{text:i,tokens:t}}function vp(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const s=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${s.length}__`;return s.push(r),l});const{text:n,tokens:o}=gp(i);i=n;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=ji(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=ji(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=ji(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=ji(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=ji(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=ji(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=ji(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((f,h)=>Math.max(f,h.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,f)=>{const h=f.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<s.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Yl(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,s=>(t.push(s),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>t[parseInt(n,10)]||""),i}function bp(e){const t=Object.entries(e).filter(([s,n])=>n!=null&&n!=="");return t.length===0?"":`---
${t.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function yp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const s=e.slice(0,i).trim(),n=e.slice(i);return s.includes("{")?e:`${s} {${t}}${n}`}function Zl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function kp(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},s={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},s={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(s={...s,...e.enter});const n={...s.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(n.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(n.delay=e.delay),Object.keys(n).length>0&&(s.transition=n),{initial:i,enter:s}}function Nn(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function un(e,t,i,s,n){const o=t!=null&&t.trim()!=="",a=kp(i),r=Nn(n),l=r?`max-height:${r};overflow-y:auto`:"",c=[s==null?void 0:s.trim(),l].filter(Boolean).join(";"),u=c!==void 0&&c!=="",f=u?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return u?`<div${f}>

${e}

</div>`:e;if(o&&!a){if(u){const k=t.trim();let y="v-click";return k==="hide"?y="v-click.hide":k!==""&&k!=="+1"&&(y=`v-click="${k}"`),`<div ${y}${f}>

${e}

</div>`}return Zl(e,t)}const h=JSON.stringify(a.initial).replace(/"/g,"'"),d=JSON.stringify(a.enter).replace(/"/g,"'"),g=`v-motion :initial="${h}" :enter="${d}"`;if(!o)return`<div ${g}${f}>

${e}

</div>`;const m=t.trim();let b="v-click";return m==="hide"?b="v-click.hide":m!==""&&m!=="+1"&&(b=`v-click="${m}"`),`<div ${b} ${g}${f}>

${e}

</div>`}function gr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function wp(e){var s;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(s=e.ial)!=null&&s.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Jl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),f=Math.min(i,c.length),h=Math.floor(c.length/f),d=c.length%f;let g=0;for(let m=0;m<f;m++){const b=h+(m<d?1:0);u[m]=c.slice(g,g+b),g+=b}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),h=f?parseInt(f[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),g=d.split(/\r?\n/),m=[];for(let y=0;y<g.length;y++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(g[y])&&m.push(y);if(m.length>=i){const y=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const D=i-S,A=m.length-w,C=Math.ceil(A/D),L=m[w],O=w+C<m.length?m[w+C]:g.length,N=g.slice(L,O).join(`
`);y[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:N,content:N}],w+=C}return y}const b=d.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const y=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const D=i-S,A=b.length-w,C=Math.ceil(A/D),L=`<ul>
${b.slice(w,w+C).join(`
`)}
</ul>`;y[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],w+=C}return y}const k=d.split(/\r?\n\s*\r?\n/).filter(y=>y.trim()!=="");if(k.length>=i){const y=Array.from({length:i},()=>[]);let w=0;for(let S=0;S<i;S++){const D=i-S,A=k.length-w,C=Math.ceil(A/D),L=k.slice(w,w+C).join(`

`);y[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],w+=C}return y}if(h&&h>=1&&h<=i){const y=Array.from({length:i},()=>[]);return y[h-1]=[c],y}return[[c],...Array.from({length:i-1},()=>[])]}const s=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const f=u.match(/^col-(\d+)$/i);if(f){const h=parseInt(f[1],10);if(h>=1&&h<=i)return h}return null},n=e.map(s);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:i},()=>[]);let g=1;for(const b of e){const k=s(b);k!==null&&(g=k),d[g-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&d[0].length===0){const b=d.filter(k=>k.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return d}const u=e.filter(d=>s(d)===1),f=e.filter(d=>s(d)===null),h=i-1;if(f.length>=h){const d=Math.floor(f.length/h),g=f.length%h,m=[u];let b=0;for(let k=0;k<h;k++){const y=d+(k<g?1:0);m.push(f.slice(b,b+y)),b+=y}return m}else if(f.length>0){const d=[u];for(let g=0;g<h;g++)d.push(g<f.length?[f[g]]:[]);return d}else return[u,...Array.from({length:h},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const f=r[u],h=u+1<i?r[u+1]:e.length;c[u]=e.slice(f,h)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let f=0;f<i;f++){const h=i-f,d=e.length-u,g=Math.ceil(d/h);c[f]=e.slice(u,u+g),u+=g}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function pa(e,t,i,s){var g;const n=cp(t),o=[],a=ua(t),r=n.background?At(n.background,s):void 0;let l={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};l.frontmatter.background&&(l.frontmatter.background=At(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=At(l.frontmatter.image,s));const c=m=>{const b=[];for(let k=m;k<i.length&&!(k>m&&gi(i[k]));k++)b.push(i[k]);return b},u=m=>{let b,k,y;const w=S=>{var O;if(b)return;const D=oi(S);if(D){b=D.layout,k=D.imageUrl,y=D.ratio;return}const A=Tr(S),C=S.ial?{...S.ial}:{},L=fa(C);if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const N=yi(A,S.content);if(N){b=L.imageLayout,k=N,y=(O=S.ial)==null?void 0:O[xt];return}}if(S.children&&S.children.length>0){for(const N of S.children)if(w(N),b)return}};for(const S of m)if(w(S),b)break;return{foundLayout:b,foundImage:k,foundRatio:y}},f=(m,b)=>{const{foundLayout:k,foundImage:y,foundRatio:w}=u(b);k&&(m.frontmatter.layout=k,y&&(m.frontmatter.image=At(y,s)),w&&!m.frontmatter.layoutRatio&&(m.frontmatter.layoutRatio=w))};f(l,c(0)),o.push(l);let h=[];for(let m=0;m<i.length;m++){const b=i[m];if(gi(b)){h=[];const y=ua(b.ial);if(o.length===1&&l.blocks.length===0){l.startBlockId=b.id,l.allBlockIds||(l.allBlockIds=[]),l.allBlockIds.includes(b.id)||l.allBlockIds.push(b.id),y.frontmatter.layout&&(l.frontmatter.layout=y.frontmatter.layout),Object.assign(l.frontmatter,y.frontmatter),delete l.frontmatter.background,!y.frontmatter.image&&a.frontmatter.image&&(l.frontmatter.image=a.frontmatter.image),r&&(l.frontmatter.background=r),l.frontmatter.background&&(l.frontmatter.background=At(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=At(l.frontmatter.image,s)),f(l,c(m+1));continue}l={pageIndex:o.length+1,startBlockId:b.id,frontmatter:{layout:y.frontmatter.layout||"default",...y.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete l.frontmatter.background,l.frontmatter.background&&(l.frontmatter.background=At(l.frontmatter.background,s)),l.frontmatter.image&&(l.frontmatter.image=At(l.frontmatter.image,s)),f(l,c(m+1)),o.push(l);continue}const k=(y,w)=>{var oe,_e,Ie,xe,fe,X,ue;if(l.allBlockIds||(l.allBlockIds=[]),y.id&&!l.allBlockIds.includes(y.id)&&l.allBlockIds.push(y.id),y.children&&y.children.length>0){const E=H=>{for(const v of H)v.id&&!l.allBlockIds.includes(v.id)&&l.allBlockIds.push(v.id),v.children&&v.children.length>0&&E(v.children)};E(y.children)}let S=Tr(y),D=y.ial?{...y.ial}:{};const A=S.match(/\{:\s*([^}]+)\s*\}\s*$/);A&&(D={...La(A[0]),...D},S=S.slice(0,A.index).trim()),y.type!=="c"&&!S.startsWith("```")&&(S=Yl(S));let C=S.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(S=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=S.trim());const L=fa(D);if(S=Ld(S,s),S=Bd(S,s==null?void 0:s.refContentMap),y.children&&y.children.length>0){const E=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],H=v=>{for(const W of v){if(W.ial)for(const[F,M]of Object.entries(W.ial))E.includes(F)&&!D[F]&&(D[F]=M);W.children&&W.children.length>0&&H(W.children)}};H(y.children)}const O=y.type==="video"||y.type==="NodeVideo"||/<video\b/i.test(S);if(O){const E=D["custom-slides-autoplay"]==="true",H=D["custom-slides-loop"]==="true",v=D["custom-slides-muted"]==="true"||E,W=D["custom-slides-controls"]==="false";S=S.replace(/<video\b([^>]*)>/gi,(F,M)=>{let I=M;return W?I=I.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(I)||(I+=" controls"),E&&!/autoplay/i.test(I)?I+=" autoplay playsinline":!E&&D["custom-slides-autoplay"]==="false"&&(I=I.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),H&&!/loop/i.test(I)?I+=" loop":!H&&D["custom-slides-loop"]==="false"&&(I=I.replace(/\bloop\b/gi,"").trim()),v&&!/muted/i.test(I)?I+=" muted":!v&&D["custom-slides-muted"]==="false"&&(I=I.replace(/\bmuted\b/gi,"").trim()),`<video ${I.trim()}>`})}if(L.isBackground){const E=yi(S,y.content);if(E){l.frontmatter.background=At(E,s);return}}const N=oi(y);if(N){l.frontmatter.layout=N.layout,l.frontmatter.image=At(N.imageUrl,s),!l.frontmatter.layoutRatio&&N.ratio&&(l.frontmatter.layoutRatio=N.ratio);for(const E of N.contentNodes)k(E);return}if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const E=yi(S,y.content);if(E){l.frontmatter.layout=L.imageLayout,l.frontmatter.image=At(E,s),!l.frontmatter.layoutRatio&&((oe=y.ial)!=null&&oe[xt])&&(l.frontmatter.layoutRatio=y.ial[xt]);return}}if(ut(y)&&y.children&&y.children.length>0){for(const E of y.children)k(E);return}const V=!!(L.slot||w!=null&&w.defaultSlot||l.frontmatter.layout==="clover"||ls(l.frontmatter.layout)||l.frontmatter.layout==="two-cols"),_=!!(y.children&&y.children.some(E=>{var H,v;return((H=E.ial)==null?void 0:H[Me])||((v=E.ial)==null?void 0:v[Ne])||E.children&&E.children.length>=2||E.children&&E.children.some(W=>{var F,M,I,z,G,Z;return((F=W.ial)==null?void 0:F[Ne])||((M=W.ial)==null?void 0:M[Me])||((I=W.ial)==null?void 0:I[Ye])||((z=W.ial)==null?void 0:z[ke])||((G=W.ial)==null?void 0:G["custom-slides-role"])||((Z=W.ial)==null?void 0:Z["custom-slides-layout"])})}));if((y.type==="l"||y.type==="NodeList"||y.type==="list")&&y.children&&y.children.length>0&&(_||L.slot||L.clicks||V)){const E=/^\s*\d+\.\s+/m.test(y.markdown||"")||y.subType==="o"||y.subtype==="o";for(let H=0;H<y.children.length;H++){const v=y.children[H];L.slot&&(!v.ial||!v.ial[Me])&&(v.ial||(v.ial={}),v.ial[Me]=L.slot),k(v,{...w,parentClicks:L.clicks||(w==null?void 0:w.parentClicks),defaultSlot:L.slot||(w==null?void 0:w.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:E,itemIndex:H+1}})}return}const j=!!(w!=null&&w.isParentListUnpacked),x=!!(y.children&&y.children.length>=2)||!!L.clicks||!!((_e=y.children)!=null&&_e.some(E=>{var H;return(H=E.ial)==null?void 0:H[Ne]}))||j||!y.markdown&&!!(y.children&&y.children.length>0);if(Oi(y)&&y.children&&y.children.length>0&&(V||j||L.clicks||y.children.some(E=>{var H;return(H=E.ial)==null?void 0:H[Ne]}))&&x){const E=!!(y.children&&y.children.length>=2),H=y.children.find(G=>!!(G.markdown||G.content||"").trim())||y.children[0],v=((Ie=H==null?void 0:H.ial)==null?void 0:Ie[Ne])||((xe=H==null?void 0:H.ial)==null?void 0:xe["custom-slides-click"]),W=!!(!L.clicks&&E&&v),F=L.clicks||(W?v:void 0)||(w==null?void 0:w.parentClicks),M=y.id||(w==null?void 0:w.parentContainerId),I=L.slot||(w==null?void 0:w.defaultSlot);let z=!0;for(const G of y.children){I&&(!G.ial||!G.ial[Me])&&(G.ial||(G.ial={}),G.ial[Me]=I);const Z=!!(G.markdown||G.content||"").trim(),B=z&&Z;if(B){if(!(l.frontmatter.layout==="image-right"||l.frontmatter.layout==="image-left")&&!!(l.frontmatter.layout==="clover"||ls(l.frontmatter.layout)||l.frontmatter.layout==="two-cols")&&!!(w!=null&&w.defaultSlot||L.slot||(fe=y.ial)!=null&&fe[Me]))G.markdown&&(G.markdown=Ns(G.markdown)),G.content&&(G.content=Ns(G.content));else{const Se=!!((X=w==null?void 0:w.listContext)!=null&&X.isOrdered),Ce=((ue=w==null?void 0:w.listContext)==null?void 0:ue.itemIndex)||1,De=Se?`${Ce}. `:"- ",Fe=ze=>{if(!ze)return De.trim();const et=ze.trim();return/^[-*+]\s+/.test(et)||/^\d+\.\s+/.test(et)?ze:`${De}${ze}`};G.markdown&&(G.markdown=Fe(G.markdown)),G.content&&(G.content=Fe(G.content))}z=!1}let U=G;B&&F&&E?(U={...G,ial:{...G.ial||{}}},delete U.ial[Ne],delete U.ial["custom-slides-click"]):!E&&F&&(U={...G,ial:{...G.ial||{},[Ne]:F}}),k(U,{...w,parentClicks:F,parentContainerId:M,defaultSlot:I,isListItem:!0})}return}if(L.isNote){const E=gr(S);E&&(l.notes?l.notes+=`

`+E:l.notes=E),l.noteBlocks||(l.noteBlocks=[]),l.noteBlocks.push({id:y.id,type:y.type,content:E||y.content||"",rawMarkdown:S,isNote:!0,attributes:y.ial});return}L.shikiLines&&(S=yp(S,L.shikiLines)),C=S.trim();const K=(y.content||"").trim();if(C==="::right::"||K==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){l.blocks.push({id:y.id,type:y.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:y.ial});return}const $=wp(y);let T=L.slot,P=L.clicks,ne=L.motion,Y={...y.ial||{}};if($!==null){for(;h.length>0&&h[h.length-1].level>=$;)h.pop();const E=h.length>0?h[h.length-1]:void 0;!T&&(E!=null&&E.slot)&&(T=E.slot),!P&&(E!=null&&E.clicks)&&!(w!=null&&w.parentContainerId)&&(P=E.clicks),!ne&&(E!=null&&E.motion)&&(ne=E.motion);const H={...(E==null?void 0:E.customAttrs)||{}};if(y.ial)for(const[v,W]of Object.entries(y.ial))v.startsWith("custom-slides-")&&!v.startsWith("custom-slides-slide")&&(H[v]=W);w!=null&&w.parentContainerId||h.push({level:$,slot:T,clicks:P,motion:ne,customAttrs:H})}else{const E=h.length>0?h[h.length-1]:void 0;E&&(!T&&E.slot&&E.slot!=="header"&&(T=E.slot),!P&&E.clicks&&!(w!=null&&w.parentContainerId)&&(P=E.clicks),!ne&&E.motion&&(ne=E.motion),E.customAttrs&&(Y={...E.customAttrs,...Y}))}!T&&l.blocks.some(E=>E.slot==="slot-divider-right")&&(T="right"),!T&&(w!=null&&w.defaultSlot)&&(T=w.defaultSlot),T&&(Y[Me]=T),P&&!Y[Ne]&&(Y[Ne]=P),ne&&!Y[ii]&&(Y[ii]=JSON.stringify(ne)),(O||D["custom-slides-autoplay"]||D["custom-slides-muted"])&&(D["custom-slides-autoplay"]&&(Y["custom-slides-autoplay"]=D["custom-slides-autoplay"],D["custom-slides-autoplay"]==="true"&&!D["custom-slides-muted"]&&(Y["custom-slides-muted"]="true")),D["custom-slides-loop"]&&(Y["custom-slides-loop"]=D["custom-slides-loop"]),D["custom-slides-muted"]&&(Y["custom-slides-muted"]=D["custom-slides-muted"]),D["custom-slides-controls"]&&(Y["custom-slides-controls"]=D["custom-slides-controls"]));const q=L.maxHeight?Nn(L.maxHeight):void 0,le=!!(w!=null&&w.isListItem||Oi(y)),se={id:y.id,type:y.type,content:y.content||"",rawMarkdown:S,clicks:P,parentClicks:w==null?void 0:w.parentClicks,parentContainerId:w==null?void 0:w.parentContainerId,motion:ne,shikiLines:L.shikiLines,maxHeight:q,slot:T,attributes:Y,attrs:Y,rawNode:y,isListItem:le};l.blocks.push(se)};k(b)}for(let m=0;m<o.length;m++){const b=o[m],k=[],y={...b.frontmatter};m===0&&(y.theme=n.theme,y.aspectRatio=n.aspectRatio,y.highlighter=n.highlighter,y.transition=b.frontmatter.transition||n.defaultTransition);const w=bp(y);w&&k.push(w);const S=b.blocks.filter(O=>O.slot!=="slot-divider-right"),D=O=>O.filter(N=>!!(N.rawMarkdown||N.content||"").trim()).map(N=>{var V;return un(N.rawMarkdown,N.clicks,N.motion,(V=N.attributes)==null?void 0:V.style,N.maxHeight)}).join(`

`),A=O=>{const N=O.filter(x=>!!(x.rawMarkdown||x.content||"").trim());if(N.length===0)return;const V=N[0],_=(V.rawMarkdown||V.content||"").trim();(Oi(V)||/^(?:[-*+]|\d+\.)\s+/.test(_))&&(V.rawMarkdown=Ns(V.rawMarkdown||V.content||""),V.content=V.rawMarkdown)},C=O=>{var x,K;if(O.length===0)return"";A(O);const N=(x=O.find(R=>R.parentClicks))==null?void 0:x.parentClicks;if(!N)return O.filter(R=>!!(R.rawMarkdown||R.content||"").trim()).map(R=>{var $;return un(R.rawMarkdown,R.clicks,R.motion,($=R.attributes)==null?void 0:$.style,R.maxHeight)}).join(`

`);const V=[];let _=[];const j=()=>{if(_.length===0)return;const R=_.map($=>($.rawMarkdown||$.content||"").trim()).filter(Boolean).join(`

`);R&&V.push(Zl(R,N)),_=[]};for(const R of O){if(!(R.rawMarkdown||R.content||"").trim())continue;!!(R.clicks&&R.clicks.trim()!=="")?(j(),V.push(un(R.rawMarkdown,R.clicks,R.motion,(K=R.attributes)==null?void 0:K.style,R.maxHeight))):_.push(R)}return j(),V.join(`

`)},L=b.frontmatter.layout||"default";if(L==="clover"||ls(L)){let O=[];const N=S.filter(R=>R.slot==="header");if(N.length>0)O=N;else if(S.length>0){const R=S.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));R&&(O=[R])}const V=S.filter(R=>!O.includes(R));let _=2;if(L==="clover")_=4;else if(L==="three-cols-header")_=3;else if(L==="two-cols-header")_=2;else{let R=0;for(const $ of V){const T=($.slot||"").match(/^col-(\d+)$/i);T&&(R=Math.max(R,parseInt(T[1],10)))}if(R>=2)_=R;else if(b.frontmatter.layoutRatio){const $=b.frontmatter.layoutRatio.trim();if($.includes(":")){const T=$.split(":").map(P=>parseFloat(P.trim())).filter(P=>!isNaN(P)&&P>0);T.length>=2&&(_=T.length)}else{const T=$.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else V.length===1&&V[0].children&&V[0].children.length>=2&&(_=Math.min(6,V[0].children.length))}const j=Jl(V,_);j.forEach((R,$)=>{const T=`col-${$+1}`;for(const P of R)(!P.slot||P.slot==="default")&&(P.slot=T);A(R)});const x=j.flat();if(V.length===1&&x.length>1){const R=b.blocks.findIndex($=>$.id===V[0].id);R!==-1&&b.blocks.splice(R,1,...x)}const K=D(O);if(K&&k.push(K),L==="two-cols-header"&&_===2){const R=C(j[0]||[]),$=C(j[1]||[]);R&&k.push(`::left::

${R}`),$&&k.push(`::right::

${$}`)}else j.forEach((R,$)=>{const T=C(R);T&&k.push(`::col-${$+1}::

${T}`)})}else if(L==="two-cols"){const O=S.filter(j=>j.slot==="left"),N=S.filter(j=>j.slot==="right");A(O),A(N);const V=D(O.length>0?O:S.filter(j=>j.slot!=="right")),_=D(N);k.push(V),_&&k.push(`::right::

${_}`)}else for(const O of S)k.push(un(O.rawMarkdown,O.clicks||O.parentClicks,O.motion,(g=O.attributes)==null?void 0:g.style,O.maxHeight));b.notes&&k.push(`<!--
${b.notes}
-->`),b.rawMarkdown=k.join(`

`).trim()}const d=o.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:n,slides:o,fullMarkdown:d}}const Fo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function xp(e){var n,o,a,r,l,c,u,f,h,d,g,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const k=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&t.push(`  ${k}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${k}-background-color: ${b.light.backgroundColor};`),(a=b.dark)!=null&&a.color&&i.push(`  ${k}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const k=b.index;(l=b.light)!=null&&l.color&&t.push(`  --b3-font-color${k}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${k}: ${b.light.backgroundColor};`),(u=b.dark)!=null&&u.color&&i.push(`  --b3-font-color${k}: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${k}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const k=b.id;(h=b.light)!=null&&h.color&&t.push(`  --b3-card-${k}-color: ${b.light.color};`),(d=b.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${k}-background: ${b.light.backgroundColor};`),(g=b.dark)!=null&&g.color&&i.push(`  --b3-card-${k}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${k}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const s=[];return t.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),s.join(`

`)}function Hs(e){const t=xp(e);return t?`${Fo}

/* Custom Workspace Inline Styles */
${t}`:Fo}const ho=La;function Sp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Cp(e,t){const i=new Map,s=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:s};const n=new Map;for(const o of t)o!=null&&o.id&&n.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=n.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(Sp(a)?s.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:s}}function _p(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function jo(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function $p(e,t,i,s=8,n){const o=new Map;for(const h of t)h!=null&&h.id&&o.set(h.id,h);const a=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:i(h.id,h.ial),children:[]}),r=h=>{let d=h.parent_id,g=0;for(;d&&d!==e&&g++<16;){const m=o.get(d);if(!m||!_p(m))return d;d=m.parent_id}return d||e},l=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||n&&n.size>0&&!n.has(h.id))continue;const d=r(h),g=l.get(d);g?g.push(h):l.set(d,[h])}if(n&&n.size>0)for(const h of l.values())h.sort((d,g)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(g.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(h,d)=>{const g=a(h);if(c.set(g.id,g),d>=s||!jo(g))return g;const m=l.get(g.id);return m&&m.length>0&&(g.children=m.map(b=>u(b,d+1))),g};return{topLevel:(l.get(e)||[]).map(h=>u(h,0)),byId:c}}const Ip={getBlockAttrs:Ko,getChildBlocks:bs,getDocBlocksOrders:Td,setBlockAttrs:He,sql:hs,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ed};class Mp{constructor(t){be(this,"deps");be(this,"attrOverrides",new Map);be(this,"trackedListSuperBlocks",new Map);be(this,"fallbackWarnedDocId","");this.deps={...Ip,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const n={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete n[o]:n[o]=String(a);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const s=this.attrOverrides.get(t);s&&(delete s[i],Object.keys(s).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},s=this.attrOverrides.get(t);s&&Object.assign(i,s);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let R=0;R<o.length;R++)o[R]&&a.set(o[R],R);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=Cp(n,c),f=new Map;if(Array.isArray(c))for(const R of c)R.id&&R.ial&&f.set(R.id,ho(R.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(d)){for(const R of d)if(R.block_id&&R.name){let $=f.get(R.block_id);$||($={},f.set(R.block_id,$)),$[R.name]=R.value||""}}const g=(R,$)=>{const T={...f.get(R)||($?ho($):{})},P=this.attrOverrides.get(R);return P&&Object.assign(T,P),T},m=Array.isArray(c)&&c.length>0?$p(t,c,g,8,a):null,b=n.map(R=>R.id).filter(Boolean),k=R=>({id:R.id,parent_id:R.parent_id,root_id:R.root_id||t,type:R.type,subType:R.subType,content:R.content||"",markdown:R.markdown||"",ial:g(R.id,R.ial),children:R.children}),y=async(R,$=0)=>{if(!R||$>8||!jo(R))return;const T=await this.deps.getChildBlocks(R.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){R.children=T.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:R.id,root_id:t,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:g(P.id,P.ial),children:[]}));for(const P of R.children)await y(P,$+1)}},w=new Map;for(const R of c)R!=null&&R.id&&w.set(R.id,R);const S=b.every(R=>{const $=w.get(R);return!$||!!$.type});let D=[],A=!1;if(m&&u.usable&&r&&S){this.fallbackWarnedDocId="";for(const[$,T]of u.leafPatch){const P=m.byId.get($);P&&(P.content=T.content,P.markdown=T.markdown)}const R=new Map;for(const $ of n)$!=null&&$.id&&R.set($.id,$);for(const $ of u.rebuildRoots){const T=m.byId.get($),P=R.get($);T&&P&&(T.content=P.content||"",T.markdown=P.markdown||""),await y(T)}for(const $ of n){if(!($!=null&&$.id)||m.byId.has($.id))continue;const T=k($);await y(T),m.byId.set(T.id,T),m.topLevel.push(T)}D=m.topLevel.filter($=>a.has($.id)).sort(($,T)=>(a.get($.id)??0)-(a.get(T.id)??0))}else b.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),D=n.map(R=>k(R))):m&&(D=m.topLevel);const C=async(R,$=0)=>{if(!(!R||R.length===0||$>8))for(const T of R){if(jo(T)&&(!T.children||T.children.length===0)){let ne=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!ne||ne.length===0){const Y=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;ne=await this.deps.sql(Y).catch(()=>[])||[]}if(Array.isArray(ne)&&ne.length>0){const Y=new Set(D.map(le=>le.id)),q=ne.filter(le=>le.id!==T.id&&!Y.has(le.id));q.length>0&&(T.children=q.map(le=>{const se=f.get(le.id)||(le.ial?ho(le.ial):{}),oe=this.attrOverrides.get(le.id);return oe&&Object.assign(se,oe),{id:le.id,parent_id:le.parent_id||T.id,root_id:le.root_id||t,type:le.type,subType:le.subType,content:le.content||"",markdown:le.markdown||"",ial:se}}))}}T.children&&T.children.length>0&&await C(T.children,$+1)}};A&&await C(D);const L=R=>{var $,T;for(const P of R)if(P.children&&P.children.length>0){L(P.children);for(const ne of P.children)if(ne.ial)for(const[Y,q]of Object.entries(ne.ial))Y.startsWith("custom-slides-")&&!(($=P.ial)!=null&&$[Y])&&(P.ial||(P.ial={}),P.ial[Y]=q);if(P.ial){for(const[ne,Y]of Object.entries(P.ial))if(ne.startsWith("custom-slides-"))for(const q of P.children)(q.type==="video"||q.type==="NodeVideo"||/<video\b/i.test(q.markdown||q.content||""))&&!((T=q.ial)!=null&&T[ne])&&(q.ial||(q.ial={}),q.ial[ne]=Y)}}};L(D),mp(D,R=>{const $={[ke]:R.layout};this.setBlockAttrOverride(R.blockId,$),(this.deps.setBlockAttrs||He)(R.blockId,$).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const O=this.trackedListSuperBlocks.get(t)||[],N=hp(t,D,{tracked:O,onTagChange:R=>{this.setBlockAttrOverride(R.blockId,R.attrs),R.blockId===t&&Object.assign(i,R.attrs);const $=P=>{for(const ne of P)ne.id===R.blockId&&(ne.ial||(ne.ial={}),Object.assign(ne.ial,R.attrs)),ne.children&&ne.children.length>0&&$(ne.children)};$(D),(this.deps.setBlockAttrs||He)(R.blockId,R.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const V=new Set,_=R=>{for(const $ of R){const T=$.markdown||$.content||"";if(T.includes("((")){const P=Ad(T);for(const ne of P)V.add(ne.blockId)}$.children&&$.children.length>0&&_($.children)}};_(D);const j={};if(V.size>0){const R=Array.from(V).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${R})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(j[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",K=pa(t,i,D,{baseUrl:x,refContentMap:j});try{const R=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;K.customThemeCss=Hs(R)}catch{K.customThemeCss=Hs(null)}return K}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const s=pa(t,{},[],{});return s.customThemeCss=Hs(null),s}}}const Le=new Mp;class vr{constructor(t){be(this,"devServerUrl","http://localhost:3030");be(this,"isConnected",!1);be(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,s=setTimeout(()=>i.abort(),t),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,s=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.background&&s.push(`background: ${i.background}`),i.colorSchema&&i.colorSchema!=="auto"&&s.push(`colorSchema: ${i.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},f=[],h=c===0;u.layout&&u.layout!=="default"&&f.push(`layout: ${u.layout}`),u.transition&&f.push(`transition: ${u.transition}`),u.background&&f.push(`background: ${u.background}`),u.class&&f.push(`class: "${u.class}"`);let d="";f.length>0?d=h?"":`---
${f.join(`
`)}
---

`:h||(d=`---

`);let g="";if(u.layout==="two-cols"){const b=l.blocks.filter(S=>S.slot!=="right"),k=l.blocks.filter(S=>S.slot==="right"),y=b.map(S=>S.rawMarkdown||S.content||"").join(`

`),w=k.map(S=>S.rawMarkdown||S.content||"").join(`

`);g=`${y}

::right::

${w}`}else g=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${d}${g}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${n}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",s){const n=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),s)try{const o=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(t),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(n),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const Tp={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function fi(e){return Tp[e]===!1}function kt(e){return!fi(e)}function Ep(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Lt(e){const t=Ep();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function br(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Lt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Xl(){var t,i;const e=br();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const s=Lt("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Ap(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Xs(){const e=br();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Lt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Ql(){var s,n;const e=br(),t={...(e==null?void 0:e.env)||{}};if(Xs()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=e==null?void 0:e.env)!=null&&s.APPDATA?`${e.env.APPDATA}\\npm`:"",(n=e==null?void 0:e.env)!=null&&n.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function Wo(e){var i,s,n;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((n=(s=(i=window.siyuan)==null?void 0:i.config)==null?void 0:s.system)!=null&&n.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function Bp(){const e=Lt("os"),t=Lt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class yr{constructor(t){be(this,"runner");this.runner=t||yr.defaultRunner}static async defaultRunner(t,i){var s;try{let n=(s=Lt("child_process"))==null?void 0:s.execFile;if(!n){const l=await import("node:child_process").catch(()=>({}));n=l==null?void 0:l.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=Xs()==="win32",r=Ql();return await new Promise(l=>{n(t,i,{timeout:5e3,shell:a,env:r},(c,u,f)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:f?String(f).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const t=Xl(),i=Xs();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(s=!0,n=r.stdout)}catch{}if(s){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class Dp{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pageChangedHandlers",[]);be(this,"readyHandlers",[]);be(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(s,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(i.type==="update-state"&&i.navState){const s=i.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const s of this.pageChangedHandlers)s(i.no,this.currentState.total||1,this.currentState)}}}}class Lp{constructor(t){be(this,"childProcess",null);be(this,"activePort",null);be(this,"isRunning",!1);be(this,"defaultPort");be(this,"maxPortRetries");be(this,"probeTimeoutMs");be(this,"customSpawner");be(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Lt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(s=>{const n=i.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=i+s;if(await this.isPortAvailable(n))return n}return i}async pollServerReady(t,i=8e3,s=300){const n=Date.now();for(;Date.now()-n<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),s),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,s))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(i);this.activePort=s;const o=Xs()==="win32"?"npx.cmd":"npx",a=Wo(t),r=["@slidev/cli",a,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let f=(l=Lt("child_process"))==null?void 0:l.spawn;if(!f){const g=await import("node:child_process").catch(()=>({}));f=g==null?void 0:g.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const h=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,d=Ql();this.childProcess=f(o,r,{cwd:h,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),Xs()==="win32"&&i.pid&&!this.customSpawner){const n=(t=Lt("child_process"))==null?void 0:t.exec;if(n)await new Promise(o=>{const a=setTimeout(o,400);n(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}const ha=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],ma=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function kr(e,t,i){return .299*e+.587*t+.114*i}function ga(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(i=>i+i).join("")),t.length>=6){const i=parseInt(t.substring(0,2),16),s=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(i)&&!isNaN(s)&&!isNaN(n))return kr(i,s,n)}return null}function va(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const i=Number(t[1]),s=Number(t[2]),n=Number(t[3]);if(isNaN(i)||isNaN(s)||isNaN(n))return null;if(t[4]!==void 0){const o=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(o)&&o<=.05)return null}return kr(i,s,n)}function ba(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const l=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(l)&&l<=.05)return null}const i=(Number(t[1])%360+360)%360/360,s=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let o,a,r;if(s===0)o=a=r=n*255;else{const l=n<.5?n*(1+s):n+s-n*s,c=2*n-l,u=f=>{let h=f;return h<0&&(h+=1),h>1&&(h-=1),h<1/6?c+(l-c)*6*h:h<1/2?l:h<2/3?c+(l-c)*(2/3-h)*6:c};o=u(i+1/3)*255,a=u(i)*255,r=u(i-1/3)*255}return kr(o,a,r)}function ec(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(ha.includes(t))return!0;if(ma.includes(t))return!1;if(t.startsWith("#")){const i=ga(t);return i===null?null:i>140}if(/^rgba?\s*\(/i.test(t)){const i=va(t);return i===null?null:i>140}if(/^hsla?\s*\(/i.test(t)){const i=ba(t);return i===null?null:i>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const i=[],s=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(s)for(const l of s){const c=ga(l);c!==null&&i.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const l of n){const c=va(l);c!==null&&i.push(c)}const o=t.match(/hsla?\s*\([^)]+\)/gi);if(o)for(const l of o){const c=ba(l);c!==null&&i.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const l of r)l!=="transparent"&&(ha.includes(l)?i.push(240):ma.includes(l)&&i.push(20));if(i.length>0)return i.reduce((c,u)=>c+u,0)/i.length>140;if(/\btransparent\b/.test(t))return!1}return null}function Ri(){var e,t,i,s,n,o,a,r,l,c,u,f,h;if(typeof window<"u"){const d=(i=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:i.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(s=document.documentElement)==null?void 0:s.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const g=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(g==="light"||g==="dark")return g;if((a=(o=document.documentElement)==null?void 0:o.classList)!=null&&a.contains("theme--dark")||(l=(r=document.body)==null?void 0:r.classList)!=null&&l.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(h=(f=document.body)==null?void 0:f.classList)!=null&&h.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function wr(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:Ri()}function tc(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=Ri();const i=()=>{const n=Ri();n!==t&&(t=n,e(n))},s=new MutationObserver(i);return document.documentElement&&s.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&s.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>s.disconnect()}class sn{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pendingMessages",[]);be(this,"slideChangedHandlers",[]);be(this,"blockClickedHandlers",[]);be(this,"openInEditorHandlers",[]);be(this,"clientReadyHandlers",[]);be(this,"openPeekDrawerHandlers",[]);be(this,"toggleFullscreenHandlers",[]);be(this,"openPresenterHandlers",[]);be(this,"captureProgressHandlers",[]);be(this,"capturePageDoneHandlers",[]);be(this,"captureCompleteHandlers",[]);be(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var n;const s={source:"siyuan-slides-host",action:t,payload:i};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=s:this.pendingMessages.push(s)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,s,n){const o=i?{...i,hostThemeMode:i.hostThemeMode||Ri()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:o,fullMarkdown:s,customThemeCss:n})}navigatePage(t,i){const s={pageIndex:t};typeof i=="number"&&(s.step=i),this.postMessage("NAVIGATE_PAGE",s)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var s,n;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((s=this.iframe)!=null&&s.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const ic={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Pp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Op=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Rp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,Np=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,zp=`${Fo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 幻灯片容器查询支持与代码块换行、弱提示滚动条样式 */
.slidev-page, .slidev-layout {
  container-type: size;
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Hp(e){var n;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=i.exec(e))!==null;){const o=(n=s[1])==null?void 0:n.trim();o&&!t.includes(o)&&t.push(o)}return t}class Fp{constructor(t){be(this,"workspacePath");be(this,"slidesFileName");be(this,"cliBridge",new vr);const i=Bp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const s=this.buildSlidesMarkdown(t),n=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=Wo(o),l=Wo(a),c=Hp(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const w of c){const S=ic[w]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${w}
// #endregion snippet
`;u.set(w,S)}t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",Pp),t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",Op),t.slides.some(w=>{var S;return((S=w.frontmatter)==null?void 0:S.layout)==="clover"})&&u.set("layouts/clover.vue",Rp),u.set("setup/root.ts",Np),u.set("styles/index.css",zp);const g=Lt("fs"),m=Lt("path");let b=!1;const k=m!=null&&m.dirname?m.dirname(r):"",y=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(g&&m&&y)try{g.existsSync(k)||g.mkdirSync(k,{recursive:!0}),g.writeFileSync(l,n,"utf-8"),g.writeFileSync(r,s,"utf-8");for(const[w,S]of u.entries()){const D=m.join(k,w),A=m.dirname(D);g.existsSync(A)||g.mkdirSync(A,{recursive:!0}),g.existsSync(D)||g.writeFileSync(D,S,"utf-8")}b=!0}catch{}if(!b&&i)try{const w=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),S=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await i(a,!1,S),await i(o,!1,w);for(const[D,A]of u.entries()){const C=`${this.workspacePath}/${D}`,L=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await i(C,!1,L).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(w){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(w)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class jp{constructor(){be(this,"mode","web-sandbox");be(this,"webBridge");be(this,"cliBridge");be(this,"nativeBridge");be(this,"processManager");be(this,"scaffolder");be(this,"envDetector");this.webBridge=new sn,this.cliBridge=new vr,this.nativeBridge=new Dp,this.processManager=new Lp,this.scaffolder=new Fp,this.envDetector=new yr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(t,i);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const o=n.physicalSlidesPath||n.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Wp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Up={key:0},Vp={key:1},qp={key:2},Gp={key:3},Kp={key:4},Yp={key:5},Zp={key:6},Jp={key:7},Xp={key:8},Qp={key:9},eh={key:10},th={key:11},ih={key:12},sh={key:13},nh={key:14},oh={key:15},rh={key:16},ah={key:17},lh={key:18},ch={key:19},dh={key:20},uh={key:21},fh={key:22},ph={key:23},hh={key:24},mh={key:25},gh={key:26},vh={key:27},bh={key:28},yh={key:29},kh={key:30},wh={key:31},xh={key:32},Sh={key:33},Ch={key:34},_h={key:35},$h={key:36},Ih={key:37},Mh={key:38},Th={key:39},Eh={key:40},Ah={key:41},Bh={key:42},Dh={key:43},Lh={key:44},Ph={key:45},Oh={key:46},Rh={key:47},Nh={key:48},zh={key:49},Hh={key:50},Fh={key:51},jh={key:52},Wh={key:53},Uh={key:54},Vh={key:55},qh={key:56},Gh={key:57},Kh={key:58},Yh={key:59},Zh={key:60},Jh={key:61},Xh={key:62},Qh={key:63},em={key:64},tm={key:65},im={key:66},sm={key:67},nm={key:68},om={key:69},rm={key:70},am={key:71},lm={key:72},cm=Rt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(J(),ee("svg",Wp,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",Up,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",Vp,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",qp,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",Gp,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",Kp,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",Yp,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",Zp,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Jp,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",Xp,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",Qp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",eh,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",th,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",ih,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",sh,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",nh,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",oh,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",rh,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",ah,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",lh,[...i[18]||(i[18]=[bt('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),ee("g",ch,[...i[19]||(i[19]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",dh,[...i[20]||(i[20]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",uh,[...i[21]||(i[21]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",fh,[...i[22]||(i[22]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",ph,[...i[23]||(i[23]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",hh,[...i[24]||(i[24]=[bt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),ee("g",mh,[...i[25]||(i[25]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",gh,[...i[26]||(i[26]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",vh,[...i[27]||(i[27]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",bh,[...i[28]||(i[28]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",yh,[...i[29]||(i[29]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",kh,[...i[30]||(i[30]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",wh,[...i[31]||(i[31]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",xh,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",Sh,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",Ch,[...i[34]||(i[34]=[p("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",_h,[...i[35]||(i[35]=[p("polyline",{points:"11 17 6 12 11 7"},null,-1),p("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",$h,[...i[36]||(i[36]=[p("polyline",{points:"13 17 18 12 13 7"},null,-1),p("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",Ih,[...i[37]||(i[37]=[p("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",Mh,[...i[38]||(i[38]=[p("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),p("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",Th,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",Eh,[...i[40]||(i[40]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",Ah,[...i[41]||(i[41]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",Bh,[...i[42]||(i[42]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",Dh,[...i[43]||(i[43]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",Lh,[...i[44]||(i[44]=[bt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",Ph,[...i[45]||(i[45]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",Oh,[...i[46]||(i[46]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",Rh,[...i[47]||(i[47]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",Nh,[...i[48]||(i[48]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",zh,[...i[49]||(i[49]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",Hh,[...i[50]||(i[50]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",Fh,[...i[51]||(i[51]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",jh,[...i[52]||(i[52]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",Wh,[...i[53]||(i[53]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",Uh,[...i[54]||(i[54]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",Vh,[...i[55]||(i[55]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",qh,[...i[56]||(i[56]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",Gh,[...i[57]||(i[57]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Kh,[...i[58]||(i[58]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",Yh,[...i[59]||(i[59]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",Zh,[...i[60]||(i[60]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Jh,[...i[61]||(i[61]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",Xh,[...i[62]||(i[62]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",Qh,[...i[63]||(i[63]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",em,[...i[64]||(i[64]=[bt('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",tm,[...i[65]||(i[65]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",im,[...i[66]||(i[66]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",sm,[...i[67]||(i[67]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",nm,[...i[68]||(i[68]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",om,[...i[69]||(i[69]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),ee("g",rm,[...i[70]||(i[70]=[bt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",am,[...i[71]||(i[71]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",lm,[...i[72]||(i[72]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ri=(e,t)=>{const i=e.__vccOpts||e;for(const[s,n]of t)i[s]=n;return i},ce=ri(cm,[["__scopeId","data-v-af7d02a2"]]),dm={class:"spm-immersion-header"},um={class:"spm-immersion-header__left"},fm={class:"spm-immersion-title"},pm={class:"spm-immersion-header__center"},hm={class:"spm-immersion-header__actions"},mm=["aria-label"],gm={class:"spm-immersion-body"},vm=Rt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,s=t;function n(){s("update:visible",!1),s("close")}function o(){i.closeOnClickMask&&n()}function a(){s("update:isMaximized",!i.isMaximized),s("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),n())}return(l,c)=>Ft((J(),ee("div",{class:$e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:ei(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:o}),p("div",{class:$e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",dm,[p("div",um,[cn(l.$slots,"header-left",{},()=>[p("span",fm,we(e.title),1)])]),p("div",pm,[cn(l.$slots,"header-center",{},void 0)]),p("div",hm,[cn(l.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[re(ce,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,mm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[re(ce,{name:"close"})])])]),p("div",gm,[cn(l.$slots,"default",{},void 0)])],2)],34)),[[No,e.visible]])}}),bm=ri(vm,[["__scopeId","data-v-1359fecb"]]),ym={class:"spm-protyle-drawer"},km={class:"spm-protyle-drawer__subbar"},wm={class:"spm-protyle-drawer__nav"},xm=["title"],Sm={class:"spm-protyle-drawer__actions"},Cm=["aria-label"],_m=["aria-label"],$m=Rt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,s=e,n=ge(s.blockId),o=ge(s.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),u=Zt,f=ge([]),h=ge(null);let d=null;Zi(()=>s.blockId,C=>{C&&C!==n.value&&(n.value=C,o.value=s.title||"",f.value=[],m(C))}),ws(()=>{n.value&&m(n.value)}),lr(()=>{b()});async function g(C){try{const L=await hs(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const O=L[0];c.value=O.root_id||"";const N=O.id===O.root_id||O.type==="d";l.value=N,r.value=!N,!o.value&&O.content&&(o.value=O.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}l.value=!1,r.value=!0}async function m(C,L){if(!h.value||!C)return;b(),await g(C),typeof L=="boolean"&&(r.value=!l.value&&L);let O,N;r.value&&!l.value?(O=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(O=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ae.Protyle(s.plugin.app,h.value,{blockId:C,action:O,render:N}),!a.value&&d&&typeof d.disable=="function"&&d.disable()}catch(V){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",V)}}function b(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}d=null}h.value&&(h.value.innerHTML="")}function k(){l.value||(r.value=!r.value,m(n.value,r.value))}function y(){a.value=!a.value,d&&(a.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function w(){if(n.value)try{ae.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function S(){var O;if(!n.value)return;const C=Qn(),L=ql(C.webServeUrl,n.value,{focus:!l.value});if(typeof window<"u"){const N=Lt("electron");(O=N==null?void 0:N.shell)!=null&&O.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}i("external-jump",L)}function D(){if(f.value.length>0){const C=f.value.pop();C&&(n.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function A(C){const L=C.target;if(!L)return;const O=L.closest('[data-type="block-ref"]');if(O){const V=O.getAttribute("data-id");if(V&&V!==n.value){C.preventDefault(),C.stopPropagation(),f.value.push({blockId:n.value,title:o.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=V,o.value=O.innerText.trim()||V,m(V);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const V=N.href.replace("siyuan://blocks/","").split("?")[0];V&&V!==n.value&&(f.value.push({blockId:n.value,title:o.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=V,o.value=N.innerText.trim()||V,m(V))}}return(C,L)=>(J(),ee("div",ym,[p("div",km,[p("div",wm,[f.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:D},[re(ce,{name:"arrow-left"}),L[0]||(L[0]=p("span",null,"返回",-1))])):Te("",!0),p("span",{class:$e(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},we(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:o.value||n.value},we(o.value||n.value),9,xm)]),p("div",Sm,[l.value?Te("",!0):(J(),ee("button",{key:0,class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[re(ce,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,Cm)),p("button",{class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:y},[re(ce,{name:a.value?"edit":"eye"},null,8,["name"]),p("span",null,we(a.value?"编辑中":"只读"),1)],10,_m),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:w},[re(ce,{name:"window"}),L[1]||(L[1]=p("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:S},[re(ce,{name:"external-link"}),L[2]||(L[2]=p("span",null,"外跳",-1))])):Te("",!0)])]),p("div",{ref_key:"mountEl",ref:h,class:$e(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:A},null,2)]))}}),Im=ri($m,[["__scopeId","data-v-0d6e2df3"]]),Mm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Tm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function ya(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const s=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return s?`/plugins/${s[1]}`:null}function sc(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const s=i.indexOf("/");return s>=0?i.slice(s):i}function Em(e){const t=e.split(/[/?#]/)[0];return!t||Tm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function Am(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",s=t>=0?e.slice(0,t):e,n=s.indexOf("?"),o=n>=0?s.slice(0,n):s,a=n>=0?s.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function nc(e){const t=Bm(e);return t.external||!t.url?t:{url:Am(t.url),external:!1}}function Bm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(za(t))return{url:`/${Ha(t)}`,external:!1};if(/^file:/i.test(t)){const s=ya(sc(t));return s?{url:s,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const s=ya(t);return s?{url:s,external:!1}:{url:t,external:!0}}return Mm.test(t)?{url:t,external:!0}:Em(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Dm={class:"spm-webview-drawer"},Lm={class:"spm-webview-toolbar"},Pm={class:"spm-webview-toolbar__nav"},Om=["disabled"],Rm=["disabled"],Nm=["aria-label"],zm={class:"spm-webview-toolbar__address"},Hm=["aria-label"],Fm={class:"spm-webview-toolbar__actions"},jm=["aria-label"],Wm={class:"spm-zoom-controller"},Um=["disabled"],Vm=["disabled"],qm={key:1,class:"spm-webview-fallback"},Gm=["src"],Km={key:2,class:"spm-load-error"},Ym={class:"spm-load-error__code"},Zm={class:"spm-load-error__code-num"},Jm={class:"spm-load-error__url"},Xm={class:"spm-load-error__hint"},Qm={class:"spm-load-error__actions"},ka="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",oc="siyuan-slides-peek-view-mode";let rc="desktop";function eg(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(oc);if(e==="mobile"||e==="desktop")return e}catch{}return rc}function tg(e){if(rc=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(oc,e)}catch{}}function ig(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const sg=Rt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,s=e,n=ge(Xl()&&!Ap()),o=ge(s.url),a=ge(s.url),r=s.url,l=ge(!1),c=ge(null),u=ge(!1),f=ge(!1),h=ge(1),d=ge(!1),g=ge(eg());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ye(()=>g.value==="mobile"?ka:m||void 0),k=ge(null),y=ge(null);let w=null,S=null,D=null;Zi(()=>s.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,g.value==="mobile"&&N(!1),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(X))}),Zi(()=>s.visible,X=>{if(X)le(),g.value==="mobile"&&N(!1);else if(k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}}),ws(()=>{A(),y.value&&typeof ResizeObserver<"u"&&(w=new ResizeObserver(()=>{const X=k.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),w.observe(y.value)),S=X=>{var E;const ue=X.message||((E=X.error)==null?void 0:E.message);if(typeof ue=="string"&&ue.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),D=X=>{const ue=X.reason,E=typeof ue=="string"?ue:ue==null?void 0:ue.message;typeof E=="string"&&E.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",D)}),lr(()=>{if(C(),w&&(w.disconnect(),w=null),S&&(window.removeEventListener("error",S,!0),S=null),D&&(window.removeEventListener("unhandledrejection",D),D=null),k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}});function A(){const X=k.value;X&&(X.addEventListener("dom-ready",L),X.addEventListener("did-start-loading",V),X.addEventListener("did-stop-loading",x),X.addEventListener("did-navigate",K),X.addEventListener("did-navigate-in-page",R),X.addEventListener("new-window",$),X.addEventListener("did-fail-load",_),X.addEventListener("did-fail-provisional-load",_))}function C(){const X=k.value;if(X)try{X.removeEventListener("dom-ready",L),X.removeEventListener("did-start-loading",V),X.removeEventListener("did-stop-loading",x),X.removeEventListener("did-navigate",K),X.removeEventListener("did-navigate-in-page",R),X.removeEventListener("new-window",$),X.removeEventListener("did-fail-load",_),X.removeEventListener("did-fail-provisional-load",_)}catch{}}function L(){const X=k.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const ue=X.getUserAgent();ue&&!ue.includes("iPhone")&&(m=ue)}catch{}g.value==="mobile"&&N(!1),le(),T()}function O(){const X=g.value==="mobile"?"desktop":"mobile";g.value=X,tg(X),N(!0)}function N(X=!1){const ue=k.value;if(!ue)return;const E=g.value==="mobile"?ka:m;if(typeof ue.setUserAgent=="function"&&E)try{ue.setUserAgent(E)}catch(H){console.warn("[WebviewPeekDrawer] setUserAgent error:",H)}if(X&&typeof ue.reload=="function")try{ue.reload()}catch(H){console.warn("[WebviewPeekDrawer] reload error:",H)}}function V(){l.value=!0,c.value=null}function _(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const ue=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:ue,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:ig(ue)},l.value=!1}function j(){c.value=null,Y()}function x(){if(l.value=!1,T(),k.value&&typeof k.value.getURL=="function"){const X=k.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function K(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function R(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function $(X){X&&X.url&&(X.preventDefault(),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(X.url))}function T(){const X=k.value;X&&(typeof X.canGoBack=="function"&&(u.value=X.canGoBack()),typeof X.canGoForward=="function"&&(f.value=X.canGoForward()))}function P(){k.value&&typeof k.value.goBack=="function"&&k.value.goBack()}function ne(){k.value&&typeof k.value.goForward=="function"&&k.value.goForward()}function Y(){k.value&&typeof k.value.reload=="function"&&k.value.reload()}function q(){const X=nc(a.value);if(X.url){if(X.external){o.value=X.url,fe();return}o.value=X.url,a.value=X.url,k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(X.url)}}function le(){const X=k.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(h.value)}catch(ue){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ue)}}function se(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),le()}function oe(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),le()}function _e(){h.value=1,le()}function Ie(X){X.preventDefault(),X.deltaY<0?se():X.deltaY>0&&oe()}async function xe(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function fe(){var ue;const X=o.value;if(typeof window<"u"){const E=Lt("electron");(ue=E==null?void 0:E.shell)!=null&&ue.openExternal?E.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,ue)=>{const E=Hu("webview");return J(),ee("div",Dm,[p("div",Lm,[p("div",Pm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:P},[re(ce,{name:"arrow-left"})],8,Om),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:ne},[re(ce,{name:"arrow-right"})],8,Rm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:Y},[re(ce,{name:"refresh"})],8,Nm)]),p("div",zm,[Ft(p("input",{"onUpdate:modelValue":ue[0]||(ue[0]=H=>a.value=H),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:ip(q,["enter"])},null,544),[[zo,a.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:xe},[re(ce,{name:"copy"})],8,Hm)]),p("div",Fm,[p("button",{class:$e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:O},[re(ce,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,jm),p("div",Wm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:oe},[re(ce,{name:"minus"})],8,Um),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:_e},we(Math.round(h.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:se},[re(ce,{name:"plus"})],8,Vm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[re(ce,{name:"external-link"}),ue[1]||(ue[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:y,class:$e(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:ei(Ie,["ctrl"])},[p("div",{class:$e(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(J(),ti(E,{key:0,ref_key:"webviewRef",ref:k,class:"spm-webview-frame",src:he(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",qm,[p("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Gm),p("div",{class:"spm-fallback-bar"},[ue[2]||(ue[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",Km,[re(ce,{name:"alert",class:"spm-load-error__icon"}),ue[5]||(ue[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",Ym,[Bt(we(c.value.description)+" ",1),p("span",Zm,"("+we(c.value.errorCode)+")",1)]),p("div",Jm,we(c.value.validatedURL),1),p("p",Xm,we(c.value.hint),1),p("div",Qm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:j},[re(ce,{name:"refresh"}),ue[3]||(ue[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[re(ce,{name:"external-link"}),ue[4]||(ue[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),ng=ri(sg,[["__scopeId","data-v-6e363f73"]]);class og{constructor(){be(this,"timers",new Map)}debounce(t,i,s=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),i()},s);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class rg{constructor(t){be(this,"blockToPageMap",new Map);be(this,"debounceCtrl",new og);be(this,"activeBlockId","");be(this,"activePageIndex",1);be(this,"currentDocId","");be(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const s of i.blocks)this.blockToPageMap.set(s.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Pt=null,vn=null,bn="";function Fs(){var e,t;if(vn&&(clearTimeout(vn),vn=null),Pt){try{Pt.classList.remove("protyle-wysiwyg--select"),bn?Pt.style.outline=bn:typeof((e=Pt.style)==null?void 0:e.removeProperty)=="function"?Pt.style.removeProperty("outline"):Pt.style&&(Pt.style.outline=""),typeof((t=Pt.style)==null?void 0:t.removeProperty)=="function"?Pt.style.removeProperty("transition"):Pt.style&&(Pt.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}Pt=null,bn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(s=>{var o,a;s.classList.remove("protyle-wysiwyg--select");const n=((o=s.style)==null?void 0:o.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((a=s.style)==null?void 0:a.removeProperty)=="function"?(s.style.removeProperty("outline"),s.style.removeProperty("transition")):s.style&&(s.style.outline="",s.style.transition=""))})}catch{}}function Ji(e,t){var a,r,l,c;if(!e||typeof document>"u")return Fs(),!1;Fs();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!s){if(t)try{return ae.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=s.scrollIntoView)==null||r.call(s)}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}const n=((c=s.style)==null?void 0:c.outline)||"";return bn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,s.classList.add("protyle-wysiwyg--select"),s.style&&(s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.2s ease"),Pt=s,vn=setTimeout(()=>{Fs()},500),!0}function ag(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>dt(a)).join("<br/>");const s=[];let n=[];const o=()=>{if(n.length>0){const a=n.map(r=>dt(r)).join("<br/>");s.push(`<p class="slide-list-item-desc">${a}</p>`),n=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();s.push(`<h${l} class="slide-list-item-title">${dt(c)}</h${l}>`)}else n.push(a)}return o(),s.join(`
`)}function lg(e){if(e.length===0)return"";const t=[],i=e[0],s=i.match(/^(#{1,6})\s+(.*)$/);if(s){const n=s[1].length,o=s[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(o)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(i)}</p>`);if(e.length>1){const n=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>dt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of n){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function ac(e,t,i){var h,d,g,m;const s=e.split(`
`);if(!s.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return(i!=null&&i.isListItem||(i==null?void 0:i.type)==="i")&&!(i!=null&&i.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const o=[],a=[];let r=!1;for(let b=0;b<s.length;b++){const k=s[b];if(!k.trim())continue;const y=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(y){const A=y[1].length,C=Math.floor(A/2);a.push({type:"task",level:C,checked:y[2].toLowerCase()==="x",text:y[3],media:[]});continue}const w=k.match(/^(\s*)[-*+]\s+(.*)$/);if(w){const A=w[1].length,C=Math.floor(A/2);a.push({type:"unordered",level:C,text:w[2],media:[]});continue}const S=k.match(/^(\s*)\d+\.\s+(.*)$/);if(S){a.length===0&&(r=!0);const A=S[1].length,C=Math.floor(A/2);a.push({type:"ordered",level:C,text:S[2],media:[]});continue}const D=k.trim();if(!(!D||/^\{:.*?\}$/.test(D)))if(a.length>0){const A=D.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const O=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${rt(A[1])}" src="${A[2]}" class="${O}" /></div>`);continue}if(D.match(/^<img\b[\s\S]*?\/?>$/i)){const L=D.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(D)){let L=D;if(!/<\/video>/i.test(L))for(;b+1<s.length&&!/<\/video>/i.test(L);)b++,L+=" "+s[b].trim();const O=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),N=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(L),V=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slides-muted"])==="true"||O||/muted/i.test(L),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",j=L.match(/\bsrc=["']([^"']+)["']/i),x=j?j[1]:"",K=['class="slide-video-player"'];_||K.push("controls"),O&&(K.push("autoplay"),K.push("playsinline")),N&&K.push("loop"),V&&K.push("muted"),K.push('preload="metadata"'),x&&K.push(`src="${x}"`);const R=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=R?R[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${V?"true":"false"}"><video ${K.join(" ")}>${$}</video></div>`);continue}a[a.length-1].text+=`
`+D}else o.push(D)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(b=>{const k=ag(b.text),y=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",w=b.level||0,S=w>0?` style="margin-left:${(w*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${w%2===1?"circle":"square"} !important;`:""}"`:"",D=w>0?" slide-list-item--nested":"";if(b.type==="task"){const C=b.checked?' checked=""':"";return`<li class="pdf-task-item${D}"${S}><label><input type="checkbox" disabled=""${C}/> <span>${k}</span></label>${y}</li>`}return`<li${D?` class="${D.trim()}"`:""}${S}>${k}${y}</li>`}).join(`
`);return`${lg(o)}<${l} class="${c}">
${u}
</${l}>`}function cg(e,t,i){const s=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<n.length;c++){const u=n[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(!f){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(/<video\b/i.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]);let h=f;if(!/<\/video>/i.test(h))for(;c+1<n.length&&!/<\/video>/i.test(h);)c++,h+=`
`+n[c];o.push(h);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var g,m,b,k;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const y=f[1].length;return`<h${y} class="slide-list-item-title">${dt(f[2].trim())}</h${y}>`}const h=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const y=/\.gif(?:\?|$)/i.test(h[2]),w=(t==null?void 0:t.imageClassName)||(y?"list-item-gif":"pdf-image slide-media-img");return`<div class="${s} ${s}--image slide-media-block slide-media-container slide-list-media"><img alt="${rt(h[1])}" src="${h[2]}" class="${w}" /></div>`}if(/<video\b/i.test(u)){const y=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),w=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),S=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||y||/muted/i.test(u),D=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slides-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),C=A?A[1]:"",L=['class="slide-video-player"'];D||L.push("controls"),y&&L.push("autoplay playsinline"),w&&L.push("loop"),S&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const O=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=O?O[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${s} ${s}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${y?"true":"false"}" data-muted="${S?"true":"false"}"><video ${L.join(" ")}>${N}</video></div>`}const d=ac(u,t,i);if(d)return r=!1,d;if(r){r=!1;const y=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(y.length===1)return`<p class="slide-list-item-title">${dt(y[0])}</p>`;const w=y[0],D=y.slice(1).map(A=>dt(A)).join("<br/>");return`<p class="slide-list-item-title">${dt(w)}</p>
<p class="slide-list-item-desc">${D}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function mo(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function lc(e,t){var r,l,c,u,f,h,d,g;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:n.find(mo);if(i==="two-cols"){const m=n.some(V=>V.slot==="right");let b=[],k=[];if(m)b=n.filter(V=>V.slot!=="right"),k=n.filter(V=>V.slot==="right");else{const V=Math.ceil(n.length/2);b=n.slice(0,V),k=n.slice(V)}const y=V=>{const _=V.filter(j=>!!(j.rawMarkdown||j.content||"").trim());if(_.length>0){const j=_[0],x=(j.rawMarkdown||j.content||"").trim();(Oi(j)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(j.rawMarkdown=Ns(j.rawMarkdown||j.content||""),j.content=j.rawMarkdown)}};y(b),y(k);const w=b.map(V=>Ii(V,t)).join(`
`),S=k.map(V=>Ii(V,t)).join(`
`),D=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",L=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${po((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${D}${A}" ${N}>
        <div class="${C}">${w}</div>
        <div class="${L}">${S}</div>
      </div>
    `}if(i==="clover"||ls(i)){const m=i==="clover";let b=[];const k=n.filter(K=>K.slot==="header");if(k.length>0)b=k;else if(n.length>0){const K=n.find(R=>R.type==="h"&&(!R.slot||R.slot==="default"));K&&(b=[K])}const y=n.filter(K=>!b.includes(K));let w=2;if(m)w=4;else if(i==="three-cols-header")w=3;else if(i==="two-cols-header")w=2;else{let K=0;for(const R of y){const $=(R.slot||"").match(/^col-(\d+)$/i);$&&(K=Math.max(K,parseInt($[1],10)))}if(K>=2)w=K;else if((u=e.frontmatter)!=null&&u.layoutRatio){const R=e.frontmatter.layoutRatio.trim();if(R.includes(":")){const $=R.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(w=$.length)}else{const $=R.split(/\s+/).filter(Boolean);$.length>=2&&(w=$.length)}}else y.length===1&&y[0].children&&y[0].children.length>=2&&(w=Math.min(6,y[0].children.length))}const S=Jl(y,w),D=y.some(K=>K.slot&&/^(?:col-\d+|left|right)$/i.test(K.slot)),A=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||ls(i)&&D,C=K=>{const R=K.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(A&&R.length>0){const T=R[0],P=(T.rawMarkdown||T.content||"").trim();(Oi(T)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(T.rawMarkdown=Ns(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=A?R.find(mo):null;return R.map(T=>Ii(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},L=b.find(mo),O=b.map(K=>Ii(K,{...t,extraClassName:K===L?"slides-page-first-heading-block":""})).join(`
`),N=m?"repeat(2, minmax(0, 1fr))":po((f=e.frontmatter)==null?void 0:f.layoutRatio,w),V=m?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,_=[m?"layout-clover-container":"layout-cols-header-container",w===2?"layout-two-cols-header-container":"",w===3?"layout-three-cols-header-container":"",`layout-${i}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),j=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",w===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",w===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),x=S.map((K,R)=>{const $=R+1;return`<div class="${["pdf-col",w===2&&$===1?"pdf-col--left":"",w===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${C(K)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${O}</div>
        <div class="${j}" ${V}>
          ${x}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=n.map(A=>Ii(A,t)).join(`
`),k=((h=e.frontmatter)==null?void 0:h.image)||((d=e.frontmatter)==null?void 0:d.background)||"",y=`<div class="pdf-image-col" style="background-image:url('${rt(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${rt(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,w=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,S=m?`${w}
${y}`:`${y}
${w}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${po((g=e.frontmatter)==null?void 0:g.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${S}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${n.map(b=>Ii(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${n.map(b=>Ii(b,t)).join(`
`)}</div>`:n.map(m=>Ii(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function rt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function dg(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const s of i){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[o,a]=n.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(n,10);isNaN(o)||t.add(o)}}return t}const ug=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=Yl(e),i=[],s=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!ug.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let n=rt(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,f)=>{const d=(r??l??c??u??f??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),n}function fg(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=i[0];let n=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(n=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${s.map((l,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function go(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function wa(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${go(e)}</span>`;const i=[];function s(o,a){return i.push(`<span class="${o}">${go(a)}</span>`),`__TOK_${i.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>s("token-string",`${a}${r}${a}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>s("token-keyword",o)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>s("token-type",o)),n=n.replace(/\b(\d+)\b/g,o=>s("token-number",o)),n=go(n),n=n.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),n}function pg(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let s=(i.title||"").trim(),n=i.level?parseInt(i.level,10):0;if(!s){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){n||(n=l[1].length),s=l[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:s,level:n}):null}function hg(e,t=1,i={}){const s=i.minDepth!==void 0?Number(i.minDepth):1,n=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=pg(c,u+1);f&&o.push(f)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>n)return[];const f=[];for(const h of c){const d=l(h.children,u+1);u>=s?f.push({...h,children:d}):f.push(...d)}return f}return l(a,1)}function mg(e,t=1,i={}){const s=hg(e,t,i),n=i.columns?Number(i.columns):1,o=n>1?` style="column-count: ${n};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,h=c.map(d=>{const g=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let b=dt(d.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${g}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${h}</ol>`}const l=r(s,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function Ii(e,t){var D,A,C,L,O,N,V,_,j,x,K,R;let i="",s="",n="";const o=[];(D=e.motion)!=null&&D.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((A=e.attributes)==null?void 0:A.style)||"";a&&(o.push(a),n=" slide-styled-block"),o.length>0&&(s=` style="${rt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${i}${n}${l}${u}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${f}"${s}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${f}"${s}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const $=h.slice(2,-2).trim();return`<div class="${f} katex-display-container"${s}><div class="katex-display font-math"><em>${rt($)}</em></div></div>`}const d=h.match(/^(#{1,6})\s+(.*)$/);if(d){const $=d[1].length,T=dt(d[2]),ne=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${s}><h${$}${ne}>${T}</h${$}></div>`}if(h.startsWith(":::")){const $=h.split(`
`),P=$[0].replace(/^:::\s*/,"").trim()||"info",ne=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),Y=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${s}><div class="${Y} ${Y}--${P}"><div class="${Y}-title">${P.toUpperCase()}</div><div class="${Y}-body">${dt(ne)}</div></div></div>`}if(h.startsWith("<<<")){const P=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((se,oe)=>`<span class="code-line shiki-focus"><span class="line-no">${oe+1}</span><span class="line-content">${wa(se,"ts")}</span></span>`).join(`
`),ne=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",Y=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((O=e.attributes)==null?void 0:O["custom-slides-max-height"])||e.maxHeight||"",q=Nn(String(Y||"")),le=q?` style="max-height:${rt(q)};overflow-y:auto;"`:"";return`<div class="${f}"${s}><pre class="${ne}"${le}><span class="lang-badge">TS</span><code>${P}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const $=h.split(`
`),T=$[0].slice(3).trim(),P=T.match(/^([^\s{\[]+)/),ne=P?P[1]:"",Y=T.match(/\[([^\]]+)\]/),q=Y?Y[1]:"",le=T.includes("twoslash"),se=e.shikiLines||((N=T.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",oe=dg(se),_e=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[h.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",xe=q?`${Ie} has-filename`:Ie,fe=oe!=="all",X=_e.map((F,M)=>{const I=M+1,G=oe==="all"||oe.has(I)?"code-line shiki-focus":fe?"code-line shiki-dimmed":"code-line";let B=(t==null?void 0:t.highlight)===!0?wa(F,ne):rt(F);return le&&F.includes("doubled.value = 2")?(B=B.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${B}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${B}</span></span>`}).join(`
`),ue=ne?`<span class="lang-badge">${rt(ne)}</span>`:"",E=q?`<span class="code-filename">${rt(q)}</span>`:"",H=((V=e.attrs)==null?void 0:V["custom-slides-max-height"])||((_=e.attributes)==null?void 0:_["custom-slides-max-height"])||e.maxHeight||"",v=Nn(String(H||"")),W=v?` style="max-height:${rt(v)};overflow-y:auto;"`:"";return`<div class="${f}"${s}><pre class="${xe}"${W}>${E}${ue}<code>${X}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=h.split(`
`).filter(P=>P.trim().startsWith("|")),T=fg($,t==null?void 0:t.tableClassName);return`<div class="${f}"${s}>${T}</div>`}if(h.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${s}><blockquote class="${$}"><p>${dt(h.slice(2))}</p></blockquote></div>`}const g=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),b=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(g&&!m&&!b&&!h.includes(`
`)){const $=((j=e.attributes)==null?void 0:j["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(h),P=((K=e.attributes)==null?void 0:K["custom-slides-muted"])==="true"||$||/muted/i.test(h),ne=((R=e.attributes)==null?void 0:R["custom-slides-controls"])==="false",Y=h.match(/\bsrc=["']([^"']+)["']/i),q=Y?Y[1]:"",le=['class="slide-video-player"'];ne||le.push("controls"),$&&(le.push("autoplay"),le.push("playsinline")),T&&le.push("loop"),P&&le.push("muted"),le.push('preload="auto"'),q&&le.push(`src="${q}"`);const se=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let oe=se?se[1].trim():"";return!oe&&q&&(oe=`<source src="${q}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${P?"true":"false"}"${s}><video ${le.join(" ")}>${oe}</video></div>`}const k=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(k){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${s}><img alt="${rt(k[1])}" src="${k[2]}" class="${$}" /></div>`}const y=ac(h,t,e);if(y)return`<div class="${f} pdf-list-item"${s}>${y}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const $=h.match(/minDepth=["']?(\d+)["']?/i),T=h.match(/maxDepth=["']?(\d+)["']?/i),P=h.match(/columns=["']?(\d+)["']?/i),ne=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${s}>${mg(ne,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:P?parseInt(P[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||b){const $=cg(h,t,e);if($)return`<div class="${f}"${s}>${$}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${s}><p${S}>${dt(h)}</p></div>`}function gg(e){return`
    ${Hs(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default,
    .slide-viewport[data-theme="light"].slides-theme-default,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default,
    .slide-viewport[data-theme="dark"].slides-theme-default,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-default,
    .slide-viewport[data-theme="light"].slides-theme-default {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-default,
    .slide-viewport[data-theme="dark"].slides-theme-default {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：非 cover 页首标题带科技 Accent 垂直指示条 */
    .slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .slides-theme-default:not(.layout-cover) .cols-header-top h1,
    .slides-theme-default:not(.layout-cover) .cols-header-top h2,
    .slides-theme-default:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-default:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-default:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-default:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border-left: 4px solid var(--slide-accent);
      padding-left: 14px;
      letter-spacing: -0.015em;
    }
    .slides-theme-default blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-default pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅学术风：非 cover 页首标题带典雅细下划线 */
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 6px;
      display: inline-block;
      margin-bottom: 12px;
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：绝对去装饰化，特大字重力量感，无边框与线条 */
    .slides-theme-apple-basic:not(.layout-cover) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover) .slide-content > .slide-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover) .slide-content > .slide-block:first-child h2 {
      border: none !important;
      padding: 0 !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function vg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function bg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function yg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function kg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function wg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function xg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function Sg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function Cg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function _g(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function $g(){return[vg(),bg(),yg(),kg(),wg(),xg(),Sg(),Cg(),_g()].join("")}function cc(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let s=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const r=t.inlineAssetBase64Map;s=e.slides.map(l=>{let c=l.rawMarkdown;for(const[h,d]of Object.entries(r))c.includes(h)&&(c=c.split(h).join(d));const u=l.blocks.map(h=>{let d=h.rawMarkdown;for(const[g,m]of Object.entries(r))d.includes(g)&&(d=d.split(g).join(m));return{...h,rawMarkdown:d}});let f=l.frontmatter?{...l.frontmatter}:l.frontmatter;if(f){if(typeof f.background=="string")for(const[h,d]of Object.entries(r))f.background.includes(h)&&(f.background=f.background.split(h).join(d));if(typeof f.image=="string")for(const[h,d]of Object.entries(r))f.image.includes(h)&&(f.image=f.image.split(h).join(d))}return{...l,rawMarkdown:c,blocks:u,frontmatter:f}})}const n=wr(e.config.colorSchema),o=JSON.stringify(s),a=JSON.stringify({...e.config,hostThemeMode:e.config.hostThemeMode||n});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${rt(i)}</title>
  <style>
${gg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${a}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${n}" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-theme="${n}" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${$g()}
  <\/script>
</body>
</html>`}function dc(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(i),n=document.createElement("a");return n.href=s,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function Ig(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Mg(e){const t=Ig(e==null?void 0:e.pageRatio);return`
    ${Hs(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-default {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-default.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-default.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-default .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-default .pdf-block h1 { color: #10b981; }
    .slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-left: 4px solid #059669;
      padding-left: 12px;
    }
    .theme-dark.slides-theme-default:not(.layout-cover) .layout-header-section h1,
    .theme-dark.slides-theme-default:not(.layout-cover) .layout-header-section h2,
    .theme-dark.slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-default:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-left-color: #10b981;
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 6px;
      display: inline-block;
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover) .pdf-slide-body > .pdf-block:first-child h2 {
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Tg(e,t){const i="即现演示讲义",s="16:9",n=wr(e.config.colorSchema),o=e.config.theme||"default",a=e.slides.map((r,l)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,f=u&&u!=="inherit"?u:e.config.spacing||"normal",h=lc(r),d=`${l+1} / ${e.slides.length}`,g=r.frontmatter.background||e.config.background,m=ec(g),b=m===!0?"light":m===!1?"dark":n,k=g&&!/^(http|\/|data:|assets\/)/.test(g)?`background: ${rt(g)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${b} spacing-${f} slides-theme-${o}" data-slides-theme="${o}" style="${k}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${rt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${h}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${rt(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${rt(i)} - 高保真讲义</title>
  <style>
    ${Mg({pageRatio:s,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${a}
</body>
</html>`}function uc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const i=Tg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(n=o.contentWindow)==null?void 0:n.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const s=window.open("","_blank");return s?(s.document.write(i),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}var fn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Eg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function pn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var vo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var xa;function Ag(){return xa||(xa=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(s,n,o){function a(c,u){if(!n[c]){if(!s[c]){var f=typeof pn=="function"&&pn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var d=n[c]={exports:{}};s[c][0].call(d.exports,function(g){var m=s[c][1][g];return a(m||g)},d,d.exports,i,s,n,o)}return n[c].exports}for(var r=typeof pn=="function"&&pn,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,s,n){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(l){for(var c,u,f,h,d,g,m,b=[],k=0,y=l.length,w=y,S=o.getTypeOf(l)!=="string";k<l.length;)w=y-k,f=S?(c=l[k++],u=k<y?l[k++]:0,k<y?l[k++]:0):(c=l.charCodeAt(k++),u=k<y?l.charCodeAt(k++):0,k<y?l.charCodeAt(k++):0),h=c>>2,d=(3&c)<<4|u>>4,g=1<w?(15&u)<<2|f>>6:64,m=2<w?63&f:64,b.push(r.charAt(h)+r.charAt(d)+r.charAt(g)+r.charAt(m));return b.join("")},n.decode=function(l){var c,u,f,h,d,g,m=0,b=0,k="data:";if(l.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var y,w=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&w--,l.charAt(l.length-2)===r.charAt(64)&&w--,w%1!=0)throw new Error("Invalid base64 input, bad content length.");for(y=a.uint8array?new Uint8Array(0|w):new Array(0|w);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(h=r.indexOf(l.charAt(m++)))>>4,u=(15&h)<<4|(d=r.indexOf(l.charAt(m++)))>>2,f=(3&d)<<6|(g=r.indexOf(l.charAt(m++))),y[b++]=c,d!==64&&(y[b++]=u),g!==64&&(y[b++]=f);return y}},{"./support":30,"./utils":32}],2:[function(i,s,n){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,f,h,d,g){this.compressedSize=u,this.uncompressedSize=f,this.crc32=h,this.compression=d,this.compressedContent=g}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,h){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(f.compressWorker(h)).pipe(new l("compressedSize")).withStreamInfo("compression",f)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,s,n){var o=i("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},n.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,s,n){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();s.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,f,h){var d=a,g=h+f;c^=-1;for(var m=h;m<g;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,f,h){var d=a,g=h+f;c^=-1;for(var m=h;m<g;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(i,s,n){var o=null;o=typeof Promise<"u"?Promise:i("lie"),s.exports={Promise:o}},{lie:37}],7:[function(i,s,n){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(f,h){l.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=h,this.meta={}}n.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(h){f.push({data:h,meta:f.meta})}},n.compressWorker=function(f){return new u("Deflate",f)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,s,n){function o(d,g){var m,b="";for(m=0;m<g;m++)b+=String.fromCharCode(255&d),d>>>=8;return b}function a(d,g,m,b,k,y){var w,S,D=d.file,A=d.compression,C=y!==c.utf8encode,L=r.transformTo("string",y(D.name)),O=r.transformTo("string",c.utf8encode(D.name)),N=D.comment,V=r.transformTo("string",y(N)),_=r.transformTo("string",c.utf8encode(N)),j=O.length!==D.name.length,x=_.length!==N.length,K="",R="",$="",T=D.dir,P=D.date,ne={crc32:0,compressedSize:0,uncompressedSize:0};g&&!m||(ne.crc32=d.crc32,ne.compressedSize=d.compressedSize,ne.uncompressedSize=d.uncompressedSize);var Y=0;g&&(Y|=8),C||!j&&!x||(Y|=2048);var q=0,le=0;T&&(q|=16),k==="UNIX"?(le=798,q|=(function(oe,_e){var Ie=oe;return oe||(Ie=_e?16893:33204),(65535&Ie)<<16})(D.unixPermissions,T)):(le=20,q|=(function(oe){return 63&(oe||0)})(D.dosPermissions)),w=P.getUTCHours(),w<<=6,w|=P.getUTCMinutes(),w<<=5,w|=P.getUTCSeconds()/2,S=P.getUTCFullYear()-1980,S<<=4,S|=P.getUTCMonth()+1,S<<=5,S|=P.getUTCDate(),j&&(R=o(1,1)+o(u(L),4)+O,K+="up"+o(R.length,2)+R),x&&($=o(1,1)+o(u(V),4)+_,K+="uc"+o($.length,2)+$);var se="";return se+=`
\0`,se+=o(Y,2),se+=A.magic,se+=o(w,2),se+=o(S,2),se+=o(ne.crc32,4),se+=o(ne.compressedSize,4),se+=o(ne.uncompressedSize,4),se+=o(L.length,2),se+=o(K.length,2),{fileRecord:f.LOCAL_FILE_HEADER+se+L+K,dirRecord:f.CENTRAL_FILE_HEADER+o(le,2)+se+o(V.length,2)+"\0\0\0\0"+o(q,4)+o(b,4)+L+K+V}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),f=i("../signature");function h(d,g,m,b){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=g,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,l),h.prototype.push=function(d){var g=d.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,l.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(g+100*(m-b-1))/m:100}}))},h.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var g=this.streamFiles&&!d.file.dir;if(g){var m=a(d,g,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(d){this.accumulate=!1;var g=this.streamFiles&&!d.file.dir,m=a(d,g,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),g)this.push({data:(function(b){return f.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var d=this.bytesWritten,g=0;g<this.dirRecords.length;g++)this.push({data:this.dirRecords[g],meta:{percent:100}});var m=this.bytesWritten-d,b=(function(k,y,w,S,D){var A=r.transformTo("string",D(S));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(k,2)+o(k,2)+o(y,4)+o(w,4)+o(A.length,2)+A})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(d){this._sources.push(d);var g=this;return d.on("data",function(m){g.processChunk(m)}),d.on("end",function(){g.closedSource(g.previous.streamInfo),g._sources.length?g.prepareNextSource():g.end()}),d.on("error",function(m){g.error(m)}),this},h.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(d){var g=this._sources;if(!l.prototype.error.call(this,d))return!1;for(var m=0;m<g.length;m++)try{g[m].error(d)}catch{}return!0},h.prototype.lock=function(){l.prototype.lock.call(this);for(var d=this._sources,g=0;g<d.length;g++)d[g].lock()},s.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,s,n){var o=i("../compressions"),a=i("./ZipFileWorker");n.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),f=0;try{r.forEach(function(h,d){f++;var g=(function(y,w){var S=y||w,D=o[S];if(!D)throw new Error(S+" is not a valid compression method !");return D})(d.options.compression,l.compression),m=d.options.compressionOptions||l.compressionOptions||{},b=d.dir,k=d.date;d._compressWorker(g,m).withStreamInfo("file",{name:h,dir:b,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(h){u.error(h)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,s,n){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),s.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,s,n){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function f(h){return new a.Promise(function(d,g){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){g(b)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?g(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}s.exports=function(h,d){var g=this;return d=o.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(h)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,d.optimizedBinaryString,d.base64).then(function(m){var b=new l(d);return b.load(m),b}).then(function(m){var b=[a.Promise.resolve(m)],k=m.files;if(d.checkCRC32)for(var y=0;y<k.length;y++)b.push(f(k[y]));return a.Promise.all(b)}).then(function(m){for(var b=m.shift(),k=b.files,y=0;y<k.length;y++){var w=k[y],S=w.fileNameStr,D=o.resolve(w.fileNameStr);g.file(D,w.decompressed,{binary:!0,optimizedBinaryString:!0,date:w.date,dir:w.dir,comment:w.fileCommentStr.length?w.fileCommentStr:null,unixPermissions:w.unixPermissions,dosPermissions:w.dosPermissions,createFolders:d.createFolders}),w.dir||(g.file(D).unsafeOriginalName=S)}return b.zipComment.length&&(g.comment=b.zipComment),g})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,s,n){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,s,n){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(f,h){u.push(f)||u._helper.pause(),c&&c(h)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},s.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,s,n){function o(D,A,C){var L,O=r.getTypeOf(A),N=r.extend(C||{},u);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(D=k(D)),N.createFolders&&(L=b(D))&&y.call(this,L,!0);var V=O==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!V),(A instanceof f&&A.uncompressedSize===0||N.dir||!A||A.length===0)&&(N.base64=!1,N.binary=!0,A="",N.compression="STORE",O="string");var _=null;_=A instanceof f||A instanceof l?A:g.isNode&&g.isStream(A)?new m(D,A):r.prepareContent(D,A,N.binary,N.optimizedBinaryString,N.base64);var j=new h(D,_,N);this.files[D]=j}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),f=i("./compressedObject"),h=i("./zipObject"),d=i("./generate"),g=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function(D){D.slice(-1)==="/"&&(D=D.substring(0,D.length-1));var A=D.lastIndexOf("/");return 0<A?D.substring(0,A):""},k=function(D){return D.slice(-1)!=="/"&&(D+="/"),D},y=function(D,A){return A=A!==void 0?A:u.createFolders,D=k(D),this.files[D]||o.call(this,D,null,{dir:!0,createFolders:A}),this.files[D]};function w(D){return Object.prototype.toString.call(D)==="[object RegExp]"}var S={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(D){var A,C,L;for(A in this.files)L=this.files[A],(C=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&D(C,L)},filter:function(D){var A=[];return this.forEach(function(C,L){D(C,L)&&A.push(L)}),A},file:function(D,A,C){if(arguments.length!==1)return D=this.root+D,o.call(this,D,A,C),this;if(w(D)){var L=D;return this.filter(function(N,V){return!V.dir&&L.test(N)})}var O=this.files[this.root+D];return O&&!O.dir?O:null},folder:function(D){if(!D)return this;if(w(D))return this.filter(function(O,N){return N.dir&&D.test(O)});var A=this.root+D,C=y.call(this,A),L=this.clone();return L.root=C.name,L},remove:function(D){D=this.root+D;var A=this.files[D];if(A||(D.slice(-1)!=="/"&&(D+="/"),A=this.files[D]),A&&!A.dir)delete this.files[D];else for(var C=this.filter(function(O,N){return N.name.slice(0,D.length)===D}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(D){var A,C={};try{if((C=r.extend(D||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";A=d.generateWorker(this,C,L)}catch(O){(A=new l("error")).error(O)}return new c(A,C.type||"string",C.mimeType)},generateAsync:function(D,A){return this.generateInternalStream(D).accumulate(A)},generateNodeStream:function(D,A){return(D=D||{}).type||(D.type="nodebuffer"),this.generateInternalStream(D).toNodejsStream(A)}};s.exports=S},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,s,n){s.exports=i("stream")},{stream:void 0}],17:[function(i,s,n){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===l&&this.data[h+1]===c&&this.data[h+2]===u&&this.data[h+3]===f)return h-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),h=this.readData(4);return l===h[0]&&c===h[1]&&u===h[2]&&f===h[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,s,n){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},s.exports=a},{"../utils":32}],19:[function(i,s,n){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,s,n){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,s,n){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},s.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,s,n){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");s.exports=function(f){var h=o.getTypeOf(f);return o.checkSupport(h),h!=="string"||a.uint8array?h==="nodebuffer"?new c(f):a.uint8array?new u(o.transformTo("uint8array",f)):new r(o.transformTo("array",f)):new l(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,s,n){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},s.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,s,n){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},s.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,s,n){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},s.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,s,n){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,s,n){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},s.exports=o},{}],29:[function(i,s,n){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(g,m){return new u.Promise(function(b,k){var y=[],w=g._internalType,S=g._outputType,D=g._mimeType;g.on("data",function(A,C){y.push(A),m&&m(C)}).on("error",function(A){y=[],k(A)}).on("end",function(){try{var A=(function(C,L,O){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",L),O);case"base64":return l.encode(L);default:return o.transformTo(C,L)}})(S,(function(C,L){var O,N=0,V=null,_=0;for(O=0;O<L.length;O++)_+=L[O].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(V=new Uint8Array(_),O=0;O<L.length;O++)V.set(L[O],N),N+=L[O].length;return V;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(w,y),D);b(A)}catch(C){k(C)}y=[]}).resume()})}function d(g,m,b){var k=m;switch(m){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=m,this._mimeType=b,o.checkSupport(k),this._worker=g.pipe(new a(k)),g.lock()}catch(y){this._worker=new r("error"),this._worker.error(y)}}d.prototype={accumulate:function(g){return h(this,g)},on:function(g,m){var b=this;return g==="data"?this._worker.on(g,function(k){m.call(b,k.data,k.meta)}):this._worker.on(g,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(g){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},g)}},s.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var o=new ArrayBuffer(0);try{n.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),n.blob=a.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!i("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(i,s,n){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){l.call(this,"utf-8 decode"),this.leftOver=null}function h(){l.call(this,"utf-8 encode")}n.utf8encode=function(d){return a.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(g){var m,b,k,y,w,S=g.length,D=0;for(y=0;y<S;y++)(64512&(b=g.charCodeAt(y)))==55296&&y+1<S&&(64512&(k=g.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),y++),D+=b<128?1:b<2048?2:b<65536?3:4;for(m=a.uint8array?new Uint8Array(D):new Array(D),y=w=0;w<D;y++)(64512&(b=g.charCodeAt(y)))==55296&&y+1<S&&(64512&(k=g.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),y++),b<128?m[w++]=b:(b<2048?m[w++]=192|b>>>6:(b<65536?m[w++]=224|b>>>12:(m[w++]=240|b>>>18,m[w++]=128|b>>>12&63),m[w++]=128|b>>>6&63),m[w++]=128|63&b);return m})(d)},n.utf8decode=function(d){return a.nodebuffer?o.transformTo("nodebuffer",d).toString("utf-8"):(function(g){var m,b,k,y,w=g.length,S=new Array(2*w);for(m=b=0;m<w;)if((k=g[m++])<128)S[b++]=k;else if(4<(y=c[k]))S[b++]=65533,m+=y-1;else{for(k&=y===2?31:y===3?15:7;1<y&&m<w;)k=k<<6|63&g[m++],y--;1<y?S[b++]=65533:k<65536?S[b++]=k:(k-=65536,S[b++]=55296|k>>10&1023,S[b++]=56320|1023&k)}return S.length!==b&&(S.subarray?S=S.subarray(0,b):S.length=b),o.applyFromCharCode(S)})(d=o.transformTo(a.uint8array?"uint8array":"array",d))},o.inherits(f,l),f.prototype.processChunk=function(d){var g=o.transformTo(a.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=g;(g=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),g.set(m,this.leftOver.length)}else g=this.leftOver.concat(g);this.leftOver=null}var b=(function(y,w){var S;for((w=w||y.length)>y.length&&(w=y.length),S=w-1;0<=S&&(192&y[S])==128;)S--;return S<0||S===0?w:S+c[y[S]]>w?S:w})(g),k=g;b!==g.length&&(a.uint8array?(k=g.subarray(0,b),this.leftOver=g.subarray(b,g.length)):(k=g.slice(0,b),this.leftOver=g.slice(b,g.length))),this.push({data:n.utf8decode(k),meta:d.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,o.inherits(h,l),h.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,s,n){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,b){for(var k=0;k<m.length;++k)b[k]=255&m.charCodeAt(k);return b}i("setimmediate"),n.newBlob=function(m,b){n.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(m),k.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,b,k){var y=[],w=0,S=m.length;if(S<=k)return String.fromCharCode.apply(null,m);for(;w<S;)b==="array"||b==="nodebuffer"?y.push(String.fromCharCode.apply(null,m.slice(w,Math.min(w+k,S)))):y.push(String.fromCharCode.apply(null,m.subarray(w,Math.min(w+k,S)))),w+=k;return y.join("")},stringifyByChar:function(m){for(var b="",k=0;k<m.length;k++)b+=String.fromCharCode(m[k]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var b=65536,k=n.getTypeOf(m),y=!0;if(k==="uint8array"?y=f.applyCanBeUsed.uint8array:k==="nodebuffer"&&(y=f.applyCanBeUsed.nodebuffer),y)for(;1<b;)try{return f.stringifyByChunk(m,k,b)}catch{b=Math.floor(b/2)}return f.stringifyByChar(m)}function d(m,b){for(var k=0;k<m.length;k++)b[k]=m[k];return b}n.applyFromCharCode=h;var g={};g.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return g.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},g.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},g.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},g.uint8array={string:h,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},g.nodebuffer={string:h,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return g.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,b){if(b=b||"",!m)return b;n.checkSupport(m);var k=n.getTypeOf(b);return g[k][m](b)},n.resolve=function(m){for(var b=m.split("/"),k=[],y=0;y<b.length;y++){var w=b[y];w==="."||w===""&&y!==0&&y!==b.length-1||(w===".."?k.pop():k.push(w))}return k.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var b,k,y="";for(k=0;k<(m||"").length;k++)y+="\\x"+((b=m.charCodeAt(k))<16?"0":"")+b.toString(16).toUpperCase();return y},n.delay=function(m,b,k){setImmediate(function(){m.apply(k||null,b||[])})},n.inherits=function(m,b){function k(){}k.prototype=b.prototype,m.prototype=new k},n.extend=function(){var m,b,k={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&k[b]===void 0&&(k[b]=arguments[m][b]);return k},n.prepareContent=function(m,b,k,y,w){return l.Promise.resolve(b).then(function(S){return o.blob&&(S instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(S))!==-1)&&typeof FileReader<"u"?new l.Promise(function(D,A){var C=new FileReader;C.onload=function(L){D(L.target.result)},C.onerror=function(L){A(L.target.error)},C.readAsArrayBuffer(S)}):S}).then(function(S){var D=n.getTypeOf(S);return D?(D==="arraybuffer"?S=n.transformTo("uint8array",S):D==="string"&&(w?S=a.decode(S):k&&y!==!0&&(S=(function(A){return u(A,o.uint8array?new Uint8Array(A.length):new Array(A.length))})(S))),S):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,s,n){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(h)+", expected "+a.pretty(f)+")")}},isSignature:function(f,h){var d=this.reader.index;this.reader.setIndex(f);var g=this.reader.readString(4)===h;return this.reader.setIndex(d),g},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",d=a.transformTo(h,f);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,h,d,g=this.zip64EndOfCentralSize-44;0<g;)f=this.reader.readInt(2),h=this.reader.readInt(4),d=this.reader.readData(h),this.zip64ExtensibleData[f]={id:f,length:h,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,h;for(f=0;f<this.files.length;f++)h=this.files[f],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var h=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var g=h-d;if(0<g)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=g);else if(g<0)throw new Error("Corrupted zip: missing "+Math.abs(g)+" bytes.")},prepareReader:function(f){this.reader=o(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,s,n){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),f=i("./support");function h(d,g){this.options=d,this.loadOptions=g}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var g,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((g=(function(b){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===b)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,g,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var g=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(g),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var g,m,b,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)g=d.readInt(2),m=d.readInt(2),b=d.readData(m),this.extraFields[g]={id:g,length:m,value:b};d.setIndex(k)},handleUTF8:function(){var d=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var g=this.findExtraFieldUnicodePath();if(g!==null)this.fileNameStr=g;else{var m=a.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var k=a.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var g=o(d.value);return g.readInt(1)!==1||l(this.fileName)!==g.readInt(4)?null:c.utf8decode(g.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var g=o(d.value);return g.readInt(1)!==1||l(this.fileComment)!==g.readInt(4)?null:c.utf8decode(g.readData(d.length-5))}return null}},s.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,s,n){function o(g,m,b){this.name=g,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(g){var m=null,b="string";try{if(!g)throw new Error("No output type specified.");var k=(b=g.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var y=!this._dataBinary;y&&!k&&(m=m.pipe(new l.Utf8EncodeWorker)),!y&&k&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(w){(m=new u("error")).error(w)}return new a(m,b,"")},async:function(g,m){return this.internalStream(g).accumulate(m)},nodeStream:function(g,m){return this.internalStream(g||"nodebuffer").toNodejsStream(m)},_compressWorker:function(g,m){if(this._data instanceof c&&this._data.compression.magic===g.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(b,g,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<f.length;d++)o.prototype[f[d]]=h;s.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,s,n){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(g),f=o.document.createTextNode("");u.observe(f,{characterData:!0}),a=function(){f.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){g(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(g,0)};else{var h=new o.MessageChannel;h.port1.onmessage=g,a=function(){h.port2.postMessage(0)}}var d=[];function g(){var m,b;r=!0;for(var k=d.length;k;){for(b=d,d=[],m=-1;++m<k;)b[m]();k=d.length}r=!1}s.exports=function(m){d.push(m)!==1||r||a()}}).call(this,typeof fn<"u"?fn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,s,n){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==a&&m(this,k)}function h(k,y,w){this.promise=k,typeof y=="function"&&(this.onFulfilled=y,this.callFulfilled=this.otherCallFulfilled),typeof w=="function"&&(this.onRejected=w,this.callRejected=this.otherCallRejected)}function d(k,y,w){o(function(){var S;try{S=y(w)}catch(D){return r.reject(k,D)}S===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,S)})}function g(k){var y=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof y=="function")return function(){y.apply(k,arguments)}}function m(k,y){var w=!1;function S(C){w||(w=!0,r.reject(k,C))}function D(C){w||(w=!0,r.resolve(k,C))}var A=b(function(){y(D,S)});A.status==="error"&&S(A.value)}function b(k,y){var w={};try{w.value=k(y),w.status="success"}catch(S){w.status="error",w.value=S}return w}(s.exports=f).prototype.finally=function(k){if(typeof k!="function")return this;var y=this.constructor;return this.then(function(w){return y.resolve(k()).then(function(){return w})},function(w){return y.resolve(k()).then(function(){throw w})})},f.prototype.catch=function(k){return this.then(null,k)},f.prototype.then=function(k,y){if(typeof k!="function"&&this.state===c||typeof y!="function"&&this.state===l)return this;var w=new this.constructor(a);return this.state!==u?d(w,this.state===c?k:y,this.outcome):this.queue.push(new h(w,k,y)),w},h.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},h.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},h.prototype.callRejected=function(k){r.reject(this.promise,k)},h.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,y){var w=b(g,y);if(w.status==="error")return r.reject(k,w.value);var S=w.value;if(S)m(k,S);else{k.state=c,k.outcome=y;for(var D=-1,A=k.queue.length;++D<A;)k.queue[D].callFulfilled(y)}return k},r.reject=function(k,y){k.state=l,k.outcome=y;for(var w=-1,S=k.queue.length;++w<S;)k.queue[w].callRejected(y);return k},f.resolve=function(k){return k instanceof this?k:r.resolve(new this(a),k)},f.reject=function(k){var y=new this(a);return r.reject(y,k)},f.all=function(k){var y=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=k.length,S=!1;if(!w)return this.resolve([]);for(var D=new Array(w),A=0,C=-1,L=new this(a);++C<w;)O(k[C],C);return L;function O(N,V){y.resolve(N).then(function(_){D[V]=_,++A!==w||S||(S=!0,r.resolve(L,D))},function(_){S||(S=!0,r.reject(L,_))})}},f.race=function(k){var y=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=k.length,S=!1;if(!w)return this.resolve([]);for(var D=-1,A=new this(a);++D<w;)C=k[D],y.resolve(C).then(function(L){S||(S=!0,r.resolve(A,L))},function(L){S||(S=!0,r.reject(A,L))});var C;return A}},{immediate:36}],38:[function(i,s,n){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),s.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,s,n){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,f=0,h=-1,d=0,g=8;function m(k){if(!(this instanceof m))return new m(k);this.options=a.assign({level:h,method:g,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var y=this.options;y.raw&&0<y.windowBits?y.windowBits=-y.windowBits:y.gzip&&0<y.windowBits&&y.windowBits<16&&(y.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var w=o.deflateInit2(this.strm,y.level,y.method,y.windowBits,y.memLevel,y.strategy);if(w!==f)throw new Error(l[w]);if(y.header&&o.deflateSetHeader(this.strm,y.header),y.dictionary){var S;if(S=typeof y.dictionary=="string"?r.string2buf(y.dictionary):u.call(y.dictionary)==="[object ArrayBuffer]"?new Uint8Array(y.dictionary):y.dictionary,(w=o.deflateSetDictionary(this.strm,S))!==f)throw new Error(l[w]);this._dict_set=!0}}function b(k,y){var w=new m(y);if(w.push(k,!0),w.err)throw w.msg||l[w.err];return w.result}m.prototype.push=function(k,y){var w,S,D=this.strm,A=this.options.chunkSize;if(this.ended)return!1;S=y===~~y?y:y===!0?4:0,typeof k=="string"?D.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?D.input=new Uint8Array(k):D.input=k,D.next_in=0,D.avail_in=D.input.length;do{if(D.avail_out===0&&(D.output=new a.Buf8(A),D.next_out=0,D.avail_out=A),(w=o.deflate(D,S))!==1&&w!==f)return this.onEnd(w),!(this.ended=!0);D.avail_out!==0&&(D.avail_in!==0||S!==4&&S!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(D.output,D.next_out))):this.onData(a.shrinkBuf(D.output,D.next_out)))}while((0<D.avail_in||D.avail_out===0)&&w!==1);return S===4?(w=o.deflateEnd(this.strm),this.onEnd(w),this.ended=!0,w===f):S!==2||(this.onEnd(f),!(D.avail_out=0))},m.prototype.onData=function(k){this.chunks.push(k)},m.prototype.onEnd=function(k){k===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},n.Deflate=m,n.deflate=b,n.deflateRaw=function(k,y){return(y=y||{}).raw=!0,b(k,y)},n.gzip=function(k,y){return(y=y||{}).gzip=!0,b(k,y)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,s,n){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),f=i("./zlib/gzheader"),h=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=o.inflateInit2(this.strm,b.windowBits);if(k!==l.Z_OK)throw new Error(c[k]);this.header=new f,o.inflateGetHeader(this.strm,this.header)}function g(m,b){var k=new d(b);if(k.push(m,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(m,b){var k,y,w,S,D,A,C=this.strm,L=this.options.chunkSize,O=this.options.dictionary,N=!1;if(this.ended)return!1;y=b===~~b?b:b===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(L),C.next_out=0,C.avail_out=L),(k=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&O&&(A=typeof O=="string"?r.string2buf(O):h.call(O)==="[object ArrayBuffer]"?new Uint8Array(O):O,k=o.inflateSetDictionary(this.strm,A)),k===l.Z_BUF_ERROR&&N===!0&&(k=l.Z_OK,N=!1),k!==l.Z_STREAM_END&&k!==l.Z_OK)return this.onEnd(k),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&k!==l.Z_STREAM_END&&(C.avail_in!==0||y!==l.Z_FINISH&&y!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(w=r.utf8border(C.output,C.next_out),S=C.next_out-w,D=r.buf2string(C.output,w),C.next_out=S,C.avail_out=L-S,S&&a.arraySet(C.output,C.output,w,S,0),this.onData(D)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&k!==l.Z_STREAM_END);return k===l.Z_STREAM_END&&(y=l.Z_FINISH),y===l.Z_FINISH?(k=o.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===l.Z_OK):y!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=d,n.inflate=g,n.inflateRaw=function(m,b){return(b=b||{}).raw=!0,g(m,b)},n.ungzip=g},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,s,n){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(l[f]=u[f])}}return l},n.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,f,h){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+f),h);else for(var d=0;d<f;d++)l[h+d]=c[u+d]},flattenChunks:function(l){var c,u,f,h,d,g;for(c=f=0,u=l.length;c<u;c++)f+=l[c].length;for(g=new Uint8Array(f),c=h=0,u=l.length;c<u;c++)d=l[c],g.set(d,h),h+=d.length;return g}},r={arraySet:function(l,c,u,f,h){for(var d=0;d<f;d++)l[h+d]=c[u+d]},flattenChunks:function(l){return[].concat.apply([],l)}};n.setTyped=function(l){l?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,a)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(o)},{}],42:[function(i,s,n){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,h){if(h<65537&&(f.subarray&&r||!f.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(f,h));for(var d="",g=0;g<h;g++)d+=String.fromCharCode(f[g]);return d}l[254]=l[254]=1,n.string2buf=function(f){var h,d,g,m,b,k=f.length,y=0;for(m=0;m<k;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<k&&(64512&(g=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(g-56320),m++),y+=d<128?1:d<2048?2:d<65536?3:4;for(h=new o.Buf8(y),m=b=0;b<y;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<k&&(64512&(g=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(g-56320),m++),d<128?h[b++]=d:(d<2048?h[b++]=192|d>>>6:(d<65536?h[b++]=224|d>>>12:(h[b++]=240|d>>>18,h[b++]=128|d>>>12&63),h[b++]=128|d>>>6&63),h[b++]=128|63&d);return h},n.buf2binstring=function(f){return u(f,f.length)},n.binstring2buf=function(f){for(var h=new o.Buf8(f.length),d=0,g=h.length;d<g;d++)h[d]=f.charCodeAt(d);return h},n.buf2string=function(f,h){var d,g,m,b,k=h||f.length,y=new Array(2*k);for(d=g=0;d<k;)if((m=f[d++])<128)y[g++]=m;else if(4<(b=l[m]))y[g++]=65533,d+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&d<k;)m=m<<6|63&f[d++],b--;1<b?y[g++]=65533:m<65536?y[g++]=m:(m-=65536,y[g++]=55296|m>>10&1023,y[g++]=56320|1023&m)}return u(y,g)},n.utf8border=function(f,h){var d;for((h=h||f.length)>f.length&&(h=f.length),d=h-1;0<=d&&(192&f[d])==128;)d--;return d<0||d===0?h:d+l[f[d]]>h?d:h}},{"./common":41}],43:[function(i,s,n){s.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,s,n){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();s.exports=function(a,r,l,c){var u=o,f=c+l;a^=-1;for(var h=c;h<f;h++)a=a>>>8^u[255&(a^r[h])];return-1^a}},{}],46:[function(i,s,n){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),f=0,h=4,d=0,g=-2,m=-1,b=4,k=2,y=8,w=9,S=286,D=30,A=19,C=2*S+1,L=15,O=3,N=258,V=N+O+1,_=42,j=113,x=1,K=2,R=3,$=4;function T(v,W){return v.msg=u[W],W}function P(v){return(v<<1)-(4<v?9:0)}function ne(v){for(var W=v.length;0<=--W;)v[W]=0}function Y(v){var W=v.state,F=W.pending;F>v.avail_out&&(F=v.avail_out),F!==0&&(a.arraySet(v.output,W.pending_buf,W.pending_out,F,v.next_out),v.next_out+=F,W.pending_out+=F,v.total_out+=F,v.avail_out-=F,W.pending-=F,W.pending===0&&(W.pending_out=0))}function q(v,W){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,W),v.block_start=v.strstart,Y(v.strm)}function le(v,W){v.pending_buf[v.pending++]=W}function se(v,W){v.pending_buf[v.pending++]=W>>>8&255,v.pending_buf[v.pending++]=255&W}function oe(v,W){var F,M,I=v.max_chain_length,z=v.strstart,G=v.prev_length,Z=v.nice_match,B=v.strstart>v.w_size-V?v.strstart-(v.w_size-V):0,U=v.window,ie=v.w_mask,te=v.prev,me=v.strstart+N,Se=U[z+G-1],Ce=U[z+G];v.prev_length>=v.good_match&&(I>>=2),Z>v.lookahead&&(Z=v.lookahead);do if(U[(F=W)+G]===Ce&&U[F+G-1]===Se&&U[F]===U[z]&&U[++F]===U[z+1]){z+=2,F++;do;while(U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&U[++z]===U[++F]&&z<me);if(M=N-(me-z),z=me-N,G<M){if(v.match_start=W,Z<=(G=M))break;Se=U[z+G-1],Ce=U[z+G]}}while((W=te[W&ie])>B&&--I!=0);return G<=v.lookahead?G:v.lookahead}function _e(v){var W,F,M,I,z,G,Z,B,U,ie,te=v.w_size;do{if(I=v.window_size-v.lookahead-v.strstart,v.strstart>=te+(te-V)){for(a.arraySet(v.window,v.window,te,te,0),v.match_start-=te,v.strstart-=te,v.block_start-=te,W=F=v.hash_size;M=v.head[--W],v.head[W]=te<=M?M-te:0,--F;);for(W=F=te;M=v.prev[--W],v.prev[W]=te<=M?M-te:0,--F;);I+=te}if(v.strm.avail_in===0)break;if(G=v.strm,Z=v.window,B=v.strstart+v.lookahead,U=I,ie=void 0,ie=G.avail_in,U<ie&&(ie=U),F=ie===0?0:(G.avail_in-=ie,a.arraySet(Z,G.input,G.next_in,ie,B),G.state.wrap===1?G.adler=l(G.adler,Z,ie,B):G.state.wrap===2&&(G.adler=c(G.adler,Z,ie,B)),G.next_in+=ie,G.total_in+=ie,ie),v.lookahead+=F,v.lookahead+v.insert>=O)for(z=v.strstart-v.insert,v.ins_h=v.window[z],v.ins_h=(v.ins_h<<v.hash_shift^v.window[z+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[z+O-1])&v.hash_mask,v.prev[z&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=z,z++,v.insert--,!(v.lookahead+v.insert<O)););}while(v.lookahead<V&&v.strm.avail_in!==0)}function Ie(v,W){for(var F,M;;){if(v.lookahead<V){if(_e(v),v.lookahead<V&&W===f)return x;if(v.lookahead===0)break}if(F=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,F=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),F!==0&&v.strstart-F<=v.w_size-V&&(v.match_length=oe(v,F)),v.match_length>=O)if(M=r._tr_tally(v,v.strstart-v.match_start,v.match_length-O),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=O){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,F=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else M=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(M&&(q(v,!1),v.strm.avail_out===0))return x}return v.insert=v.strstart<O-1?v.strstart:O-1,W===h?(q(v,!0),v.strm.avail_out===0?R:$):v.last_lit&&(q(v,!1),v.strm.avail_out===0)?x:K}function xe(v,W){for(var F,M,I;;){if(v.lookahead<V){if(_e(v),v.lookahead<V&&W===f)return x;if(v.lookahead===0)break}if(F=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,F=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=O-1,F!==0&&v.prev_length<v.max_lazy_match&&v.strstart-F<=v.w_size-V&&(v.match_length=oe(v,F),v.match_length<=5&&(v.strategy===1||v.match_length===O&&4096<v.strstart-v.match_start)&&(v.match_length=O-1)),v.prev_length>=O&&v.match_length<=v.prev_length){for(I=v.strstart+v.lookahead-O,M=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-O),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=I&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,F=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=O-1,v.strstart++,M&&(q(v,!1),v.strm.avail_out===0))return x}else if(v.match_available){if((M=r._tr_tally(v,0,v.window[v.strstart-1]))&&q(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return x}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(M=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<O-1?v.strstart:O-1,W===h?(q(v,!0),v.strm.avail_out===0?R:$):v.last_lit&&(q(v,!1),v.strm.avail_out===0)?x:K}function fe(v,W,F,M,I){this.good_length=v,this.max_lazy=W,this.nice_length=F,this.max_chain=M,this.func=I}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=y,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*D+1)),this.bl_tree=new a.Buf16(2*(2*A+1)),ne(this.dyn_ltree),ne(this.dyn_dtree),ne(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(L+1),this.heap=new a.Buf16(2*S+1),ne(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*S+1),ne(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ue(v){var W;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=k,(W=v.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?_:j,v.adler=W.wrap===2?0:1,W.last_flush=f,r._tr_init(W),d):T(v,g)}function E(v){var W=ue(v);return W===d&&(function(F){F.window_size=2*F.w_size,ne(F.head),F.max_lazy_match=o[F.level].max_lazy,F.good_match=o[F.level].good_length,F.nice_match=o[F.level].nice_length,F.max_chain_length=o[F.level].max_chain,F.strstart=0,F.block_start=0,F.lookahead=0,F.insert=0,F.match_length=F.prev_length=O-1,F.match_available=0,F.ins_h=0})(v.state),W}function H(v,W,F,M,I,z){if(!v)return g;var G=1;if(W===m&&(W=6),M<0?(G=0,M=-M):15<M&&(G=2,M-=16),I<1||w<I||F!==y||M<8||15<M||W<0||9<W||z<0||b<z)return T(v,g);M===8&&(M=9);var Z=new X;return(v.state=Z).strm=v,Z.wrap=G,Z.gzhead=null,Z.w_bits=M,Z.w_size=1<<Z.w_bits,Z.w_mask=Z.w_size-1,Z.hash_bits=I+7,Z.hash_size=1<<Z.hash_bits,Z.hash_mask=Z.hash_size-1,Z.hash_shift=~~((Z.hash_bits+O-1)/O),Z.window=new a.Buf8(2*Z.w_size),Z.head=new a.Buf16(Z.hash_size),Z.prev=new a.Buf16(Z.w_size),Z.lit_bufsize=1<<I+6,Z.pending_buf_size=4*Z.lit_bufsize,Z.pending_buf=new a.Buf8(Z.pending_buf_size),Z.d_buf=1*Z.lit_bufsize,Z.l_buf=3*Z.lit_bufsize,Z.level=W,Z.strategy=z,Z.method=F,E(v)}o=[new fe(0,0,0,0,function(v,W){var F=65535;for(F>v.pending_buf_size-5&&(F=v.pending_buf_size-5);;){if(v.lookahead<=1){if(_e(v),v.lookahead===0&&W===f)return x;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var M=v.block_start+F;if((v.strstart===0||v.strstart>=M)&&(v.lookahead=v.strstart-M,v.strstart=M,q(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-V&&(q(v,!1),v.strm.avail_out===0))return x}return v.insert=0,W===h?(q(v,!0),v.strm.avail_out===0?R:$):(v.strstart>v.block_start&&(q(v,!1),v.strm.avail_out),x)}),new fe(4,4,8,4,Ie),new fe(4,5,16,8,Ie),new fe(4,6,32,32,Ie),new fe(4,4,16,16,xe),new fe(8,16,32,32,xe),new fe(8,16,128,128,xe),new fe(8,32,128,256,xe),new fe(32,128,258,1024,xe),new fe(32,258,258,4096,xe)],n.deflateInit=function(v,W){return H(v,W,y,15,8,0)},n.deflateInit2=H,n.deflateReset=E,n.deflateResetKeep=ue,n.deflateSetHeader=function(v,W){return v&&v.state?v.state.wrap!==2?g:(v.state.gzhead=W,d):g},n.deflate=function(v,W){var F,M,I,z;if(!v||!v.state||5<W||W<0)return v?T(v,g):g;if(M=v.state,!v.output||!v.input&&v.avail_in!==0||M.status===666&&W!==h)return T(v,v.avail_out===0?-5:g);if(M.strm=v,F=M.last_flush,M.last_flush=W,M.status===_)if(M.wrap===2)v.adler=0,le(M,31),le(M,139),le(M,8),M.gzhead?(le(M,(M.gzhead.text?1:0)+(M.gzhead.hcrc?2:0)+(M.gzhead.extra?4:0)+(M.gzhead.name?8:0)+(M.gzhead.comment?16:0)),le(M,255&M.gzhead.time),le(M,M.gzhead.time>>8&255),le(M,M.gzhead.time>>16&255),le(M,M.gzhead.time>>24&255),le(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),le(M,255&M.gzhead.os),M.gzhead.extra&&M.gzhead.extra.length&&(le(M,255&M.gzhead.extra.length),le(M,M.gzhead.extra.length>>8&255)),M.gzhead.hcrc&&(v.adler=c(v.adler,M.pending_buf,M.pending,0)),M.gzindex=0,M.status=69):(le(M,0),le(M,0),le(M,0),le(M,0),le(M,0),le(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),le(M,3),M.status=j);else{var G=y+(M.w_bits-8<<4)<<8;G|=(2<=M.strategy||M.level<2?0:M.level<6?1:M.level===6?2:3)<<6,M.strstart!==0&&(G|=32),G+=31-G%31,M.status=j,se(M,G),M.strstart!==0&&(se(M,v.adler>>>16),se(M,65535&v.adler)),v.adler=1}if(M.status===69)if(M.gzhead.extra){for(I=M.pending;M.gzindex<(65535&M.gzhead.extra.length)&&(M.pending!==M.pending_buf_size||(M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),Y(v),I=M.pending,M.pending!==M.pending_buf_size));)le(M,255&M.gzhead.extra[M.gzindex]),M.gzindex++;M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),M.gzindex===M.gzhead.extra.length&&(M.gzindex=0,M.status=73)}else M.status=73;if(M.status===73)if(M.gzhead.name){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),Y(v),I=M.pending,M.pending===M.pending_buf_size)){z=1;break}z=M.gzindex<M.gzhead.name.length?255&M.gzhead.name.charCodeAt(M.gzindex++):0,le(M,z)}while(z!==0);M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),z===0&&(M.gzindex=0,M.status=91)}else M.status=91;if(M.status===91)if(M.gzhead.comment){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),Y(v),I=M.pending,M.pending===M.pending_buf_size)){z=1;break}z=M.gzindex<M.gzhead.comment.length?255&M.gzhead.comment.charCodeAt(M.gzindex++):0,le(M,z)}while(z!==0);M.gzhead.hcrc&&M.pending>I&&(v.adler=c(v.adler,M.pending_buf,M.pending-I,I)),z===0&&(M.status=103)}else M.status=103;if(M.status===103&&(M.gzhead.hcrc?(M.pending+2>M.pending_buf_size&&Y(v),M.pending+2<=M.pending_buf_size&&(le(M,255&v.adler),le(M,v.adler>>8&255),v.adler=0,M.status=j)):M.status=j),M.pending!==0){if(Y(v),v.avail_out===0)return M.last_flush=-1,d}else if(v.avail_in===0&&P(W)<=P(F)&&W!==h)return T(v,-5);if(M.status===666&&v.avail_in!==0)return T(v,-5);if(v.avail_in!==0||M.lookahead!==0||W!==f&&M.status!==666){var Z=M.strategy===2?(function(B,U){for(var ie;;){if(B.lookahead===0&&(_e(B),B.lookahead===0)){if(U===f)return x;break}if(B.match_length=0,ie=r._tr_tally(B,0,B.window[B.strstart]),B.lookahead--,B.strstart++,ie&&(q(B,!1),B.strm.avail_out===0))return x}return B.insert=0,U===h?(q(B,!0),B.strm.avail_out===0?R:$):B.last_lit&&(q(B,!1),B.strm.avail_out===0)?x:K})(M,W):M.strategy===3?(function(B,U){for(var ie,te,me,Se,Ce=B.window;;){if(B.lookahead<=N){if(_e(B),B.lookahead<=N&&U===f)return x;if(B.lookahead===0)break}if(B.match_length=0,B.lookahead>=O&&0<B.strstart&&(te=Ce[me=B.strstart-1])===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]){Se=B.strstart+N;do;while(te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&te===Ce[++me]&&me<Se);B.match_length=N-(Se-me),B.match_length>B.lookahead&&(B.match_length=B.lookahead)}if(B.match_length>=O?(ie=r._tr_tally(B,1,B.match_length-O),B.lookahead-=B.match_length,B.strstart+=B.match_length,B.match_length=0):(ie=r._tr_tally(B,0,B.window[B.strstart]),B.lookahead--,B.strstart++),ie&&(q(B,!1),B.strm.avail_out===0))return x}return B.insert=0,U===h?(q(B,!0),B.strm.avail_out===0?R:$):B.last_lit&&(q(B,!1),B.strm.avail_out===0)?x:K})(M,W):o[M.level].func(M,W);if(Z!==R&&Z!==$||(M.status=666),Z===x||Z===R)return v.avail_out===0&&(M.last_flush=-1),d;if(Z===K&&(W===1?r._tr_align(M):W!==5&&(r._tr_stored_block(M,0,0,!1),W===3&&(ne(M.head),M.lookahead===0&&(M.strstart=0,M.block_start=0,M.insert=0))),Y(v),v.avail_out===0))return M.last_flush=-1,d}return W!==h?d:M.wrap<=0?1:(M.wrap===2?(le(M,255&v.adler),le(M,v.adler>>8&255),le(M,v.adler>>16&255),le(M,v.adler>>24&255),le(M,255&v.total_in),le(M,v.total_in>>8&255),le(M,v.total_in>>16&255),le(M,v.total_in>>24&255)):(se(M,v.adler>>>16),se(M,65535&v.adler)),Y(v),0<M.wrap&&(M.wrap=-M.wrap),M.pending!==0?d:1)},n.deflateEnd=function(v){var W;return v&&v.state?(W=v.state.status)!==_&&W!==69&&W!==73&&W!==91&&W!==103&&W!==j&&W!==666?T(v,g):(v.state=null,W===j?T(v,-3):d):g},n.deflateSetDictionary=function(v,W){var F,M,I,z,G,Z,B,U,ie=W.length;if(!v||!v.state||(z=(F=v.state).wrap)===2||z===1&&F.status!==_||F.lookahead)return g;for(z===1&&(v.adler=l(v.adler,W,ie,0)),F.wrap=0,ie>=F.w_size&&(z===0&&(ne(F.head),F.strstart=0,F.block_start=0,F.insert=0),U=new a.Buf8(F.w_size),a.arraySet(U,W,ie-F.w_size,F.w_size,0),W=U,ie=F.w_size),G=v.avail_in,Z=v.next_in,B=v.input,v.avail_in=ie,v.next_in=0,v.input=W,_e(F);F.lookahead>=O;){for(M=F.strstart,I=F.lookahead-(O-1);F.ins_h=(F.ins_h<<F.hash_shift^F.window[M+O-1])&F.hash_mask,F.prev[M&F.w_mask]=F.head[F.ins_h],F.head[F.ins_h]=M,M++,--I;);F.strstart=M,F.lookahead=O-1,_e(F)}return F.strstart+=F.lookahead,F.block_start=F.strstart,F.insert=F.lookahead,F.lookahead=0,F.match_length=F.prev_length=O-1,F.match_available=0,v.next_in=Z,v.input=B,v.avail_in=G,F.wrap=z,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,s,n){s.exports=function(o,a){var r,l,c,u,f,h,d,g,m,b,k,y,w,S,D,A,C,L,O,N,V,_,j,x,K;r=o.state,l=o.next_in,x=o.input,c=l+(o.avail_in-5),u=o.next_out,K=o.output,f=u-(a-o.avail_out),h=u+(o.avail_out-257),d=r.dmax,g=r.wsize,m=r.whave,b=r.wnext,k=r.window,y=r.hold,w=r.bits,S=r.lencode,D=r.distcode,A=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{w<15&&(y+=x[l++]<<w,w+=8,y+=x[l++]<<w,w+=8),L=S[y&A];t:for(;;){if(y>>>=O=L>>>24,w-=O,(O=L>>>16&255)===0)K[u++]=65535&L;else{if(!(16&O)){if((64&O)==0){L=S[(65535&L)+(y&(1<<O)-1)];continue t}if(32&O){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&L,(O&=15)&&(w<O&&(y+=x[l++]<<w,w+=8),N+=y&(1<<O)-1,y>>>=O,w-=O),w<15&&(y+=x[l++]<<w,w+=8,y+=x[l++]<<w,w+=8),L=D[y&C];i:for(;;){if(y>>>=O=L>>>24,w-=O,!(16&(O=L>>>16&255))){if((64&O)==0){L=D[(65535&L)+(y&(1<<O)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(V=65535&L,w<(O&=15)&&(y+=x[l++]<<w,(w+=8)<O&&(y+=x[l++]<<w,w+=8)),d<(V+=y&(1<<O)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(y>>>=O,w-=O,(O=u-f)<V){if(m<(O=V-O)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(j=k,(_=0)===b){if(_+=g-O,O<N){for(N-=O;K[u++]=k[_++],--O;);_=u-V,j=K}}else if(b<O){if(_+=g+b-O,(O-=b)<N){for(N-=O;K[u++]=k[_++],--O;);if(_=0,b<N){for(N-=O=b;K[u++]=k[_++],--O;);_=u-V,j=K}}}else if(_+=b-O,O<N){for(N-=O;K[u++]=k[_++],--O;);_=u-V,j=K}for(;2<N;)K[u++]=j[_++],K[u++]=j[_++],K[u++]=j[_++],N-=3;N&&(K[u++]=j[_++],1<N&&(K[u++]=j[_++]))}else{for(_=u-V;K[u++]=K[_++],K[u++]=K[_++],K[u++]=K[_++],2<(N-=3););N&&(K[u++]=K[_++],1<N&&(K[u++]=K[_++]))}break}}break}}while(l<c&&u<h);l-=N=w>>3,y&=(1<<(w-=N<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<h?h-u+257:257-(u-h),r.hold=y,r.bits=w}},{}],49:[function(i,s,n){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,f=2,h=0,d=-2,g=1,m=852,b=592;function k(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function y(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function w(_){var j;return _&&_.state?(j=_.state,_.total_in=_.total_out=j.total=0,_.msg="",j.wrap&&(_.adler=1&j.wrap),j.mode=g,j.last=0,j.havedict=0,j.dmax=32768,j.head=null,j.hold=0,j.bits=0,j.lencode=j.lendyn=new o.Buf32(m),j.distcode=j.distdyn=new o.Buf32(b),j.sane=1,j.back=-1,h):d}function S(_){var j;return _&&_.state?((j=_.state).wsize=0,j.whave=0,j.wnext=0,w(_)):d}function D(_,j){var x,K;return _&&_.state?(K=_.state,j<0?(x=0,j=-j):(x=1+(j>>4),j<48&&(j&=15)),j&&(j<8||15<j)?d:(K.window!==null&&K.wbits!==j&&(K.window=null),K.wrap=x,K.wbits=j,S(_))):d}function A(_,j){var x,K;return _?(K=new y,(_.state=K).window=null,(x=D(_,j))!==h&&(_.state=null),x):d}var C,L,O=!0;function N(_){if(O){var j;for(C=new o.Buf32(512),L=new o.Buf32(32),j=0;j<144;)_.lens[j++]=8;for(;j<256;)_.lens[j++]=9;for(;j<280;)_.lens[j++]=7;for(;j<288;)_.lens[j++]=8;for(c(u,_.lens,0,288,C,0,_.work,{bits:9}),j=0;j<32;)_.lens[j++]=5;c(f,_.lens,0,32,L,0,_.work,{bits:5}),O=!1}_.lencode=C,_.lenbits=9,_.distcode=L,_.distbits=5}function V(_,j,x,K){var R,$=_.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new o.Buf8($.wsize)),K>=$.wsize?(o.arraySet($.window,j,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(K<(R=$.wsize-$.wnext)&&(R=K),o.arraySet($.window,j,x-K,R,$.wnext),(K-=R)?(o.arraySet($.window,j,x-K,K,0),$.wnext=K,$.whave=$.wsize):($.wnext+=R,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=R))),0}n.inflateReset=S,n.inflateReset2=D,n.inflateResetKeep=w,n.inflateInit=function(_){return A(_,15)},n.inflateInit2=A,n.inflate=function(_,j){var x,K,R,$,T,P,ne,Y,q,le,se,oe,_e,Ie,xe,fe,X,ue,E,H,v,W,F,M,I=0,z=new o.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return d;(x=_.state).mode===12&&(x.mode=13),T=_.next_out,R=_.output,ne=_.avail_out,$=_.next_in,K=_.input,P=_.avail_in,Y=x.hold,q=x.bits,le=P,se=ne,W=h;e:for(;;)switch(x.mode){case g:if(x.wrap===0){x.mode=13;break}for(;q<16;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(2&x.wrap&&Y===35615){z[x.check=0]=255&Y,z[1]=Y>>>8&255,x.check=r(x.check,z,2,0),q=Y=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&Y)<<8)+(Y>>8))%31){_.msg="incorrect header check",x.mode=30;break}if((15&Y)!=8){_.msg="unknown compression method",x.mode=30;break}if(q-=4,v=8+(15&(Y>>>=4)),x.wbits===0)x.wbits=v;else if(v>x.wbits){_.msg="invalid window size",x.mode=30;break}x.dmax=1<<v,_.adler=x.check=1,x.mode=512&Y?10:12,q=Y=0;break;case 2:for(;q<16;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(x.flags=Y,(255&x.flags)!=8){_.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){_.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=Y>>8&1),512&x.flags&&(z[0]=255&Y,z[1]=Y>>>8&255,x.check=r(x.check,z,2,0)),q=Y=0,x.mode=3;case 3:for(;q<32;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.head&&(x.head.time=Y),512&x.flags&&(z[0]=255&Y,z[1]=Y>>>8&255,z[2]=Y>>>16&255,z[3]=Y>>>24&255,x.check=r(x.check,z,4,0)),q=Y=0,x.mode=4;case 4:for(;q<16;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.head&&(x.head.xflags=255&Y,x.head.os=Y>>8),512&x.flags&&(z[0]=255&Y,z[1]=Y>>>8&255,x.check=r(x.check,z,2,0)),q=Y=0,x.mode=5;case 5:if(1024&x.flags){for(;q<16;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.length=Y,x.head&&(x.head.extra_len=Y),512&x.flags&&(z[0]=255&Y,z[1]=Y>>>8&255,x.check=r(x.check,z,2,0)),q=Y=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(P<(oe=x.length)&&(oe=P),oe&&(x.head&&(v=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),o.arraySet(x.head.extra,K,$,oe,v)),512&x.flags&&(x.check=r(x.check,K,oe,$)),P-=oe,$+=oe,x.length-=oe),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(P===0)break e;for(oe=0;v=K[$+oe++],x.head&&v&&x.length<65536&&(x.head.name+=String.fromCharCode(v)),v&&oe<P;);if(512&x.flags&&(x.check=r(x.check,K,oe,$)),P-=oe,$+=oe,v)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(P===0)break e;for(oe=0;v=K[$+oe++],x.head&&v&&x.length<65536&&(x.head.comment+=String.fromCharCode(v)),v&&oe<P;);if(512&x.flags&&(x.check=r(x.check,K,oe,$)),P-=oe,$+=oe,v)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;q<16;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(Y!==(65535&x.check)){_.msg="header crc mismatch",x.mode=30;break}q=Y=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),_.adler=x.check=0,x.mode=12;break;case 10:for(;q<32;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}_.adler=x.check=k(Y),q=Y=0,x.mode=11;case 11:if(x.havedict===0)return _.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=Y,x.bits=q,2;_.adler=x.check=1,x.mode=12;case 12:if(j===5||j===6)break e;case 13:if(x.last){Y>>>=7&q,q-=7&q,x.mode=27;break}for(;q<3;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}switch(x.last=1&Y,q-=1,3&(Y>>>=1)){case 0:x.mode=14;break;case 1:if(N(x),x.mode=20,j!==6)break;Y>>>=2,q-=2;break e;case 2:x.mode=17;break;case 3:_.msg="invalid block type",x.mode=30}Y>>>=2,q-=2;break;case 14:for(Y>>>=7&q,q-=7&q;q<32;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if((65535&Y)!=(Y>>>16^65535)){_.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&Y,q=Y=0,x.mode=15,j===6)break e;case 15:x.mode=16;case 16:if(oe=x.length){if(P<oe&&(oe=P),ne<oe&&(oe=ne),oe===0)break e;o.arraySet(R,K,$,oe,T),P-=oe,$+=oe,ne-=oe,T+=oe,x.length-=oe;break}x.mode=12;break;case 17:for(;q<14;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(x.nlen=257+(31&Y),Y>>>=5,q-=5,x.ndist=1+(31&Y),Y>>>=5,q-=5,x.ncode=4+(15&Y),Y>>>=4,q-=4,286<x.nlen||30<x.ndist){_.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;q<3;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.lens[G[x.have++]]=7&Y,Y>>>=3,q-=3}for(;x.have<19;)x.lens[G[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,F={bits:x.lenbits},W=c(0,x.lens,0,19,x.lencode,0,x.work,F),x.lenbits=F.bits,W){_.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;fe=(I=x.lencode[Y&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((xe=I>>>24)<=q);){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(X<16)Y>>>=xe,q-=xe,x.lens[x.have++]=X;else{if(X===16){for(M=xe+2;q<M;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(Y>>>=xe,q-=xe,x.have===0){_.msg="invalid bit length repeat",x.mode=30;break}v=x.lens[x.have-1],oe=3+(3&Y),Y>>>=2,q-=2}else if(X===17){for(M=xe+3;q<M;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}q-=xe,v=0,oe=3+(7&(Y>>>=xe)),Y>>>=3,q-=3}else{for(M=xe+7;q<M;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}q-=xe,v=0,oe=11+(127&(Y>>>=xe)),Y>>>=7,q-=7}if(x.have+oe>x.nlen+x.ndist){_.msg="invalid bit length repeat",x.mode=30;break}for(;oe--;)x.lens[x.have++]=v}}if(x.mode===30)break;if(x.lens[256]===0){_.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,F={bits:x.lenbits},W=c(u,x.lens,0,x.nlen,x.lencode,0,x.work,F),x.lenbits=F.bits,W){_.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,F={bits:x.distbits},W=c(f,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,F),x.distbits=F.bits,W){_.msg="invalid distances set",x.mode=30;break}if(x.mode=20,j===6)break e;case 20:x.mode=21;case 21:if(6<=P&&258<=ne){_.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=Y,x.bits=q,l(_,se),T=_.next_out,R=_.output,ne=_.avail_out,$=_.next_in,K=_.input,P=_.avail_in,Y=x.hold,q=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;fe=(I=x.lencode[Y&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((xe=I>>>24)<=q);){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(fe&&(240&fe)==0){for(ue=xe,E=fe,H=X;fe=(I=x.lencode[H+((Y&(1<<ue+E)-1)>>ue)])>>>16&255,X=65535&I,!(ue+(xe=I>>>24)<=q);){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}Y>>>=ue,q-=ue,x.back+=ue}if(Y>>>=xe,q-=xe,x.back+=xe,x.length=X,fe===0){x.mode=26;break}if(32&fe){x.back=-1,x.mode=12;break}if(64&fe){_.msg="invalid literal/length code",x.mode=30;break}x.extra=15&fe,x.mode=22;case 22:if(x.extra){for(M=x.extra;q<M;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.length+=Y&(1<<x.extra)-1,Y>>>=x.extra,q-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;fe=(I=x.distcode[Y&(1<<x.distbits)-1])>>>16&255,X=65535&I,!((xe=I>>>24)<=q);){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if((240&fe)==0){for(ue=xe,E=fe,H=X;fe=(I=x.distcode[H+((Y&(1<<ue+E)-1)>>ue)])>>>16&255,X=65535&I,!(ue+(xe=I>>>24)<=q);){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}Y>>>=ue,q-=ue,x.back+=ue}if(Y>>>=xe,q-=xe,x.back+=xe,64&fe){_.msg="invalid distance code",x.mode=30;break}x.offset=X,x.extra=15&fe,x.mode=24;case 24:if(x.extra){for(M=x.extra;q<M;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}x.offset+=Y&(1<<x.extra)-1,Y>>>=x.extra,q-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){_.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(ne===0)break e;if(oe=se-ne,x.offset>oe){if((oe=x.offset-oe)>x.whave&&x.sane){_.msg="invalid distance too far back",x.mode=30;break}_e=oe>x.wnext?(oe-=x.wnext,x.wsize-oe):x.wnext-oe,oe>x.length&&(oe=x.length),Ie=x.window}else Ie=R,_e=T-x.offset,oe=x.length;for(ne<oe&&(oe=ne),ne-=oe,x.length-=oe;R[T++]=Ie[_e++],--oe;);x.length===0&&(x.mode=21);break;case 26:if(ne===0)break e;R[T++]=x.length,ne--,x.mode=21;break;case 27:if(x.wrap){for(;q<32;){if(P===0)break e;P--,Y|=K[$++]<<q,q+=8}if(se-=ne,_.total_out+=se,x.total+=se,se&&(_.adler=x.check=x.flags?r(x.check,R,se,T-se):a(x.check,R,se,T-se)),se=ne,(x.flags?Y:k(Y))!==x.check){_.msg="incorrect data check",x.mode=30;break}q=Y=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;q<32;){if(P===0)break e;P--,Y+=K[$++]<<q,q+=8}if(Y!==(4294967295&x.total)){_.msg="incorrect length check",x.mode=30;break}q=Y=0}x.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return d}return _.next_out=T,_.avail_out=ne,_.next_in=$,_.avail_in=P,x.hold=Y,x.bits=q,(x.wsize||se!==_.avail_out&&x.mode<30&&(x.mode<27||j!==4))&&V(_,_.output,_.next_out,se-_.avail_out)?(x.mode=31,-4):(le-=_.avail_in,se-=_.avail_out,_.total_in+=le,_.total_out+=se,x.total+=se,x.wrap&&se&&(_.adler=x.check=x.flags?r(x.check,R,se,_.next_out-se):a(x.check,R,se,_.next_out-se)),_.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(le==0&&se===0||j===4)&&W===h&&(W=-5),W)},n.inflateEnd=function(_){if(!_||!_.state)return d;var j=_.state;return j.window&&(j.window=null),_.state=null,h},n.inflateGetHeader=function(_,j){var x;return _&&_.state?(2&(x=_.state).wrap)==0?d:((x.head=j).done=!1,h):d},n.inflateSetDictionary=function(_,j){var x,K=j.length;return _&&_.state?(x=_.state).wrap!==0&&x.mode!==11?d:x.mode===11&&a(1,j,K,0)!==x.check?-3:V(_,j,K,K)?(x.mode=31,-4):(x.havedict=1,h):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,s,n){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(u,f,h,d,g,m,b,k){var y,w,S,D,A,C,L,O,N,V=k.bits,_=0,j=0,x=0,K=0,R=0,$=0,T=0,P=0,ne=0,Y=0,q=null,le=0,se=new o.Buf16(16),oe=new o.Buf16(16),_e=null,Ie=0;for(_=0;_<=15;_++)se[_]=0;for(j=0;j<d;j++)se[f[h+j]]++;for(R=V,K=15;1<=K&&se[K]===0;K--);if(K<R&&(R=K),K===0)return g[m++]=20971520,g[m++]=20971520,k.bits=1,0;for(x=1;x<K&&se[x]===0;x++);for(R<x&&(R=x),_=P=1;_<=15;_++)if(P<<=1,(P-=se[_])<0)return-1;if(0<P&&(u===0||K!==1))return-1;for(oe[1]=0,_=1;_<15;_++)oe[_+1]=oe[_]+se[_];for(j=0;j<d;j++)f[h+j]!==0&&(b[oe[f[h+j]]++]=j);if(C=u===0?(q=_e=b,19):u===1?(q=a,le-=257,_e=r,Ie-=257,256):(q=l,_e=c,-1),_=x,A=m,T=j=Y=0,S=-1,D=(ne=1<<($=R))-1,u===1&&852<ne||u===2&&592<ne)return 1;for(;;){for(L=_-T,N=b[j]<C?(O=0,b[j]):b[j]>C?(O=_e[Ie+b[j]],q[le+b[j]]):(O=96,0),y=1<<_-T,x=w=1<<$;g[A+(Y>>T)+(w-=y)]=L<<24|O<<16|N|0,w!==0;);for(y=1<<_-1;Y&y;)y>>=1;if(y!==0?(Y&=y-1,Y+=y):Y=0,j++,--se[_]==0){if(_===K)break;_=f[h+b[j]]}if(R<_&&(Y&D)!==S){for(T===0&&(T=R),A+=x,P=1<<($=_-T);$+T<K&&!((P-=se[$+T])<=0);)$++,P<<=1;if(ne+=1<<$,u===1&&852<ne||u===2&&592<ne)return 1;g[S=Y&D]=R<<24|$<<16|A-m|0}}return Y!==0&&(g[A+Y]=_-T<<24|64<<16|0),k.bits=R,0}},{"../utils/common":41}],51:[function(i,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,s,n){var o=i("../utils/common"),a=0,r=1;function l(I){for(var z=I.length;0<=--z;)I[z]=0}var c=0,u=29,f=256,h=f+1+u,d=30,g=19,m=2*h+1,b=15,k=16,y=7,w=256,S=16,D=17,A=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],O=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],V=new Array(2*(h+2));l(V);var _=new Array(2*d);l(_);var j=new Array(512);l(j);var x=new Array(256);l(x);var K=new Array(u);l(K);var R,$,T,P=new Array(d);function ne(I,z,G,Z,B){this.static_tree=I,this.extra_bits=z,this.extra_base=G,this.elems=Z,this.max_length=B,this.has_stree=I&&I.length}function Y(I,z){this.dyn_tree=I,this.max_code=0,this.stat_desc=z}function q(I){return I<256?j[I]:j[256+(I>>>7)]}function le(I,z){I.pending_buf[I.pending++]=255&z,I.pending_buf[I.pending++]=z>>>8&255}function se(I,z,G){I.bi_valid>k-G?(I.bi_buf|=z<<I.bi_valid&65535,le(I,I.bi_buf),I.bi_buf=z>>k-I.bi_valid,I.bi_valid+=G-k):(I.bi_buf|=z<<I.bi_valid&65535,I.bi_valid+=G)}function oe(I,z,G){se(I,G[2*z],G[2*z+1])}function _e(I,z){for(var G=0;G|=1&I,I>>>=1,G<<=1,0<--z;);return G>>>1}function Ie(I,z,G){var Z,B,U=new Array(b+1),ie=0;for(Z=1;Z<=b;Z++)U[Z]=ie=ie+G[Z-1]<<1;for(B=0;B<=z;B++){var te=I[2*B+1];te!==0&&(I[2*B]=_e(U[te]++,te))}}function xe(I){var z;for(z=0;z<h;z++)I.dyn_ltree[2*z]=0;for(z=0;z<d;z++)I.dyn_dtree[2*z]=0;for(z=0;z<g;z++)I.bl_tree[2*z]=0;I.dyn_ltree[2*w]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function fe(I){8<I.bi_valid?le(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function X(I,z,G,Z){var B=2*z,U=2*G;return I[B]<I[U]||I[B]===I[U]&&Z[z]<=Z[G]}function ue(I,z,G){for(var Z=I.heap[G],B=G<<1;B<=I.heap_len&&(B<I.heap_len&&X(z,I.heap[B+1],I.heap[B],I.depth)&&B++,!X(z,Z,I.heap[B],I.depth));)I.heap[G]=I.heap[B],G=B,B<<=1;I.heap[G]=Z}function E(I,z,G){var Z,B,U,ie,te=0;if(I.last_lit!==0)for(;Z=I.pending_buf[I.d_buf+2*te]<<8|I.pending_buf[I.d_buf+2*te+1],B=I.pending_buf[I.l_buf+te],te++,Z===0?oe(I,B,z):(oe(I,(U=x[B])+f+1,z),(ie=C[U])!==0&&se(I,B-=K[U],ie),oe(I,U=q(--Z),G),(ie=L[U])!==0&&se(I,Z-=P[U],ie)),te<I.last_lit;);oe(I,w,z)}function H(I,z){var G,Z,B,U=z.dyn_tree,ie=z.stat_desc.static_tree,te=z.stat_desc.has_stree,me=z.stat_desc.elems,Se=-1;for(I.heap_len=0,I.heap_max=m,G=0;G<me;G++)U[2*G]!==0?(I.heap[++I.heap_len]=Se=G,I.depth[G]=0):U[2*G+1]=0;for(;I.heap_len<2;)U[2*(B=I.heap[++I.heap_len]=Se<2?++Se:0)]=1,I.depth[B]=0,I.opt_len--,te&&(I.static_len-=ie[2*B+1]);for(z.max_code=Se,G=I.heap_len>>1;1<=G;G--)ue(I,U,G);for(B=me;G=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ue(I,U,1),Z=I.heap[1],I.heap[--I.heap_max]=G,I.heap[--I.heap_max]=Z,U[2*B]=U[2*G]+U[2*Z],I.depth[B]=(I.depth[G]>=I.depth[Z]?I.depth[G]:I.depth[Z])+1,U[2*G+1]=U[2*Z+1]=B,I.heap[1]=B++,ue(I,U,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(Ce,De){var Fe,ze,et,Oe,ft,tt,Ke=De.dyn_tree,de=De.max_code,pe=De.stat_desc.static_tree,Qe=De.stat_desc.has_stree,at=De.stat_desc.extra_bits,_t=De.stat_desc.extra_base,lt=De.stat_desc.max_length,ai=0;for(Oe=0;Oe<=b;Oe++)Ce.bl_count[Oe]=0;for(Ke[2*Ce.heap[Ce.heap_max]+1]=0,Fe=Ce.heap_max+1;Fe<m;Fe++)lt<(Oe=Ke[2*Ke[2*(ze=Ce.heap[Fe])+1]+1]+1)&&(Oe=lt,ai++),Ke[2*ze+1]=Oe,de<ze||(Ce.bl_count[Oe]++,ft=0,_t<=ze&&(ft=at[ze-_t]),tt=Ke[2*ze],Ce.opt_len+=tt*(Oe+ft),Qe&&(Ce.static_len+=tt*(pe[2*ze+1]+ft)));if(ai!==0){do{for(Oe=lt-1;Ce.bl_count[Oe]===0;)Oe--;Ce.bl_count[Oe]--,Ce.bl_count[Oe+1]+=2,Ce.bl_count[lt]--,ai-=2}while(0<ai);for(Oe=lt;Oe!==0;Oe--)for(ze=Ce.bl_count[Oe];ze!==0;)de<(et=Ce.heap[--Fe])||(Ke[2*et+1]!==Oe&&(Ce.opt_len+=(Oe-Ke[2*et+1])*Ke[2*et],Ke[2*et+1]=Oe),ze--)}})(I,z),Ie(U,Se,I.bl_count)}function v(I,z,G){var Z,B,U=-1,ie=z[1],te=0,me=7,Se=4;for(ie===0&&(me=138,Se=3),z[2*(G+1)+1]=65535,Z=0;Z<=G;Z++)B=ie,ie=z[2*(Z+1)+1],++te<me&&B===ie||(te<Se?I.bl_tree[2*B]+=te:B!==0?(B!==U&&I.bl_tree[2*B]++,I.bl_tree[2*S]++):te<=10?I.bl_tree[2*D]++:I.bl_tree[2*A]++,U=B,Se=(te=0)===ie?(me=138,3):B===ie?(me=6,3):(me=7,4))}function W(I,z,G){var Z,B,U=-1,ie=z[1],te=0,me=7,Se=4;for(ie===0&&(me=138,Se=3),Z=0;Z<=G;Z++)if(B=ie,ie=z[2*(Z+1)+1],!(++te<me&&B===ie)){if(te<Se)for(;oe(I,B,I.bl_tree),--te!=0;);else B!==0?(B!==U&&(oe(I,B,I.bl_tree),te--),oe(I,S,I.bl_tree),se(I,te-3,2)):te<=10?(oe(I,D,I.bl_tree),se(I,te-3,3)):(oe(I,A,I.bl_tree),se(I,te-11,7));U=B,Se=(te=0)===ie?(me=138,3):B===ie?(me=6,3):(me=7,4)}}l(P);var F=!1;function M(I,z,G,Z){se(I,(c<<1)+(Z?1:0),3),(function(B,U,ie,te){fe(B),le(B,ie),le(B,~ie),o.arraySet(B.pending_buf,B.window,U,ie,B.pending),B.pending+=ie})(I,z,G)}n._tr_init=function(I){F||((function(){var z,G,Z,B,U,ie=new Array(b+1);for(B=Z=0;B<u-1;B++)for(K[B]=Z,z=0;z<1<<C[B];z++)x[Z++]=B;for(x[Z-1]=B,B=U=0;B<16;B++)for(P[B]=U,z=0;z<1<<L[B];z++)j[U++]=B;for(U>>=7;B<d;B++)for(P[B]=U<<7,z=0;z<1<<L[B]-7;z++)j[256+U++]=B;for(G=0;G<=b;G++)ie[G]=0;for(z=0;z<=143;)V[2*z+1]=8,z++,ie[8]++;for(;z<=255;)V[2*z+1]=9,z++,ie[9]++;for(;z<=279;)V[2*z+1]=7,z++,ie[7]++;for(;z<=287;)V[2*z+1]=8,z++,ie[8]++;for(Ie(V,h+1,ie),z=0;z<d;z++)_[2*z+1]=5,_[2*z]=_e(z,5);R=new ne(V,C,f+1,h,b),$=new ne(_,L,0,d,b),T=new ne(new Array(0),O,0,g,y)})(),F=!0),I.l_desc=new Y(I.dyn_ltree,R),I.d_desc=new Y(I.dyn_dtree,$),I.bl_desc=new Y(I.bl_tree,T),I.bi_buf=0,I.bi_valid=0,xe(I)},n._tr_stored_block=M,n._tr_flush_block=function(I,z,G,Z){var B,U,ie=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(te){var me,Se=4093624447;for(me=0;me<=31;me++,Se>>>=1)if(1&Se&&te.dyn_ltree[2*me]!==0)return a;if(te.dyn_ltree[18]!==0||te.dyn_ltree[20]!==0||te.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(te.dyn_ltree[2*me]!==0)return r;return a})(I)),H(I,I.l_desc),H(I,I.d_desc),ie=(function(te){var me;for(v(te,te.dyn_ltree,te.l_desc.max_code),v(te,te.dyn_dtree,te.d_desc.max_code),H(te,te.bl_desc),me=g-1;3<=me&&te.bl_tree[2*N[me]+1]===0;me--);return te.opt_len+=3*(me+1)+5+5+4,me})(I),B=I.opt_len+3+7>>>3,(U=I.static_len+3+7>>>3)<=B&&(B=U)):B=U=G+5,G+4<=B&&z!==-1?M(I,z,G,Z):I.strategy===4||U===B?(se(I,2+(Z?1:0),3),E(I,V,_)):(se(I,4+(Z?1:0),3),(function(te,me,Se,Ce){var De;for(se(te,me-257,5),se(te,Se-1,5),se(te,Ce-4,4),De=0;De<Ce;De++)se(te,te.bl_tree[2*N[De]+1],3);W(te,te.dyn_ltree,me-1),W(te,te.dyn_dtree,Se-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,ie+1),E(I,I.dyn_ltree,I.dyn_dtree)),xe(I),Z&&fe(I)},n._tr_tally=function(I,z,G){return I.pending_buf[I.d_buf+2*I.last_lit]=z>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&z,I.pending_buf[I.l_buf+I.last_lit]=255&G,I.last_lit++,z===0?I.dyn_ltree[2*G]++:(I.matches++,z--,I.dyn_ltree[2*(x[G]+f+1)]++,I.dyn_dtree[2*q(z)]++),I.last_lit===I.lit_bufsize-1},n._tr_align=function(I){se(I,2,3),oe(I,w,V),(function(z){z.bi_valid===16?(le(z,z.bi_buf),z.bi_buf=0,z.bi_valid=0):8<=z.bi_valid&&(z.pending_buf[z.pending++]=255&z.bi_buf,z.bi_buf>>=8,z.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,s,n){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,f,h=1,d={},g=!1,m=a.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(a);b=b&&b.setTimeout?b:a,l={}.toString.call(a.process)==="[object process]"?function(S){process.nextTick(function(){y(S)})}:(function(){if(a.postMessage&&!a.importScripts){var S=!0,D=a.onmessage;return a.onmessage=function(){S=!1},a.postMessage("","*"),a.onmessage=D,S}})()?(f="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",w,!1):a.attachEvent("onmessage",w),function(S){a.postMessage(f+S,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(S){y(S.data)},function(S){u.port2.postMessage(S)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(S){var D=m.createElement("script");D.onreadystatechange=function(){y(S),D.onreadystatechange=null,c.removeChild(D),D=null},c.appendChild(D)}):function(S){setTimeout(y,0,S)},b.setImmediate=function(S){typeof S!="function"&&(S=new Function(""+S));for(var D=new Array(arguments.length-1),A=0;A<D.length;A++)D[A]=arguments[A+1];var C={callback:S,args:D};return d[h]=C,l(h),h++},b.clearImmediate=k}function k(S){delete d[S]}function y(S){if(g)setTimeout(y,0,S);else{var D=d[S];if(D){g=!0;try{(function(A){var C=A.callback,L=A.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})(D)}finally{k(S),g=!1}}}}function w(S){S.source===a&&typeof S.data=="string"&&S.data.indexOf(f)===0&&y(+S.data.slice(f.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof fn<"u"?fn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(vo)),vo.exports}var Bg=Ag();const fc=Eg(Bg);function pc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function hc(e,t){var i,s,n;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(s=o==null?void 0:o.blocks)==null?void 0:s.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await hs(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((n=o[0])!=null&&n.content))return String(o[0].content).trim()}catch{}return""}async function Dg(e,t,i){var c,u,f;const s=c2(),n=!!((c=s==null?void 0:s.isPinned)!=null&&c.value),o=String(((u=s==null?void 0:s.pinnedDocId)==null?void 0:u.value)||"");if(n&&o&&i&&i!==o)return;const a=i||(n&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await hc(e,a));const l=pc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of h){const g=d.querySelector(".item__text"),m=((f=g==null?void 0:g.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){g&&(g.textContent=l),d.setAttribute("title",l);break}}}}function As(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Pi(e,t,i){var n,o;const s=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&s)try{const a=await i.fetchDocumentTitle(s);if(a&&a.trim())return As(a)}catch{}if(typeof document<"u")try{const a=(s?document.querySelector(`.protyle-title[data-node-id="${s}"] .protyle-title__input`):null)||(s?document.querySelector(`.protyle[data-doc-id="${s}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return As(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return As(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return As(l)}return"presentation"}function Lg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),s=document.createElement("a");return s.href=i,s.download=e,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(i),!0}function Sa(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function Pg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Uo(e,t){return new Promise(i=>{let s=[],n=null;const o=()=>{n&&(clearTimeout(n),n=null),s.forEach(l=>l()),s=[]};n=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});s.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});s.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function mc(e,t){const i=[],s=As((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(d=>d()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(d=>{var g;l(),(g=t==null?void 0:t.onProgress)==null||g.call(t,d.current,d.total,d.pageIndex)});o.push(c);const u=e.onCapturePageDone(d=>{l(),(d.mode==="all"||!d.mode)&&i.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});o.push(u);const f=async()=>{r();try{if(i.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new fc,g=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const k of i){const y=String(k.pageIndex).padStart(2,"0"),w=k.dataUrl.split(",")[1];d.file(`slide-${y}.${g}`,w,{base64:!0})}const m=await d.generateAsync({type:"blob",compression:"DEFLATE"}),b=Lg(`${s}.zip`,m);n({success:b,total:i.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};o.push(e.onCaptureComplete(f));const h=e.onCaptureError(d=>{r(),n({success:!1,error:d})});o.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function gc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const s=new sn;s.attach(i);try{if(await new Promise((n,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);s.onClientReady(()=>{clearTimeout(a),n()})}),s.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Uo(s,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await Pi(e,e.docId);return await mc(s,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{s.detach(),i.remove()}}const Og=1500,Rg=500,Ng=4,zg=new Set(["INPUT","TEXTAREA","SELECT"]);function vc(e){const t=e;return!t||!t.tagName?!1:zg.has(t.tagName)||t.isContentEditable===!0}function Hg(e){let t="",i=!1,s=null,n=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){s&&(clearTimeout(s),s=null),n&&(clearTimeout(n),n=null)}function r(){a(),t="",i=!1,o()}function l(){s&&clearTimeout(s),s=setTimeout(r,Og)}function c(){s&&(clearTimeout(s),s=null),i=!0,o(),n&&clearTimeout(n),n=setTimeout(r,Rg)}function u(f){if(e.isEnabled&&!e.isEnabled()||vc(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return i||t.length>=Ng||(t+=f.key,o(),l()),!0;if(f.key==="Enter"){if(!t||i)return!1;const d=parseInt(t,10),g=e.getTotalPages();return!isNaN(d)&&d>=1&&g>0&&d<=g?(r(),e.onJump(d),!0):(c(),!0)}return f.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Fg={class:"spm-slides-tab__toolbar"},jg={class:"spm-slides-tab__nav"},Wg=["disabled"],Ug={class:"spm-page-badge"},Vg=["disabled"],qg=["aria-label"],Gg=["aria-label"],Kg={class:"spm-slides-tab__tools"},Yg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Zg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Jg=["src"],Xg=Rt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=Ut("plugin"),s=Ut("sandboxBridge",new sn),n=new rg(s),o=new jp,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),u=ge(null),f=ge(1),h=ge(1),d=ge(!1),g=ge(!1),m=ge(!1),b=ge("siyuan"),k=ge(""),y=ge(""),w=ge(""),S=ge(!1),D=ge(!1),A=ge(""),C=ge(""),L=ge(!1),O=Hg({getTotalPages:()=>h.value,isEnabled:()=>!g.value,onJump:B=>_(B),onStateChange:B=>{C.value=B.display,L.value=B.invalid}});function N(B){if(B.key==="o"||B.key==="O"){if(g.value||B.isComposing||B.ctrlKey||B.metaKey||B.altKey||vc(B.target))return;B.preventDefault(),V();return}O.handleKeydown(B)&&B.preventDefault()}function V(){var B,U;if(a.value==="pro-cli"){(B=u.value)==null||B.focus(),ae.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}s.toggleOverview(),(U=u.value)==null||U.focus()}function _(B){var U;f.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):s.navigatePage(B),(U=u.value)==null||U.focus()}const j=ge("/plugins/siyuan-live-slides/slides-client/index.html");let x=null,K=null,R=null,$=null,T=null,P=null,ne=null,Y=null,q=null;ws(()=>{u.value&&(s.attach(u.value),o.nativeBridge.attach(u.value)),x=s.onSlideChanged((B,U)=>{f.value=B,h.value=U}),K=s.onBlockClicked((B,U)=>{f.value=U,n.setActiveBlockId(B),B||Fs(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(B,U):B&&Ji(B,i==null?void 0:i.app)}),R=s.onOpenInEditor((B,U)=>{f.value=U,n.setActiveBlockId(B),Ji(B,i==null?void 0:i.app)}),$=o.nativeBridge.onPageChanged((B,U)=>{f.value=B,h.value=U}),T=s.onOpenPeekDrawer(async B=>{const U=Qn();if(B.peekType==="siyuan"&&U.enableWebServeJump){let ie=!1;if(q&&q.docId===B.target)ie=!0;else if(q&&q.slides&&q.slides.some(te=>{var me;return(me=te.blocks)==null?void 0:me.some(Se=>Se.id===B.target)}))ie=!1;else try{const te=await hs(`SELECT id, root_id, type FROM blocks WHERE id = '${B.target}' LIMIT 1`);te&&te.length>0&&(ie=te[0].type==="d"||te[0].id===te[0].root_id)}catch(te){console.warn("[SlidesPreviewTab] detect block type failed:",te)}b.value="web",S.value=!0,y.value=ql(U.webServeUrl,B.target,{focus:!ie}),w.value=B.title||`${ie?"思源文档":"思源块"}: ${B.target.slice(0,8)}`,g.value=!0,s.freezeKeyboardNav(!0)}else{if(b.value=B.peekType,B.peekType==="siyuan")k.value=B.target,w.value=B.title||`块速览: ${B.target.slice(0,8)}`;else{const ie=nc(B.target);if(ie.external){E(B.target);return}S.value=!0,y.value=ie.url,w.value=B.title||ie.url}g.value=!0,s.freezeKeyboardNav(!0)}}),P=s.onRequestToggleFullscreen(()=>{v()}),ne=s.onOpenPresenter(()=>{W()}),typeof document<"u"&&document.addEventListener("fullscreenchange",H),Y=tc(B=>{q&&a.value==="web-sandbox"&&s.updateSlides(q.slides,{...q.config,hostThemeMode:B},q.fullMarkdown,q.customThemeCss)})}),Yn(()=>{Y&&(Y(),Y=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",H),T&&T(),P&&P(),ne&&ne(),x&&x(),K&&K(),R&&R(),$&&$(),s.detach(),O.clear(),n.destroy(),o.destroy()});async function le(){if(a.value==="web-sandbox"){if(!q){ae.showMessage("请先在主编辑区打开演示文档");return}ae.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const B=await o.startProMode(q,_o);if(!B.success){ae.showMessage(`无法启动官方 Pro 模式：${B.error}`);return}a.value="pro-cli",r.value=B.port||3030,j.value=B.url,u.value&&o.nativeBridge.attach(u.value),ae.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",j.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&s.attach(u.value),ae.showMessage("已切回内置高保真沙箱")}function se(){D.value=!D.value,D.value?(A.value=(q==null?void 0:q.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.value)):(A.value="",fe(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let oe=0;function _e(B){if(g.value||Math.abs(B.deltaY)<Math.abs(B.deltaX)||Math.abs(B.deltaY)<15)return;const U=Date.now();U-oe<280||(oe=U,B.deltaY>0?xe():Ie())}function Ie(){if(f.value>1){const B=f.value-1;f.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):s.navigatePage(B)}}function xe(){if(f.value<h.value){const B=f.value+1;f.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):s.navigatePage(B)}}function fe(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function X(){g.value=!1,s.freezeKeyboardNav(!1)}function ue(){X()}function E(B){var me,Se;const U=/^file:/i.test(B),ie=U||/^[a-zA-Z]:[\\/]/.test(B),te=Lt("electron");if(ie&&typeof((me=te==null?void 0:te.shell)==null?void 0:me.openPath)=="function"){te.shell.openPath(U?sc(B):B),ae.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Se=te==null?void 0:te.shell)==null?void 0:Se.openExternal)=="function"?te.shell.openExternal(B).catch(()=>{typeof window<"u"&&window.open(B,"_blank")}):typeof window<"u"&&window.open(B,"_blank"),ae.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function H(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function v(){const B=l.value||u.value;B&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):B.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function W(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function F(){if(!q){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const B=await Pi(q,i==null?void 0:i.currentDocId,i),U=cc(q,{title:B});dc(`${B}.html`,U)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${B}.html)`)}function M(){if(!q){ae.showMessage("请先在主编辑区打开幻灯片文档");return}uc(q)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const I=ge(!1);async function z(){if(I.value){ae.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!q){ae.showMessage("请先在主编辑区打开幻灯片文档");return}I.value=!0;try{ae.showMessage("正在逐页导出幻灯片图片...",2e3);const B=await Pi(q,i==null?void 0:i.currentDocId,i),U=await mc(s,{title:B,onProgress:(ie,te)=>{ae.showMessage(`正在导出幻灯片图片 (${ie} / ${te})...`,1500)}});U.success?ae.showMessage(`🎉 成功导出 ${U.total||0} 张高清图片并保存为 ${B}.zip！`,4e3):ae.showMessage(`导出图片失败：${U.error||"未知异常"}`)}finally{I.value=!1}}async function G(){if(!q){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在导出当前幻灯片图片...",1500);const B=await Uo(s);if(B.success&&B.dataUrl){const U=await Pi(q,i==null?void 0:i.currentDocId,i),ie=f.value||1,me=(h.value||1)>1?`${U}-${ie}.png`:`${U}.png`;Sa(me,B.dataUrl),ae.showMessage(`已下载当前页高清图片 (${me})`)}else ae.showMessage(`导出当前页图片失败：${B.error||"未知异常"}`)}async function Z(){if(!q){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const B=await Uo(s);if(B.success&&B.dataUrl)if(await Pg(B.dataUrl))ae.showMessage(`已成功将第 ${f.value||1} 页幻灯片复制到剪贴板！`);else{const ie=await Pi(q,i==null?void 0:i.currentDocId,i),te=f.value||1,Se=(h.value||1)>1?`${ie}-${te}.png`:`${ie}.png`;Sa(Se,B.dataUrl),ae.showMessage(`剪贴板权限不可用，已自动下载为 ${Se}`)}else ae.showMessage(`复制失败：${B.error||"未知异常"}`)}return t({updateDocument(B,U){D.value&&A.value&&U&&U!==A.value||(q=B,D.value&&!A.value&&(A.value=B.docId),h.value=B.slides.length,n.setDocId(B.docId),n.updateSlidesIndex(B.slides),a.value==="pro-cli"?o.scaffolder.scaffold(B,_o).catch(()=>{}):s.updateSlides(B.slides,{...B.config,hostThemeMode:Ri()},B.fullMarkdown,B.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",B.docId))},navigateToBlock(B){n.onCursorFocusBlock(B)},isPinned:D,pinnedDocId:A,engineMode:a,toggleEngineMode:le}),(B,U)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:N},[p("div",Fg,[p("div",jg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:Ie},[re(ce,{name:"chevron-left"})],8,Wg),p("span",Ug,we(f.value)+" / "+we(h.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=h.value,"aria-label":"下一页",onClick:xe},[re(ce,{name:"chevron-right"})],8,Vg),p("button",{class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":D.value}]),"aria-label":D.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:se},[re(ce,{name:"pin"}),p("span",null,we(D.value?"已锁定":"跟随"),1)],10,qg),he(kt)("proMode")?(J(),ee("button",{key:0,class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:le},[re(ce,{name:"rocket"}),p("span",null,we(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Gg)):Te("",!0)]),p("div",Kg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:V},[re(ce,{name:"columns"})]),he(kt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:W},[re(ce,{name:"presenter"})])):Te("",!0),he(kt)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:F},[re(ce,{name:"export-html"})])):Te("",!0),he(kt)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:M},[re(ce,{name:"export-pdf"})])):Te("",!0),he(kt)("exportImage")?(J(),ee("div",Yg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:z},[re(ce,{name:"export-image"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:U[0]||(U[0]=ei(ie=>d.value=!d.value,["stop"]))},[re(ce,{name:"chevron-down"})]),d.value?(J(),ee("div",Zg,[p("button",{class:"b3-menu__item",onClick:U[1]||(U[1]=ie=>{z(),d.value=!1})},[...U[6]||(U[6]=[p("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),p("button",{class:"b3-menu__item",onClick:U[2]||(U[2]=ie=>{G(),d.value=!1})},[...U[7]||(U[7]=[p("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),p("button",{class:"b3-menu__item",onClick:U[3]||(U[3]=ie=>{Z(),d.value=!1})},[...U[8]||(U[8]=[p("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:fe},[re(ce,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:v},[re(ce,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:_e},[p("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:j.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Jg),re(bm,{visible:g.value,"onUpdate:visible":U[4]||(U[4]=ie=>g.value=ie),"is-maximized":m.value,"onUpdate:isMaximized":U[5]||(U[5]=ie=>m.value=ie),title:w.value,onClose:X},{default:ml(()=>[b.value==="siyuan"&&k.value?(J(),ti(Im,{key:0,"block-id":k.value,title:w.value,plugin:he(i),onExternalJump:ue},null,8,["block-id","title","plugin"])):Te("",!0),S.value?Ft((J(),ti(ng,{key:1,visible:g.value&&b.value==="web",url:y.value,title:w.value,onExternalJump:ue},null,8,["visible","url","title"])),[[No,b.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ft(p("div",{class:$e(["spm-jump-badge",{"is-invalid":L.value}])},we(C.value),3),[[No,C.value]])],544)],32))}}),Qg=ri(Xg,[["__scopeId","data-v-e2be740c"]]);function bc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,s=new Map;let n=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!s.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const h=parseInt(f,10);n=Math.max(n,h),s.set(r.parentContainerId,h)}else n+=1,s.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&s.has(r.parentContainerId)){const f=s.get(r.parentContainerId);o(r,{type:"step",step:f})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,o(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const h=Math.min(Number(f[0]),Number(f[1])),d=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(h)&&!isNaN(d)){n=Math.max(n,d),o(r,{type:"range",min:h,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,o(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;n+=f,o(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;n=Math.max(1,n-f),o(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){n=Math.max(n,f),o(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),o(r,{type:"step",step:u})):(n+=1,o(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:i}}function ev(e,t,i){if(!e)return"v-click-visible";const s=e.id||e.blockId,n=i.blockMap.get(e)||(s?i.idMap.get(s):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Vo=980;function tv(e){if(!e)return 0;const i=bc(e.blocks||[]).maxStep||0,s=e.frontmatter||{},n=s.mask;if(n!=="down"&&n!=="right")return i;const o=Dd(s.maskRatio),r=s.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function iv(e,t=Vo){const i=(e||"16/9").trim();let s=16/9;if(i==="4/3"||i==="4:3")s=4/3;else if(i==="16/10"||i==="16:10")s=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(s=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(s=o)}const n=Math.ceil(t/s);return{baseWidth:t,baseHeight:n,ratio:s}}function Ca(e,t,i=Vo,s=552,n=16){const o=i>0?i:Vo,a=s>0?s:552,r=Math.max(0,e-n),l=Math.max(0,t-n);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function sv(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function _a(e,t){if(!e)return"";const i=sv(e),s=i.frontmatter||{},n=s.layout||"default",o=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!s.image&&!s.background&&o.image&&(s.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?bc(i.blocks||[]):null,u=lc(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?w=>{if(ev(w,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const D=w.id||w.blockId,A=l.blockMap.get(w)||(D?l.idMap.get(D):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(w,S)=>{let D=S.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(D)||(D+=" muted"),`<video ${D.trim()}>`}),f=s.spacing,h=f&&f!=="inherit"?f:o.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${h}`,s.class||"",s.layoutClass||""].filter(Boolean).join(" "),g=[],m=(s.background||o.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const w=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;g.push(`background-image:url('${rt(w)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else g.push(`background:${rt(m)};`);const b=typeof s.zoom=="number"?s.zoom:typeof s.zoom=="string"?parseFloat(s.zoom):1,k=!isNaN(b)&&b>0?b:1;k!==1&&g.push(`width:${(100/k).toFixed(2)}%;height:${(100/k).toFixed(2)}%;transform-origin:top left;transform:scale(${k});`);const y=g.length>0?` style="${g.join("")}"`:"";return`<div class="${rt(d)}"${y}>${u}</div>`}const nv={class:"presenter-header"},ov={class:"presenter-title-area"},rv={class:"presenter-brand"},av={class:"header-pills"},lv={class:"pill pill-page"},cv={key:0,class:"pill pill-step"},dv={class:"header-toolbar"},uv={class:"timer-capsule"},fv={class:"timer-digits"},pv={class:"timer-actions"},hv=["aria-label"],mv={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},gv={key:0,class:"presenter-grid"},vv={class:"slide-panels"},bv={class:"panel-box current-slide-panel"},yv={class:"panel-header"},kv={class:"panel-header-left"},wv={class:"panel-page-num"},xv={class:"panel-header-meta"},Sv={key:0,class:"panel-step-pill"},Cv={class:"panel-layout-pill"},_v=["aria-label"],$v=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Iv={key:1,class:"panel-fallback"},Mv=["aria-label"],Tv={class:"panel-header"},Ev={class:"panel-header-left"},Av={key:0,class:"panel-page-num"},Bv={class:"panel-header-meta"},Dv={key:0,class:"panel-end-pill"},Lv={key:1,class:"panel-layout-pill"},Pv=["aria-label"],Ov=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Rv={key:1,class:"panel-fallback"},Nv={class:"notes-panel"},zv={class:"panel-header"},Hv={class:"panel-header-left"},Fv={class:"notes-size-controls"},jv=["disabled"],Wv={class:"notes-size-value"},Uv=["disabled"],Vv={key:1,class:"presenter-empty"},qv={class:"empty-icon-wrap"},Gv={class:"empty-actions"},Kv={class:"presenter-actions"},Yv={class:"nav-btn-group"},Zv=["disabled"],Jv=["disabled"],Xv={class:"actions-center"},Qv={class:"center-meta"},eb={class:"progress-pill"},tb={class:"nav-btn-group"},ib=["aria-label"],sb={class:"step-dots-text"},nb=["disabled"],ob=["disabled"],rb=280,ab=15,lb=Rt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=Ut("plugin"),s=Ut("sandboxBridge",new sn),n=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),u=ye(()=>n.value.length||l.value),f=ge(null),h=ge(null),d=ge({width:0,height:0}),g=ge({width:0,height:0}),m=ge(Ri()),b=ye(()=>{var de;return iv((de=o.value)==null?void 0:de.aspectRatio)}),k=ye(()=>{var de;return((de=o.value)==null?void 0:de.theme)||"default"}),y=ye(()=>{var de;return wr((de=o.value)==null?void 0:de.colorSchema,m.value)}),w=ye(()=>{var de;return!!((de=o.value)!=null&&de.normalizeHeadingSizes)}),S=ye(()=>{var de;return((de=o.value)==null?void 0:de.showUnorderedListMarkers)===!1}),D=ye(()=>{var de;return((de=o.value)==null?void 0:de.showOrderedListMarkers)===!1}),A=ye(()=>Ca(d.value.width,d.value.height,b.value.baseWidth,b.value.baseHeight,14)),C=ye(()=>Ca(g.value.width,g.value.height,b.value.baseWidth,b.value.baseHeight,14));function L(){f.value&&(d.value={width:f.value.clientWidth,height:f.value.clientHeight}),h.value&&(g.value={width:h.value.clientWidth,height:h.value.clientHeight})}let O=null;function N(){typeof window>"u"||typeof window.ResizeObserver!="function"||(O||(O=new window.ResizeObserver(()=>{L()})),O.disconnect(),f.value&&O.observe(f.value),h.value&&O.observe(h.value))}Zi([f,h,u],()=>{An(()=>{N(),L()})},{flush:"post"});const V=ge(0),_=ge(!0);let j=null,x=Date.now(),K=0;const R=ye(()=>{const de=String(Math.floor(V.value/60)).padStart(2,"0"),pe=String(V.value%60).padStart(2,"0");return`${de}:${pe}`});function $(){if(_.value){const de=K+(Date.now()-x);V.value=Math.floor(de/1e3)}}function T(){_.value?(K+=Date.now()-x,_.value=!1):(x=Date.now(),_.value=!0,$())}function P(){x=Date.now(),K=0,V.value=0}const ne=ge("");let Y=null;function q(){const de=new Date,pe=String(de.getHours()).padStart(2,"0"),Qe=String(de.getMinutes()).padStart(2,"0");ne.value=`${pe}:${Qe}`}const le=ye(()=>n.value.length===0?null:n.value[a.value-1]||null),se=ye(()=>a.value>=n.value.length?null:n.value[a.value]||null);function oe(de){var _t;const pe=de==null?void 0:de.frontmatter;if((pe==null?void 0:pe.colorSchema)==="light")return"light";if((pe==null?void 0:pe.colorSchema)==="dark")return"dark";if(typeof(pe==null?void 0:pe.class)=="string"){const lt=pe.class.split(/\s+/);if(lt.includes("light"))return"light";if(lt.includes("dark"))return"dark"}const Qe=(pe==null?void 0:pe.background)||((_t=o.value)==null?void 0:_t.background),at=ec(Qe);return at===!0?"light":at===!1?"dark":y.value}const _e=ye(()=>oe(le.value)),Ie=ye(()=>oe(se.value)),xe=ye(()=>le.value?tv(le.value):c.value),fe=ye(()=>a.value>1||r.value>0),X=ye(()=>a.value<u.value||r.value<xe.value),ue=ye(()=>_a(le.value,{config:o.value,allSlides:n.value,pageIndex:a.value,currentStep:r.value})),E=ye(()=>_a(se.value,{config:o.value,allSlides:n.value,pageIndex:a.value+1})),H=ye(()=>{var pe;if(!le.value)return"无内容";const de=(pe=le.value.blocks)==null?void 0:pe[0];return(de==null?void 0:de.content)||(de==null?void 0:de.rawMarkdown)||`第 ${a.value} 页`});function v(de){return(de||[]).slice(1).map(pe=>(pe.content||pe.rawMarkdown||"").trim()).filter(pe=>pe&&!/^(image\s+)?assets\/\S*$/i.test(pe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(pe)).join(" | ").slice(0,120)}const W=ye(()=>{var de;return v((de=le.value)==null?void 0:de.blocks)}),F=ye(()=>{var pe;if(!se.value)return"演示结束";const de=(pe=se.value.blocks)==null?void 0:pe[0];return(de==null?void 0:de.content)||(de==null?void 0:de.rawMarkdown)||`第 ${a.value+1} 页`}),M=ye(()=>se.value?v(se.value.blocks):"这是最后一页"),I=ye(()=>{var de;return((de=le.value)==null?void 0:de.notes)||""}),z=ge(20);function G(){z.value<36&&(z.value+=2)}function Z(){z.value>14&&(z.value-=2)}const B=ye(()=>u.value<=1?100:Math.round(a.value/u.value*100));let U=null;try{U=new BroadcastChannel("siyuan-slides-sync"),U.onmessage=de=>{const pe=de.data;if(pe&&(pe.type==="SYNC_PAGE"&&typeof pe.page=="number"&&(a.value=pe.page,r.value=typeof pe.step=="number"?Math.max(0,pe.step):0,typeof pe.maxStep=="number"&&(c.value=Math.max(0,pe.maxStep))),pe.type==="SYNC_SLIDES"&&Array.isArray(pe.slides)&&(n.value=pe.slides,pe.config&&typeof pe.config=="object"&&(o.value=pe.config)),pe.type==="REQUEST_SYNC"&&n.value.length>0))try{U==null||U.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),U==null||U.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:xe.value})}catch{}}}catch{U=null}function ie(de,pe=0){const Qe=Number(de)||1,at=Math.max(0,Number(pe)||0);s.navigatePage(Qe,at);try{U==null||U.postMessage({type:"SYNC_PAGE",page:Qe,step:at,maxStep:xe.value})}catch{}}function te(){if(r.value<xe.value){r.value++,ie(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,ie(a.value,0))}function me(){if(r.value>0){r.value--,ie(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,ie(a.value,0))}function Se(){a.value<u.value&&(a.value++,r.value=0,ie(a.value,0))}function Ce(){a.value>1&&(a.value--,r.value=0,ie(a.value,0))}function De(){a.value=1,r.value=0,P(),ie(1,0)}function Fe(){const de=i;typeof(de==null?void 0:de.openBottomPreviewTab)=="function"&&de.openBottomPreviewTab()}function ze(){const de=i;typeof(de==null?void 0:de.openStandalonePreviewWindow)=="function"&&de.openStandalonePreviewWindow()}function et(de){var pe,Qe;if(!(de.key===" "&&((Qe=(pe=de.target)==null?void 0:pe.closest)!=null&&Qe.call(pe,"button")))){if(de.shiftKey&&de.key==="ArrowRight"||de.key==="ArrowDown"){de.preventDefault(),Se();return}if(de.shiftKey&&de.key==="ArrowLeft"||de.key==="ArrowUp"){de.preventDefault(),Ce();return}de.key==="ArrowRight"||de.key===" "||de.key==="PageDown"?(de.preventDefault(),te()):(de.key==="ArrowLeft"||de.key==="PageUp")&&(de.preventDefault(),me())}}let Oe=0;function ft(de){var at,_t;if(Math.abs(de.deltaY)<ab)return;const pe=(_t=(at=de.target)==null?void 0:at.closest)==null?void 0:_t.call(at,".notes-content");if(pe){const lt=pe.scrollHeight-pe.clientHeight;if(lt>2&&(de.deltaY>0&&pe.scrollTop<lt-1||de.deltaY<0&&pe.scrollTop>1))return}const Qe=Date.now();Qe-Oe<rb||(Oe=Qe,de.deltaY>0?te():me())}let tt=null,Ke=null;return ws(()=>{var pe;m.value=Ri(),Ke=tc(Qe=>{m.value=Qe}),x=Date.now(),K=0,j=window.setInterval($,500),typeof document<"u"&&document.addEventListener("visibilitychange",$),q(),Y=window.setInterval(q,1e3),tt=s.onSlideChanged((Qe,at,_t,lt,ai)=>{a.value=Qe,at>0&&(l.value=at),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof ai=="number"&&(c.value=Math.max(0,ai))});try{U==null||U.postMessage({type:"REQUEST_SYNC"})}catch{}const de=i==null?void 0:i.latestCompiledDoc;(pe=de==null?void 0:de.slides)!=null&&pe.length&&(n.value=de.slides,de.config&&(o.value=de.config)),typeof window<"u"&&window.addEventListener("resize",L),An(()=>{N(),L()})}),Yn(()=>{Ke&&(Ke(),Ke=null),j&&(window.clearInterval(j),j=null),typeof document<"u"&&document.removeEventListener("visibilitychange",$),Y&&(window.clearInterval(Y),Y=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",L),O&&(O.disconnect(),O=null);try{U==null||U.close()}catch{}U=null}),t({updateDocument(de){var pe;(pe=de==null?void 0:de.slides)!=null&&pe.length&&(n.value=de.slides),de!=null&&de.config&&(o.value=de.config)}}),(de,pe)=>{var Qe,at,_t;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:et,onWheel:ft},[p("header",nv,[p("div",ov,[p("div",rv,[re(ce,{name:"presenter",class:"brand-icon"}),pe[1]||(pe[1]=p("span",{class:"title-name"},"演讲者控制台",-1))]),p("div",av,[p("span",lv,"P."+we(a.value)+" / "+we(u.value||1),1),xe.value>0?(J(),ee("span",cv,[re(ce,{name:"step",class:"pill-icon"}),Bt(" 步进 "+we(r.value)+" / "+we(xe.value),1)])):Te("",!0)])]),p("div",dv,[p("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:ze},[re(ce,{name:"window"}),pe[2]||(pe[2]=p("span",{class:"btn-tool-label"},"独立放映",-1))]),p("div",uv,[re(ce,{name:"clock",class:"timer-icon"}),p("span",fv,we(R.value),1),p("div",pv,[p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":_.value?"暂停计时":"继续计时",onClick:T},[re(ce,{name:_.value?"pause":"play"},null,8,["name"])],8,hv),p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:P},[re(ce,{name:"reset"})])])]),p("div",mv,[p("span",null,we(ne.value),1)])])]),u.value>0?(J(),ee("main",gv,[p("section",vv,[p("div",bv,[p("div",yv,[p("div",kv,[pe[3]||(pe[3]=p("span",{class:"panel-tag is-current"},"当前放映",-1)),p("span",wv,"P."+we(a.value),1)]),p("div",xv,[xe.value>0?(J(),ee("span",Sv," 步进 "+we(r.value)+" / "+we(xe.value),1)):Te("",!0),p("span",Cv,we(((at=(Qe=le.value)==null?void 0:Qe.frontmatter)==null?void 0:at.layout)||"default"),1)])]),p("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":H.value},[le.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Nt({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[p("div",{class:$e(["presenter-thumb-viewport slide-viewport","slides-theme-"+k.value]),"data-theme":_e.value,"data-slides-theme":k.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":D.value?"true":"false",style:Nt({width:b.value.baseWidth+"px",height:b.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:ue.value},null,14,$v)],4)):(J(),ee("div",Iv,[p("h2",null,we(H.value),1),p("p",null,we(W.value),1)]))],8,_v)]),p("div",{class:$e(["panel-box next-slide-panel",{"is-clickable":!!se.value,"b3-tooltips b3-tooltips__n":!!se.value}]),"aria-label":se.value?"点击直接跳至下一页":"",onClick:pe[0]||(pe[0]=lt=>se.value&&Se())},[p("div",Tv,[p("div",Ev,[pe[4]||(pe[4]=p("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(J(),ee("span",Av,"P."+we(a.value+1),1)):Te("",!0)]),p("div",Bv,[a.value>=u.value?(J(),ee("span",Dv,"已到尾页")):se.value?(J(),ee("span",Lv,we(((_t=se.value.frontmatter)==null?void 0:_t.layout)||"default"),1)):Te("",!0)])]),p("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":F.value},[se.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Nt({width:C.value.boxWidth+"px",height:C.value.boxHeight+"px"})},[p("div",{class:$e(["presenter-thumb-viewport slide-viewport","slides-theme-"+k.value]),"data-theme":Ie.value,"data-slides-theme":k.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":D.value?"true":"false",style:Nt({width:b.value.baseWidth+"px",height:b.value.baseHeight+"px",transform:"scale("+C.value.scale+")"}),innerHTML:E.value},null,14,Ov)],4)):(J(),ee("div",Rv,[p("h2",null,we(F.value),1),p("p",null,we(M.value),1)]))],8,Pv)],10,Mv)]),p("section",Nv,[p("div",zv,[p("div",Hv,[re(ce,{name:"notes",class:"panel-title-icon"}),pe[5]||(pe[5]=p("span",null,"讲稿备忘",-1))]),p("div",Fv,[p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:z.value<=14,onClick:Z},[re(ce,{name:"minus"})],8,jv),p("span",Wv,we(z.value)+"px",1),p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:z.value>=36,onClick:G},[re(ce,{name:"plus"})],8,Uv)])]),p("div",{class:$e(["notes-content",{"is-empty":!I.value}]),style:Nt({fontSize:z.value+"px"})},we(I.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Vv,[p("div",qv,[re(ce,{name:"refresh",class:"empty-icon"})]),pe[8]||(pe[8]=p("h2",null,"等待大屏放映数据",-1)),pe[9]||(pe[9]=p("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),p("div",Gv,[p("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:Fe},[re(ce,{name:"presenter"}),pe[6]||(pe[6]=p("span",null,"打开大屏放映页签",-1))]),p("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:ze},[re(ce,{name:"window"}),pe[7]||(pe[7]=p("span",null,"弹出独立放映窗口",-1))])])])),p("footer",Kv,[p("div",Yv,[p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:Ce},[re(ce,{name:"chevrons-left"}),pe[10]||(pe[10]=p("span",null,"上一页",-1))],8,Zv),p("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!fe.value,"aria-label":"回退一步 (←)",onClick:me},[re(ce,{name:"chevron-left"}),pe[11]||(pe[11]=p("span",null,"上一步",-1))],8,Jv)]),p("div",Xv,[p("div",Qv,[p("span",eb,we(B.value)+"%",1)]),p("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:De},[re(ce,{name:"reset"}),pe[12]||(pe[12]=p("span",null,"重头放映",-1))])]),p("div",tb,[xe.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${xe.value}`},[(J(!0),ee(Je,null,Mt(xe.value,lt=>(J(),ee("span",{key:lt,class:$e(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),p("span",sb,we(r.value)+"/"+we(xe.value),1)],8,ib)):Te("",!0),p("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!X.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:te},[pe[13]||(pe[13]=p("span",null,"下一步",-1)),re(ce,{name:"chevron-right"})],8,nb),p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Se},[pe[14]||(pe[14]=p("span",null,"下一页",-1)),re(ce,{name:"chevrons-right"})],8,ob)])])],32)}}}),cb=ri(lb,[["__scopeId","data-v-f80cf3a9"]]),db={class:"spm-layout-picker"},ub={class:"spm-layout-picker__grid"},fb=["title","onClick"],pb={class:"spm-layout-icon"},hb={class:"spm-layout-label"},mb=Rt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,s=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){s("update:modelValue",r),s("change",r)}return(r,l)=>(J(),ee("div",db,[l[0]||(l[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",ub,[(J(),ee(Je,null,Mt(n,c=>p("div",{key:c.name,class:$e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[p("div",pb,[re(ce,{name:"layout-"+c.name},null,8,["name"])]),p("span",hb,we(c.label),1)],10,fb)),64))])]))}}),gb=ri(mb,[["__scopeId","data-v-96c8a248"]]),vb={key:0,class:"spm-transition-selector__header"},bb={class:"spm-transition-list"},yb=["onClick"],kb={class:"spm-transition-meta"},wb={class:"spm-transition-label"},xb={class:"spm-transition-preview-box"},Sb=Rt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(J(),ee("div",{class:$e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",vb,we(e.title||"转场动效"),1)),p("div",bb,[(J(),ee(Je,null,Mt(s,r=>p("div",{key:r.name,class:$e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>n(r.name)},[p("div",kb,[p("span",wb,we(r.label),1)]),p("div",xb,[p("div",{class:$e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,yb)),64))])],2))}}),yc=ri(Sb,[["__scopeId","data-v-b5051f69"]]),Cb={class:"spm-section spm-section--page"},_b={class:"spm-section-header"},$b={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Ib={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Mb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Tb={key:1,class:"spm-card-control"},Eb={class:"spm-control-header"},Ab={class:"spm-control-title-group"},Bb={class:"spm-control-title"},Db={class:"spm-quick-chips"},Lb=["onClick"],Pb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ob=["value"],Rb=["aria-label"],Nb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},zb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Hb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Fb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},qb={class:"spm-segmented-group"},Gb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Kb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Yb=["aria-label"],Zb={class:"spm-quick-chips"},Jb=["onClick"],Xb=["value"],Qb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},e1={style:{display:"flex",gap:"8px","margin-top":"2px"}},t1={style:{flex:"1"}},i1={class:"spm-segmented-group"},s1={style:{flex:"1"}},n1={class:"spm-segmented-group"},o1={class:"spm-card-control"},r1={class:"spm-control-header"},a1={class:"spm-control-title-group"},l1={class:"spm-control-title"},c1={class:"spm-segmented-group"},d1={key:2,class:"spm-card-control"},u1={class:"spm-control-header"},f1={class:"spm-control-title-group"},p1={class:"spm-control-title"},h1={class:"spm-quick-chips"},m1=["onClick"],g1=["value"],v1={class:"spm-card-control"},b1={class:"spm-control-header"},y1={class:"spm-control-title-group"},k1={class:"spm-control-title"},w1={key:0,class:"spm-note-status-box"},x1=["title"],S1={class:"spm-action-grid",style:{"margin-top":"6px"}},C1={key:1,class:"spm-note-empty-box"},_1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},$1={class:"spm-action-grid"},I1=["disabled"],M1=["disabled"],T1={class:"spm-card-control"},E1={class:"spm-action-grid"},A1=Rt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,s=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const y=i.pageMask;return y==="clockwise"||y==="counter-clockwise"||y==="cw"||y==="ccw"}),a=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||a.value);function l(y){s("update:pageMask",y),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&s("update:pageMaskRatio","1:1:1:1")}function c(y){s("update:pageMask",y),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&s("update:pageMaskRatio","1:1")}const u=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),h=ye(()=>{var S,D;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const y=(i.pageLayoutRatio||"").trim();if(y.includes(":")){const A=y.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const w=(i.detectedSbRatio||"").trim();if(w.includes(":")){const A=w.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((S=i.detectedSbInfo)!=null&&S.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((D=i.detectedSbInfo)!=null&&D.slots&&Array.isArray(i.detectedSbInfo.slots)){const A=i.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),d=ye(()=>{const y=h.value;return y===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:y===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:y===5?[{label:"默认 1:1:1:1:1",value:""}]:y===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),g=ye(()=>i.pageLayoutRatio||"");function m(){const y=h.value||2,w=Array(y).fill("1").join(":");s("update:pageLayoutRatio",w),s("resetSuperblockRatio")}const b=ye(()=>{if(!i.pageNotes)return"";const y=i.pageNotes.replace(/[\r\n]+/g," ").trim();return y.length>50?y.slice(0,50)+"...":y}),k=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(y,w)=>(J(),ee("div",Cb,[p("div",_b,[p("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(gb,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=S=>y.$emit("update:pageLayout",S))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",$b,[p("div",Ib,[p("div",Mb,[re(ce,{name:"sparkles"}),p("span",null,[w[31]||(w[31]=Bt("检测到本页横向超级块列宽比例：",-1)),p("b",null,we(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=S=>y.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(ce,{name:"columns"}),w[32]||(w[32]=p("span",null,"设为分栏",-1))])])])):Te("",!0),f.value?(J(),ee("div",Tb,[p("div",Eb,[p("div",Ab,[p("div",Bb,[re(ce,{name:"ratio"}),w[33]||(w[33]=p("span",null,"分栏比例",-1))]),w[34]||(w[34]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",Db,[(J(!0),ee(Je,null,Mt(d.value,S=>(J(),ee("button",{key:S.value,class:$e(["spm-chip",{active:g.value===S.value}]),onClick:D=>y.$emit("update:pageLayoutRatio",S.value)},we(S.label),11,Lb))),128))]),p("div",Pb,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=S=>y.$emit("update:pageLayoutRatio",S.target.value)),onChange:w[3]||(w[3]=S=>y.$emit("update:pageLayoutRatio",S.target.value))},null,40,Ob),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=S=>y.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(ce,{name:"sparkles"}),w[35]||(w[35]=p("span",null,"读取",-1))],8,Rb)):(J(),ee("button",Nb,[re(ce,{name:"sparkles"}),w[36]||(w[36]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[re(ce,{name:"reset"}),w[37]||(w[37]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",zb,[re(ce,{name:"ratio"}),w[38]||(w[38]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",Hb,we(e.detectedSbRatio),1)])):(J(),ee("div",Fb,[re(ce,{name:"ratio"}),w[39]||(w[39]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),re(yc,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=S=>y.$emit("update:pageTransition",S))},null,8,["model-value"]),p("div",jb,[p("div",Wb,[p("div",Ub,[p("div",Vb,[re(ce,{name:"sparkles"}),w[40]||(w[40]=p("span",null,"页面动态蒙版",-1))]),w[41]||(w[41]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",qb,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=S=>y.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=S=>c("down"))}," 从上至下 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=S=>c("right"))}," 从左至右 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=S=>l("clockwise"))}," 顺时针 ↻ ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=S=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",Gb,[p("div",Kb,[w[43]||(w[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[re(ce,{name:"help"}),w[42]||(w[42]=p("span",null,"输入规则",-1))],8,Yb)]),p("div",Zb,[(J(),ee(Je,null,Mt(n,S=>p("button",{key:S.value,class:$e(["spm-chip",{active:r.value===S.value}]),onClick:D=>y.$emit("update:pageMaskRatio",S.value)},we(S.label),11,Jb)),64))]),p("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=S=>y.$emit("update:pageMaskRatio",S.target.value)),onChange:w[12]||(w[12]=S=>y.$emit("update:pageMaskRatio",S.target.value))},null,40,Xb),p("div",Qb,we(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),p("div",e1,[p("div",t1,[w[44]||(w[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",i1,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=S=>y.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=S=>y.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",s1,[w[45]||(w[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",n1,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=S=>y.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=S=>y.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),p("div",o1,[p("div",r1,[p("div",a1,[p("div",l1,[re(ce,{name:"ratio"}),w[46]||(w[46]=p("span",null,"页面间距",-1))]),w[47]||(w[47]=p("span",{class:"spm-control-desc"},"覆盖本页内衬、内容间隙与正文行距",-1))])]),p("div",c1,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=S=>y.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[18]||(w[18]=S=>y.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:w[19]||(w[19]=S=>y.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[20]||(w[20]=S=>y.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",d1,[p("div",u1,[p("div",f1,[p("div",p1,[re(ce,{name:"image"}),w[48]||(w[48]=p("span",null,"页面图片",-1))]),w[49]||(w[49]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",h1,[(J(),ee(Je,null,Mt(k,S=>p("button",{key:S.value,class:$e(["spm-chip",{active:e.pageImage===S.value}]),onClick:D=>y.$emit("update:pageImage",S.value)},we(S.label),11,m1)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:w[21]||(w[21]=S=>y.$emit("update:pageImage",S.target.value)),onChange:w[22]||(w[22]=S=>y.$emit("update:pageImage",S.target.value))},null,40,g1)])):Te("",!0),p("div",v1,[p("div",b1,[p("div",y1,[p("div",k1,[re(ce,{name:"presenter"}),w[50]||(w[50]=p("span",null,"演讲者提词",-1))]),w[51]||(w[51]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(kt)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[23]||(w[23]=S=>y.$emit("generateNotes"))},[re(ce,{name:"sparkles"}),w[52]||(w[52]=p("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",w1,[w[55]||(w[55]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},we(b.value),9,x1),p("div",S1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[24]||(w[24]=S=>y.$emit("locateNoteBlock"))},[re(ce,{name:"search"}),w[53]||(w[53]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[25]||(w[25]=S=>y.$emit("addNoteBlock"))},[re(ce,{name:"insert-below"}),w[54]||(w[54]=p("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",C1,[w[57]||(w[57]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[26]||(w[26]=S=>y.$emit("addNoteBlock"))},[re(ce,{name:"insert-below"}),w[56]||(w[56]=p("span",null,"添加讲稿备注块",-1))])])),p("div",_1,[p("div",$1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Nt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:w[27]||(w[27]=S=>y.$emit("batchAppendNotes"))},[re(ce,{name:"insert-below"}),w[58]||(w[58]=p("span",null,"全部追加",-1))],12,I1),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Nt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:w[28]||(w[28]=S=>y.$emit("batchDeleteNotes"))},[re(ce,{name:"trash"}),w[59]||(w[59]=p("span",null,"全部删除",-1))],12,M1)])])]),p("div",T1,[w[62]||(w[62]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",E1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[29]||(w[29]=S=>y.$emit("insertDividerAfter"))},[re(ce,{name:"insert-below"}),w[60]||(w[60]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[30]||(w[30]=S=>y.$emit("deleteDivider"))},[re(ce,{name:"trash"}),w[61]||(w[61]=p("span",null,"删除此页",-1))])])])]))}}),B1=ri(A1,[["__scopeId","data-v-b11d7c22"]]),D1={class:"spm-section spm-section--block"},L1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},P1={class:"spm-control-header"},O1={class:"spm-control-title-group"},R1={class:"spm-control-title"},N1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},z1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},H1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},F1={key:0},j1={key:1},W1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},U1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},V1={class:"spm-action-grid"},q1={class:"spm-card-control"},G1={class:"spm-control-header"},K1={class:"spm-control-title-group"},Y1={class:"spm-control-title"},Z1=["aria-label"],J1=["checked"],X1={key:1,class:"spm-card-control"},Q1={class:"spm-control-header"},ey={class:"spm-control-title-group"},ty={class:"spm-control-title"},iy={class:"spm-quick-chips"},sy={key:2,class:"spm-card-control"},ny={class:"spm-control-header"},oy={class:"spm-control-title-group"},ry={class:"spm-control-title"},ay={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},ly={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},cy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},dy=["aria-label"],uy=["checked"],fy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},py={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},hy=["aria-label"],my=["checked"],gy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},vy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},by=["aria-label"],yy=["checked"],ky={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},wy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},xy=["aria-label"],Sy=["checked"],Cy={class:"spm-card-control"},_y={class:"spm-control-header"},$y={class:"spm-control-title-group"},Iy={class:"spm-control-title"},My=["aria-label"],Ty=["checked"],Ey={key:0,class:"spm-quick-chips"},Ay=["onClick"],By={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Dy={class:"spm-card-control"},Ly={class:"spm-control-header"},Py={class:"spm-control-title-group"},Oy={class:"spm-control-title"},Ry=["aria-label"],Ny=["checked"],zy={key:0,class:"spm-quick-chips"},Hy=["onClick"],Fy={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},jy={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Wy={style:{display:"flex",gap:"6px"}},Uy=["value"],Vy=["value"],qy={key:3,class:"spm-card-control"},Gy={class:"spm-control-header"},Ky={class:"spm-control-title-group"},Yy={class:"spm-control-title"},Zy={class:"spm-control-desc"},Jy={class:"spm-segmented-group"},Xy=["onClick"],Qy={key:4,class:"spm-card-control"},e0={class:"spm-control-header"},t0={class:"spm-control-title-group"},i0={class:"spm-control-title"},s0={class:"spm-quick-chips"},n0=["onClick"],o0=["value"],r0={key:5,class:"spm-card-control"},a0={class:"spm-control-header"},l0={class:"spm-control-title-group"},c0={class:"spm-control-title"},d0={class:"spm-quick-chips"},u0=["onClick"],f0=["value"],p0={class:"spm-card-control"},h0={class:"spm-action-grid"},m0=["aria-label"],g0=Rt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,s=ye(()=>{const A=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":A}),n=ye(()=>{const A=s.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),o=ye(()=>{var C,L,O,N;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const A=(L=i.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(A){const V=parseInt(A[1],10);if(V>=2&&V<=6)return Math.max(V,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(O=i.detectedSbInfo)==null?void 0:O.ratio)!=null&&N.includes(":")){const V=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(V.length>=2)return Math.min(V.length,6)}return 3}),a=ye(()=>{const A=s.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=s.value;return A==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const A=s.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let O=1;O<=C;O++)L.push({value:`col-${O}`,label:`第 ${O} 栏`});return L});function c(A){const C=i.elemSlot||"";return A?C===A||A==="col-1"&&C==="left"||A==="col-2"&&C==="center"||A==="col-3"&&C==="right"&&o.value===3||A==="col-2"&&C==="right"&&o.value===2||A==="left"&&C==="col-1"||A==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],h=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const A=JSON.parse(i.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!h.value),g=ye(()=>{var A;return((A=h.value)==null?void 0:A.preset)||"slide-up"}),m=ye(()=>{var A;return((A=h.value)==null?void 0:A.duration)||0}),b=ye(()=>{var A;return((A=h.value)==null?void 0:A.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function y(A){D(A,m.value,b.value)}function w(A){D(g.value,A,b.value)}function S(A){D(g.value,m.value,A)}function D(A,C,L){if(!A||A==="none"){u("update:elemMotion","");return}if(!C&&!L){u("update:elemMotion",A);return}const O={preset:A};C>0&&(O.duration=C),L>0&&(O.delay=L),u("update:elemMotion",JSON.stringify(O))}return(A,C)=>{var L,O,N,V,_,j;return J(),ee("div",D1,[C[62]||(C[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(J(),ee("div",L1,[p("div",P1,[p("div",O1,[p("div",R1,[re(ce,{name:"ratio"}),C[24]||(C[24]=p("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",N1,[p("div",z1,[p("div",H1,[re(ce,{name:"ratio"}),(O=e.detectedSbInfo)!=null&&O.isCustomWidth?(J(),ee("span",F1,"已识别自定义列宽比例")):(J(),ee("span",j1,"识别到 "+we(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),p("code",W1,we(((V=e.detectedSbInfo)==null?void 0:V.ratio)||"1:1"),1)]),p("div",U1,we((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",V1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=x=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(ce,{name:"sparkles"}),C[26]||(C[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=x=>{var K;return A.$emit("applySuperBlockRatio",((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1")})},[re(ce,{name:"check"}),p("span",null,"应用比例 ("+we(((j=e.detectedSbInfo)==null?void 0:j.ratio)||"1:1")+")",1)])])])):Te("",!0),p("div",q1,[p("div",G1,[p("div",K1,[p("div",Y1,[re(ce,{name:"presenter"}),C[27]||(C[27]=p("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=x=>A.$emit("toggleNote"))},null,40,J1),C[29]||(C[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,Z1)])]),e.isImage||e.imageRole?(J(),ee("div",X1,[p("div",Q1,[p("div",ey,[p("div",ty,[re(ce,{name:"image"}),C[30]||(C[30]=p("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",iy,[p("button",{class:$e(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=x=>A.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=x=>A.$emit("update:imageRole","background"))},[re(ce,{name:"image"}),C[32]||(C[32]=p("span",null,"背景图",-1))],2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=x=>A.$emit("update:imageRole","image-left"))},[re(ce,{name:"image-left"}),C[33]||(C[33]=p("span",null,"图左",-1))],2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=x=>A.$emit("update:imageRole","image-right"))},[re(ce,{name:"image-right"}),C[34]||(C[34]=p("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",sy,[p("div",ny,[p("div",oy,[p("div",ry,[re(ce,{name:"video"}),C[35]||(C[35]=p("span",null,"视频播放设置",-1))]),C[36]||(C[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",ay,[p("div",ly,[p("span",cy,[re(ce,{name:"sliders"}),C[37]||(C[37]=Bt(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=x=>A.$emit("toggleVideoControls"))},null,40,uy),C[38]||(C[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,dy)]),p("div",fy,[p("span",py,[re(ce,{name:"video"}),C[39]||(C[39]=Bt(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=x=>A.$emit("toggleVideoAutoplay"))},null,40,my),C[40]||(C[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,hy)]),p("div",gy,[p("span",vy,[re(ce,{name:"repeat"}),C[41]||(C[41]=Bt(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=x=>A.$emit("toggleVideoLoop"))},null,40,yy),C[42]||(C[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,by)]),p("div",ky,[p("span",wy,[re(ce,{name:"volume-x"}),C[43]||(C[43]=Bt(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=x=>A.$emit("toggleVideoMuted"))},null,40,Sy),C[44]||(C[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,xy)])])])):Te("",!0),p("div",Cy,[p("div",_y,[p("div",$y,[p("div",Iy,[re(ce,{name:"step"}),C[45]||(C[45]=p("span",null,"逐步呈现",-1))]),C[46]||(C[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=x=>A.$emit("toggleElemClick"))},null,40,Ty),C[47]||(C[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,My)]),e.elemClick?(J(),ee("div",Ey,[(J(),ee(Je,null,Mt(["+1","1","2","hide"],x=>p("button",{key:x,class:$e(["spm-chip",{active:e.elemClick===x}]),onClick:K=>A.$emit("update:elemClick",x)},we(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,Ay)),64))])):e.parentElemClick?(J(),ee("div",By,[re(ce,{name:"check"}),C[48]||(C[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),p("div",Dy,[p("div",Ly,[p("div",Py,[p("div",Oy,[re(ce,{name:"motion"}),C[49]||(C[49]=p("span",null,"入场微动效",-1))]),C[50]||(C[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[p("input",{type:"checkbox",checked:d.value,onChange:k},null,40,Ny),C[51]||(C[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ry)]),d.value?(J(),ee("div",zy,[(J(),ee(Je,null,Mt(f,x=>p("button",{key:x.value,class:$e(["spm-chip",{active:g.value===x.value}]),onClick:K=>y(x.value)},we(x.label),11,Hy)),64))])):Te("",!0),d.value?(J(),ee("div",Fy,[p("div",jy,[p("span",null,"时长: "+we(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+we(b.value?b.value+"ms":"0ms"),1)]),p("div",Wy,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=x=>w(Number(x.target.value)))},[...C[52]||(C[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,Uy),p("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:C[13]||(C[13]=x=>S(Number(x.target.value)))},[...C[53]||(C[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,Vy)])])):Te("",!0)]),n.value||e.elemSlot?(J(),ee("div",qy,[p("div",Gy,[p("div",Ky,[p("div",Yy,[re(ce,{name:"columns"}),p("span",null,we(a.value),1)]),p("span",Zy,we(r.value),1)])]),p("div",Jy,[(J(!0),ee(Je,null,Mt(l.value,x=>(J(),ee("button",{key:x.value,class:$e(["spm-segmented-item",{active:c(x.value)}]),onClick:K=>A.$emit("update:elemSlot",x.value)},we(x.label),11,Xy))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",Qy,[p("div",e0,[p("div",t0,[p("div",i0,[re(ce,{name:"code"}),C[54]||(C[54]=p("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",s0,[(J(),ee(Je,null,Mt(["1-3","all","1|2|3","2-5"],x=>p("button",{key:x,class:$e(["spm-chip",{active:e.elemShikiLines===x}]),onClick:K=>A.$emit("update:elemShikiLines",x)},we(x),11,n0)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=x=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=x=>A.$emit("update:elemShikiLines",x.target.value)),onChange:C[16]||(C[16]=x=>A.$emit("update:elemShikiLines",x.target.value))},null,40,o0)])):Te("",!0),e.isCodeBlock?(J(),ee("div",r0,[p("div",a0,[p("div",l0,[p("div",c0,[re(ce,{name:"code"}),C[56]||(C[56]=p("span",null,"代码块限高",-1))]),C[57]||(C[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",d0,[(J(),ee(Je,null,Mt(["240px","320px","400px","50%"],x=>p("button",{key:x,class:$e(["spm-chip",{active:e.elemMaxHeight===x||x==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:K=>A.$emit("update:elemMaxHeight",x)},we(x),11,u0)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=x=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:C[18]||(C[18]=x=>A.$emit("update:elemMaxHeight",x.target.value)),onChange:C[19]||(C[19]=x=>A.$emit("update:elemMaxHeight",x.target.value))},null,40,f0)])):Te("",!0),p("div",p0,[C[61]||(C[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",h0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=x=>A.$emit("insertDividerBefore"))},[re(ce,{name:"insert-above"}),C[58]||(C[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=x=>A.$emit("insertDividerAfter"))},[re(ce,{name:"insert-below"}),C[59]||(C[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=x=>A.$emit("setTwoColsContrast"))},[re(ce,{name:"columns"}),p("span",null,we(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,m0),e.hasBlockAttrs?(J(),ee("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=x=>A.$emit("clearBlockAttrs"))},[re(ce,{name:"broom"}),C[60]||(C[60]=p("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),v0={class:"spm-section spm-section--doc"},b0={class:"spm-card-control"},y0={class:"spm-control-header"},k0={class:"spm-control-title-group"},w0={class:"spm-control-title"},x0={class:"spm-segmented-group"},S0=["aria-label","onClick"],C0={class:"spm-card-control"},_0={class:"spm-control-header"},$0={class:"spm-control-title-group"},I0={class:"spm-control-title"},M0={class:"spm-bg-swatch-grid"},T0=["aria-label","onClick"],E0={key:0,class:"spm-bg-swatch-check"},A0={class:"spm-bg-swatch-label"},B0={class:"spm-bg-input-row"},D0=["value"],L0={class:"spm-card-control"},P0={class:"spm-control-header"},O0={class:"spm-control-title-group"},R0={class:"spm-control-title"},N0={class:"spm-segmented-group"},z0={class:"spm-card-control"},H0={class:"spm-control-header"},F0={class:"spm-control-title-group"},j0={class:"spm-control-title"},W0={class:"spm-segmented-group"},U0={class:"spm-card-control"},V0={class:"spm-control-header"},q0={class:"spm-control-title-group"},G0={class:"spm-control-title"},K0={class:"spm-card-control"},Y0={class:"spm-control-header"},Z0={class:"spm-control-title-group"},J0={class:"spm-control-title"},X0=["aria-label"],Q0=["checked"],ek={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},tk=["value"],ik={class:"spm-card-control"},sk={class:"spm-control-header"},nk={class:"spm-control-title-group"},ok={class:"spm-control-title"},rk=["aria-label"],ak=["checked"],lk={class:"spm-card-control"},ck={class:"spm-control-header"},dk={class:"spm-control-title-group"},uk={class:"spm-control-title"},fk={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},pk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},hk=["aria-label"],mk=["checked"],gk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},vk=["aria-label"],bk=["checked"],yk={class:"spm-card-control"},kk={class:"spm-action-grid"},wk=["disabled"],xk=["disabled"],Sk=["disabled","aria-label"],Ck=Rt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","clearDividers","exportHtml","exportPdf","exportImages"],setup(e){const t=Ut("plugin"),i=Zt,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(h){ui({enableWebServeJump:h}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:h})}async function o(h){var d;ui({normalizeHeadingSizes:h}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:h}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(h){var d;ui({showUnorderedListMarkers:h}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:h}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(h){var d;ui({showOrderedListMarkers:h}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:h}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(h){ui({webServeUrl:h})}function c(h){ui({webServeUrl:h}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:h})}const u=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function f(h){const d=(h||"").trim();return d?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(d)?{backgroundImage:`url("${d.startsWith("assets/")?`/${d}`:d.startsWith("./assets/")?d.slice(1):d}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:d}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}return(h,d)=>(J(),ee("div",v0,[d[59]||(d[59]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",b0,[p("div",y0,[p("div",k0,[p("div",w0,[re(ce,{name:"palette"}),d[27]||(d[27]=p("span",null,"幻灯片主题",-1))]),d[28]||(d[28]=p("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),p("div",x0,[(J(),ee(Je,null,Mt(s,g=>p("button",{key:g.value,class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===g.value}]),"aria-label":g.desc,onClick:m=>h.$emit("update:docTheme",g.value)},we(g.label),11,S0)),64))])]),p("div",C0,[p("div",_0,[p("div",$0,[p("div",I0,[re(ce,{name:"palette"}),d[29]||(d[29]=p("span",null,"演示背景",-1))]),d[30]||(d[30]=p("span",{class:"spm-control-desc"},"全篇幻灯片统一底色、微渐变或壁纸",-1))])]),p("div",M0,[(J(),ee(Je,null,Mt(u,g=>p("button",{key:g.value||"__default__",type:"button",class:$e(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===g.value,"is-default":!g.value}]),"aria-label":g.desc,onClick:m=>h.$emit("update:docBackground",g.value)},[p("span",{class:"spm-bg-swatch-preview",style:Nt(f(g.value))},[p("span",{class:$e(["spm-bg-swatch-aa","is-"+g.mode])},"Aa",2),(e.docBackground||"")===g.value?(J(),ee("span",E0,"✓")):Te("",!0)],4),p("span",A0,we(g.label),1)],10,T0)),64))]),p("div",B0,[p("span",{class:"spm-bg-input-preview",style:Nt(f(e.docBackground||"")),"aria-hidden":"true"},null,4),p("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:d[0]||(d[0]=g=>h.$emit("update:docBackground",g.target.value)),onChange:d[1]||(d[1]=g=>h.$emit("update:docBackground",g.target.value))},null,40,D0),e.docBackground?(J(),ee("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:d[2]||(d[2]=g=>h.$emit("update:docBackground",""))}," ✕ ")):Te("",!0)])]),p("div",L0,[p("div",P0,[p("div",O0,[p("div",R0,[re(ce,{name:"ratio"}),d[31]||(d[31]=p("span",null,"画幅比例",-1))]),d[32]||(d[32]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",N0,[p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[3]||(d[3]=g=>h.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[4]||(d[4]=g=>h.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[5]||(d[5]=g=>h.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",z0,[p("div",H0,[p("div",F0,[p("div",j0,[re(ce,{name:"ratio"}),d[33]||(d[33]=p("span",null,"间距风格",-1))]),d[34]||(d[34]=p("span",{class:"spm-control-desc"},"内衬、内容间隙与正文行距预设",-1))])]),p("div",W0,[p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:d[6]||(d[6]=g=>h.$emit("update:docSpacing","compact"))}," 紧凑 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:d[7]||(d[7]=g=>h.$emit("update:docSpacing","normal"))}," 标准 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:d[8]||(d[8]=g=>h.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),p("div",U0,[p("div",V0,[p("div",q0,[p("div",G0,[re(ce,{name:"transition"}),d[35]||(d[35]=p("span",null,"全局默认转场",-1))]),d[36]||(d[36]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(yc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[9]||(d[9]=g=>h.$emit("update:docDefaultTransition",g))},null,8,["model-value"])]),p("div",K0,[p("div",Y0,[p("div",Z0,[p("div",J0,[re(ce,{name:"external-link"}),d[37]||(d[37]=p("span",null,"本地网络伺服预览",-1))]),d[38]||(d[38]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:d[10]||(d[10]=g=>n(g.target.checked))},null,40,Q0),d[39]||(d[39]=p("span",{class:"spm-switch-slider"},null,-1))],8,X0)]),he(i).enableWebServeJump?(J(),ee("div",ek,[p("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[11]||(d[11]=ei(()=>{},["stop"])),onKeyup:d[12]||(d[12]=ei(()=>{},["stop"])),onInput:d[13]||(d[13]=g=>l(g.target.value)),onChange:d[14]||(d[14]=g=>c(g.target.value))},null,40,tk),d[40]||(d[40]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),p("div",ik,[p("div",sk,[p("div",nk,[p("div",ok,[re(ce,{name:"type"}),d[41]||(d[41]=p("span",null,"固定特定标题大小",-1))]),d[42]||(d[42]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:d[15]||(d[15]=g=>o(g.target.checked))},null,40,ak),d[43]||(d[43]=p("span",{class:"spm-switch-slider"},null,-1))],8,rk)])]),p("div",lk,[p("div",ck,[p("div",dk,[p("div",uk,[re(ce,{name:"list"}),d[44]||(d[44]=p("span",null,"列表前缀标记",-1))]),d[45]||(d[45]=p("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),p("div",fk,[p("div",pk,[d[47]||(d[47]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[p("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:d[16]||(d[16]=g=>a(g.target.checked))},null,40,mk),d[46]||(d[46]=p("span",{class:"spm-switch-slider"},null,-1))],8,hk)]),p("div",gk,[d[49]||(d[49]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[p("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:d[17]||(d[17]=g=>r(g.target.checked))},null,40,bk),d[48]||(d[48]=p("span",{class:"spm-switch-slider"},null,-1))],8,vk)])])]),p("div",yk,[d[58]||(d[58]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",kk,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[18]||(d[18]=g=>h.$emit("openBottomPreview"))},[re(ce,{name:"split-preview"}),d[50]||(d[50]=p("span",null,"分屏预览",-1))]),he(kt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[19]||(d[19]=g=>h.$emit("openPresenter"))},[re(ce,{name:"presenter"}),d[51]||(d[51]=p("span",null,"演讲者视图",-1))])):Te("",!0),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[20]||(d[20]=g=>h.$emit("identifyNotes"))},[re(ce,{name:"notes"}),d[52]||(d[52]=p("span",null,"识别讲稿块",-1))],8,wk),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[21]||(d[21]=g=>h.$emit("autoAnimate"))},[re(ce,{name:"step"}),d[53]||(d[53]=p("span",null,"智能动效",-1))],8,xk),he(kt)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:d[22]||(d[22]=g=>h.$emit("aiAutoSplit"))},[re(ce,{name:"sparkles"}),d[54]||(d[54]=p("span",null,"智能分页",-1))])):Te("",!0),he(kt)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线",onClick:d[23]||(d[23]=g=>h.$emit("clearDividers"))},[re(ce,{name:"trash"}),d[55]||(d[55]=p("span",null,"清除分页",-1))])):Te("",!0),he(kt)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[24]||(d[24]=g=>h.$emit("exportHtml"))},[re(ce,{name:"export-html"}),d[56]||(d[56]=p("span",null,"导出 HTML",-1))])):Te("",!0),he(kt)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[25]||(d[25]=g=>h.$emit("exportPdf"))},[re(ce,{name:"export-pdf"}),d[57]||(d[57]=p("span",null,"导出 PDF",-1))])):Te("",!0),he(kt)("exportImage")?(J(),ee("button",{key:5,class:$e(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[26]||(d[26]=g=>h.$emit("exportImages"))},[re(ce,{name:"export-image"}),p("span",null,we(e.isExportingImages?"正在导出...":"导出图片"),1)],10,Sk)):Te("",!0)])])]))}}),_k=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,$k=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Ik(e){const t=await fc.loadAsync(e),i={},s=[];let n="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||$k.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=u)}else if(_k.test(c)){const u=await l.file.async("uint8array"),f=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([u]):void 0;s.push({zipPath:c,fileName:f,data:u,blob:h})}}return{entryMarkdown:n,entryMarkdownPath:o,virtualFiles:i,assets:s}}function Mk(e,t){if(Object.keys(t).length===0)return e;function i(n){const o=n.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function s(n){let o=n;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const n of e.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const o=n.pageAttrs["custom-slides-background"],a=i(o);a&&(n.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=s(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],o=i(n);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function kc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function Tk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const s=i[1].trim(),n=s.indexOf("#"),o=n!==-1?s.slice(0,n):s,a=n!==-1?s.slice(n+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const d=r.split("/").pop();for(const[g,m]of Object.entries(l))if(g.endsWith(`/${r}`)||d&&g.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const g=require("path");d.push(g.resolve(t.baseDir,r)),d.push(g.resolve(t.baseDir,o))}catch{}try{const g=require("path");d.push(g.resolve(process.cwd(),r))}catch{}for(const g of d){const m=kc(g);if(m!==null){c=m;break}}}if(!c){const d=ic||{};if(c=d[o]||d[r]||d[`snippets/${r}`],!c){const g=r.split("/").pop();for(const[m,b]of Object.entries(d))if(m.endsWith(`/${r}`)||g&&m.endsWith(`/${g}`)){c=b;break}}}if(!c)return null;let u=c;if(a){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),g=c.match(d);if(g){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+g[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function Ek(e){let t=!1,i=!1;for(let s=0;s<e.length;s++){const n=e[s];if(n==="'"&&!i)t=!t;else if(n==='"'&&!t)i=!i;else if(n==="#"&&!t&&!i)return e.slice(0,s).trim()}return e.trim()}function yn(e){const t={},i=e.split(/\r?\n/);let s=0;for(;s<i.length;){const n=i[s],o=n.trim();if(!o||o.startsWith("#")){s++;continue}const a=n.indexOf(":");if(a>0){const r=n.slice(0,a).trim();let l=n.slice(a+1).trim();if(l==="|"||l===">"){s++;const c=[];let u=-1;for(;s<i.length;){const f=i[s];if(!f.trim()){c.push(""),s++;continue}const d=f.match(/^(\s+)/),g=d?d[1].length:0;if(u===-1&&(u=g),g<u)break;c.push(f.slice(u)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=Ek(l),!l){let c=s+1;const u=[];let f=-1;for(;c<i.length;){const h=i[c],d=h.trim();if(!d||d.startsWith("#")){f!==-1&&u.push(""),c++;continue}const g=h.match(/^(\s+)/),m=g?g[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(h.slice(f)),c++}if(u.length>0){t[r]=yn(u.join(`
`)),s=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}s++}return t}const Ak=/^\s*```ya?ml([\s\S]*?)```/;function $a(e){let t={},i=e.trim();const s=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const o=yn(s[1]);if(Object.keys(o).length>0||!s[1].trim())return t=o,i=i.slice(s[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const n=i.match(Ak);if(n)t=yn(n[1]),i=i.slice(n[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=yn(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function Bk(e){const t=e.split(/\r?\n/),i=[];let s=0,n=!1;function o(a){if(s>=a)return;const r=t.slice(s,a).join(`
`).trim();r&&i.push(r),s=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(n){l.includes("-->")&&(n=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(n=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let u=!1,f=-1;const h=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&h.length>0){for(let d=a+1;d<t.length;d++){const g=t[d].trimEnd();if(g.startsWith("```"))break;if(g==="---"){f=d;break}}f!==-1&&f-a<=60&&t.slice(a+1,f).some(m=>{const b=m.trim();return b.length>0&&!b.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(b)})&&(u=!0)}u&&f!==-1&&(s=a,a=f)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let f=a+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(a=f)}}return s<t.length&&o(t.length),i}function kn(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=Bk(u),h={};let d="",g="",m=0;if(f.length>0){const N=f[0],V=$a(N),_=Object.keys(V.frontmatter).length>0,j=V.content.length>0;_&&!j&&f.length>1?(m=1,b(V.frontmatter)):_&&b(V.frontmatter)}function b(N){d=N.title||"",N.theme&&(h[js]=String(N.theme)),N.aspectRatio&&(h[Ws]=String(N.aspectRatio)),N.highlighter&&(h[Oa]=String(N.highlighter)),N.transition&&(h[Us]=String(N.transition)),N.colorSchema&&(h[Ra]=String(N.colorSchema)),N.layout&&(h[ke]=String(N.layout)),N.background&&(h[ct]=String(N.background)),N.image&&(h[jt]=String(N.image)),N.class&&(h[ns]=String(N.class));for(const[V,_]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(V)||(h[`custom-slides-${V}`]=typeof _=="object"?JSON.stringify(_):String(_))}const k=[];let y=0,w=0,S=0,D=0;const A=new Set,C={};let L=1;for(let N=m;N<f.length;N++){const V=f[N],{frontmatter:_,content:j}=$a(V),x=V.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),K=_.src||(x?x[1]:void 0);if(K){const fe=String(K).trim().replace(/^['"]|['"]$/g,"");let X=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!X){const E=fe.replace(/^\.\//,""),H=[];if(t.baseDir)try{const v=require("path");H.push(v.resolve(t.baseDir,E)),H.push(v.resolve(t.baseDir,fe))}catch{}try{const v=require("path");H.push(v.resolve(process.cwd(),E)),H.push(v.resolve(process.cwd(),fe))}catch{}for(const v of H){const W=kc(v);if(W!==null){X=W;break}}}const ue={};_.layout&&(ue[ke]=String(_.layout)),_.transition&&(ue[wt]=String(_.transition)),_.background&&(ue[ct]=String(_.background)),_.image&&(ue[jt]=String(_.image)),_.class&&(ue[ns]=String(_.class));for(const[E,H]of Object.entries(_))["src","layout","transition","background","image","class"].includes(E)||(ue[`custom-slides-${E}`]=typeof H=="object"?JSON.stringify(H):String(H));if(X){const E=kn(X,{...t,virtualFiles:c});for(const H of E.slides){H.pageIndex=L++,H.pageAttrs={...ue,...H.pageAttrs},k.push(H);const v=H.pageAttrs[ke]||"default";C[v]=(C[v]||0)+1}continue}else{k.push({pageIndex:L++,pageAttrs:{...ue,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=ue[ke]||"default";C[E]=(C[E]||0)+1;continue}}const R={};_.layout&&(R[ke]=String(_.layout)),_.transition&&(R[wt]=String(_.transition)),_.background&&(R[ct]=String(_.background)),_.image&&(R[jt]=String(_.image)),_.class&&(R[ns]=String(_.class)),_.mask&&(R[os]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(R[Gi]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(R[rs]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(R[as]=String(_.maskInitial||_["mask-initial"]));for(const[fe,X]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(R[`custom-slides-${fe}`]=typeof X=="object"?JSON.stringify(X):String(X));let $=j;const T=[];let P=$.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});let ne="";const Y=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(Y.length>0){const fe=Y[Y.length-1],X=P.slice(fe.index+fe[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=fe[1].trim();E.startsWith("TODO:")||(ne=E,y++),i&&(P=P.slice(0,fe.index).trimEnd()+P.slice(fe.index+fe[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<T.length;fe++)P=P.replace(`__CODE_TOKEN_NOTE_${fe}__`,()=>T[fe]);if($=P,ne){for(let ue=0;ue<T.length;ue++)ne=ne.replace(`__CODE_TOKEN_NOTE_${ue}__`,()=>T[ue]);const X=`> [!NOTE] 💡 演讲备注
${ne.split(/\r?\n/).map(ue=>`> ${ue}`).join(`
`)}
{: custom-slides-note="true"}`;$=$?`${$}

${X}`:X}let q=!1;if(/<style\b/i.test($)){q=!0;const fe=$.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const X of fe){const ue=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();g=g?`${g}

${ue}`:ue}a&&($=$.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const le=$.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);le&&(w+=le.length);const se=$.match(/```\w+\s+\{[^}]+\}/g);se&&(S+=se.length);const oe=$.match(/::\w+::|<template\s+#[^>]+>/g);if(oe&&(D+=oe.length),$=$.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>Tk(fe,{...t,virtualFiles:c})||fe),s&&($=$.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&($=$.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),$=$.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&($=$.replace(/^::\w+::\s*$/gm,"")),r&&($=vp($)),l){let fe=$.trim(),X="";const ue=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ue!==-1&&(X=fe.slice(ue),fe=fe.slice(0,ue).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const E=String(_.image).trim(),H=_.layout==="image-left"?"image-left":"image-right",v=`![配图](${E})
{: custom-slides-layout="${H}" }`;_.layout==="image-left"?fe=`{{{col

${v}

${fe}

}}}`:fe=`{{{col

${fe}

${v}

}}}`}if(_.background){const H=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${H}

${fe}`:H}$=X?`${fe}

${X}`:fe}const _e=Dk($);R[ct]&&_e.push(R[ct]),R[jt]&&_e.push(R[jt]);for(const fe of _e)A.add(fe);const Ie=/<[A-Z][a-zA-Z0-9]+/.test($),xe=R[ke]||(L===1?h[ke]||"cover":"default");C[xe]=(C[xe]||0)+1,k.push({pageIndex:L++,pageAttrs:R,notes:ne,rawMarkdown:$,hasVueComponent:Ie,hasStyleTag:q,assetReferences:_e})}if(!d&&k.length>0){const N=k[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(d=N[1].trim())}g&&(h["custom-slides-custom-css"]=g);let O=k.map(N=>`---

${N.rawMarkdown}`).join(`

`);return O.trimStart().startsWith("---")||(O=`---

${O.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:h,slides:k,totalSlides:k.length,stats:{totalNotes:y,totalVClicks:w,totalShikiHighlights:S,totalSlots:D,discoveredAssets:Array.from(A),layoutDistribution:C},flattenedMarkdown:O,customCss:g}}function Dk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=i.exec(e))!==null;){const o=s[1].split(/\s+/)[0].trim();o&&t.push(o)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(e))!==null;){const o=s[1].trim();o&&t.push(o)}return t}function wc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),s=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||s==="---"||s==="***"}function Lk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Pk(e,t,i=He){const s=e.filter(wc);let n=0;if(s.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=s[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),n++)}else for(let o=1;o<t.length;o++){const a=t[o],r=s[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),n++)}return n}async function Ok(e,t=He){let i=!1,s=0;for(const n of e){if(wc(n)){i=!1;continue}const o=(n.markdown||n.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&n.id&&(await t(n.id,{[Me]:"right"}).catch(()=>{}),s++)}return s}async function Rk(e,t,i=Ba){const s={};if(!t||t.length===0)return s;const n=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});n.push(a)}try{const o=await i("/data/assets",n);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))s[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(s).length>0&&Mk(e,s),s}async function Nk(e){var y;const{presentation:t,notebookId:i,docTitle:s,extractedAssets:n=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||Ba,u=l.createDocFn||Id,f=l.setAttrsFn||He,h=l.getChildBlocksFn||bs,d=l.openTabFn||ae.openTab,g=l.showMessageFn||ae.showMessage;o&&n.length>0&&await Rk(t,n,c);const m=Lk(s),b=`/${m}`,k=await u(i,b,t.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const w=((y=t.slides[0])==null?void 0:y.pageAttrs)||{};await f(k,{...w,...t.docRootAttrs});const S=await h(k).catch(()=>[]);Array.isArray(S)&&S.length>0&&(await Pk(S,t.slides,f),await Ok(S,f))}catch(w){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",w),g(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${w.message||String(w)}`,6e3)}return g(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function zk(e){const t=ge("file"),i=ge(!1),s=ge(!1),n=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),u=ge([]),f=ge(null),h=ge(""),d=ge([]),g=ge(""),m=ge(!0),b=ge(!0),k=ge(!0),y=ge(!0),w=ye(()=>{const $=l.value;if($===0)return"0 B";const T=1024,P=["B","KB","MB","GB"],ne=Math.floor(Math.log($)/Math.log(T));return`${($/T**ne).toFixed(1)} ${P[ne]}`}),S=ye(()=>{var $;return(($=f.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),D=ye(()=>{var $;return u.value.length>0?u.value.length:(($=f.value)==null?void 0:$.stats.discoveredAssets.length)||0}),A=ye(()=>{var T;const $=((T=f.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([P,ne])=>({name:P,count:ne}))});async function C($=$d){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(d.value=T.notebooks.filter(P=>!P.closed),d.value.length>0&&!g.value&&(g.value=d.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function L(){var $;($=o.value)==null||$.click()}function O(){a.value=null,r.value="",l.value=0,f.value=null,u.value=[],n.value=""}let N=0;async function V($){const T=++N;n.value="",a.value=$,r.value=$.name,l.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const ne=await $.arrayBuffer();if(T!==N)return;const Y=await Ik(ne);if(T!==N)return;if(!Y.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=Y.assets;const q=kn(Y.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:Y.virtualFiles});if(T!==N)return;f.value=q,h.value=q.docTitle||$.name.replace(/\.zip$/i,"")}else{const ne=await $.text();if(T!==N)return;u.value=[];const Y=$.path||"",q=Y?Y.replace(/[\\/][^\\/]+$/,""):"",le=kn(ne,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:q||void 0});if(T!==N)return;f.value=le,h.value=le.docTitle||$.name.replace(/\.md$/i,"")}}catch(P){if(T!==N)return;console.error("解析文件失败:",P),n.value=`解析文件失败: ${P.message||String(P)}`}}function _(){if(n.value="",!c.value.trim()){f.value=null;return}try{const $=kn(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=$,h.value=$.docTitle||"Slidev 演示文稿"}catch($){n.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function j(){a.value?await V(a.value):c.value&&_()}async function x($){const T=$.target;T.files&&T.files[0]&&await V(T.files[0])}async function K($){var T;i.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await V($.dataTransfer.files[0])}async function R($=e){if(f.value){if(!g.value&&d.value.length>0&&(g.value=d.value[0].id),!g.value){n.value="请先选择目标笔记本";return}s.value=!0,n.value="";try{return await Nk({presentation:f.value,notebookId:g.value,docTitle:h.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:y.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),n.value=`导入执行失败: ${T.message||String(T)}`}finally{s.value=!1}}}return{inputMode:t,isDragging:i,isImporting:s,errorMessage:n,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:h,notebooks:d,selectedNotebookId:g,optCleanHtml:m,optStripNotes:b,optUploadAssets:k,optAutoPreview:y,formattedFileSize:w,currentTheme:S,extractedAssetsCount:D,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:O,processFile:V,onFileSelected:x,onFileDrop:K,onTextChange:_,reprocessCurrentInput:j,handleConfirmImport:R}}const Hk={class:"spm-import-dialog"},Fk={class:"spm-tabs-header"},jk={class:"spm-dialog-body"},Wk={key:0,class:"spm-file-section"},Uk={key:0,class:"spm-dropzone-prompt"},Vk={class:"spm-dropzone-icon"},qk={key:1,class:"spm-dropzone-active"},Gk={class:"spm-file-badge"},Kk={class:"spm-file-size"},Yk={key:1,class:"spm-text-section"},Zk={key:2,class:"spm-error-banner"},Jk={key:3,class:"spm-preview-card"},Xk={class:"spm-preview-card__header"},Qk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},ew={class:"spm-config-grid"},tw={class:"spm-form-item"},iw={class:"spm-form-item"},sw=["value"],nw={class:"spm-stats-grid"},ow={class:"spm-stat-box"},rw={class:"spm-stat-value"},aw={class:"spm-stat-box"},lw={class:"spm-stat-value"},cw={class:"spm-stat-box"},dw={class:"spm-stat-value"},uw={class:"spm-stat-box"},fw={class:"spm-stat-value"},pw={key:0,class:"spm-chips-row"},hw={class:"spm-options-group"},mw={class:"spm-checkbox-label"},gw={class:"spm-checkbox-label"},vw={class:"spm-checkbox-label"},bw={class:"spm-checkbox-label"},yw={class:"spm-dialog-footer"},kw=["disabled"],ww=["disabled"],xw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Sw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Cw=Rt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,s=Ut("plugin"),{inputMode:n,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:h,customDocTitle:d,notebooks:g,selectedNotebookId:m,optCleanHtml:b,optStripNotes:k,optUploadAssets:y,optAutoPreview:w,formattedFileSize:S,currentTheme:D,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:O,onFileSelected:N,onFileDrop:V,onTextChange:_,reprocessCurrentInput:j,handleConfirmImport:x}=zk(s);ws(async()=>{await C()});async function K(){const $=await x();$&&(i("success",{docId:$}),i("close"))}function R(){i("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:ei(R,["self"])},[p("div",Hk,[p("div",{class:"spm-dialog-header"},[T[18]||(T[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlides"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:R},"✕")]),p("div",Fk,[p("button",{class:$e(["spm-tab-btn",{active:he(n)==="file"}]),onClick:T[0]||(T[0]=P=>n.value="file")},[re(ce,{name:"package"}),T[19]||(T[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:$e(["spm-tab-btn",{active:he(n)==="text"}]),onClick:T[1]||(T[1]=P=>n.value="text")},[re(ce,{name:"notes"}),T[20]||(T[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",jk,[he(n)==="file"?(J(),ee("div",Wk,[p("div",{class:$e(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=ei(P=>o.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=ei(P=>o.value=!1,["prevent"])),onDrop:T[6]||(T[6]=ei((...P)=>he(V)&&he(V)(...P),["prevent"])),onClick:T[7]||(T[7]=(...P)=>he(L)&&he(L)(...P))},[p("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...P)=>he(N)&&he(N)(...P))},null,544),he(c)?(J(),ee("div",qk,[p("span",Gk,[re(ce,{name:"notes"}),Bt(" "+we(he(c)),1)]),p("span",Kk,"("+we(he(S))+")",1),p("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=ei((...P)=>he(O)&&he(O)(...P),["stop"]))},"更换文件")])):(J(),ee("div",Uk,[p("span",Vk,[re(ce,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=p("p",{class:"spm-dropzone-hint"},[Bt(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),Bt("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(J(),ee("div",Yk,[Ft(p("textarea",{"onUpdate:modelValue":T[8]||(T[8]=P=>st(u)?u.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...P)=>he(_)&&he(_)(...P))},null,544),[[zo,he(u)]])])),he(r)?(J(),ee("div",Zk," ⚠️ "+we(he(r)),1)):Te("",!0),he(h)?(J(),ee("div",Jk,[p("div",Xk,[p("span",Qk,[re(ce,{name:"sparkles"}),T[23]||(T[23]=Bt(" 演示解析摘要",-1))]),T[24]||(T[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",ew,[p("div",tw,[T[25]||(T[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ft(p("input",{"onUpdate:modelValue":T[10]||(T[10]=P=>st(d)?d.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[zo,he(d)]])]),p("div",iw,[T[26]||(T[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ft(p("select",{"onUpdate:modelValue":T[11]||(T[11]=P=>st(m)?m.value=P:null),class:"spm-select"},[(J(!0),ee(Je,null,Mt(he(g),P=>(J(),ee("option",{key:P.id,value:P.id},we(P.name),9,sw))),128))],512),[[Xf,he(m)]])])]),p("div",nw,[p("div",ow,[p("span",rw,we(he(h).totalSlides),1),T[27]||(T[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",aw,[p("span",lw,we(he(D)),1),T[28]||(T[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",cw,[p("span",dw,we(he(h).stats.totalNotes),1),T[29]||(T[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",uw,[p("span",fw,we(he(f)),1),T[30]||(T[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(A).length>0?(J(),ee("div",pw,[T[31]||(T[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Je,null,Mt(he(A),P=>(J(),ee("span",{key:P.name,class:"spm-chip-badge"},we(P.name)+": "+we(P.count),1))),128))])):Te("",!0),p("div",hw,[p("label",mw,[Ft(p("input",{"onUpdate:modelValue":T[12]||(T[12]=P=>st(b)?b.value=P:null),type:"checkbox",onChange:T[13]||(T[13]=(...P)=>he(j)&&he(j)(...P))},null,544),[[dn,he(b)]]),T[32]||(T[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",gw,[Ft(p("input",{"onUpdate:modelValue":T[14]||(T[14]=P=>st(k)?k.value=P:null),type:"checkbox",onChange:T[15]||(T[15]=(...P)=>he(j)&&he(j)(...P))},null,544),[[dn,he(k)]]),T[33]||(T[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",vw,[Ft(p("input",{"onUpdate:modelValue":T[16]||(T[16]=P=>st(y)?y.value=P:null),type:"checkbox"},null,512),[[dn,he(y)]]),T[34]||(T[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",bw,[Ft(p("input",{"onUpdate:modelValue":T[17]||(T[17]=P=>st(w)?w.value=P:null),type:"checkbox"},null,512),[[dn,he(w)]]),T[35]||(T[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),p("div",yw,[p("button",{class:"spm-btn-secondary",disabled:he(a),onClick:R}," 取消 ",8,kw),p("button",{class:"spm-btn-primary",disabled:!he(h)||he(a),onClick:K},[he(a)?(J(),ee("span",xw,[re(ce,{name:"refresh"}),T[36]||(T[36]=Bt(" 正在导入生成中...",-1))])):(J(),ee("span",Sw,[re(ce,{name:"rocket"}),T[37]||(T[37]=Bt(" 确认导入思源笔记",-1))]))],8,ww)])])]))}}),_w=ri(Cw,[["__scopeId","data-v-c56a3d7e"]]);function xr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function $w(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",s=t.currentTopBlockId||i,n=t.currentPageDividerId||"",o=t.activeBlockType||"";if(xr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(n){let l=e.find(c=>c.startBlockId===n);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===n}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var f,h;return((f=u.blocks)==null?void 0:f.some(d=>d.id===i))||((h=u.allBlockIds)==null?void 0:h.includes(i))}),l)||s&&s!==i&&(l=e.find(u=>{var f,h;return((f=u.blocks)==null?void 0:f.some(d=>d.id===s))||((h=u.allBlockIds)==null?void 0:h.includes(s))}),l)||(l=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(h=>h.id===i||h.id===s)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var f,h;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((h=u.blocks)==null?void 0:h.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),l))return l}return e[0]||null}function it(e,t){var n;if(typeof document>"u"||!e)return;const i=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${i}"]`);!s||s.length===0||s.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function Iw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ke),s.removeAttribute("custom-slides-layout"),s.removeAttribute(Ye),s.removeAttribute("custom-slides-role");return}const o=e.get(n),a=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slides-layout"])||"",r=s.getAttribute(ke)||s.getAttribute("custom-slides-layout");r&&r!==a&&(a?s.setAttribute(ke,a):(s.removeAttribute(ke),s.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ye])||(o==null?void 0:o["custom-slides-role"])||"",c=s.getAttribute(Ye)||s.getAttribute("custom-slides-role");c&&c!==l&&(l?s.setAttribute(Ye,l):(s.removeAttribute(Ye),s.removeAttribute("custom-slides-role")))})}function Mw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const s=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(s==null?void 0:s.getAttribute("data-node-id"))===e}function Tw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function s(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[g,m]of Object.entries(c))e.activeBlockAttrs.value[g]=m;Le.setBlockAttrOverride(u,c),it(u,c);const f=(d=e.parentContainerId)==null?void 0:d.value,h=!!(f&&Mw(u,f));if(Ne in c&&h&&f){const g=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=g),Le.setBlockAttrOverride(f,{[Ne]:g}),it(f,{[Ne]:g}),He(f,{[Ne]:g}).catch(()=>{})}if(ke in c){const g=c[ke];e.currentPageDividerLayout.value=g,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=g)}if(xt in c){const g=c[xt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=g)}i("保存中...");try{await He(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function n(c,u){await s({[c]:u})}function o(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const f=o();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Le.setBlockAttrOverride(f,{[c]:u}),it(f,{[c]:u}),c===ke&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===xt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await He(f,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const f=o();if(!f)return;const h={[ke]:c,[xt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[xt]=u),e.currentPageDividerLayout.value=c,Le.setBlockAttrOverride(f,h),it(f,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await He(f,h),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var h;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Le.setBlockAttrOverride(f,{[c]:u}),it(f,{[c]:u}),(h=e.latestDoc.value)!=null&&h.config&&(c===js&&(e.latestDoc.value.config.theme=u),c===Ws&&(e.latestDoc.value.config.aspectRatio=u),c===Us&&(e.latestDoc.value.config.defaultTransition=u),c===Cn&&(e.latestDoc.value.config.background=u)),i("更新中...");try{await He(f,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:s,saveAttr:n,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function Ia(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],s=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):s.push(a.slice(0,50)))}const n=[];return i.length>0&&n.push(`【核心重点】：${i.join("、")}`),s.length>0&&(n.push("【口播要点】："),s.slice(0,3).forEach((o,a)=>{n.push(`${a+1}. 讲解 ${o}`)})),n.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),n.join(`
`)}async function xc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const n=await t(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Ia(e),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Ia(e),isAiGenerated:!1}}async function Ew(e,t){return(await xc(e,t)).notes}function Aw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Bw(e,t){if(!((t==null?void 0:t[qe])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const s=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(s)}async function Dw(e,t){const s=await((t==null?void 0:t.getChildBlocksFn)||bs)(e).catch(()=>[]);if(!Array.isArray(s)||s.length===0)return[];const n=[];let o=[];for(const r of s){if(gi({...r,ial:{...r.ial||{},...Le.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&o.length===0)continue;n.push(o),o=[];continue}o.push(r)}n.push(o);const a=[];for(let r=0;r<n.length;r++){const l=n[r];if(!l||l.length===0)continue;let c=null;for(let g=l.length-1;g>=0;g--){const m=l[g];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!Aw(c))continue;const u=Le.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[qe]&&!f["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const g=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...g,...u}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const g=await t.getBlockKramdownFn(c.id);g!=null&&g.kramdown&&(h=g.kramdown)}catch{}if(Bw(h,f))continue;const d=gr(h)||h.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:d||"在此输入本页讲稿提词..."})}return a}async function Lw(e,t,i){const s=(i==null?void 0:i.updateBlockFn)||Co,n=(i==null?void 0:i.setBlockAttrsFn)||He,o=(i==null?void 0:i.syncDomFn)||it,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${qe}="true"}`;await s("markdown",r,e),await n(e,{[qe]:"true"}),Le.setBlockAttrOverride(e,{[qe]:"true"}),o(e,{[qe]:"true"})}async function Sc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,s=(t==null?void 0:t.confirmFn)||ae.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await Dw(e,t);if(n.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=n.length;return new Promise(a=>{s("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of n)try{await Lw(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function Pw(e,t){const i=ge(!1),{triggerSaveNotice:s}=t;async function n(h){var D,A,C,L,O,N,V,_;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(j=>`> ${j}`).join(`
`)}
{: custom-slides-note="true"}`,b=((D=e.latestDoc.value)==null?void 0:D.slides)||[],k=e.targetSlide.value,y=k?b.findIndex(j=>j===k):-1;let w=null;if(y!==-1&&y<b.length-1){const j=b[y+1];w=await Vi("markdown",m,j.startBlockId)}else{const j=((A=k==null?void 0:k.noteBlocks)==null?void 0:A.slice(-1)[0])||((C=k==null?void 0:k.blocks)==null?void 0:C.slice(-1)[0]),x=(j==null?void 0:j.id)||(k==null?void 0:k.startBlockId);x?w=await Vi("markdown",m,void 0,x):w=await So("markdown",m,e.currentDocId.value)}const S=((N=(O=(L=w==null?void 0:w[0])==null?void 0:L.doOperations)==null?void 0:O[0])==null?void 0:N.id)||((V=w==null?void 0:w[0])==null?void 0:V.id);return S&&(await He(S,{[qe]:"true"}),Le.setBlockAttrOverride(S,{[qe]:"true"}),Ji(S,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),S}async function o(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){s("取消中...");try{await He(h,{[qe]:"","slides-note":""}),Le.setBlockAttrOverride(h,{[qe]:"","slides-note":""}),it(h,{[qe]:"","slides-note":""}),delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"],s("已取消备注"),ae.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(d){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",d),s("取消失败"),ae.showMessage("取消讲稿备注失败")}}else{s("转换中...");try{let d=e.rawSnippet.value;try{const k=await Md(h);k!=null&&k.kramdown&&(d=k.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(gr(d)||d.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;await Co("markdown",b,h),await He(h,{[qe]:"true"}),Le.setBlockAttrOverride(h,{[qe]:"true"}),it(h,{[qe]:"true"}),e.activeBlockAttrs.value[qe]="true",e.activeBlockType.value="NodeCallout",s("已设为讲稿备注"),ae.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(d){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",d),s("设置失败"),ae.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await n(),ae.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){ae.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var g;const h=e.currentSlideNoteBlockId.value;if(!h){ae.showMessage("未找到本页关联的讲稿备注块");return}Ji(h,(g=e.plugin)==null?void 0:g.app)?ae.showMessage("已在编辑区定位讲稿备注块"):ae.showMessage("定位讲稿备注块失败")}async function l(){var g;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ae.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const d=await xc(h,Da);if(d.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${d.notes.split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;await Co("markdown",b,m),await He(m,{[qe]:"true"}),Le.setBlockAttrOverride(m,{[qe]:"true"}),Ji(m,(g=e.plugin)==null?void 0:g.app)}else await n(d.notes);d.isAiGenerated?ae.showMessage("思源 AI 演讲提词卡生成成功！"):ae.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){ae.showMessage("当前文档无幻灯片页面");return}const d=h.map((b,k)=>({slide:b,idx:k})).filter(({slide:b})=>{var w;const k=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,y=!!((w=b.notes)!=null&&w.trim());return!k&&!y});if(d.length===0){ae.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const g=d.length;ae.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${g} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var k,y,w,S,D,A;if(i.value)return;i.value=!0,ae.showMessage("正在批量追加讲稿块...");let b=0;try{const O=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:V}of d)try{let _=null;if(V<h.length-1){const x=h[V+1];_=await Vi("markdown",O,x.startBlockId)}else{const x=((k=N==null?void 0:N.noteBlocks)==null?void 0:k.slice(-1)[0])||((y=N==null?void 0:N.blocks)==null?void 0:y.slice(-1)[0]),K=(x==null?void 0:x.id)||(N==null?void 0:N.startBlockId);K?_=await Vi("markdown",O,void 0,K):_=await So("markdown",O,e.currentDocId.value)}const j=((D=(S=(w=_==null?void 0:_[0])==null?void 0:w.doOperations)==null?void 0:S[0])==null?void 0:D.id)||((A=_==null?void 0:_[0])==null?void 0:A.id);j&&(await He(j,{[qe]:"true"}),Le.setBlockAttrOverride(j,{[qe]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${V+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ae.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var b;if(i.value)return;const h=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(h.length===0){ae.showMessage("当前文档无幻灯片页面");return}const d=[];for(const k of h)if(k.noteBlocks&&k.noteBlocks.length>0)for(const y of k.noteBlocks)y.id&&d.push({id:y.id,pageIndex:k.pageIndex});if(d.length===0){ae.showMessage("当前文档中没有讲稿备注块，无需删除");return}const g=new Set(d.map(k=>k.pageIndex)).size,m=d.length;ae.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${g} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ae.showMessage("正在批量删除讲稿块...");let k=0;try{for(const y of d)try{await Go(y.id),Le.clearBlockAttrOverride(y.id),k++}catch(w){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${y.id} 失败:`,w)}e.activeBlockId.value&&d.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功删除全部 ${k} 个讲稿备注块`)}catch(y){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",y),ae.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function f(){var d;const h=e.currentDocId.value||((d=e.plugin)==null?void 0:d.currentDocId);if(!h){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ae.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await Sc(h,{onSuccessNotice:s,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:n,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:f}}function Ow(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const s=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(s)}function Rw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function Nw(e){const t=[],i=s=>{var n,o,a,r,l,c,u,f,h,d,g;for(const m of s){if(!m||m.isNote||((n=m.attributes)==null?void 0:n[qe])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[qe])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(Ow(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Ne])||((c=m.ial)==null?void 0:c[Ne]),rawBlock:m});continue}if(Rw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[Ne])||((f=m.ial)==null?void 0:f[Ne]),rawBlock:m});continue}const b=m.children&&m.children.length>0?m.children:(h=m.rawNode)==null?void 0:h.children;if(Array.isArray(b)&&b.length>0){i(b);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((d=m.attributes)==null?void 0:d[Ne])||((g=m.ial)==null?void 0:g[Ne]),rawBlock:m})}};return i(e||[]),t}function zw(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=Nw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const s=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&s.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return s}async function Hw(e,t){const s=await((t==null?void 0:t.compileDocFn)||(a=>Le.compile(a)))(e).catch(()=>null);if(!s||!Array.isArray(s.slides)||s.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],o=new Set;for(const a of s.slides){const r=zw(a);r.length>0&&(n.push(...r),o.add(a.pageIndex))}return{totalPages:s.slides.length,animatedPagesCount:o.size,targets:n}}async function Cc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,s=(t==null?void 0:t.confirmFn)||ae.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||He,o=(t==null?void 0:t.syncDomFn)||it;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await Hw(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{s("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var h;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const d of a.targets)try{await n(d.blockId,{[Ne]:d.targetClick}),Le.setBlockAttrOverride(d.blockId,{[Ne]:d.targetClick}),o(d.blockId,{[Ne]:d.targetClick}),u++}catch(g){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,g),f++}(h=t==null?void 0:t.onSuccessNotice)==null||h.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:f})},()=>{c({...a,successCount:0,errorCount:0})})})}function Fw(e,t){const{saveAttr:i,saveAttrs:s,savePageAttr:n}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await s({[Ui]:"true",[ss]:"true"}),e.activeBlockAttrs.value[Ui]="true",e.activeBlockAttrs.value[ss]="true"):(await i(Ui,"false"),e.activeBlockAttrs.value[Ui]="false")}async function a(){const L=e.videoLoop.value?"false":"true";await i(_n,L)}async function r(){const L=e.videoMuted.value?"false":"true";await i(ss,L)}async function l(){const L=e.videoControls.value?"false":"true";await i($n,L)}async function c(L){var j,x;const O=e.activeBlockId.value;if(!O)return;const N=e.rawSnippet.value||"",V=yi(N)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(L)if(L==="background"){const K={[Ye]:"background",[ke]:""};_&&V&&(e.pageBackground&&(e.pageBackground.value=V),await He(_,{[ct]:V}).catch(()=>{}),Le.setBlockAttrOverride(_,{[ct]:V}),it(_,{[ct]:V}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=V)),await s(K)}else(L===In||L===Mn)&&await s({[ke]:L,[Ye]:""});else{const K={[Ye]:"",[ke]:""};if(e.activeBlockAttrs.value[ct]==="true"&&(K[ct]=""),_&&V&&((j=e.pageBackground)==null?void 0:j.value)===V&&(e.pageBackground&&(e.pageBackground.value=""),await He(_,{[ct]:""}).catch(()=>{}),Le.setBlockAttrOverride(_,{[ct]:""}),it(_,{[ct]:""}),(x=e.targetSlide.value)!=null&&x.frontmatter&&delete e.targetSlide.value.frontmatter.background),await s(K),typeof document<"u"){const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${O}"]`),$=R==null?void 0:R.closest('[data-type="NodeListItem"]'),T=$==null?void 0:$.getAttribute("data-node-id");if(T&&T!==O){const P={[ke]:"",[Ye]:""};it(T,P),Le.setBlockAttrOverride(T,P),await He(T,P).catch(()=>{})}}}}function u(){e.elemClick.value?i(Ne,""):i(Ne,"+1")}function f(L){i(Ne,L)}function h(L){i(ii,L)}function d(L){(e.activeBlockAttrs.value[Me]||"")===L?i(Me,""):i(Me,L)}function g(L){e.elemShikiLines.value=L,i(Xi,L)}function m(L){const O=L?L.trim():"",N=/^\d+$/.test(O)?`${O}px`:O;e.elemMaxHeight.value=N,i(Vs,N)}async function b(){const L=e.currentSlideLayout.value==="three-cols-header";await i(Me,L?"col-1":"left"),ae.showMessage(L?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function k(){const L=e.activeBlockId.value;if(!L)return;const O={[Ne]:"",[ii]:"",[Me]:"",[Xi]:"",[Vs]:"",[qe]:"","slides-note":"",[ke]:"",[xt]:"",[Ye]:"",[wt]:"",[ct]:"",[jt]:"",[Ui]:"",[_n]:"",[ss]:"",[$n]:""};if(it(L,O),await He(L,O),Le.clearBlockAttrOverride(L),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`),V=N==null?void 0:N.closest('[data-type="NodeListItem"]'),_=V==null?void 0:V.getAttribute("data-node-id");_&&_!==L&&(it(_,O),await He(_,O).catch(()=>{}),Le.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ae.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function y(){if(e.activeBlockId.value)try{await Vi("markdown","---",e.activeBlockId.value,void 0),ae.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function w(){const L=e.activeBlockId.value||e.currentDocId.value;if(L)try{await Vi("markdown","---",void 0,L),ae.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function S(){if(e.activeBlockId.value)try{await Go(e.activeBlockId.value),ae.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("删除失败")}}async function D(){var L,O;try{let N=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);j&&(N=j.getAttribute("data-type")==="NodeSuperBlock"?j:j.closest('[data-type="NodeSuperBlock"]'))}if(!N){const j=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(j){const x=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);if(x){let K=x.nextElementSibling;for(;K&&!(K.getAttribute("data-type")==="NodeThematicBreak"||(L=K.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));){const R=K.getAttribute("data-type")==="NodeSuperBlock"?K:K.querySelector('[data-type="NodeSuperBlock"]');if(R){N=R;break}K=K.nextElementSibling}}}else{const x=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),K=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const R of K)if(!x||R.compareDocumentPosition(x)&Node.DOCUMENT_POSITION_FOLLOWING){N=R;break}}}}const V=[];if(N){const _=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const j of _){const x=j.getAttribute("data-node-id");x&&(V.push(x),j.removeAttribute("style"))}}else if((O=e.targetSlide.value)!=null&&O.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const j of _.children)j.id&&V.push(j.id);break}}if(V.length>0)for(const _ of V)await He(_,{style:""}).catch(()=>{});await n(xt,""),ae.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),ae.showMessage("重置超级块比例失败")}}async function A(){var L,O,N;try{let V=null;if(typeof document<"u"){const j=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),x=e.activeBlockId.value;let K=[];if(j){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);if(T){let P=T.nextElementSibling;for(;P&&!(P.getAttribute("data-type")==="NodeThematicBreak"||(L=P.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));)K.push(P),P=P.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),P=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const ne of P)if(!T||ne.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)K.push(ne);else break}const R=[];let $;for(const T of K){const P=T.getAttribute("data-type");P==="NodeHeading"&&($=T.getAttribute("data-node-id")||void 0);const ne=[];P==="NodeSuperBlock"?ne.push(T):ne.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const Y of ne){if((Y.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const le=Y.getAttribute("data-node-id")||"";let se=[];const oe=Array.from(Y.querySelectorAll('[data-type="NodeListItem"]'));if(oe.length===4&&(se=oe.map(_e=>_e.getAttribute("data-node-id")).filter(Boolean)),se.length!==4){const _e=Array.from(Y.querySelectorAll(":scope > [data-node-id]"));_e.length===4&&(se=_e.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}se.length===4&&R.push({sbId:le,itemIds:se,headerId:$})}}R.length>0&&(x&&(V=R.find(T=>{if(T.sbId===x||T.itemIds.includes(x))return!0;const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),ne=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);return!!(P&&ne&&P.contains(ne))})||null),V||(V=R[0]))}if(!V&&((O=e.targetSlide.value)!=null&&O.blocks)){const j=e.targetSlide.value,x=[];for(const R of j.blocks)R.rawNode?x.push(R.rawNode):x.push({id:R.id,type:R.type,content:R.content,markdown:R.rawMarkdown,children:R.children,ial:R.attributes||R.ial||{}});const K=pp(x,e.activeBlockId.value);K&&K.items.length===4&&(V={sbId:K.superBlockNode.id,itemIds:K.items.map(R=>R.id),headerId:(N=K.headerNode)==null?void 0:N.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Le.setBlockAttrOverride(_,{[ke]:"clover"}),it(_,{[ke]:"clover"}),await He(_,{[ke]:"clover"}).catch(()=>{})),V&&V.itemIds.length>0){V.headerId&&(Le.setBlockAttrOverride(V.headerId,{[Me]:"header"}),it(V.headerId,{[Me]:"header"}),await He(V.headerId,{[Me]:"header"}).catch(()=>{}));const j=Math.min(4,V.itemIds.length);for(let x=0;x<j;x++){const K=V.itemIds[x],R=`col-${x+1}`;Le.setBlockAttrOverride(K,{[Me]:R}),it(K,{[Me]:R}),await He(K,{[Me]:R}).catch(()=>{})}}return ae.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(V){return console.error("[layout-actions] applyCloverLayout error:",V),ae.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var O,N;const L=e.currentDocId.value||((O=e.plugin)==null?void 0:O.currentDocId);if(!L){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if((N=t.isBatchProcessing)!=null&&N.value){ae.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await Cc(L,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:h,onElemSlotChange:d,onElemShikiLinesChange:g,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:k,onInsertDividerBefore:y,onInsertDividerAfter:w,onDeleteCurrentBlock:S,resetSuperBlockWidth:D,applyCloverLayout:A,onAutoAnimateDocument:C}}function jw(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:s,savePageAttr:n,applyPageLayoutAndRatio:o,saveDocAttr:a}=Tw(e),r=Pw(e,{triggerSaveNotice:t}),l=Fw(e,{saveAttr:s,saveAttrs:i,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var k;if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,g=await Pi(d,(k=e.currentDocId)==null?void 0:k.value,e.plugin),m=cc(d,{title:g});dc(`${g}.html`,m)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${g}.html)`)}function u(){if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}uc(e.latestDoc.value)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=ge(!1);async function h(){var d;if(f.value){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const g=e.latestDoc.value,m=await Pi(g,(d=e.currentDocId)==null?void 0:d.value,e.plugin),b=await gc(g,{title:m,onProgress:(k,y)=>{ae.showMessage(`正在导出幻灯片图片 (${k} / ${y})...`,2e3)}});b.success?ae.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ae.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:s,savePageAttr:n,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:h}}function Ww(e){const t=ye(()=>xr(e.activeBlockType.value));function i(s){const{attrKey:n,fallback:o,mode:a="defined"}=s,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Le.getBlockAttrOverride(l);if(r(c==null?void 0:c[n]))return c[n]}return o()})}return{isDivider:t,resolvePageAttr:i}}function bo(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function Uw(e,t){for(let i=t-1;i>=0;i--){const s=e[i];if(gi(s)||(s.content||s.markdown||"").trim())return s}return null}function yo(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const i=(e.markdown||e.content||"").trim();return i?i.includes("![")||i.includes("<img")||i.length>100?2:1:0}function Ma(e,t){if(e===1)return"cover";let i=!1,s=-1;for(let r=0;r<t.length;r++){const l=t[r],c=(l.markdown||l.content||"").trim();if(c.includes("![")||c.includes("<img")||l.type==="img"){i=!0,s=r;break}}if(i)return s===0?"image-left":"image-right";let n=0,o=!1,a=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(o=!0),r.type==="b"&&(a=!0);return o||n>=3?"two-cols":a&&t.length<=2?"quote":"default"}function Vw(e,t){const i=[],s=new Set,n=6,o=6;let a=0,r=0,l=0,c=0,u=null;function f(h){const d=[];for(let g=h+1;g<e.length;g++){const m=e[g];if(gi(m))break;const b=bo(m);if(b!==null&&(b===1||b===2||b===3))break;d.push(m)}return d}if(e.length>0){let h=!1,d=-1;for(let g=0;g<e.length;g++){const m=e[g];if(gi(m)){h=!0;break}if((m.content||m.markdown||"").trim()){d=g;break}}if(!h&&d>=0){const g=e[d],m=bo(g);let b=m===1?"cover":"default";if(m!==1){const y=f(d);b=Ma(m,y)}const k=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";i.push({blockId:g.id,recommendedLayout:b,reason:k}),s.add(g.id)}}for(let h=0;h<e.length;h++){const d=e[h];if(gi(d)){a=0,r=0,l=0,c=0,u=null;continue}const g=Uw(e,h),m=!g||gi(g),b=bo(d);if(b===1||b===2||b===3){if(!(l===1&&c===0&&u!==null&&!(u===1&&b===2))&&!m&&a>0&&!s.has(d.id)){let D=b===1?"cover":"default";{const C=f(h);D=Ma(b,C)}let A=b===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":b===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";D==="image-right"||D==="image-left"?A+=" (推荐图文版式)":D==="two-cols"?A+=" (推荐双栏版式)":D==="quote"&&(A+=" (推荐引言版式)"),i.push({blockId:d.id,recommendedLayout:D,reason:A}),s.add(d.id),a=1,r=yo(d),l=1,c=0,u=b;continue}a++,r+=yo(d),l++,u=b;continue}const y=yo(d);if((a>=n||r+y>o&&a>0)&&!m&&a>0&&!s.has(d.id)){i.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s.add(d.id),a=1,r=y,l=0,c=1,u=null;continue}a++,r+=y,c++}return i}async function _c(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await bs(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),s=Vw(i);if(s.length===0){ae.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ae.showMessage(`智能分析完毕：发现 ${s.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const o of s)try{await Vi("markdown","---",o.blockId,void 0),await He(o.blockId,{"custom-slides-layout":o.recommendedLayout}),n++}catch(a){console.warn("Failed to insert divider:",a)}ae.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function $c(e){var o,a,r,l,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await bs(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容");return}const i=[],s=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((o=f.markdown)==null?void 0:o.trim())==="---"||((a=f.markdown)==null?void 0:a.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((l=f.content)==null?void 0:l.trim())==="---")?i.push(f.id):((c=f.ial)!=null&&c[pi]||(u=f.ial)!=null&&u[ke])&&s.push(f.id);if(i.length===0&&s.length===0){ae.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}ae.showMessage(`正在清除文档中的 ${i.length} 处分页线...`);let n=0;for(const f of i)try{await Go(f),n++}catch(h){console.warn("Failed to delete divider block:",h)}for(const f of s)try{await He(f,{[pi]:"",[ke]:""})}catch(h){console.warn("Failed to clear slide attrs:",h)}ae.showMessage(`已成功清除文档中的 ${n} 处分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const qw={class:"spm-slides-inspector"},Gw={class:"spm-inspector-topbar"},Kw={class:"spm-inspector-title"},Yw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Zw={class:"spm-inspector-topbar-actions"},Jw={class:"spm-target-banner"},Xw={class:"spm-target-info"},Qw=["aria-label"],e2={key:0,class:"spm-save-status"},t2=["title"],i2={class:"spm-inspector-body"},s2=Rt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=Ut("plugin"),s=ge(!1);function n(Q){s.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),u=ge(""),f=ge(""),h=ge(""),d=ge(""),g=ge(""),m=ge(""),b=ge(null),k=ge(""),y=ge("");function w(){var ve;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(Q).then(()=>{y.value="已复制！",setTimeout(()=>{y.value=""},1500)}).catch(()=>{})}const S=ye(()=>xr(a.value)),D=ye(()=>a.value==="NodeCodeBlock"),A=ge(!1),C=ye(()=>{if(A.value||ze.value)return!0;const Q=l.value||"";return!!yi(Q)}),L=ye(()=>{const Q=a.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ve=l.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),O=ye(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),N=ye(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),V=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(S.value)return"分页符 (---)";if(O.value)return"全局文档";if(L.value)return"视频块";let Q="内容块";switch(a.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return d.value?g.value?`${g.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),j=ye(()=>S.value?"tag-divider":O.value?"tag-doc":"tag-block"),x=ye(()=>r.value[ke]||"default"),K=ye(()=>r.value[wt]||"slide-left"),R=ge(""),$=ge(""),T=ye(()=>r.value[Bs]||"inherit"),P=ye(()=>{var Q;return $w((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),ne=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),Y=ye(()=>{var Q,ve,Ae;return((Ae=(ve=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:ve[0])==null?void 0:Ae.id)||""}),q=ye(()=>{var Ue,Ve,Re,gt,nn,_i;if(S.value){const nt=r.value[ke]||r.value["custom-slides-layout"];if(nt)return nt}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(h.value)return h.value;const ve=f.value||(S.value?o.value:"");if(ve){const nt=Le.getBlockAttrOverride(ve);if(nt!=null&&nt[ke])return nt[ke]}if(ve&&((Ue=b.value)!=null&&Ue.slides)){const nt=b.value.slides.find(Qi=>Qi.startBlockId===ve);if((Ve=nt==null?void 0:nt.frontmatter)!=null&&Ve.layout)return nt.frontmatter.layout}if((gt=(Re=P.value)==null?void 0:Re.frontmatter)!=null&&gt.layout)return P.value.frontmatter.layout;if((_i=(nn=P.value)==null?void 0:nn.blocks)!=null&&_i.some(nt=>nt.slot&&(["col-1","col-2","col-3"].includes(nt.slot)||/^col-\d+$/.test(nt.slot))))return"cols-header";const Ae=Le.getBlockAttrOverride(c.value);return Ae!=null&&Ae[ke]?Ae[ke]:"default"}),le=Ww({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:f}),se=le.resolvePageAttr({attrKey:xt,mode:"truthy",fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.layoutRatio)||""}}),oe=le.resolvePageAttr({attrKey:os,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.mask)||""}}),_e=le.resolvePageAttr({attrKey:Gi,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskRatio)||""}}),Ie=le.resolvePageAttr({attrKey:rs,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),xe=le.resolvePageAttr({attrKey:as,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const Ue=Ae.length,Ve=Ae.map(_i=>{const nt=_i.getAttribute("style")||"",Qi=nt.match(/calc\(\s*([\d.]+)%/);if(Qi)return parseFloat(Qi[1]);const Cs=nt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Cs?parseFloat(Cs[1]):null});let Re="",gt=!1;if(Ve.some(_i=>_i!==null)){gt=!0;const _i=Ve.reduce((Pe,vt)=>Pe+(vt||0),0),nt=Ve.filter(Pe=>Pe===null).length,Qi=nt>0?Math.max(0,100-_i)/nt:100/Ae.length,Cs=Ve.map(Pe=>Pe!==null?Pe:Qi),bd=Cs.reduce((Pe,vt)=>Pe+vt,0)||1,_s=Cs.map(Pe=>Pe/bd*100);if(_s.length===2){const[Pe]=_s;if(Pe>=48&&Pe<=52)Re="1:1";else if(Pe>=31&&Pe<=35)Re="1:2";else if(Pe>=65&&Pe<=69)Re="2:1";else if(Pe>=28&&Pe<=32)Re="3:7";else if(Pe>=68&&Pe<=72)Re="7:3";else if(Pe>=38&&Pe<=42)Re="4:6";else if(Pe>=58&&Pe<=62)Re="6:4";else{const vt=Math.round(Pe);Re=`${vt}:${100-vt}`}}else if(_s.length===3){const[Pe,vt,$i]=_s;if(Pe>=31&&Pe<=35&&vt>=31&&vt<=35&&$i>=31&&$i<=35)Re="1:1:1";else if(Pe>=23&&Pe<=27&&vt>=48&&vt<=52&&$i>=23&&$i<=27)Re="1:2:1";else if(Pe>=48&&Pe<=52&&vt>=23&&vt<=27&&$i>=23&&$i<=27)Re="2:1:1";else if(Pe>=23&&Pe<=27&&vt>=23&&vt<=27&&$i>=48&&$i<=52)Re="1:1:2";else{const Ir=Math.round(Pe),Mr=Math.round(vt);Re=`${Ir}:${Mr}:${100-Ir-Mr}`}}else Re=_s.map(Pe=>Math.round(Pe)).join(":")}else gt=!1,Re=Array.from({length:Ue},()=>1).join(":");const nn=Ue>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ue,ratio:Re,isCustomWidth:gt,recommendedLayout:nn}}function X(Q){if(!(Q!=null&&Q.blocks))return null;for(const ve of Q.blocks){const Ae=ve.rawNode;if(Ae&&ut(Ae)&&ni(Ae)){const Ve=xs(Ae).length,Re=mr(Ae);return{hasSuperBlock:!0,colCount:Ve,ratio:Re||Array.from({length:Ve},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ve>=2?"cols-header":"two-cols"}}}return null}const ue=ye(()=>{var Q;if(typeof document<"u"){const ve=o.value;if(ve){const Ue=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(Ue){const Ve=Ue.getAttribute("data-type")==="NodeSuperBlock"?Ue:Ue.closest('[data-type="NodeSuperBlock"]');if(Ve){const Re=fe(Ve);if(Re)return Re}}}const Ae=f.value||(S.value?o.value:"");if(Ae){const Ue=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(Ue){let Ve=Ue.nextElementSibling;for(;Ve&&!(Ve.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ve.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ve.getAttribute("data-type")==="NodeSuperBlock"?Ve:Ve.querySelector('[data-type="NodeSuperBlock"]');if(Re){const gt=fe(Re);if(gt)return gt}Ve=Ve.nextElementSibling}}}else{const Ue=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ve=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ve)if(!Ue||Re.compareDocumentPosition(Ue)&Node.DOCUMENT_POSITION_FOLLOWING){const gt=fe(Re);if(gt)return gt}}}return X(P.value)}),E=ye(()=>{var Q;return((Q=ue.value)==null?void 0:Q.ratio)||""}),H=ye(()=>{const Q=a.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),W=ye(()=>!!(r.value[qe]||r.value["slides-note"]));function F(){if(!d.value)return!1;if(o.value===d.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!Q)return!1;const ve=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const M=ye(()=>{var ve;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(d.value&&F())return m.value||"";if(d.value)return"";const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ue=>Ue.id===Q);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),I=ye(()=>{var ve;if(r.value[ii])return r.value[ii];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ue=>Ue.id===Q);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),z=ye(()=>{var ve;if(r.value[Me])return r.value[Me];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ue=>Ue.id===Q);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),G=ge(""),Z=ge(""),B=ye(()=>r.value[Ui]==="true"),U=ye(()=>r.value[_n]==="true"),ie=ye(()=>r.value[ss]==="true"),te=ye(()=>r.value[$n]!=="false"),me=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.theme)||r.value[js]||"default"}),Se=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.aspectRatio)||r.value[Ws]||"16/9"}),Ce=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.defaultTransition)||r.value[Us]||"slide-left"}),De=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.spacing)||r.value[$o]||"normal"}),Fe=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.background)||r.value[Cn]||""}),ze=ye(()=>{var Ve,Re;if((r.value[Ye]||r.value["slides-role"])===Na||r.value[ct]==="true")return"background";const ve=r.value[ke]||r.value["slides-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ae=l.value||"",Ue=yi(Ae);if(Ue&&((Re=(Ve=P.value)==null?void 0:Ve.frontmatter)!=null&&Re.background)){const gt=P.value.frontmatter.background;if(gt===Ue||gt.endsWith(Ue)||Ue.endsWith(gt))return"background"}return""}),et=ye(()=>!!(r.value[Ne]||r.value[ii]||r.value[Me]||r.value[Xi]||r.value[qe]||r.value["slides-note"]||r.value[Ye]||r.value[ke]||r.value[Ui]||r.value[_n]||r.value[ss]||r.value[$n])),{saveAttr:Oe,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ke,resetSuperBlockWidth:de,saveDocAttr:pe,onToggleVideoAutoplay:Qe,onToggleVideoLoop:at,onToggleVideoMuted:_t,onToggleVideoControls:lt,onImageRoleChange:ai,onToggleNoteBlock:Ac,onAddNoteBlock:Bc,onLocateNoteBlock:Dc,onGenerateNotesWithAI:Lc,isBatchProcessing:Sr,onBatchAppendNotes:Pc,onBatchDeleteNotes:Oc,onIdentifyNotesBlocks:Rc,onAutoAnimateDocument:Nc,toggleElemClick:zc,onElemClickStepChange:Hc,onElemMotionChange:Fc,onElemSlotChange:jc,onElemShikiLinesChange:Wc,onElemMaxHeightChange:Uc,onSetTwoColsContrast:Vc,onClearBlockAttrs:qc,onInsertDividerBefore:Gc,onInsertDividerAfter:Cr,onDeleteCurrentBlock:Kc,onExportHtml:Yc,onExportPdf:Zc,onExportImages:Jc,isExportingImages:Xc}=jw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:h,parentContainerId:d,parentContainerClicks:m,latestDoc:b,targetSlide:P,currentSlideNoteBlockId:Y,currentSlideLayout:q,isNoteBlock:W,elemClick:M,videoAutoplay:B,videoLoop:U,videoMuted:ie,videoControls:te,pageBackground:R,pageImage:$,elemShikiLines:G,elemMaxHeight:Z,saveStatus:k,plugin:i});async function Qc(Q){if(Q==="clover"){if(!await Ke())return}else ft(ke,Q)}function ed(Q){ft(xt,Q)}async function td(Q){await ft(os,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!_e.value||_e.value==="1:1")&&await ft(Gi,"1:1:1:1")}function id(Q){ft(Gi,Q)}function sd(Q){ft(rs,Q)}function nd(Q){ft(as,Q)}function _r(Q){if(!Q)return;const ve=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ae=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");tt(ve,Ae)}function od(Q){ft(xt,Q)}async function rd(){await de()}function ad(Q){Oe(wt,Q)}function ld(Q){$.value=Q,Oe(jt,Q)}function cd(Q){Oe(Bs,Q==="inherit"?"":Q)}function dd(Q){pe(js,Q)}function ud(Q){pe(Cn,Q)}function fd(Q){pe(Ws,Q)}function pd(Q){pe(Us,Q)}function hd(Q){pe($o,Q)}function $r(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function md(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function gd(){i&&kt("aiScript")&&_c(i)}function vd(){i&&kt("aiScript")&&$c(i)}return t({setActiveBlock(Q){o.value=Q.id,a.value=Q.type,r.value={...Q.attrs},l.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,f.value=Q.pageDividerId||"",h.value=Q.pageDividerLayout||"",d.value=Q.parentContainerId||"",g.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),R.value=Q.attrs[ct]||"",$.value=Q.attrs[jt]||"",G.value=Q.attrs[Xi]||"",Z.value=Q.attrs[Vs]||"",A.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){s.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ve)=>(J(),ee("div",qw,[p("div",Gw,[p("div",Kw,[(J(),ee("svg",Yw,[...ve[2]||(ve[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=p("span",null,"演示配置",-1))]),p("div",Zw,[he(kt)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ae=>s.value=!0)},[re(ce,{name:"import"}),ve[4]||(ve[4]=p("span",null,"导入",-1))])):Te("",!0),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:$r},[re(ce,{name:"split-preview"}),ve[5]||(ve[5]=p("span",null,"分屏预览",-1))])])]),p("div",Jw,[p("div",Xw,[p("span",{class:$e(["spm-target-tag",j.value])},we(_.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":y.value||"点击复制 ID: "+(o.value||c.value),onClick:w},[re(ce,{name:"copy"}),p("span",null,"#"+we(N.value),1)],8,Qw)]),k.value?(J(),ee("span",e2,"● "+we(k.value),1)):Te("",!0)]),V.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:l.value},we(V.value),9,t2)):Te("",!0),p("div",i2,[S.value?(J(),ti(B1,{key:0,"page-layout":x.value,"page-layout-ratio":he(se),"page-mask":he(oe),"page-mask-ratio":he(_e),"page-mask-style":he(Ie),"page-mask-initial":he(xe),"detected-sb-ratio":E.value,"detected-sb-info":ue.value,"page-transition":K.value,"page-spacing":T.value,"page-image":$.value,"page-notes":ne.value,"page-index":v.value,"onUpdate:pageLayout":Qc,"onUpdate:pageLayoutRatio":ed,"onUpdate:pageMask":td,"onUpdate:pageMaskRatio":id,"onUpdate:pageMaskStyle":sd,"onUpdate:pageMaskInitial":nd,onApplySuperBlockLayout:_r,onResetSuperblockRatio:rd,"onUpdate:pageTransition":ad,"onUpdate:pageSpacing":cd,"onUpdate:pageImage":ld,onAddNoteBlock:he(Bc),onLocateNoteBlock:he(Dc),onGenerateNotes:he(Lc),onBatchAppendNotes:he(Pc),onBatchDeleteNotes:he(Oc),"is-batch-processing":he(Sr),onInsertDividerAfter:he(Cr),onDeleteDivider:he(Kc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!O.value?(J(),ti(g0,{key:1,"elem-click":M.value,"elem-motion":I.value,"elem-slot":z.value,"elem-shiki-lines":G.value,"elem-max-height":Z.value,"is-code-block":D.value,"is-image":C.value,"is-video":L.value,"is-super-block":H.value,"detected-sb-info":ue.value,"video-autoplay":B.value,"video-loop":U.value,"video-muted":ie.value,"video-controls":te.value,"has-block-attrs":et.value,"is-note":W.value,"image-role":ze.value,"current-slide-layout":q.value,"parent-elem-click":m.value,"parent-container-slot":g.value,"parent-container-id":d.value,onToggleNote:he(Ac),onToggleElemClick:he(zc),onToggleVideoAutoplay:he(Qe),onToggleVideoLoop:he(at),onToggleVideoMuted:he(_t),onToggleVideoControls:he(lt),"onUpdate:imageRole":he(ai),"onUpdate:elemClick":he(Hc),"onUpdate:elemMotion":he(Fc),"onUpdate:elemSlot":he(jc),"onUpdate:elemShikiLines":he(Wc),"onUpdate:elemMaxHeight":he(Uc),onApplySuperBlockLayout:_r,onApplySuperBlockRatio:od,onInsertDividerBefore:he(Gc),onInsertDividerAfter:he(Cr),onSetTwoColsContrast:he(Vc),onClearBlockAttrs:he(qc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),ti(Ck,{key:2,"doc-theme":me.value,"doc-background":Fe.value,"doc-aspect-ratio":Se.value,"doc-default-transition":Ce.value,"doc-spacing":De.value,"is-exporting-images":he(Xc),"is-batch-processing":he(Sr),"onUpdate:docTheme":dd,"onUpdate:docBackground":ud,"onUpdate:docAspectRatio":fd,"onUpdate:docDefaultTransition":pd,"onUpdate:docSpacing":hd,onOpenBottomPreview:$r,onOpenPresenter:md,onIdentifyNotes:he(Rc),onAutoAnimate:he(Nc),onAiAutoSplit:gd,onClearDividers:vd,onExportHtml:he(Yc),onExportPdf:he(Zc),onExportImages:he(Jc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),s.value&&he(kt)("import")?(J(),ti(_w,{key:1,onClose:ve[1]||(ve[1]=Ae=>s.value=!1),onSuccess:n})):Te("",!0)]))}}),n2=2e3,o2=600;function r2(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ko(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Ta(e))return!0;const t=e.firstElementChild;return!!(t&&Ta(t))}function Ta(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function a2(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class l2{constructor(){be(this,"consumers",new Map);be(this,"seq",0);be(this,"verifyTimer",null)}register(t,i,s){if(!i)return()=>{};const n=++this.seq,o=a2(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:s};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=ko(i),this.consumers.set(n,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ko(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!r2(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const s of this.consumers.values())if(!s.visible&&ko(s.element)){s.visible=!0,(i=s.onVisible)==null||i.call(s);return}},n2))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const wn=new l2,Ss=new sn;function Ic(e,t,i){const s=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},n=wn.register(e,t,s);return s(),n}let Ai=null,zt=null,xn=null;function c2(){return zt}function d2(e,t){Ai&&Mc(),Ai=pr(Qg),Ai.provide("plugin",t),Ai.provide("sandboxBridge",Ss);const i=Ai.mount(e);return zt=i,xn=Ic("preview",e,t),i}function Mc(e){xn&&(xn(),xn=null),Ai&&(Ai.unmount(),Ai=null,zt=null)}function u2(){return zt!==null}let Bi=null,qi=null;function f2(e,t){return Bi&&Tc(),Bi=pr(cb),Bi.provide("plugin",t),Bi.provide("sandboxBridge",Ss),qi=Bi.mount(e),qi}function Tc(e){Bi&&(Bi.unmount(),Bi=null,qi=null)}function p2(e){var t;try{const i=new BroadcastChannel("siyuan-slides-sync");i.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||Ri()}}),i.close()}catch{}}let Di=null,Dt=null,Sn=null;function h2(e,t){Di&&Ec(),Di=pr(s2),Di.provide("plugin",t),Di.provide("sandboxBridge",Ss);const i=Di.mount(e);return Dt=i,Sn=Ic("dock",e,t),i}function Ec(e){Sn&&(Sn(),Sn=null),Di&&(Di.unmount(),Di=null,Dt=null)}function m2(e,t){Dt!=null&&Dt.updateDocument&&Dt.updateDocument(e),zt!=null&&zt.updateDocument?zt.updateDocument(e,t):(Ss.updateSlides(e.slides,e.config,e.fullMarkdown),p2(e)),qi!=null&&qi.updateDocument&&qi.updateDocument(e)}function qo(e){zt!=null&&zt.navigateToBlock?zt.navigateToBlock(e):Ss.highlightElement(e)}function is(e){Dt!=null&&Dt.setActiveBlock&&Dt.setActiveBlock(e)}function g2(){return fi("import")?!1:Dt!=null&&Dt.openImportDialog?(Dt.openImportDialog(),!0):!1}const v2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:pi,value:"true"},{key:ke,value:"cover"},{key:wt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:pi,value:"true"},{key:ke,value:"two-cols"},{key:wt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:pi,value:"true"},{key:ke,value:"fact"},{key:wt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:pi,value:"true"},{key:ke,value:"intro"},{key:wt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:pi,value:"true"},{key:ke,value:"quote"},{key:wt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Xi,value:"1-3"}]}];class wo{getPresetTemplates(){return v2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${wt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,s,n){const o=`SELECT block_id FROM attributes WHERE name = '${wt}' AND value = '${t}'`,a=await s(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[wt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,s,n){const o=`SELECT block_id FROM attributes WHERE name = '${ke}' AND value = '${t}'`,a=await s(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[ke]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}function b2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),fi("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{g2()||ae.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await He(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ae.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),fi("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>_c(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>$c(e)})),fi("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,f;if(!e.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}ae.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await bs(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await Ew(i,Da)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slides-note="true"}`,a=await So("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((f=a==null?void 0:a[0])==null?void 0:f.id);r&&(await He(r,{"custom-slides-note":"true"}),Le.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Ji(r,e.app)),ae.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await Sc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await Cc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new wo,i=t.buildTransitionStatsSql(),s=await hs(i).catch(()=>[]),n=t.formatTransitionSummary(s||[]);ae.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new wo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ae.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ae.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new wo().batchUpdateTransitions("fade","slide-left",s=>hs(s).catch(()=>[]),(s,n)=>He(s,n));ae.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),fi("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),fi("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ae.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ae.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ae.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ae.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",_o);t.success?ae.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ae.showMessage(`同步失败：${t.error}`)}})),!fi("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,s=await Pi(i,e.currentDocId,e),n=await gc(i,{title:s,onProgress:(o,a)=>{ae.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});n.success?ae.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${s}.zip！`,4e3):ae.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class y2{constructor(t=400){be(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const s=this.entries.get(t);if(s){if(i-s.at>this.ttlMs){this.entries.delete(t);return}return s.attrs}}set(t,i,s=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:s})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function k2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=s=>{for(const n of s||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const s of e.slides)i(s.blocks),i(s.noteBlocks);return t}class w2{constructor(t=150){be(this,"lastBlockId","");be(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class x2{constructor(){be(this,"attrCache",new y2);be(this,"compiledIalIndex",{doc:null,map:new Map});be(this,"locatingLockUntil",0);be(this,"lockedTargetBlockId","");be(this,"lastKnownPageDividerId","");be(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const s=Le.getBlockAttrOverride(t),n=this.getCompiledIal(i,t);if(s||n)return{...n||{},...s||{}};const o=this.attrCache.get(t);if(o)return o;const a=await Ko(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:k2(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const s=document.querySelector(".protyle .protyle-title[data-node-id]"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const s=t.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let s=i||"";if(!s&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");s=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const n=await this.resolveBlockAttrs(t,null);is({id:t,rootId:t,type:"doc",content:s,attrs:n,isDivider:!1,isCode:!1}),qo(t)}handleBlockClickedFromSlide(t,i,s,n,o){var c,u,f,h;if(!t){Fs();const d=typeof o=="number"&&o>0?o:1,g=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(g){const m=g.startBlockId||"",b=((f=g.frontmatter)==null?void 0:f.layout)||"",k={"custom-slides-layout":b,...g.frontmatter};return is({id:m,rootId:s,type:"NodeThematicBreak",attrs:k,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,n).then(y=>{y&&Object.keys(y).length>0&&is({id:m,rootId:s,type:"NodeThematicBreak",attrs:{...k,...y},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(s),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Ji(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,s,n);else{let d="",g="";if(n!=null&&n.slides){const m=n.slides.find(b=>{var k,y,w;return b.startBlockId===t||((k=b.blocks)==null?void 0:k.some(S=>S.id===t))||((y=b.allBlockIds)==null?void 0:y.includes(t))||((w=b.noteBlocks)==null?void 0:w.some(S=>S.id===t))});m!=null&&m.startBlockId&&(d=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(g=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(d&&!g){const b=Le.getBlockAttrOverride(d);if(b!=null&&b[ke]||b!=null&&b["custom-slides-layout"])g=b[ke]||b["custom-slides-layout"]||"";else{const k=await this.resolveBlockAttrs(d,n);g=k[ke]||k["custom-slides-layout"]||"",k&&Object.keys(k).length>0&&Le.setBlockAttrOverride(d,k)}}is({id:t,rootId:s,type:l||"NodeParagraph",attrs:m||{},pageDividerId:d,pageDividerLayout:g})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,s,n,o){var K,R,$,T,P,ne,Y,q,le;if(this.isLocatingLocked(i))return;let a=t,r=i,l=s;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const se=c.getAttribute("data-node-id");if(se){const oe=await this.resolveBlockAttrs(se,o),_e=Le.getBlockAttrOverride(se)||{},Ie={...oe,..._e};(Ie[qe]||Ie["slides-note"])&&(a=c,r=se,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,h=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((K=u==null?void 0:u.classList)!=null&&K.contains("hr")),d=l==="NodeCodeBlock",g=((R=a.innerText)==null?void 0:R.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Le.getBlockAttrOverride(r)||{},k={...m,...b};let y="",w="";if(h)y=r,w=k[ke]||k["custom-slides-layout"]||"";else{let se=u.previousElementSibling;for(;se;){const oe=se.getAttribute("data-type");if(oe==="NodeThematicBreak"||oe==="tb"||($=se.classList)!=null&&$.contains("hr")){y=se.getAttribute("data-node-id")||"";break}se=se.previousElementSibling}}if(o!=null&&o.slides){const se=[r,f];let oe=a.parentElement;for(;oe&&!oe.classList.contains("protyle-wysiwyg");){const Ie=oe.getAttribute("data-node-id");Ie&&!se.includes(Ie)&&se.push(Ie),oe=oe.parentElement}const _e=o.slides.find(Ie=>{var xe,fe,X;return se.includes(Ie.startBlockId)||((xe=Ie.blocks)==null?void 0:xe.some(ue=>se.includes(ue.id)))||((fe=Ie.allBlockIds)==null?void 0:fe.some(ue=>se.includes(ue)))||((X=Ie.noteBlocks)==null?void 0:X.some(ue=>se.includes(ue.id)))});_e&&(!y&&_e.startBlockId&&(y=_e.startBlockId),!w&&((T=_e.frontmatter)!=null&&T.layout)&&(w=_e.frontmatter.layout))}if(y?(this.lastKnownDocId=n,this.lastKnownPageDividerId=y):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((P=u.parentElement)==null?void 0:P.scrollTop)||0)===0||(y=this.lastKnownPageDividerId)),y){const se=Le.getBlockAttrOverride(y);if(se&&(ke in se||"custom-slides-layout"in se)&&(w=se[ke]||se["custom-slides-layout"]||""),!w&&(o!=null&&o.slides)){const oe=o.slides.find(_e=>_e.startBlockId===y);(ne=oe==null?void 0:oe.frontmatter)!=null&&ne.layout&&(w=oe.frontmatter.layout)}if(!w){const oe=await this.resolveBlockAttrs(y,o);w=oe[ke]||oe["custom-slides-layout"]||"",oe&&Object.keys(oe).length>0&&Le.setBlockAttrOverride(y,oe)}it(y,{[ke]:w||""})}else if(n){const se=Le.getBlockAttrOverride(n);se&&(ke in se||"custom-slides-layout"in se)?w=se[ke]||se["custom-slides-layout"]||"":!w&&((le=(q=(Y=o==null?void 0:o.slides)==null?void 0:Y[0])==null?void 0:q.frontmatter)!=null&&le.layout)&&(w=o.slides[0].frontmatter.layout)}const S=a.getAttribute(ke)||a.getAttribute("custom-slides-layout"),D=k[ke]||k["custom-slides-layout"]||"";S&&S!==D&&it(r,{[ke]:D});const A=a.getAttribute(Ye)||a.getAttribute("custom-slides-role"),C=k[Ye]||k["custom-slides-role"]||"";A&&A!==C&&it(r,{[Ye]:C});let L="",O="",N="";const V=a.closest('[data-type="NodeListItem"]');if(V&&V!==a){const se=V.getAttribute("data-node-id");if(se){L=se;const oe=await this.resolveBlockAttrs(se,o),_e=Le.getBlockAttrOverride(se)||{},Ie={...oe,..._e};O=Ie[Me]||"",N=Ie[Ne]||"";const xe=Ie[ke]||Ie["custom-slides-layout"]||"",fe=V.getAttribute(ke)||V.getAttribute("custom-slides-layout");fe&&fe!==xe&&it(se,{[ke]:xe});const X=Ie[Ye]||Ie["custom-slides-role"]||"",ue=V.getAttribute(Ye)||V.getAttribute("custom-slides-role");ue&&ue!==X&&it(se,{[Ye]:X})}}const _=!!a.querySelector("img, span[data-type='img']"),j=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=_&&j.length<=50;is({id:r,rootId:n,type:l,content:g,attrs:k,isDivider:h,isCode:d,isImage:x,topBlockId:f,pageDividerId:y,pageDividerLayout:w,parentContainerId:L,parentContainerSlot:O,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const s of i.doOperations)if((s==null?void 0:s.action)==="updateAttrs"&&s.id&&s.data){const n=s.data.old||{},o=s.data.new||{},a={};for(const r of Object.keys(n))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");it(s.id,a),Le.setBlockAttrOverride(s.id,a)}}}}purgeStaleDomSlidesAttrs(t){var n,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(l[ke]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[ke]&&(c[ke]=l.ial[ke]),(a=l.ial)!=null&&a[Ye]&&(c[Ye]=l.ial[Ye]),Object.keys(c).length>0&&i.set(l.id,c)}}}const s=Le.getAllAttrOverrides();for(const[r,l]of s.entries()){const c=i.get(r)||{};l[ke]!==void 0&&(c[ke]=l[ke]),l[Ye]!==void 0&&(c[Ye]=l[Ye]),i.set(r,c)}Iw(i)}}const Mi=new x2;class S2{constructor(){be(this,"state","IDLE");be(this,"inFlightDocId",null);be(this,"pendingDocs",new Set);be(this,"lastPendingDocId",null);be(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const C2=150,_2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,$2="slides-dock",xo="slides-preview-tab",Ea="slides-presenter-tab",Aa=ap;class I2 extends ae.Plugin{constructor(){super(...arguments);be(this,"isMobile",!1);be(this,"currentDocId","");be(this,"previewTab",null);be(this,"latestCompiledDoc",null);be(this,"cliBridge",new vr);be(this,"debounceTimer",null);be(this,"activeCursorBlockId","");be(this,"cancelledCursorBlockId","");be(this,"compileScheduler",new S2);be(this,"dirtyDocId",null);be(this,"inspectorSyncThrottle",new w2);be(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));be(this,"onWsMainBound",this.onWsMain.bind(this));be(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));be(this,"onEditorClickBound",this.onEditorClick.bind(this));be(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));be(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));be(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ae.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(_2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),b2(this);const s=this;if(this.addTab({type:xo,init(n){var r;const o=this||n;s.previewTab=(o==null?void 0:o.tab)||null,d2(o.element,s);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!s.getActiveDocumentId()&&s.compileCurrentDocument(a,{reason:"explicit"}),s.updatePreviewTabHeader()},destroy(){s.previewTab===(this==null?void 0:this.tab)&&(s.previewTab=null),Mc(this.element)}}),this.addTab({type:Ea,init(n){f2((this||n).element,s)},destroy(){Tc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:$2,init(){h2(this.element,s)},destroy(){Ec(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Aa),s=lp(i);return ui(s),s}catch{return ui(Li),Li}}async saveGlobalSettings(i){const s=Qn(),n=ui({...s,...i||{}});try{await this.saveData(Aa,n)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,wn.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),Ss.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(i);await ae.openTab({app:this.app,custom:{id:this.name+xo,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){fi("presenterMode")||(u2()||await this.openBottomPreviewTab(),await ae.openTab({app:this.app,custom:{id:this.name+Ea,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ae.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let s=this.previewTab;if(!s){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(n),a=await ae.openTab({app:this.app,custom:{id:this.name+xo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});s=this.previewTab||a}s&&(this.currentDocId&&s.model&&(s.model.data={...s.model.data||{},docId:this.currentDocId}),ae.openWindow({tab:s,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const s=(a=i.detail)==null?void 0:a.protyle,n=(r=s==null?void 0:s.block)==null?void 0:r.rootID,o=((u=(c=(l=s==null?void 0:s.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const f=await Ko(n).catch(()=>({}));is({id:n,rootId:n,type:"doc",attrs:f}),this.markCompileDirty(n),this.updatePreviewTabHeader(o,n)}}onClickEditorContent(i){var o,a;const s=i==null?void 0:i.detail;if(!s)return;const n=(a=(o=s.protyle)==null?void 0:o.block)==null?void 0:a.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}buildPreviewTabTitle(i){return pc(i)}async fetchDocumentTitle(i){return hc(this,i)}async updatePreviewTabHeader(i,s){return Dg(this,i,s)}getActiveDocumentId(){return Mi.getActiveDocumentId()}resolveDocIdFromElement(i){return Mi.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,s){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Mi.switchToDocGlobalInspector(i,s))}onWsMain(i){const s=i.detail;s&&s.cmd==="transactions"&&(Mi.patchThematicBreakTransactions(s),this.markCompileDirty())}markCompileDirty(i){const s=i||this.currentDocId||this.getActiveDocumentId();s&&(this.currentDocId||(this.currentDocId=s),this.dirtyDocId=s,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=C2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const s=wn.getVisibility();if(s==="none")return;const n=s==="visible"?i:Math.max(i,o2);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,s){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Mi.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,s)}onBlockClickedFromSlide(i){const s=(i==null?void 0:i.detail)||i;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(i){const s=i.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const f=n||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=f==null?void 0:f.querySelector(".protyle-title__input"),d=((h==null?void 0:h.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,qo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const s=i.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const o=n.closest(".protyle-title");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const f=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=f==null?void 0:f.querySelector(".protyle-title__input"),d=((h==null?void 0:h.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(Mi.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,qo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,s,n){this.inspectorSyncThrottle.shouldSkip(s)||await Mi.syncInspectorBlock(i,s,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,s){const n=(s==null?void 0:s.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(n==="auto"&&wn.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Le.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,m2(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){Mi.purgeStaleDomSlidesAttrs(i)}}module.exports=I2;
