"use strict";var aa=Object.create;var ys=Object.defineProperty;var ca=Object.getOwnPropertyDescriptor;var da=Object.getOwnPropertyNames;var ua=Object.getPrototypeOf,fa=Object.prototype.hasOwnProperty;var pa=(t,i,e)=>i in t?ys(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var ha=(t,i,e,s)=>{if(i&&typeof i=="object"||typeof i=="function")for(let n of da(i))!fa.call(t,n)&&n!==e&&ys(t,n,{get:()=>i[n],enumerable:!(s=ca(i,n))||s.enumerable});return t};var Mn=(t,i,e)=>(e=t!=null?aa(ua(t)):{},ha(i||!t||!t.__esModule?ys(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>pa(t,typeof i!="symbol"?i+"":i,e);const vt=require("siyuan");async function me(t,i){const e=await vt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ma(){return me("/api/notebook/lsNotebooks","")}async function ga(t,i,e){return me("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function va(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const n of i)e.append("file[]",n);return me("/api/asset/upload",e)}async function sn(t,i,e,s,n){return me("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:s,parentID:n})}async function _r(t,i,e){return me("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Po(t,i,e){return me("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ba(t){return me("/api/block/deleteBlock",{id:t})}async function ya(t){return me("/api/block/getBlockKramdown",{id:t})}async function qn(t){return me("/api/block/getChildBlocks",{id:t})}async function zt(t,i){return me("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ye(t){return me("/api/attr/getBlockAttrs",{id:t})}async function vn(t){return me("/api/query/sql",{stmt:t})}async function Ls(t,i,e){const s=new FormData;return s.append("path",t),s.append("isDir",i.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",e),me("/api/file/putFile",s)}async function Sr(t){const i="/api/ai/chatGPT";try{const e=await me(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function ka(){return me("/api/storage/getInlineStyles","")}const ln="custom-slidev-theme",an="custom-slidev-aspect-ratio",Cr="custom-slidev-highlighter",cn="custom-slidev-default-transition",$r="custom-slidev-color-schema",Si="custom-slidev-slide",ft="custom-slidev-layout",Xt="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Fi="custom-slidev-notes",ji="custom-slidev-class",Ce="custom-slidev-click",We="custom-slidev-motion",$i="custom-slidev-shiki-lines",Tt="custom-slidev-slot",ie="custom-slidev-note",qt="custom-slidev-role",dn="custom-slidev-max-height",yi="custom-slidev-autoplay",Bn="custom-slidev-loop",Li="custom-slidev-muted",Dn="custom-slidev-controls",Ir="background",Rs="image-left",zs="image-right",Ri={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto"};function wa(t){var i,e,s,n,r;return t?{theme:((i=t[ln])==null?void 0:i.trim())||Ri.theme,aspectRatio:((e=t[an])==null?void 0:e.trim())||Ri.aspectRatio,highlighter:((s=t[Cr])==null?void 0:s.trim())||Ri.highlighter,defaultTransition:((n=t[cn])==null?void 0:n.trim())||Ri.defaultTransition,colorSchema:((r=t[$r])==null?void 0:r.trim())||Ri.colorSchema}:{...Ri}}function Gn(t){var e,s,n,r,l;const i=(e=t.ial)==null?void 0:e[Si];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((s=t.markdown)==null?void 0:s.trim())==="---"||((n=t.markdown)==null?void 0:n.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Lo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ft]&&(i.layout=t[ft].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ee]&&(i.image=t[Ee].trim()),t[ji]&&(i.class=t[ji].trim()),t[Fi]&&(e=t[Fi].trim());for(const[s,n]of Object.entries(t))if(s.startsWith("custom-slidev-")&&![ft,Xt,Ut,Ee,ji,Fi,Si].includes(s)){const r=s.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(n)}catch{i[r]=n}}return{frontmatter:i,notes:e}}function xa(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const s=t[qt]??t["slidev-role"],n=t[Ut]??t["slidev-background"];(s===Ir||n==="true"||n==="1")&&(i.isBackground=!0);const r=t[ft]??t["slidev-layout"];r===Rs||r===zs?i.imageLayout=r:(s===Rs||s===zs)&&(i.imageLayout=s);const l=t[Ce]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[We])try{const o=JSON.parse(t[We]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[We].trim()}}return t[$i]&&(i.shikiLines=t[$i].trim()),t[dn]&&(i.maxHeight=t[dn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function _a(t,i){const e=[];let n=0;for(let r=0;r<t.length;r++){const l=t[r];if(Gn(l)){n=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),n=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),n=0;continue}}if(n++,n>=6&&r<t.length-1){const c=t[r+1];Gn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n=0)}}return e}function Ro(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const s=[],n=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?s.push(o.replace(/^#+\s*/,"")):n.push(o.slice(0,50)))}const r=[];return s.length>0&&r.push(`【核心重点】：${s.join("、")}`),n.length>0&&(r.push("【口播要点】："),n.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Ar(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const n=await i(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Ro(t),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Ro(t),isAiGenerated:!1}}async function Sa(t,i){return(await Ar(t,i)).notes}const Tr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ca(t){const i=[];if(!t)return i;const e=new RegExp(Tr.source,"g");let s;for(;(s=e.exec(t))!==null;){const n=s[2]??s[3]??s[4];i.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return i}function $a(t,i){if(!t)return"";const e=new RegExp(Tr.source,"g");return t.replace(e,(s,n,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[n]){const d=i[n].trim();return`<div class="slidev-block-ref" data-ref-id="${n}">${d}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slidev-ref-tag">🔗 ${c}</a>`})}function Ia(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Aa(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}function Ta(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Ea(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Se(t,i){if(!Ta(t))return t;const e=Ea(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ma(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,r)=>{const l=Se(r,i);return`![${n}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,r,l)=>{const o=Se(r,i);return`${n}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,r,l)=>{const o=Se(r,i);return`${n}${o}${l}`}),e}function hi(t,i){const e=(t||i||"").trim();if(!e)return null;const s=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function de(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Di(t){if(!de(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const s=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(t.children&&t.children.length>0){for(const s of t.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function ye(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Ns(t){return!t||ye(t)||de(t)||!hi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function mi(t){if(!t||!de(t)||!Di(t))return null;const i=(t.children||[]).filter(n=>{const r=n.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(n.markdown||n.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Ns(i[0]),s=Ns(i[i.length-1]);if(e&&!s){const n=hi(i[0].markdown,i[0].content);if(n)return{imageNode:i[0],imageUrl:n,layout:Rs,contentNodes:i.slice(1)}}if(!e&&s){const n=hi(i[i.length-1].markdown,i[i.length-1].content);if(n)return{imageNode:i[i.length-1],imageUrl:n,layout:zs,contentNodes:i.slice(0,i.length-1)}}return null}function Ba(t,i){const e=[];function s(n){for(const r of n){const l=mi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ft];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ft]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&s(r.children)}}return s(t),e}function to(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const s=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function Da(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Fe(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],s=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return t;const n=s[1].length,r=s[2].trim(),l=e.length-s[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),h=d?d[1].length:0;h>=l?o.push(c.slice(l)):h>n?o.push(c.slice(h)):o.push(c)}return o.join(`
`)}function Ci(t){if(!t)return[];if(de(t)&&Di(t)&&!mi(t)){const s=to(t),n=[];for(const r of s)n.push(...Ci(r));return n}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(ye);if(l.length>0)return l}const n=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:n.length,d=n.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return ye(t)?[t]:[]}function Er(t){var s;if(!t||!de(t)||!Di(t)||mi(t))return null;const i=to(t);if(i.length===0)return null;if(i.length===1&&de(i[0])&&Di(i[0])){const n=Er(i[0]);return n?{items:n.items,nestedSuperBlocks:[i[0],...n.nestedSuperBlocks]}:null}const e=[];for(const n of i)if(de(n)){e.push(n);const r=((s=n.children)==null?void 0:s.filter(de))||[];e.push(...r)}if(i.length===3){const n=Ci(i[0]),r=Ci(i[1]),l=Ci(i[2]);if(n.length===1&&r.length===1&&l.length===1)return{items:[n[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const n=Ci(i[0]),r=Ci(i[1]);if(n.length===2&&r.length===1)return{items:[n[0],n[1],r[0]],nestedSuperBlocks:e};if(n.length===1&&r.length===2)return{items:[n[0],r[0],r[1]],nestedSuperBlocks:e};if(n.length===1&&r.length===1)return{items:[n[0],r[0]],nestedSuperBlocks:e}}return null}function Oa(t){if(!t||!de(t)||!Di(t)||mi(t))return null;const i=Er(t);if(!i)return null;const{items:e,nestedSuperBlocks:s}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:s,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:s,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Pa(t){if(!t||!de(t)||!Di(t)||mi(t))return null;const i=to(t);if(i.length===0)return null;const e=[];for(const s of i){const n=Ci(s);if(n.length===0)return null;e.push(...n)}return e}function La(t){if(!t||!de(t)||!Di(t)||mi(t))return null;const i=Pa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Ra(t,i,e){var d,h,g,u,k;const s=[],n=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let p=0;p<i.length;p++){const b=i[p];if(Gn(b)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=b.id,o.blocks.push(b);continue}o={pageTargetId:b.id,blocks:[b]},l.push(o)}else o.blocks.push(b)}function a(p){const b=[];for(const v of p)de(v)&&b.push(v),v.children&&v.children.length>0&&b.push(...a(v.children));return b}function c(p,b,v){const y={blockId:p,attrs:b,previousAttrs:v};s.push(y),e!=null&&e.onTagChange&&e.onTagChange(y)}for(const p of l){const b=p.pageTargetId,v=i.find(C=>C.id===b),y=r.find(C=>C.pageTargetId===b);if(p.blocks.some(C=>{var A,E;return!!(mi(C)||Ns(C)&&(((A=C.ial)==null?void 0:A[ft])==="image-left"||((E=C.ial)==null?void 0:E[ft])==="image-right"))})){if(y){const C=y.headerId;if(C){c(C,{[Tt]:""});const A=i.find(E=>E.id===C);A!=null&&A.ial&&(A.ial[Tt]="")}for(const A of y.itemIds){c(A,{[Tt]:""});const E=i.find(D=>D.id===A);E!=null&&E.ial&&(E.ial[Tt]="")}}continue}let I=null,x=-1;for(let C=0;C<p.blocks.length;C++){const A=p.blocks[C],E=de(A)?[A,...a(A.children||[])]:A.children?a(A.children):[];for(const D of E){const R=Oa(D);if(R){I=R,x=C;break}}if(I)break}if(I){const{superBlockNode:C,layout:A,items:E,slots:D}=I,X=p.blocks.slice(0,x).find(z=>Da(z)),T=X==null?void 0:X.id,O=((d=v==null?void 0:v.ial)==null?void 0:d[ft])||"";if(O!==A&&(c(b,{[ft]:A},{[ft]:O}),v&&(v.ial||(v.ial={}),v.ial[ft]=A)),X){const z=((h=X.ial)==null?void 0:h[Tt])||"";z!=="header"&&(c(X.id,{[Tt]:"header"},{[Tt]:z}),X.ial||(X.ial={}),X.ial[Tt]="header")}if(y!=null&&y.headerId&&y.headerId!==T){c(y.headerId,{[Tt]:""});const z=i.find(Q=>Q.id===y.headerId);z&&(z.ial||(z.ial={}),z.ial[Tt]="")}const w=[];for(let z=0;z<E.length;z++){const Q=E[z],j=D[z];w.push(Q.id);const at=((g=Q.ial)==null?void 0:g[Tt])||"";if(at!==j&&(c(Q.id,{[Tt]:j},{[Tt]:at}),Q.ial||(Q.ial={}),Q.ial[Tt]=j),Q.children&&Q.children.length>0)for(const W of Q.children)W.ial||(W.ial={}),W.ial[Tt]!==j&&(W.ial[Tt]=j)}if(y!=null&&y.itemIds){for(const z of y.itemIds)if(!w.includes(z)){c(z,{[Tt]:""});const Q=i.find(j=>j.id===z);Q&&(Q.ial||(Q.ial={}),Q.ial[Tt]="")}}n.push({superBlockId:C.id,nestedSuperBlockIds:(u=I.nestedSuperBlocks)==null?void 0:u.map(z=>z.id),pageTargetId:b,headerId:T,itemIds:w,layout:A})}else{let C=!1;const A=[];for(const R of p.blocks){const X=de(R)?[R,...a(R.children||[])]:R.children?a(R.children):[];for(const T of X){const O=La(T);if(O){C=!0;for(const w of O.items)A.push(w.id)}}}const E=((k=v==null?void 0:v.ial)==null?void 0:k[ft])||"";if(y||C&&(E==="two-cols-header"||E==="three-cols-header")){c(b,{[ft]:""},{[ft]:E}),v&&(v.ial||(v.ial={}),v.ial[ft]="");const R=y==null?void 0:y.headerId;if(R){c(R,{[Tt]:""});const T=i.find(O=>O.id===R);T&&(T.ial||(T.ial={}),T.ial[Tt]="")}const X=new Set([...(y==null?void 0:y.itemIds)||[],...A]);for(const T of X){c(T,{[Tt]:""});const O=i.find(w=>w.id===T);O&&(O.ial||(O.ial={}),O.ial[Tt]="")}}}}return{changes:s,newTracked:n}}function ki(t,i,e){let s="",n=0;const r=/<div\b([^>]*)>/gi;for(;n<t.length;){r.lastIndex=n;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const y=v[1];if(typeof i=="string"?y.split(/\s+/).includes(i):i.test(y)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){s+=t.slice(n);break}s+=t.slice(n,a);const d=a+c;let h=1,g=-1,u=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let p;for(;(p=k.exec(t))!==null;)if(p[0].startsWith("</")){if(h--,h===0){g=p.index,u=p.index+p[0].length;break}}else h++;if(g!==-1&&u!==-1){const b=t.slice(d,g);s+=e(b),n=u}else s+=t.slice(a,d),n=d}return s}function za(t){const i=[];let e="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<t.length;){n.lastIndex=s;let r,l=!1,o=-1,a=0;for(;(r=n.exec(t))!==null;){const p=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(p)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(s);break}e+=t.slice(s,o);const c=o+a;let d=1,h=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let k;for(;(k=u.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){h=k.index,g=k.index+k[0].length;break}}else d++;if(h!==-1&&g!==-1){const p=t.slice(o,g),b=`__VUE_DIV_TOKEN_${i.length}__`;i.push(p),e+=b,s=g}else e+=t.slice(o,c),s=c}return{text:e,tokens:i}}function Na(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const s=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${s.length}__`;return s.push(o),a});const{text:n,tokens:r}=za(e);e=n;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=ki(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),h=c[3].trim();return`**${d}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:o}),e=ki(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=ki(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let h="-";return d.includes("warn")?h="- ⚠️":d.includes("bad")?h="- ❌":d.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=ki(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=ki(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=ki(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=ki(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,g)=>Math.max(h,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,h)=>{const g=h.trim();return g.includes("<")||g.includes(`
`)?o:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<s.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,s[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Mr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,s=>(i.push(s),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>i[parseInt(n,10)]||""),e}function Fa(t){const i=Object.entries(t).filter(([s,n])=>n!=null&&n!=="");return i.length===0?"":`---
${i.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function ja(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const s=t.slice(0,e).trim(),n=t.slice(e);return s.includes("{")?t:`${s} {${i}}${n}`}function Ha(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Ua(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},s={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},s={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(s={...s,...t.enter});const n={...s.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(n.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(n.delay=t.delay),Object.keys(n).length>0&&(s.transition=n),{initial:e,enter:s}}function ks(t,i,e,s){const n=i!=null&&i.trim()!=="",r=Ua(e),l=s==null?void 0:s.trim(),o=l!==void 0&&l!=="",a=o?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!n&&!r)return o?`<div${a}>

${t}

</div>`:t;if(n&&!r){if(o){const k=i.trim();let p="v-click";return k==="hide"?p="v-click.hide":k!==""&&k!=="+1"&&(p=`v-click="${k}"`),`<div ${p}${a}>

${t}

</div>`}return Ha(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),h=`v-motion :initial="${c}" :enter="${d}"`;if(!n)return`<div ${h}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${h}${a}>

${t}

</div>`}function Br(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let n=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Wa(t){var s;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(s=t.ial)!=null&&s.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Dr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],h=[],g=[];let u=1;for(const k of t){const p=i(k);p!==null&&(u=p),u===1?d.push(k):u===2?h.push(k):g.push(k)}return{col1:d,col2:h,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const n=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>n(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),k=a.slice(c[0],c[g]).join(`
`),p=a.slice(c[g],c[g+u]).join(`
`),b=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p,content:p}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),k=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,p=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,b=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p,content:p}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const h=o.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(h.length>=3){const g=Math.ceil(h.length/3),u=Math.ceil((h.length-g)/2);return{col1:[{...l,rawMarkdown:h.slice(0,g).join(`

`),content:h.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h.slice(g,g+u).join(`

`),content:h.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:h.slice(g+u).join(`

`),content:h.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function zo(t,i,e,s){var d;const n=wa(i),r=[],l=Lo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=Se(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=Se(o.frontmatter.image,s)),r.push(o);let a=[];for(const h of e){if(Gn(h)){a=[];const u=Lo(h.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=h.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(h.id)||o.allBlockIds.push(h.id),u.frontmatter.layout&&(o.frontmatter.layout=u.frontmatter.layout),Object.assign(o.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=Se(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=Se(o.frontmatter.image,s));continue}o={pageIndex:r.length+1,startBlockId:h.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[h.id]},o.frontmatter.background&&(o.frontmatter.background=Se(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=Se(o.frontmatter.image,s)),r.push(o);continue}const g=u=>{if(o.allBlockIds||(o.allBlockIds=[]),u.id&&!o.allBlockIds.includes(u.id)&&o.allBlockIds.push(u.id),u.children&&u.children.length>0){const O=w=>{for(const z of w)z.id&&!o.allBlockIds.includes(z.id)&&o.allBlockIds.push(z.id),z.children&&z.children.length>0&&O(z.children)};O(u.children)}let k=Ia(u),p=u.ial?{...u.ial}:{};const b=k.match(/\{:\s*([^}]+)\s*\}\s*$/);b&&(p={...Aa(b[0]),...p},k=k.slice(0,b.index).trim()),u.type!=="c"&&!k.startsWith("```")&&(k=Mr(k));let v=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(v)||v==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(v)&&/\r?\n\}\}\}$/.test(v)&&(k=v.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),v=k.trim());const y=xa(p);if(k=Ma(k,s),k=$a(k,s==null?void 0:s.refContentMap),u.children&&u.children.length>0){const O=w=>{for(const z of w){if(z.ial)for(const[Q,j]of Object.entries(z.ial))Q.startsWith("custom-slidev-")&&!p[Q]&&(p[Q]=j);z.children&&z.children.length>0&&O(z.children)}};O(u.children)}const S=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(k);if(S){const O=p["custom-slidev-autoplay"]==="true",w=p["custom-slidev-loop"]==="true",z=p["custom-slidev-muted"]==="true"||O,Q=p["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(j,at)=>{let W=at;return Q?W=W.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(W)||(W+=" controls"),O&&!/autoplay/i.test(W)?W+=" autoplay playsinline":!O&&p["custom-slidev-autoplay"]==="false"&&(W=W.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),w&&!/loop/i.test(W)?W+=" loop":!w&&p["custom-slidev-loop"]==="false"&&(W=W.replace(/\bloop\b/gi,"").trim()),z&&!/muted/i.test(W)?W+=" muted":!z&&p["custom-slidev-muted"]==="false"&&(W=W.replace(/\bmuted\b/gi,"").trim()),`<video ${W.trim()}>`})}if(y.isBackground){const O=hi(k,u.content);if(O){o.frontmatter.background=Se(O,s);return}}const I=mi(u);if(I){o.frontmatter.layout=I.layout,o.frontmatter.image=Se(I.imageUrl,s);for(const O of I.contentNodes)g(O);return}if(y.imageLayout==="image-left"||y.imageLayout==="image-right"){const O=hi(k,u.content);if(O){o.frontmatter.layout=y.imageLayout,o.frontmatter.image=Se(O,s);return}}if(de(u)&&u.children&&u.children.length>0){for(const O of u.children)g(O);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(O=>{var w;return(w=O.ial)==null?void 0:w[Tt]})||y.slot)){for(const O of u.children)y.slot&&(!O.ial||!O.ial[Tt])&&(O.ial||(O.ial={}),O.ial[Tt]=y.slot),g(O);return}if(y.isNote){const O=Br(k);O&&(o.notes?o.notes+=`

`+O:o.notes=O),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:u.id,type:u.type,content:O||u.content||"",rawMarkdown:k,isNote:!0,attributes:u.ial});return}y.shikiLines&&(k=ja(k,y.shikiLines)),v=k.trim();const x=(u.content||"").trim();if(v==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(v)||v.startsWith("::right::")){o.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const A=Wa(u);let E=y.slot,D=y.clicks,R=y.motion,X={...u.ial||{}};if(A!==null){for(;a.length>0&&a[a.length-1].level>=A;)a.pop();const O=a.length>0?a[a.length-1]:void 0;!E&&(O!=null&&O.slot)&&(E=O.slot),!D&&(O!=null&&O.clicks)&&(D=O.clicks),!R&&(O!=null&&O.motion)&&(R=O.motion);const w={...(O==null?void 0:O.customAttrs)||{}};if(u.ial)for(const[z,Q]of Object.entries(u.ial))z.startsWith("custom-slidev-")&&!z.startsWith("custom-slidev-slide")&&(w[z]=Q);a.push({level:A,slot:E,clicks:D,motion:R,customAttrs:w})}else{const O=a.length>0?a[a.length-1]:void 0;O&&(!E&&O.slot&&O.slot!=="header"&&(E=O.slot),!D&&O.clicks&&(D=O.clicks),!R&&O.motion&&(R=O.motion),O.customAttrs&&(X={...O.customAttrs,...X}))}!E&&o.blocks.some(O=>O.slot==="slot-divider-right")&&(E="right"),E&&(X[Tt]=E),D&&!X[Ce]&&(X[Ce]=D),R&&!X[We]&&(X[We]=JSON.stringify(R)),(S||p["custom-slidev-autoplay"]||p["custom-slidev-muted"])&&(p["custom-slidev-autoplay"]&&(X["custom-slidev-autoplay"]=p["custom-slidev-autoplay"],p["custom-slidev-autoplay"]==="true"&&!p["custom-slidev-muted"]&&(X["custom-slidev-muted"]="true")),p["custom-slidev-loop"]&&(X["custom-slidev-loop"]=p["custom-slidev-loop"]),p["custom-slidev-muted"]&&(X["custom-slidev-muted"]=p["custom-slidev-muted"]),p["custom-slidev-controls"]&&(X["custom-slidev-controls"]=p["custom-slidev-controls"]));const T={id:u.id,type:u.type,content:u.content||"",rawMarkdown:k,clicks:D,motion:R,shikiLines:y.shikiLines,slot:E,attributes:X};o.blocks.push(T)};g(h)}for(let h=0;h<r.length;h++){const g=r[h],u=[],k={...g.frontmatter};h===0&&(k.theme=n.theme,k.aspectRatio=n.aspectRatio,k.highlighter=n.highlighter,k.transition=g.frontmatter.transition||n.defaultTransition);const p=Fa(k);p&&u.push(p);const b=g.blocks.filter(I=>I.slot!=="slot-divider-right"),v=I=>I.map(x=>{var C;return ks(x.rawMarkdown,x.clicks,x.motion,(C=x.attributes)==null?void 0:C.style)}).join(`

`),y=I=>{var x;if(I.length===0)return"";if(I.length===1&&ye(I[0])){const C=Fe(I[0].rawMarkdown);return ks(C,I[0].clicks,I[0].motion,(x=I[0].attributes)==null?void 0:x.style)}return v(I)},S=g.frontmatter.layout||"default";if(S==="two-cols-header"){let I=[];const x=b.filter(T=>T.slot==="header");if(x.length>0)I=x;else if(b.length>0){const T=b.find(O=>O.type==="h"&&(!O.slot||O.slot==="default"));T&&(I=[T])}const C=b.filter(T=>!I.includes(T)),A=C.filter(T=>T.slot==="right"||T.slot==="col-2"),E=C.filter(T=>!A.includes(T));E.length===1&&ye(E[0])&&(E[0].rawMarkdown=Fe(E[0].rawMarkdown)),A.length===1&&ye(A[0])&&(A[0].rawMarkdown=Fe(A[0].rawMarkdown));const D=v(I),R=y(E),X=y(A);D&&u.push(D),R&&u.push(`::left::

${R}`),X&&u.push(`::right::

${X}`)}else if(S==="three-cols-header"){let I=[];const x=b.filter(z=>z.slot==="header");if(x.length>0)I=x;else if(b.length>0){const z=b.find(Q=>Q.type==="h"&&(!Q.slot||Q.slot==="default"));z&&(I=[z])}const C=b.filter(z=>!I.includes(z)),A=Dr(C),E=A.col1,D=A.col2,R=A.col3;for(const z of E)z.slot||(z.slot="col-1");for(const z of D)z.slot||(z.slot="col-2");for(const z of R)z.slot||(z.slot="col-3");if(E.length===1&&ye(E[0])&&(E[0].rawMarkdown=Fe(E[0].rawMarkdown)),D.length===1&&ye(D[0])&&(D[0].rawMarkdown=Fe(D[0].rawMarkdown)),R.length===1&&ye(R[0])&&(R[0].rawMarkdown=Fe(R[0].rawMarkdown)),C.length===1&&(D.length>0||R.length>0)){const z=g.blocks.findIndex(Q=>Q.id===C[0].id);z!==-1&&g.blocks.splice(z,1,...E,...D,...R)}const X=v(I),T=y(E),O=y(D),w=y(R);X&&u.push(X),T&&u.push(`::col-1::

${T}`),O&&u.push(`::col-2::

${O}`),w&&u.push(`::col-3::

${w}`)}else if(S==="two-cols"){const I=b.filter(E=>E.slot==="left"),x=b.filter(E=>E.slot==="right");I.length===1&&ye(I[0])&&(I[0].rawMarkdown=Fe(I[0].rawMarkdown)),x.length===1&&ye(x[0])&&(x[0].rawMarkdown=Fe(x[0].rawMarkdown));const C=v(I.length>0?I:b.filter(E=>E.slot!=="right")),A=v(x);u.push(C),A&&u.push(`::right::

${A}`)}else for(const I of b)u.push(ks(I.rawMarkdown,I.clicks,I.motion,(d=I.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(h=>h.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:n,slides:r,fullMarkdown:c}}const Fs=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Va(t){var n,r,l,o,a,c,d,h,g,u,k,p;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const b of t.styles){if(!b||!b.id)continue;const v=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&i.push(`  ${v}-color: ${b.light.color};`),(r=b.light)!=null&&r.backgroundColor&&i.push(`  ${v}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&e.push(`  ${v}-color: ${b.dark.color};`),(o=b.dark)!=null&&o.backgroundColor&&e.push(`  ${v}-background-color: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const b of t.builtin.colors){if(!b||typeof b.index!="number")continue;const v=b.index;(a=b.light)!=null&&a.color&&i.push(`  --b3-font-color${v}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${v}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&e.push(`  --b3-font-color${v}: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&e.push(`  --b3-font-background${v}: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const b of t.builtin.styles){if(!b||!b.id)continue;const v=b.id;(g=b.light)!=null&&g.color&&i.push(`  --b3-card-${v}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${v}-background: ${b.light.backgroundColor};`),(k=b.dark)!=null&&k.color&&e.push(`  --b3-card-${v}-color: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&e.push(`  --b3-card-${v}-background: ${b.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const s=[];return i.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),s.join(`

`)}function un(t){const i=Va(t);return i?`${Fs}

/* Custom Workspace Inline Styles */
${i}`:Fs}function ws(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}const Ka={getBlockAttrs:Ye,getChildBlocks:qn,setBlockAttrs:zt,sql:vn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ka};class qa{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...Ka,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const n={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete n[r]:n[r]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,n)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const s=this.attrOverrides.get(i);s&&(delete s[e],Object.keys(s).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},s=this.attrOverrides.get(i);s&&Object.assign(e,s);let n=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const S of l)S.id&&S.ial&&o.set(S.id,ws(S.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const S of c)if(S.block_id&&S.name){let I=o.get(S.block_id);I||(I={},o.set(S.block_id,I)),I[S.name]=S.value||""}}if(!n||n.length===0){const S=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;n=await this.deps.sql(S).catch(()=>[])||[]}const d=(n||[]).map(S=>{const I=o.get(S.id)||(S.ial?ws(S.ial):{}),x=this.attrOverrides.get(S.id);return x&&Object.assign(I,x),{id:S.id,parent_id:S.parent_id,root_id:S.root_id||i,type:S.type,subType:S.subType,content:S.content||"",markdown:S.markdown||"",ial:I,children:S.children}}),h=async(S,I=0)=>{if(!(!S||S.length===0||I>8))for(const x of S){if((de(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let A=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!A||A.length===0){const E=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;A=await this.deps.sql(E).catch(()=>[])||[]}Array.isArray(A)&&A.length>0&&(x.children=A.map(E=>{const D=o.get(E.id)||(E.ial?ws(E.ial):{}),R=this.attrOverrides.get(E.id);return R&&Object.assign(D,R),{id:E.id,parent_id:E.parent_id||x.id,root_id:E.root_id||i,type:E.type,subType:E.subType,content:E.content||"",markdown:E.markdown||"",ial:D}}))}x.children&&x.children.length>0&&await h(x.children,I+1)}};await h(d);const g=S=>{var I,x;for(const C of S)if(C.children&&C.children.length>0){g(C.children);for(const A of C.children)if(A.ial)for(const[E,D]of Object.entries(A.ial))E.startsWith("custom-slidev-")&&!((I=C.ial)!=null&&I[E])&&(C.ial||(C.ial={}),C.ial[E]=D);if(C.ial){for(const[A,E]of Object.entries(C.ial))if(A.startsWith("custom-slidev-"))for(const D of C.children)(D.type==="video"||D.type==="NodeVideo"||/<video\b/i.test(D.markdown||D.content||""))&&!((x=D.ial)!=null&&x[A])&&(D.ial||(D.ial={}),D.ial[A]=E)}}};g(d),Ba(d,S=>{this.setBlockAttrOverride(S.blockId,{[ft]:S.layout}),(this.deps.setBlockAttrs||zt)(S.blockId,{[ft]:S.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],k=Ra(i,d,{tracked:u,onTagChange:S=>{this.setBlockAttrOverride(S.blockId,S.attrs),S.blockId===i&&Object.assign(e,S.attrs);const I=C=>{for(const A of C)A.id===S.blockId&&(A.ial||(A.ial={}),Object.assign(A.ial,S.attrs)),A.children&&A.children.length>0&&I(A.children)};I(d),(this.deps.setBlockAttrs||zt)(S.blockId,S.attrs).catch(C=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",C)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const p=new Set;for(const S of d){const I=S.markdown||S.content||"";if(I.includes("((")){const x=Ca(I);for(const C of x)p.add(C.blockId)}}const b={};if(p.size>0){const S=Array.from(p).map(x=>`'${x}'`).join(","),I=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${S})`).catch(()=>[])||[];if(Array.isArray(I))for(const x of I)x.id&&(b[x.id]=x.markdown||x.content||"")}const v=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=zo(i,e,d,{baseUrl:v,refContentMap:b});try{const S=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=un(S)}catch{y.customThemeCss=un(null)}return y}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const s=zo(i,{},[],{});return s.customThemeCss=un(null),s}}}const Ht=new qa;class eo{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,s=setTimeout(()=>e.abort(),i),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,s=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&s.push(`colorSchema: ${e.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let h="";c.length>0?h=d?"":`---
${c.join(`
`)}
---

`:d||(h=`---

`);let g="";if(a.layout==="two-cols"){const k=l.blocks.filter(y=>y.slot!=="right"),p=l.blocks.filter(y=>y.slot==="right"),b=k.map(y=>y.rawMarkdown||y.content||"").join(`

`),v=p.map(y=>y.rawMarkdown||y.content||"").join(`

`);g=`${b}

::right::

${v}`}else g=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${h}${g}${u}`}).join(`

`);return`${n}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",s){const n=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),s)try{const r=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(i),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function io(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},Hi=[],qe=()=>{},Or=()=>!1,ss=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),os=t=>t.startsWith("onUpdate:"),re=Object.assign,no=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},Ga=Object.prototype.hasOwnProperty,Rt=(t,i)=>Ga.call(t,i),Ct=Array.isArray,Ui=t=>Cn(t)==="[object Map]",Xi=t=>Cn(t)==="[object Set]",No=t=>Cn(t)==="[object Date]",It=t=>typeof t=="function",Qt=t=>typeof t=="string",Oe=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Pr=t=>(jt(t)||It(t))&&It(t.then)&&It(t.catch),Lr=Object.prototype.toString,Cn=t=>Lr.call(t),Za=t=>Cn(t).slice(8,-1),Rr=t=>Cn(t)==="[object Object]",so=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=io(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),rs=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Ya=/-\w/g,he=rs(t=>t.replace(Ya,i=>i.slice(1).toUpperCase())),Ja=/\B([A-Z])/g,gi=rs(t=>t.replace(Ja,"-$1").toLowerCase()),ls=rs(t=>t.charAt(0).toUpperCase()+t.slice(1)),xs=rs(t=>t?`on${ls(t)}`:""),Ve=(t,i)=>!Object.is(t,i),Hn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},zr=(t,i,e,s=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:s,value:e})},as=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Fo;const cs=()=>Fo||(Fo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function oo(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const s=t[e],n=Qt(s)?ec(s):oo(s);if(n)for(const r in n)i[r]=n[r]}return i}else if(Qt(t)||jt(t))return t}const Xa=/;(?![^(]*\))/g,Qa=/:([^]+)/,tc=/\/\*[^]*?\*\//g;function ec(t){const i={};return t.replace(tc,"").split(Xa).forEach(e=>{if(e){const s=e.split(Qa);s.length>1&&(i[s[0].trim()]=s[1].trim())}}),i}function Et(t){let i="";if(Qt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const s=Et(t[e]);s&&(i+=s+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const ic="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",nc=io(ic);function Nr(t){return!!t||t===""}function sc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let s=0;e&&s<t.length;s++)e=Qi(t[s],i[s]);return e}function Qi(t,i){if(t===i)return!0;let e=No(t),s=No(i);if(e||s)return e&&s?t.getTime()===i.getTime():!1;if(e=Oe(t),s=Oe(i),e||s)return t===i;if(e=Ct(t),s=Ct(i),e||s)return e&&s?sc(t,i):!1;if(e=jt(t),s=jt(i),e||s){if(!e||!s)return!1;const n=Object.keys(t).length,r=Object.keys(i).length;if(n!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Qi(t[l],i[l]))return!1}}return String(t)===String(i)}function ro(t,i){return t.findIndex(e=>Qi(e,i))}const Fr=t=>!!(t&&t.__v_isRef===!0),St=t=>Qt(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Lr||!It(t.toString))?Fr(t)?St(t.value):JSON.stringify(t,jr,2):String(t),jr=(t,i)=>Fr(i)?jr(t,i.value):Ui(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[s,n],r)=>(e[_s(s,r)+" =>"]=n,e),{})}:Xi(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>_s(e))}:Oe(i)?_s(i):jt(i)&&!Ct(i)&&!Rr(i)?String(i):i,_s=(t,i="")=>{var e;return Oe(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ne;class oc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ne&&(ne.active?(this.parent=ne,this.index=(ne.scopes||(ne.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}const s=this.effects.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}}run(i){if(this._active){const e=ne;try{return ne=this,i()}finally{ne=e}}}on(){++this._on===1&&(this.prevScope=ne,ne=this)}off(){if(this._on>0&&--this._on===0){if(ne===this)ne=this.prevScope;else{let i=ne;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,s;for(e=0,s=this.effects.length;e<s;e++)this.effects[e].stop();for(this.effects.length=0,e=0,s=this.cleanups.length;e<s;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(e=0,s=n.length;e<s;e++)n[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function rc(){return ne}let Kt;const Ss=new WeakSet;class Hr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ne&&(ne.active?ne.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Ss.has(this)&&(Ss.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Wr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,jo(this),Vr(this);const i=Kt,e=De;Kt=this,De=!0;try{return this.fn()}finally{Kr(this),Kt=i,De=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)co(i);this.deps=this.depsTail=void 0,jo(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Ss.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){js(this)&&this.run()}get dirty(){return js(this)}}let Ur=0,pn,hn;function Wr(t,i=!1){if(t.flags|=8,i){t.next=hn,hn=t;return}t.next=pn,pn=t}function lo(){Ur++}function ao(){if(--Ur>0)return;if(hn){let i=hn;for(hn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;pn;){let i=pn;for(pn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(s){t||(t=s)}i=e}}if(t)throw t}function Vr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Kr(t){let i,e=t.depsTail,s=e;for(;s;){const n=s.prevDep;s.version===-1?(s===e&&(e=n),co(s),lc(s)):i=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}t.deps=i,t.depsTail=e}function js(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(qr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function qr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===bn)||(t.globalVersion=bn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!js(t))))return;t.flags|=2;const i=t.dep,e=Kt,s=De;Kt=t,De=!0;try{Vr(t);const n=t.fn(t._value);(i.version===0||Ve(n,t._value))&&(t.flags|=128,t._value=n,i.version++)}catch(n){throw i.version++,n}finally{Kt=e,De=s,Kr(t),t.flags&=-3}}function co(t,i=!1){const{dep:e,prevSub:s,nextSub:n}=t;if(s&&(s.nextSub=n,t.prevSub=void 0),n&&(n.prevSub=s,t.nextSub=void 0),e.subs===t&&(e.subs=s,!s&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)co(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function lc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let De=!0;const Gr=[];function si(){Gr.push(De),De=!1}function oi(){const t=Gr.pop();De=t===void 0?!0:t}function jo(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Kt;Kt=void 0;try{i()}finally{Kt=e}}}let bn=0;class ac{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class uo{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Kt||!De||Kt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Kt)e=this.activeLink=new ac(Kt,this),Kt.deps?(e.prevDep=Kt.depsTail,Kt.depsTail.nextDep=e,Kt.depsTail=e):Kt.deps=Kt.depsTail=e,Zr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const s=e.nextDep;s.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=s),e.prevDep=Kt.depsTail,e.nextDep=void 0,Kt.depsTail.nextDep=e,Kt.depsTail=e,Kt.deps===e&&(Kt.deps=s)}return e}trigger(i){this.version++,bn++,this.notify(i)}notify(i){lo();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ao()}}}function Zr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let s=i.deps;s;s=s.nextDep)Zr(s)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Hs=new WeakMap,Ti=Symbol(""),Us=Symbol(""),yn=Symbol("");function ae(t,i,e){if(De&&Kt){let s=Hs.get(t);s||Hs.set(t,s=new Map);let n=s.get(e);n||(s.set(e,n=new uo),n.map=s,n.key=e),n.track()}}function Qe(t,i,e,s,n,r){const l=Hs.get(t);if(!l){bn++;return}const o=a=>{a&&a.trigger()};if(lo(),i==="clear")l.forEach(o);else{const a=Ct(t),c=a&&so(e);if(a&&e==="length"){const d=Number(s);l.forEach((h,g)=>{(g==="length"||g===yn||!Oe(g)&&g>=d)&&o(h)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(yn)),i){case"add":a?c&&o(l.get("length")):(o(l.get(Ti)),Ui(t)&&o(l.get(Us)));break;case"delete":a||(o(l.get(Ti)),Ui(t)&&o(l.get(Us)));break;case"set":Ui(t)&&o(l.get(Ti));break}}ao()}function zi(t){const i=Lt(t);return i===t?i:(ae(i,"iterate",yn),Ie(t)?i:i.map(Pe))}function ds(t){return ae(t=Lt(t),"iterate",yn),t}function He(t,i){return ri(t)?Gi(Ei(t)?Pe(i):i):Pe(i)}const cc={__proto__:null,[Symbol.iterator](){return Cs(this,Symbol.iterator,t=>He(this,t))},concat(...t){return zi(this).concat(...t.map(i=>Ct(i)?zi(i):i))},entries(){return Cs(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,i){return Ze(this,"every",t,i,void 0,arguments)},filter(t,i){return Ze(this,"filter",t,i,e=>e.map(s=>He(this,s)),arguments)},find(t,i){return Ze(this,"find",t,i,e=>He(this,e),arguments)},findIndex(t,i){return Ze(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ze(this,"findLast",t,i,e=>He(this,e),arguments)},findLastIndex(t,i){return Ze(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ze(this,"forEach",t,i,void 0,arguments)},includes(...t){return $s(this,"includes",t)},indexOf(...t){return $s(this,"indexOf",t)},join(t){return zi(this).join(t)},lastIndexOf(...t){return $s(this,"lastIndexOf",t)},map(t,i){return Ze(this,"map",t,i,void 0,arguments)},pop(){return tn(this,"pop")},push(...t){return tn(this,"push",t)},reduce(t,...i){return Ho(this,"reduce",t,i)},reduceRight(t,...i){return Ho(this,"reduceRight",t,i)},shift(){return tn(this,"shift")},some(t,i){return Ze(this,"some",t,i,void 0,arguments)},splice(...t){return tn(this,"splice",t)},toReversed(){return zi(this).toReversed()},toSorted(t){return zi(this).toSorted(t)},toSpliced(...t){return zi(this).toSpliced(...t)},unshift(...t){return tn(this,"unshift",t)},values(){return Cs(this,"values",t=>He(this,t))}};function Cs(t,i,e){const s=ds(t),n=s[i]();return s!==t&&!Ie(t)&&(n._next=n.next,n.next=()=>{const r=n._next();return r.done||(r.value=e(r.value)),r}),n}const dc=Array.prototype;function Ze(t,i,e,s,n,r){const l=ds(t),o=l!==t&&!Ie(t),a=l[i];if(a!==dc[i]){const h=a.apply(t,r);return o?Pe(h):h}let c=e;l!==t&&(o?c=function(h,g){return e.call(this,He(t,h),g,t)}:e.length>2&&(c=function(h,g){return e.call(this,h,g,t)}));const d=a.call(l,c,s);return o&&n?n(d):d}function Ho(t,i,e,s){const n=ds(t),r=n!==t&&!Ie(t);let l=e,o=!1;n!==t&&(r?(o=s.length===0,l=function(c,d,h){return o&&(o=!1,c=He(t,c)),e.call(this,c,He(t,d),h,t)}):e.length>3&&(l=function(c,d,h){return e.call(this,c,d,h,t)}));const a=n[i](l,...s);return o?He(t,a):a}function $s(t,i,e){const s=Lt(t);ae(s,"iterate",yn);const n=s[i](...e);return(n===-1||n===!1)&&ho(e[0])?(e[0]=Lt(e[0]),s[i](...e)):n}function tn(t,i,e=[]){si(),lo();const s=Lt(t)[i].apply(t,e);return ao(),oi(),s}const uc=io("__proto__,__v_isRef,__isVue"),Yr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Oe));function fc(t){Oe(t)||(t=String(t));const i=Lt(this);return ae(i,"has",t),i.hasOwnProperty(t)}class Jr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,s){if(e==="__v_skip")return i.__v_skip;const n=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!n;if(e==="__v_isReadonly")return n;if(e==="__v_isShallow")return r;if(e==="__v_raw")return s===(n?r?xc:el:r?tl:Qr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(s)?i:void 0;const l=Ct(i);if(!n){let a;if(l&&(a=cc[e]))return a;if(e==="hasOwnProperty")return fc}const o=Reflect.get(i,e,ue(i)?i:s);if((Oe(e)?Yr.has(e):uc(e))||(n||ae(i,"get",e),r))return o;if(ue(o)){const a=l&&so(e)?o:o.value;return n&&jt(a)?Vs(a):a}return jt(o)?n?Vs(o):us(o):o}}class Xr extends Jr{constructor(i=!1){super(!1,i)}set(i,e,s,n){let r=i[e];const l=Ct(i)&&so(e);if(!this._isShallow){const c=ri(r);if(!Ie(s)&&!ri(s)&&(r=Lt(r),s=Lt(s)),!l&&ue(r)&&!ue(s))return c||(r.value=s),!0}const o=l?Number(e)<i.length:Rt(i,e),a=Reflect.set(i,e,s,ue(i)?i:n);return i===Lt(n)&&a&&(o?Ve(s,r)&&Qe(i,"set",e,s):Qe(i,"add",e,s)),a}deleteProperty(i,e){const s=Rt(i,e);i[e];const n=Reflect.deleteProperty(i,e);return n&&s&&Qe(i,"delete",e,void 0),n}has(i,e){const s=Reflect.has(i,e);return(!Oe(e)||!Yr.has(e))&&ae(i,"has",e),s}ownKeys(i){return ae(i,"iterate",Ct(i)?"length":Ti),Reflect.ownKeys(i)}}class pc extends Jr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const hc=new Xr,mc=new pc,gc=new Xr(!0);const Ws=t=>t,On=t=>Reflect.getPrototypeOf(t);function vc(t,i,e){return function(...s){const n=this.__v_raw,r=Lt(n),l=Ui(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=n[t](...s),d=e?Ws:i?Gi:Pe;return!i&&ae(r,"iterate",a?Us:Ti),re(Object.create(c),{next(){const{value:h,done:g}=c.next();return g?{value:h,done:g}:{value:o?[d(h[0]),d(h[1])]:d(h),done:g}}})}}function Pn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function bc(t,i){const e={get(n){const r=this.__v_raw,l=Lt(r),o=Lt(n);t||(Ve(n,o)&&ae(l,"get",n),ae(l,"get",o));const{has:a}=On(l),c=i?Ws:t?Gi:Pe;if(a.call(l,n))return c(r.get(n));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(n)},get size(){const n=this.__v_raw;return!t&&ae(Lt(n),"iterate",Ti),n.size},has(n){const r=this.__v_raw,l=Lt(r),o=Lt(n);return t||(Ve(n,o)&&ae(l,"has",n),ae(l,"has",o)),n===o?r.has(n):r.has(n)||r.has(o)},forEach(n,r){const l=this,o=l.__v_raw,a=Lt(o),c=i?Ws:t?Gi:Pe;return!t&&ae(a,"iterate",Ti),o.forEach((d,h)=>n.call(r,c(d),c(h),l))}};return re(e,t?{add:Pn("add"),set:Pn("set"),delete:Pn("delete"),clear:Pn("clear")}:{add(n){const r=Lt(this),l=On(r),o=Lt(n),a=!i&&!Ie(n)&&!ri(n)?o:n;return l.has.call(r,a)||Ve(n,a)&&l.has.call(r,n)||Ve(o,a)&&l.has.call(r,o)||(r.add(a),Qe(r,"add",a,a)),this},set(n,r){!i&&!Ie(r)&&!ri(r)&&(r=Lt(r));const l=Lt(this),{has:o,get:a}=On(l);let c=o.call(l,n);c||(n=Lt(n),c=o.call(l,n));const d=a.call(l,n);return l.set(n,r),c?Ve(r,d)&&Qe(l,"set",n,r):Qe(l,"add",n,r),this},delete(n){const r=Lt(this),{has:l,get:o}=On(r);let a=l.call(r,n);a||(n=Lt(n),a=l.call(r,n)),o&&o.call(r,n);const c=r.delete(n);return a&&Qe(r,"delete",n,void 0),c},clear(){const n=Lt(this),r=n.size!==0,l=n.clear();return r&&Qe(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{e[n]=vc(n,t,i)}),e}function fo(t,i){const e=bc(t,i);return(s,n,r)=>n==="__v_isReactive"?!t:n==="__v_isReadonly"?t:n==="__v_raw"?s:Reflect.get(Rt(e,n)&&n in s?e:s,n,r)}const yc={get:fo(!1,!1)},kc={get:fo(!1,!0)},wc={get:fo(!0,!1)};const Qr=new WeakMap,tl=new WeakMap,el=new WeakMap,xc=new WeakMap;function _c(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function us(t){return ri(t)?t:po(t,!1,hc,yc,Qr)}function Sc(t){return po(t,!1,gc,kc,tl)}function Vs(t){return po(t,!0,mc,wc,el)}function po(t,i,e,s,n){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=n.get(t);if(r)return r;const l=_c(Za(t));if(l===0)return t;const o=new Proxy(t,l===2?s:e);return n.set(t,o),o}function Ei(t){return ri(t)?Ei(t.__v_raw):!!(t&&t.__v_isReactive)}function ri(t){return!!(t&&t.__v_isReadonly)}function Ie(t){return!!(t&&t.__v_isShallow)}function ho(t){return t?!!t.__v_raw:!1}function Lt(t){const i=t&&t.__v_raw;return i?Lt(i):t}function Cc(t){return!Rt(t,"__v_skip")&&Object.isExtensible(t)&&zr(t,"__v_skip",!0),t}const Pe=t=>jt(t)?us(t):t,Gi=t=>jt(t)?Vs(t):t;function ue(t){return t?t.__v_isRef===!0:!1}function ht(t){return $c(t,!1)}function $c(t,i){return ue(t)?t:new Ic(t,i)}class Ic{constructor(i,e){this.dep=new uo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Lt(i),this._value=e?i:Pe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,s=this.__v_isShallow||Ie(i)||ri(i);i=s?i:Lt(i),Ve(i,e)&&(this._rawValue=i,this._value=s?i:Pe(i),this.dep.trigger())}}function Ii(t){return ue(t)?t.value:t}const Ac={get:(t,i,e)=>i==="__v_raw"?t:Ii(Reflect.get(t,i,e)),set:(t,i,e,s)=>{const n=t[i];return ue(n)&&!ue(e)?(n.value=e,!0):Reflect.set(t,i,e,s)}};function il(t){return Ei(t)?t:new Proxy(t,Ac)}class Tc{constructor(i,e,s){this.fn=i,this.setter=e,this._value=void 0,this.dep=new uo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=bn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return Wr(this,!0),!0}get value(){const i=this.dep.track();return qr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Ec(t,i,e=!1){let s,n;return It(t)?s=t:(s=t.get,n=t.set),new Tc(s,n,e)}const Ln={},Zn=new WeakMap;let _i;function Mc(t,i=!1,e=_i){if(e){let s=Zn.get(e);s||Zn.set(e,s=[]),s.push(t)}}function Bc(t,i,e=Wt){const{immediate:s,deep:n,once:r,scheduler:l,augmentJob:o,call:a}=e,c=I=>n?I:Ie(I)||n===!1||n===0?ti(I,1):ti(I);let d,h,g,u,k=!1,p=!1;if(ue(t)?(h=()=>t.value,k=Ie(t)):Ei(t)?(h=()=>c(t),k=!0):Ct(t)?(p=!0,k=t.some(I=>Ei(I)||Ie(I)),h=()=>t.map(I=>{if(ue(I))return I.value;if(Ei(I))return c(I);if(It(I))return a?a(I,2):I()})):It(t)?i?h=a?()=>a(t,2):t:h=()=>{if(g){si();try{g()}finally{oi()}}const I=_i;_i=d;try{return a?a(t,3,[u]):t(u)}finally{_i=I}}:h=qe,i&&n){const I=h,x=n===!0?1/0:n;h=()=>ti(I(),x)}const b=rc(),v=()=>{d.stop(),b&&b.active&&no(b.effects,d)};if(r&&i){const I=i;i=(...x)=>{const C=I(...x);return v(),C}}let y=p?new Array(t.length).fill(Ln):Ln;const S=I=>{if(!(!(d.flags&1)||!d.dirty&&!I))if(i){const x=d.run();if(I||n||k||(p?x.some((C,A)=>Ve(C,y[A])):Ve(x,y))){g&&g();const C=_i;_i=d;try{const A=[x,y===Ln?void 0:p&&y[0]===Ln?[]:y,u];y=x,a?a(i,3,A):i(...A)}finally{_i=C}}}else d.run()};return o&&o(S),d=new Hr(h),d.scheduler=l?()=>l(S,!1):S,u=I=>Mc(I,!1,d),g=d.onStop=()=>{const I=Zn.get(d);if(I){if(a)a(I,4);else for(const x of I)x();Zn.delete(d)}},i?s?S(!0):y=d.run():l?l(S.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function ti(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,ue(t))ti(t.value,i,e);else if(Ct(t))for(let s=0;s<t.length;s++)ti(t[s],i,e);else if(Xi(t)||Ui(t))t.forEach(s=>{ti(s,i,e)});else if(Rr(t)){for(const s in t)ti(t[s],i,e);for(const s of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,s)&&ti(t[s],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function $n(t,i,e,s){try{return s?t(...s):t()}catch(n){fs(n,i,e)}}function Le(t,i,e,s){if(It(t)){const n=$n(t,i,e,s);return n&&Pr(n)&&n.catch(r=>{fs(r,i,e)}),n}if(Ct(t)){const n=[];for(let r=0;r<t.length;r++)n.push(Le(t[r],i,e,s));return n}}function fs(t,i,e,s=!0){const n=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let h=0;h<d.length;h++)if(d[h](t,a,c)===!1)return}o=o.parent}if(r){si(),$n(r,null,10,[t,a,c]),oi();return}}Dc(t,e,n,s,l)}function Dc(t,i,e,s=!0,n=!1){if(n)throw t;console.error(t)}const pe=[];let je=-1;const Wi=[];let di=null,Ni=0;const nl=Promise.resolve();let Yn=null;function sl(t){const i=Yn||nl;return t?i.then(this?t.bind(this):t):i}function Oc(t){let i=je+1,e=pe.length;for(;i<e;){const s=i+e>>>1,n=pe[s],r=kn(n);r<t||r===t&&n.flags&2?i=s+1:e=s}return i}function mo(t){if(!(t.flags&1)){const i=kn(t),e=pe[pe.length-1];!e||!(t.flags&2)&&i>=kn(e)?pe.push(t):pe.splice(Oc(i),0,t),t.flags|=1,ol()}}function ol(){Yn||(Yn=nl.then(ll))}function Pc(t){Ct(t)?Wi.push(...t):di&&t.id===-1?di.splice(Ni+1,0,t):t.flags&1||(Wi.push(t),t.flags|=1),ol()}function Uo(t,i,e=je+1){for(;e<pe.length;e++){const s=pe[e];if(s&&s.flags&2){if(t&&s.id!==t.uid)continue;pe.splice(e,1),e--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function rl(t){if(Wi.length){const i=[...new Set(Wi)].sort((e,s)=>kn(e)-kn(s));if(Wi.length=0,di){di.push(...i);return}for(di=i,Ni=0;Ni<di.length;Ni++){const e=di[Ni];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}di=null,Ni=0}}const kn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function ll(t){try{for(je=0;je<pe.length;je++){const i=pe[je];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),$n(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;je<pe.length;je++){const i=pe[je];i&&(i.flags&=-2)}je=-1,pe.length=0,rl(),Yn=null,(pe.length||Wi.length)&&ll()}}let oe=null,al=null;function Jn(t){const i=oe;return oe=t,al=t&&t.type.__scopeId||null,i}function cl(t,i=oe,e){if(!i||t._n)return t;const s=(...n)=>{s._d&&er(-1);const r=Jn(i),l=ii.length;let o;try{o=t(...n)}finally{for(let a=ii.length;a>l;a--)wo();Jn(r),s._d&&er(1)}return o};return s._n=!0,s._c=!0,s._d=!0,s}function Te(t,i){if(oe===null)return t;const e=gs(oe),s=t.dirs||(t.dirs=[]);for(let n=0;n<i.length;n++){let[r,l,o,a=Wt]=i[n];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&ti(l),s.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function wi(t,i,e,s){const n=t.dirs,r=i&&i.dirs;for(let l=0;l<n.length;l++){const o=n[l];r&&(o.oldValue=r[l].value);let a=o.dir[s];a&&(si(),Le(a,e,8,[t.el,o,t,i]),oi())}}function Lc(t,i){if(ce){let e=ce.provides;const s=ce.parent&&ce.parent.provides;s===e&&(e=ce.provides=Object.create(s)),e[t]=i}}function ei(t,i,e=!1){const s=Od();if(s||Ki){let n=Ki?Ki._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&t in n)return n[t];if(arguments.length>1)return e&&It(i)?i.call(s&&s.proxy):i}}const Rc=Symbol.for("v-scx"),zc=()=>ei(Rc);function Mi(t,i,e){return dl(t,i,e)}function dl(t,i,e=Wt){const{immediate:s,deep:n,flush:r,once:l}=e,o=re({},e),a=i&&s||!i&&r!=="post";let c;if(xn){if(r==="sync"){const u=zc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=qe,u.resume=qe,u.pause=qe,u}}const d=ce;o.call=(u,k,p)=>Le(u,d,k,p);let h=!1;r==="post"?o.scheduler=u=>{ge(u,d&&d.suspense)}:r!=="sync"&&(h=!0,o.scheduler=(u,k)=>{k?u():mo(u)}),o.augmentJob=u=>{i&&(u.flags|=4),h&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Bc(t,i,o);return xn&&(c?c.push(g):a&&g()),g}function Nc(t,i,e){const s=this.proxy,n=Qt(t)?t.includes(".")?ul(s,t):()=>s[t]:t.bind(s,s);let r;It(i)?r=i:(r=i.handler,e=i);const l=An(this),o=dl(n,r.bind(s),e);return l(),o}function ul(t,i){const e=i.split(".");return()=>{let s=t;for(let n=0;n<e.length&&s;n++)s=s[e[n]];return s}}const Fc=Symbol("_vte"),jc=t=>t.__isTeleport,Is=Symbol("_leaveCb");function go(t,i){t.shapeFlag&6&&t.component?(t.transition=i,go(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?re({name:t.name},i,{setup:t}):t}function fl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Wo(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Xn=new WeakMap;function mn(t,i,e,s,n=!1){if(Ct(t)){t.forEach((p,b)=>mn(p,i&&(Ct(i)?i[b]:i),e,s,n));return}if(Vi(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&mn(t,i,e,s.component.subTree);return}const r=s.shapeFlag&4?gs(s.component):s.el,l=n?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===Wt?o.refs={}:o.refs,h=o.setupState,g=Lt(h),u=h===Wt?Or:p=>Wo(d,p)?!1:Rt(g,p),k=(p,b)=>!(b&&Wo(d,b));if(c!=null&&c!==a){if(Vo(i),Qt(c))d[c]=null,u(c)&&(h[c]=null);else if(ue(c)){const p=i;k(c,p.k)&&(c.value=null),p.k&&(d[p.k]=null)}}if(It(a))$n(a,o,12,[l,d]);else{const p=Qt(a),b=ue(a);if(p||b){const v=()=>{if(t.f){const y=p?u(a)?h[a]:d[a]:k()||!t.k?a.value:d[t.k];if(n)Ct(y)&&no(y,r);else if(Ct(y))y.includes(r)||y.push(r);else if(p)d[a]=[r],u(a)&&(h[a]=d[a]);else{const S=[r];k(a,t.k)&&(a.value=S),t.k&&(d[t.k]=S)}}else p?(d[a]=l,u(a)&&(h[a]=l)):b&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const y=()=>{v(),Xn.delete(t)};y.id=-1,Xn.set(t,y),ge(y,e)}else Vo(t),v()}}}function Vo(t){const i=Xn.get(t);i&&(i.flags|=8,Xn.delete(t))}cs().requestIdleCallback;cs().cancelIdleCallback;const Vi=t=>!!t.type.__asyncLoader,pl=t=>t.type.__isKeepAlive;function Hc(t,i){hl(t,"a",i)}function Uc(t,i){hl(t,"da",i)}function hl(t,i,e=ce){const s=t.__wdc||(t.__wdc=()=>{let n=e;for(;n;){if(n.isDeactivated)return;n=n.parent}return t()});if(ps(i,s,e),e){let n=e.parent;for(;n&&n.parent;)pl(n.parent.vnode)&&Wc(s,i,e,n),n=n.parent}}function Wc(t,i,e,s){const n=ps(i,t,s,!0);bo(()=>{no(s[i],n)},e)}function ps(t,i,e=ce,s=!1){if(e){const n=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{si();const o=An(e),a=Le(i,e,t,l);return o(),oi(),a});return s?n.unshift(r):n.push(r),r}}const ai=t=>(i,e=ce)=>{(!xn||t==="sp")&&ps(t,(...s)=>i(...s),e)},Vc=ai("bm"),In=ai("m"),Kc=ai("bu"),qc=ai("u"),vo=ai("bum"),bo=ai("um"),Gc=ai("sp"),Zc=ai("rtg"),Yc=ai("rtc");function Jc(t,i=ce){ps("ec",t,i)}const Xc="components";function Qc(t,i){return ed(Xc,t,!0,i)||t}const td=Symbol.for("v-ndc");function ed(t,i,e=!0,s=!1){const n=oe||ce;if(n){const r=n.type;{const o=Nd(r,!1);if(o&&(o===i||o===he(i)||o===ls(he(i))))return r}const l=Ko(n[t]||r[t],i)||Ko(n.appContext[t],i);return!l&&s?r:l}}function Ko(t,i){return t&&(t[i]||t[he(i)]||t[ls(he(i))])}function ke(t,i,e,s){let n;const r=e,l=Ct(t);if(l||Qt(t)){const o=l&&Ei(t);let a=!1,c=!1;o&&(a=!Ie(t),c=ri(t),t=ds(t)),n=new Array(t.length);for(let d=0,h=t.length;d<h;d++)n[d]=i(a?c?Gi(Pe(t[d])):Pe(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){n=new Array(t);for(let o=0;o<t;o++)n[o]=i(o+1,o,void 0,r)}else if(jt(t))if(t[Symbol.iterator])n=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);n=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];n[a]=i(t[d],d,a,r)}}else n=[];return n}function Rn(t,i,e={},s,n,r){if(oe.ce||oe.parent&&Vi(oe.parent)&&oe.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),et(),Be(Gt,null,[pt("slot",c,s&&s())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ii.length;et();let a;try{const c=l&&ml(l(e)),d=e.key||r||c&&c.key;a=Be(Gt,{key:(d&&!Oe(d)?d:`_${i}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&t._===1?64:-2)}catch(c){for(let d=ii.length;d>o;d--)wo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function ml(t){return t.some(i=>xo(i)?!(i.type===li||i.type===Gt&&!ml(i.children)):!0)?t:null}const Ks=t=>t?Pl(t)?gs(t):Ks(t.parent):null,gn=re(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Ks(t.parent),$root:t=>Ks(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>vl(t),$forceUpdate:t=>t.f||(t.f=()=>{mo(t.update)}),$nextTick:t=>t.n||(t.n=sl.bind(t.proxy)),$watch:t=>Nc.bind(t)}),As=(t,i)=>t!==Wt&&!t.__isScriptSetup&&Rt(t,i),id={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:s,data:n,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return s[i];case 2:return n[i];case 4:return e[i];case 3:return r[i]}else{if(As(s,i))return l[i]=1,s[i];if(n!==Wt&&Rt(n,i))return l[i]=2,n[i];if(Rt(r,i))return l[i]=3,r[i];if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];qs&&(l[i]=0)}}const c=gn[i];let d,h;if(c)return i==="$attrs"&&ae(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];if(h=a.config.globalProperties,Rt(h,i))return h[i]},set({_:t},i,e){const{data:s,setupState:n,ctx:r}=t;return As(n,i)?(n[i]=e,!0):s!==Wt&&Rt(s,i)?(s[i]=e,!0):Rt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:s,appContext:n,props:r,type:l}},o){let a;return!!(e[o]||t!==Wt&&o[0]!=="$"&&Rt(t,o)||As(i,o)||Rt(r,o)||Rt(s,o)||Rt(gn,o)||Rt(n.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Rt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function qo(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let qs=!0;function nd(t){const i=vl(t),e=t.proxy,s=t.ctx;qs=!1,i.beforeCreate&&Go(i.beforeCreate,t,"bc");const{data:n,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:h,mounted:g,beforeUpdate:u,updated:k,activated:p,deactivated:b,beforeDestroy:v,beforeUnmount:y,destroyed:S,unmounted:I,render:x,renderTracked:C,renderTriggered:A,errorCaptured:E,serverPrefetch:D,expose:R,inheritAttrs:X,components:T,directives:O,filters:w}=i;if(c&&sd(c,s,null),l)for(const j in l){const at=l[j];It(at)&&(s[j]=at.bind(e))}if(n){const j=n.call(e,e);jt(j)&&(t.data=us(j))}if(qs=!0,r)for(const j in r){const at=r[j],W=It(at)?at.bind(e,e):It(at.get)?at.get.bind(e,e):qe,Y=!It(at)&&It(at.set)?at.set.bind(e):qe,V=$t({get:W,set:Y});Object.defineProperty(s,j,{enumerable:!0,configurable:!0,get:()=>V.value,set:N=>V.value=N})}if(o)for(const j in o)gl(o[j],s,e,j);if(a){const j=It(a)?a.call(e):a;Reflect.ownKeys(j).forEach(at=>{Lc(at,j[at])})}d&&Go(d,t,"c");function Q(j,at){Ct(at)?at.forEach(W=>j(W.bind(e))):at&&j(at.bind(e))}if(Q(Vc,h),Q(In,g),Q(Kc,u),Q(qc,k),Q(Hc,p),Q(Uc,b),Q(Jc,E),Q(Yc,C),Q(Zc,A),Q(vo,y),Q(bo,I),Q(Gc,D),Ct(R))if(R.length){const j=t.exposed||(t.exposed={});R.forEach(at=>{Object.defineProperty(j,at,{get:()=>e[at],set:W=>e[at]=W,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===qe&&(t.render=x),X!=null&&(t.inheritAttrs=X),T&&(t.components=T),O&&(t.directives=O),D&&fl(t)}function sd(t,i,e=qe){Ct(t)&&(t=Gs(t));for(const s in t){const n=t[s];let r;jt(n)?"default"in n?r=ei(n.from||s,n.default,!0):r=ei(n.from||s):r=ei(n),ue(r)?Object.defineProperty(i,s,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[s]=r}}function Go(t,i,e){Le(Ct(t)?t.map(s=>s.bind(i.proxy)):t.bind(i.proxy),i,e)}function gl(t,i,e,s){let n=s.includes(".")?ul(e,s):()=>e[s];if(Qt(t)){const r=i[t];It(r)&&Mi(n,r)}else if(It(t))Mi(n,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(r=>gl(r,i,e,s));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Mi(n,r,t)}}function vl(t){const i=t.type,{mixins:e,extends:s}=i,{mixins:n,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!n.length&&!e&&!s?a=i:(a={},n.length&&n.forEach(c=>Qn(a,c,l,!0)),Qn(a,i,l)),jt(i)&&r.set(i,a),a}function Qn(t,i,e,s=!1){const{mixins:n,extends:r}=i;r&&Qn(t,r,e,!0),n&&n.forEach(l=>Qn(t,l,e,!0));for(const l in i)if(!(s&&l==="expose")){const o=od[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const od={data:Zo,props:Yo,emits:Yo,methods:on,computed:on,beforeCreate:fe,created:fe,beforeMount:fe,mounted:fe,beforeUpdate:fe,updated:fe,beforeDestroy:fe,beforeUnmount:fe,destroyed:fe,unmounted:fe,activated:fe,deactivated:fe,errorCaptured:fe,serverPrefetch:fe,components:on,directives:on,watch:ld,provide:Zo,inject:rd};function Zo(t,i){return i?t?function(){return re(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function rd(t,i){return on(Gs(t),Gs(i))}function Gs(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function fe(t,i){return t?[...new Set([].concat(t,i))]:i}function on(t,i){return t?re(Object.create(null),t,i):i}function Yo(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:re(Object.create(null),qo(t),qo(i??{})):i}function ld(t,i){if(!t)return i;if(!i)return t;const e=re(Object.create(null),t);for(const s in i)e[s]=fe(t[s],i[s]);return e}function bl(){return{app:null,config:{isNativeTag:Or,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let ad=0;function cd(t,i){return function(s,n=null){It(s)||(s=re({},s)),n!=null&&!jt(n)&&(n=null);const r=bl(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:ad++,_component:s,_props:n,_container:null,_context:r,_instance:null,version:jd,get config(){return r.config},set config(d){},use(d,...h){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...h)):It(d)&&(l.add(d),d(c,...h))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,h){return h?(r.components[d]=h,c):r.components[d]},directive(d,h){return h?(r.directives[d]=h,c):r.directives[d]},mount(d,h,g){if(!a){const u=c._ceVNode||pt(s,n);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,gs(u.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Le(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,h){return r.provides[d]=h,c},runWithContext(d){const h=Ki;Ki=c;try{return d()}finally{Ki=h}}};return c}}let Ki=null;const dd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${he(i)}Modifiers`]||t[`${gi(i)}Modifiers`];function ud(t,i,...e){if(t.isUnmounted)return;const s=t.vnode.props||Wt;let n=e;const r=i.startsWith("update:"),l=r&&dd(s,i.slice(7));l&&(l.trim&&(n=e.map(d=>Qt(d)?d.trim():d)),l.number&&(n=e.map(as)));let o,a=s[o=xs(i)]||s[o=xs(he(i))];!a&&r&&(a=s[o=xs(gi(i))]),a&&Le(a,t,6,n);const c=s[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Le(c,t,6,n)}}const fd=new WeakMap;function yl(t,i,e=!1){const s=e?fd:i.emitsCache,n=s.get(t);if(n!==void 0)return n;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=yl(c,i,!0);d&&(o=!0,re(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(jt(t)&&s.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):re(l,r),jt(t)&&s.set(t,l),l)}function hs(t,i){return!t||!ss(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Rt(t,i[0].toLowerCase()+i.slice(1))||Rt(t,gi(i))||Rt(t,i))}function Jo(t){const{type:i,vnode:e,proxy:s,withProxy:n,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:h,data:g,setupState:u,ctx:k,inheritAttrs:p}=t,b=Jn(t);let v,y;try{if(e.shapeFlag&4){const I=n||s,x=I;v=Ue(c.call(x,I,d,h,u,g,k)),y=o}else{const I=i;v=Ue(I.length>1?I(h,{attrs:o,slots:l,emit:a}):I(h,null)),y=i.props?o:pd(o)}}catch(I){ii.length=0,fs(I,t,1),v=pt(li)}let S=v;if(y&&p!==!1){const I=Object.keys(y),{shapeFlag:x}=S;I.length&&x&7&&(r&&I.some(os)&&(y=hd(y,r)),S=Zi(S,y,!1,!0))}return e.dirs&&(S=Zi(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(e.dirs):e.dirs),e.transition&&go(S,e.transition),v=S,Jn(b),v}const pd=t=>{let i;for(const e in t)(e==="class"||e==="style"||ss(e))&&((i||(i={}))[e]=t[e]);return i},hd=(t,i)=>{const e={};for(const s in t)(!os(s)||!(s.slice(9)in i))&&(e[s]=t[s]);return e};function md(t,i,e){const{props:s,children:n,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return s?Xo(s,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let h=0;h<d.length;h++){const g=d[h];if(kl(l,s,g)&&!hs(c,g))return!0}}}else return(n||o)&&(!o||!o.$stable)?!0:s===l?!1:s?l?Xo(s,l,c):!0:!!l;return!1}function Xo(t,i,e){const s=Object.keys(i);if(s.length!==Object.keys(t).length)return!0;for(let n=0;n<s.length;n++){const r=s[n];if(kl(i,t,r)&&!hs(e,r))return!0}return!1}function kl(t,i,e){const s=t[e],n=i[e];return e==="style"&&jt(s)&&jt(n)?!Qi(s,n):s!==n}function gd({vnode:t,parent:i,suspense:e},s){for(;i;){const n=i.subTree;if(n.suspense&&n.suspense.activeBranch===t&&(n.suspense.vnode.el=n.el=s,t=n),n===t)(t=i.vnode).el=s,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=s)}const wl={},xl=()=>Object.create(wl),_l=t=>Object.getPrototypeOf(t)===wl;function vd(t,i,e,s=!1){const n={},r=xl();t.propsDefaults=Object.create(null),Sl(t,i,n,r);for(const l in t.propsOptions[0])l in n||(n[l]=void 0);e?t.props=s?n:Sc(n):t.type.props?t.props=n:t.props=r,t.attrs=r}function bd(t,i,e,s){const{props:n,attrs:r,vnode:{patchFlag:l}}=t,o=Lt(n),[a]=t.propsOptions;let c=!1;if((s||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let h=0;h<d.length;h++){let g=d[h];if(hs(t.emitsOptions,g))continue;const u=i[g];if(a)if(Rt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const k=he(g);n[k]=Zs(a,o,k,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{Sl(t,i,n,r)&&(c=!0);let d;for(const h in o)(!i||!Rt(i,h)&&((d=gi(h))===h||!Rt(i,d)))&&(a?e&&(e[h]!==void 0||e[d]!==void 0)&&(n[h]=Zs(a,o,h,void 0,t,!0)):delete n[h]);if(r!==o)for(const h in r)(!i||!Rt(i,h))&&(delete r[h],c=!0)}c&&Qe(t.attrs,"set","")}function Sl(t,i,e,s){const[n,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(fn(a))continue;const c=i[a];let d;n&&Rt(n,d=he(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:hs(t.emitsOptions,a)||(!(a in s)||c!==s[a])&&(s[a]=c,l=!0)}if(r){const a=Lt(e),c=o||Wt;for(let d=0;d<r.length;d++){const h=r[d];e[h]=Zs(n,a,h,c[h],t,!Rt(c,h))}}return l}function Zs(t,i,e,s,n,r){const l=t[e];if(l!=null){const o=Rt(l,"default");if(o&&s===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=n;if(e in c)s=c[e];else{const d=An(n);s=c[e]=a.call(null,i),d()}}else s=a;n.ce&&n.ce._setProp(e,s)}l[0]&&(r&&!o?s=!1:l[1]&&(s===""||s===gi(e))&&(s=!0))}return s}const yd=new WeakMap;function Cl(t,i,e=!1){const s=e?yd:i.propsCache,n=s.get(t);if(n)return n;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=h=>{a=!0;const[g,u]=Cl(h,i,!0);re(l,g),u&&o.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&s.set(t,Hi),Hi;if(Ct(r))for(let d=0;d<r.length;d++){const h=he(r[d]);Qo(h)&&(l[h]=Wt)}else if(r)for(const d in r){const h=he(d);if(Qo(h)){const g=r[d],u=l[h]=Ct(g)||It(g)?{type:g}:re({},g),k=u.type;let p=!1,b=!0;if(Ct(k))for(let v=0;v<k.length;++v){const y=k[v],S=It(y)&&y.name;if(S==="Boolean"){p=!0;break}else S==="String"&&(b=!1)}else p=It(k)&&k.name==="Boolean";u[0]=p,u[1]=b,(p||Rt(u,"default"))&&o.push(h)}}const c=[l,o];return jt(t)&&s.set(t,c),c}function Qo(t){return t[0]!=="$"&&!fn(t)}const yo=t=>t==="_"||t==="_ctx"||t==="$stable",ko=t=>Ct(t)?t.map(Ue):[Ue(t)],kd=(t,i,e)=>{if(i._n)return i;const s=cl((...n)=>ko(i(...n)),e);return s._c=!1,s},$l=(t,i,e)=>{const s=t._ctx;for(const n in t){if(yo(n))continue;const r=t[n];if(It(r))i[n]=kd(n,r,s);else if(r!=null){const l=ko(r);i[n]=()=>l}}},Il=(t,i)=>{const e=ko(i);t.slots.default=()=>e},Al=(t,i,e)=>{for(const s in i)(e||!yo(s))&&(t[s]=i[s])},wd=(t,i,e)=>{const s=t.slots=xl();if(t.vnode.shapeFlag&32){const n=i._;n?(Al(s,i,e),e&&zr(s,"_",n,!0)):$l(i,s)}else i&&Il(t,i)},xd=(t,i,e)=>{const{vnode:s,slots:n}=t;let r=!0,l=Wt;if(s.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Al(n,i,e):(r=!i.$stable,$l(i,n)),l=i}else i&&(Il(t,i),l={default:1});if(r)for(const o in n)!yo(o)&&l[o]==null&&delete n[o]},ge=Id;function _d(t){return Sd(t)}function Sd(t,i){const e=cs();e.__VUE__=!0;const{insert:s,remove:n,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:h,nextSibling:g,setScopeId:u=qe,insertStaticContent:k}=t,p=(M,L,f,F=null,P=null,_=null,$=void 0,B=null,K=!!L.dynamicChildren)=>{if(M===L)return;M&&!en(M,L)&&(F=gt(M),N(M,P,_,!0),M=null),L.patchFlag===-2&&(K=!1,L.dynamicChildren=null);const{type:H,ref:U,shapeFlag:G}=L;switch(H){case ms:b(M,L,f,F);break;case li:v(M,L,f,F);break;case Un:M==null&&y(L,f,F,$);break;case Gt:T(M,L,f,F,P,_,$,B,K);break;default:G&1?x(M,L,f,F,P,_,$,B,K):G&6?O(M,L,f,F,P,_,$,B,K):(G&64||G&128)&&H.process(M,L,f,F,P,_,$,B,K,ot)}U!=null&&P?mn(U,M&&M.ref,_,L||M,!L):U==null&&M&&M.ref!=null&&mn(M.ref,null,_,M,!0)},b=(M,L,f,F)=>{if(M==null)s(L.el=o(L.children),f,F);else{const P=L.el=M.el;L.children!==M.children&&c(P,L.children)}},v=(M,L,f,F)=>{M==null?s(L.el=a(L.children||""),f,F):L.el=M.el},y=(M,L,f,F)=>{[M.el,M.anchor]=k(M.children,L,f,F,M.el,M.anchor)},S=({el:M,anchor:L},f,F)=>{let P;for(;M&&M!==L;)P=g(M),s(M,f,F),M=P;s(L,f,F)},I=({el:M,anchor:L})=>{let f;for(;M&&M!==L;)f=g(M),n(M),M=f;n(L)},x=(M,L,f,F,P,_,$,B,K)=>{if(L.type==="svg"?$="svg":L.type==="math"&&($="mathml"),M==null)C(L,f,F,P,_,$,B,K);else{const H=M.el&&M.el._isVueCE?M.el:null;try{H&&H._beginPatch(),D(M,L,P,_,$,B,K)}finally{H&&H._endPatch()}}},C=(M,L,f,F,P,_,$,B)=>{let K,H;const{props:U,shapeFlag:G,transition:it,dirs:tt}=M;if(K=M.el=l(M.type,_,U&&U.is,U),G&8?d(K,M.children):G&16&&E(M.children,K,null,F,P,Ts(M,_),$,B),tt&&wi(M,null,F,"created"),A(K,M,M.scopeId,$,F),U){for(const xt in U)xt!=="value"&&!fn(xt)&&r(K,xt,null,U[xt],_,F);"value"in U&&r(K,"value",null,U.value,_),(H=U.onVnodeBeforeMount)&&Ne(H,F,M)}tt&&wi(M,null,F,"beforeMount");const ut=Cd(P,it);ut&&it.beforeEnter(K),s(K,L,f),((H=U&&U.onVnodeMounted)||ut||tt)&&ge(()=>{try{H&&Ne(H,F,M),ut&&it.enter(K),tt&&wi(M,null,F,"mounted")}finally{}},P)},A=(M,L,f,F,P)=>{if(f&&u(M,f),F)for(let _=0;_<F.length;_++)u(M,F[_]);if(P){let _=P.subTree;if(L===_||Bl(_.type)&&(_.ssContent===L||_.ssFallback===L)){const $=P.vnode;A(M,$,$.scopeId,$.slotScopeIds,P.parent)}}},E=(M,L,f,F,P,_,$,B,K=0)=>{for(let H=K;H<M.length;H++){const U=M[H]=B?Xe(M[H]):Ue(M[H]);p(null,U,L,f,F,P,_,$,B)}},D=(M,L,f,F,P,_,$)=>{const B=L.el=M.el;let{patchFlag:K,dynamicChildren:H,dirs:U}=L;K|=M.patchFlag&16;const G=M.props||Wt,it=L.props||Wt;let tt;if(f&&xi(f,!1),(tt=it.onVnodeBeforeUpdate)&&Ne(tt,f,L,M),U&&wi(L,M,f,"beforeUpdate"),f&&xi(f,!0),H&&(!M.dynamicChildren||M.dynamicChildren.length!==H.length)&&(K=0,$=!1,H=null),(G.innerHTML&&it.innerHTML==null||G.textContent&&it.textContent==null)&&d(B,""),H?R(M.dynamicChildren,H,B,f,F,Ts(L,P),_):$||at(M,L,B,null,f,F,Ts(L,P),_,!1),K>0){if(K&16)X(B,G,it,f,P);else if(K&2&&G.class!==it.class&&r(B,"class",null,it.class,P),K&4&&r(B,"style",G.style,it.style,P),K&8){const ut=L.dynamicProps;for(let xt=0;xt<ut.length;xt++){const bt=ut[xt],Mt=G[bt],Vt=it[bt];(Vt!==Mt||bt==="value")&&r(B,bt,Mt,Vt,P,f)}}K&1&&M.children!==L.children&&d(B,L.children)}else!$&&H==null&&X(B,G,it,f,P);((tt=it.onVnodeUpdated)||U)&&ge(()=>{tt&&Ne(tt,f,L,M),U&&wi(L,M,f,"updated")},F)},R=(M,L,f,F,P,_,$)=>{for(let B=0;B<L.length;B++){const K=M[B],H=L[B],U=K.el&&(K.type===Gt||!en(K,H)||K.shapeFlag&198)?h(K.el):f;p(K,H,U,null,F,P,_,$,!0)}},X=(M,L,f,F,P)=>{if(L!==f){if(L!==Wt)for(const _ in L)!fn(_)&&!(_ in f)&&r(M,_,L[_],null,P,F);for(const _ in f){if(fn(_))continue;const $=f[_],B=L[_];$!==B&&_!=="value"&&r(M,_,B,$,P,F)}"value"in f&&r(M,"value",L.value,f.value,P)}},T=(M,L,f,F,P,_,$,B,K)=>{const H=L.el=M?M.el:o(""),U=L.anchor=M?M.anchor:o("");let{patchFlag:G,dynamicChildren:it,slotScopeIds:tt}=L;tt&&(B=B?B.concat(tt):tt),M==null?(s(H,f,F),s(U,f,F),E(L.children||[],f,U,P,_,$,B,K)):G>0&&G&64&&it&&M.dynamicChildren&&M.dynamicChildren.length===it.length?(R(M.dynamicChildren,it,f,P,_,$,B),(L.key!=null||P&&L===P.subTree)&&Tl(M,L,!0)):at(M,L,f,U,P,_,$,B,K)},O=(M,L,f,F,P,_,$,B,K)=>{L.slotScopeIds=B,M==null?L.shapeFlag&512?P.ctx.activate(L,f,F,$,K):w(L,f,F,P,_,$,K):z(M,L,K)},w=(M,L,f,F,P,_,$)=>{const B=M.component=Dd(M,F,P);if(pl(M)&&(B.ctx.renderer=ot),Pd(B,!1,$),B.asyncDep){if(P&&P.registerDep(B,Q,$),!M.el){const K=B.subTree=pt(li);v(null,K,L,f),M.placeholder=K.el}}else Q(B,M,L,f,P,_,$)},z=(M,L,f)=>{const F=L.component=M.component;if(md(M,L,f))if(F.asyncDep&&!F.asyncResolved){j(F,L,f);return}else F.next=L,F.update();else L.el=M.el,F.vnode=L},Q=(M,L,f,F,P,_,$)=>{const B=()=>{if(M.isMounted){let{next:G,bu:it,u:tt,parent:ut,vnode:xt}=M;{const ee=El(M);if(ee){G&&(G.el=xt.el,j(M,G,$)),ee.asyncDep.then(()=>{ge(()=>{M.isUnmounted||H()},P)});return}}let bt=G,Mt;xi(M,!1),G?(G.el=xt.el,j(M,G,$)):G=xt,it&&Hn(it),(Mt=G.props&&G.props.onVnodeBeforeUpdate)&&Ne(Mt,ut,G,xt),xi(M,!0);const Vt=Jo(M),Yt=M.subTree;M.subTree=Vt,p(Yt,Vt,h(Yt.el),gt(Yt),M,P,_),G.el=Vt.el,bt===null&&gd(M,Vt.el),tt&&ge(tt,P),(Mt=G.props&&G.props.onVnodeUpdated)&&ge(()=>Ne(Mt,ut,G,xt),P)}else{let G;const{el:it,props:tt}=L,{bm:ut,m:xt,parent:bt,root:Mt,type:Vt}=M,Yt=Vi(L);xi(M,!1),ut&&Hn(ut),!Yt&&(G=tt&&tt.onVnodeBeforeMount)&&Ne(G,bt,L),xi(M,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Vt,M.parent?M.parent.type:void 0);const ee=M.subTree=Jo(M);p(null,ee,f,F,M,P,_),L.el=ee.el}if(xt&&ge(xt,P),!Yt&&(G=tt&&tt.onVnodeMounted)){const ee=L;ge(()=>Ne(G,bt,ee),P)}(L.shapeFlag&256||bt&&Vi(bt.vnode)&&bt.vnode.shapeFlag&256)&&M.a&&ge(M.a,P),M.isMounted=!0,L=f=F=null}};M.scope.on();const K=M.effect=new Hr(B);M.scope.off();const H=M.update=K.run.bind(K),U=M.job=K.runIfDirty.bind(K);U.i=M,U.id=M.uid,K.scheduler=()=>mo(U),xi(M,!0),H()},j=(M,L,f)=>{L.component=M;const F=M.vnode.props;M.vnode=L,M.next=null,bd(M,L.props,F,f),xd(M,L.children,f),si(),Uo(M),oi()},at=(M,L,f,F,P,_,$,B,K=!1)=>{const H=M&&M.children,U=M?M.shapeFlag:0,G=L.children,{patchFlag:it,shapeFlag:tt}=L;if(it>0){if(it&128){Y(H,G,f,F,P,_,$,B,K);return}else if(it&256){W(H,G,f,F,P,_,$,B,K);return}}tt&8?(U&16&&J(H,P,_),G!==H&&d(f,G)):U&16?tt&16?Y(H,G,f,F,P,_,$,B,K):J(H,P,_,!0):(U&8&&d(f,""),tt&16&&E(G,f,F,P,_,$,B,K))},W=(M,L,f,F,P,_,$,B,K)=>{M=M||Hi,L=L||Hi;const H=M.length,U=L.length,G=Math.min(H,U);let it;for(it=0;it<G;it++){const tt=L[it]=K?Xe(L[it]):Ue(L[it]);p(M[it],tt,f,null,P,_,$,B,K)}H>U?J(M,P,_,!0,!1,G):E(L,f,F,P,_,$,B,K,G)},Y=(M,L,f,F,P,_,$,B,K)=>{let H=0;const U=L.length;let G=M.length-1,it=U-1;for(;H<=G&&H<=it;){const tt=M[H],ut=L[H]=K?Xe(L[H]):Ue(L[H]);if(en(tt,ut))p(tt,ut,f,null,P,_,$,B,K);else break;H++}for(;H<=G&&H<=it;){const tt=M[G],ut=L[it]=K?Xe(L[it]):Ue(L[it]);if(en(tt,ut))p(tt,ut,f,null,P,_,$,B,K);else break;G--,it--}if(H>G){if(H<=it){const tt=it+1,ut=tt<U?L[tt].el:F;for(;H<=it;)p(null,L[H]=K?Xe(L[H]):Ue(L[H]),f,ut,P,_,$,B,K),H++}}else if(H>it)for(;H<=G;)N(M[H],P,_,!0),H++;else{const tt=H,ut=H,xt=new Map;for(H=ut;H<=it;H++){const te=L[H]=K?Xe(L[H]):Ue(L[H]);te.key!=null&&xt.set(te.key,H)}let bt,Mt=0;const Vt=it-ut+1;let Yt=!1,ee=0;const Nt=new Array(Vt);for(H=0;H<Vt;H++)Nt[H]=0;for(H=tt;H<=G;H++){const te=M[H];if(Mt>=Vt){N(te,P,_,!0);continue}let Jt;if(te.key!=null)Jt=xt.get(te.key);else for(bt=ut;bt<=it;bt++)if(Nt[bt-ut]===0&&en(te,L[bt])){Jt=bt;break}Jt===void 0?N(te,P,_,!0):(Nt[Jt-ut]=H+1,Jt>=ee?ee=Jt:Yt=!0,p(te,L[Jt],f,null,P,_,$,B,K),Mt++)}const Ge=Yt?$d(Nt):Hi;for(bt=Ge.length-1,H=Vt-1;H>=0;H--){const te=ut+H,Jt=L[te],vi=L[te+1],Oi=te+1<U?vi.el||Ml(vi):F;Nt[H]===0?p(null,Jt,f,Oi,P,_,$,B,K):Yt&&(bt<0||H!==Ge[bt]?V(Jt,f,Oi,2):bt--)}}},V=(M,L,f,F,P=null)=>{const{el:_,type:$,transition:B,children:K,shapeFlag:H}=M;if(H&6){V(M.component.subTree,L,f,F);return}if(H&128){M.suspense.move(L,f,F);return}if(H&64){$.move(M,L,f,ot);return}if($===Gt){s(_,L,f);for(let G=0;G<K.length;G++)V(K[G],L,f,F);s(M.anchor,L,f);return}if($===Un){S(M,L,f);return}if(F!==2&&H&1&&B)if(F===0)B.persisted&&!_[Is]?s(_,L,f):(B.beforeEnter(_),s(_,L,f),ge(()=>B.enter(_),P));else{const{leave:G,delayLeave:it,afterLeave:tt}=B,ut=()=>{M.ctx.isUnmounted?n(_):s(_,L,f)},xt=()=>{const bt=_._isLeaving||!!_[Is];_._isLeaving&&_[Is](!0),B.persisted&&!bt?ut():G(_,()=>{ut(),tt&&tt()})};it?it(_,ut,xt):xt()}else s(_,L,f)},N=(M,L,f,F=!1,P=!1)=>{const{type:_,props:$,ref:B,children:K,dynamicChildren:H,shapeFlag:U,patchFlag:G,dirs:it,cacheIndex:tt,memo:ut}=M;if(G===-2&&(P=!1),B!=null&&(si(),mn(B,null,f,M,!0),oi()),tt!=null&&(L.renderCache[tt]=void 0),U&256){L.ctx.deactivate(M);return}const xt=U&1&&it,bt=!Vi(M);let Mt;if(bt&&(Mt=$&&$.onVnodeBeforeUnmount)&&Ne(Mt,L,M),U&6)st(M.component,f,F);else{if(U&128){M.suspense.unmount(f,F);return}xt&&wi(M,null,L,"beforeUnmount"),U&64?M.type.remove(M,L,f,ot,F):H&&!H.hasOnce&&(_!==Gt||G>0&&G&64)?J(H,L,f,!1,!0):(_===Gt&&G&384||!P&&U&16)&&J(K,L,f),F&&ct(M)}const Vt=ut!=null&&tt==null;(bt&&(Mt=$&&$.onVnodeUnmounted)||xt||Vt)&&ge(()=>{Mt&&Ne(Mt,L,M),xt&&wi(M,null,L,"unmounted"),Vt&&(M.el=null)},f)},ct=M=>{const{type:L,el:f,anchor:F,transition:P}=M;if(L===Gt){rt(f,F);return}if(L===Un){I(M);return}const _=()=>{n(f),P&&!P.persisted&&P.afterLeave&&P.afterLeave()};if(M.shapeFlag&1&&P&&!P.persisted){const{leave:$,delayLeave:B}=P,K=()=>$(f,_);B?B(M.el,_,K):K()}else _()},rt=(M,L)=>{let f;for(;M!==L;)f=g(M),n(M),M=f;n(L)},st=(M,L,f)=>{const{bum:F,scope:P,job:_,subTree:$,um:B,m:K,a:H}=M;tr(K),tr(H),F&&Hn(F),P.stop(),_&&(_.flags|=8,N($,M,L,f)),B&&ge(B,L),ge(()=>{M.isUnmounted=!0},L)},J=(M,L,f,F=!1,P=!1,_=0)=>{for(let $=_;$<M.length;$++)N(M[$],L,f,F,P)},gt=M=>{if(M.shapeFlag&6)return gt(M.component.subTree);if(M.shapeFlag&128)return M.suspense.next();const L=g(M.anchor||M.el),f=L&&L[Fc];return f?g(f):L};let mt=!1;const Z=(M,L,f)=>{let F;M==null?L._vnode&&(N(L._vnode,null,null,!0),F=L._vnode.component):p(L._vnode||null,M,L,null,null,null,f),L._vnode=M,mt||(mt=!0,Uo(F),rl(),mt=!1)},ot={p,um:N,m:V,r:ct,mt:w,mc:E,pc:at,pbc:R,n:gt,o:t};return{render:Z,hydrate:void 0,createApp:cd(Z)}}function Ts({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function xi({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Cd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Tl(t,i,e=!1){const s=t.children,n=i.children;if(Ct(s)&&Ct(n))for(let r=0;r<s.length;r++){const l=s[r];let o=n[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=n[r]=Xe(n[r]),o.el=l.el),!e&&o.patchFlag!==-2&&Tl(l,o)),o.type===ms&&(o.patchFlag===-1&&(o=n[r]=Xe(o)),o.el=l.el),o.type===li&&!o.el&&(o.el=l.el)}}function $d(t){const i=t.slice(),e=[0];let s,n,r,l,o;const a=t.length;for(s=0;s<a;s++){const c=t[s];if(c!==0){if(n=e[e.length-1],t[n]<c){i[s]=n,e.push(s);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[s]=e[r-1]),e[r]=s)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function El(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:El(i)}function tr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Ml(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Ml(i.subTree):null}const Bl=t=>t.__isSuspense;function Id(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Pc(t)}const Gt=Symbol.for("v-fgt"),ms=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),Un=Symbol.for("v-stc"),ii=[];let we=null;function et(t=!1){ii.push(we=t?null:[])}function wo(){ii.pop(),we=ii[ii.length-1]||null}let wn=1;function er(t,i=!1){wn+=t,t<0&&we&&i&&(we.hasOnce=!0)}function Dl(t){return t.dynamicChildren=wn>0?we||Hi:null,wo(),wn>0&&we&&we.push(t),t}function nt(t,i,e,s,n,r){return Dl(m(t,i,e,s,n,r,!0))}function Be(t,i,e,s,n){return Dl(pt(t,i,e,s,n,!0))}function xo(t){return t?t.__v_isVNode===!0:!1}function en(t,i){return t.type===i.type&&t.key===i.key}const Ol=({key:t})=>t??null,Wn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||ue(t)||It(t)?{i:oe,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,s=0,n=null,r=t===Gt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ol(i),ref:i&&Wn(i),scopeId:al,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:oe};return o?(ts(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),wn>0&&!l&&we&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&we.push(a),a}const pt=Ad;function Ad(t,i=null,e=null,s=0,n=null,r=!1){if((!t||t===td)&&(t=li),xo(t)){const o=Zi(t,i,!0);return e&&ts(o,e),wn>0&&!r&&we&&(o.shapeFlag&6?we[we.indexOf(t)]=o:we.push(o)),o.patchFlag=-2,o}if(Fd(t)&&(t=t.__vccOpts),i){i=Td(i);let{class:o,style:a}=i;o&&!Qt(o)&&(i.class=Et(o)),jt(a)&&(ho(a)&&!Ct(a)&&(a=re({},a)),i.style=oo(a))}const l=Qt(t)?1:Bl(t)?128:jc(t)?64:jt(t)?4:It(t)?2:0;return m(t,i,e,s,n,l,r,!0)}function Td(t){return t?ho(t)||_l(t)?re({},t):t:null}function Zi(t,i,e=!1,s=!1){const{props:n,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?Ed(n||{},i):n,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ol(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Wn(i)):[r,Wn(i)]:Wn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Zi(t.ssContent),ssFallback:t.ssFallback&&Zi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&s&&go(d,a.clone(d)),d}function Ys(t=" ",i=0){return pt(ms,null,t,i)}function Ae(t,i){const e=pt(Un,null,t);return e.staticCount=i,e}function Ft(t="",i=!1){return i?(et(),Be(li,null,t)):pt(li,null,t)}function Ue(t){return t==null||typeof t=="boolean"?pt(li):Ct(t)?pt(Gt,null,t.slice()):xo(t)?Xe(t):pt(ms,null,String(t))}function Xe(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Zi(t)}function ts(t,i){let e=0;const{shapeFlag:s}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(s&65){const n=i.default;n&&(n._c&&(n._d=!1),ts(t,n()),n._c&&(n._d=!0));return}else{e=32;const n=i._;!n&&!_l(i)?i._ctx=oe:n===3&&oe&&(oe.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(s&65){ts(t,{default:i});return}i={default:i,_ctx:oe},e=32}else i=String(i),s&64?(e=16,i=[Ys(i)]):e=8;t.children=i,t.shapeFlag|=e}function Ed(...t){const i={};for(let e=0;e<t.length;e++){const s=t[e];for(const n in s)if(n==="class")i.class!==s.class&&(i.class=Et([i.class,s.class]));else if(n==="style")i.style=oo([i.style,s.style]);else if(ss(n)){const r=i[n],l=s[n];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[n]=r?[].concat(r,l):l:l==null&&r==null&&!os(n)&&(i[n]=l)}else n!==""&&(i[n]=s[n])}return i}function Ne(t,i,e,s=null){Le(t,i,7,[e,s])}const Md=bl();let Bd=0;function Dd(t,i,e){const s=t.type,n=(i?i.appContext:t.appContext)||Md,r={uid:Bd++,vnode:t,type:s,parent:i,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new oc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(n.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Cl(s,n),emitsOptions:yl(s,n),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:s.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=ud.bind(null,r),t.ce&&t.ce(r),r}let ce=null;const Od=()=>ce||oe;let es,Js;{const t=cs(),i=(e,s)=>{let n;return(n=t[e])||(n=t[e]=[]),n.push(s),r=>{n.length>1?n.forEach(l=>l(r)):n[0](r)}};es=i("__VUE_INSTANCE_SETTERS__",e=>ce=e),Js=i("__VUE_SSR_SETTERS__",e=>xn=e)}const An=t=>{const i=ce;return es(t),t.scope.on(),()=>{t.scope.off(),es(i)}},ir=()=>{ce&&ce.scope.off(),es(null)};function Pl(t){return t.vnode.shapeFlag&4}let xn=!1;function Pd(t,i=!1,e=!1){i&&Js(i);const{props:s,children:n}=t.vnode,r=Pl(t);vd(t,s,r,i),wd(t,n,e||i);const l=r?Ld(t,i):void 0;return i&&Js(!1),l}function Ld(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,id);const{setup:s}=e;if(s){si();const n=t.setupContext=s.length>1?zd(t):null,r=An(t),l=$n(s,t,0,[t.props,n]),o=Pr(l);if(oi(),r(),(o||t.sp)&&!Vi(t)&&fl(t),o){if(l.then(ir,ir),i)return l.then(a=>{nr(t,a)}).catch(a=>{fs(a,t,0)});t.asyncDep=l}else nr(t,l)}else Ll(t)}function nr(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=il(i)),Ll(t)}function Ll(t,i,e){const s=t.type;t.render||(t.render=s.render||qe);{const n=An(t);si();try{nd(t)}finally{oi(),n()}}}const Rd={get(t,i){return ae(t,"get",""),t[i]}};function zd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Rd),slots:t.slots,emit:t.emit,expose:i}}function gs(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(il(Cc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in gn)return gn[e](t)},has(i,e){return e in i||e in gn}})):t.proxy}function Nd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Fd(t){return It(t)&&"__vccOpts"in t}const $t=(t,i)=>Ec(t,i,xn),jd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Xs;const sr=typeof window<"u"&&window.trustedTypes;if(sr)try{Xs=sr.createPolicy("vue",{createHTML:t=>t})}catch{}const Rl=Xs?t=>Xs.createHTML(t):t=>t,Hd="http://www.w3.org/2000/svg",Ud="http://www.w3.org/1998/Math/MathML",Je=typeof document<"u"?document:null,or=Je&&Je.createElement("template"),Wd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,s)=>{const n=i==="svg"?Je.createElementNS(Hd,t):i==="mathml"?Je.createElementNS(Ud,t):e?Je.createElement(t,{is:e}):Je.createElement(t);return t==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:t=>Je.createTextNode(t),createComment:t=>Je.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Je.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,s,n,r){const l=e?e.previousSibling:i.lastChild;if(n&&(n===r||n.nextSibling))for(;i.insertBefore(n.cloneNode(!0),e),!(n===r||!(n=n.nextSibling)););else{or.innerHTML=Rl(s==="svg"?`<svg>${t}</svg>`:s==="mathml"?`<math>${t}</math>`:t);const o=or.content;if(s==="svg"||s==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Vd=Symbol("_vtc");function Kd(t,i,e){const s=t[Vd];s&&(i=(i?[i,...s]:[...s]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const is=Symbol("_vod"),zl=Symbol("_vsh"),Nl={name:"show",beforeMount(t,{value:i},{transition:e}){t[is]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):nn(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:s}){!i!=!e&&(s?i?(s.beforeEnter(t),nn(t,!0),s.enter(t)):s.leave(t,()=>{nn(t,!1)}):nn(t,i))},beforeUnmount(t,{value:i}){nn(t,i)}};function nn(t,i){t.style.display=i?t[is]:"none",t[zl]=!i}const qd=Symbol(""),Gd=/(?:^|;)\s*display\s*:/;function Zd(t,i,e){const s=t.style,n=Qt(e);let r=!1;if(e&&!n){if(i)if(Qt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&rn(s,o,"")}else for(const l in i)e[l]==null&&rn(s,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?Jd(t,l,!Qt(i)&&i?i[l]:void 0,o)||rn(s,l,o):rn(s,l,"")}}else if(n){if(i!==e){const l=s[qd];l&&(e+=";"+l),s.cssText=e,r=Gd.test(e)}}else i&&t.removeAttribute("style");is in t&&(t[is]=r?s.display:"",t[zl]&&(s.display="none"))}const rr=/\s*!important$/;function rn(t,i,e){if(Ct(e))e.forEach(s=>rn(t,i,s));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const s=Yd(t,i);rr.test(e)?t.setProperty(gi(s),e.replace(rr,""),"important"):t[s]=e}}const lr=["Webkit","Moz","ms"],Es={};function Yd(t,i){const e=Es[i];if(e)return e;let s=he(i);if(s!=="filter"&&s in t)return Es[i]=s;s=ls(s);for(let n=0;n<lr.length;n++){const r=lr[n]+s;if(r in t)return Es[i]=r}return i}function Jd(t,i,e,s){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(s)&&e===s}const ar="http://www.w3.org/1999/xlink";function cr(t,i,e,s,n,r=nc(i)){s&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ar,i.slice(6,i.length)):t.setAttributeNS(ar,i,e):e==null||r&&!Nr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Oe(e)?String(e):e)}function dr(t,i,e,s,n){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Rl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Nr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(n||i)}function ui(t,i,e,s){t.addEventListener(i,e,s)}function Xd(t,i,e,s){t.removeEventListener(i,e,s)}const ur=Symbol("_vei");function Qd(t,i,e,s,n=null){const r=t[ur]||(t[ur]={}),l=r[i];if(s&&l)l.value=s;else{const[o,a]=iu(i);if(s){const c=r[i]=ou(s,n);ui(t,o,c,a)}else l&&(Xd(t,o,l,a),r[i]=void 0)}}const tu=/(Once|Passive|Capture)$/,eu=/^on:?(?:Once|Passive|Capture)$/;function iu(t){let i,e;for(;(e=t.match(tu))&&!eu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):gi(t.slice(2)),i]}let Ms=0;const nu=Promise.resolve(),su=()=>Ms||(nu.then(()=>Ms=0),Ms=Date.now());function ou(t,i){const e=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=e.attached)return;const n=e.value;if(Ct(n)){const r=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{r.call(s),s._stopped=!0};const l=n.slice(),o=[s];for(let a=0;a<l.length&&!s._stopped;a++){const c=l[a];c&&Le(c,i,5,o)}}else Le(n,i,5,[s])};return e.value=t,e.attached=su(),e}const fr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,ru=(t,i,e,s,n,r)=>{const l=n==="svg";i==="class"?Kd(t,s,l):i==="style"?Zd(t,e,s):ss(i)?os(i)||Qd(t,i,e,s,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):lu(t,i,s,l))?(dr(t,i,s),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&cr(t,i,s,l,r,i!=="value")):t._isVueCE&&(au(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(s)))?dr(t,he(i),s,r,i):(i==="true-value"?t._trueValue=s:i==="false-value"&&(t._falseValue=s),cr(t,i,s,l))};function lu(t,i,e,s){if(s)return!!(i==="innerHTML"||i==="textContent"||i in t&&fr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const n=t.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return fr(i)&&Qt(e)?!1:i in t}function au(t,i){const e=t._def.props;if(!e)return!1;const s=he(i);return Array.isArray(e)?e.some(n=>he(n)===s):Object.keys(e).some(n=>he(n)===s)}const Yi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Hn(i,e):i};function cu(t){t.target.composing=!0}function pr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ni=Symbol("_assign");function hr(t,i,e){return i&&(t=t.trim()),e&&(t=as(t)),t}const ns={created(t,{modifiers:{lazy:i,trim:e,number:s}},n){t[ni]=Yi(n);const r=s||n.props&&n.props.type==="number";ui(t,i?"change":"input",l=>{l.target.composing||t[ni](hr(t.value,e,r))}),(e||r)&&ui(t,"change",()=>{t.value=hr(t.value,e,r)}),i||(ui(t,"compositionstart",cu),ui(t,"compositionend",pr),ui(t,"change",pr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:s,trim:n,number:r}},l){if(t[ni]=Yi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?as(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(s&&i===e||n&&t.value.trim()===a)||(t.value=a)}},zn={deep:!0,created(t,i,e){t[ni]=Yi(e),ui(t,"change",()=>{const s=t._modelValue,n=_n(t),r=t.checked,l=t[ni];if(Ct(s)){const o=ro(s,n),a=o!==-1;if(r&&!a)l(s.concat(n));else if(!r&&a){const c=[...s];c.splice(o,1),l(c)}}else if(Xi(s)){const o=new Set(s);r?o.add(n):o.delete(n),l(o)}else l(Fl(t,r))})},mounted:mr,beforeUpdate(t,i,e){t[ni]=Yi(e),mr(t,i,e)}};function mr(t,{value:i,oldValue:e},s){t._modelValue=i;let n;if(Ct(i))n=ro(i,s.props.value)>-1;else if(Xi(i))n=i.has(s.props.value);else{if(i===e)return;n=Qi(i,Fl(t,!0))}t.checked!==n&&(t.checked=n)}const du={deep:!0,created(t,{value:i,modifiers:{number:e}},s){t._modelValue=i,ui(t,"change",()=>{const n=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?as(_n(r)):_n(r));t[ni](t.multiple?Xi(t._modelValue)?new Set(n):n:n[0]),t._assigning=!0,sl(()=>{t._assigning=!1})}),t[ni]=Yi(s)},mounted(t,{value:i}){gr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ni]=Yi(e)},updated(t,{value:i}){t._assigning||gr(t,i)}};function gr(t,i){const e=t.multiple,s=Ct(i);if(!(e&&!s&&!Xi(i))){for(let n=0,r=t.options.length;n<r;n++){const l=t.options[n],o=_n(l);if(e)if(s){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=ro(i,o)>-1}else l.selected=i.has(o);else if(Qi(_n(l),i)){t.selectedIndex!==n&&(t.selectedIndex=n);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function _n(t){return"_value"in t?t._value:t.value}function Fl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const uu=["ctrl","shift","alt","meta"],fu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>uu.some(e=>t[`${e}Key`]&&!i.includes(e))},Me=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),s=i.join(".");return e[s]||(e[s]=((n,...r)=>{for(let l=0;l<i.length;l++){const o=fu[i[l]];if(o&&o(n,i))return}return t(n,...r)}))},pu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},hu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),s=i.join(".");return e[s]||(e[s]=(n=>{if(!("key"in n))return;const r=gi(n.key);if(i.some(l=>l===r||pu[l]===r))return t(n)}))},mu=re({patchProp:ru},Wd);let vr;function gu(){return vr||(vr=_d(mu))}const jl=((...t)=>{const i=gu().createApp(...t),{mount:e}=i;return i.mount=s=>{const n=bu(s);if(!n)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=e(n,!1,vu(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},i});function vu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function bu(t){return Qt(t)?document.querySelector(t):t}function yu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function xe(t){const i=yu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function _o(){var i;if(typeof window<"u"&&window.process)return window.process;const t=xe("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Hl(){var i,e;const t=_o();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const s=xe("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Sn(){const t=_o();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=xe("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Ul(){var s,n;const t=_o(),i={...(t==null?void 0:t.env)||{}};if(Sn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=t==null?void 0:t.env)!=null&&s.APPDATA?`${t.env.APPDATA}\\npm`:"",(n=t==null?void 0:t.env)!=null&&n.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Qs(t){var e,s,n;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((n=(s=(e=window.siyuan)==null?void 0:e.config)==null?void 0:s.system)!=null&&n.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function ku(){const t=xe("os"),i=xe("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class So{constructor(i){wt(this,"runner");this.runner=i||So.defaultRunner}static async defaultRunner(i,e){var s;try{let n=(s=xe("child_process"))==null?void 0:s.execFile;if(!n){const a=await import("node:child_process").catch(()=>({}));n=a==null?void 0:a.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Sn()==="win32",o=Ul();return await new Promise(a=>{n(i,e,{timeout:5e3,shell:l,env:o},(c,d,h)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:h?String(h).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const i=Hl(),e=Sn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(s=!0,n=o.stdout)}catch{}if(s){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class wu{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(e.type==="update-state"&&e.navState){const s=e.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const s of this.pageChangedHandlers)s(e.no,this.currentState.total||1,this.currentState)}}}}class xu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=xe("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(s=>{const n=e.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=e+s;if(await this.isPortAvailable(n))return n}return e}async pollServerReady(i,e=8e3,s=300){const n=Date.now();for(;Date.now()-n<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),s),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,s))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(e);this.activePort=s;const r=Sn()==="win32"?"npx.cmd":"npx",l=Qs(i),o=["@slidev/cli",l,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let h=(a=xe("child_process"))==null?void 0:a.spawn;if(!h){const k=await import("node:child_process").catch(()=>({}));h=k==null?void 0:k.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ul();this.childProcess=h(r,o,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Sn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const s=(i=xe("child_process"))==null?void 0:i.exec;s?s(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:n})=>{var r;n(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Co{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var n;const s={source:"siyuan-slidev-host",action:i,payload:e};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,s,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:s,customThemeCss:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var s;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const n=this.pendingMessages.shift();n&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(n,"*")}for(const n of this.clientReadyHandlers)n();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const n of this.slideChangedHandlers)n(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const n of this.blockClickedHandlers)n(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const n=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(n,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const n=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:n,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const n of this.toggleFullscreenHandlers)n();break}}}const Wl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},_u=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Su=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Cu=`${Fs}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
}
.slide-list-media {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
}
.slide-video-container {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function $u(t){var n;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=e.exec(t))!==null;){const r=(n=s[1])==null?void 0:n.trim();r&&!i.includes(r)&&i.push(r)}return i}class Iu{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new eo);const e=ku();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const s=this.buildSlidesMarkdown(i),n=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=Qs(r),a=Qs(l),c=$u(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const y=Wl[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,y)}i.slides.some(v=>{var y;return((y=v.frontmatter)==null?void 0:y.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",_u),d.set("setup/root.ts",Su),d.set("styles/index.css",Cu);const g=xe("fs"),u=xe("path");let k=!1;const p=u!=null&&u.dirname?u.dirname(o):"",b=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(g&&u&&b)try{g.existsSync(p)||g.mkdirSync(p,{recursive:!0}),g.writeFileSync(a,n,"utf-8"),g.writeFileSync(o,s,"utf-8");for(const[v,y]of d.entries()){const S=u.join(p,v),I=u.dirname(S);g.existsSync(I)||g.mkdirSync(I,{recursive:!0}),g.existsSync(S)||g.writeFileSync(S,y,"utf-8")}k=!0}catch{}if(!k&&e)try{const v=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),y=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await e(l,!1,y),await e(r,!1,v);for(const[S,I]of d.entries()){const x=`${this.workspacePath}/${S}`,C=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await e(x,!1,C).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class Au{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new Co,this.cliBridge=new eo,this.nativeBridge=new wu,this.processManager=new xu,this.scaffolder=new Iu,this.envDetector=new So}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(i,e);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const r=n.physicalSlidesPath||n.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Tu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Eu={key:0},Mu={key:1},Bu={key:2},Du={key:3},Ou={key:4},Pu={key:5},Lu={key:6},Ru={key:7},zu={key:8},Nu={key:9},Fu={key:10},ju={key:11},Hu={key:12},Uu={key:13},Wu={key:14},Vu={key:15},Ku={key:16},qu={key:17},Gu={key:18},Zu={key:19},Yu={key:20},Ju={key:21},Xu={key:22},Qu={key:23},tf={key:24},ef={key:25},nf={key:26},sf={key:27},of={key:28},rf={key:29},lf={key:30},af={key:31},cf={key:32},df={key:33},uf={key:34},ff={key:35},pf={key:36},hf={key:37},mf={key:38},gf={key:39},vf={key:40},bf={key:41},yf={key:42},kf={key:43},wf={key:44},xf={key:45},_f={key:46},Sf={key:47},Cf={key:48},$f={key:49},If={key:50},Af={key:51},Tf={key:52},Ef=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(et(),nt("svg",Tu,[t.name==="fullscreen"||t.name==="maximize"?(et(),nt("g",Eu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(et(),nt("g",Mu,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(et(),nt("g",Bu,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(et(),nt("g",Du,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(et(),nt("g",Ou,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(et(),nt("g",Pu,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(et(),nt("g",Lu,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(et(),nt("g",Ru,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(et(),nt("g",zu,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(et(),nt("g",Nu,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(et(),nt("g",Fu,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(et(),nt("g",ju,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(et(),nt("g",Hu,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(et(),nt("g",Uu,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(et(),nt("g",Wu,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(et(),nt("g",Vu,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(et(),nt("g",Ku,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(et(),nt("g",qu,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(et(),nt("g",Gu,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(et(),nt("g",Zu,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(et(),nt("g",Yu,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(et(),nt("g",Ju,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(et(),nt("g",Xu,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(et(),nt("g",Qu,[...e[23]||(e[23]=[Ae('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(et(),nt("g",tf,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(et(),nt("g",ef,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(et(),nt("g",nf,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(et(),nt("g",sf,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(et(),nt("g",of,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(et(),nt("g",rf,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(et(),nt("g",lf,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(et(),nt("g",af,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(et(),nt("g",cf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(et(),nt("g",df,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(et(),nt("g",uf,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(et(),nt("g",ff,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(et(),nt("g",pf,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(et(),nt("g",hf,[...e[37]||(e[37]=[Ae('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(et(),nt("g",mf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(et(),nt("g",gf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(et(),nt("g",vf,[...e[40]||(e[40]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(et(),nt("g",bf,[...e[41]||(e[41]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(et(),nt("g",yf,[...e[42]||(e[42]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(et(),nt("g",kf,[...e[43]||(e[43]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(et(),nt("g",wf,[...e[44]||(e[44]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(et(),nt("g",xf,[...e[45]||(e[45]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(et(),nt("g",_f,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(et(),nt("g",Sf,[...e[47]||(e[47]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(et(),nt("g",Cf,[...e[48]||(e[48]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(et(),nt("g",$f,[...e[49]||(e[49]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(et(),nt("g",If,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(et(),nt("g",Af,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(et(),nt("g",Tf,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Re=(t,i)=>{const e=t.__vccOpts||t;for(const[s,n]of i)e[s]=n;return e},kt=Re(Ef,[["__scopeId","data-v-b8552023"]]);function se(t,i){var n;if(typeof document>"u"||!t)return;const e=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${e}"]`);!s||s.length===0||s.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function Mf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ft}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout"),s.removeAttribute(qt),s.removeAttribute("custom-slidev-role");return}const r=t.get(n),l=(r==null?void 0:r[ft])||(r==null?void 0:r["custom-slidev-layout"])||"",o=s.getAttribute(ft)||s.getAttribute("custom-slidev-layout");o&&o!==l&&(l?s.setAttribute(ft,l):(s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[qt])||(r==null?void 0:r["custom-slidev-role"])||"",c=s.getAttribute(qt)||s.getAttribute("custom-slidev-role");c&&c!==a&&(a?s.setAttribute(qt,a):(s.removeAttribute(qt),s.removeAttribute("custom-slidev-role")))})}const Bf={class:"spm-layout-picker"},Df={class:"spm-layout-picker__grid"},Of=["title","onClick"],Pf={class:"spm-layout-icon"},Lf={class:"spm-layout-label"},Rf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",Bf,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Df,[(et(),nt(Gt,null,ke(s,o=>m("div",{key:o.name,class:Et(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>n(o.name)},[m("div",Pf,[pt(kt,{name:"layout-"+o.name},null,8,["name"])]),m("span",Lf,St(o.label),1)],10,Of)),64))])]))}}),Vl=Re(Rf,[["__scopeId","data-v-c57441d5"]]),zf={key:0,class:"spm-transition-selector__header"},Nf={class:"spm-transition-list"},Ff=["onClick"],jf={class:"spm-transition-meta"},Hf={class:"spm-transition-label"},Uf={class:"spm-transition-name"},Wf={class:"spm-transition-preview-box"},Vf=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",{class:Et(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ft("",!0):(et(),nt("div",zf,St(t.title||"转场动效"),1)),m("div",Nf,[(et(),nt(Gt,null,ke(s,o=>m("div",{key:o.name,class:Et(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>n(o.name)},[m("div",jf,[m("span",Hf,St(o.label),1),m("span",Uf,"("+St(o.name)+")",1)]),m("div",Wf,[m("div",{class:Et(["spm-anim-cube","anim-"+o.name])},null,2)])],10,Ff)),64))])],2))}}),$o=Re(Vf,[["__scopeId","data-v-b0aa61ff"]]),Kf={class:"spm-divider-popover"},qf={class:"spm-divider-popover__title"},Gf={class:"spm-form-item"},Zf={class:"spm-popover-footer"},Yf={class:"spm-save-hint"},Jf=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,k;const e=t,s=i,n=ht(((g=e.initialAttrs)==null?void 0:g[ft])||"default"),r=ht(((u=e.initialAttrs)==null?void 0:u[Xt])||"slide-left"),l=ht(((k=e.initialAttrs)==null?void 0:k[Ut])||""),o=ht("");Mi(()=>e.initialAttrs,p=>{n.value=(p==null?void 0:p[ft])||"default",r.value=(p==null?void 0:p[Xt])||"slide-left",l.value=(p==null?void 0:p[Ut])||""},{deep:!0});async function a(p,b){if(e.blockId){o.value="正在同步...",Ht.setBlockAttrOverride(e.blockId,{[p]:b}),se(e.blockId,{[p]:b});try{await zt(e.blockId,{[p]:b}),o.value="已同步至块属性",s("updated",{[p]:b}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(p){a(ft,p)}function d(p){a(Xt,p)}function h(){a(Ut,l.value.trim())}return(p,b)=>(et(),nt("div",Kf,[m("div",qf,[b[4]||(b[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=v=>s("close"))},"✕")]),pt(Vl,{modelValue:n.value,"onUpdate:modelValue":b[1]||(b[1]=v=>n.value=v),onChange:c},null,8,["modelValue"]),pt($o,{modelValue:r.value,"onUpdate:modelValue":b[2]||(b[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),m("div",Gf,[b[5]||(b[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Te(m("input",{"onUpdate:modelValue":b[3]||(b[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[ns,l.value]])]),m("div",Zf,[m("span",Yf,St(o.value),1)])]))}}),Xf=Re(Jf,[["__scopeId","data-v-e4871368"]]),Qf={class:"spm-slide-inspector"},tp={class:"spm-inspector-header"},ep={class:"spm-inspector-list"},ip=["onClick"],np={class:"spm-card-top"},sp={class:"spm-card-badge"},op={class:"spm-card-layout"},rp=["onClick"],lp={class:"spm-card-preview"},ap={key:0,class:"spm-card-notes",title:"演讲备忘录"},cp={class:"spm-inspector-modal-content"},dp=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,s=ht(null);function n(c){s.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ft]=c.frontmatter.layout),c.frontmatter.transition&&(d[Xt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[Fi]=c.notes),d}function l(c){s.value&&(c[ft]&&(s.value.frontmatter.layout=c[ft]),c[Xt]&&(s.value.frontmatter.transition=c[Xt]),c[Ut]&&(s.value.frontmatter.background=c[Ut]),c[Fi]&&(s.value.notes=c[Fi]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],h=d.content||d.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,d)=>(et(),nt("div",Qf,[m("div",tp,[m("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),m("div",ep,[(et(!0),nt(Gt,null,ke(t.slides,h=>(et(),nt("div",{key:h.pageIndex,class:Et(["spm-card",{active:t.currentActivePage===h.pageIndex}]),onClick:g=>o(h.pageIndex)},[m("div",np,[m("span",sp,"P"+St(h.pageIndex),1),m("span",op,St(h.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(g=>n(h),["stop"])},[pt(kt,{name:"settings"})],8,rp)]),m("div",lp,St(a(h)),1),h.notes?(et(),nt("div",ap,[pt(kt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,St(h.notes),1)])):Ft("",!0)],10,ip))),128))]),s.value?(et(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Me(h=>s.value=null,["self"]))},[m("div",cp,[pt(Xf,{"block-id":s.value.startBlockId,"initial-attrs":r(s.value),onClose:d[0]||(d[0]=h=>s.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ft("",!0)]))}}),up=Re(dp,[["__scopeId","data-v-68b25edd"]]),fp={class:"spm-immersion-header"},pp={class:"spm-immersion-header__left"},hp={class:"spm-immersion-title"},mp={class:"spm-immersion-header__center"},gp={class:"spm-immersion-header__actions"},vp=["aria-label"],bp={class:"spm-immersion-body"},yp=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,s=i;function n(){s("update:visible",!1),s("close")}function r(){e.closeOnClickMask&&n()}function l(){s("update:isMaximized",!e.isMaximized),s("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Te((et(),nt("div",{class:Et(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(o,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:Et(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",fp,[m("div",pp,[Rn(a.$slots,"header-left",{},()=>[m("span",hp,St(t.title),1)])]),m("div",mp,[Rn(a.$slots,"header-center",{},void 0)]),m("div",gp,[Rn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[pt(kt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,vp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[pt(kt,{name:"close"})])])]),m("div",bp,[Rn(a.$slots,"default",{},void 0)])],2)],34)),[[Nl,t.visible]])}}),kp=Re(yp,[["__scopeId","data-v-3f1665db"]]),wp="slidev-config.json",Ji={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ai=us({...Ji});function xp(t){if(!t||typeof t!="object")return{...Ji};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Ji.webServeUrl}}function qi(t){if(!t||typeof t!="object")return{...Ai};const i=t;return i.enableWebServeJump!==void 0&&(Ai.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ai.webServeUrl=String(i.webServeUrl)),{...Ai}}function Io(){return{...Ai}}function Kl(t,i,e){const s=(t||Ji.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const _p={class:"spm-protyle-drawer"},Sp={class:"spm-protyle-drawer__subbar"},Cp={class:"spm-protyle-drawer__nav"},$p=["title"],Ip={class:"spm-protyle-drawer__actions"},Ap=["aria-label"],Tp=["aria-label"],Ep=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(s.blockId),r=ht(s.title||""),l=ht(!1),o=ht(!0),a=ht(!1),c=ht(""),d=Ai,h=ht([]),g=ht(null);let u=null;Mi(()=>s.blockId,A=>{A&&A!==n.value&&(n.value=A,r.value=s.title||"",h.value=[],p(A))}),In(()=>{n.value&&p(n.value)}),vo(()=>{b()});async function k(A){try{const E=await vn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${A}' LIMIT 1`);if(Array.isArray(E)&&E.length>0){const D=E[0];c.value=D.root_id||"";const R=D.id===D.root_id||D.type==="d";a.value=R,o.value=!R,!r.value&&D.content&&(r.value=D.content.trim().slice(0,30));return}}catch(E){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",E)}a.value=!1,o.value=!0}async function p(A,E){if(!g.value||!A)return;b(),await k(A),typeof E=="boolean"&&(o.value=!a.value&&E);let D,R;o.value&&!a.value?(D=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(D=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new vt.Protyle(s.plugin.app,g.value,{blockId:A,action:D,render:R}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(A){console.warn("[ProtylePeekDrawer] Error destroying protyle:",A)}u=null}g.value&&(g.value.innerHTML="")}function v(){a.value||(o.value=!o.value,p(n.value,o.value))}function y(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(n.value)try{vt.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(A){console.warn("[ProtylePeekDrawer] openWindow failed:",A)}}function I(){var D;if(!n.value)return;const A=Io(),E=Kl(A.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const R=xe("electron");(D=R==null?void 0:R.shell)!=null&&D.openExternal?R.shell.openExternal(E).catch(()=>{window.open(E,"_blank")}):window.open(E,"_blank")}e("external-jump",E)}function x(){if(h.value.length>0){const A=h.value.pop();A&&(n.value=A.blockId,r.value=A.title,o.value=A.isFocusMode,a.value=A.isDoc,p(A.blockId,A.isFocusMode))}}function C(A){const E=A.target;if(!E)return;const D=E.closest('[data-type="block-ref"]');if(D){const X=D.getAttribute("data-id");if(X&&X!==n.value){A.preventDefault(),A.stopPropagation(),h.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=X,r.value=D.innerText.trim()||X,p(X);return}}const R=E.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){A.preventDefault(),A.stopPropagation();const X=R.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==n.value&&(h.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=X,r.value=R.innerText.trim()||X,p(X))}}return(A,E)=>(et(),nt("div",_p,[m("div",Sp,[m("div",Cp,[h.value.length>0?(et(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[pt(kt,{name:"arrow-left"}),E[0]||(E[0]=m("span",null,"返回",-1))])):Ft("",!0),m("span",{class:Et(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},St(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||n.value},St(r.value||n.value),9,$p)]),m("div",Ip,[a.value?Ft("",!0):(et(),nt("button",{key:0,class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[pt(kt,{name:o.value?"focus":"file-text"},null,8,["name"]),m("span",null,St(o.value?"块聚焦":"展开全文"),1)],10,Ap)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:y},[pt(kt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,St(l.value?"编辑中":"只读"),1)],10,Tp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[pt(kt,{name:"window"}),E[1]||(E[1]=m("span",null,"独立窗口",-1))]),Ii(d).enableWebServeJump?(et(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:I},[pt(kt,{name:"external-link"}),E[2]||(E[2]=m("span",null,"外跳",-1))])):Ft("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:Et(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:C},null,2)]))}}),Mp=Re(Ep,[["__scopeId","data-v-7e586ef3"]]),Bp={class:"spm-webview-drawer"},Dp={class:"spm-webview-toolbar"},Op={class:"spm-webview-toolbar__nav"},Pp=["disabled"],Lp=["disabled"],Rp=["aria-label"],zp={class:"spm-webview-toolbar__address"},Np=["aria-label"],Fp={class:"spm-webview-toolbar__actions"},jp=["aria-label"],Hp={class:"spm-zoom-controller"},Up=["disabled"],Wp=["disabled"],Vp={key:1,class:"spm-webview-fallback"},Kp=["src"],br="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ql="siyuan-slidev-peek-view-mode";let Gl="desktop";function qp(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ql);if(t==="mobile"||t==="desktop")return t}catch{}return Gl}function Gp(t){if(Gl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ql,t)}catch{}}const Zp=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(Hl()),r=ht(s.url),l=ht(s.url),o=ht(!1),a=ht(!1),c=ht(!1),d=ht(1),h=ht(!1),g=ht(qp());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=$t(()=>g.value==="mobile"?br:u||void 0),p=ht(null),b=ht(null);let v=null,y=null,S=null;Mi(()=>s.url,J=>{J&&J!==r.value&&(r.value=J,l.value=J,g.value==="mobile"&&E(!1),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(J))}),Mi(()=>s.visible,J=>{if(J)W(),g.value==="mobile"&&E(!1);else if(p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}}),In(()=>{I(),b.value&&typeof ResizeObserver<"u"&&(v=new ResizeObserver(()=>{const J=p.value;if(J&&typeof J.invalidate=="function")try{J.invalidate()}catch{}}),v.observe(b.value)),y=J=>{var mt;const gt=J.message||((mt=J.error)==null?void 0:mt.message);if(typeof gt=="string"&&gt.includes("Invalid guestInstanceId"))return J.preventDefault(),J.stopImmediatePropagation(),!0},window.addEventListener("error",y,!0),S=J=>{const gt=J.reason,mt=typeof gt=="string"?gt:gt==null?void 0:gt.message;typeof mt=="string"&&mt.includes("Invalid guestInstanceId")&&J.preventDefault()},window.addEventListener("unhandledrejection",S)}),vo(()=>{if(x(),v&&(v.disconnect(),v=null),y&&(window.removeEventListener("error",y,!0),y=null),S&&(window.removeEventListener("unhandledrejection",S),S=null),p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}});function I(){const J=p.value;J&&(J.addEventListener("dom-ready",C),J.addEventListener("did-start-loading",D),J.addEventListener("did-stop-loading",R),J.addEventListener("did-navigate",X),J.addEventListener("did-navigate-in-page",T),J.addEventListener("new-window",O))}function x(){const J=p.value;if(J)try{J.removeEventListener("dom-ready",C),J.removeEventListener("did-start-loading",D),J.removeEventListener("did-stop-loading",R),J.removeEventListener("did-navigate",X),J.removeEventListener("did-navigate-in-page",T),J.removeEventListener("new-window",O)}catch{}}function C(){const J=p.value;if(J&&typeof J.getUserAgent=="function"&&!u)try{const gt=J.getUserAgent();gt&&!gt.includes("iPhone")&&(u=gt)}catch{}g.value==="mobile"&&E(!1),W(),w()}function A(){const J=g.value==="mobile"?"desktop":"mobile";g.value=J,Gp(J),E(!0)}function E(J=!1){const gt=p.value;if(!gt)return;const mt=g.value==="mobile"?br:u;if(typeof gt.setUserAgent=="function"&&mt)try{gt.setUserAgent(mt)}catch(Z){console.warn("[WebviewPeekDrawer] setUserAgent error:",Z)}if(J&&typeof gt.reload=="function")try{gt.reload()}catch(Z){console.warn("[WebviewPeekDrawer] reload error:",Z)}}function D(){o.value=!0}function R(){if(o.value=!1,w(),p.value&&typeof p.value.getURL=="function"){const J=p.value.getURL();J&&J!=="about:blank"&&(r.value=J,l.value=J)}}function X(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),w()}function T(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),w()}function O(J){J&&J.url&&(J.preventDefault(),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(J.url))}function w(){const J=p.value;J&&(typeof J.canGoBack=="function"&&(a.value=J.canGoBack()),typeof J.canGoForward=="function"&&(c.value=J.canGoForward()))}function z(){p.value&&typeof p.value.goBack=="function"&&p.value.goBack()}function Q(){p.value&&typeof p.value.goForward=="function"&&p.value.goForward()}function j(){p.value&&typeof p.value.reload=="function"&&p.value.reload()}function at(){let J=l.value.trim();J&&(/^https?:\/\//i.test(J)||(J=`https://${J}`),r.value=J,l.value=J,p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(J))}function W(){const J=p.value;if(J&&typeof J.setZoomFactor=="function")try{J.setZoomFactor(d.value)}catch(gt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",gt)}}function Y(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),W()}function V(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),W()}function N(){d.value=1,W()}function ct(J){J.preventDefault(),J.deltaY<0?Y():J.deltaY>0&&V()}async function rt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),h.value=!0,setTimeout(()=>{h.value=!1},2e3)}catch(J){console.warn("Copy url failed:",J)}}function st(){var gt;const J=r.value;if(typeof window<"u"){const mt=xe("electron");(gt=mt==null?void 0:mt.shell)!=null&&gt.openExternal?mt.shell.openExternal(J).catch(()=>{window.open(J,"_blank")}):window.open(J,"_blank")}e("external-jump",J)}return(J,gt)=>{const mt=Qc("webview");return et(),nt("div",Bp,[m("div",Dp,[m("div",Op,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:z},[pt(kt,{name:"arrow-left"})],8,Pp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:Q},[pt(kt,{name:"arrow-right"})],8,Lp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:j},[pt(kt,{name:"refresh"})],8,Rp)]),m("div",zp,[Te(m("input",{"onUpdate:modelValue":gt[0]||(gt[0]=Z=>l.value=Z),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:hu(at,["enter"])},null,544),[[ns,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":h.value?"已复制地址！":"复制网址",onClick:rt},[pt(kt,{name:"copy"})],8,Np)]),m("div",Fp,[m("button",{class:Et(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:A},[pt(kt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,jp),m("div",Hp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:V},[pt(kt,{name:"minus"})],8,Up),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:N},St(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:Y},[pt(kt,{name:"plus"})],8,Wp)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[pt(kt,{name:"external-link"}),gt[1]||(gt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:b,class:Et(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Me(ct,["ctrl"])},[m("div",{class:Et(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(et(),Be(mt,{key:0,ref_key:"webviewRef",ref:p,class:"spm-webview-frame",src:r.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(et(),nt("div",Vp,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Kp),m("div",{class:"spm-fallback-bar"},[gt[2]||(gt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Yp=Re(Zp,[["__scopeId","data-v-40e35375"]]);class Jp{constructor(){wt(this,"timers",new Map)}debounce(i,e,s=150){this.cancel(i);const n=setTimeout(()=>{this.timers.delete(i),e()},s);this.timers.set(i,n)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Xp{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new Jp);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const s of e.blocks)this.blockToPageMap.set(s.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Bi(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!s){if(i)try{return vt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{s.scrollIntoView()}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}s.classList.add("protyle-wysiwyg--select");const n=s.style.outline;return s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.3s ease",setTimeout(()=>{s.classList.remove("protyle-wysiwyg--select"),s.style.outline=n},1200),!0}function le(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Qp(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const s of e){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[r,l]=n.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(n,10);isNaN(r)||i.add(r)}}return i}const th=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function $e(t){if(!t)return"";const i=Mr(t),e=[],s=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const o=l.toLowerCase();if(!th.has(o)||/on\w+\s*=|javascript:/i.test(r))return r;if(o==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let n=le(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,o,a,c,d,h)=>{const u=(o??a??c??d??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{const c=/\.gif(?:\?|$)/i.test(o)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${o}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{if(o.startsWith("siyuan://blocks/")){const a=o.replace("siyuan://blocks/","").split("?")[0];return`<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${o}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,o,a)=>`${l}<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${o}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const o=parseInt(l,10);return e[o]||""}),n}function eh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=e[0];let n=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(n=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${s.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${$e(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${n[d]?` style="text-align: ${n[d]}"`:""}>${$e(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Bs(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ih(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Bs(t)}</span>`;const e=[];function s(r,l){return e.push(`<span class="${r}">${Bs(l)}</span>`),`__TOK_${e.length-1}__`}let n=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>s("token-string",`${l}${o}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>s("token-keyword",r)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>s("token-type",r)),n=n.replace(/\b(\d+)\b/g,r=>s("token-number",r)),n=Bs(n),n=n.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),n}function nh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let s=(e.title||"").trim(),n=e.level?parseInt(e.level,10):0;if(!s){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),s=a[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:t.pageIndex||i,title:s,level:n}):null}function sh(t,i=1,e={}){const s=e.minDepth!==void 0?Number(e.minDepth):1,n=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const h=nh(c,d+1);h&&r.push(h)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>n)return[];const h=[];for(const g of c){const u=a(g.children,d+1);d>=s?h.push({...g,children:u}):h.push(...u)}return h}return a(l,1)}function oh(t,i=1,e={}){const s=sh(t,i,e),n=e.columns?Number(e.columns):1,r=n>1?` style="column-count: ${n};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const k=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",p=u.children&&u.children.length>0?o(u.children,d+1):"";let b=$e(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${p}
        </li>
      `}).join("");return`<ol class="${h}">${g}</ol>`}const a=o(s,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function rh(t,i,e){var k,p,b,v;const s=t.split(`
`);if(!s.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const r=[],l=[];let o=!1;for(let y=0;y<s.length;y++){const S=s[y];if(!S.trim())continue;const I=S.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(I){const E=I[1].length,D=Math.floor(E/2);l.push({type:"task",level:D,checked:I[2].toLowerCase()==="x",text:I[3],media:[]});continue}const x=S.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const E=x[1].length,D=Math.floor(E/2);l.push({type:"unordered",level:D,text:x[2],media:[]});continue}const C=S.match(/^(\s*)\d+\.\s+(.*)$/);if(C){l.length===0&&(o=!0);const E=C[1].length,D=Math.floor(E/2);l.push({type:"ordered",level:D,text:C[2],media:[]});continue}const A=S.trim();if(l.length>0){const E=A.match(/^!\[(.*?)\]\((.*?)\)$/);if(E){const X=/\.gif(?:\?|$)/i.test(E[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${le(E[1])}" src="${E[2]}" class="${X}" /></div>`);continue}if(A.match(/^<img\b[\s\S]*?\/?>$/i)){l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${A}</div>`);continue}if(/<video\b/i.test(A)){let R=A;if(!/<\/video>/i.test(R))for(;y+1<s.length&&!/<\/video>/i.test(R);)y++,R+=" "+s[y].trim();const X=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-autoplay"])==="true"||/autoplay/i.test(R),T=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-loop"])==="true"||/loop/i.test(R),O=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||X||/muted/i.test(R),w=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-controls"])==="false",z=R.match(/\bsrc=["']([^"']+)["']/i),Q=z?z[1]:"",j=['class="slide-video-player"'];w||j.push("controls"),X&&(j.push("autoplay"),j.push("playsinline")),T&&j.push("loop"),O&&j.push("muted"),j.push('preload="metadata"'),Q&&j.push(`src="${Q}"`);const at=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let W=at?at[1].trim():"";!W&&Q&&(W=`<source src="${Q}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${X?"true":"false"}" data-muted="${O?"true":"false"}"><video ${j.join(" ")}>${W}</video></div>`);continue}l[l.length-1].text+=`
`+A}else r.push(A)}if(l.length===0)return null;function a(y){if(!y)return"";const S=y.split(`
`).map(E=>E.trim()).filter(Boolean);if(S.length===0)return"";if(!S.some(E=>/^#{1,6}\s+/.test(E)))return $e(S.join(" "));const x=[];let C=[];const A=()=>{if(C.length>0){const E=C.join(" ");x.push(`<p class="slide-list-item-desc">${$e(E)}</p>`),C=[]}};for(const E of S){const D=E.match(/^(#{1,6})\s+(.*)$/);if(D){A();const R=D[1].length,X=D[2].trim();x.push(`<h${R} class="slide-list-item-title">${$e(X)}</h${R}>`)}else C.push(E)}return A(),x.join(`
`)}function c(y){if(y.length===0)return"";const S=[];let I=[];const x=A=>{if(I.length>0){const E=I.join(" "),D=A?"slide-list-item-title":"slide-list-item-desc";S.push(`<p class="${D}">${$e(E)}</p>`),I=[]}};let C=!0;for(const A of y){const E=A.match(/^(#{1,6})\s+(.*)$/);if(E){x(C);const D=E[1].length,R=E[2].trim();S.push(`<h${D} class="slide-list-item-title">${$e(R)}</h${D}>`),C=!1}else I.push(A)}return x(C),S.join(`
`)+(S.length>0?`
`:"")}const d=o?"ol":"ul",h=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",g=l.map(y=>{const S=a(y.text),I=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",x=y.level||0,C=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",A=x>0?" slide-list-item--nested":"";if(y.type==="task"){const D=y.checked?' checked=""':"";return`<li class="pdf-task-item${A}"${C}><label><input type="checkbox" disabled=""${D}/> <span>${S}</span></label>${I}</li>`}return`<li${A?` class="${A.trim()}"`:""}${C}>${S}${I}</li>`}).join(`
`);return`${c(r)}<${d} class="${h}">
${g}
</${d}>`}function _e(t,i){var p,b,v,y,S,I,x,C,A;let e="",s="",n="";const r=[];(p=t.motion)!=null&&p.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),n=" slide-styled-block"),r.length>0&&(s=` style="${le(r.join(";"))}"`);const a=`pdf-block${e}${n}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${s}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${s}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const E=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${s}><div class="katex-display font-math"><em>${le(E)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const E=d[1].length,D=$e(d[2]);return`<div class="${a}"${s}><h${E}>${D}</h${E}></div>`}if(c.startsWith(":::")){const E=c.split(`
`),R=E[0].replace(/^:::\s*/,"").trim()||"info",X=E.slice(1,E[E.length-1].startsWith(":::")?-1:void 0).join(`
`),T="pdf-callout";return`<div class="${a}"${s}><div class="${T} ${T}--${R}"><div class="${T}-title">${R.toUpperCase()}</div><div class="${T}-body">${$e(X)}</div></div></div>`}if(c.startsWith("<<<")){const R=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((w,z)=>`<span class="code-line shiki-focus"><span class="line-no">${z+1}</span><span class="line-content">${ih(w,"ts")}</span></span>`).join(`
`),X="pdf-code shiki-container",T=((v=t.attrs)==null?void 0:v["custom-slidev-max-height"])||t.maxHeight||"",O=T?` style="max-height:${le(T)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${X}"${O}><span class="lang-badge">TS</span><code>${R}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const E=c.split(`
`),D=E[0].slice(3).trim(),R=D.match(/^([^\s{\[]+)/),X=R?R[1]:"",T=D.match(/\[([^\]]+)\]/),O=T?T[1]:"",w=D.includes("twoslash"),z=t.shikiLines||((y=D.match(/\{([^}]+)\}/))==null?void 0:y[1])||"",Q=Qp(z),j=E.length>2?E[E.length-1]==="```"?E.slice(1,-1):E.slice(1):[c.slice(3).replace(/```$/,"")],at="pdf-code shiki-container",W=O?`${at} has-filename`:at,Y=Q!=="all",V=j.map((J,gt)=>{const mt=gt+1,ot=Q==="all"||Q.has(mt)?"code-line shiki-focus":Y?"code-line shiki-dimmed":"code-line";let dt=le(J);return w&&J.includes("doubled.value = 2")?(dt=dt.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${ot}"><span class="line-no">${mt}</span><span class="line-content">${dt}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${ot}"><span class="line-no">${mt}</span><span class="line-content">${dt}</span></span>`}).join(`
`),N=X?`<span class="lang-badge">${le(X)}</span>`:"",ct=O?`<span class="code-filename">${le(O)}</span>`:"",rt=((S=t.attrs)==null?void 0:S["custom-slidev-max-height"])||t.maxHeight||"",st=rt?` style="max-height:${le(rt)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${W}"${st}>${ct}${N}<code>${V}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(E=>E.trim().startsWith("|")).length>=2){const E=c.split(`
`).filter(R=>R.trim().startsWith("|")),D=eh(E,i==null?void 0:i.tableClassName);return`<div class="${a}"${s}>${D}</div>`}if(c.startsWith("> "))return`<div class="${a}"${s}><blockquote class="pdf-quote"><p>${$e(c.slice(2))}</p></blockquote></div>`;const h=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c);if(h&&!g){const E=((I=t.attributes)==null?void 0:I["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),D=((x=t.attributes)==null?void 0:x["custom-slidev-loop"])==="true"||/loop/i.test(c),R=((C=t.attributes)==null?void 0:C["custom-slidev-muted"])==="true"||E||/muted/i.test(c),X=((A=t.attributes)==null?void 0:A["custom-slidev-controls"])==="false",T=c.match(/\bsrc=["']([^"']+)["']/i),O=T?T[1]:"",w=['class="slide-video-player"'];X||w.push("controls"),E&&(w.push("autoplay"),w.push("playsinline")),D&&w.push("loop"),R&&w.push("muted"),w.push('preload="metadata"'),O&&w.push(`src="${O}"`);const z=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let Q=z?z[1].trim():"";return!Q&&O&&(Q=`<source src="${O}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${E?"true":"false"}" data-muted="${R?"true":"false"}"${s}><video ${w.join(" ")}>${Q}</video></div>`}const u=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(u)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${s}><img alt="${le(u[1])}" src="${u[2]}" class="pdf-image slide-media-img" /></div>`;const k=rh(c,i,t);if(k)return`<div class="${a} pdf-list-item"${s}>${k}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const E=c.match(/minDepth=["']?(\d+)["']?/i),D=c.match(/maxDepth=["']?(\d+)["']?/i),R=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${s}>${oh([],1,{minDepth:E?parseInt(E[1],10):1,maxDepth:D?parseInt(D[1],10):1/0,columns:R?parseInt(R[1],10):1,textSm:c.includes("text-sm")})}</div>`}return`<div class="${a}"${s}><p>${$e(c)}</p></div>`}function lh(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",n=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=n.some(y=>y.slot==="right");let d=[],h=[];if(c)d=n.filter(y=>y.slot!=="right"),h=n.filter(y=>y.slot==="right");else{const y=Math.ceil(n.length/2);d=n.slice(0,y),h=n.slice(y)}const g=d.map(y=>_e(y,i)).join(`
`),u=h.map(y=>_e(y,i)).join(`
`),k="pdf-two-cols-wrapper layout-two-cols-grid",p=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${k}${p}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=n.filter(y=>y.slot==="header");if(d.length>0)c=d;else if(n.length>0){const y=n.find(S=>S.type==="h"&&(!S.slot||S.slot==="default"));y&&(c=[y])}const h=n.filter(y=>!c.includes(y)),g=h.filter(y=>y.slot==="right"||y.slot==="col-2"),u=h.filter(y=>!g.includes(y)),k=y=>{if(y.length===1&&ye(y[0])){const S=Fe(y[0].rawMarkdown);return _e({...y[0],rawMarkdown:S},i)}return y.map(S=>_e(S,i)).join(`
`)},p=c.map(y=>_e(y,i)).join(`
`),b=k(u),v=k(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${p}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${b}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=n.filter(I=>I.slot==="header");if(d.length>0)c=d;else if(n.length>0){const I=n.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));I&&(c=[I])}const h=n.filter(I=>!c.includes(I)),{col1:g,col2:u,col3:k}=Dr(h),p=I=>{if(I.length===1&&ye(I[0])){const x=Fe(I[0].rawMarkdown);return _e({...I[0],rawMarkdown:x},i)}return I.map(x=>_e(x,i)).join(`
`)},b=c.map(I=>_e(I,i)).join(`
`),v=p(g),y=p(u),S=p(k);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${b}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${y}</div>
          <div class="pdf-col pdf-col--3">${S}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=n.map(p=>_e(p,i)).join(`
`),h=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${le(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${le(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${n.map(d=>_e(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${n.map(d=>_e(d,i)).join(`
`)}</div>`:n.map(c=>_e(c,i)).join(`
`)}function Zl(t,i){const e="Slidev 演示文稿";let s=t.slides;const n=JSON.stringify(s),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${le(e)}</title>
  <style>
    ${un(i==null?void 0:i.customInlineStyles)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 32px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block {
      flex: 0 0 auto !important;
      min-height: auto !important;
      height: auto !important;
      max-height: none !important;
      width: 100% !important;
      display: block !important;
      overflow: visible !important;
      margin-bottom: 8px !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block:has(video),
    .pdf-col .slide-block:has(img),
    .pdf-col .slide-block:has(.slide-media-container),
    .pdf-col .slide-block:has(.slide-video-container),
    .pdf-col .slide-block:has(.slide-list-media),
    .pdf-col .slide-block.slide-block--media,
    .pdf-col .slide-block.slide-block--video,
    .pdf-col .slide-block.slide-block--image,
    .pdf-col .slide-block:only-child {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
    }

    .slide-list-media {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: auto !important;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container,
    .two-cols-left img,
    .two-cols-right img,
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .layout-three-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${n},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                items[items.length - 1].media.push('<div class="slide-list-media">' + tr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
          if (imgMatch) {
            div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
            div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
          } else {
            let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
            div.innerHTML = "<p>" + html + "</p>";
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default");
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          for (const block of (slide.blocks || [])) {
            const el = renderBlock(block);
            if (block.slot === "right") rightCol.appendChild(el);
            else leftCol.appendChild(el);
          }
          container.appendChild(leftCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightCol.appendChild(renderBlock(b));
            else leftCol.appendChild(renderBlock(b));
          }
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function Yl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(e),n=document.createElement("a");return n.href=s,n.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function ah(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function ch(t,i){const e="Slidev 演示讲义",s="16:9",n="light",r=ah(s),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=lh(o),h=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${n}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${le(e)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${le(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${le(e)} - 高保真讲义</title>
  <style>
    ${un(i==null?void 0:i.customInlineStyles)}

    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      align-items: center;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 36px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Jl(t,i){var n;if(typeof window>"u"||typeof document>"u")return!1;const e=ch(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(n=r.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const s=window.open("","_blank");return s?(s.document.write(e),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}const dh={class:"spm-slidev-preview-tab"},uh={class:"spm-slidev-tab__toolbar"},fh={class:"spm-slidev-tab__actions"},ph=["disabled"],hh={class:"spm-page-badge"},mh=["disabled"],gh=["aria-label"],vh=["aria-label"],bh=["src"],yh=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ei("plugin"),s=ei("sandboxBridge",new Co),n=new Xp(s),r=new Au,l=ht("web-sandbox"),o=ht(3030),a=ht(null),c=ht(!1),d=ht(null),h=ht(1),g=ht(1),u=ht([]),k=ht(!1),p=ht(!1),b=ht(!1),v=ht("siyuan"),y=ht(""),S=ht(""),I=ht(""),x=ht(!1),C=ht(!1),A=ht(""),E=ht("/plugins/siyuan-slidev/slidev-client/index.html");let D=null,R=null,X=null,T=null,O=null,w=null,z=null;In(()=>{d.value&&(s.attach(d.value),r.nativeBridge.attach(d.value)),D=s.onSlideChanged((Z,ot)=>{h.value=Z,g.value=ot}),R=s.onBlockClicked((Z,ot)=>{h.value=ot,n.setActiveBlockId(Z),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Z,ot):Bi(Z,e==null?void 0:e.app)}),X=s.onOpenInEditor((Z,ot)=>{h.value=ot,n.setActiveBlockId(Z),Bi(Z,e==null?void 0:e.app)}),T=r.nativeBridge.onPageChanged((Z,ot)=>{h.value=Z,g.value=ot}),O=s.onOpenPeekDrawer(async Z=>{const ot=Io();if(Z.peekType==="siyuan"&&ot.enableWebServeJump){let dt=!1;if(z&&z.docId===Z.target)dt=!0;else if(z&&z.slides&&z.slides.some(M=>{var L;return(L=M.blocks)==null?void 0:L.some(f=>f.id===Z.target)}))dt=!1;else try{const M=await vn(`SELECT id, root_id, type FROM blocks WHERE id = '${Z.target}' LIMIT 1`);M&&M.length>0&&(dt=M[0].type==="d"||M[0].id===M[0].root_id)}catch(M){console.warn("[SlidevPreviewTab] detect block type failed:",M)}v.value="web",x.value=!0,S.value=Kl(ot.webServeUrl,Z.target,{focus:!dt}),I.value=Z.title||`${dt?"思源文档":"思源块"}: ${Z.target.slice(0,8)}`,p.value=!0,s.freezeKeyboardNav(!0)}else v.value=Z.peekType,Z.peekType==="siyuan"?(y.value=Z.target,I.value=Z.title||`块速览: ${Z.target.slice(0,8)}`):(x.value=!0,S.value=Z.target,I.value=Z.title||Z.target),p.value=!0,s.freezeKeyboardNav(!0)}),w=s.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),bo(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),O&&O(),w&&w(),D&&D(),R&&R(),X&&X(),T&&T(),s.detach(),n.destroy(),r.destroy()});async function Q(){if(l.value==="web-sandbox"){if(!z){vt.showMessage("请先在主编辑区打开演示文档");return}vt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Z=await r.startProMode(z,Ls);if(!Z.success){vt.showMessage(`无法启动官方 Pro 模式：${Z.error}`);return}l.value="pro-cli",o.value=Z.port||3030,E.value=Z.url,d.value&&r.nativeBridge.attach(d.value),vt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",E.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&s.attach(d.value),vt.showMessage("已切回内置高保真沙箱")}function j(){C.value=!C.value,C.value?A.value=(z==null?void 0:z.docId)||"":(A.value="",V())}function at(){h.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value-1):s.navigatePage(h.value-1))}function W(){h.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value+1):s.navigatePage(h.value+1))}function Y(Z){h.value=Z,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Z):s.navigatePage(Z)}function V(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function N(){p.value=!1,s.freezeKeyboardNav(!1)}function ct(){N()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const Z=a.value||d.value;Z&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Z.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function J(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function gt(){if(!z){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const Z=Zl(z);Yl("presentation.html",Z)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function mt(){if(!z){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(z)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Z,ot){C.value&&A.value&&ot&&ot!==A.value||(z=Z,C.value&&!A.value&&(A.value=Z.docId),u.value=Z.slides,g.value=Z.slides.length,n.setDocId(Z.docId),n.updateSlidesIndex(Z.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Z,Ls).catch(()=>{}):s.updateSlides(Z.slides,Z.config,Z.fullMarkdown,Z.customThemeCss))},navigateToBlock(Z){n.onCursorFocusBlock(Z)},isPinned:C,pinnedDocId:A,engineMode:l,toggleEngineMode:Q}),(Z,ot)=>(et(),nt("div",dh,[m("div",uh,[ot[4]||(ot[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",fh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:at},[pt(kt,{name:"chevron-left"})],8,ph),m("span",hh,St(h.value)+" / "+St(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=g.value,"aria-label":"下一页",onClick:W},[pt(kt,{name:"chevron-right"})],8,mh),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":C.value}]),"aria-label":C.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:j},[pt(kt,{name:"pin"}),m("span",null,St(C.value?"已锁定":"跟随"),1)],10,gh),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Q},[pt(kt,{name:"step"}),m("span",null,St(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,vh),ot[3]||(ot[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ot[0]||(ot[0]=dt=>k.value=!k.value)},[pt(kt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:J},[pt(kt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:gt},[pt(kt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:mt},[pt(kt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:V},[pt(kt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[pt(kt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:E.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,bh),pt(kp,{visible:p.value,"onUpdate:visible":ot[1]||(ot[1]=dt=>p.value=dt),"is-maximized":b.value,"onUpdate:isMaximized":ot[2]||(ot[2]=dt=>b.value=dt),title:I.value,onClose:N},{default:cl(()=>[v.value==="siyuan"&&y.value?(et(),Be(Mp,{key:0,"block-id":y.value,title:I.value,plugin:Ii(e),onExternalJump:ct},null,8,["block-id","title","plugin"])):Ft("",!0),x.value?Te((et(),Be(Yp,{key:1,visible:p.value&&v.value==="web",url:S.value,title:I.value,onExternalJump:ct},null,8,["visible","url","title"])),[[Nl,v.value==="web"]]):Ft("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&u.value.length>0?(et(),Be(up,{key:0,slides:u.value,"current-active-page":h.value,onNavigate:Y,onRefresh:V},null,8,["slides","current-active-page"])):Ft("",!0)]))}}),kh=Re(yh,[["__scopeId","data-v-2622f6d8"]]),wh={class:"spm-section spm-section--page"},xh={class:"spm-section-header"},_h={class:"spm-card-control"},Sh={class:"spm-control-header"},Ch={class:"spm-control-title-group"},$h={class:"spm-control-title"},Ih={class:"spm-quick-chips"},Ah=["onClick"],Th=["value"],Eh={key:0,class:"spm-card-control"},Mh={class:"spm-control-header"},Bh={class:"spm-control-title-group"},Dh={class:"spm-control-title"},Oh={class:"spm-quick-chips"},Ph=["onClick"],Lh=["value"],Rh={class:"spm-card-control"},zh={class:"spm-control-header"},Nh={class:"spm-control-title-group"},Fh={class:"spm-control-title"},jh={key:0,class:"spm-note-status-box"},Hh=["title"],Uh={class:"spm-action-grid",style:{"margin-top":"6px"}},Wh={key:1,class:"spm-note-empty-box"},Vh={class:"spm-card-control"},Kh={class:"spm-action-grid"},qh=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,s=$t(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),n=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(et(),nt("div",wh,[m("div",xh,[m("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),pt(Vl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),pt($o,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",_h,[m("div",Sh,[m("div",Ch,[m("div",$h,[pt(kt,{name:"palette"}),o[12]||(o[12]=m("span",null,"页面背景 (Background)",-1))]),o[13]||(o[13]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",Ih,[(et(),nt(Gt,null,ke(n,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},St(a.label),11,Ah)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[2]||(o[2]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[3]||(o[3]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Th)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(et(),nt("div",Eh,[m("div",Mh,[m("div",Bh,[m("div",Dh,[pt(kt,{name:"image"}),o[14]||(o[14]=m("span",null,"页面图片 (Image)",-1))]),o[15]||(o[15]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Oh,[(et(),nt(Gt,null,ke(r,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},St(a.label),11,Ph)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[4]||(o[4]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[5]||(o[5]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Lh)])):Ft("",!0),m("div",Rh,[m("div",zh,[m("div",Nh,[m("div",Fh,[pt(kt,{name:"presenter"}),o[16]||(o[16]=m("span",null,"演讲者提词 (Notes)",-1))]),o[17]||(o[17]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[6]||(o[6]=a=>l.$emit("generateNotes"))},[pt(kt,{name:"sparkles"}),o[18]||(o[18]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(et(),nt("div",jh,[o[21]||(o[21]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},St(s.value),9,Hh),m("div",Uh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[7]||(o[7]=a=>l.$emit("locateNoteBlock"))},[pt(kt,{name:"search"}),o[19]||(o[19]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[8]||(o[8]=a=>l.$emit("addNoteBlock"))},[pt(kt,{name:"insert-below"}),o[20]||(o[20]=m("span",null,"追加讲稿块",-1))])])])):(et(),nt("div",Wh,[o[23]||(o[23]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[9]||(o[9]=a=>l.$emit("addNoteBlock"))},[pt(kt,{name:"insert-below"}),o[22]||(o[22]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",Vh,[o[26]||(o[26]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",Kh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[10]||(o[10]=a=>l.$emit("insertDividerAfter"))},[pt(kt,{name:"insert-below"}),o[24]||(o[24]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[11]||(o[11]=a=>l.$emit("deleteDivider"))},[pt(kt,{name:"trash"}),o[25]||(o[25]=m("span",null,"删除此页",-1))])])])]))}}),Gh=Re(qh,[["__scopeId","data-v-4916b87e"]]),Zh={class:"spm-section spm-section--block"},Yh={class:"spm-card-control"},Jh={class:"spm-control-header"},Xh={class:"spm-control-title-group"},Qh={class:"spm-control-title"},tm=["aria-label"],em=["checked"],im={key:0,class:"spm-card-control"},nm={class:"spm-control-header"},sm={class:"spm-control-title-group"},om={class:"spm-control-title"},rm={class:"spm-quick-chips"},lm={key:1,class:"spm-card-control"},am={class:"spm-control-header"},cm={class:"spm-control-title-group"},dm={class:"spm-control-title"},um={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},fm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},pm=["aria-label"],hm=["checked"],mm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},gm=["aria-label"],vm=["checked"],bm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ym=["aria-label"],km=["checked"],wm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},xm=["aria-label"],_m=["checked"],Sm={class:"spm-card-control"},Cm={class:"spm-control-header"},$m={class:"spm-control-title-group"},Im={class:"spm-control-title"},Am=["aria-label"],Tm=["checked"],Em={key:0,class:"spm-quick-chips"},Mm=["onClick"],Bm={class:"spm-card-control"},Dm={class:"spm-control-header"},Om={class:"spm-control-title-group"},Pm={class:"spm-control-title"},Lm=["aria-label"],Rm=["checked"],zm={key:0,class:"spm-quick-chips"},Nm=["onClick"],Fm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},jm={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Hm={style:{display:"flex",gap:"6px"}},Um=["value"],Wm=["value"],Vm={key:2,class:"spm-card-control"},Km={class:"spm-control-header"},qm={class:"spm-control-title-group"},Gm={class:"spm-control-title"},Zm={class:"spm-control-desc"},Ym={class:"spm-segmented-group"},Jm=["onClick"],Xm={key:3,class:"spm-card-control"},Qm={class:"spm-control-header"},tg={class:"spm-control-title-group"},eg={class:"spm-control-title"},ig={class:"spm-quick-chips"},ng=["onClick"],sg=["value"],og={key:4,class:"spm-card-control"},rg={class:"spm-control-header"},lg={class:"spm-control-title-group"},ag={class:"spm-control-title"},cg={class:"spm-quick-chips"},dg=["onClick"],ug=["value"],fg={class:"spm-card-control"},pg={class:"spm-action-grid"},hg=["aria-label"],mg=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,s=$t(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),n=$t(()=>{const x=s.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=$t(()=>{const x=s.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=$t(()=>{const x=s.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=$t(()=>{const x=s.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const C=e.elemSlot||"";return x?C===x||x==="col-1"&&C==="left"||x==="col-2"&&C==="center"||x==="col-3"&&C==="right"||x==="left"&&C==="col-1"||x==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=$t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=$t(()=>!!h.value),u=$t(()=>{var x;return((x=h.value)==null?void 0:x.preset)||"slide-up"}),k=$t(()=>{var x;return((x=h.value)==null?void 0:x.duration)||0}),p=$t(()=>{var x;return((x=h.value)==null?void 0:x.delay)||0});function b(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(x){I(x,k.value,p.value)}function y(x){I(u.value,x,p.value)}function S(x){I(u.value,k.value,x)}function I(x,C,A){if(!x||x==="none"){c("update:elemMotion","");return}if(!C&&!A){c("update:elemMotion",x);return}const E={preset:x};C>0&&(E.duration=C),A>0&&(E.delay=A),c("update:elemMotion",JSON.stringify(E))}return(x,C)=>(et(),nt("div",Zh,[C[53]||(C[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",Yh,[m("div",Jh,[m("div",Xh,[m("div",Qh,[pt(kt,{name:"presenter"}),C[22]||(C[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),C[23]||(C[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:C[0]||(C[0]=A=>x.$emit("toggleNote"))},null,40,em),C[24]||(C[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,tm)])]),t.isImage||t.imageRole?(et(),nt("div",im,[m("div",nm,[m("div",sm,[m("div",om,[pt(kt,{name:"image"}),C[25]||(C[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),C[26]||(C[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",rm,[m("button",{class:Et(["spm-chip",{active:!t.imageRole}]),onClick:C[1]||(C[1]=A=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="background"}]),onClick:C[2]||(C[2]=A=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:C[3]||(C[3]=A=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:C[4]||(C[4]=A=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ft("",!0),t.isVideo?(et(),nt("div",lm,[m("div",am,[m("div",cm,[m("div",dm,[pt(kt,{name:"video"}),C[27]||(C[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),C[28]||(C[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",um,[m("div",fm,[C[30]||(C[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:C[5]||(C[5]=A=>x.$emit("toggleVideoControls"))},null,40,hm),C[29]||(C[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,pm)]),m("div",mm,[C[32]||(C[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:C[6]||(C[6]=A=>x.$emit("toggleVideoAutoplay"))},null,40,vm),C[31]||(C[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,gm)]),m("div",bm,[C[34]||(C[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:C[7]||(C[7]=A=>x.$emit("toggleVideoLoop"))},null,40,km),C[33]||(C[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,ym)]),m("div",wm,[C[36]||(C[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:C[8]||(C[8]=A=>x.$emit("toggleVideoMuted"))},null,40,_m),C[35]||(C[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,xm)])])])):Ft("",!0),m("div",Sm,[m("div",Cm,[m("div",$m,[m("div",Im,[pt(kt,{name:"step"}),C[37]||(C[37]=m("span",null,"逐步呈现 (v-click)",-1))]),C[38]||(C[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:C[9]||(C[9]=A=>x.$emit("toggleElemClick"))},null,40,Tm),C[39]||(C[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Am)]),t.elemClick?(et(),nt("div",Em,[(et(),nt(Gt,null,ke(["+1","1","2","hide"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemClick===A}]),onClick:E=>x.$emit("update:elemClick",A)},St(A==="+1"?"顺延 (+1)":A==="hide"?"隐藏 (hide)":"第 "+A+" 步"),11,Mm)),64))])):Ft("",!0)]),m("div",Bm,[m("div",Dm,[m("div",Om,[m("div",Pm,[pt(kt,{name:"motion"}),C[40]||(C[40]=m("span",null,"入场微动效 (v-motion)",-1))]),C[41]||(C[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:b},null,40,Rm),C[42]||(C[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Lm)]),g.value?(et(),nt("div",zm,[(et(),nt(Gt,null,ke(d,A=>m("button",{key:A.value,class:Et(["spm-chip",{active:u.value===A.value}]),onClick:E=>v(A.value)},St(A.label),11,Nm)),64))])):Ft("",!0),g.value?(et(),nt("div",Fm,[m("div",jm,[m("span",null,"时长: "+St(k.value?k.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+St(p.value?p.value+"ms":"0ms"),1)]),m("div",Hm,[m("select",{class:"spm-select",style:{flex:"1"},value:k.value,onChange:C[10]||(C[10]=A=>y(Number(A.target.value)))},[...C[43]||(C[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Um),m("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:C[11]||(C[11]=A=>S(Number(A.target.value)))},[...C[44]||(C[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Wm)])])):Ft("",!0)]),n.value||t.elemSlot?(et(),nt("div",Vm,[m("div",Km,[m("div",qm,[m("div",Gm,[pt(kt,{name:"columns"}),m("span",null,St(r.value),1)]),m("span",Zm,St(l.value),1)])]),m("div",Ym,[(et(!0),nt(Gt,null,ke(o.value,A=>(et(),nt("button",{key:A.value,class:Et(["spm-segmented-item",{active:a(A.value)}]),onClick:E=>x.$emit("update:elemSlot",A.value)},St(A.label),11,Jm))),128))])])):Ft("",!0),t.isCodeBlock?(et(),nt("div",Xm,[m("div",Qm,[m("div",tg,[m("div",eg,[pt(kt,{name:"code"}),C[45]||(C[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),C[46]||(C[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",ig,[(et(),nt(Gt,null,ke(["1-3","all","1|2|3","2-5"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemShikiLines===A}]),onClick:E=>x.$emit("update:elemShikiLines",A)},St(A),11,ng)),64)),t.elemShikiLines?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[12]||(C[12]=A=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Ft("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[13]||(C[13]=A=>x.$emit("update:elemShikiLines",A.target.value)),onChange:C[14]||(C[14]=A=>x.$emit("update:elemShikiLines",A.target.value))},null,40,sg)])):Ft("",!0),t.isCodeBlock?(et(),nt("div",og,[m("div",rg,[m("div",lg,[m("div",ag,[pt(kt,{name:"code"}),C[47]||(C[47]=m("span",null,"代码块限高 (Max Height)",-1))]),C[48]||(C[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",cg,[(et(),nt(Gt,null,ke(["240px","320px","400px","50vh"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemMaxHeight===A}]),onClick:E=>x.$emit("update:elemMaxHeight",A)},St(A),11,dg)),64)),t.elemMaxHeight?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[15]||(C[15]=A=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ft("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[16]||(C[16]=A=>x.$emit("update:elemMaxHeight",A.target.value)),onChange:C[17]||(C[17]=A=>x.$emit("update:elemMaxHeight",A.target.value))},null,40,ug)])):Ft("",!0),m("div",fg,[C[52]||(C[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",pg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[18]||(C[18]=A=>x.$emit("insertDividerBefore"))},[pt(kt,{name:"insert-above"}),C[49]||(C[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[19]||(C[19]=A=>x.$emit("insertDividerAfter"))},[pt(kt,{name:"insert-below"}),C[50]||(C[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:C[20]||(C[20]=A=>x.$emit("setTwoColsContrast"))},[pt(kt,{name:"columns"}),m("span",null,St(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,hg),t.hasBlockAttrs?(et(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:C[21]||(C[21]=A=>x.$emit("clearBlockAttrs"))},[pt(kt,{name:"broom"}),C[51]||(C[51]=m("span",null,"清除属性",-1))])):Ft("",!0)])])]))}}),gg={class:"spm-section spm-section--doc"},vg={class:"spm-card-control"},bg={class:"spm-control-header"},yg={class:"spm-control-title-group"},kg={class:"spm-control-title"},wg={class:"spm-segmented-group"},xg=["aria-label","onClick"],_g={class:"spm-card-control"},Sg={class:"spm-control-header"},Cg={class:"spm-control-title-group"},$g={class:"spm-control-title"},Ig={class:"spm-segmented-group"},Ag={class:"spm-card-control"},Tg={class:"spm-control-header"},Eg={class:"spm-control-title-group"},Mg={class:"spm-control-title"},Bg={class:"spm-card-control"},Dg={class:"spm-control-header"},Og={class:"spm-control-title-group"},Pg={class:"spm-control-title"},Lg=["aria-label"],Rg=["checked"],zg={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Ng=["value"],Fg={class:"spm-card-control"},jg={class:"spm-action-grid"},Hg=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ei("plugin"),e=Ai,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(o){qi({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){qi({webServeUrl:o})}function l(o){qi({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(et(),nt("div",gg,[a[30]||(a[30]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",vg,[m("div",bg,[m("div",yg,[m("div",kg,[pt(kt,{name:"palette"}),a[14]||(a[14]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[15]||(a[15]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",wg,[(et(),nt(Gt,null,ke(s,c=>m("button",{key:c.value,class:Et(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},St(c.label),11,xg)),64))])]),m("div",_g,[m("div",Sg,[m("div",Cg,[m("div",$g,[pt(kt,{name:"ratio"}),a[16]||(a[16]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[17]||(a[17]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Ig,[m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Ag,[m("div",Tg,[m("div",Eg,[m("div",Mg,[pt(kt,{name:"transition"}),a[18]||(a[18]=m("span",null,"全局默认转场",-1))]),a[19]||(a[19]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),pt($o,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[3]||(a[3]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Bg,[m("div",Dg,[m("div",Og,[m("div",Pg,[pt(kt,{name:"external-link"}),a[20]||(a[20]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[21]||(a[21]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Ii(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:Ii(e).enableWebServeJump,onChange:a[4]||(a[4]=c=>n(c.target.checked))},null,40,Rg),a[22]||(a[22]=m("span",{class:"spm-switch-slider"},null,-1))],8,Lg)]),Ii(e).enableWebServeJump?(et(),nt("div",zg,[m("input",{value:Ii(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[5]||(a[5]=Me(()=>{},["stop"])),onKeyup:a[6]||(a[6]=Me(()=>{},["stop"])),onInput:a[7]||(a[7]=c=>r(c.target.value)),onChange:a[8]||(a[8]=c=>l(c.target.value))},null,40,Ng),a[23]||(a[23]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ft("",!0)]),m("div",Fg,[a[29]||(a[29]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",jg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[9]||(a[9]=c=>o.$emit("openBottomPreview"))},[pt(kt,{name:"split-preview"}),a[24]||(a[24]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[10]||(a[10]=c=>o.$emit("openPresenter"))},[pt(kt,{name:"presenter"}),a[25]||(a[25]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[11]||(a[11]=c=>o.$emit("aiAutoSplit"))},[pt(kt,{name:"sparkles"}),a[26]||(a[26]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[12]||(a[12]=c=>o.$emit("exportHtml"))},[pt(kt,{name:"export-html"}),a[27]||(a[27]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[13]||(a[13]=c=>o.$emit("exportPdf"))},[pt(kt,{name:"export-pdf"}),a[28]||(a[28]=m("span",null,"导出 PDF",-1))])])])]))}});var Nn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Ug(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Fn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ds={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var yr;function Wg(){return yr||(yr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(s,n,r){function l(c,d){if(!n[c]){if(!s[c]){var h=typeof Fn=="function"&&Fn;if(!d&&h)return h(c,!0);if(o)return o(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=n[c]={exports:{}};s[c][0].call(u.exports,function(k){var p=s[c][1][k];return l(p||k)},u,u.exports,e,s,n,r)}return n[c].exports}for(var o=typeof Fn=="function"&&Fn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,s,n){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,d,h,g,u,k,p,b=[],v=0,y=a.length,S=y,I=r.getTypeOf(a)!=="string";v<a.length;)S=y-v,h=I?(c=a[v++],d=v<y?a[v++]:0,v<y?a[v++]:0):(c=a.charCodeAt(v++),d=v<y?a.charCodeAt(v++):0,v<y?a.charCodeAt(v++):0),g=c>>2,u=(3&c)<<4|d>>4,k=1<S?(15&d)<<2|h>>6:64,p=2<S?63&h:64,b.push(o.charAt(g)+o.charAt(u)+o.charAt(k)+o.charAt(p));return b.join("")},n.decode=function(a){var c,d,h,g,u,k,p=0,b=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var y,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&S--,a.charAt(a.length-2)===o.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(y=l.uint8array?new Uint8Array(0|S):new Array(0|S);p<a.length;)c=o.indexOf(a.charAt(p++))<<2|(g=o.indexOf(a.charAt(p++)))>>4,d=(15&g)<<4|(u=o.indexOf(a.charAt(p++)))>>2,h=(3&u)<<6|(k=o.indexOf(a.charAt(p++))),y[b++]=c,u!==64&&(y[b++]=d),k!==64&&(y[b++]=h);return y}},{"./support":30,"./utils":32}],2:[function(e,s,n){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,h,g,u,k){this.compressedSize=d,this.uncompressedSize=h,this.crc32=g,this.compression=u,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return d.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,h,g){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(h.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,s,n){var r=e("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},n.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,s,n){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();s.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,h,g){var u=l,k=g+h;c^=-1;for(var p=g;p<k;p++)c=c>>>8^u[255&(c^d[p])];return-1^c})(0|a,o,o.length,0):(function(c,d,h,g){var u=l,k=g+h;c^=-1;for(var p=g;p<k;p++)c=c>>>8^u[255&(c^d.charCodeAt(p))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,s,n){var r=null;r=typeof Promise<"u"?Promise:e("lie"),s.exports={Promise:r}},{lie:37}],7:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(h,g){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=g,this.meta={}}n.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,h.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(g){h.push({data:g,meta:h.meta})}},n.compressWorker=function(h){return new d("Deflate",h)},n.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,s,n){function r(u,k){var p,b="";for(p=0;p<k;p++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,k,p,b,v,y){var S,I,x=u.file,C=u.compression,A=y!==c.utf8encode,E=o.transformTo("string",y(x.name)),D=o.transformTo("string",c.utf8encode(x.name)),R=x.comment,X=o.transformTo("string",y(R)),T=o.transformTo("string",c.utf8encode(R)),O=D.length!==x.name.length,w=T.length!==R.length,z="",Q="",j="",at=x.dir,W=x.date,Y={crc32:0,compressedSize:0,uncompressedSize:0};k&&!p||(Y.crc32=u.crc32,Y.compressedSize=u.compressedSize,Y.uncompressedSize=u.uncompressedSize);var V=0;k&&(V|=8),A||!O&&!w||(V|=2048);var N=0,ct=0;at&&(N|=16),v==="UNIX"?(ct=798,N|=(function(st,J){var gt=st;return st||(gt=J?16893:33204),(65535&gt)<<16})(x.unixPermissions,at)):(ct=20,N|=(function(st){return 63&(st||0)})(x.dosPermissions)),S=W.getUTCHours(),S<<=6,S|=W.getUTCMinutes(),S<<=5,S|=W.getUTCSeconds()/2,I=W.getUTCFullYear()-1980,I<<=4,I|=W.getUTCMonth()+1,I<<=5,I|=W.getUTCDate(),O&&(Q=r(1,1)+r(d(E),4)+D,z+="up"+r(Q.length,2)+Q),w&&(j=r(1,1)+r(d(X),4)+T,z+="uc"+r(j.length,2)+j);var rt="";return rt+=`
\0`,rt+=r(V,2),rt+=C.magic,rt+=r(S,2),rt+=r(I,2),rt+=r(Y.crc32,4),rt+=r(Y.compressedSize,4),rt+=r(Y.uncompressedSize,4),rt+=r(E.length,2),rt+=r(z.length,2),{fileRecord:h.LOCAL_FILE_HEADER+rt+E+z,dirRecord:h.CENTRAL_FILE_HEADER+r(ct,2)+rt+r(X.length,2)+"\0\0\0\0"+r(N,4)+r(b,4)+E+z+X}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),h=e("../signature");function g(u,k,p,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=p,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(g,a),g.prototype.push=function(u){var k=u.meta.percent||0,p=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:p?(k+100*(p-b-1))/p:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var k=this.streamFiles&&!u.file.dir;if(k){var p=l(u,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:p.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var k=this.streamFiles&&!u.file.dir,p=l(u,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(p.dirRecord),k)this.push({data:(function(b){return h.DATA_DESCRIPTOR+r(b.crc32,4)+r(b.compressedSize,4)+r(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:p.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var p=this.bytesWritten-u,b=(function(v,y,S,I,x){var C=o.transformTo("string",x(I));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(y,4)+r(S,4)+r(C.length,2)+C})(this.dirRecords.length,p,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var k=this;return u.on("data",function(p){k.processChunk(p)}),u.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),u.on("error",function(p){k.error(p)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var k=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var p=0;p<k.length;p++)try{k[p].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,k=0;k<u.length;k++)u[k].lock()},s.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,s,n){var r=e("../compressions"),l=e("./ZipFileWorker");n.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{o.forEach(function(g,u){h++;var k=(function(y,S){var I=y||S,x=r[I];if(!x)throw new Error(I+" is not a valid compression method !");return x})(u.options.compression,a.compression),p=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,v=u.date;u._compressWorker(k,p).withStreamInfo("file",{name:g,dir:b,date:v,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=h}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,s,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),s.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,s,n){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function h(g){return new l.Promise(function(u,k){var p=g.decompressed.getContentWorker().pipe(new c);p.on("error",function(b){k(b)}).on("end",function(){p.streamInfo.crc32!==g.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}s.exports=function(g,u){var k=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(p){var b=new a(u);return b.load(p),b}).then(function(p){var b=[l.Promise.resolve(p)],v=p.files;if(u.checkCRC32)for(var y=0;y<v.length;y++)b.push(h(v[y]));return l.Promise.all(b)}).then(function(p){for(var b=p.shift(),v=b.files,y=0;y<v.length;y++){var S=v[y],I=S.fileNameStr,x=r.resolve(S.fileNameStr);k.file(x,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(k.file(x).unsafeOriginalName=I)}return b.zipComment.length&&(k.comment=b.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,s,n){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,s,n){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(h,g){d.push(h)||d._helper.pause(),c&&c(g)}).on("error",function(h){d.emit("error",h)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},s.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,s,n){function r(x,C,A){var E,D=o.getTypeOf(C),R=o.extend(A||{},d);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(x=v(x)),R.createFolders&&(E=b(x))&&y.call(this,E,!0);var X=D==="string"&&R.binary===!1&&R.base64===!1;A&&A.binary!==void 0||(R.binary=!X),(C instanceof h&&C.uncompressedSize===0||R.dir||!C||C.length===0)&&(R.base64=!1,R.binary=!0,C="",R.compression="STORE",D="string");var T=null;T=C instanceof h||C instanceof a?C:k.isNode&&k.isStream(C)?new p(x,C):o.prepareContent(x,C,R.binary,R.optimizedBinaryString,R.base64);var O=new g(x,T,R);this.files[x]=O}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),h=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),k=e("./nodejsUtils"),p=e("./nodejs/NodejsStreamInputAdapter"),b=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var C=x.lastIndexOf("/");return 0<C?x.substring(0,C):""},v=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},y=function(x,C){return C=C!==void 0?C:d.createFolders,x=v(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:C}),this.files[x]};function S(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var I={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var C,A,E;for(C in this.files)E=this.files[C],(A=C.slice(this.root.length,C.length))&&C.slice(0,this.root.length)===this.root&&x(A,E)},filter:function(x){var C=[];return this.forEach(function(A,E){x(A,E)&&C.push(E)}),C},file:function(x,C,A){if(arguments.length!==1)return x=this.root+x,r.call(this,x,C,A),this;if(S(x)){var E=x;return this.filter(function(R,X){return!X.dir&&E.test(R)})}var D=this.files[this.root+x];return D&&!D.dir?D:null},folder:function(x){if(!x)return this;if(S(x))return this.filter(function(D,R){return R.dir&&x.test(D)});var C=this.root+x,A=y.call(this,C),E=this.clone();return E.root=A.name,E},remove:function(x){x=this.root+x;var C=this.files[x];if(C||(x.slice(-1)!=="/"&&(x+="/"),C=this.files[x]),C&&!C.dir)delete this.files[x];else for(var A=this.filter(function(D,R){return R.name.slice(0,x.length)===x}),E=0;E<A.length;E++)delete this.files[A[E].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var C,A={};try{if((A=o.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=A.type.toLowerCase(),A.compression=A.compression.toUpperCase(),A.type==="binarystring"&&(A.type="string"),!A.type)throw new Error("No output type specified.");o.checkSupport(A.type),A.platform!=="darwin"&&A.platform!=="freebsd"&&A.platform!=="linux"&&A.platform!=="sunos"||(A.platform="UNIX"),A.platform==="win32"&&(A.platform="DOS");var E=A.comment||this.comment||"";C=u.generateWorker(this,A,E)}catch(D){(C=new a("error")).error(D)}return new c(C,A.type||"string",A.mimeType)},generateAsync:function(x,C){return this.generateInternalStream(x).accumulate(C)},generateNodeStream:function(x,C){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(C)}};s.exports=I},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,s,n){s.exports=e("stream")},{stream:void 0}],17:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===h)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&h===g[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,s,n){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},s.exports=l},{"../utils":32}],19:[function(e,s,n){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,s,n){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,s,n){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");s.exports=function(h){var g=r.getTypeOf(h);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(h):l.uint8array?new d(r.transformTo("uint8array",h)):new o(r.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,s,n){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},s.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,s,n){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},s.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},s.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,s,n){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},s.exports=r},{}],29:[function(e,s,n){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),h=null;if(c.nodestream)try{h=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(k,p){return new d.Promise(function(b,v){var y=[],S=k._internalType,I=k._outputType,x=k._mimeType;k.on("data",function(C,A){y.push(C),p&&p(A)}).on("error",function(C){y=[],v(C)}).on("end",function(){try{var C=(function(A,E,D){switch(A){case"blob":return r.newBlob(r.transformTo("arraybuffer",E),D);case"base64":return a.encode(E);default:return r.transformTo(A,E)}})(I,(function(A,E){var D,R=0,X=null,T=0;for(D=0;D<E.length;D++)T+=E[D].length;switch(A){case"string":return E.join("");case"array":return Array.prototype.concat.apply([],E);case"uint8array":for(X=new Uint8Array(T),D=0;D<E.length;D++)X.set(E[D],R),R+=E[D].length;return X;case"nodebuffer":return Buffer.concat(E);default:throw new Error("concat : unsupported type '"+A+"'")}})(S,y),x);b(C)}catch(A){v(A)}y=[]}).resume()})}function u(k,p,b){var v=p;switch(p){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=p,this._mimeType=b,r.checkSupport(v),this._worker=k.pipe(new l(v)),k.lock()}catch(y){this._worker=new o("error"),this._worker.error(y)}}u.prototype={accumulate:function(k){return g(this,k)},on:function(k,p){var b=this;return k==="data"?this._worker.on(k,function(v){p.call(b,v.data,v.meta)}):this._worker.on(k,function(){r.delay(p,arguments,b)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},k)}},s.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!e("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,s,n){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}n.utf8encode=function(u){return l.nodebuffer?o.newBufferFrom(u,"utf-8"):(function(k){var p,b,v,y,S,I=k.length,x=0;for(y=0;y<I;y++)(64512&(b=k.charCodeAt(y)))==55296&&y+1<I&&(64512&(v=k.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),y++),x+=b<128?1:b<2048?2:b<65536?3:4;for(p=l.uint8array?new Uint8Array(x):new Array(x),y=S=0;S<x;y++)(64512&(b=k.charCodeAt(y)))==55296&&y+1<I&&(64512&(v=k.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),y++),b<128?p[S++]=b:(b<2048?p[S++]=192|b>>>6:(b<65536?p[S++]=224|b>>>12:(p[S++]=240|b>>>18,p[S++]=128|b>>>12&63),p[S++]=128|b>>>6&63),p[S++]=128|63&b);return p})(u)},n.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(k){var p,b,v,y,S=k.length,I=new Array(2*S);for(p=b=0;p<S;)if((v=k[p++])<128)I[b++]=v;else if(4<(y=c[v]))I[b++]=65533,p+=y-1;else{for(v&=y===2?31:y===3?15:7;1<y&&p<S;)v=v<<6|63&k[p++],y--;1<y?I[b++]=65533:v<65536?I[b++]=v:(v-=65536,I[b++]=55296|v>>10&1023,I[b++]=56320|1023&v)}return I.length!==b&&(I.subarray?I=I.subarray(0,b):I.length=b),r.applyFromCharCode(I)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(h,a),h.prototype.processChunk=function(u){var k=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var p=k;(k=new Uint8Array(p.length+this.leftOver.length)).set(this.leftOver,0),k.set(p,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var b=(function(y,S){var I;for((S=S||y.length)>y.length&&(S=y.length),I=S-1;0<=I&&(192&y[I])==128;)I--;return I<0||I===0?S:I+c[y[I]]>S?I:S})(k),v=k;b!==k.length&&(l.uint8array?(v=k.subarray(0,b),this.leftOver=k.subarray(b,k.length)):(v=k.slice(0,b),this.leftOver=k.slice(b,k.length))),this.push({data:n.utf8decode(v),meta:u.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=h,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:n.utf8encode(u.data),meta:u.meta})},n.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,s,n){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(p){return p}function d(p,b){for(var v=0;v<p.length;++v)b[v]=255&p.charCodeAt(v);return b}e("setimmediate"),n.newBlob=function(p,b){n.checkSupport("blob");try{return new Blob([p],{type:b})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(p),v.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(p,b,v){var y=[],S=0,I=p.length;if(I<=v)return String.fromCharCode.apply(null,p);for(;S<I;)b==="array"||b==="nodebuffer"?y.push(String.fromCharCode.apply(null,p.slice(S,Math.min(S+v,I)))):y.push(String.fromCharCode.apply(null,p.subarray(S,Math.min(S+v,I)))),S+=v;return y.join("")},stringifyByChar:function(p){for(var b="",v=0;v<p.length;v++)b+=String.fromCharCode(p[v]);return b},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function g(p){var b=65536,v=n.getTypeOf(p),y=!0;if(v==="uint8array"?y=h.applyCanBeUsed.uint8array:v==="nodebuffer"&&(y=h.applyCanBeUsed.nodebuffer),y)for(;1<b;)try{return h.stringifyByChunk(p,v,b)}catch{b=Math.floor(b/2)}return h.stringifyByChar(p)}function u(p,b){for(var v=0;v<p.length;v++)b[v]=p[v];return b}n.applyFromCharCode=g;var k={};k.string={string:c,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return k.string.uint8array(p).buffer},uint8array:function(p){return d(p,new Uint8Array(p.length))},nodebuffer:function(p){return d(p,o.allocBuffer(p.length))}},k.array={string:g,array:c,arraybuffer:function(p){return new Uint8Array(p).buffer},uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return o.newBufferFrom(p)}},k.arraybuffer={string:function(p){return g(new Uint8Array(p))},array:function(p){return u(new Uint8Array(p),new Array(p.byteLength))},arraybuffer:c,uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return o.newBufferFrom(new Uint8Array(p))}},k.uint8array={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return p.buffer},uint8array:c,nodebuffer:function(p){return o.newBufferFrom(p)}},k.nodebuffer={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return k.nodebuffer.uint8array(p).buffer},uint8array:function(p){return u(p,new Uint8Array(p.length))},nodebuffer:c},n.transformTo=function(p,b){if(b=b||"",!p)return b;n.checkSupport(p);var v=n.getTypeOf(b);return k[v][p](b)},n.resolve=function(p){for(var b=p.split("/"),v=[],y=0;y<b.length;y++){var S=b[y];S==="."||S===""&&y!==0&&y!==b.length-1||(S===".."?v.pop():v.push(S))}return v.join("/")},n.getTypeOf=function(p){return typeof p=="string"?"string":Object.prototype.toString.call(p)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(p)?"nodebuffer":r.uint8array&&p instanceof Uint8Array?"uint8array":r.arraybuffer&&p instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(p){if(!r[p.toLowerCase()])throw new Error(p+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(p){var b,v,y="";for(v=0;v<(p||"").length;v++)y+="\\x"+((b=p.charCodeAt(v))<16?"0":"")+b.toString(16).toUpperCase();return y},n.delay=function(p,b,v){setImmediate(function(){p.apply(v||null,b||[])})},n.inherits=function(p,b){function v(){}v.prototype=b.prototype,p.prototype=new v},n.extend=function(){var p,b,v={};for(p=0;p<arguments.length;p++)for(b in arguments[p])Object.prototype.hasOwnProperty.call(arguments[p],b)&&v[b]===void 0&&(v[b]=arguments[p][b]);return v},n.prepareContent=function(p,b,v,y,S){return a.Promise.resolve(b).then(function(I){return r.blob&&(I instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(I))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,C){var A=new FileReader;A.onload=function(E){x(E.target.result)},A.onerror=function(E){C(E.target.error)},A.readAsArrayBuffer(I)}):I}).then(function(I){var x=n.getTypeOf(I);return x?(x==="arraybuffer"?I=n.transformTo("uint8array",I):x==="string"&&(S?I=l.decode(I):v&&y!==!0&&(I=(function(C){return d(C,r.uint8array?new Uint8Array(C.length):new Array(C.length))})(I))),I):a.Promise.reject(new Error("Can't read the data of '"+p+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(h){this.files=[],this.loadOptions=h}d.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(h)+")")}},isSignature:function(h,g){var u=this.reader.index;this.reader.setIndex(h);var k=this.reader.readString(4)===g;return this.reader.setIndex(u),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,h);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,g,u,k=this.zip64EndOfCentralSize-44;0<k;)h=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[h]={id:h,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,g;for(h=0;h<this.files.length;h++)g=this.files[h],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var g=h;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var k=g-u;if(0<k)this.isSignature(g,o.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(h){this.reader=r(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),h=e("./support");function g(u,k){this.options=u,this.loadOptions=k}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var k,p;if(u.skip(22),this.fileNameLength=u.readInt(2),p=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(p),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(b){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===b)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,k,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var k=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(k),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var k,p,b,v=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<v;)k=u.readInt(2),p=u.readInt(2),b=u.readData(p),this.extraFields[k]={id:k,length:p,value:b};u.setIndex(v)},handleUTF8:function(){var u=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var p=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(p)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var v=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null}},s.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,s,n){function r(k,p,b){this.name=k,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=p,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(k){var p=null,b="string";try{if(!k)throw new Error("No output type specified.");var v=(b=k.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),p=this._decompressWorker();var y=!this._dataBinary;y&&!v&&(p=p.pipe(new a.Utf8EncodeWorker)),!y&&v&&(p=p.pipe(new a.Utf8DecodeWorker))}catch(S){(p=new d("error")).error(S)}return new l(p,b,"")},async:function(k,p){return this.internalStream(k).accumulate(p)},nodeStream:function(k,p){return this.internalStream(k||"nodebuffer").toNodejsStream(p)},_compressWorker:function(k,p){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,k,p)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<h.length;u++)r.prototype[h[u]]=g;s.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,s,n){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(k),h=r.document.createTextNode("");d.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var p=r.document.createElement("script");p.onreadystatechange=function(){k(),p.onreadystatechange=null,p.parentNode.removeChild(p),p=null},r.document.documentElement.appendChild(p)}:function(){setTimeout(k,0)};else{var g=new r.MessageChannel;g.port1.onmessage=k,l=function(){g.port2.postMessage(0)}}var u=[];function k(){var p,b;o=!0;for(var v=u.length;v;){for(b=u,u=[],p=-1;++p<v;)b[p]();v=u.length}o=!1}s.exports=function(p){u.push(p)!==1||o||l()}}).call(this,typeof Nn<"u"?Nn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,s,n){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function h(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&p(this,v)}function g(v,y,S){this.promise=v,typeof y=="function"&&(this.onFulfilled=y,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(v,y,S){r(function(){var I;try{I=y(S)}catch(x){return o.reject(v,x)}I===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,I)})}function k(v){var y=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof y=="function")return function(){y.apply(v,arguments)}}function p(v,y){var S=!1;function I(A){S||(S=!0,o.reject(v,A))}function x(A){S||(S=!0,o.resolve(v,A))}var C=b(function(){y(x,I)});C.status==="error"&&I(C.value)}function b(v,y){var S={};try{S.value=v(y),S.status="success"}catch(I){S.status="error",S.value=I}return S}(s.exports=h).prototype.finally=function(v){if(typeof v!="function")return this;var y=this.constructor;return this.then(function(S){return y.resolve(v()).then(function(){return S})},function(S){return y.resolve(v()).then(function(){throw S})})},h.prototype.catch=function(v){return this.then(null,v)},h.prototype.then=function(v,y){if(typeof v!="function"&&this.state===c||typeof y!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?v:y,this.outcome):this.queue.push(new g(S,v,y)),S},g.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},g.prototype.otherCallFulfilled=function(v){u(this.promise,this.onFulfilled,v)},g.prototype.callRejected=function(v){o.reject(this.promise,v)},g.prototype.otherCallRejected=function(v){u(this.promise,this.onRejected,v)},o.resolve=function(v,y){var S=b(k,y);if(S.status==="error")return o.reject(v,S.value);var I=S.value;if(I)p(v,I);else{v.state=c,v.outcome=y;for(var x=-1,C=v.queue.length;++x<C;)v.queue[x].callFulfilled(y)}return v},o.reject=function(v,y){v.state=a,v.outcome=y;for(var S=-1,I=v.queue.length;++S<I;)v.queue[S].callRejected(y);return v},h.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},h.reject=function(v){var y=new this(l);return o.reject(y,v)},h.all=function(v){var y=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=v.length,I=!1;if(!S)return this.resolve([]);for(var x=new Array(S),C=0,A=-1,E=new this(l);++A<S;)D(v[A],A);return E;function D(R,X){y.resolve(R).then(function(T){x[X]=T,++C!==S||I||(I=!0,o.resolve(E,x))},function(T){I||(I=!0,o.reject(E,T))})}},h.race=function(v){var y=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=v.length,I=!1;if(!S)return this.resolve([]);for(var x=-1,C=new this(l);++x<S;)A=v[x],y.resolve(A).then(function(E){I||(I=!0,o.resolve(C,E))},function(E){I||(I=!0,o.reject(C,E))});var A;return C}},{immediate:36}],38:[function(e,s,n){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),s.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,s,n){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,h=0,g=-1,u=0,k=8;function p(v){if(!(this instanceof p))return new p(v);this.options=l.assign({level:g,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},v||{});var y=this.options;y.raw&&0<y.windowBits?y.windowBits=-y.windowBits:y.gzip&&0<y.windowBits&&y.windowBits<16&&(y.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=r.deflateInit2(this.strm,y.level,y.method,y.windowBits,y.memLevel,y.strategy);if(S!==h)throw new Error(a[S]);if(y.header&&r.deflateSetHeader(this.strm,y.header),y.dictionary){var I;if(I=typeof y.dictionary=="string"?o.string2buf(y.dictionary):d.call(y.dictionary)==="[object ArrayBuffer]"?new Uint8Array(y.dictionary):y.dictionary,(S=r.deflateSetDictionary(this.strm,I))!==h)throw new Error(a[S]);this._dict_set=!0}}function b(v,y){var S=new p(y);if(S.push(v,!0),S.err)throw S.msg||a[S.err];return S.result}p.prototype.push=function(v,y){var S,I,x=this.strm,C=this.options.chunkSize;if(this.ended)return!1;I=y===~~y?y:y===!0?4:0,typeof v=="string"?x.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?x.input=new Uint8Array(v):x.input=v,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(C),x.next_out=0,x.avail_out=C),(S=r.deflate(x,I))!==1&&S!==h)return this.onEnd(S),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||I!==4&&I!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&S!==1);return I===4?(S=r.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===h):I!==2||(this.onEnd(h),!(x.avail_out=0))},p.prototype.onData=function(v){this.chunks.push(v)},p.prototype.onEnd=function(v){v===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},n.Deflate=p,n.deflate=b,n.deflateRaw=function(v,y){return(y=y||{}).raw=!0,b(v,y)},n.gzip=function(v,y){return(y=y||{}).gzip=!0,b(v,y)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,s,n){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),h=e("./zlib/gzheader"),g=Object.prototype.toString;function u(p){if(!(this instanceof u))return new u(p);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},p||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||p&&p.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,b.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new h,r.inflateGetHeader(this.strm,this.header)}function k(p,b){var v=new u(b);if(v.push(p,!0),v.err)throw v.msg||c[v.err];return v.result}u.prototype.push=function(p,b){var v,y,S,I,x,C,A=this.strm,E=this.options.chunkSize,D=this.options.dictionary,R=!1;if(this.ended)return!1;y=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof p=="string"?A.input=o.binstring2buf(p):g.call(p)==="[object ArrayBuffer]"?A.input=new Uint8Array(p):A.input=p,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(E),A.next_out=0,A.avail_out=E),(v=r.inflate(A,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&D&&(C=typeof D=="string"?o.string2buf(D):g.call(D)==="[object ArrayBuffer]"?new Uint8Array(D):D,v=r.inflateSetDictionary(this.strm,C)),v===a.Z_BUF_ERROR&&R===!0&&(v=a.Z_OK,R=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);A.next_out&&(A.avail_out!==0&&v!==a.Z_STREAM_END&&(A.avail_in!==0||y!==a.Z_FINISH&&y!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=o.utf8border(A.output,A.next_out),I=A.next_out-S,x=o.buf2string(A.output,S),A.next_out=I,A.avail_out=E-I,I&&l.arraySet(A.output,A.output,S,I,0),this.onData(x)):this.onData(l.shrinkBuf(A.output,A.next_out)))),A.avail_in===0&&A.avail_out===0&&(R=!0)}while((0<A.avail_in||A.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(y=a.Z_FINISH),y===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):y!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(A.avail_out=0))},u.prototype.onData=function(p){this.chunks.push(p)},u.prototype.onEnd=function(p){p===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},n.Inflate=u,n.inflate=k,n.inflateRaw=function(p,b){return(b=b||{}).raw=!0,k(p,b)},n.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var h in d)d.hasOwnProperty(h)&&(a[h]=d[h])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,h,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+h),g);else for(var u=0;u<h;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,h,g,u,k;for(c=h=0,d=a.length;c<d;c++)h+=a[c].length;for(k=new Uint8Array(h),c=g=0,d=a.length;c<d;c++)u=a[c],k.set(u,g),g+=u.length;return k}},o={arraySet:function(a,c,d,h,g){for(var u=0;u<h;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,o))},n.setTyped(r)},{}],42:[function(e,s,n){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(h,g){if(g<65537&&(h.subarray&&o||!h.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(h,g));for(var u="",k=0;k<g;k++)u+=String.fromCharCode(h[k]);return u}a[254]=a[254]=1,n.string2buf=function(h){var g,u,k,p,b,v=h.length,y=0;for(p=0;p<v;p++)(64512&(u=h.charCodeAt(p)))==55296&&p+1<v&&(64512&(k=h.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),p++),y+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(y),p=b=0;b<y;p++)(64512&(u=h.charCodeAt(p)))==55296&&p+1<v&&(64512&(k=h.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),p++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},n.buf2binstring=function(h){return d(h,h.length)},n.binstring2buf=function(h){for(var g=new r.Buf8(h.length),u=0,k=g.length;u<k;u++)g[u]=h.charCodeAt(u);return g},n.buf2string=function(h,g){var u,k,p,b,v=g||h.length,y=new Array(2*v);for(u=k=0;u<v;)if((p=h[u++])<128)y[k++]=p;else if(4<(b=a[p]))y[k++]=65533,u+=b-1;else{for(p&=b===2?31:b===3?15:7;1<b&&u<v;)p=p<<6|63&h[u++],b--;1<b?y[k++]=65533:p<65536?y[k++]=p:(p-=65536,y[k++]=55296|p>>10&1023,y[k++]=56320|1023&p)}return d(y,k)},n.utf8border=function(h,g){var u;for((g=g||h.length)>h.length&&(g=h.length),u=g-1;0<=u&&(192&h[u])==128;)u--;return u<0||u===0?g:u+a[h[u]]>g?u:g}},{"./common":41}],43:[function(e,s,n){s.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,h=0;o!==0;){for(o-=h=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--h;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,s,n){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();s.exports=function(l,o,a,c){var d=r,h=c+a;l^=-1;for(var g=c;g<h;g++)l=l>>>8^d[255&(l^o[g])];return-1^l}},{}],46:[function(e,s,n){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),h=0,g=4,u=0,k=-2,p=-1,b=4,v=2,y=8,S=9,I=286,x=30,C=19,A=2*I+1,E=15,D=3,R=258,X=R+D+1,T=42,O=113,w=1,z=2,Q=3,j=4;function at(f,F){return f.msg=d[F],F}function W(f){return(f<<1)-(4<f?9:0)}function Y(f){for(var F=f.length;0<=--F;)f[F]=0}function V(f){var F=f.state,P=F.pending;P>f.avail_out&&(P=f.avail_out),P!==0&&(l.arraySet(f.output,F.pending_buf,F.pending_out,P,f.next_out),f.next_out+=P,F.pending_out+=P,f.total_out+=P,f.avail_out-=P,F.pending-=P,F.pending===0&&(F.pending_out=0))}function N(f,F){o._tr_flush_block(f,0<=f.block_start?f.block_start:-1,f.strstart-f.block_start,F),f.block_start=f.strstart,V(f.strm)}function ct(f,F){f.pending_buf[f.pending++]=F}function rt(f,F){f.pending_buf[f.pending++]=F>>>8&255,f.pending_buf[f.pending++]=255&F}function st(f,F){var P,_,$=f.max_chain_length,B=f.strstart,K=f.prev_length,H=f.nice_match,U=f.strstart>f.w_size-X?f.strstart-(f.w_size-X):0,G=f.window,it=f.w_mask,tt=f.prev,ut=f.strstart+R,xt=G[B+K-1],bt=G[B+K];f.prev_length>=f.good_match&&($>>=2),H>f.lookahead&&(H=f.lookahead);do if(G[(P=F)+K]===bt&&G[P+K-1]===xt&&G[P]===G[B]&&G[++P]===G[B+1]){B+=2,P++;do;while(G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&G[++B]===G[++P]&&B<ut);if(_=R-(ut-B),B=ut-R,K<_){if(f.match_start=F,H<=(K=_))break;xt=G[B+K-1],bt=G[B+K]}}while((F=tt[F&it])>U&&--$!=0);return K<=f.lookahead?K:f.lookahead}function J(f){var F,P,_,$,B,K,H,U,G,it,tt=f.w_size;do{if($=f.window_size-f.lookahead-f.strstart,f.strstart>=tt+(tt-X)){for(l.arraySet(f.window,f.window,tt,tt,0),f.match_start-=tt,f.strstart-=tt,f.block_start-=tt,F=P=f.hash_size;_=f.head[--F],f.head[F]=tt<=_?_-tt:0,--P;);for(F=P=tt;_=f.prev[--F],f.prev[F]=tt<=_?_-tt:0,--P;);$+=tt}if(f.strm.avail_in===0)break;if(K=f.strm,H=f.window,U=f.strstart+f.lookahead,G=$,it=void 0,it=K.avail_in,G<it&&(it=G),P=it===0?0:(K.avail_in-=it,l.arraySet(H,K.input,K.next_in,it,U),K.state.wrap===1?K.adler=a(K.adler,H,it,U):K.state.wrap===2&&(K.adler=c(K.adler,H,it,U)),K.next_in+=it,K.total_in+=it,it),f.lookahead+=P,f.lookahead+f.insert>=D)for(B=f.strstart-f.insert,f.ins_h=f.window[B],f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+1])&f.hash_mask;f.insert&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+D-1])&f.hash_mask,f.prev[B&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=B,B++,f.insert--,!(f.lookahead+f.insert<D)););}while(f.lookahead<X&&f.strm.avail_in!==0)}function gt(f,F){for(var P,_;;){if(f.lookahead<X){if(J(f),f.lookahead<X&&F===h)return w;if(f.lookahead===0)break}if(P=0,f.lookahead>=D&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+D-1])&f.hash_mask,P=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),P!==0&&f.strstart-P<=f.w_size-X&&(f.match_length=st(f,P)),f.match_length>=D)if(_=o._tr_tally(f,f.strstart-f.match_start,f.match_length-D),f.lookahead-=f.match_length,f.match_length<=f.max_lazy_match&&f.lookahead>=D){for(f.match_length--;f.strstart++,f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+D-1])&f.hash_mask,P=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart,--f.match_length!=0;);f.strstart++}else f.strstart+=f.match_length,f.match_length=0,f.ins_h=f.window[f.strstart],f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+1])&f.hash_mask;else _=o._tr_tally(f,0,f.window[f.strstart]),f.lookahead--,f.strstart++;if(_&&(N(f,!1),f.strm.avail_out===0))return w}return f.insert=f.strstart<D-1?f.strstart:D-1,F===g?(N(f,!0),f.strm.avail_out===0?Q:j):f.last_lit&&(N(f,!1),f.strm.avail_out===0)?w:z}function mt(f,F){for(var P,_,$;;){if(f.lookahead<X){if(J(f),f.lookahead<X&&F===h)return w;if(f.lookahead===0)break}if(P=0,f.lookahead>=D&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+D-1])&f.hash_mask,P=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),f.prev_length=f.match_length,f.prev_match=f.match_start,f.match_length=D-1,P!==0&&f.prev_length<f.max_lazy_match&&f.strstart-P<=f.w_size-X&&(f.match_length=st(f,P),f.match_length<=5&&(f.strategy===1||f.match_length===D&&4096<f.strstart-f.match_start)&&(f.match_length=D-1)),f.prev_length>=D&&f.match_length<=f.prev_length){for($=f.strstart+f.lookahead-D,_=o._tr_tally(f,f.strstart-1-f.prev_match,f.prev_length-D),f.lookahead-=f.prev_length-1,f.prev_length-=2;++f.strstart<=$&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+D-1])&f.hash_mask,P=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),--f.prev_length!=0;);if(f.match_available=0,f.match_length=D-1,f.strstart++,_&&(N(f,!1),f.strm.avail_out===0))return w}else if(f.match_available){if((_=o._tr_tally(f,0,f.window[f.strstart-1]))&&N(f,!1),f.strstart++,f.lookahead--,f.strm.avail_out===0)return w}else f.match_available=1,f.strstart++,f.lookahead--}return f.match_available&&(_=o._tr_tally(f,0,f.window[f.strstart-1]),f.match_available=0),f.insert=f.strstart<D-1?f.strstart:D-1,F===g?(N(f,!0),f.strm.avail_out===0?Q:j):f.last_lit&&(N(f,!1),f.strm.avail_out===0)?w:z}function Z(f,F,P,_,$){this.good_length=f,this.max_lazy=F,this.nice_length=P,this.max_chain=_,this.func=$}function ot(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=y,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*A),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*C+1)),Y(this.dyn_ltree),Y(this.dyn_dtree),Y(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(E+1),this.heap=new l.Buf16(2*I+1),Y(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*I+1),Y(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function dt(f){var F;return f&&f.state?(f.total_in=f.total_out=0,f.data_type=v,(F=f.state).pending=0,F.pending_out=0,F.wrap<0&&(F.wrap=-F.wrap),F.status=F.wrap?T:O,f.adler=F.wrap===2?0:1,F.last_flush=h,o._tr_init(F),u):at(f,k)}function M(f){var F=dt(f);return F===u&&(function(P){P.window_size=2*P.w_size,Y(P.head),P.max_lazy_match=r[P.level].max_lazy,P.good_match=r[P.level].good_length,P.nice_match=r[P.level].nice_length,P.max_chain_length=r[P.level].max_chain,P.strstart=0,P.block_start=0,P.lookahead=0,P.insert=0,P.match_length=P.prev_length=D-1,P.match_available=0,P.ins_h=0})(f.state),F}function L(f,F,P,_,$,B){if(!f)return k;var K=1;if(F===p&&(F=6),_<0?(K=0,_=-_):15<_&&(K=2,_-=16),$<1||S<$||P!==y||_<8||15<_||F<0||9<F||B<0||b<B)return at(f,k);_===8&&(_=9);var H=new ot;return(f.state=H).strm=f,H.wrap=K,H.gzhead=null,H.w_bits=_,H.w_size=1<<H.w_bits,H.w_mask=H.w_size-1,H.hash_bits=$+7,H.hash_size=1<<H.hash_bits,H.hash_mask=H.hash_size-1,H.hash_shift=~~((H.hash_bits+D-1)/D),H.window=new l.Buf8(2*H.w_size),H.head=new l.Buf16(H.hash_size),H.prev=new l.Buf16(H.w_size),H.lit_bufsize=1<<$+6,H.pending_buf_size=4*H.lit_bufsize,H.pending_buf=new l.Buf8(H.pending_buf_size),H.d_buf=1*H.lit_bufsize,H.l_buf=3*H.lit_bufsize,H.level=F,H.strategy=B,H.method=P,M(f)}r=[new Z(0,0,0,0,function(f,F){var P=65535;for(P>f.pending_buf_size-5&&(P=f.pending_buf_size-5);;){if(f.lookahead<=1){if(J(f),f.lookahead===0&&F===h)return w;if(f.lookahead===0)break}f.strstart+=f.lookahead,f.lookahead=0;var _=f.block_start+P;if((f.strstart===0||f.strstart>=_)&&(f.lookahead=f.strstart-_,f.strstart=_,N(f,!1),f.strm.avail_out===0)||f.strstart-f.block_start>=f.w_size-X&&(N(f,!1),f.strm.avail_out===0))return w}return f.insert=0,F===g?(N(f,!0),f.strm.avail_out===0?Q:j):(f.strstart>f.block_start&&(N(f,!1),f.strm.avail_out),w)}),new Z(4,4,8,4,gt),new Z(4,5,16,8,gt),new Z(4,6,32,32,gt),new Z(4,4,16,16,mt),new Z(8,16,32,32,mt),new Z(8,16,128,128,mt),new Z(8,32,128,256,mt),new Z(32,128,258,1024,mt),new Z(32,258,258,4096,mt)],n.deflateInit=function(f,F){return L(f,F,y,15,8,0)},n.deflateInit2=L,n.deflateReset=M,n.deflateResetKeep=dt,n.deflateSetHeader=function(f,F){return f&&f.state?f.state.wrap!==2?k:(f.state.gzhead=F,u):k},n.deflate=function(f,F){var P,_,$,B;if(!f||!f.state||5<F||F<0)return f?at(f,k):k;if(_=f.state,!f.output||!f.input&&f.avail_in!==0||_.status===666&&F!==g)return at(f,f.avail_out===0?-5:k);if(_.strm=f,P=_.last_flush,_.last_flush=F,_.status===T)if(_.wrap===2)f.adler=0,ct(_,31),ct(_,139),ct(_,8),_.gzhead?(ct(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),ct(_,255&_.gzhead.time),ct(_,_.gzhead.time>>8&255),ct(_,_.gzhead.time>>16&255),ct(_,_.gzhead.time>>24&255),ct(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ct(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(ct(_,255&_.gzhead.extra.length),ct(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(f.adler=c(f.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(ct(_,0),ct(_,0),ct(_,0),ct(_,0),ct(_,0),ct(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ct(_,3),_.status=O);else{var K=y+(_.w_bits-8<<4)<<8;K|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(K|=32),K+=31-K%31,_.status=O,rt(_,K),_.strstart!==0&&(rt(_,f.adler>>>16),rt(_,65535&f.adler)),f.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),V(f),$=_.pending,_.pending!==_.pending_buf_size));)ct(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),V(f),$=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,ct(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),B===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),V(f),$=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,ct(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>$&&(f.adler=c(f.adler,_.pending_buf,_.pending-$,$)),B===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&V(f),_.pending+2<=_.pending_buf_size&&(ct(_,255&f.adler),ct(_,f.adler>>8&255),f.adler=0,_.status=O)):_.status=O),_.pending!==0){if(V(f),f.avail_out===0)return _.last_flush=-1,u}else if(f.avail_in===0&&W(F)<=W(P)&&F!==g)return at(f,-5);if(_.status===666&&f.avail_in!==0)return at(f,-5);if(f.avail_in!==0||_.lookahead!==0||F!==h&&_.status!==666){var H=_.strategy===2?(function(U,G){for(var it;;){if(U.lookahead===0&&(J(U),U.lookahead===0)){if(G===h)return w;break}if(U.match_length=0,it=o._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++,it&&(N(U,!1),U.strm.avail_out===0))return w}return U.insert=0,G===g?(N(U,!0),U.strm.avail_out===0?Q:j):U.last_lit&&(N(U,!1),U.strm.avail_out===0)?w:z})(_,F):_.strategy===3?(function(U,G){for(var it,tt,ut,xt,bt=U.window;;){if(U.lookahead<=R){if(J(U),U.lookahead<=R&&G===h)return w;if(U.lookahead===0)break}if(U.match_length=0,U.lookahead>=D&&0<U.strstart&&(tt=bt[ut=U.strstart-1])===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]){xt=U.strstart+R;do;while(tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&ut<xt);U.match_length=R-(xt-ut),U.match_length>U.lookahead&&(U.match_length=U.lookahead)}if(U.match_length>=D?(it=o._tr_tally(U,1,U.match_length-D),U.lookahead-=U.match_length,U.strstart+=U.match_length,U.match_length=0):(it=o._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++),it&&(N(U,!1),U.strm.avail_out===0))return w}return U.insert=0,G===g?(N(U,!0),U.strm.avail_out===0?Q:j):U.last_lit&&(N(U,!1),U.strm.avail_out===0)?w:z})(_,F):r[_.level].func(_,F);if(H!==Q&&H!==j||(_.status=666),H===w||H===Q)return f.avail_out===0&&(_.last_flush=-1),u;if(H===z&&(F===1?o._tr_align(_):F!==5&&(o._tr_stored_block(_,0,0,!1),F===3&&(Y(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),V(f),f.avail_out===0))return _.last_flush=-1,u}return F!==g?u:_.wrap<=0?1:(_.wrap===2?(ct(_,255&f.adler),ct(_,f.adler>>8&255),ct(_,f.adler>>16&255),ct(_,f.adler>>24&255),ct(_,255&f.total_in),ct(_,f.total_in>>8&255),ct(_,f.total_in>>16&255),ct(_,f.total_in>>24&255)):(rt(_,f.adler>>>16),rt(_,65535&f.adler)),V(f),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?u:1)},n.deflateEnd=function(f){var F;return f&&f.state?(F=f.state.status)!==T&&F!==69&&F!==73&&F!==91&&F!==103&&F!==O&&F!==666?at(f,k):(f.state=null,F===O?at(f,-3):u):k},n.deflateSetDictionary=function(f,F){var P,_,$,B,K,H,U,G,it=F.length;if(!f||!f.state||(B=(P=f.state).wrap)===2||B===1&&P.status!==T||P.lookahead)return k;for(B===1&&(f.adler=a(f.adler,F,it,0)),P.wrap=0,it>=P.w_size&&(B===0&&(Y(P.head),P.strstart=0,P.block_start=0,P.insert=0),G=new l.Buf8(P.w_size),l.arraySet(G,F,it-P.w_size,P.w_size,0),F=G,it=P.w_size),K=f.avail_in,H=f.next_in,U=f.input,f.avail_in=it,f.next_in=0,f.input=F,J(P);P.lookahead>=D;){for(_=P.strstart,$=P.lookahead-(D-1);P.ins_h=(P.ins_h<<P.hash_shift^P.window[_+D-1])&P.hash_mask,P.prev[_&P.w_mask]=P.head[P.ins_h],P.head[P.ins_h]=_,_++,--$;);P.strstart=_,P.lookahead=D-1,J(P)}return P.strstart+=P.lookahead,P.block_start=P.strstart,P.insert=P.lookahead,P.lookahead=0,P.match_length=P.prev_length=D-1,P.match_available=0,f.next_in=H,f.input=U,f.avail_in=K,P.wrap=B,u},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,s,n){s.exports=function(r,l){var o,a,c,d,h,g,u,k,p,b,v,y,S,I,x,C,A,E,D,R,X,T,O,w,z;o=r.state,a=r.next_in,w=r.input,c=a+(r.avail_in-5),d=r.next_out,z=r.output,h=d-(l-r.avail_out),g=d+(r.avail_out-257),u=o.dmax,k=o.wsize,p=o.whave,b=o.wnext,v=o.window,y=o.hold,S=o.bits,I=o.lencode,x=o.distcode,C=(1<<o.lenbits)-1,A=(1<<o.distbits)-1;t:do{S<15&&(y+=w[a++]<<S,S+=8,y+=w[a++]<<S,S+=8),E=I[y&C];e:for(;;){if(y>>>=D=E>>>24,S-=D,(D=E>>>16&255)===0)z[d++]=65535&E;else{if(!(16&D)){if((64&D)==0){E=I[(65535&E)+(y&(1<<D)-1)];continue e}if(32&D){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}R=65535&E,(D&=15)&&(S<D&&(y+=w[a++]<<S,S+=8),R+=y&(1<<D)-1,y>>>=D,S-=D),S<15&&(y+=w[a++]<<S,S+=8,y+=w[a++]<<S,S+=8),E=x[y&A];i:for(;;){if(y>>>=D=E>>>24,S-=D,!(16&(D=E>>>16&255))){if((64&D)==0){E=x[(65535&E)+(y&(1<<D)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(X=65535&E,S<(D&=15)&&(y+=w[a++]<<S,(S+=8)<D&&(y+=w[a++]<<S,S+=8)),u<(X+=y&(1<<D)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(y>>>=D,S-=D,(D=d-h)<X){if(p<(D=X-D)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(O=v,(T=0)===b){if(T+=k-D,D<R){for(R-=D;z[d++]=v[T++],--D;);T=d-X,O=z}}else if(b<D){if(T+=k+b-D,(D-=b)<R){for(R-=D;z[d++]=v[T++],--D;);if(T=0,b<R){for(R-=D=b;z[d++]=v[T++],--D;);T=d-X,O=z}}}else if(T+=b-D,D<R){for(R-=D;z[d++]=v[T++],--D;);T=d-X,O=z}for(;2<R;)z[d++]=O[T++],z[d++]=O[T++],z[d++]=O[T++],R-=3;R&&(z[d++]=O[T++],1<R&&(z[d++]=O[T++]))}else{for(T=d-X;z[d++]=z[T++],z[d++]=z[T++],z[d++]=z[T++],2<(R-=3););R&&(z[d++]=z[T++],1<R&&(z[d++]=z[T++]))}break}}break}}while(a<c&&d<g);a-=R=S>>3,y&=(1<<(S-=R<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),o.hold=y,o.bits=S}},{}],49:[function(e,s,n){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,h=2,g=0,u=-2,k=1,p=852,b=592;function v(T){return(T>>>24&255)+(T>>>8&65280)+((65280&T)<<8)+((255&T)<<24)}function y(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(T){var O;return T&&T.state?(O=T.state,T.total_in=T.total_out=O.total=0,T.msg="",O.wrap&&(T.adler=1&O.wrap),O.mode=k,O.last=0,O.havedict=0,O.dmax=32768,O.head=null,O.hold=0,O.bits=0,O.lencode=O.lendyn=new r.Buf32(p),O.distcode=O.distdyn=new r.Buf32(b),O.sane=1,O.back=-1,g):u}function I(T){var O;return T&&T.state?((O=T.state).wsize=0,O.whave=0,O.wnext=0,S(T)):u}function x(T,O){var w,z;return T&&T.state?(z=T.state,O<0?(w=0,O=-O):(w=1+(O>>4),O<48&&(O&=15)),O&&(O<8||15<O)?u:(z.window!==null&&z.wbits!==O&&(z.window=null),z.wrap=w,z.wbits=O,I(T))):u}function C(T,O){var w,z;return T?(z=new y,(T.state=z).window=null,(w=x(T,O))!==g&&(T.state=null),w):u}var A,E,D=!0;function R(T){if(D){var O;for(A=new r.Buf32(512),E=new r.Buf32(32),O=0;O<144;)T.lens[O++]=8;for(;O<256;)T.lens[O++]=9;for(;O<280;)T.lens[O++]=7;for(;O<288;)T.lens[O++]=8;for(c(d,T.lens,0,288,A,0,T.work,{bits:9}),O=0;O<32;)T.lens[O++]=5;c(h,T.lens,0,32,E,0,T.work,{bits:5}),D=!1}T.lencode=A,T.lenbits=9,T.distcode=E,T.distbits=5}function X(T,O,w,z){var Q,j=T.state;return j.window===null&&(j.wsize=1<<j.wbits,j.wnext=0,j.whave=0,j.window=new r.Buf8(j.wsize)),z>=j.wsize?(r.arraySet(j.window,O,w-j.wsize,j.wsize,0),j.wnext=0,j.whave=j.wsize):(z<(Q=j.wsize-j.wnext)&&(Q=z),r.arraySet(j.window,O,w-z,Q,j.wnext),(z-=Q)?(r.arraySet(j.window,O,w-z,z,0),j.wnext=z,j.whave=j.wsize):(j.wnext+=Q,j.wnext===j.wsize&&(j.wnext=0),j.whave<j.wsize&&(j.whave+=Q))),0}n.inflateReset=I,n.inflateReset2=x,n.inflateResetKeep=S,n.inflateInit=function(T){return C(T,15)},n.inflateInit2=C,n.inflate=function(T,O){var w,z,Q,j,at,W,Y,V,N,ct,rt,st,J,gt,mt,Z,ot,dt,M,L,f,F,P,_,$=0,B=new r.Buf8(4),K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!T||!T.state||!T.output||!T.input&&T.avail_in!==0)return u;(w=T.state).mode===12&&(w.mode=13),at=T.next_out,Q=T.output,Y=T.avail_out,j=T.next_in,z=T.input,W=T.avail_in,V=w.hold,N=w.bits,ct=W,rt=Y,F=g;t:for(;;)switch(w.mode){case k:if(w.wrap===0){w.mode=13;break}for(;N<16;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(2&w.wrap&&V===35615){B[w.check=0]=255&V,B[1]=V>>>8&255,w.check=o(w.check,B,2,0),N=V=0,w.mode=2;break}if(w.flags=0,w.head&&(w.head.done=!1),!(1&w.wrap)||(((255&V)<<8)+(V>>8))%31){T.msg="incorrect header check",w.mode=30;break}if((15&V)!=8){T.msg="unknown compression method",w.mode=30;break}if(N-=4,f=8+(15&(V>>>=4)),w.wbits===0)w.wbits=f;else if(f>w.wbits){T.msg="invalid window size",w.mode=30;break}w.dmax=1<<f,T.adler=w.check=1,w.mode=512&V?10:12,N=V=0;break;case 2:for(;N<16;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(w.flags=V,(255&w.flags)!=8){T.msg="unknown compression method",w.mode=30;break}if(57344&w.flags){T.msg="unknown header flags set",w.mode=30;break}w.head&&(w.head.text=V>>8&1),512&w.flags&&(B[0]=255&V,B[1]=V>>>8&255,w.check=o(w.check,B,2,0)),N=V=0,w.mode=3;case 3:for(;N<32;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.head&&(w.head.time=V),512&w.flags&&(B[0]=255&V,B[1]=V>>>8&255,B[2]=V>>>16&255,B[3]=V>>>24&255,w.check=o(w.check,B,4,0)),N=V=0,w.mode=4;case 4:for(;N<16;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.head&&(w.head.xflags=255&V,w.head.os=V>>8),512&w.flags&&(B[0]=255&V,B[1]=V>>>8&255,w.check=o(w.check,B,2,0)),N=V=0,w.mode=5;case 5:if(1024&w.flags){for(;N<16;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.length=V,w.head&&(w.head.extra_len=V),512&w.flags&&(B[0]=255&V,B[1]=V>>>8&255,w.check=o(w.check,B,2,0)),N=V=0}else w.head&&(w.head.extra=null);w.mode=6;case 6:if(1024&w.flags&&(W<(st=w.length)&&(st=W),st&&(w.head&&(f=w.head.extra_len-w.length,w.head.extra||(w.head.extra=new Array(w.head.extra_len)),r.arraySet(w.head.extra,z,j,st,f)),512&w.flags&&(w.check=o(w.check,z,st,j)),W-=st,j+=st,w.length-=st),w.length))break t;w.length=0,w.mode=7;case 7:if(2048&w.flags){if(W===0)break t;for(st=0;f=z[j+st++],w.head&&f&&w.length<65536&&(w.head.name+=String.fromCharCode(f)),f&&st<W;);if(512&w.flags&&(w.check=o(w.check,z,st,j)),W-=st,j+=st,f)break t}else w.head&&(w.head.name=null);w.length=0,w.mode=8;case 8:if(4096&w.flags){if(W===0)break t;for(st=0;f=z[j+st++],w.head&&f&&w.length<65536&&(w.head.comment+=String.fromCharCode(f)),f&&st<W;);if(512&w.flags&&(w.check=o(w.check,z,st,j)),W-=st,j+=st,f)break t}else w.head&&(w.head.comment=null);w.mode=9;case 9:if(512&w.flags){for(;N<16;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(V!==(65535&w.check)){T.msg="header crc mismatch",w.mode=30;break}N=V=0}w.head&&(w.head.hcrc=w.flags>>9&1,w.head.done=!0),T.adler=w.check=0,w.mode=12;break;case 10:for(;N<32;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}T.adler=w.check=v(V),N=V=0,w.mode=11;case 11:if(w.havedict===0)return T.next_out=at,T.avail_out=Y,T.next_in=j,T.avail_in=W,w.hold=V,w.bits=N,2;T.adler=w.check=1,w.mode=12;case 12:if(O===5||O===6)break t;case 13:if(w.last){V>>>=7&N,N-=7&N,w.mode=27;break}for(;N<3;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}switch(w.last=1&V,N-=1,3&(V>>>=1)){case 0:w.mode=14;break;case 1:if(R(w),w.mode=20,O!==6)break;V>>>=2,N-=2;break t;case 2:w.mode=17;break;case 3:T.msg="invalid block type",w.mode=30}V>>>=2,N-=2;break;case 14:for(V>>>=7&N,N-=7&N;N<32;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if((65535&V)!=(V>>>16^65535)){T.msg="invalid stored block lengths",w.mode=30;break}if(w.length=65535&V,N=V=0,w.mode=15,O===6)break t;case 15:w.mode=16;case 16:if(st=w.length){if(W<st&&(st=W),Y<st&&(st=Y),st===0)break t;r.arraySet(Q,z,j,st,at),W-=st,j+=st,Y-=st,at+=st,w.length-=st;break}w.mode=12;break;case 17:for(;N<14;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(w.nlen=257+(31&V),V>>>=5,N-=5,w.ndist=1+(31&V),V>>>=5,N-=5,w.ncode=4+(15&V),V>>>=4,N-=4,286<w.nlen||30<w.ndist){T.msg="too many length or distance symbols",w.mode=30;break}w.have=0,w.mode=18;case 18:for(;w.have<w.ncode;){for(;N<3;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.lens[K[w.have++]]=7&V,V>>>=3,N-=3}for(;w.have<19;)w.lens[K[w.have++]]=0;if(w.lencode=w.lendyn,w.lenbits=7,P={bits:w.lenbits},F=c(0,w.lens,0,19,w.lencode,0,w.work,P),w.lenbits=P.bits,F){T.msg="invalid code lengths set",w.mode=30;break}w.have=0,w.mode=19;case 19:for(;w.have<w.nlen+w.ndist;){for(;Z=($=w.lencode[V&(1<<w.lenbits)-1])>>>16&255,ot=65535&$,!((mt=$>>>24)<=N);){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(ot<16)V>>>=mt,N-=mt,w.lens[w.have++]=ot;else{if(ot===16){for(_=mt+2;N<_;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(V>>>=mt,N-=mt,w.have===0){T.msg="invalid bit length repeat",w.mode=30;break}f=w.lens[w.have-1],st=3+(3&V),V>>>=2,N-=2}else if(ot===17){for(_=mt+3;N<_;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}N-=mt,f=0,st=3+(7&(V>>>=mt)),V>>>=3,N-=3}else{for(_=mt+7;N<_;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}N-=mt,f=0,st=11+(127&(V>>>=mt)),V>>>=7,N-=7}if(w.have+st>w.nlen+w.ndist){T.msg="invalid bit length repeat",w.mode=30;break}for(;st--;)w.lens[w.have++]=f}}if(w.mode===30)break;if(w.lens[256]===0){T.msg="invalid code -- missing end-of-block",w.mode=30;break}if(w.lenbits=9,P={bits:w.lenbits},F=c(d,w.lens,0,w.nlen,w.lencode,0,w.work,P),w.lenbits=P.bits,F){T.msg="invalid literal/lengths set",w.mode=30;break}if(w.distbits=6,w.distcode=w.distdyn,P={bits:w.distbits},F=c(h,w.lens,w.nlen,w.ndist,w.distcode,0,w.work,P),w.distbits=P.bits,F){T.msg="invalid distances set",w.mode=30;break}if(w.mode=20,O===6)break t;case 20:w.mode=21;case 21:if(6<=W&&258<=Y){T.next_out=at,T.avail_out=Y,T.next_in=j,T.avail_in=W,w.hold=V,w.bits=N,a(T,rt),at=T.next_out,Q=T.output,Y=T.avail_out,j=T.next_in,z=T.input,W=T.avail_in,V=w.hold,N=w.bits,w.mode===12&&(w.back=-1);break}for(w.back=0;Z=($=w.lencode[V&(1<<w.lenbits)-1])>>>16&255,ot=65535&$,!((mt=$>>>24)<=N);){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(Z&&(240&Z)==0){for(dt=mt,M=Z,L=ot;Z=($=w.lencode[L+((V&(1<<dt+M)-1)>>dt)])>>>16&255,ot=65535&$,!(dt+(mt=$>>>24)<=N);){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}V>>>=dt,N-=dt,w.back+=dt}if(V>>>=mt,N-=mt,w.back+=mt,w.length=ot,Z===0){w.mode=26;break}if(32&Z){w.back=-1,w.mode=12;break}if(64&Z){T.msg="invalid literal/length code",w.mode=30;break}w.extra=15&Z,w.mode=22;case 22:if(w.extra){for(_=w.extra;N<_;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.length+=V&(1<<w.extra)-1,V>>>=w.extra,N-=w.extra,w.back+=w.extra}w.was=w.length,w.mode=23;case 23:for(;Z=($=w.distcode[V&(1<<w.distbits)-1])>>>16&255,ot=65535&$,!((mt=$>>>24)<=N);){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if((240&Z)==0){for(dt=mt,M=Z,L=ot;Z=($=w.distcode[L+((V&(1<<dt+M)-1)>>dt)])>>>16&255,ot=65535&$,!(dt+(mt=$>>>24)<=N);){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}V>>>=dt,N-=dt,w.back+=dt}if(V>>>=mt,N-=mt,w.back+=mt,64&Z){T.msg="invalid distance code",w.mode=30;break}w.offset=ot,w.extra=15&Z,w.mode=24;case 24:if(w.extra){for(_=w.extra;N<_;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}w.offset+=V&(1<<w.extra)-1,V>>>=w.extra,N-=w.extra,w.back+=w.extra}if(w.offset>w.dmax){T.msg="invalid distance too far back",w.mode=30;break}w.mode=25;case 25:if(Y===0)break t;if(st=rt-Y,w.offset>st){if((st=w.offset-st)>w.whave&&w.sane){T.msg="invalid distance too far back",w.mode=30;break}J=st>w.wnext?(st-=w.wnext,w.wsize-st):w.wnext-st,st>w.length&&(st=w.length),gt=w.window}else gt=Q,J=at-w.offset,st=w.length;for(Y<st&&(st=Y),Y-=st,w.length-=st;Q[at++]=gt[J++],--st;);w.length===0&&(w.mode=21);break;case 26:if(Y===0)break t;Q[at++]=w.length,Y--,w.mode=21;break;case 27:if(w.wrap){for(;N<32;){if(W===0)break t;W--,V|=z[j++]<<N,N+=8}if(rt-=Y,T.total_out+=rt,w.total+=rt,rt&&(T.adler=w.check=w.flags?o(w.check,Q,rt,at-rt):l(w.check,Q,rt,at-rt)),rt=Y,(w.flags?V:v(V))!==w.check){T.msg="incorrect data check",w.mode=30;break}N=V=0}w.mode=28;case 28:if(w.wrap&&w.flags){for(;N<32;){if(W===0)break t;W--,V+=z[j++]<<N,N+=8}if(V!==(4294967295&w.total)){T.msg="incorrect length check",w.mode=30;break}N=V=0}w.mode=29;case 29:F=1;break t;case 30:F=-3;break t;case 31:return-4;case 32:default:return u}return T.next_out=at,T.avail_out=Y,T.next_in=j,T.avail_in=W,w.hold=V,w.bits=N,(w.wsize||rt!==T.avail_out&&w.mode<30&&(w.mode<27||O!==4))&&X(T,T.output,T.next_out,rt-T.avail_out)?(w.mode=31,-4):(ct-=T.avail_in,rt-=T.avail_out,T.total_in+=ct,T.total_out+=rt,w.total+=rt,w.wrap&&rt&&(T.adler=w.check=w.flags?o(w.check,Q,rt,T.next_out-rt):l(w.check,Q,rt,T.next_out-rt)),T.data_type=w.bits+(w.last?64:0)+(w.mode===12?128:0)+(w.mode===20||w.mode===15?256:0),(ct==0&&rt===0||O===4)&&F===g&&(F=-5),F)},n.inflateEnd=function(T){if(!T||!T.state)return u;var O=T.state;return O.window&&(O.window=null),T.state=null,g},n.inflateGetHeader=function(T,O){var w;return T&&T.state?(2&(w=T.state).wrap)==0?u:((w.head=O).done=!1,g):u},n.inflateSetDictionary=function(T,O){var w,z=O.length;return T&&T.state?(w=T.state).wrap!==0&&w.mode!==11?u:w.mode===11&&l(1,O,z,0)!==w.check?-3:X(T,O,z,z)?(w.mode=31,-4):(w.havedict=1,g):u},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,s,n){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(d,h,g,u,k,p,b,v){var y,S,I,x,C,A,E,D,R,X=v.bits,T=0,O=0,w=0,z=0,Q=0,j=0,at=0,W=0,Y=0,V=0,N=null,ct=0,rt=new r.Buf16(16),st=new r.Buf16(16),J=null,gt=0;for(T=0;T<=15;T++)rt[T]=0;for(O=0;O<u;O++)rt[h[g+O]]++;for(Q=X,z=15;1<=z&&rt[z]===0;z--);if(z<Q&&(Q=z),z===0)return k[p++]=20971520,k[p++]=20971520,v.bits=1,0;for(w=1;w<z&&rt[w]===0;w++);for(Q<w&&(Q=w),T=W=1;T<=15;T++)if(W<<=1,(W-=rt[T])<0)return-1;if(0<W&&(d===0||z!==1))return-1;for(st[1]=0,T=1;T<15;T++)st[T+1]=st[T]+rt[T];for(O=0;O<u;O++)h[g+O]!==0&&(b[st[h[g+O]]++]=O);if(A=d===0?(N=J=b,19):d===1?(N=l,ct-=257,J=o,gt-=257,256):(N=a,J=c,-1),T=w,C=p,at=O=V=0,I=-1,x=(Y=1<<(j=Q))-1,d===1&&852<Y||d===2&&592<Y)return 1;for(;;){for(E=T-at,R=b[O]<A?(D=0,b[O]):b[O]>A?(D=J[gt+b[O]],N[ct+b[O]]):(D=96,0),y=1<<T-at,w=S=1<<j;k[C+(V>>at)+(S-=y)]=E<<24|D<<16|R|0,S!==0;);for(y=1<<T-1;V&y;)y>>=1;if(y!==0?(V&=y-1,V+=y):V=0,O++,--rt[T]==0){if(T===z)break;T=h[g+b[O]]}if(Q<T&&(V&x)!==I){for(at===0&&(at=Q),C+=w,W=1<<(j=T-at);j+at<z&&!((W-=rt[j+at])<=0);)j++,W<<=1;if(Y+=1<<j,d===1&&852<Y||d===2&&592<Y)return 1;k[I=V&x]=Q<<24|j<<16|C-p|0}}return V!==0&&(k[C+V]=T-at<<24|64<<16|0),v.bits=Q,0}},{"../utils/common":41}],51:[function(e,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,s,n){var r=e("../utils/common"),l=0,o=1;function a($){for(var B=$.length;0<=--B;)$[B]=0}var c=0,d=29,h=256,g=h+1+d,u=30,k=19,p=2*g+1,b=15,v=16,y=7,S=256,I=16,x=17,C=18,A=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],E=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],D=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(g+2));a(X);var T=new Array(2*u);a(T);var O=new Array(512);a(O);var w=new Array(256);a(w);var z=new Array(d);a(z);var Q,j,at,W=new Array(u);function Y($,B,K,H,U){this.static_tree=$,this.extra_bits=B,this.extra_base=K,this.elems=H,this.max_length=U,this.has_stree=$&&$.length}function V($,B){this.dyn_tree=$,this.max_code=0,this.stat_desc=B}function N($){return $<256?O[$]:O[256+($>>>7)]}function ct($,B){$.pending_buf[$.pending++]=255&B,$.pending_buf[$.pending++]=B>>>8&255}function rt($,B,K){$.bi_valid>v-K?($.bi_buf|=B<<$.bi_valid&65535,ct($,$.bi_buf),$.bi_buf=B>>v-$.bi_valid,$.bi_valid+=K-v):($.bi_buf|=B<<$.bi_valid&65535,$.bi_valid+=K)}function st($,B,K){rt($,K[2*B],K[2*B+1])}function J($,B){for(var K=0;K|=1&$,$>>>=1,K<<=1,0<--B;);return K>>>1}function gt($,B,K){var H,U,G=new Array(b+1),it=0;for(H=1;H<=b;H++)G[H]=it=it+K[H-1]<<1;for(U=0;U<=B;U++){var tt=$[2*U+1];tt!==0&&($[2*U]=J(G[tt]++,tt))}}function mt($){var B;for(B=0;B<g;B++)$.dyn_ltree[2*B]=0;for(B=0;B<u;B++)$.dyn_dtree[2*B]=0;for(B=0;B<k;B++)$.bl_tree[2*B]=0;$.dyn_ltree[2*S]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function Z($){8<$.bi_valid?ct($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function ot($,B,K,H){var U=2*B,G=2*K;return $[U]<$[G]||$[U]===$[G]&&H[B]<=H[K]}function dt($,B,K){for(var H=$.heap[K],U=K<<1;U<=$.heap_len&&(U<$.heap_len&&ot(B,$.heap[U+1],$.heap[U],$.depth)&&U++,!ot(B,H,$.heap[U],$.depth));)$.heap[K]=$.heap[U],K=U,U<<=1;$.heap[K]=H}function M($,B,K){var H,U,G,it,tt=0;if($.last_lit!==0)for(;H=$.pending_buf[$.d_buf+2*tt]<<8|$.pending_buf[$.d_buf+2*tt+1],U=$.pending_buf[$.l_buf+tt],tt++,H===0?st($,U,B):(st($,(G=w[U])+h+1,B),(it=A[G])!==0&&rt($,U-=z[G],it),st($,G=N(--H),K),(it=E[G])!==0&&rt($,H-=W[G],it)),tt<$.last_lit;);st($,S,B)}function L($,B){var K,H,U,G=B.dyn_tree,it=B.stat_desc.static_tree,tt=B.stat_desc.has_stree,ut=B.stat_desc.elems,xt=-1;for($.heap_len=0,$.heap_max=p,K=0;K<ut;K++)G[2*K]!==0?($.heap[++$.heap_len]=xt=K,$.depth[K]=0):G[2*K+1]=0;for(;$.heap_len<2;)G[2*(U=$.heap[++$.heap_len]=xt<2?++xt:0)]=1,$.depth[U]=0,$.opt_len--,tt&&($.static_len-=it[2*U+1]);for(B.max_code=xt,K=$.heap_len>>1;1<=K;K--)dt($,G,K);for(U=ut;K=$.heap[1],$.heap[1]=$.heap[$.heap_len--],dt($,G,1),H=$.heap[1],$.heap[--$.heap_max]=K,$.heap[--$.heap_max]=H,G[2*U]=G[2*K]+G[2*H],$.depth[U]=($.depth[K]>=$.depth[H]?$.depth[K]:$.depth[H])+1,G[2*K+1]=G[2*H+1]=U,$.heap[1]=U++,dt($,G,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(bt,Mt){var Vt,Yt,ee,Nt,Ge,te,Jt=Mt.dyn_tree,vi=Mt.max_code,Oi=Mt.stat_desc.static_tree,vs=Mt.stat_desc.has_stree,bs=Mt.stat_desc.extra_bits,En=Mt.stat_desc.extra_base,bi=Mt.stat_desc.max_length,Pi=0;for(Nt=0;Nt<=b;Nt++)bt.bl_count[Nt]=0;for(Jt[2*bt.heap[bt.heap_max]+1]=0,Vt=bt.heap_max+1;Vt<p;Vt++)bi<(Nt=Jt[2*Jt[2*(Yt=bt.heap[Vt])+1]+1]+1)&&(Nt=bi,Pi++),Jt[2*Yt+1]=Nt,vi<Yt||(bt.bl_count[Nt]++,Ge=0,En<=Yt&&(Ge=bs[Yt-En]),te=Jt[2*Yt],bt.opt_len+=te*(Nt+Ge),vs&&(bt.static_len+=te*(Oi[2*Yt+1]+Ge)));if(Pi!==0){do{for(Nt=bi-1;bt.bl_count[Nt]===0;)Nt--;bt.bl_count[Nt]--,bt.bl_count[Nt+1]+=2,bt.bl_count[bi]--,Pi-=2}while(0<Pi);for(Nt=bi;Nt!==0;Nt--)for(Yt=bt.bl_count[Nt];Yt!==0;)vi<(ee=bt.heap[--Vt])||(Jt[2*ee+1]!==Nt&&(bt.opt_len+=(Nt-Jt[2*ee+1])*Jt[2*ee],Jt[2*ee+1]=Nt),Yt--)}})($,B),gt(G,xt,$.bl_count)}function f($,B,K){var H,U,G=-1,it=B[1],tt=0,ut=7,xt=4;for(it===0&&(ut=138,xt=3),B[2*(K+1)+1]=65535,H=0;H<=K;H++)U=it,it=B[2*(H+1)+1],++tt<ut&&U===it||(tt<xt?$.bl_tree[2*U]+=tt:U!==0?(U!==G&&$.bl_tree[2*U]++,$.bl_tree[2*I]++):tt<=10?$.bl_tree[2*x]++:$.bl_tree[2*C]++,G=U,xt=(tt=0)===it?(ut=138,3):U===it?(ut=6,3):(ut=7,4))}function F($,B,K){var H,U,G=-1,it=B[1],tt=0,ut=7,xt=4;for(it===0&&(ut=138,xt=3),H=0;H<=K;H++)if(U=it,it=B[2*(H+1)+1],!(++tt<ut&&U===it)){if(tt<xt)for(;st($,U,$.bl_tree),--tt!=0;);else U!==0?(U!==G&&(st($,U,$.bl_tree),tt--),st($,I,$.bl_tree),rt($,tt-3,2)):tt<=10?(st($,x,$.bl_tree),rt($,tt-3,3)):(st($,C,$.bl_tree),rt($,tt-11,7));G=U,xt=(tt=0)===it?(ut=138,3):U===it?(ut=6,3):(ut=7,4)}}a(W);var P=!1;function _($,B,K,H){rt($,(c<<1)+(H?1:0),3),(function(U,G,it,tt){Z(U),ct(U,it),ct(U,~it),r.arraySet(U.pending_buf,U.window,G,it,U.pending),U.pending+=it})($,B,K)}n._tr_init=function($){P||((function(){var B,K,H,U,G,it=new Array(b+1);for(U=H=0;U<d-1;U++)for(z[U]=H,B=0;B<1<<A[U];B++)w[H++]=U;for(w[H-1]=U,U=G=0;U<16;U++)for(W[U]=G,B=0;B<1<<E[U];B++)O[G++]=U;for(G>>=7;U<u;U++)for(W[U]=G<<7,B=0;B<1<<E[U]-7;B++)O[256+G++]=U;for(K=0;K<=b;K++)it[K]=0;for(B=0;B<=143;)X[2*B+1]=8,B++,it[8]++;for(;B<=255;)X[2*B+1]=9,B++,it[9]++;for(;B<=279;)X[2*B+1]=7,B++,it[7]++;for(;B<=287;)X[2*B+1]=8,B++,it[8]++;for(gt(X,g+1,it),B=0;B<u;B++)T[2*B+1]=5,T[2*B]=J(B,5);Q=new Y(X,A,h+1,g,b),j=new Y(T,E,0,u,b),at=new Y(new Array(0),D,0,k,y)})(),P=!0),$.l_desc=new V($.dyn_ltree,Q),$.d_desc=new V($.dyn_dtree,j),$.bl_desc=new V($.bl_tree,at),$.bi_buf=0,$.bi_valid=0,mt($)},n._tr_stored_block=_,n._tr_flush_block=function($,B,K,H){var U,G,it=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(tt){var ut,xt=4093624447;for(ut=0;ut<=31;ut++,xt>>>=1)if(1&xt&&tt.dyn_ltree[2*ut]!==0)return l;if(tt.dyn_ltree[18]!==0||tt.dyn_ltree[20]!==0||tt.dyn_ltree[26]!==0)return o;for(ut=32;ut<h;ut++)if(tt.dyn_ltree[2*ut]!==0)return o;return l})($)),L($,$.l_desc),L($,$.d_desc),it=(function(tt){var ut;for(f(tt,tt.dyn_ltree,tt.l_desc.max_code),f(tt,tt.dyn_dtree,tt.d_desc.max_code),L(tt,tt.bl_desc),ut=k-1;3<=ut&&tt.bl_tree[2*R[ut]+1]===0;ut--);return tt.opt_len+=3*(ut+1)+5+5+4,ut})($),U=$.opt_len+3+7>>>3,(G=$.static_len+3+7>>>3)<=U&&(U=G)):U=G=K+5,K+4<=U&&B!==-1?_($,B,K,H):$.strategy===4||G===U?(rt($,2+(H?1:0),3),M($,X,T)):(rt($,4+(H?1:0),3),(function(tt,ut,xt,bt){var Mt;for(rt(tt,ut-257,5),rt(tt,xt-1,5),rt(tt,bt-4,4),Mt=0;Mt<bt;Mt++)rt(tt,tt.bl_tree[2*R[Mt]+1],3);F(tt,tt.dyn_ltree,ut-1),F(tt,tt.dyn_dtree,xt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,it+1),M($,$.dyn_ltree,$.dyn_dtree)),mt($),H&&Z($)},n._tr_tally=function($,B,K){return $.pending_buf[$.d_buf+2*$.last_lit]=B>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&B,$.pending_buf[$.l_buf+$.last_lit]=255&K,$.last_lit++,B===0?$.dyn_ltree[2*K]++:($.matches++,B--,$.dyn_ltree[2*(w[K]+h+1)]++,$.dyn_dtree[2*N(B)]++),$.last_lit===$.lit_bufsize-1},n._tr_align=function($){rt($,2,3),st($,S,X),(function(B){B.bi_valid===16?(ct(B,B.bi_buf),B.bi_buf=0,B.bi_valid=0):8<=B.bi_valid&&(B.pending_buf[B.pending++]=255&B.bi_buf,B.bi_buf>>=8,B.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,s,n){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,h,g=1,u={},k=!1,p=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(I){process.nextTick(function(){y(I)})}:(function(){if(l.postMessage&&!l.importScripts){var I=!0,x=l.onmessage;return l.onmessage=function(){I=!1},l.postMessage("","*"),l.onmessage=x,I}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(I){l.postMessage(h+I,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(I){y(I.data)},function(I){d.port2.postMessage(I)}):p&&"onreadystatechange"in p.createElement("script")?(c=p.documentElement,function(I){var x=p.createElement("script");x.onreadystatechange=function(){y(I),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(I){setTimeout(y,0,I)},b.setImmediate=function(I){typeof I!="function"&&(I=new Function(""+I));for(var x=new Array(arguments.length-1),C=0;C<x.length;C++)x[C]=arguments[C+1];var A={callback:I,args:x};return u[g]=A,a(g),g++},b.clearImmediate=v}function v(I){delete u[I]}function y(I){if(k)setTimeout(y,0,I);else{var x=u[I];if(x){k=!0;try{(function(C){var A=C.callback,E=C.args;switch(E.length){case 0:A();break;case 1:A(E[0]);break;case 2:A(E[0],E[1]);break;case 3:A(E[0],E[1],E[2]);break;default:A.apply(o,E)}})(x)}finally{v(I),k=!1}}}}function S(I){I.source===l&&typeof I.data=="string"&&I.data.indexOf(h)===0&&y(+I.data.slice(h.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Nn<"u"?Nn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ds)),Ds.exports}var Vg=Wg();const Kg=Ug(Vg),qg=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Gg=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Zg(t){const i=await Kg.loadAsync(t),e={},s=[];let n="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(n=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Gg.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const h=c.split("/");h.length>1&&(e[h.slice(1).join("/")]=d)}else if(qg.test(c)){const d=await a.file.async("uint8array"),h=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;s.push({zipPath:c,fileName:h,data:d,blob:g})}}return{entryMarkdown:n,entryMarkdownPath:r,virtualFiles:e,assets:s}}function Yg(t,i){if(Object.keys(i).length===0)return t;function e(n){const r=n.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function s(n){let r=n;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const n of t.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slidev-background"]){const r=n.pageAttrs["custom-slidev-background"],l=e(r);l&&(n.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=s(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const n=t.docRootAttrs["custom-slidev-background"],r=e(n);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function Xl(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Jg(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const s=e[1].trim(),n=s.indexOf("#"),r=n!==-1?s.slice(0,n):s,l=n!==-1?s.slice(n+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const u=o.split("/").pop();for(const[k,p]of Object.entries(a))if(k.endsWith(`/${o}`)||u&&k.endsWith(`/${u}`)){c=p;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const k=require("path");u.push(k.resolve(i.baseDir,o)),u.push(k.resolve(i.baseDir,r))}catch{}try{const k=require("path");u.push(k.resolve(process.cwd(),o))}catch{}for(const k of u){const p=Xl(k);if(p!==null){c=p;break}}}if(!c){const u=Wl||{};if(c=u[r]||u[o]||u[`snippets/${o}`],!c){const k=o.split("/").pop();for(const[p,b]of Object.entries(u))if(p.endsWith(`/${o}`)||k&&p.endsWith(`/${k}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(u);if(k){const p=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(p?p[1]:"")+k[1].trimEnd()}}const h=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${d}
\`\`\``}function Xg(t){let i=!1,e=!1;for(let s=0;s<t.length;s++){const n=t[s];if(n==="'"&&!e)i=!i;else if(n==='"'&&!i)e=!e;else if(n==="#"&&!i&&!e)return t.slice(0,s).trim()}return t.trim()}function Vn(t){const i={},e=t.split(/\r?\n/);let s=0;for(;s<e.length;){const n=e[s],r=n.trim();if(!r||r.startsWith("#")){s++;continue}const l=n.indexOf(":");if(l>0){const o=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){s++;const c=[];let d=-1;for(;s<e.length;){const h=e[s];if(!h.trim()){c.push(""),s++;continue}const u=h.match(/^(\s+)/),k=u?u[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(h.slice(d)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Xg(a),!a){let c=s+1;const d=[];let h=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){h!==-1&&d.push(""),c++;continue}const k=g.match(/^(\s+)/),p=k?k[1].length:0;if(h===-1)if(p>0)h=p;else break;if(p<h)break;d.push(g.slice(h)),c++}if(d.length>0){i[o]=Vn(d.join(`
`)),s=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}s++}return i}const Qg=/^\s*```ya?ml([\s\S]*?)```/;function kr(t){let i={},e=t.trim();const s=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const r=Vn(s[1]);if(Object.keys(r).length>0||!s[1].trim())return i=r,e=e.slice(s[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const n=e.match(Qg);if(n)i=Vn(n[1]),e=e.slice(n[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Vn(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function tv(t){const i=t.split(/\r?\n/),e=[];let s=0,n=!1;function r(l){if(s>=l)return;const o=i.slice(s,l).join(`
`).trim();o&&e.push(o),s=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(s=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let h=l+1;for(;h<i.length&&!i[h].trimStart().startsWith(d);h++);h<i.length&&(l=h)}}return s<i.length&&r(i.length),e}function Kn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const h=tv(d),g={};let u="",k="",p=0;if(h.length>0){const R=h[0],X=kr(R),T=Object.keys(X.frontmatter).length>0,O=X.content.length>0;T&&!O&&h.length>1?(p=1,b(X.frontmatter)):T&&b(X.frontmatter)}function b(R){u=R.title||"",R.theme&&(g[ln]=String(R.theme)),R.aspectRatio&&(g[an]=String(R.aspectRatio)),R.highlighter&&(g[Cr]=String(R.highlighter)),R.transition&&(g[cn]=String(R.transition)),R.colorSchema&&(g[$r]=String(R.colorSchema)),R.layout&&(g[ft]=String(R.layout)),R.background&&(g[Ut]=String(R.background)),R.image&&(g[Ee]=String(R.image)),R.class&&(g[ji]=String(R.class));for(const[X,T]of Object.entries(R))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(g[`custom-slidev-${X}`]=typeof T=="object"?JSON.stringify(T):String(T))}const v=[];let y=0,S=0,I=0,x=0;const C=new Set,A={};let E=1;for(let R=p;R<h.length;R++){const X=h[R],{frontmatter:T,content:O}=kr(X),w=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),z=T.src||(w?w[1]:void 0);if(z){const Z=String(z).trim().replace(/^['"]|['"]$/g,"");let ot=c[Z]||c[Z.replace(/^\.\//,"")]||c[`pages/${Z.replace(/^.*pages\//,"")}`];if(!ot){const M=Z.replace(/^\.\//,""),L=[];if(i.baseDir)try{const f=require("path");L.push(f.resolve(i.baseDir,M)),L.push(f.resolve(i.baseDir,Z))}catch{}try{const f=require("path");L.push(f.resolve(process.cwd(),M)),L.push(f.resolve(process.cwd(),Z))}catch{}for(const f of L){const F=Xl(f);if(F!==null){ot=F;break}}}const dt={};T.layout&&(dt[ft]=String(T.layout)),T.transition&&(dt[Xt]=String(T.transition)),T.background&&(dt[Ut]=String(T.background)),T.image&&(dt[Ee]=String(T.image)),T.class&&(dt[ji]=String(T.class));for(const[M,L]of Object.entries(T))["src","layout","transition","background","image","class"].includes(M)||(dt[`custom-slidev-${M}`]=typeof L=="object"?JSON.stringify(L):String(L));if(ot){const M=Kn(ot,{...i,virtualFiles:c});for(const L of M.slides){L.pageIndex=E++,L.pageAttrs={...dt,...L.pageAttrs},v.push(L);const f=L.pageAttrs[ft]||"default";A[f]=(A[f]||0)+1}continue}else{v.push({pageIndex:E++,pageAttrs:{...dt,"custom-slidev-src":Z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const M=dt[ft]||"default";A[M]=(A[M]||0)+1;continue}}const Q={};T.layout&&(Q[ft]=String(T.layout)),T.transition&&(Q[Xt]=String(T.transition)),T.background&&(Q[Ut]=String(T.background)),T.image&&(Q[Ee]=String(T.image)),T.class&&(Q[ji]=String(T.class));for(const[Z,ot]of Object.entries(T))["layout","transition","background","image","class"].includes(Z)||(Q[`custom-slidev-${Z}`]=typeof ot=="object"?JSON.stringify(ot):String(ot));let j=O;const at=[];let W=j.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});W=W.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});let Y="";const V=Array.from(W.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const Z=V[V.length-1],ot=W.slice(Z.index+Z[0].length).trim();if(!ot||!ot.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const M=Z[1].trim();M.startsWith("TODO:")||(Y=M,y++),e&&(W=W.slice(0,Z.index).trimEnd()+W.slice(Z.index+Z[0].length))}}e&&(W=W.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Z=0;Z<at.length;Z++)W=W.replace(`__CODE_TOKEN_NOTE_${Z}__`,at[Z]);if(j=W,Y){for(let dt=0;dt<at.length;dt++)Y=Y.replace(`__CODE_TOKEN_NOTE_${dt}__`,at[dt]);const ot=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(dt=>`> ${dt}`).join(`
`)}
{: custom-slidev-note="true"}`;j=j?`${j}

${ot}`:ot}let N=!1;if(/<style\b/i.test(j)){N=!0;const Z=j.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Z){for(const ot of Z){const dt=ot.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${dt}`:dt}l&&(j=j.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ct=j.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ct&&(S+=ct.length);const rt=j.match(/```\w+\s+\{[^}]+\}/g);rt&&(I+=rt.length);const st=j.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),j=j.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Z=>Jg(Z,{...i,virtualFiles:c})||Z),s&&(j=j.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(j=j.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),j=j.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(j=j.replace(/^::\w+::\s*$/gm,"")),o&&(j=Na(j)),a){let Z=j.trim(),ot="";const dt=Z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(dt!==-1&&(ot=Z.slice(dt),Z=Z.slice(0,dt).trim()),(T.layout==="image-left"||T.layout==="image-right")&&T.image){const M=String(T.image).trim(),L=T.layout==="image-left"?"image-left":"image-right",f=`![配图](${M})
{: custom-slidev-layout="${L}" }`;T.layout==="image-left"?Z=`{{{col

${f}

${Z}

}}}`:Z=`{{{col

${Z}

${f}

}}}`}if(T.background){const L=`![背景图](${String(T.background).trim()})
{: custom-slidev-role="background" }`;Z=Z?`${L}

${Z}`:L}j=ot?`${Z}

${ot}`:Z}const J=ev(j);Q[Ut]&&J.push(Q[Ut]),Q[Ee]&&J.push(Q[Ee]);for(const Z of J)C.add(Z);const gt=/<[A-Z][a-zA-Z0-9]+/.test(j),mt=Q[ft]||(E===1?g[ft]||"cover":"default");A[mt]=(A[mt]||0)+1,v.push({pageIndex:E++,pageAttrs:Q,notes:Y,rawMarkdown:j,hasVueComponent:gt,hasStyleTag:N,assetReferences:J})}if(!u&&v.length>0){const R=v[0].rawMarkdown.match(/^#\s+(.+)$/m);R&&(u=R[1].trim())}k&&(g["custom-slidev-custom-css"]=k);let D=v.map(R=>`---

${R.rawMarkdown}`).join(`

`);return D.trimStart().startsWith("---")||(D=`---

${D.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:v,totalSlides:v.length,stats:{totalNotes:y,totalVClicks:S,totalShikiHighlights:I,totalSlots:x,discoveredAssets:Array.from(C),layoutDistribution:A},flattenedMarkdown:D,customCss:k}}function ev(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=e.exec(t))!==null;){const r=s[1].split(/\s+/)[0].trim();r&&i.push(r)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(t))!==null;){const r=s[1].trim();r&&i.push(r)}return i}const iv={class:"spm-import-dialog"},nv={class:"spm-tabs-header"},sv={class:"spm-dialog-body"},ov={key:0,class:"spm-file-section"},rv={key:0,class:"spm-dropzone-prompt"},lv={key:1,class:"spm-dropzone-active"},av={class:"spm-file-badge"},cv={class:"spm-file-size"},dv={key:1,class:"spm-text-section"},uv={key:2,class:"spm-error-banner"},fv={key:3,class:"spm-preview-card"},pv={class:"spm-config-grid"},hv={class:"spm-form-item"},mv={class:"spm-form-item"},gv=["value"],vv={class:"spm-stats-grid"},bv={class:"spm-stat-box"},yv={class:"spm-stat-value"},kv={class:"spm-stat-box"},wv={class:"spm-stat-value"},xv={class:"spm-stat-box"},_v={class:"spm-stat-value"},Sv={class:"spm-stat-box"},Cv={class:"spm-stat-value"},$v={key:0,class:"spm-chips-row"},Iv={class:"spm-options-group"},Av={class:"spm-checkbox-label"},Tv={class:"spm-checkbox-label"},Ev={class:"spm-checkbox-label"},Mv={class:"spm-checkbox-label"},Bv={class:"spm-dialog-footer"},Dv=["disabled"],Ov=["disabled"],Pv={key:0},Lv={key:1},Rv=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,s=ei("plugin"),n=ht("file"),r=ht(!1),l=ht(!1),o=ht(""),a=ht(null),c=ht(null),d=ht(""),h=ht(0),g=ht(""),u=ht([]),k=ht(null),p=ht(""),b=ht([]),v=ht(""),y=ht(!0),S=ht(!0),I=ht(!0),x=ht(!0);async function C(){c.value?await z(c.value):g.value&&Q()}const A=$t(()=>{const W=h.value;if(W===0)return"0 B";const Y=1024,V=["B","KB","MB","GB"],N=Math.floor(Math.log(W)/Math.log(Y));return`${(W/Y**N).toFixed(1)} ${V[N]}`}),E=$t(()=>{var W;return((W=k.value)==null?void 0:W.docRootAttrs["custom-slidev-theme"])||"default"}),D=$t(()=>{var W;return u.value.length>0?u.value.length:((W=k.value)==null?void 0:W.stats.discoveredAssets.length)||0}),R=$t(()=>{var Y;const W=((Y=k.value)==null?void 0:Y.stats.layoutDistribution)||{};return Object.entries(W).map(([V,N])=>({name:V,count:N}))});In(async()=>{try{const W=await ma();W!=null&&W.notebooks&&Array.isArray(W.notebooks)&&(b.value=W.notebooks.filter(Y=>!Y.closed),b.value.length>0&&(v.value=b.value[0].id))}catch(W){console.warn("获取笔记本列表失败:",W)}});function X(){var W;(W=a.value)==null||W.click()}function T(){c.value=null,d.value="",h.value=0,k.value=null,u.value=[],o.value=""}async function O(W){const Y=W.target;Y.files&&Y.files[0]&&await z(Y.files[0])}async function w(W){var Y;r.value=!1,(Y=W.dataTransfer)!=null&&Y.files&&W.dataTransfer.files[0]&&await z(W.dataTransfer.files[0])}async function z(W){o.value="",c.value=W,d.value=W.name,h.value=W.size;try{if(W.name.toLowerCase().endsWith(".zip")){const V=await W.arrayBuffer(),N=await Zg(V);if(!N.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=N.assets;const ct=Kn(N.entryMarkdown,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,virtualFiles:N.virtualFiles});k.value=ct,p.value=ct.docTitle||W.name.replace(/\.zip$/i,"")}else{const V=await W.text();u.value=[];const N=W.path||"",ct=N?N.replace(/[\\/][^\\/]+$/,""):"",rt=Kn(V,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,baseDir:ct||void 0});k.value=rt,p.value=rt.docTitle||W.name.replace(/\.md$/i,"")}}catch(Y){console.error("解析文件失败:",Y),o.value=`解析文件失败: ${Y.message||String(Y)}`}}function Q(){if(o.value="",!g.value.trim()){k.value=null;return}try{const W=Kn(g.value,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1});k.value=W,p.value=W.docTitle||"Slidev 演示文稿"}catch(W){o.value=`解析 Markdown 源码失败: ${W.message||String(W)}`}}async function j(){var W;if(k.value){if(!v.value&&b.value.length>0&&(v.value=b.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Y=k.value,V={};if(I.value&&u.value.length>0){const ot=[];for(const dt of u.value){const M=new File([dt.data],dt.fileName,{type:"application/octet-stream"});ot.push(M)}try{const dt=await va("/data/assets",ot);if(dt!=null&&dt.succMap)for(const[M,L]of Object.entries(dt.succMap))V[M]=String(L)}catch(dt){console.warn("上传本地静态资产失败，保留原路径:",dt)}}Object.keys(V).length>0&&Yg(Y,V);const N=(p.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ct=`/${N}`,rt=await ga(v.value,ct,Y.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const st=((W=Y.slides[0])==null?void 0:W.pageAttrs)||{};await zt(rt,{...st,...Y.docRootAttrs});const J=await qn(rt).catch(()=>[]),gt=ot=>{if(!ot)return!1;const dt=String(ot.type||"").toLowerCase(),M=String(ot.markdown||"").trim(),L=String(ot.content||"").trim();return dt==="tb"||dt==="thematic-break"||dt==="nodethematicbreak"||M==="---"||M==="***"||L==="---"||L==="***"},mt=J.filter(gt);if(mt.length>=Y.slides.length)for(let ot=0;ot<Y.slides.length;ot++){const dt=Y.slides[ot],M=mt[ot];M&&M.id&&Object.keys(dt.pageAttrs).length>0&&await zt(M.id,dt.pageAttrs)}else for(let ot=1;ot<Y.slides.length;ot++){const dt=Y.slides[ot],M=mt[ot-1];M&&M.id&&Object.keys(dt.pageAttrs).length>0&&await zt(M.id,dt.pageAttrs)}let Z=!1;for(const ot of J){if(gt(ot)){Z=!1;continue}const dt=(ot.markdown||ot.content||"").trim();if(dt==="::right::"||dt.startsWith("::right::")){Z=!0;continue}Z&&ot.id&&await zt(ot.id,{[Tt]:"right"}).catch(()=>{})}vt.showMessage(`🎉 成功导入 Slidev 演示文档《${N}》！`),e("success",{docId:rt}),e("close"),x.value&&s&&(s.currentDocId=rt,await vt.openTab({app:s.app,doc:{id:rt}}),s.openBottomPreviewTab&&s.openBottomPreviewTab())}catch(Y){console.error("导入 Slidev 演示失败:",Y),o.value=`导入执行失败: ${Y.message||String(Y)}`}finally{l.value=!1}}}function at(){e("close")}return(W,Y)=>(et(),nt("div",{class:"spm-modal-overlay",onClick:Me(at,["self"])},[m("div",iv,[m("div",{class:"spm-dialog-header"},[Y[11]||(Y[11]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:at},"✕")]),m("div",nv,[m("button",{class:Et(["spm-tab-btn",{active:n.value==="file"}]),onClick:Y[0]||(Y[0]=V=>n.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:Et(["spm-tab-btn",{active:n.value==="text"}]),onClick:Y[1]||(Y[1]=V=>n.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",sv,[n.value==="file"?(et(),nt("div",ov,[m("div",{class:Et(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Y[2]||(Y[2]=Me(V=>r.value=!0,["prevent"])),onDragleave:Y[3]||(Y[3]=Me(V=>r.value=!1,["prevent"])),onDrop:Me(w,["prevent"]),onClick:X},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:O},null,544),d.value?(et(),nt("div",lv,[m("span",av,"📄 "+St(d.value),1),m("span",cv,"("+St(A.value)+")",1),m("button",{class:"spm-btn-text",onClick:Me(T,["stop"])},"更换文件")])):(et(),nt("div",rv,[...Y[12]||(Y[12]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Ys(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Ys("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(et(),nt("div",dv,[Te(m("textarea",{"onUpdate:modelValue":Y[4]||(Y[4]=V=>g.value=V),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:Q},null,544),[[ns,g.value]])])),o.value?(et(),nt("div",uv," ⚠️ "+St(o.value),1)):Ft("",!0),k.value?(et(),nt("div",fv,[Y[24]||(Y[24]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",pv,[m("div",hv,[Y[13]||(Y[13]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(m("input",{"onUpdate:modelValue":Y[5]||(Y[5]=V=>p.value=V),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[ns,p.value]])]),m("div",mv,[Y[14]||(Y[14]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(m("select",{"onUpdate:modelValue":Y[6]||(Y[6]=V=>v.value=V),class:"spm-select"},[(et(!0),nt(Gt,null,ke(b.value,V=>(et(),nt("option",{key:V.id,value:V.id},St(V.name),9,gv))),128))],512),[[du,v.value]])])]),m("div",vv,[m("div",bv,[m("span",yv,St(k.value.totalSlides),1),Y[15]||(Y[15]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",kv,[m("span",wv,St(E.value),1),Y[16]||(Y[16]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",xv,[m("span",_v,St(k.value.stats.totalNotes),1),Y[17]||(Y[17]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Sv,[m("span",Cv,St(D.value),1),Y[18]||(Y[18]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),R.value.length>0?(et(),nt("div",$v,[Y[19]||(Y[19]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(et(!0),nt(Gt,null,ke(R.value,V=>(et(),nt("span",{key:V.name,class:"spm-chip-badge"},St(V.name)+": "+St(V.count),1))),128))])):Ft("",!0),m("div",Iv,[m("label",Av,[Te(m("input",{"onUpdate:modelValue":Y[7]||(Y[7]=V=>y.value=V),type:"checkbox",onChange:C},null,544),[[zn,y.value]]),Y[20]||(Y[20]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Tv,[Te(m("input",{"onUpdate:modelValue":Y[8]||(Y[8]=V=>S.value=V),type:"checkbox",onChange:C},null,544),[[zn,S.value]]),Y[21]||(Y[21]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Ev,[Te(m("input",{"onUpdate:modelValue":Y[9]||(Y[9]=V=>I.value=V),type:"checkbox"},null,512),[[zn,I.value]]),Y[22]||(Y[22]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Mv,[Te(m("input",{"onUpdate:modelValue":Y[10]||(Y[10]=V=>x.value=V),type:"checkbox"},null,512),[[zn,x.value]]),Y[23]||(Y[23]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ft("",!0)]),m("div",Bv,[m("button",{class:"spm-btn-secondary",disabled:l.value,onClick:at}," 取消 ",8,Dv),m("button",{class:"spm-btn-primary",disabled:!k.value||l.value,onClick:j},[l.value?(et(),nt("span",Pv,"⏳ 正在导入生成中...")):(et(),nt("span",Lv,"🚀 确认导入思源笔记"))],8,Ov)])])]))}}),zv=Re(Rv,[["__scopeId","data-v-8771dc8a"]]),Nv={class:"spm-slidev-inspector"},Fv={class:"spm-inspector-topbar"},jv={class:"spm-inspector-title"},Hv={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Uv={class:"spm-inspector-topbar-actions"},Wv={class:"spm-target-banner"},Vv={class:"spm-target-info"},Kv=["aria-label"],qv={key:0,class:"spm-save-status"},Gv=["title"],Zv={class:"spm-inspector-body"},Yv=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ei("plugin"),s=ht(!1);function n(q){s.value=!1,c.value=q.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(q.docId)}const r=ht(""),l=ht(""),o=ht({}),a=ht(""),c=ht(""),d=ht(""),h=ht(""),g=ht(""),u=ht(null),k=ht(""),p=ht("");let b=null;function v(q="已同步"){k.value=q,b&&window.clearTimeout(b),b=window.setTimeout(()=>{k.value=""},1200)}function y(){var lt;const q=r.value||c.value;q&&(lt=navigator==null?void 0:navigator.clipboard)!=null&&lt.writeText&&navigator.clipboard.writeText(q).then(()=>{p.value="已复制！",setTimeout(()=>{p.value=""},1500)}).catch(()=>{})}const S=$t(()=>l.value==="NodeThematicBreak"),I=$t(()=>l.value==="NodeCodeBlock"),x=ht(!1),C=$t(()=>{if(x.value||B.value)return!0;const q=a.value||"";return!!hi(q)}),A=$t(()=>{const q=l.value||"";if(q==="NodeVideo"||q==="video")return!0;const lt=a.value||"";return!!(/<video\b/i.test(lt)||/\.mp4\b/i.test(lt))}),E=$t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),D=$t(()=>{const q=r.value||c.value||"";return q.length>8?q.slice(-8):q||"无"}),R=$t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),X=$t(()=>{if(S.value)return"分页符 (---)";if(E.value)return"全局文档";if(A.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),T=$t(()=>S.value?"tag-divider":E.value?"tag-doc":"tag-block"),O=$t(()=>o.value[ft]||"default"),w=$t(()=>o.value[Xt]||"slide-left"),z=ht(""),Q=ht(""),j=$t(()=>{var At;if(!((At=u.value)!=null&&At.slides)||u.value.slides.length===0)return null;const q=r.value,lt=d.value,yt=h.value;if(yt){let _t=u.value.slides.find(Dt=>Dt.startBlockId===yt);if(_t||(_t=u.value.slides.find(Dt=>{var Ot,Pt;return((Pt=(Ot=Dt.blocks)==null?void 0:Ot[0])==null?void 0:Pt.id)===yt}),_t))return _t}if(q){let _t=u.value.slides.find(Ot=>Ot.startBlockId===q);if(_t||(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===q))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(q))}),_t)||lt&&lt!==q&&(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===lt))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(lt))}),_t)||(_t=u.value.slides.find(Ot=>{var Pt;return(Pt=Ot.noteBlocks)==null?void 0:Pt.some(Zt=>Zt.id===q||Zt.id===lt)}),_t))return _t;const Dt=o.value[Tt];if(Dt&&["col-1","col-2","col-3"].includes(Dt)&&(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.frontmatter)==null?void 0:Pt.layout)==="three-cols-header"||((Zt=Ot.blocks)==null?void 0:Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))}),_t))return _t}return u.value.slides[0]||null}),at=$t(()=>{var q;return((q=j.value)==null?void 0:q.notes)||""}),W=$t(()=>{var q,lt,yt;return((yt=(lt=(q=j.value)==null?void 0:q.noteBlocks)==null?void 0:lt[0])==null?void 0:yt.id)||""}),Y=$t(()=>{var At,_t,Dt,Ot,Pt,Zt;if(S.value){const Bt=o.value[ft]||o.value["custom-slidev-layout"];if(Bt)return Bt}const q=o.value[Tt]||o.value["custom-slidev-slot"];if(q&&["col-1","col-2","col-3"].includes(q))return"three-cols-header";if(g.value)return g.value;const lt=h.value||(S.value?r.value:"");if(lt){const Bt=Ht.getBlockAttrOverride(lt);if(Bt!=null&&Bt[ft])return Bt[ft]}if(lt&&((At=u.value)!=null&&At.slides)){const Bt=u.value.slides.find(ci=>ci.startBlockId===lt);if((_t=Bt==null?void 0:Bt.frontmatter)!=null&&_t.layout)return Bt.frontmatter.layout}if((Ot=(Dt=j.value)==null?void 0:Dt.frontmatter)!=null&&Ot.layout)return j.value.frontmatter.layout;if((Zt=(Pt=j.value)==null?void 0:Pt.blocks)!=null&&Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))return"three-cols-header";const yt=Ht.getBlockAttrOverride(c.value);return yt!=null&&yt[ft]?yt[ft]:"default"}),V=$t(()=>{var q;return((q=j.value)==null?void 0:q.pageIndex)||1}),N=$t(()=>!!(o.value[ie]||o.value["slidev-note"])),ct=$t(()=>{var lt;if(o.value[Ce])return o.value[Ce];const q=r.value;if(q&&((lt=j.value)!=null&&lt.blocks)){const yt=j.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.clicks)return yt.clicks}return""}),rt=$t(()=>{var lt;if(o.value[We])return o.value[We];const q=r.value;if(q&&((lt=j.value)!=null&&lt.blocks)){const yt=j.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.motion)return typeof yt.motion=="string"?yt.motion:JSON.stringify(yt.motion)}return""}),st=$t(()=>{var lt;if(o.value[Tt])return o.value[Tt];const q=r.value;if(q&&((lt=j.value)!=null&&lt.blocks)){const yt=j.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.slot)return yt.slot}return""}),J=ht(""),gt=ht(""),mt=$t(()=>o.value[yi]==="true"),Z=$t(()=>o.value[Bn]==="true"),ot=$t(()=>o.value[Li]==="true"),dt=$t(()=>o.value[Dn]!=="false");async function M(){(mt.value?"false":"true")==="true"?(await H({[yi]:"true",[Li]:"true"}),o.value[yi]="true",o.value[Li]="true"):(await G(yi,"false"),o.value[yi]="false")}async function L(){const q=Z.value?"false":"true";await G(Bn,q)}async function f(){const q=ot.value?"false":"true";await G(Li,q)}async function F(){const q=dt.value?"false":"true";await G(Dn,q)}const P=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.theme)||o.value[ln]||"default"}),_=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.aspectRatio)||o.value[an]||"16/9"}),$=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.defaultTransition)||o.value[cn]||"slide-left"}),B=$t(()=>{var _t,Dt;if((o.value[qt]||o.value["slidev-role"])===Ir||o.value[Ut]==="true")return"background";const lt=o.value[ft]||o.value["slidev-layout"];if(lt==="image-left"||lt==="image-right")return lt;const yt=a.value||"",At=hi(yt);if(At&&((Dt=(_t=j.value)==null?void 0:_t.frontmatter)!=null&&Dt.background)){const Ot=j.value.frontmatter.background;if(Ot===At||Ot.endsWith(At)||At.endsWith(Ot))return"background"}return""});async function K(q){var Dt;const lt=r.value;if(!lt)return;const yt=a.value||"",At=hi(yt)||"",_t=h.value||c.value;if(q)if(q==="background"){const Ot={[qt]:"background",[ft]:""};_t&&At&&(z.value=At,await zt(_t,{[Ut]:At}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:At}),se(_t,{[Ut]:At}),j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.background=At)),await H(Ot)}else(q==="image-left"||q==="image-right")&&await H({[ft]:q,[qt]:""});else{const Ot={[qt]:"",[ft]:""};if(o.value[Ut]==="true"&&(Ot[Ut]=""),_t&&At&&z.value===At&&(z.value="",await zt(_t,{[Ut]:""}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:""}),se(_t,{[Ut]:""}),(Dt=j.value)!=null&&Dt.frontmatter&&delete j.value.frontmatter.background),await H(Ot),typeof document<"u"){const Pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${lt}"]`),Zt=Pt==null?void 0:Pt.closest('[data-type="NodeListItem"]'),Bt=Zt==null?void 0:Zt.getAttribute("data-node-id");if(Bt&&Bt!==lt){const ci={[ft]:"",[qt]:""};se(Bt,ci),Ht.setBlockAttrOverride(Bt,ci),await zt(Bt,ci).catch(()=>{})}}}}async function H(q){const lt=r.value||c.value;if(lt){for(const[yt,At]of Object.entries(q))o.value[yt]=At;if(Ht.setBlockAttrOverride(lt,q),se(lt,q),ft in q){const yt=q[ft];g.value=yt,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=yt)}v("保存中...");try{await zt(lt,q),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const U=$t(()=>!!(o.value[Ce]||o.value[We]||o.value[Tt]||o.value[$i]||o.value[ie]||o.value["slidev-note"]||o.value[qt]||o.value[ft]||o.value[yi]||o.value[Bn]||o.value[Li]||o.value[Dn]));async function G(q,lt){const yt=r.value||c.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),q===ft&&(g.value=lt,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=lt)),v("保存中...");try{await zt(yt,{[q]:lt}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function it(q,lt){var At;const yt=c.value||r.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),(At=u.value)!=null&&At.config&&(q===ln&&(u.value.config.theme=lt),q===an&&(u.value.config.aspectRatio=lt),q===cn&&(u.value.config.defaultTransition=lt)),v("更新中...");try{await zt(yt,{[q]:lt}),v("已更新"),e&&await e.compileCurrentDocument(yt)}catch{v("更新失败")}}}function tt(q){G(ft,q)}function ut(q){G(Xt,q)}function xt(q){z.value=q,G(Ut,q)}function bt(q){Q.value=q,G(Ee,q)}async function Mt(){const q=r.value;if(q)if(N.value){v("取消中...");try{await zt(q,{[ie]:"","slidev-note":""}),Ht.setBlockAttrOverride(q,{[ie]:"","slidev-note":""}),se(q,{[ie]:"","slidev-note":""}),delete o.value[ie],delete o.value["slidev-note"],v("已取消备注"),vt.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 取消讲稿备注失败:",lt),v("取消失败"),vt.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let lt=a.value;try{const Dt=await ya(q);Dt!=null&&Dt.kramdown&&(lt=Dt.kramdown)}catch{}const _t=`> [!NOTE] 💡 演讲备注
${(Br(lt)||lt.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Dt=>`> ${Dt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Po("markdown",_t,q),await zt(q,{[ie]:"true"}),Ht.setBlockAttrOverride(q,{[ie]:"true"}),se(q,{[ie]:"true"}),o.value[ie]="true",l.value="NodeCallout",v("已设为讲稿备注"),vt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",lt),v("设置失败"),vt.showMessage("转为讲稿备注提示块失败")}}}async function Vt(q){var Bt,ci,Eo,Mo,Bo,Do,Oo;const At=`> [!NOTE] 💡 演讲备注
${(q||"在此输入本页讲稿提词...").split(/\r?\n/).map(ze=>`> ${ze}`).join(`
`)}
{: custom-slidev-note="true"}`,_t=((Bt=u.value)==null?void 0:Bt.slides)||[],Dt=j.value,Ot=Dt?_t.findIndex(ze=>ze===Dt):-1;let Pt=null;if(Ot!==-1&&Ot<_t.length-1){const ze=_t[Ot+1];Pt=await sn("markdown",At,ze.startBlockId)}else{const ze=((ci=Dt==null?void 0:Dt.noteBlocks)==null?void 0:ci.slice(-1)[0])||((Eo=Dt==null?void 0:Dt.blocks)==null?void 0:Eo.slice(-1)[0]);ze!=null&&ze.id?Pt=await sn("markdown",At,void 0,ze.id):Pt=await _r("markdown",At,c.value)}const Zt=((Do=(Bo=(Mo=Pt==null?void 0:Pt[0])==null?void 0:Mo.doOperations)==null?void 0:Bo[0])==null?void 0:Do.id)||((Oo=Pt==null?void 0:Pt[0])==null?void 0:Oo.id);return Zt&&(await zt(Zt,{[ie]:"true"}),Ht.setBlockAttrOverride(Zt,{[ie]:"true"}),Bi(Zt,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),Zt}async function Yt(){try{await Vt(),vt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(q){vt.showMessage("插入讲稿备注块失败"),console.error(q)}}function ee(){const q=W.value;if(!q){vt.showMessage("未找到本页关联的讲稿备注块");return}Bi(q,e==null?void 0:e.app)?vt.showMessage("已在编辑区定位讲稿备注块"):vt.showMessage("定位讲稿备注块失败")}async function Nt(){if(!c.value)return;const q=j.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};vt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const lt=await Ar(q,Sr);if(lt.notes){const yt=W.value;if(yt){const At=`> [!NOTE] 💡 演讲备注
${lt.notes.split(/\r?\n/).map(_t=>`> ${_t}`).join(`
`)}
{: custom-slidev-note="true"}`;await Po("markdown",At,yt),await zt(yt,{[ie]:"true"}),Ht.setBlockAttrOverride(yt,{[ie]:"true"}),Bi(yt,e==null?void 0:e.app)}else await Vt(lt.notes);lt.isAiGenerated?vt.showMessage("思源 AI 演讲提词卡生成成功！"):vt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function Ge(){ct.value?G(Ce,""):G(Ce,"+1")}function te(q){G(Ce,q)}function Jt(q){G(We,q)}function vi(q){(o.value[Tt]||"")===q?G(Tt,""):G(Tt,q)}function Oi(q){J.value=q,G($i,q)}function vs(q){gt.value=q,G(dn,q)}async function bs(){const q=Y.value==="three-cols-header";await G(Tt,q?"col-1":"left"),vt.showMessage(q?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function En(){const q=r.value;if(!q)return;const lt={[Ce]:"",[We]:"",[Tt]:"",[$i]:"",[dn]:"",[ie]:"","slidev-note":"",[ft]:"",[qt]:"",[Xt]:"",[Ut]:"",[Ee]:"",[yi]:"",[Bn]:"",[Li]:"",[Dn]:""};if(se(q,lt),await zt(q,lt),Ht.clearBlockAttrOverride(q),typeof document<"u"){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`),At=yt==null?void 0:yt.closest('[data-type="NodeListItem"]'),_t=At==null?void 0:At.getAttribute("data-node-id");_t&&_t!==q&&(se(_t,lt),await zt(_t,lt).catch(()=>{}),Ht.clearBlockAttrOverride(_t))}o.value={},J.value="",gt.value="",z.value="",Q.value="",vt.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function bi(q){it(ln,q)}function Pi(q){it(an,q)}function ea(q){it(cn,q)}async function ia(){if(r.value)try{await sn("markdown","---",r.value,void 0),vt.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function Ao(){const q=r.value||c.value;if(q)try{await sn("markdown","---",void 0,q),vt.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function na(){if(r.value)try{await ba(r.value),vt.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{vt.showMessage("删除失败")}}function To(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function sa(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function oa(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function ra(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const q=Zl(u.value);Yl("presentation.html",q)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function la(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(u.value)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(q){r.value=q.id,l.value=q.type,o.value={...q.attrs},a.value=q.content||q.markdown||"",d.value=q.topBlockId||q.id,h.value=q.pageDividerId||"",g.value=q.pageDividerLayout||"",q.rootId?c.value=q.rootId:(q.type==="doc"||q.type==="NodeDocument")&&q.id&&(c.value=q.id),z.value=q.attrs[Ut]||"",Q.value=q.attrs[Ee]||"",J.value=q.attrs[$i]||"",gt.value=q.attrs[dn]||"",x.value=!!q.isImage},updateDocument(q){u.value=q,c.value=q.docId},openImportDialog(){s.value=!0},setCurrentDocId(q){c.value=q}}),(q,lt)=>(et(),nt("div",Nv,[m("div",Fv,[m("div",jv,[(et(),nt("svg",Hv,[...lt[2]||(lt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),lt[3]||(lt[3]=m("span",null,"演示配置",-1))]),m("div",Uv,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:lt[0]||(lt[0]=yt=>s.value=!0)},[pt(kt,{name:"import"}),lt[4]||(lt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:To},[pt(kt,{name:"split-preview"}),lt[5]||(lt[5]=m("span",null,"分屏预览",-1))])])]),m("div",Wv,[m("div",Vv,[m("span",{class:Et(["spm-target-tag",T.value])},St(X.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":p.value||"点击复制 ID: "+(r.value||c.value),onClick:y},[pt(kt,{name:"copy"}),m("span",null,"#"+St(D.value),1)],8,Kv)]),k.value?(et(),nt("span",qv,"● "+St(k.value),1)):Ft("",!0)]),R.value?(et(),nt("div",{key:0,class:"spm-context-quote",title:a.value},St(R.value),9,Gv)):Ft("",!0),m("div",Zv,[S.value?(et(),Be(Gh,{key:0,"page-layout":O.value,"page-transition":w.value,"page-background":z.value,"page-image":Q.value,"page-notes":at.value,"page-index":V.value,"onUpdate:pageLayout":tt,"onUpdate:pageTransition":ut,"onUpdate:pageBackground":xt,"onUpdate:pageImage":bt,onAddNoteBlock:Yt,onLocateNoteBlock:ee,onGenerateNotes:Nt,onInsertDividerAfter:Ao,onDeleteDivider:na},null,8,["page-layout","page-transition","page-background","page-image","page-notes","page-index"])):r.value&&!E.value?(et(),Be(mg,{key:1,"elem-click":ct.value,"elem-motion":rt.value,"elem-slot":st.value,"elem-shiki-lines":J.value,"elem-max-height":gt.value,"is-code-block":I.value,"is-image":C.value,"is-video":A.value,"video-autoplay":mt.value,"video-loop":Z.value,"video-muted":ot.value,"video-controls":dt.value,"has-block-attrs":U.value,"is-note":N.value,"image-role":B.value,"current-slide-layout":Y.value,onToggleNote:Mt,onToggleElemClick:Ge,onToggleVideoAutoplay:M,onToggleVideoLoop:L,onToggleVideoMuted:f,onToggleVideoControls:F,"onUpdate:imageRole":K,"onUpdate:elemClick":te,"onUpdate:elemMotion":Jt,"onUpdate:elemSlot":vi,"onUpdate:elemShikiLines":Oi,"onUpdate:elemMaxHeight":vs,onInsertDividerBefore:ia,onInsertDividerAfter:Ao,onSetTwoColsContrast:bs,onClearBlockAttrs:En},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(et(),Be(Hg,{key:2,"doc-theme":P.value,"doc-aspect-ratio":_.value,"doc-default-transition":$.value,"onUpdate:docTheme":bi,"onUpdate:docAspectRatio":Pi,"onUpdate:docDefaultTransition":ea,onOpenBottomPreview:To,onOpenPresenter:sa,onAiAutoSplit:oa,onExportHtml:ra,onExportPdf:la},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition"]))]),s.value?(et(),Be(zv,{key:1,onClose:lt[1]||(lt[1]=yt=>s.value=!1),onSuccess:n})):Ft("",!0)]))}}),Tn=new Co;let fi=null,Ke=null;function Jv(t,i){fi&&Ql(),fi=jl(kh),fi.provide("plugin",i),fi.provide("sandboxBridge",Tn);const e=fi.mount(t);return Ke=e,e}function Ql(t){fi&&(fi.unmount(),fi=null,Ke=null)}let pi=null,ve=null;function Xv(t,i){pi&&ta(),pi=jl(Yv),pi.provide("plugin",i),pi.provide("sandboxBridge",Tn);const e=pi.mount(t);return ve=e,e}function ta(t){pi&&(pi.unmount(),pi=null,ve=null)}function Qv(t,i){ve!=null&&ve.updateDocument&&ve.updateDocument(t),Ke!=null&&Ke.updateDocument?Ke.updateDocument(t,i):Tn.updateSlides(t.slides,t.config,t.fullMarkdown)}function Os(t){Ke!=null&&Ke.navigateToBlock?Ke.navigateToBlock(t):Tn.highlightElement(t)}function jn(t){ve!=null&&ve.setActiveBlock&&ve.setActiveBlock(t)}function tb(){return ve!=null&&ve.openImportDialog?(ve.openImportDialog(),!0):!1}const eb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Si,value:"true"},{key:ft,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Si,value:"true"},{key:ft,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Si,value:"true"},{key:ft,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Si,value:"true"},{key:ft,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Si,value:"true"},{key:ft,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ce,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ce,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:$i,value:"1-3"}]}];class Ps{getPresetTemplates(){return eb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[Xt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}const ib=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,nb="slidev-dock",wr="slidev-preview-tab",xr=wp;class sb extends vt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new eo);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=vt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(ib),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{tb()||vt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const n=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(n==null?void 0:n.getAttribute("data-doc-id"))||""}this.currentDocId&&(await zt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}const n=await qn(this.currentDocId).catch(()=>[]);if(!n||n.length===0){vt.showMessage("当前文档无内容，无需断页");return}const r=n.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=_a(r);if(l.length===0){vt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}vt.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await sn("markdown","---",void 0,a.blockId),await zt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}vt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var h,g,u,k;if(!this.currentDocId){const p=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(p==null?void 0:p.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}vt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const n=await qn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:n.map(p=>({id:p.id,type:p.type,content:p.content||"",rawMarkdown:p.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await Sa(r,Sr)).split(/\r?\n/).map(p=>`> ${p}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await _r("markdown",a,this.currentDocId).catch(()=>null),d=((u=(g=(h=c==null?void 0:c[0])==null?void 0:h.doOperations)==null?void 0:g[0])==null?void 0:u.id)||((k=c==null?void 0:c[0])==null?void 0:k.id);d&&(await zt(d,{"custom-slidev-note":"true"}),Ht.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Bi(d,this.app)),vt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const n=new Ps,r=n.buildTransitionStatsSql(),l=await vn(r).catch(()=>[]),o=n.formatTransitionSummary(l||[]);vt.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Ps().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),vt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):vt.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Ps().batchUpdateTransitions("fade","slide-left",l=>vn(l).catch(()=>[]),(l,o)=>zt(l,o));vt.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&vt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{vt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?vt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):vt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}const n=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Ls);n.success?vt.showMessage(`已成功同步最新 slides.md 至工作空间：${n.path}`):vt.showMessage(`同步失败：${n.error}`)}});const s=this;if(this.addTab({type:wr,init(){Jv(this.element,s)},destroy(){Ql(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:nb,init(){Xv(this.element,s)},destroy(){ta(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const n=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(xr),s=xp(e);return qi(s),s}catch{return qi(Ji),Ji}}async saveGlobalSettings(e){const s=Io(),n=qi({...s,...e||{}});try{await this.saveData(xr,n)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Tn.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await vt.openTab({app:this.app,custom:{id:this.name+wr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const s=e.detail,n=s==null?void 0:s.menu,r=((l=s==null?void 0:s.data)==null?void 0:l.id)||this.currentDocId;!n||!r||n.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await zt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await zt(r,{"custom-slidev-theme":"default"}),vt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await zt(r,{"custom-slidev-theme":"seriph"}),vt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await zt(r,{"custom-slidev-theme":"apple-basic"}),vt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"16/9"}),vt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"4/3"}),vt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const s=(r=e.detail)==null?void 0:r.protyle,n=(l=s==null?void 0:s.block)==null?void 0:l.rootID;if(n&&n!==this.currentDocId){this.currentDocId=n,this.activeCursorBlockId=n;const o=await Ye(n).catch(()=>({}));jn({id:n,rootId:n,type:"doc",attrs:o}),this.compileCurrentDocument(n)}}onClickEditorContent(e){var r,l;const s=e==null?void 0:e.detail;if(!s)return;const n=(l=(r=s.protyle)==null?void 0:r.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),s=e==null?void 0:e.getAttribute("data-node-id");if(s)return s;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),r=n==null?void 0:n.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const s=e.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,s){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let n=s||"";if(!n&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ye(e).catch(()=>({}));jn({id:e,rootId:e,type:"doc",content:n,attrs:r,isDivider:!1,isCode:!1}),Os(e)}onWsMain(e){const s=e.detail;if(s){if(s.cmd==="transactions"&&Array.isArray(s.data)){for(const n of s.data)if(Array.isArray(n==null?void 0:n.doOperations)){for(const r of n.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");se(r.id,a),Ht.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,s){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const n=Bi(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const h=this.latestCompiledDoc.slides.find(g=>{var u,k,p;return g.startBlockId===e||((u=g.blocks)==null?void 0:u.some(b=>b.id===e))||((k=g.allBlockIds)==null?void 0:k.includes(e))||((p=g.noteBlocks)==null?void 0:p.some(b=>b.id===e))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(d=h.frontmatter.layout)}Ye(e).then(async h=>{if(c&&!d){const g=Ht.getBlockAttrOverride(c);if(g!=null&&g[ft]||g!=null&&g["custom-slidev-layout"])d=g[ft]||g["custom-slidev-layout"]||"";else{const u=await Ye(c).catch(()=>({}))||{};d=u[ft]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Ht.setBlockAttrOverride(c,u)}}jn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return n}onBlockClickedFromSlide(e){const s=(e==null?void 0:e.detail)||e;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(e){const s=e.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const h=n||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=h==null?void 0:h.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Os(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const s=e.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const r=n.closest(".protyle-title");if(!!(r||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const h=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=h==null?void 0:h.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Os(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,s,n){var T,O,w,z,Q,j,at,W,Y,V;let r=e,l=s,o=n;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const N=a.getAttribute("data-node-id");if(N){const ct=await Ye(N).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(N)||{},st={...ct,...rt};(st[ie]||st["slidev-note"])&&(r=a,l=N,o="NodeCallout")}}const c=o==="NodeThematicBreak",d=o==="NodeCodeBlock",h=((T=r.innerText)==null?void 0:T.trim())||"",g=await Ye(l).catch(()=>({}))||{},u=Ht.getBlockAttrOverride(l)||{},k={...g,...u},p=r.closest(".protyle-wysiwyg > [data-node-id]")||r,b=(p==null?void 0:p.getAttribute("data-node-id"))||l;let v="",y="",S=p.previousElementSibling;for(;S;){const N=S.getAttribute("data-type");if(N==="NodeThematicBreak"||N==="tb"||(O=S.classList)!=null&&O.contains("hr")){v=S.getAttribute("data-node-id")||"";break}S=S.previousElementSibling}if((w=this.latestCompiledDoc)!=null&&w.slides){const N=[l,b];let ct=r.parentElement;for(;ct&&!ct.classList.contains("protyle-wysiwyg");){const st=ct.getAttribute("data-node-id");st&&!N.includes(st)&&N.push(st),ct=ct.parentElement}const rt=this.latestCompiledDoc.slides.find(st=>{var J,gt,mt;return N.includes(st.startBlockId)||((J=st.blocks)==null?void 0:J.some(Z=>N.includes(Z.id)))||((gt=st.allBlockIds)==null?void 0:gt.some(Z=>N.includes(Z)))||((mt=st.noteBlocks)==null?void 0:mt.some(Z=>N.includes(Z.id)))});rt&&(!v&&rt.startBlockId&&(v=rt.startBlockId),!y&&((z=rt.frontmatter)!=null&&z.layout)&&(y=rt.frontmatter.layout))}if(v){const N=Ht.getBlockAttrOverride(v);if(N&&(ft in N||"custom-slidev-layout"in N)&&(y=N[ft]||N["custom-slidev-layout"]||""),!y&&((Q=this.latestCompiledDoc)!=null&&Q.slides)){const ct=this.latestCompiledDoc.slides.find(rt=>rt.startBlockId===v);(j=ct==null?void 0:ct.frontmatter)!=null&&j.layout&&(y=ct.frontmatter.layout)}if(!y){const ct=await Ye(v).catch(()=>({}))||{};y=ct[ft]||ct["custom-slidev-layout"]||"",ct&&Object.keys(ct).length>0&&Ht.setBlockAttrOverride(v,ct)}se(v,{[ft]:y||""})}else if(this.currentDocId){const N=Ht.getBlockAttrOverride(this.currentDocId);N&&(ft in N||"custom-slidev-layout"in N)?y=N[ft]||N["custom-slidev-layout"]||"":!y&&((V=(Y=(W=(at=this.latestCompiledDoc)==null?void 0:at.slides)==null?void 0:W[0])==null?void 0:Y.frontmatter)!=null&&V.layout)&&(y=this.latestCompiledDoc.slides[0].frontmatter.layout)}const I=r.getAttribute(ft)||r.getAttribute("custom-slidev-layout"),x=k[ft]||k["custom-slidev-layout"]||"";I&&I!==x&&se(l,{[ft]:x});const C=r.getAttribute(qt)||r.getAttribute("custom-slidev-role"),A=k[qt]||k["custom-slidev-role"]||"";C&&C!==A&&se(l,{[qt]:A});const E=r.closest('[data-type="NodeListItem"]');if(E&&E!==r){const N=E.getAttribute("data-node-id");if(N){const ct=await Ye(N).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(N)||{},st={...ct,...rt},J=st[ft]||st["custom-slidev-layout"]||"",gt=E.getAttribute(ft)||E.getAttribute("custom-slidev-layout");gt&&gt!==J&&se(N,{[ft]:J});const mt=st[qt]||st["custom-slidev-role"]||"",Z=E.getAttribute(qt)||E.getAttribute("custom-slidev-role");Z&&Z!==mt&&se(N,{[qt]:mt})}}const D=!!r.querySelector("img, span[data-type='img']"),R=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),X=D&&R.length<=50;jn({id:l,rootId:this.currentDocId,type:o,content:h,attrs:k,isDivider:c,isCode:d,isImage:X,topBlockId:b,pageDividerId:v,pageDividerLayout:y})}async compileCurrentDocument(e){var n,r,l,o;let s=e||this.currentDocId;if(!s){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((n=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:n.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,s=c;else return}try{const a=await Ht.compile(s);this.latestCompiledDoc=a,Qv(a,s),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const s=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=s.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ft]=a.frontmatter.layout),s.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=s.get(c.id)||{};(l=c.ial)!=null&&l[ft]&&(d[ft]=c.ial[ft]),(o=c.ial)!=null&&o[qt]&&(d[qt]=c.ial[qt]),Object.keys(d).length>0&&s.set(c.id,d)}}}const n=Ht.getAllAttrOverrides();for(const[a,c]of n.entries()){const d=s.get(a)||{};c[ft]!==void 0&&(d[ft]=c[ft]),c[qt]!==void 0&&(d[qt]=c[qt]),s.set(a,d)}Mf(s)}}module.exports=sb;
