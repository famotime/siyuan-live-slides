"use strict";var $d=Object.defineProperty;var Td=(e,t,o)=>t in e?$d(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var Ie=(e,t,o)=>Td(e,typeof t!="symbol"?t+"":t,o);const ie=require("siyuan");async function Lt(e,t){const o=await ie.fetchSyncPost(e,t);return o.code===0?o.data:null}async function Ad(){return Lt("/api/notebook/lsNotebooks","")}async function Md(e,t,o){return Lt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Fa(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return Lt("/api/asset/upload",o)}async function ho(e,t,o,i,n){return Lt("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function bn(e,t,o){return Lt("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function Ms(e,t,o){return Lt("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Qs(e){return Lt("/api/block/deleteBlock",{id:e})}async function Dr(e){return Lt("/api/transactions",{reqId:Date.now(),transactions:e})}async function Ed(e){return Lt("/api/block/getBlockKramdown",{id:e})}async function Si(e){return Lt("/api/block/getChildBlocks",{id:e})}async function Bd(e){return Lt("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return Lt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function er(e){return Lt("/api/attr/getBlockAttrs",{id:e})}async function vi(e){return Lt("/api/query/sql",{stmt:e})}async function ja(e,t="GET",o={},i=[],n=15e3,s="application/json"){const a=await ie.fetchSyncPost("/api/network/forwardProxy",{url:e,method:t,timeout:n,contentType:s,headers:i,payload:o});if(!a||a.code!==0){const r=(a==null?void 0:a.msg)||"思源内核代理转发请求失败";throw new Error(r)}return a.data}async function Ld(){return Lt("/api/storage/getInlineStyles","")}function Nr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Ua(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],a=n[2]??n[3]??n[4]??"";t[s]=a}return t}const Wa=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Dd(e){const t=[];if(!e)return t;const o=new RegExp(Wa.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function Nd(e,t){if(!e)return"";const o=new RegExp(Wa.source,"g");return e.replace(o,(i,n,s,a,r)=>{const l=(s??a??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=l||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Vi="custom-slides-theme",Ki="custom-slides-aspect-ratio",Gi="custom-slides-default-transition",qa="custom-slides-color-schema",Es="custom-slides-spacing",An="custom-slides-background",Or="custom-slides-show-unordered-list-markers",Pr="custom-slides-show-ordered-list-markers",mo="custom-slides-slide",be="custom-slides-layout",Ct="custom-slides-transition",ct="custom-slides-background",qt="custom-slides-image",ls="custom-slides-notes",li="custom-slides-class",Oi="custom-slides-spacing",yt="custom-slides-layout-ratio",ci="custom-slides-mask",Jo="custom-slides-mask-ratio",di="custom-slides-mask-style",ui="custom-slides-mask-initial",Ne="custom-slides-click",Et="custom-slides-motion",ei="custom-slides-shiki-lines",Te="custom-slides-slot",Fe="custom-slides-note",Ze="custom-slides-role",Yi="custom-slides-max-height",Yo="custom-slides-autoplay",Mn="custom-slides-loop",ai="custom-slides-muted",En="custom-slides-controls",Va="background",Bn="image-left",Ln="image-right";function fi(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Od(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(p=>parseFloat(p.trim())).filter(p=>!isNaN(p)&&p>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const p=Math.min(100,Math.max(1,s[0]));return p===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(p*100)/100,100]}}const a=s.every((p,d)=>d===0||p>s[d-1]),r=s[s.length-1];if(a&&(r===100||s.some(p=>p>10))){const p=s.map(d=>Math.min(100,Math.round(d*100)/100));return p[p.length-1]<100&&p.push(100),{steps:p.length,breakpoints:p}}const c=s.reduce((p,d)=>p+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const f=[];for(let p=0;p<s.length;p++)u+=s[p],p===s.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function Ka(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ga(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Nt(e,t){if(!Ka(e))return e;const o=Ga(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function Pd(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const a=Nt(s,t);return`![${n}](${a})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,a)=>{const r=Nt(s,t);return`${n}${r}${a}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,a)=>{const r=Nt(s,t);return`${n}${r}${a}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function tr(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Je={},hi=[],so=()=>{},Ya=()=>!1,Wn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),qn=e=>e.startsWith("onUpdate:"),vt=Object.assign,or=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},Rd=Object.prototype.hasOwnProperty,Ue=(e,t)=>Rd.call(e,t),Me=Array.isArray,pi=e=>on(e)==="[object Map]",Ci=e=>on(e)==="[object Set]",Rr=e=>on(e)==="[object Date]",Le=e=>typeof e=="function",st=e=>typeof e=="string",Yt=e=>typeof e=="symbol",Ke=e=>e!==null&&typeof e=="object",Za=e=>(Ke(e)||Le(e))&&Le(e.then)&&Le(e.catch),Ja=Object.prototype.toString,on=e=>Ja.call(e),zd=e=>on(e).slice(8,-1),Xa=e=>on(e)==="[object Object]",ir=e=>st(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Pi=tr(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Vn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},Hd=/-\w/g,Bt=Vn(e=>e.replace(Hd,t=>t.slice(1).toUpperCase())),Fd=/\B([A-Z])/g,Wo=Vn(e=>e.replace(Fd,"-$1").toLowerCase()),Kn=Vn(e=>e.charAt(0).toUpperCase()+e.slice(1)),cs=Vn(e=>e?`on${Kn(e)}`:""),oo=(e,t)=>!Object.is(e,t),vn=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Qa=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},Gn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let zr;const Yn=()=>zr||(zr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function io(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=st(i)?qd(i):io(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(st(e)||Ke(e))return e}const jd=/;(?![^(]*\))/g,Ud=/:([^]+)/,Wd=/\/\*[^]*?\*\//g;function qd(e){const t={};return e.replace(Wd,"").split(jd).forEach(o=>{if(o){const i=o.split(Ud);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(st(e))t=e;else if(Me(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(Ke(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const Vd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Kd=tr(Vd);function el(e){return!!e||e===""}function Gd(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=_i(e[i],t[i]);return o}function _i(e,t){if(e===t)return!0;let o=Rr(e),i=Rr(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Yt(e),i=Yt(t),o||i)return e===t;if(o=Me(e),i=Me(t),o||i)return o&&i?Gd(e,t):!1;if(o=Ke(e),i=Ke(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!_i(e[a],t[a]))return!1}}return String(e)===String(t)}function nr(e,t){return e.findIndex(o=>_i(o,t))}const tl=e=>!!(e&&e.__v_isRef===!0),ve=e=>st(e)?e:e==null?"":Me(e)||Ke(e)&&(e.toString===Ja||!Le(e.toString))?tl(e)?ve(e.value):JSON.stringify(e,ol,2):String(e),ol=(e,t)=>tl(t)?ol(e,t.value):pi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[ds(i,s)+" =>"]=n,o),{})}:Ci(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>ds(o))}:Yt(t)?ds(t):Ke(t)&&!Me(t)&&!Xa(t)?String(t):t,ds=(e,t="")=>{var o;return Yt(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let gt;class Yd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&gt&&(gt.active?(this.parent=gt,this.index=(gt.scopes||(gt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=gt;try{return gt=this,t()}finally{gt=o}}}on(){++this._on===1&&(this.prevScope=gt,gt=this)}off(){if(this._on>0&&--this._on===0){if(gt===this)gt=this.prevScope;else{let t=gt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Zd(){return gt}let Xe;const us=new WeakSet;class il{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,gt&&(gt.active?gt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,us.has(this)&&(us.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||sl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Hr(this),rl(this);const t=Xe,o=Kt;Xe=this,Kt=!0;try{return this.fn()}finally{al(this),Xe=t,Kt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)ar(t);this.deps=this.depsTail=void 0,Hr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?us.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Bs(this)&&this.run()}get dirty(){return Bs(this)}}let nl=0,Ri,zi;function sl(e,t=!1){if(e.flags|=8,t){e.next=zi,zi=e;return}e.next=Ri,Ri=e}function sr(){nl++}function rr(){if(--nl>0)return;if(zi){let t=zi;for(zi=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;Ri;){let t=Ri;for(Ri=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function rl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function al(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),ar(i),Jd(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function Bs(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(ll(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function ll(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Zi)||(e.globalVersion=Zi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!Bs(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=Kt;Xe=e,Kt=!0;try{rl(e);const n=e.fn(e._value);(t.version===0||oo(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,Kt=i,al(e),e.flags&=-3}}function ar(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)ar(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Jd(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let Kt=!0;const cl=[];function So(){cl.push(Kt),Kt=!1}function Co(){const e=cl.pop();Kt=e===void 0?!0:e}function Hr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let Zi=0;class Xd{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class lr{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!Kt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new Xd(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,dl(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,Zi++,this.notify(t)}notify(t){sr();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{rr()}}}function dl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)dl(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const Ls=new WeakMap,Xo=Symbol(""),Ds=Symbol(""),Ji=Symbol("");function xt(e,t,o){if(Kt&&Xe){let i=Ls.get(e);i||Ls.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new lr),n.map=i,n.key=o),n.track()}}function go(e,t,o,i,n,s){const a=Ls.get(e);if(!a){Zi++;return}const r=l=>{l&&l.trigger()};if(sr(),t==="clear")a.forEach(r);else{const l=Me(e),c=l&&ir(o);if(l&&o==="length"){const u=Number(i);a.forEach((f,p)=>{(p==="length"||p===Ji||!Yt(p)&&p>=u)&&r(f)})}else switch((o!==void 0||a.has(void 0))&&r(a.get(o)),c&&r(a.get(Ji)),t){case"add":l?c&&r(a.get("length")):(r(a.get(Xo)),pi(e)&&r(a.get(Ds)));break;case"delete":l||(r(a.get(Xo)),pi(e)&&r(a.get(Ds)));break;case"set":pi(e)&&r(a.get(Xo));break}}rr()}function ii(e){const t=je(e);return t===e?t:(xt(t,"iterate",Ji),Ut(e)?t:t.map(Zt))}function Zn(e){return xt(e=je(e),"iterate",Ji),e}function eo(e,t){return _o(e)?ki(Qo(e)?Zt(t):t):Zt(t)}const Qd={__proto__:null,[Symbol.iterator](){return fs(this,Symbol.iterator,e=>eo(this,e))},concat(...e){return ii(this).concat(...e.map(t=>Me(t)?ii(t):t))},entries(){return fs(this,"entries",e=>(e[1]=eo(this,e[1]),e))},every(e,t){return uo(this,"every",e,t,void 0,arguments)},filter(e,t){return uo(this,"filter",e,t,o=>o.map(i=>eo(this,i)),arguments)},find(e,t){return uo(this,"find",e,t,o=>eo(this,o),arguments)},findIndex(e,t){return uo(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return uo(this,"findLast",e,t,o=>eo(this,o),arguments)},findLastIndex(e,t){return uo(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return uo(this,"forEach",e,t,void 0,arguments)},includes(...e){return hs(this,"includes",e)},indexOf(...e){return hs(this,"indexOf",e)},join(e){return ii(this).join(e)},lastIndexOf(...e){return hs(this,"lastIndexOf",e)},map(e,t){return uo(this,"map",e,t,void 0,arguments)},pop(){return Mi(this,"pop")},push(...e){return Mi(this,"push",e)},reduce(e,...t){return Fr(this,"reduce",e,t)},reduceRight(e,...t){return Fr(this,"reduceRight",e,t)},shift(){return Mi(this,"shift")},some(e,t){return uo(this,"some",e,t,void 0,arguments)},splice(...e){return Mi(this,"splice",e)},toReversed(){return ii(this).toReversed()},toSorted(e){return ii(this).toSorted(e)},toSpliced(...e){return ii(this).toSpliced(...e)},unshift(...e){return Mi(this,"unshift",e)},values(){return fs(this,"values",e=>eo(this,e))}};function fs(e,t,o){const i=Zn(e),n=i[t]();return i!==e&&!Ut(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const eu=Array.prototype;function uo(e,t,o,i,n,s){const a=Zn(e),r=a!==e&&!Ut(e),l=a[t];if(l!==eu[t]){const f=l.apply(e,s);return r?Zt(f):f}let c=o;a!==e&&(r?c=function(f,p){return o.call(this,eo(e,f),p,e)}:o.length>2&&(c=function(f,p){return o.call(this,f,p,e)}));const u=l.call(a,c,i);return r&&n?n(u):u}function Fr(e,t,o,i){const n=Zn(e),s=n!==e&&!Ut(e);let a=o,r=!1;n!==e&&(s?(r=i.length===0,a=function(c,u,f){return r&&(r=!1,c=eo(e,c)),o.call(this,c,eo(e,u),f,e)}):o.length>3&&(a=function(c,u,f){return o.call(this,c,u,f,e)}));const l=n[t](a,...i);return r?eo(e,l):l}function hs(e,t,o){const i=je(e);xt(i,"iterate",Ji);const n=i[t](...o);return(n===-1||n===!1)&&ur(o[0])?(o[0]=je(o[0]),i[t](...o)):n}function Mi(e,t,o=[]){So(),sr();const i=je(e)[t].apply(e,o);return rr(),Co(),i}const tu=tr("__proto__,__v_isRef,__isVue"),ul=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Yt));function ou(e){Yt(e)||(e=String(e));const t=je(this);return xt(t,"has",e),t.hasOwnProperty(e)}class fl{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?fu:gl:s?ml:pl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const a=Me(t);if(!n){let l;if(a&&(l=Qd[o]))return l;if(o==="hasOwnProperty")return ou}const r=Reflect.get(t,o,ot(t)?t:i);if((Yt(o)?ul.has(o):tu(o))||(n||xt(t,"get",o),s))return r;if(ot(r)){const l=a&&ir(o)?r:r.value;return n&&Ke(l)?Os(l):l}return Ke(r)?n?Os(r):Jn(r):r}}class hl extends fl{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const a=Me(t)&&ir(o);if(!this._isShallow){const c=_o(s);if(!Ut(i)&&!_o(i)&&(s=je(s),i=je(i)),!a&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=a?Number(o)<t.length:Ue(t,o),l=Reflect.set(t,o,i,ot(t)?t:n);return t===je(n)&&l&&(r?oo(i,s)&&go(t,"set",o,i):go(t,"add",o,i)),l}deleteProperty(t,o){const i=Ue(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&go(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Yt(o)||!ul.has(o))&&xt(t,"has",o),i}ownKeys(t){return xt(t,"iterate",Me(t)?"length":Xo),Reflect.ownKeys(t)}}class iu extends fl{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const nu=new hl,su=new iu,ru=new hl(!0);const Ns=e=>e,dn=e=>Reflect.getPrototypeOf(e);function au(e,t,o){return function(...i){const n=this.__v_raw,s=je(n),a=pi(s),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=n[e](...i),u=o?Ns:t?ki:Zt;return!t&&xt(s,"iterate",l?Ds:Xo),vt(Object.create(c),{next(){const{value:f,done:p}=c.next();return p?{value:f,done:p}:{value:r?[u(f[0]),u(f[1])]:u(f),done:p}}})}}function un(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function lu(e,t){const o={get(n){const s=this.__v_raw,a=je(s),r=je(n);e||(oo(n,r)&&xt(a,"get",n),xt(a,"get",r));const{has:l}=dn(a),c=t?Ns:e?ki:Zt;if(l.call(a,n))return c(s.get(n));if(l.call(a,r))return c(s.get(r));s!==a&&s.get(n)},get size(){const n=this.__v_raw;return!e&&xt(je(n),"iterate",Xo),n.size},has(n){const s=this.__v_raw,a=je(s),r=je(n);return e||(oo(n,r)&&xt(a,"has",n),xt(a,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const a=this,r=a.__v_raw,l=je(r),c=t?Ns:e?ki:Zt;return!e&&xt(l,"iterate",Xo),r.forEach((u,f)=>n.call(s,c(u),c(f),a))}};return vt(o,e?{add:un("add"),set:un("set"),delete:un("delete"),clear:un("clear")}:{add(n){const s=je(this),a=dn(s),r=je(n),l=!t&&!Ut(n)&&!_o(n)?r:n;return a.has.call(s,l)||oo(n,l)&&a.has.call(s,n)||oo(r,l)&&a.has.call(s,r)||(s.add(l),go(s,"add",l,l)),this},set(n,s){!t&&!Ut(s)&&!_o(s)&&(s=je(s));const a=je(this),{has:r,get:l}=dn(a);let c=r.call(a,n);c||(n=je(n),c=r.call(a,n));const u=l.call(a,n);return a.set(n,s),c?oo(s,u)&&go(a,"set",n,s):go(a,"add",n,s),this},delete(n){const s=je(this),{has:a,get:r}=dn(s);let l=a.call(s,n);l||(n=je(n),l=a.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return l&&go(s,"delete",n,void 0),c},clear(){const n=je(this),s=n.size!==0,a=n.clear();return s&&go(n,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=au(n,e,t)}),o}function cr(e,t){const o=lu(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(Ue(o,n)&&n in i?o:i,n,s)}const cu={get:cr(!1,!1)},du={get:cr(!1,!0)},uu={get:cr(!0,!1)};const pl=new WeakMap,ml=new WeakMap,gl=new WeakMap,fu=new WeakMap;function hu(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Jn(e){return _o(e)?e:dr(e,!1,nu,cu,pl)}function pu(e){return dr(e,!1,ru,du,ml)}function Os(e){return dr(e,!0,su,uu,gl)}function dr(e,t,o,i,n){if(!Ke(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const a=hu(zd(e));if(a===0)return e;const r=new Proxy(e,a===2?i:o);return n.set(e,r),r}function Qo(e){return _o(e)?Qo(e.__v_raw):!!(e&&e.__v_isReactive)}function _o(e){return!!(e&&e.__v_isReadonly)}function Ut(e){return!!(e&&e.__v_isShallow)}function ur(e){return e?!!e.__v_raw:!1}function je(e){const t=e&&e.__v_raw;return t?je(t):e}function mu(e){return!Ue(e,"__v_skip")&&Object.isExtensible(e)&&Qa(e,"__v_skip",!0),e}const Zt=e=>Ke(e)?Jn(e):e,ki=e=>Ke(e)?Os(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function pe(e){return gu(e,!1)}function gu(e,t){return ot(e)?e:new yu(e,t)}class yu{constructor(t,o){this.dep=new lr,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:je(t),this._value=o?t:Zt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||Ut(t)||_o(t);t=i?t:je(t),oo(t,o)&&(this._rawValue=t,this._value=i?t:Zt(t),this.dep.trigger())}}function ue(e){return ot(e)?e.value:e}const bu={get:(e,t,o)=>t==="__v_raw"?e:ue(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function yl(e){return Qo(e)?e:new Proxy(e,bu)}class vu{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new lr(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Zi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return sl(this,!0),!0}get value(){const t=this.dep.track();return ll(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function ku(e,t,o=!1){let i,n;return Le(e)?i=e:(i=e.get,n=e.set),new vu(i,n,o)}const fn={},Dn=new WeakMap;let Go;function wu(e,t=!1,o=Go){if(o){let i=Dn.get(o);i||Dn.set(o,i=[]),i.push(e)}}function xu(e,t,o=Je){const{immediate:i,deep:n,once:s,scheduler:a,augmentJob:r,call:l}=o,c=_=>n?_:Ut(_)||n===!1||n===0?yo(_,1):yo(_);let u,f,p,d,b=!1,m=!1;if(ot(e)?(f=()=>e.value,b=Ut(e)):Qo(e)?(f=()=>c(e),b=!0):Me(e)?(m=!0,b=e.some(_=>Qo(_)||Ut(_)),f=()=>e.map(_=>{if(ot(_))return _.value;if(Qo(_))return c(_);if(Le(_))return l?l(_,2):_()})):Le(e)?t?f=l?()=>l(e,2):e:f=()=>{if(p){So();try{p()}finally{Co()}}const _=Go;Go=u;try{return l?l(e,3,[d]):e(d)}finally{Go=_}}:f=so,t&&n){const _=f,T=n===!0?1/0:n;f=()=>yo(_(),T)}const y=Zd(),g=()=>{u.stop(),y&&y.active&&or(y.effects,u)};if(s&&t){const _=t;t=(...T)=>{const k=_(...T);return g(),k}}let v=m?new Array(e.length).fill(fn):fn;const x=_=>{if(!(!(u.flags&1)||!u.dirty&&!_))if(t){const T=u.run();if(_||n||b||(m?T.some((k,C)=>oo(k,v[C])):oo(T,v))){p&&p();const k=Go;Go=u;try{const C=[T,v===fn?void 0:m&&v[0]===fn?[]:v,d];v=T,l?l(t,3,C):t(...C)}finally{Go=k}}}else u.run()};return r&&r(x),u=new il(f),u.scheduler=a?()=>a(x,!1):x,d=_=>wu(_,!1,u),p=u.onStop=()=>{const _=Dn.get(u);if(_){if(l)l(_,4);else for(const T of _)T();Dn.delete(u)}},t?i?x(!0):v=u.run():a?a(x.bind(null,!0),!0):u.run(),g.pause=u.pause.bind(u),g.resume=u.resume.bind(u),g.stop=g,g}function yo(e,t=1/0,o){if(t<=0||!Ke(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))yo(e.value,t,o);else if(Me(e))for(let i=0;i<e.length;i++)yo(e[i],t,o);else if(Ci(e)||pi(e))e.forEach(i=>{yo(i,t,o)});else if(Xa(e)){for(const i in e)yo(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&yo(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function nn(e,t,o,i){try{return i?e(...i):e()}catch(n){Xn(n,t,o)}}function Jt(e,t,o,i){if(Le(e)){const n=nn(e,t,o,i);return n&&Za(n)&&n.catch(s=>{Xn(s,t,o)}),n}if(Me(e)){const n=[];for(let s=0;s<e.length;s++)n.push(Jt(e[s],t,o,i));return n}}function Xn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,l,c)===!1)return}r=r.parent}if(s){So(),nn(s,null,10,[e,l,c]),Co();return}}Su(e,o,n,i,a)}function Su(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const Mt=[];let Qt=-1;const mi=[];let Bo=null,si=0;const bl=Promise.resolve();let Nn=null;function On(e){const t=Nn||bl;return e?t.then(this?e.bind(this):e):t}function Cu(e){let t=Qt+1,o=Mt.length;for(;t<o;){const i=t+o>>>1,n=Mt[i],s=Xi(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function fr(e){if(!(e.flags&1)){const t=Xi(e),o=Mt[Mt.length-1];!o||!(e.flags&2)&&t>=Xi(o)?Mt.push(e):Mt.splice(Cu(t),0,e),e.flags|=1,vl()}}function vl(){Nn||(Nn=bl.then(wl))}function _u(e){Me(e)?mi.push(...e):Bo&&e.id===-1?Bo.splice(si+1,0,e):e.flags&1||(mi.push(e),e.flags|=1),vl()}function jr(e,t,o=Qt+1){for(;o<Mt.length;o++){const i=Mt[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;Mt.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function kl(e){if(mi.length){const t=[...new Set(mi)].sort((o,i)=>Xi(o)-Xi(i));if(mi.length=0,Bo){Bo.push(...t);return}for(Bo=t,si=0;si<Bo.length;si++){const o=Bo[si];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}Bo=null,si=0}}const Xi=e=>e.id==null?e.flags&2?-1:1/0:e.id;function wl(e){try{for(Qt=0;Qt<Mt.length;Qt++){const t=Mt[Qt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),nn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Qt<Mt.length;Qt++){const t=Mt[Qt];t&&(t.flags&=-2)}Qt=-1,Mt.length=0,kl(),Nn=null,(Mt.length||mi.length)&&wl()}}let bt=null,xl=null;function Pn(e){const t=bt;return bt=e,xl=e&&e.type.__scopeId||null,t}function Sl(e,t=bt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&ea(-1);const s=Pn(t),a=ko.length;let r;try{r=e(...n)}finally{for(let l=ko.length;l>a;l--)yr();Pn(s),i._d&&ea(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Wt(e,t){if(bt===null)return e;const o=os(bt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,a,r,l=Je]=t[n];s&&(Le(s)&&(s={mounted:s,updated:s}),s.deep&&yo(a),i.push({dir:s,instance:o,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function qo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let a=0;a<n.length;a++){const r=n[a];s&&(r.oldValue=s[a].value);let l=r.dir[i];l&&(So(),Jt(l,o,8,[e.el,r,e,t]),Co())}}function Iu(e,t){if(It){let o=It.provides;const i=It.parent&&It.parent.provides;i===o&&(o=It.provides=Object.create(i)),o[e]=t}}function Gt(e,t,o=!1){const i=_f();if(i||yi){let n=yi?yi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&Le(t)?t.call(i&&i.proxy):t}}const $u=Symbol.for("v-scx"),Tu=()=>Gt($u);function Ho(e,t,o){return Cl(e,t,o)}function Cl(e,t,o=Je){const{immediate:i,deep:n,flush:s,once:a}=o,r=vt({},o),l=t&&i||!t&&s!=="post";let c;if(en){if(s==="sync"){const d=Tu();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!l){const d=()=>{};return d.stop=so,d.resume=so,d.pause=so,d}}const u=It;r.call=(d,b,m)=>Jt(d,u,b,m);let f=!1;s==="post"?r.scheduler=d=>{Dt(d,u&&u.suspense)}:s!=="sync"&&(f=!0,r.scheduler=(d,b)=>{b?d():fr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),f&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const p=xu(e,t,r);return en&&(c?c.push(p):l&&p()),p}function Au(e,t,o){const i=this.proxy,n=st(e)?e.includes(".")?_l(i,e):()=>i[e]:e.bind(i,i);let s;Le(t)?s=t:(s=t.handler,o=t);const a=rn(this),r=Cl(n,s.bind(i),o);return a(),r}function _l(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const Mu=Symbol("_vte"),Eu=e=>e.__isTeleport,ps=Symbol("_leaveCb");function hr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,hr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Ht(e,t){return Le(e)?vt({name:e.name},t,{setup:e}):e}function Il(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Ur(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const Rn=new WeakMap;function Hi(e,t,o,i,n=!1){if(Me(e)){e.forEach((m,y)=>Hi(m,t&&(Me(t)?t[y]:t),o,i,n));return}if(gi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Hi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?os(i.component):i.el,a=n?null:s,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,f=r.setupState,p=je(f),d=f===Je?Ya:m=>Ur(u,m)?!1:Ue(p,m),b=(m,y)=>!(y&&Ur(u,y));if(c!=null&&c!==l){if(Wr(t),st(c))u[c]=null,d(c)&&(f[c]=null);else if(ot(c)){const m=t;b(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Le(l))nn(l,r,12,[a,u]);else{const m=st(l),y=ot(l);if(m||y){const g=()=>{if(e.f){const v=m?d(l)?f[l]:u[l]:b()||!e.k?l.value:u[e.k];if(n)Me(v)&&or(v,s);else if(Me(v))v.includes(s)||v.push(s);else if(m)u[l]=[s],d(l)&&(f[l]=u[l]);else{const x=[s];b(l,e.k)&&(l.value=x),e.k&&(u[e.k]=x)}}else m?(u[l]=a,d(l)&&(f[l]=a)):y&&(b(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const v=()=>{g(),Rn.delete(e)};v.id=-1,Rn.set(e,v),Dt(v,o)}else Wr(e),g()}}}function Wr(e){const t=Rn.get(e);t&&(t.flags|=8,Rn.delete(e))}Yn().requestIdleCallback;Yn().cancelIdleCallback;const gi=e=>!!e.type.__asyncLoader,$l=e=>e.type.__isKeepAlive;function Bu(e,t){Tl(e,"a",t)}function Lu(e,t){Tl(e,"da",t)}function Tl(e,t,o=It){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Qn(t,i,o),o){let n=o.parent;for(;n&&n.parent;)$l(n.parent.vnode)&&Du(i,t,o,n),n=n.parent}}function Du(e,t,o,i){const n=Qn(t,e,i,!0);sn(()=>{or(i[t],n)},o)}function Qn(e,t,o=It,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...a)=>{So();const r=rn(o),l=Jt(t,o,e,a);return r(),Co(),l});return i?n.unshift(s):n.push(s),s}}const $o=e=>(t,o=It)=>{(!en||e==="sp")&&Qn(e,(...i)=>t(...i),o)},Nu=$o("bm"),ti=$o("m"),Ou=$o("bu"),Pu=$o("u"),pr=$o("bum"),sn=$o("um"),Ru=$o("sp"),zu=$o("rtg"),Hu=$o("rtc");function Fu(e,t=It){Qn("ec",e,t)}const ju="components";function Uu(e,t){return qu(ju,e,!0,t)||e}const Wu=Symbol.for("v-ndc");function qu(e,t,o=!0,i=!1){const n=bt||It;if(n){const s=n.type;{const r=Mf(s,!1);if(r&&(r===t||r===Bt(t)||r===Kn(Bt(t))))return s}const a=qr(n[e]||s[e],t)||qr(n.appContext[e],t);return!a&&i?s:a}}function qr(e,t){return e&&(e[t]||e[Bt(t)]||e[Kn(Bt(t))])}function _t(e,t,o,i){let n;const s=o,a=Me(e);if(a||st(e)){const r=a&&Qo(e);let l=!1,c=!1;r&&(l=!Ut(e),c=_o(e),e=Zn(e)),n=new Array(e.length);for(let u=0,f=e.length;u<f;u++)n[u]=t(l?c?ki(Zt(e[u])):Zt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(Ke(e))if(e[Symbol.iterator])n=Array.from(e,(r,l)=>t(r,l,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];n[l]=t(e[u],u,l,s)}}else n=[];return n}function hn(e,t,o={},i,n,s){if(bt.ce||bt.parent&&gi(bt.parent)&&bt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Vt(Ve,null,[le("slot",c,i&&i())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=ko.length;J();let l;try{const c=a&&Al(a(o)),u=o.key||s||c&&c.key;l=Vt(Ve,{key:(u&&!Yt(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=ko.length;u>r;u--)yr();throw c}finally{a&&a._c&&(a._d=!0)}return l}function Al(e){return e.some(t=>br(t)?!(t.type===Io||t.type===Ve&&!Al(t.children)):!0)?e:null}const Ps=e=>e?Yl(e)?os(e):Ps(e.parent):null,Fi=vt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ps(e.parent),$root:e=>Ps(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>El(e),$forceUpdate:e=>e.f||(e.f=()=>{fr(e.update)}),$nextTick:e=>e.n||(e.n=On.bind(e.proxy)),$watch:e=>Au.bind(e)}),ms=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ue(e,t),Vu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const p=a[t];if(p!==void 0)switch(p){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(ms(i,t))return a[t]=1,i[t];if(n!==Je&&Ue(n,t))return a[t]=2,n[t];if(Ue(s,t))return a[t]=3,s[t];if(o!==Je&&Ue(o,t))return a[t]=4,o[t];Rs&&(a[t]=0)}}const c=Fi[t];let u,f;if(c)return t==="$attrs"&&xt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Je&&Ue(o,t))return a[t]=4,o[t];if(f=l.config.globalProperties,Ue(f,t))return f[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return ms(n,t)?(n[t]=o,!0):i!==Je&&Ue(i,t)?(i[t]=o,!0):Ue(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:a}},r){let l;return!!(o[r]||e!==Je&&r[0]!=="$"&&Ue(e,r)||ms(t,r)||Ue(s,r)||Ue(i,r)||Ue(Fi,r)||Ue(n.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:Ue(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function Vr(e){return Me(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let Rs=!0;function Ku(e){const t=El(e),o=e.proxy,i=e.ctx;Rs=!1,t.beforeCreate&&Kr(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:f,mounted:p,beforeUpdate:d,updated:b,activated:m,deactivated:y,beforeDestroy:g,beforeUnmount:v,destroyed:x,unmounted:_,render:T,renderTracked:k,renderTriggered:C,errorCaptured:D,serverPrefetch:P,expose:R,inheritAttrs:j,components:B,directives:N,filters:S}=t;if(c&&Gu(c,i,null),a)for(const $ in a){const M=a[$];Le(M)&&(i[$]=M.bind(o))}if(n){const $=n.call(o,o);Ke($)&&(e.data=Jn($))}if(Rs=!0,s)for(const $ in s){const M=s[$],E=Le(M)?M.bind(o,o):Le(M.get)?M.get.bind(o,o):so,Q=!Le(M)&&Le(M.set)?M.set.bind(o):so,F=ye({get:E,set:Q});Object.defineProperty(i,$,{enumerable:!0,configurable:!0,get:()=>F.value,set:V=>F.value=V})}if(r)for(const $ in r)Ml(r[$],i,o,$);if(l){const $=Le(l)?l.call(o):l;Reflect.ownKeys($).forEach(M=>{Iu(M,$[M])})}u&&Kr(u,e,"c");function W($,M){Me(M)?M.forEach(E=>$(E.bind(o))):M&&$(M.bind(o))}if(W(Nu,f),W(ti,p),W(Ou,d),W(Pu,b),W(Bu,m),W(Lu,y),W(Fu,D),W(Hu,k),W(zu,C),W(pr,v),W(sn,_),W(Ru,P),Me(R))if(R.length){const $=e.exposed||(e.exposed={});R.forEach(M=>{Object.defineProperty($,M,{get:()=>o[M],set:E=>o[M]=E,enumerable:!0})})}else e.exposed||(e.exposed={});T&&e.render===so&&(e.render=T),j!=null&&(e.inheritAttrs=j),B&&(e.components=B),N&&(e.directives=N),P&&Il(e)}function Gu(e,t,o=so){Me(e)&&(e=zs(e));for(const i in e){const n=e[i];let s;Ke(n)?"default"in n?s=Gt(n.from||i,n.default,!0):s=Gt(n.from||i):s=Gt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:a=>s.value=a}):t[i]=s}}function Kr(e,t,o){Jt(Me(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function Ml(e,t,o,i){let n=i.includes(".")?_l(o,i):()=>o[i];if(st(e)){const s=t[e];Le(s)&&Ho(n,s)}else if(Le(e))Ho(n,e.bind(o));else if(Ke(e))if(Me(e))e.forEach(s=>Ml(s,t,o,i));else{const s=Le(e.handler)?e.handler.bind(o):t[e.handler];Le(s)&&Ho(n,s,e)}}function El(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:a}}=e.appContext,r=s.get(t);let l;return r?l=r:!n.length&&!o&&!i?l=t:(l={},n.length&&n.forEach(c=>zn(l,c,a,!0)),zn(l,t,a)),Ke(t)&&s.set(t,l),l}function zn(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&zn(e,s,o,!0),n&&n.forEach(a=>zn(e,a,o,!0));for(const a in t)if(!(i&&a==="expose")){const r=Yu[a]||o&&o[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Yu={data:Gr,props:Yr,emits:Yr,methods:Li,computed:Li,beforeCreate:At,created:At,beforeMount:At,mounted:At,beforeUpdate:At,updated:At,beforeDestroy:At,beforeUnmount:At,destroyed:At,unmounted:At,activated:At,deactivated:At,errorCaptured:At,serverPrefetch:At,components:Li,directives:Li,watch:Ju,provide:Gr,inject:Zu};function Gr(e,t){return t?e?function(){return vt(Le(e)?e.call(this,this):e,Le(t)?t.call(this,this):t)}:t:e}function Zu(e,t){return Li(zs(e),zs(t))}function zs(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function At(e,t){return e?[...new Set([].concat(e,t))]:t}function Li(e,t){return e?vt(Object.create(null),e,t):t}function Yr(e,t){return e?Me(e)&&Me(t)?[...new Set([...e,...t])]:vt(Object.create(null),Vr(e),Vr(t??{})):t}function Ju(e,t){if(!e)return t;if(!t)return e;const o=vt(Object.create(null),e);for(const i in t)o[i]=At(e[i],t[i]);return o}function Bl(){return{app:null,config:{isNativeTag:Ya,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Xu=0;function Qu(e,t){return function(i,n=null){Le(i)||(i=vt({},i)),n!=null&&!Ke(n)&&(n=null);const s=Bl(),a=new WeakSet,r=[];let l=!1;const c=s.app={_uid:Xu++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:Bf,get config(){return s.config},set config(u){},use(u,...f){return a.has(u)||(u&&Le(u.install)?(a.add(u),u.install(c,...f)):Le(u)&&(a.add(u),u(c,...f))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,f){return f?(s.components[u]=f,c):s.components[u]},directive(u,f){return f?(s.directives[u]=f,c):s.directives[u]},mount(u,f,p){if(!l){const d=c._ceVNode||le(i,n);return d.appContext=s,p===!0?p="svg":p===!1&&(p=void 0),e(d,u,p),l=!0,c._container=u,u.__vue_app__=c,os(d.component)}},onUnmount(u){r.push(u)},unmount(){l&&(Jt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return s.provides[u]=f,c},runWithContext(u){const f=yi;yi=c;try{return u()}finally{yi=f}}};return c}}let yi=null;const ef=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Bt(t)}Modifiers`]||e[`${Wo(t)}Modifiers`];function tf(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Je;let n=o;const s=t.startsWith("update:"),a=s&&ef(i,t.slice(7));a&&(a.trim&&(n=o.map(u=>st(u)?u.trim():u)),a.number&&(n=o.map(Gn)));let r,l=i[r=cs(t)]||i[r=cs(Bt(t))];!l&&s&&(l=i[r=cs(Wo(t))]),l&&Jt(l,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Jt(c,e,6,n)}}const of=new WeakMap;function Ll(e,t,o=!1){const i=o?of:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let a={},r=!1;if(!Le(e)){const l=c=>{const u=Ll(c,t,!0);u&&(r=!0,vt(a,u))};!o&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!s&&!r?(Ke(e)&&i.set(e,null),null):(Me(s)?s.forEach(l=>a[l]=null):vt(a,s),Ke(e)&&i.set(e,a),a)}function es(e,t){return!e||!Wn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ue(e,t[0].toLowerCase()+t.slice(1))||Ue(e,Wo(t))||Ue(e,t))}function Zr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:f,data:p,setupState:d,ctx:b,inheritAttrs:m}=e,y=Pn(e);let g,v;try{if(o.shapeFlag&4){const _=n||i,T=_;g=to(c.call(T,_,u,f,d,p,b)),v=r}else{const _=t;g=to(_.length>1?_(f,{attrs:r,slots:a,emit:l}):_(f,null)),v=t.props?r:nf(r)}}catch(_){ko.length=0,Xn(_,e,1),g=le(Io)}let x=g;if(v&&m!==!1){const _=Object.keys(v),{shapeFlag:T}=x;_.length&&T&7&&(s&&_.some(qn)&&(v=sf(v,s)),x=wi(x,v,!1,!0))}return o.dirs&&(x=wi(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(o.dirs):o.dirs),o.transition&&hr(x,o.transition),g=x,Pn(y),g}const nf=e=>{let t;for(const o in e)(o==="class"||o==="style"||Wn(o))&&((t||(t={}))[o]=e[o]);return t},sf=(e,t)=>{const o={};for(const i in e)(!qn(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function rf(e,t,o){const{props:i,children:n,component:s}=e,{props:a,children:r,patchFlag:l}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&l>=0){if(l&1024)return!0;if(l&16)return i?Jr(i,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const p=u[f];if(Dl(a,i,p)&&!es(c,p))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===a?!1:i?a?Jr(i,a,c):!0:!!a;return!1}function Jr(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(Dl(t,e,s)&&!es(o,s))return!0}return!1}function Dl(e,t,o){const i=e[o],n=t[o];return o==="style"&&Ke(i)&&Ke(n)?!_i(i,n):i!==n}function af({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const Nl={},Ol=()=>Object.create(Nl),Pl=e=>Object.getPrototypeOf(e)===Nl;function lf(e,t,o,i=!1){const n={},s=Ol();e.propsDefaults=Object.create(null),Rl(e,t,n,s);for(const a in e.propsOptions[0])a in n||(n[a]=void 0);o?e.props=i?n:pu(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function cf(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:a}}=e,r=je(n),[l]=e.propsOptions;let c=!1;if((i||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let p=u[f];if(es(e.emitsOptions,p))continue;const d=t[p];if(l)if(Ue(s,p))d!==s[p]&&(s[p]=d,c=!0);else{const b=Bt(p);n[b]=Hs(l,r,b,d,e,!1)}else d!==s[p]&&(s[p]=d,c=!0)}}}else{Rl(e,t,n,s)&&(c=!0);let u;for(const f in r)(!t||!Ue(t,f)&&((u=Wo(f))===f||!Ue(t,u)))&&(l?o&&(o[f]!==void 0||o[u]!==void 0)&&(n[f]=Hs(l,r,f,void 0,e,!0)):delete n[f]);if(s!==r)for(const f in s)(!t||!Ue(t,f))&&(delete s[f],c=!0)}c&&go(e.attrs,"set","")}function Rl(e,t,o,i){const[n,s]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Pi(l))continue;const c=t[l];let u;n&&Ue(n,u=Bt(l))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:es(e.emitsOptions,l)||(!(l in i)||c!==i[l])&&(i[l]=c,a=!0)}if(s){const l=je(o),c=r||Je;for(let u=0;u<s.length;u++){const f=s[u];o[f]=Hs(n,l,f,c[f],e,!Ue(c,f))}}return a}function Hs(e,t,o,i,n,s){const a=e[o];if(a!=null){const r=Ue(a,"default");if(r&&i===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Le(l)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=rn(n);i=c[o]=l.call(null,t),u()}}else i=l;n.ce&&n.ce._setProp(o,i)}a[0]&&(s&&!r?i=!1:a[1]&&(i===""||i===Wo(o))&&(i=!0))}return i}const df=new WeakMap;function zl(e,t,o=!1){const i=o?df:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,a={},r=[];let l=!1;if(!Le(e)){const u=f=>{l=!0;const[p,d]=zl(f,t,!0);vt(a,p),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!l)return Ke(e)&&i.set(e,hi),hi;if(Me(s))for(let u=0;u<s.length;u++){const f=Bt(s[u]);Xr(f)&&(a[f]=Je)}else if(s)for(const u in s){const f=Bt(u);if(Xr(f)){const p=s[u],d=a[f]=Me(p)||Le(p)?{type:p}:vt({},p),b=d.type;let m=!1,y=!0;if(Me(b))for(let g=0;g<b.length;++g){const v=b[g],x=Le(v)&&v.name;if(x==="Boolean"){m=!0;break}else x==="String"&&(y=!1)}else m=Le(b)&&b.name==="Boolean";d[0]=m,d[1]=y,(m||Ue(d,"default"))&&r.push(f)}}const c=[a,r];return Ke(e)&&i.set(e,c),c}function Xr(e){return e[0]!=="$"&&!Pi(e)}const mr=e=>e==="_"||e==="_ctx"||e==="$stable",gr=e=>Me(e)?e.map(to):[to(e)],uf=(e,t,o)=>{if(t._n)return t;const i=Sl((...n)=>gr(t(...n)),o);return i._c=!1,i},Hl=(e,t,o)=>{const i=e._ctx;for(const n in e){if(mr(n))continue;const s=e[n];if(Le(s))t[n]=uf(n,s,i);else if(s!=null){const a=gr(s);t[n]=()=>a}}},Fl=(e,t)=>{const o=gr(t);e.slots.default=()=>o},jl=(e,t,o)=>{for(const i in t)(o||!mr(i))&&(e[i]=t[i])},ff=(e,t,o)=>{const i=e.slots=Ol();if(e.vnode.shapeFlag&32){const n=t._;n?(jl(i,t,o),o&&Qa(i,"_",n,!0)):Hl(t,i)}else t&&Fl(e,t)},hf=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,a=Je;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:jl(n,t,o):(s=!t.$stable,Hl(t,n)),a=t}else t&&(Fl(e,t),a={default:1});if(s)for(const r in n)!mr(r)&&a[r]==null&&delete n[r]},Dt=bf;function pf(e){return mf(e)}function mf(e,t){const o=Yn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:f,nextSibling:p,setScopeId:d=so,insertStaticContent:b}=e,m=(L,U,w,q=null,H=null,I=null,A=void 0,O=null,G=!!U.dynamicChildren)=>{if(L===U)return;L&&!Ei(L,U)&&(q=$e(L),V(L,H,I,!0),L=null),U.patchFlag===-2&&(G=!1,U.dynamicChildren=null);const{type:K,ref:Y,shapeFlag:ee}=U;switch(K){case ts:y(L,U,w,q);break;case Io:g(L,U,w,q);break;case kn:L==null&&v(U,w,q,A);break;case Ve:B(L,U,w,q,H,I,A,O,G);break;default:ee&1?T(L,U,w,q,H,I,A,O,G):ee&6?N(L,U,w,q,H,I,A,O,G):(ee&64||ee&128)&&K.process(L,U,w,q,H,I,A,O,G,z)}Y!=null&&H?Hi(Y,L&&L.ref,I,U||L,!U):Y==null&&L&&L.ref!=null&&Hi(L.ref,null,I,L,!0)},y=(L,U,w,q)=>{if(L==null)i(U.el=r(U.children),w,q);else{const H=U.el=L.el;U.children!==L.children&&c(H,U.children)}},g=(L,U,w,q)=>{L==null?i(U.el=l(U.children||""),w,q):U.el=L.el},v=(L,U,w,q)=>{[L.el,L.anchor]=b(L.children,U,w,q,L.el,L.anchor)},x=({el:L,anchor:U},w,q)=>{let H;for(;L&&L!==U;)H=p(L),i(L,w,q),L=H;i(U,w,q)},_=({el:L,anchor:U})=>{let w;for(;L&&L!==U;)w=p(L),n(L),L=w;n(U)},T=(L,U,w,q,H,I,A,O,G)=>{if(U.type==="svg"?A="svg":U.type==="math"&&(A="mathml"),L==null)k(U,w,q,H,I,A,O,G);else{const K=L.el&&L.el._isVueCE?L.el:null;try{K&&K._beginPatch(),P(L,U,H,I,A,O,G)}finally{K&&K._endPatch()}}},k=(L,U,w,q,H,I,A,O)=>{let G,K;const{props:Y,shapeFlag:ee,transition:ce,dirs:se}=L;if(G=L.el=a(L.type,I,Y&&Y.is,Y),ee&8?u(G,L.children):ee&16&&D(L.children,G,null,q,H,gs(L,I),A,O),se&&qo(L,null,q,"created"),C(G,L,L.scopeId,A,q),Y){for(const _e in Y)_e!=="value"&&!Pi(_e)&&s(G,_e,null,Y[_e],I,q);"value"in Y&&s(G,"value",null,Y.value,I),(K=Y.onVnodeBeforeMount)&&Xt(K,q,L)}se&&qo(L,null,q,"beforeMount");const me=gf(H,ce);me&&ce.beforeEnter(G),i(G,U,w),((K=Y&&Y.onVnodeMounted)||me||se)&&Dt(()=>{try{K&&Xt(K,q,L),me&&ce.enter(G),se&&qo(L,null,q,"mounted")}finally{}},H)},C=(L,U,w,q,H)=>{if(w&&d(L,w),q)for(let I=0;I<q.length;I++)d(L,q[I]);if(H){let I=H.subTree;if(U===I||Vl(I.type)&&(I.ssContent===U||I.ssFallback===U)){const A=H.vnode;C(L,A,A.scopeId,A.slotScopeIds,H.parent)}}},D=(L,U,w,q,H,I,A,O,G=0)=>{for(let K=G;K<L.length;K++){const Y=L[K]=O?po(L[K]):to(L[K]);m(null,Y,U,w,q,H,I,A,O)}},P=(L,U,w,q,H,I,A)=>{const O=U.el=L.el;let{patchFlag:G,dynamicChildren:K,dirs:Y}=U;G|=L.patchFlag&16;const ee=L.props||Je,ce=U.props||Je;let se;if(w&&Vo(w,!1),(se=ce.onVnodeBeforeUpdate)&&Xt(se,w,U,L),Y&&qo(U,L,w,"beforeUpdate"),w&&Vo(w,!0),K&&(!L.dynamicChildren||L.dynamicChildren.length!==K.length)&&(G=0,A=!1,K=null),(ee.innerHTML&&ce.innerHTML==null||ee.textContent&&ce.textContent==null)&&u(O,""),K?R(L.dynamicChildren,K,O,w,q,gs(U,H),I):A||M(L,U,O,null,w,q,gs(U,H),I,!1),G>0){if(G&16)j(O,ee,ce,w,H);else if(G&2&&ee.class!==ce.class&&s(O,"class",null,ce.class,H),G&4&&s(O,"style",ee.style,ce.style,H),G&8){const me=U.dynamicProps;for(let _e=0;_e<me.length;_e++){const we=me[_e],De=ee[we],He=ce[we];(He!==De||we==="value")&&s(O,we,De,He,H,w)}}G&1&&L.children!==U.children&&u(O,U.children)}else!A&&K==null&&j(O,ee,ce,w,H);((se=ce.onVnodeUpdated)||Y)&&Dt(()=>{se&&Xt(se,w,U,L),Y&&qo(U,L,w,"updated")},q)},R=(L,U,w,q,H,I,A)=>{for(let O=0;O<U.length;O++){const G=L[O],K=U[O],Y=G.el&&(G.type===Ve||!Ei(G,K)||G.shapeFlag&198)?f(G.el):w;m(G,K,Y,null,q,H,I,A,!0)}},j=(L,U,w,q,H)=>{if(U!==w){if(U!==Je)for(const I in U)!Pi(I)&&!(I in w)&&s(L,I,U[I],null,H,q);for(const I in w){if(Pi(I))continue;const A=w[I],O=U[I];A!==O&&I!=="value"&&s(L,I,O,A,H,q)}"value"in w&&s(L,"value",U.value,w.value,H)}},B=(L,U,w,q,H,I,A,O,G)=>{const K=U.el=L?L.el:r(""),Y=U.anchor=L?L.anchor:r("");let{patchFlag:ee,dynamicChildren:ce,slotScopeIds:se}=U;se&&(O=O?O.concat(se):se),L==null?(i(K,w,q),i(Y,w,q),D(U.children||[],w,Y,H,I,A,O,G)):ee>0&&ee&64&&ce&&L.dynamicChildren&&L.dynamicChildren.length===ce.length?(R(L.dynamicChildren,ce,w,H,I,A,O),(U.key!=null||H&&U===H.subTree)&&Ul(L,U,!0)):M(L,U,w,Y,H,I,A,O,G)},N=(L,U,w,q,H,I,A,O,G)=>{U.slotScopeIds=O,L==null?U.shapeFlag&512?H.ctx.activate(U,w,q,A,G):S(U,w,q,H,I,A,G):Z(L,U,G)},S=(L,U,w,q,H,I,A)=>{const O=L.component=Cf(L,q,H);if($l(L)&&(O.ctx.renderer=z),If(O,!1,A),O.asyncDep){if(H&&H.registerDep(O,W,A),!L.el){const G=O.subTree=le(Io);g(null,G,U,w),L.placeholder=G.el}}else W(O,L,U,w,H,I,A)},Z=(L,U,w)=>{const q=U.component=L.component;if(rf(L,U,w))if(q.asyncDep&&!q.asyncResolved){$(q,U,w);return}else q.next=U,q.update();else U.el=L.el,q.vnode=U},W=(L,U,w,q,H,I,A)=>{const O=()=>{if(L.isMounted){let{next:ee,bu:ce,u:se,parent:me,vnode:_e}=L;{const rt=Wl(L);if(rt){ee&&(ee.el=_e.el,$(L,ee,A)),rt.asyncDep.then(()=>{Dt(()=>{L.isUnmounted||K()},H)});return}}let we=ee,De;Vo(L,!1),ee?(ee.el=_e.el,$(L,ee,A)):ee=_e,ce&&vn(ce),(De=ee.props&&ee.props.onVnodeBeforeUpdate)&&Xt(De,me,ee,_e),Vo(L,!0);const He=Zr(L),Ge=L.subTree;L.subTree=He,m(Ge,He,f(Ge.el),$e(Ge),L,H,I),ee.el=He.el,we===null&&af(L,He.el),se&&Dt(se,H),(De=ee.props&&ee.props.onVnodeUpdated)&&Dt(()=>Xt(De,me,ee,_e),H)}else{let ee;const{el:ce,props:se}=U,{bm:me,m:_e,parent:we,root:De,type:He}=L,Ge=gi(U);Vo(L,!1),me&&vn(me),!Ge&&(ee=se&&se.onVnodeBeforeMount)&&Xt(ee,we,U),Vo(L,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(He,L.parent?L.parent.type:void 0);const rt=L.subTree=Zr(L);m(null,rt,w,q,L,H,I),U.el=rt.el}if(_e&&Dt(_e,H),!Ge&&(ee=se&&se.onVnodeMounted)){const rt=U;Dt(()=>Xt(ee,we,rt),H)}(U.shapeFlag&256||we&&gi(we.vnode)&&we.vnode.shapeFlag&256)&&L.a&&Dt(L.a,H),L.isMounted=!0,U=w=q=null}};L.scope.on();const G=L.effect=new il(O);L.scope.off();const K=L.update=G.run.bind(G),Y=L.job=G.runIfDirty.bind(G);Y.i=L,Y.id=L.uid,G.scheduler=()=>fr(Y),Vo(L,!0),K()},$=(L,U,w)=>{U.component=L;const q=L.vnode.props;L.vnode=U,L.next=null,cf(L,U.props,q,w),hf(L,U.children,w),So(),jr(L),Co()},M=(L,U,w,q,H,I,A,O,G=!1)=>{const K=L&&L.children,Y=L?L.shapeFlag:0,ee=U.children,{patchFlag:ce,shapeFlag:se}=U;if(ce>0){if(ce&128){Q(K,ee,w,q,H,I,A,O,G);return}else if(ce&256){E(K,ee,w,q,H,I,A,O,G);return}}se&8?(Y&16&&Se(K,H,I),ee!==K&&u(w,ee)):Y&16?se&16?Q(K,ee,w,q,H,I,A,O,G):Se(K,H,I,!0):(Y&8&&u(w,""),se&16&&D(ee,w,q,H,I,A,O,G))},E=(L,U,w,q,H,I,A,O,G)=>{L=L||hi,U=U||hi;const K=L.length,Y=U.length,ee=Math.min(K,Y);let ce;for(ce=0;ce<ee;ce++){const se=U[ce]=G?po(U[ce]):to(U[ce]);m(L[ce],se,w,null,H,I,A,O,G)}K>Y?Se(L,H,I,!0,!1,ee):D(U,w,q,H,I,A,O,G,ee)},Q=(L,U,w,q,H,I,A,O,G)=>{let K=0;const Y=U.length;let ee=L.length-1,ce=Y-1;for(;K<=ee&&K<=ce;){const se=L[K],me=U[K]=G?po(U[K]):to(U[K]);if(Ei(se,me))m(se,me,w,null,H,I,A,O,G);else break;K++}for(;K<=ee&&K<=ce;){const se=L[ee],me=U[ce]=G?po(U[ce]):to(U[ce]);if(Ei(se,me))m(se,me,w,null,H,I,A,O,G);else break;ee--,ce--}if(K>ee){if(K<=ce){const se=ce+1,me=se<Y?U[se].el:q;for(;K<=ce;)m(null,U[K]=G?po(U[K]):to(U[K]),w,me,H,I,A,O,G),K++}}else if(K>ce)for(;K<=ee;)V(L[K],H,I,!0),K++;else{const se=K,me=K,_e=new Map;for(K=me;K<=ce;K++){const tt=U[K]=G?po(U[K]):to(U[K]);tt.key!=null&&_e.set(tt.key,K)}let we,De=0;const He=ce-me+1;let Ge=!1,rt=0;const Pe=new Array(He);for(K=0;K<He;K++)Pe[K]=0;for(K=se;K<=ee;K++){const tt=L[K];if(De>=He){V(tt,H,I,!0);continue}let Ye;if(tt.key!=null)Ye=_e.get(tt.key);else for(we=me;we<=ce;we++)if(Pe[we-me]===0&&Ei(tt,U[we])){Ye=we;break}Ye===void 0?V(tt,H,I,!0):(Pe[Ye-me]=K+1,Ye>=rt?rt=Ye:Ge=!0,m(tt,U[Ye],w,null,H,I,A,O,G),De++)}const ft=Ge?yf(Pe):hi;for(we=ft.length-1,K=He-1;K>=0;K--){const tt=me+K,Ye=U[tt],fe=U[tt+1],he=tt+1<Y?fe.el||ql(fe):q;Pe[K]===0?m(null,Ye,w,he,H,I,A,O,G):Ge&&(we<0||K!==ft[we]?F(Ye,w,he,2):we--)}}},F=(L,U,w,q,H=null)=>{const{el:I,type:A,transition:O,children:G,shapeFlag:K}=L;if(K&6){F(L.component.subTree,U,w,q);return}if(K&128){L.suspense.move(U,w,q);return}if(K&64){A.move(L,U,w,z);return}if(A===Ve){i(I,U,w);for(let ee=0;ee<G.length;ee++)F(G[ee],U,w,q);i(L.anchor,U,w);return}if(A===kn){x(L,U,w);return}if(q!==2&&K&1&&O)if(q===0)O.persisted&&!I[ps]?i(I,U,w):(O.beforeEnter(I),i(I,U,w),Dt(()=>O.enter(I),H));else{const{leave:ee,delayLeave:ce,afterLeave:se}=O,me=()=>{L.ctx.isUnmounted?n(I):i(I,U,w)},_e=()=>{const we=I._isLeaving||!!I[ps];I._isLeaving&&I[ps](!0),O.persisted&&!we?me():ee(I,()=>{me(),se&&se()})};ce?ce(I,me,_e):_e()}else i(I,U,w)},V=(L,U,w,q=!1,H=!1)=>{const{type:I,props:A,ref:O,children:G,dynamicChildren:K,shapeFlag:Y,patchFlag:ee,dirs:ce,cacheIndex:se,memo:me}=L;if(ee===-2&&(H=!1),O!=null&&(So(),Hi(O,null,w,L,!0),Co()),se!=null&&(U.renderCache[se]=void 0),Y&256){U.ctx.deactivate(L);return}const _e=Y&1&&ce,we=!gi(L);let De;if(we&&(De=A&&A.onVnodeBeforeUnmount)&&Xt(De,U,L),Y&6)ae(L.component,w,q);else{if(Y&128){L.suspense.unmount(w,q);return}_e&&qo(L,null,U,"beforeUnmount"),Y&64?L.type.remove(L,U,w,z,q):K&&!K.hasOnce&&(I!==Ve||ee>0&&ee&64)?Se(K,U,w,!1,!0):(I===Ve&&ee&384||!H&&Y&16)&&Se(G,U,w),q&&re(L)}const He=me!=null&&se==null;(we&&(De=A&&A.onVnodeUnmounted)||_e||He)&&Dt(()=>{De&&Xt(De,U,L),_e&&qo(L,null,U,"unmounted"),He&&(L.el=null)},w)},re=L=>{const{type:U,el:w,anchor:q,transition:H}=L;if(U===Ve){oe(w,q);return}if(U===kn){_(L);return}const I=()=>{n(w),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(L.shapeFlag&1&&H&&!H.persisted){const{leave:A,delayLeave:O}=H,G=()=>A(w,I);O?O(L.el,I,G):G()}else I()},oe=(L,U)=>{let w;for(;L!==U;)w=p(L),n(L),L=w;n(U)},ae=(L,U,w)=>{const{bum:q,scope:H,job:I,subTree:A,um:O,m:G,a:K}=L;Qr(G),Qr(K),q&&vn(q),H.stop(),I&&(I.flags|=8,V(A,L,U,w)),O&&Dt(O,U),Dt(()=>{L.isUnmounted=!0},U)},Se=(L,U,w,q=!1,H=!1,I=0)=>{for(let A=I;A<L.length;A++)V(L[A],U,w,q,H)},$e=L=>{if(L.shapeFlag&6)return $e(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const U=p(L.anchor||L.el),w=U&&U[Mu];return w?p(w):U};let ke=!1;const Ce=(L,U,w)=>{let q;L==null?U._vnode&&(V(U._vnode,null,null,!0),q=U._vnode.component):m(U._vnode||null,L,U,null,null,null,w),U._vnode=L,ke||(ke=!0,jr(q),kl(),ke=!1)},z={p:m,um:V,m:F,r:re,mt:S,mc:D,pc:M,pbc:R,n:$e,o:e};return{render:Ce,hydrate:void 0,createApp:Qu(Ce)}}function gs({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function Vo({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function gf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ul(e,t,o=!1){const i=e.children,n=t.children;if(Me(i)&&Me(n))for(let s=0;s<i.length;s++){const a=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=po(n[s]),r.el=a.el),!o&&r.patchFlag!==-2&&Ul(a,r)),r.type===ts&&(r.patchFlag===-1&&(r=n[s]=po(r)),r.el=a.el),r.type===Io&&!r.el&&(r.el=a.el)}}function yf(e){const t=e.slice(),o=[0];let i,n,s,a,r;const l=e.length;for(i=0;i<l;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,a=o.length-1;s<a;)r=s+a>>1,e[o[r]]<c?s=r+1:a=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,a=o[s-1];s-- >0;)o[s]=a,a=t[a];return o}function Wl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Wl(t)}function Qr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ql(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ql(t.subTree):null}const Vl=e=>e.__isSuspense;function bf(e,t){t&&t.pendingBranch?Me(e)?t.effects.push(...e):t.effects.push(e):_u(e)}const Ve=Symbol.for("v-fgt"),ts=Symbol.for("v-txt"),Io=Symbol.for("v-cmt"),kn=Symbol.for("v-stc"),ko=[];let zt=null;function J(e=!1){ko.push(zt=e?null:[])}function yr(){ko.pop(),zt=ko[ko.length-1]||null}let Qi=1;function ea(e,t=!1){Qi+=e,e<0&&zt&&t&&(zt.hasOnce=!0)}function Kl(e){return e.dynamicChildren=Qi>0?zt||hi:null,yr(),Qi>0&&zt&&zt.push(e),e}function X(e,t,o,i,n,s){return Kl(h(e,t,o,i,n,s,!0))}function Vt(e,t,o,i,n){return Kl(le(e,t,o,i,n,!0))}function br(e){return e?e.__v_isVNode===!0:!1}function Ei(e,t){return e.type===t.type&&e.key===t.key}const Gl=({key:e})=>e??null,wn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?st(e)||ot(e)||Le(e)?{i:bt,r:e,k:t,f:!!o}:e:null);function h(e,t=null,o=null,i=0,n=null,s=e===Ve?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Gl(t),ref:t&&wn(t),scopeId:xl,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:bt};return r?(Hn(l,o),s&128&&e.normalize(l)):o&&(l.shapeFlag|=st(o)?8:16),Qi>0&&!a&&zt&&(l.patchFlag>0||s&6)&&l.patchFlag!==32&&zt.push(l),l}const le=vf;function vf(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===Wu)&&(e=Io),br(e)){const r=wi(e,t,!0);return o&&Hn(r,o),Qi>0&&!s&&zt&&(r.shapeFlag&6?zt[zt.indexOf(e)]=r:zt.push(r)),r.patchFlag=-2,r}if(Ef(e)&&(e=e.__vccOpts),t){t=kf(t);let{class:r,style:l}=t;r&&!st(r)&&(t.class=xe(r)),Ke(l)&&(ur(l)&&!Me(l)&&(l=vt({},l)),t.style=io(l))}const a=st(e)?1:Vl(e)?128:Eu(e)?64:Ke(e)?4:Le(e)?2:0;return h(e,t,o,i,n,a,s,!0)}function kf(e){return e?ur(e)||Pl(e)?vt({},e):e:null}function wi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:a,children:r,transition:l}=e,c=t?wf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Gl(c),ref:t&&t.ref?o&&s?Me(s)?s.concat(wn(t)):[s,wn(t)]:wn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ve?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&wi(e.ssContent),ssFallback:e.ssFallback&&wi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&i&&hr(u,l.clone(u)),u}function St(e=" ",t=0){return le(ts,null,e,t)}function ht(e,t){const o=le(kn,null,e);return o.staticCount=t,o}function Ae(e="",t=!1){return t?(J(),Vt(Io,null,e)):le(Io,null,e)}function to(e){return e==null||typeof e=="boolean"?le(Io):Me(e)?le(Ve,null,e.slice()):br(e)?po(e):le(ts,null,String(e))}function po(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:wi(e)}function Hn(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Me(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Hn(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!Pl(t)?t._ctx=bt:n===3&&bt&&(bt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Le(t)){if(i&65){Hn(e,{default:t});return}t={default:t,_ctx:bt},o=32}else t=String(t),i&64?(o=16,t=[St(t)]):o=8;e.children=t,e.shapeFlag|=o}function wf(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=io([t.style,i.style]);else if(Wn(n)){const s=t[n],a=i[n];a&&s!==a&&!(Me(s)&&s.includes(a))?t[n]=s?[].concat(s,a):a:a==null&&s==null&&!qn(n)&&(t[n]=a)}else n!==""&&(t[n]=i[n])}return t}function Xt(e,t,o,i=null){Jt(e,t,7,[o,i])}const xf=Bl();let Sf=0;function Cf(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||xf,s={uid:Sf++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Yd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:zl(i,n),emitsOptions:Ll(i,n),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:i.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=tf.bind(null,s),e.ce&&e.ce(s),s}let It=null;const _f=()=>It||bt;let Fn,Fs;{const e=Yn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(a=>a(s)):n[0](s)}};Fn=t("__VUE_INSTANCE_SETTERS__",o=>It=o),Fs=t("__VUE_SSR_SETTERS__",o=>en=o)}const rn=e=>{const t=It;return Fn(e),e.scope.on(),()=>{e.scope.off(),Fn(t)}},ta=()=>{It&&It.scope.off(),Fn(null)};function Yl(e){return e.vnode.shapeFlag&4}let en=!1;function If(e,t=!1,o=!1){t&&Fs(t);const{props:i,children:n}=e.vnode,s=Yl(e);lf(e,i,s,t),ff(e,n,o||t);const a=s?$f(e,t):void 0;return t&&Fs(!1),a}function $f(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Vu);const{setup:i}=o;if(i){So();const n=e.setupContext=i.length>1?Af(e):null,s=rn(e),a=nn(i,e,0,[e.props,n]),r=Za(a);if(Co(),s(),(r||e.sp)&&!gi(e)&&Il(e),r){if(a.then(ta,ta),t)return a.then(l=>{oa(e,l)}).catch(l=>{Xn(l,e,0)});e.asyncDep=a}else oa(e,a)}else Zl(e)}function oa(e,t,o){Le(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ke(t)&&(e.setupState=yl(t)),Zl(e)}function Zl(e,t,o){const i=e.type;e.render||(e.render=i.render||so);{const n=rn(e);So();try{Ku(e)}finally{Co(),n()}}}const Tf={get(e,t){return xt(e,"get",""),e[t]}};function Af(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,Tf),slots:e.slots,emit:e.emit,expose:t}}function os(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(yl(mu(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in Fi)return Fi[o](e)},has(t,o){return o in t||o in Fi}})):e.proxy}function Mf(e,t=!0){return Le(e)?e.displayName||e.name:e.name||t&&e.__name}function Ef(e){return Le(e)&&"__vccOpts"in e}const ye=(e,t)=>ku(e,t,en),Bf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let js;const ia=typeof window<"u"&&window.trustedTypes;if(ia)try{js=ia.createPolicy("vue",{createHTML:e=>e})}catch{}const Jl=js?e=>js.createHTML(e):e=>e,Lf="http://www.w3.org/2000/svg",Df="http://www.w3.org/1998/Math/MathML",fo=typeof document<"u"?document:null,na=fo&&fo.createElement("template"),Nf={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?fo.createElementNS(Lf,e):t==="mathml"?fo.createElementNS(Df,e):o?fo.createElement(e,{is:o}):fo.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>fo.createTextNode(e),createComment:e=>fo.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>fo.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const a=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{na.innerHTML=Jl(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=na.content;if(i==="svg"||i==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,o)}return[a?a.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},Of=Symbol("_vtc");function Pf(e,t,o){const i=e[Of];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const jn=Symbol("_vod"),Xl=Symbol("_vsh"),Us={name:"show",beforeMount(e,{value:t},{transition:o}){e[jn]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Bi(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Bi(e,!0),i.enter(e)):i.leave(e,()=>{Bi(e,!1)}):Bi(e,t))},beforeUnmount(e,{value:t}){Bi(e,t)}};function Bi(e,t){e.style.display=t?e[jn]:"none",e[Xl]=!t}const Rf=Symbol(""),zf=/(?:^|;)\s*display\s*:/;function Hf(e,t,o){const i=e.style,n=st(o);let s=!1;if(o&&!n){if(t)if(st(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();o[r]==null&&Di(i,r,"")}else for(const a in t)o[a]==null&&Di(i,a,"");for(const a in o){a==="display"&&(s=!0);const r=o[a];r!=null?jf(e,a,!st(t)&&t?t[a]:void 0,r)||Di(i,a,r):Di(i,a,"")}}else if(n){if(t!==o){const a=i[Rf];a&&(o+=";"+a),i.cssText=o,s=zf.test(o)}}else t&&e.removeAttribute("style");jn in e&&(e[jn]=s?i.display:"",e[Xl]&&(i.display="none"))}const sa=/\s*!important$/;function Di(e,t,o){if(Me(o))o.forEach(i=>Di(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=Ff(e,t);sa.test(o)?e.setProperty(Wo(i),o.replace(sa,""),"important"):e[i]=o}}const ra=["Webkit","Moz","ms"],ys={};function Ff(e,t){const o=ys[t];if(o)return o;let i=Bt(t);if(i!=="filter"&&i in e)return ys[t]=i;i=Kn(i);for(let n=0;n<ra.length;n++){const s=ra[n]+i;if(s in e)return ys[t]=s}return t}function jf(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&st(i)&&o===i}const aa="http://www.w3.org/1999/xlink";function la(e,t,o,i,n,s=Kd(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(aa,t.slice(6,t.length)):e.setAttributeNS(aa,t,o):o==null||s&&!el(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Yt(o)?String(o):o)}function ca(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Jl(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,l=o==null?e.type==="checkbox"?"on":"":String(o);(r!==l||!("_value"in e))&&(e.value=l),o==null&&e.removeAttribute(t),e._value=o;return}let a=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=el(o):o==null&&r==="string"?(o="",a=!0):r==="number"&&(o=0,a=!0)}try{e[t]=o}catch{}a&&e.removeAttribute(n||t)}function Lo(e,t,o,i){e.addEventListener(t,o,i)}function Uf(e,t,o,i){e.removeEventListener(t,o,i)}const da=Symbol("_vei");function Wf(e,t,o,i,n=null){const s=e[da]||(e[da]={}),a=s[t];if(i&&a)a.value=i;else{const[r,l]=Kf(t);if(i){const c=s[t]=Zf(i,n);Lo(e,r,c,l)}else a&&(Uf(e,r,a,l),s[t]=void 0)}}const qf=/(Once|Passive|Capture)$/,Vf=/^on:?(?:Once|Passive|Capture)$/;function Kf(e){let t,o;for(;(o=e.match(qf))&&!Vf.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Wo(e.slice(2)),t]}let bs=0;const Gf=Promise.resolve(),Yf=()=>bs||(Gf.then(()=>bs=0),bs=Date.now());function Zf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Me(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const a=n.slice(),r=[i];for(let l=0;l<a.length&&!i._stopped;l++){const c=a[l];c&&Jt(c,t,5,r)}}else Jt(n,t,5,[i])};return o.value=e,o.attached=Yf(),o}const ua=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Jf=(e,t,o,i,n,s)=>{const a=n==="svg";t==="class"?Pf(e,i,a):t==="style"?Hf(e,o,i):Wn(t)?qn(t)||Wf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Xf(e,t,i,a))?(ca(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&la(e,t,i,a,s,t!=="value")):e._isVueCE&&(Qf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!st(i)))?ca(e,Bt(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),la(e,t,i,a))};function Xf(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&ua(t)&&Le(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return ua(t)&&st(o)?!1:t in e}function Qf(e,t){const o=e._def.props;if(!o)return!1;const i=Bt(t);return Array.isArray(o)?o.some(n=>Bt(n)===i):Object.keys(o).some(n=>Bt(n)===i)}const xi=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Me(t)?o=>vn(t,o):t};function eh(e){e.target.composing=!0}function fa(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const wo=Symbol("_assign");function ha(e,t,o){return t&&(e=e.trim()),o&&(e=Gn(e)),e}const Ws={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[wo]=xi(n);const s=i||n.props&&n.props.type==="number";Lo(e,t?"change":"input",a=>{a.target.composing||e[wo](ha(e.value,o,s))}),(o||s)&&Lo(e,"change",()=>{e.value=ha(e.value,o,s)}),t||(Lo(e,"compositionstart",eh),Lo(e,"compositionend",fa),Lo(e,"change",fa))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},a){if(e[wo]=xi(a),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Gn(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===l)||(e.value=l)}},pn={deep:!0,created(e,t,o){e[wo]=xi(o),Lo(e,"change",()=>{const i=e._modelValue,n=tn(e),s=e.checked,a=e[wo];if(Me(i)){const r=nr(i,n),l=r!==-1;if(s&&!l)a(i.concat(n));else if(!s&&l){const c=[...i];c.splice(r,1),a(c)}}else if(Ci(i)){const r=new Set(i);s?r.add(n):r.delete(n),a(r)}else a(Ql(e,s))})},mounted:pa,beforeUpdate(e,t,o){e[wo]=xi(o),pa(e,t,o)}};function pa(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Me(t))n=nr(t,i.props.value)>-1;else if(Ci(t))n=t.has(i.props.value);else{if(t===o)return;n=_i(t,Ql(e,!0))}e.checked!==n&&(e.checked=n)}const th={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,Lo(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?Gn(tn(s)):tn(s));e[wo](e.multiple?Ci(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,On(()=>{e._assigning=!1})}),e[wo]=xi(i)},mounted(e,{value:t}){ma(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[wo]=xi(o)},updated(e,{value:t}){e._assigning||ma(e,t)}};function ma(e,t){const o=e.multiple,i=Me(t);if(!(o&&!i&&!Ci(t))){for(let n=0,s=e.options.length;n<s;n++){const a=e.options[n],r=tn(a);if(o)if(i){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=nr(t,r)>-1}else a.selected=t.has(r);else if(_i(tn(a),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function tn(e){return"_value"in e?e._value:e.value}function Ql(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const oh=["ctrl","shift","alt","meta"],ih={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>oh.some(o=>e[`${o}Key`]&&!t.includes(o))},no=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let a=0;a<t.length;a++){const r=ih[t[a]];if(r&&r(n,t))return}return e(n,...s)}))},nh={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},sh=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=Wo(n.key);if(t.some(a=>a===s||nh[a]===s))return e(n)}))},rh=vt({patchProp:Jf},Nf);let ga;function ah(){return ga||(ga=pf(rh))}const vr=((...e)=>{const t=ah().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=ch(i);if(!n)return;const s=t._component;!Le(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const a=o(n,!1,lh(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),a},t});function lh(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function ch(e){return st(e)?document.querySelector(e):e}const mt={baseUrl:"",apiKey:"",model:"",requestTimeoutSeconds:60,temperature:.7,maxTokens:4096},dh="slides-config.json",bo={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0,aiConfig:{...mt}},Ft=Jn({...bo}),is=pe(null);function uh(e){is.value=e}function fh(){return is.value}function bi(e){if(!e||typeof e!="object")return{...mt};const t=e;return{baseUrl:typeof t.baseUrl=="string"?t.baseUrl.trim():mt.baseUrl,apiKey:typeof t.apiKey=="string"?t.apiKey.trim():mt.apiKey,model:typeof t.model=="string"?t.model.trim():mt.model,requestTimeoutSeconds:typeof t.requestTimeoutSeconds=="number"&&t.requestTimeoutSeconds>0?Math.floor(t.requestTimeoutSeconds):mt.requestTimeoutSeconds,temperature:typeof t.temperature=="number"&&t.temperature>=0&&t.temperature<=2?Number(t.temperature.toFixed(2)):mt.temperature,maxTokens:typeof t.maxTokens=="number"&&t.maxTokens>0?Math.floor(t.maxTokens):mt.maxTokens}}function Un(e){return e?!!(typeof e.baseUrl=="string"&&e.baseUrl.trim()&&typeof e.apiKey=="string"&&e.apiKey.trim()&&typeof e.model=="string"&&e.model.trim()):!1}function kr(){const e=is.value;if(e&&Un(e))return{isManaged:!0,profileName:e.profileName,config:{baseUrl:e.baseUrl,apiKey:e.apiKey,model:e.model,requestTimeoutSeconds:e.requestTimeoutSeconds??mt.requestTimeoutSeconds,temperature:e.temperature??mt.temperature,maxTokens:e.maxTokens??mt.maxTokens,headers:e.headers}};const t=Ft.aiConfig;return Un(t)?{isManaged:!1,config:{...t}}:null}function hh(e){if(!e||typeof e!="object")return{...bo,aiConfig:{...mt}};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():bo.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:bo.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:bo.showOrderedListMarkers,aiConfig:bi(t.aiConfig)}}function pt(e){if(!e||typeof e!="object")return{...Ft};const t=e;return t.enableWebServeJump!==void 0&&(Ft.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ft.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ft.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ft.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ft.showOrderedListMarkers=!!t.showOrderedListMarkers),t.aiConfig!==void 0&&(Ft.aiConfig=bi(t.aiConfig)),{...Ft}}function Fo(){return{...Ft}}function ec(e,t,o){const i=(e||bo.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(n);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),o!=null&&o.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",s),a.toString()}catch{const a=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${s}`}}const ni={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function ph(e){var n,s,a,r,l,c;const t=Fo();if(!e)return{...ni,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[Or]!==void 0?e[Or]!=="false":t.showUnorderedListMarkers,i=e[Pr]!==void 0?e[Pr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Vi])==null?void 0:n.trim())||ni.theme,aspectRatio:((s=e[Ki])==null?void 0:s.trim())||ni.aspectRatio,defaultTransition:((a=e[Gi])==null?void 0:a.trim())||ni.defaultTransition,colorSchema:((r=e[qa])==null?void 0:r.trim())||ni.colorSchema,spacing:((l=e[Es])==null?void 0:l.trim())||ni.spacing,background:((c=e[An])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function vo(e){var o,i,n,s,a;const t=(o=e.ial)==null?void 0:o[mo];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function ya(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[Ct]&&(t.transition=e[Ct].trim()),e[ct]&&(t.background=e[ct].trim()),e[qt]&&(t.image=e[qt].trim()),e[li]&&(t.class=e[li].trim()),e[Oi]&&(t.spacing=e[Oi].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[ci]&&(t.mask=e[ci].trim()),e[Jo]&&(t.maskRatio=e[Jo].trim()),e[di]&&(t.maskStyle=e[di].trim()),e[ui]&&(t.maskInitial=e[ui].trim()),e[ls]&&(o=e[ls].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,yt,ci,Jo,di,ui,Ct,ct,qt,li,Oi,ls,mo].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function ba(e){const t={};if(!e)return t;const o=e[Fe];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ze],n=e[ct];(i===Va||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===Bn||s===Ln?t.imageLayout=s:(i===Bn||i===Ln)&&(t.imageLayout=i);const a=e[Ne];if(a!=null&&(t.clicks=a.trim()),e[Et])try{const r=JSON.parse(e[Et]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Et].trim()}}return e[ei]&&(t.shikiLines=e[ei].trim()),e[Yi]&&(t.maxHeight=e[Yi].trim()),e[Te]&&(t.slot=e[Te].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function xo(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function ji(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),a=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=a?r.push(c.slice(a)):f>n?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function jo(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function vs(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function Ui(e){if(!e)return[];if(ut(e)&&ro(e)&&!ao(e)){const i=Ii(e),n=[];for(const s of i)n.push(...Ui(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(jo);if(a.length>0)return a}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let a=0;a<n.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(n[a])&&s.push(a);if(s.length>=2){const a=[];for(let r=0;r<s.length;r++){const l=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return jo(e)?[e]:[]}function wr(e){var n;if(!e||!ut(e)||!ro(e)||ao(e))return null;const t=Ii(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&ro(t[0])){const s=wr(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ut(s)){o.push(s);const a=((n=s.children)==null?void 0:n.filter(ut))||[];o.push(...a)}const i=t.map(Ui);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=Ui(t[0]),a=Ui(t[1]);if(s.length+a.length>=2&&s.length+a.length<=6&&(s.length>0||a.length>0))return{items:[...s,...a],nestedSuperBlocks:o}}return null}function mh(e){if(!e||!ut(e)||!ro(e)||ao(e))return null;const t=wr(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=xr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((a,r)=>`col-${r+1}`),ratio:n}}function tc(e){if(!e||!ut(e)||!ro(e)||ao(e))return null;const t=Ii(e);if(t.length===0)return null;const o=[];for(const i of t){const n=Ui(i);if(n.length===0)return null;o.push(...n)}return o}function gh(e){if(!e||!ut(e)||!ro(e)||ao(e))return null;const t=tc(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function yh(e){if(!e||!ut(e)||!ro(e)||ao(e))return null;const t=wr(e);if(t&&t.items.length===4)return t.items;const o=tc(e);if(o&&o.length===4)return o;const i=Ii(e);return i.length===4?i:null}function bh(e,t){if(!e||e.length===0)return null;const o=[];function i(r,l){if(ut(r)){const c=yh(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,l)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),n||(n=o[0]);const a=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>oc(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:a}}function vh(e,t,o){var u,f,p,d,b;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const y=t[m];if(vo(y)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},a.push(r)}else r.blocks.push(y)}function l(m){const y=[];for(const g of m)ut(g)&&y.push(g),g.children&&g.children.length>0&&y.push(...l(g.children));return y}function c(m,y,g){const v={blockId:m,attrs:y,previousAttrs:g};i.push(v),o!=null&&o.onTagChange&&o.onTagChange(v)}for(const m of a){const y=m.pageTargetId,g=t.find(k=>k.id===y),v=s.find(k=>k.pageTargetId===y);if(m.blocks.some(k=>{var C,D;return!!(ao(k)||qs(k)&&(((C=k.ial)==null?void 0:C[be])==="image-left"||((D=k.ial)==null?void 0:D[be])==="image-right"))})){if(v){const k=v.headerId;if(k){c(k,{[Te]:""});const C=t.find(D=>D.id===k);C!=null&&C.ial&&(C.ial[Te]="")}for(const C of v.itemIds){c(C,{[Te]:""});const D=t.find(P=>P.id===C);D!=null&&D.ial&&(D.ial[Te]="")}}continue}let _=null,T=-1;for(let k=0;k<m.blocks.length;k++){const C=m.blocks[k],D=ut(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const P of D){const R=mh(P);if(R){_=R,T=k;break}}if(_)break}if(_){const{superBlockNode:k,layout:C,items:D,slots:P}=_,j=m.blocks.slice(0,T).find($=>oc($)),B=j==null?void 0:j.id,N=((u=g==null?void 0:g.ial)==null?void 0:u[be])||"",S=N==="clover",Z=S?"clover":C;if(N!==Z&&(c(y,{[be]:Z},{[be]:N}),g&&(g.ial||(g.ial={}),g.ial[be]=Z)),j){const $=((f=j.ial)==null?void 0:f[Te])||"";$!=="header"&&(c(j.id,{[Te]:"header"},{[Te]:$}),j.ial||(j.ial={}),j.ial[Te]="header")}if(v!=null&&v.headerId&&v.headerId!==B){c(v.headerId,{[Te]:""});const $=t.find(M=>M.id===v.headerId);$&&($.ial||($.ial={}),$.ial[Te]="")}const W=[];for(let $=0;$<D.length;$++){const M=D[$],E=P[$];W.push(M.id);const Q=((p=M.ial)==null?void 0:p[Te])||"";if(Q!==E&&(c(M.id,{[Te]:E},{[Te]:Q}),M.ial||(M.ial={}),M.ial[Te]=E),M.children&&M.children.length>0)for(const F of M.children)F.ial||(F.ial={}),F.ial[Te]!==E&&(F.ial[Te]=E)}if(v!=null&&v.itemIds){for(const $ of v.itemIds)if(!W.includes($)){c($,{[Te]:""});const M=t.find(E=>E.id===$);M&&(M.ial||(M.ial={}),M.ial[Te]="")}}n.push({superBlockId:k.id,nestedSuperBlockIds:(d=_.nestedSuperBlocks)==null?void 0:d.map($=>$.id),pageTargetId:y,headerId:B,itemIds:W,layout:S?"clover":C})}else{let k=!1;const C=[];for(const R of m.blocks){const j=ut(R)?[R,...l(R.children||[])]:R.children?l(R.children):[];for(const B of j){const N=gh(B);if(N){k=!0;for(const S of N.items)C.push(S.id)}}}const D=((b=g==null?void 0:g.ial)==null?void 0:b[be])||"",P=fi(D);if(v||k&&P){c(y,{[be]:""},{[be]:D}),g&&(g.ial||(g.ial={}),g.ial[be]="");const R=v==null?void 0:v.headerId;if(R){c(R,{[Te]:""});const B=t.find(N=>N.id===R);B&&(B.ial||(B.ial={}),B.ial[Te]="")}const j=new Set([...(v==null?void 0:v.itemIds)||[],...C]);for(const B of j){c(B,{[Te]:""});const N=t.find(S=>S.id===B);N&&(N.ial||(N.ial={}),N.ial[Te]="")}}}}return{changes:i,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function ro(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function qs(e){return!e||jo(e)||ut(e)||!xo(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function xr(e){var p;if(!e||!ut(e)||!ro(e))return null;const t=Ii(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const b=(((p=d.ial)==null?void 0:p.style)||d.style||"").trim();let m=null;if(b){const y=b.match(/calc\(\s*([\d.]+)%/i);if(y)m=parseFloat(y[1]);else{const g=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);g&&(m=parseFloat(g[1]))}}m!==null&&!isNaN(m)&&m>0?(o.push(m),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,b)=>d+(b||0),0),a=o.filter(d=>d===null).length,r=Math.max(0,100-s),l=a>0?r/a:100/n,c=o.map(d=>d!==null?d:l),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const f=c.map(d=>d/u*100);if(f.length===2){const[d]=f;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),m=100-b;return`${b}:${m}`}if(f.length===3){const[d,b,m]=f;if(d>=31&&d<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const y=Math.round(d),g=Math.round(b),v=100-y-g;return`${y}:${g}:${v}`}return f.map(d=>Math.round(d)).join(":")}function ao(e){if(!e||!ut(e)||!ro(e))return null;const t=(e.children||[]).filter(s=>{const a=s.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=qs(t[0]),i=qs(t[t.length-1]),n=xr(e)||void 0;if(o&&!i){const s=xo(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:Bn,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=xo(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:Ln,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function kh(e,t){const o=[];function i(n){for(const s of n){const a=ao(s);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[be];if(u!==l){const p={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[be]=l,o.push(p),t&&t(p)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function Ii(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function oc(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function Ko(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let a,r=!1,l=-1,c=0;for(;(a=s.exec(e))!==null;){const g=a[1].match(/\bclass=["']([^"']*)["']/i);if(g){const v=g[1];if(typeof t=="string"?v.split(/\s+/).includes(t):t.test(v)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,l);const u=l+c;let f=1,p=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let m;for(;(m=b.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){p=m.index,d=m.index+m[0].length;break}}else f++;if(p!==-1&&d!==-1){const y=e.slice(u,p);i+=o(y),n=d}else i+=e.slice(l,u),n=u}return i}function wh(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,a=!1,r=-1,l=0;for(;(s=n.exec(e))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=s.index,l=s[0].length;break}}if(!a){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+l;let u=1,f=-1,p=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(e))!==null;)if(b[0].startsWith("</")){if(u--,u===0){f=b.index,p=b.index+b[0].length;break}}else u++;if(f!==-1&&p!==-1){const m=e.slice(r,p),y=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),o+=y,i=p}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function xh(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),l});const{text:n,tokens:s}=wh(o);o=n;const a=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=Ko(o,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),o=Ko(o,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),o=Ko(o,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=Ko(o,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const p=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${p}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=Ko(o,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=Ko(o,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=Ko(o,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((f,p)=>Math.max(f,p.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,f)=>{const p=f.trim();return p.includes("<")||p.includes(`
`)?r:`[${p}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function ic(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Vs(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function Sr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Sh(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ks(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),f=Math.min(o,c.length),p=Math.floor(c.length/f),d=c.length%f;let b=0;for(let m=0;m<f;m++){const y=p+(m<d?1:0);u[m]=c.slice(b,b+y),b+=y}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),p=f?parseInt(f[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),b=d.split(/\r?\n/),m=[];for(let v=0;v<b.length;v++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[v])&&m.push(v);if(m.length>=o){const v=Array.from({length:o},()=>[]);let x=0;for(let _=0;_<o;_++){const T=o-_,k=m.length-x,C=Math.ceil(k/T),D=m[x],P=x+C<m.length?m[x+C]:b.length,R=b.slice(D,P).join(`
`);v[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:R,content:R}],x+=C}return v}const y=d.match(/<li[\s\S]*?<\/li>/gi);if(y&&y.length>=o){const v=Array.from({length:o},()=>[]);let x=0;for(let _=0;_<o;_++){const T=o-_,k=y.length-x,C=Math.ceil(k/T),D=`<ul>
${y.slice(x,x+C).join(`
`)}
</ul>`;v[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:D,content:D}],x+=C}return v}const g=d.split(/\r?\n\s*\r?\n/).filter(v=>v.trim()!=="");if(g.length>=o){const v=Array.from({length:o},()=>[]);let x=0;for(let _=0;_<o;_++){const T=o-_,k=g.length-x,C=Math.ceil(k/T),D=g.slice(x,x+C).join(`

`);v[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:D,content:D}],x+=C}return v}if(p&&p>=1&&p<=o){const v=Array.from({length:o},()=>[]);return v[p-1]=[c],v}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const f=u.match(/^col-(\d+)$/i);if(f){const p=parseInt(f[1],10);if(p>=1&&p<=o)return p}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let b=1;for(const y of e){const g=i(y);g!==null&&(b=g),d[b-1].push(y)}if(!e.some(y=>/^col-\d+$/i.test((y.slot||"").trim()))&&d[0].length===0){const y=d.filter(g=>g.length>0);if(y.length===1)return[y[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),f=e.filter(d=>i(d)===null),p=o-1;if(f.length>=p){const d=Math.floor(f.length/p),b=f.length%p,m=[u];let y=0;for(let g=0;g<p;g++){const v=d+(g<b?1:0);m.push(f.slice(y,y+v)),y+=v}return m}else if(f.length>0){const d=[u];for(let b=0;b<p;b++)d.push(b<f.length?[f[b]]:[]);return d}else return[u,...Array.from({length:p},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const f=r[u],p=u+1<o?r[u+1]:e.length;c[u]=e.slice(f,p)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let f=0;f<o;f++){const p=o-f,d=e.length-u,b=Math.ceil(d/p);c[f]=e.slice(u,u+b),u+=b}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:o},()=>[]);return l[0]=e,l}function va(e,t,o,i){const n=ph(t),s=[],a=ya(t),r=n.background?Nt(n.background,i):void 0;let l={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};l.frontmatter.background&&(l.frontmatter.background=Nt(l.frontmatter.background,i)),l.frontmatter.image&&(l.frontmatter.image=Nt(l.frontmatter.image,i));const c=d=>{const b=[];for(let m=d;m<o.length&&!(m>d&&vo(o[m]));m++)b.push(o[m]);return b},u=d=>{let b,m,y;const g=v=>{var C;if(b)return;const x=ao(v);if(x){b=x.layout,m=x.imageUrl,y=x.ratio;return}const _=Nr(v),T=v.ial?{...v.ial}:{},k=ba(T);if(k.imageLayout==="image-left"||k.imageLayout==="image-right"){const D=xo(_,v.content);if(D){b=k.imageLayout,m=D,y=(C=v.ial)==null?void 0:C[yt];return}}if(v.children&&v.children.length>0){for(const D of v.children)if(g(D),b)return}};for(const v of d)if(g(v),b)break;return{foundLayout:b,foundImage:m,foundRatio:y}},f=(d,b)=>{const{foundLayout:m,foundImage:y,foundRatio:g}=u(b);m&&(d.frontmatter.layout=m,y&&(d.frontmatter.image=Nt(y,i)),g&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=g))};f(l,c(0)),s.push(l);let p=[];for(let d=0;d<o.length;d++){const b=o[d];if(vo(b)){p=[];const y=ya(b.ial);if(s.length===1&&l.blocks.length===0){l.startBlockId=b.id,l.allBlockIds||(l.allBlockIds=[]),l.allBlockIds.includes(b.id)||l.allBlockIds.push(b.id),y.frontmatter.layout&&(l.frontmatter.layout=y.frontmatter.layout),Object.assign(l.frontmatter,y.frontmatter),delete l.frontmatter.background,!y.frontmatter.image&&a.frontmatter.image&&(l.frontmatter.image=a.frontmatter.image),r&&(l.frontmatter.background=r),l.frontmatter.background&&(l.frontmatter.background=Nt(l.frontmatter.background,i)),l.frontmatter.image&&(l.frontmatter.image=Nt(l.frontmatter.image,i)),f(l,c(d+1));continue}l={pageIndex:s.length+1,startBlockId:b.id,frontmatter:{layout:y.frontmatter.layout||"default",...y.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete l.frontmatter.background,l.frontmatter.background&&(l.frontmatter.background=Nt(l.frontmatter.background,i)),l.frontmatter.image&&(l.frontmatter.image=Nt(l.frontmatter.image,i)),f(l,c(d+1)),s.push(l);continue}const m=(y,g)=>{var re,oe,ae,Se,$e,ke,Ce;if(l.allBlockIds||(l.allBlockIds=[]),y.id&&!l.allBlockIds.includes(y.id)&&l.allBlockIds.push(y.id),y.children&&y.children.length>0){const z=ne=>{for(const L of ne)L.id&&!l.allBlockIds.includes(L.id)&&l.allBlockIds.push(L.id),L.children&&L.children.length>0&&z(L.children)};z(y.children)}let v=Nr(y),x=y.ial?{...y.ial}:{};const _=v.match(/\{:\s*([^}]+)\s*\}\s*$/);_&&(x={...Ua(_[0]),...x},v=v.slice(0,_.index).trim()),y.type!=="c"&&!v.startsWith("```")&&(v=ic(v));let T=v.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(T)||T==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(T)&&/\r?\n\}\}\}$/.test(T)&&(v=T.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),T=v.trim());const k=ba(x);if(v=Pd(v,i),v=Nd(v,i==null?void 0:i.refContentMap),y.children&&y.children.length>0){const z=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ne=L=>{for(const U of L){if(U.ial)for(const[w,q]of Object.entries(U.ial))z.includes(w)&&!x[w]&&(x[w]=q);U.children&&U.children.length>0&&ne(U.children)}};ne(y.children)}const C=y.type==="video"||y.type==="NodeVideo"||/<video\b/i.test(v);if(C){const z=x["custom-slides-autoplay"]==="true",ne=x["custom-slides-loop"]==="true",L=x["custom-slides-muted"]==="true"||z,U=x["custom-slides-controls"]==="false";v=v.replace(/<video\b([^>]*)>/gi,(w,q)=>{let H=q;return U?H=H.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(H)||(H+=" controls"),z&&!/autoplay/i.test(H)?H+=" autoplay playsinline":!z&&x["custom-slides-autoplay"]==="false"&&(H=H.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ne&&!/loop/i.test(H)?H+=" loop":!ne&&x["custom-slides-loop"]==="false"&&(H=H.replace(/\bloop\b/gi,"").trim()),L&&!/muted/i.test(H)?H+=" muted":!L&&x["custom-slides-muted"]==="false"&&(H=H.replace(/\bmuted\b/gi,"").trim()),`<video ${H.trim()}>`})}if(k.isBackground){const z=xo(v,y.content);if(z){l.frontmatter.background=Nt(z,i);return}}const D=ao(y);if(D){l.frontmatter.layout=D.layout,l.frontmatter.image=Nt(D.imageUrl,i),!l.frontmatter.layoutRatio&&D.ratio&&(l.frontmatter.layoutRatio=D.ratio);for(const z of D.contentNodes)m(z);return}if(k.imageLayout==="image-left"||k.imageLayout==="image-right"){const z=xo(v,y.content);if(z){l.frontmatter.layout=k.imageLayout,l.frontmatter.image=Nt(z,i),!l.frontmatter.layoutRatio&&((re=y.ial)!=null&&re[yt])&&(l.frontmatter.layoutRatio=y.ial[yt]);return}}if(ut(y)&&y.children&&y.children.length>0){for(const z of y.children)m(z);return}const P=!!(k.slot||g!=null&&g.defaultSlot||l.frontmatter.layout==="clover"||l.frontmatter.layout==="timeline"||l.frontmatter.layout==="steps"||fi(l.frontmatter.layout)||l.frontmatter.layout==="two-cols"),R=!!(y.children&&y.children.some(z=>{var ne,L;return((ne=z.ial)==null?void 0:ne[Te])||((L=z.ial)==null?void 0:L[Ne])||z.children&&z.children.length>=2||z.children&&z.children.some(U=>{var w,q,H,I,A,O;return((w=U.ial)==null?void 0:w[Ne])||((q=U.ial)==null?void 0:q[Te])||((H=U.ial)==null?void 0:H[Ze])||((I=U.ial)==null?void 0:I[be])||((A=U.ial)==null?void 0:A["custom-slides-role"])||((O=U.ial)==null?void 0:O["custom-slides-layout"])})}));if((y.type==="l"||y.type==="NodeList"||y.type==="list")&&y.children&&y.children.length>0&&(R||k.slot||k.clicks||P)){const z=/^\s*\d+\.\s+/m.test(y.markdown||"")||y.subType==="o"||y.subtype==="o";for(let ne=0;ne<y.children.length;ne++){const L=y.children[ne];k.slot&&(!L.ial||!L.ial[Te])&&(L.ial||(L.ial={}),L.ial[Te]=k.slot),m(L,{...g,parentClicks:k.clicks||(g==null?void 0:g.parentClicks),defaultSlot:k.slot||(g==null?void 0:g.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:z,itemIndex:ne+1}})}return}const j=!!(g!=null&&g.isParentListUnpacked),B=!!(y.children&&y.children.length>=2)||!!k.clicks||!!((oe=y.children)!=null&&oe.some(z=>{var ne;return(ne=z.ial)==null?void 0:ne[Ne]}))||j||!y.markdown&&!!(y.children&&y.children.length>0);if(jo(y)&&y.children&&y.children.length>0&&(P||j||k.clicks||y.children.some(z=>{var ne;return(ne=z.ial)==null?void 0:ne[Ne]}))&&B){const z=!!(y.children&&y.children.length>=2),ne=y.children.find(A=>!!(A.markdown||A.content||"").trim())||y.children[0],L=((ae=ne==null?void 0:ne.ial)==null?void 0:ae[Ne])||((Se=ne==null?void 0:ne.ial)==null?void 0:Se["custom-slides-click"]),U=!!(!k.clicks&&z&&L),w=k.clicks||(U?L:void 0)||(g==null?void 0:g.parentClicks),q=y.id||(g==null?void 0:g.parentContainerId),H=k.slot||(g==null?void 0:g.defaultSlot);let I=!0;for(const A of y.children){H&&(!A.ial||!A.ial[Te])&&(A.ial||(A.ial={}),A.ial[Te]=H);const O=!!(A.markdown||A.content||"").trim(),G=I&&O;if(G){if(!(l.frontmatter.layout==="image-right"||l.frontmatter.layout==="image-left")&&!!(l.frontmatter.layout==="clover"||l.frontmatter.layout==="timeline"||l.frontmatter.layout==="steps"||fi(l.frontmatter.layout)||l.frontmatter.layout==="two-cols")&&!!(g!=null&&g.defaultSlot||k.slot||($e=y.ial)!=null&&$e[Te]))A.markdown&&(A.markdown=ji(A.markdown)),A.content&&(A.content=ji(A.content));else{const se=!!((ke=g==null?void 0:g.listContext)!=null&&ke.isOrdered),me=((Ce=g==null?void 0:g.listContext)==null?void 0:Ce.itemIndex)||1,_e=se?`${me}. `:"- ",we=De=>{if(!De)return _e.trim();const He=De.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?De:`${_e}${De}`};A.markdown&&(A.markdown=we(A.markdown)),A.content&&(A.content=we(A.content))}I=!1}let K=A;G&&w&&z?(K={...A,ial:{...A.ial||{}}},delete K.ial[Ne],delete K.ial["custom-slides-click"]):!z&&w&&(K={...A,ial:{...A.ial||{},[Ne]:w}}),m(K,{...g,parentClicks:w,parentContainerId:q,defaultSlot:H,isListItem:!0})}return}if(k.isNote){const z=Sr(v);z&&(l.notes?l.notes+=`

`+z:l.notes=z),l.noteBlocks||(l.noteBlocks=[]),l.noteBlocks.push({id:y.id,type:y.type,content:z||y.content||"",rawMarkdown:v,isNote:!0,attributes:y.ial});return}T=v.trim();const N=(y.content||"").trim();if(T==="::right::"||N==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(T)||T.startsWith("::right::")){l.blocks.push({id:y.id,type:y.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:y.ial});return}const Z=Sh(y);let W=k.slot,$=k.clicks,M=k.motion,E={...y.ial||{}};if(Z!==null){for(;p.length>0&&p[p.length-1].level>=Z;)p.pop();const z=p.length>0?p[p.length-1]:void 0;!W&&(z!=null&&z.slot)&&(W=z.slot),!$&&(z!=null&&z.clicks)&&!(g!=null&&g.parentContainerId)&&($=z.clicks),!M&&(z!=null&&z.motion)&&(M=z.motion);const ne={...(z==null?void 0:z.customAttrs)||{}};if(y.ial)for(const[L,U]of Object.entries(y.ial))L.startsWith("custom-slides-")&&!L.startsWith("custom-slides-slide")&&(ne[L]=U);g!=null&&g.parentContainerId||p.push({level:Z,slot:W,clicks:$,motion:M,customAttrs:ne})}else{const z=p.length>0?p[p.length-1]:void 0;z&&(!W&&z.slot&&z.slot!=="header"&&(W=z.slot),!$&&z.clicks&&!(g!=null&&g.parentContainerId)&&($=z.clicks),!M&&z.motion&&(M=z.motion),z.customAttrs&&(E={...z.customAttrs,...E}))}!W&&l.blocks.some(z=>z.slot==="slot-divider-right")&&(W="right"),!W&&(g!=null&&g.defaultSlot)&&(W=g.defaultSlot),W&&(E[Te]=W),$&&!E[Ne]&&(E[Ne]=$),M&&!E[Et]&&(E[Et]=JSON.stringify(M)),(C||x["custom-slides-autoplay"]||x["custom-slides-muted"])&&(x["custom-slides-autoplay"]&&(E["custom-slides-autoplay"]=x["custom-slides-autoplay"],x["custom-slides-autoplay"]==="true"&&!x["custom-slides-muted"]&&(E["custom-slides-muted"]="true")),x["custom-slides-loop"]&&(E["custom-slides-loop"]=x["custom-slides-loop"]),x["custom-slides-muted"]&&(E["custom-slides-muted"]=x["custom-slides-muted"]),x["custom-slides-controls"]&&(E["custom-slides-controls"]=x["custom-slides-controls"]));const Q=k.maxHeight?Vs(k.maxHeight):void 0,F=!!(g!=null&&g.isListItem||jo(y)),V={id:y.id,type:y.type,content:y.content||"",rawMarkdown:v,clicks:$,parentClicks:g==null?void 0:g.parentClicks,parentContainerId:g==null?void 0:g.parentContainerId,motion:M,shikiLines:k.shikiLines,maxHeight:Q,slot:W,attributes:E,attrs:E,rawNode:y,isListItem:F};l.blocks.push(V)};m(b)}for(let d=0;d<s.length;d++){const b=s[d],m=b.blocks.filter(v=>v.slot!=="slot-divider-right"),y=v=>{const x=v.filter(C=>!!(C.rawMarkdown||C.content||"").trim());if(x.length===0)return;const _=x[0],T=(_.rawMarkdown||_.content||"").trim();(jo(_)||/^(?:[-*+]|\d+\.)\s+/.test(T))&&(_.rawMarkdown=ji(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)},g=b.frontmatter.layout||"default";if(g==="clover"||g==="timeline"||g==="steps"||fi(g)){let v=[];const x=m.filter(D=>D.slot==="header");if(x.length>0)v=x;else if(m.length>0){const D=m.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));D&&(v=[D])}const _=m.filter(D=>!v.includes(D));let T=2;if(g==="clover")T=4;else if(g==="timeline"||g==="steps")_.length===1&&_[0].children&&_[0].children.length>=2?T=Math.min(6,Math.max(2,_[0].children.length)):_.length>=2?T=Math.min(6,_.length):T=3;else if(g==="three-cols-header")T=3;else if(g==="two-cols-header")T=2;else{let D=0;for(const P of _){const R=(P.slot||"").match(/^col-(\d+)$/i);R&&(D=Math.max(D,parseInt(R[1],10)))}if(D>=2)T=D;else if(b.frontmatter.layoutRatio){const P=b.frontmatter.layoutRatio.trim();if(P.includes(":")){const R=P.split(":").map(j=>parseFloat(j.trim())).filter(j=>!isNaN(j)&&j>0);R.length>=2&&(T=R.length)}else{const R=P.split(/\s+/).filter(Boolean);R.length>=2&&(T=R.length)}}else _.length===1&&_[0].children&&_[0].children.length>=2&&(T=Math.min(6,_[0].children.length))}const k=Ks(_,T);k.forEach((D,P)=>{const R=`col-${P+1}`;for(const j of D)(!j.slot||j.slot==="default")&&(j.slot=R);y(D)});const C=k.flat();if(_.length===1&&C.length>1){const D=b.blocks.findIndex(P=>P.id===_[0].id);D!==-1&&b.blocks.splice(D,1,...C)}}else if(g==="two-cols"){const v=m.filter(_=>_.slot==="right"),x=m.filter(_=>!_.slot||_.slot==="default");if(v.length===0&&x.length>=2){const[,_]=Ks(x,2);for(const T of _)T.slot="right"}y(m.filter(_=>_.slot!=="right")),y(m.filter(_=>_.slot==="right"))}b.rawMarkdown=b.blocks.filter(v=>v.slot!=="slot-divider-right").map(v=>v.rawMarkdown||v.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const ka=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Ch(e){var n,s,a,r,l,c,u,f,p,d,b,m;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const y of e.styles){if(!y||!y.id)continue;const g=`--b3-inline-style-${y.id}`;(n=y.light)!=null&&n.color&&t.push(`  ${g}-color: ${y.light.color};`),(s=y.light)!=null&&s.backgroundColor&&t.push(`  ${g}-background-color: ${y.light.backgroundColor};`),(a=y.dark)!=null&&a.color&&o.push(`  ${g}-color: ${y.dark.color};`),(r=y.dark)!=null&&r.backgroundColor&&o.push(`  ${g}-background-color: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const y of e.builtin.colors){if(!y||typeof y.index!="number")continue;const g=y.index;(l=y.light)!=null&&l.color&&t.push(`  --b3-font-color${g}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${g}: ${y.light.backgroundColor};`),(u=y.dark)!=null&&u.color&&o.push(`  --b3-font-color${g}: ${y.dark.color};`),(f=y.dark)!=null&&f.backgroundColor&&o.push(`  --b3-font-background${g}: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const y of e.builtin.styles){if(!y||!y.id)continue;const g=y.id;(p=y.light)!=null&&p.color&&t.push(`  --b3-card-${g}-color: ${y.light.color};`),(d=y.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${g}-background: ${y.light.backgroundColor};`),(b=y.dark)!=null&&b.color&&o.push(`  --b3-card-${g}-color: ${y.dark.color};`),(m=y.dark)!=null&&m.backgroundColor&&o.push(`  --b3-card-${g}-background: ${y.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Wi(e){const t=Ch(e);return t?`${ka}

/* Custom Workspace Inline Styles */
${t}`:ka}const ks=Ua;function _h(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Ih(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const a=n.get(s.id);if(!a)continue;const r=s.content??"",l=s.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(_h(a)?i.push(s.id):o.set(s.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function $h(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Gs(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Th(e,t,o,i=8,n){const s=new Map;for(const p of t)p!=null&&p.id&&s.set(p.id,p);const a=p=>({id:p.id,parent_id:p.parent_id,root_id:p.root_id||e,type:p.type,subType:p.subtype??p.subType??"",content:p.content||"",markdown:p.markdown||"",ial:o(p.id,p.ial),children:[]}),r=p=>{let d=p.parent_id,b=0;for(;d&&d!==e&&b++<16;){const m=s.get(d);if(!m||!$h(m))return d;d=m.parent_id}return d||e},l=new Map;for(const p of t){if(!(p!=null&&p.id)||p.id===e||n&&n.size>0&&!n.has(p.id))continue;const d=r(p),b=l.get(d);b?b.push(p):l.set(d,[p])}if(n&&n.size>0)for(const p of l.values())p.sort((d,b)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(p,d)=>{const b=a(p);if(c.set(b.id,b),d>=i||!Gs(b))return b;const m=l.get(b.id);return m&&m.length>0&&(b.children=m.map(y=>u(y,d+1))),b};return{topLevel:(l.get(e)||[]).map(p=>u(p,0)),byId:c}}const Ah={getBlockAttrs:er,getChildBlocks:Si,getDocBlocksOrders:Bd,setBlockAttrs:ze,sql:vi,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ld};class Mh{constructor(t){Ie(this,"deps");Ie(this,"attrOverrides",new Map);Ie(this,"trackedListSuperBlocks",new Map);Ie(this,"fallbackWarnedDocId","");this.deps={...Ah,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,a]of Object.entries(o))a===""||a===null||a===void 0?delete n[s]:n[s]=String(a);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let W=0;W<s.length;W++)s[W]&&a.set(s[W],W);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=Ih(n,c),f=new Map;if(Array.isArray(c))for(const W of c)W.id&&W.ial&&f.set(W.id,ks(W.ial));const p=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(p).catch(()=>[])||[];if(Array.isArray(d)){for(const W of d)if(W.block_id&&W.name){let $=f.get(W.block_id);$||($={},f.set(W.block_id,$)),$[W.name]=W.value||""}}const b=(W,$)=>{const M={...f.get(W)||($?ks($):{})},E=this.attrOverrides.get(W);return E&&Object.assign(M,E),M},m=Array.isArray(c)&&c.length>0?Th(t,c,b,8,a):null,y=n.map(W=>W.id).filter(Boolean),g=W=>({id:W.id,parent_id:W.parent_id,root_id:W.root_id||t,type:W.type,subType:W.subType,content:W.content||"",markdown:W.markdown||"",ial:b(W.id,W.ial),children:W.children}),v=async(W,$=0)=>{if(!W||$>8||!Gs(W))return;const M=await this.deps.getChildBlocks(W.id).catch(()=>[])||[];if(!(!Array.isArray(M)||M.length===0)){W.children=M.filter(E=>E==null?void 0:E.id).map(E=>({id:E.id,parent_id:W.id,root_id:t,type:E.type,subType:E.subType,content:E.content||"",markdown:E.markdown||"",ial:b(E.id,E.ial),children:[]}));for(const E of W.children)await v(E,$+1)}},x=new Map;for(const W of c)W!=null&&W.id&&x.set(W.id,W);const _=y.every(W=>{const $=x.get(W);return!$||!!$.type});let T=[],k=!1;if(m&&u.usable&&r&&_){this.fallbackWarnedDocId="";for(const[$,M]of u.leafPatch){const E=m.byId.get($);E&&(E.content=M.content,E.markdown=M.markdown)}const W=new Map;for(const $ of n)$!=null&&$.id&&W.set($.id,$);for(const $ of u.rebuildRoots){const M=m.byId.get($),E=W.get($);M&&E&&(M.content=E.content||"",M.markdown=E.markdown||""),await v(M)}for(const $ of n){if(!($!=null&&$.id)||m.byId.has($.id))continue;const M=g($);await v(M),m.byId.set(M.id,M),m.topLevel.push(M)}T=m.topLevel.filter($=>a.has($.id)).sort(($,M)=>(a.get($.id)??0)-(a.get(M.id)??0))}else y.length>0?(k=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${y.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),T=n.map(W=>g(W))):m&&(T=m.topLevel);const C=async(W,$=0)=>{if(!(!W||W.length===0||$>8))for(const M of W){if(Gs(M)&&(!M.children||M.children.length===0)){let Q=await this.deps.getChildBlocks(M.id).catch(()=>[]);if(!Q||Q.length===0){const F=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${M.id}' ORDER BY sort ASC, created ASC`;Q=await this.deps.sql(F).catch(()=>[])||[]}if(Array.isArray(Q)&&Q.length>0){const F=new Set(T.map(re=>re.id)),V=Q.filter(re=>re.id!==M.id&&!F.has(re.id));V.length>0&&(M.children=V.map(re=>{const oe=f.get(re.id)||(re.ial?ks(re.ial):{}),ae=this.attrOverrides.get(re.id);return ae&&Object.assign(oe,ae),{id:re.id,parent_id:re.parent_id||M.id,root_id:re.root_id||t,type:re.type,subType:re.subType,content:re.content||"",markdown:re.markdown||"",ial:oe}}))}}M.children&&M.children.length>0&&await C(M.children,$+1)}};k&&await C(T);const D=W=>{var $,M;for(const E of W)if(E.children&&E.children.length>0){D(E.children);for(const Q of E.children)if(Q.ial)for(const[F,V]of Object.entries(Q.ial))F.startsWith("custom-slides-")&&!(($=E.ial)!=null&&$[F])&&(E.ial||(E.ial={}),E.ial[F]=V);if(E.ial){for(const[Q,F]of Object.entries(E.ial))if(Q.startsWith("custom-slides-"))for(const V of E.children)(V.type==="video"||V.type==="NodeVideo"||/<video\b/i.test(V.markdown||V.content||""))&&!((M=V.ial)!=null&&M[Q])&&(V.ial||(V.ial={}),V.ial[Q]=F)}}};D(T),kh(T,W=>{const $={[be]:W.layout};this.setBlockAttrOverride(W.blockId,$),(this.deps.setBlockAttrs||ze)(W.blockId,$).catch(E=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",E)})});const P=this.trackedListSuperBlocks.get(t)||[],R=vh(t,T,{tracked:P,onTagChange:W=>{this.setBlockAttrOverride(W.blockId,W.attrs),W.blockId===t&&Object.assign(o,W.attrs);const $=E=>{for(const Q of E)Q.id===W.blockId&&(Q.ial||(Q.ial={}),Object.assign(Q.ial,W.attrs)),Q.children&&Q.children.length>0&&$(Q.children)};$(T),(this.deps.setBlockAttrs||ze)(W.blockId,W.attrs).catch(E=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",E)})}});this.trackedListSuperBlocks.set(t,R.newTracked);const j=new Set,B=W=>{for(const $ of W){const M=$.markdown||$.content||"";if(M.includes("((")){const E=Dd(M);for(const Q of E)j.add(Q.blockId)}$.children&&$.children.length>0&&B($.children)}};B(T);const N={};if(j.size>0){const W=Array.from(j).map(M=>`'${M}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${W})`).catch(()=>[])||[];if(Array.isArray($))for(const M of $)M.id&&(N[M.id]=M.markdown||M.content||"")}const S=this.deps.getBaseUrl?this.deps.getBaseUrl():"",Z=va(t,o,T,{baseUrl:S,refContentMap:N});try{const W=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;Z.customThemeCss=Wi(W)}catch{Z.customThemeCss=Wi(null)}return Z}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=va(t,{},[],{});return i.customThemeCss=Wi(null),i}}}const Ee=new Mh,Eh={presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0};function Do(e){return Eh[e]===!1}function Ot(e){return!Do(e)}const wa=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],xa=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function Cr(e,t,o){return .299*e+.587*t+.114*o}function Sa(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return Cr(o,i,n)}return null}function Ca(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return Cr(o,i,n)}function _a(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const l=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(l)&&l<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,a,r;if(i===0)s=a=r=n*255;else{const l=n<.5?n*(1+i):n+i-n*i,c=2*n-l,u=f=>{let p=f;return p<0&&(p+=1),p>1&&(p-=1),p<1/6?c+(l-c)*6*p:p<1/2?l:p<2/3?c+(l-c)*(2/3-p)*6:c};s=u(o+1/3)*255,a=u(o)*255,r=u(o-1/3)*255}return Cr(s,a,r)}function nc(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(wa.includes(t))return!0;if(xa.includes(t))return!1;if(t.startsWith("#")){const o=Sa(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=Ca(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=_a(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const l of i){const c=Sa(l);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const l of n){const c=Ca(l);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const l of s){const c=_a(l);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const l of r)l!=="transparent"&&(wa.includes(l)?o.push(240):xa.includes(l)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function Uo(){var e,t,o,i,n,s,a,r,l,c,u,f,p;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const b=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(b==="light"||b==="dark")return b;if((a=(s=document.documentElement)==null?void 0:s.classList)!=null&&a.contains("theme--dark")||(l=(r=document.body)==null?void 0:r.classList)!=null&&l.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(p=(f=document.body)==null?void 0:f.classList)!=null&&p.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function _r(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:Uo()}function sc(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=Uo();const o=()=>{const n=Uo();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class ns{constructor(){Ie(this,"iframe",null);Ie(this,"isReady",!1);Ie(this,"pendingMessages",[]);Ie(this,"slideChangedHandlers",[]);Ie(this,"blockClickedHandlers",[]);Ie(this,"openInEditorHandlers",[]);Ie(this,"clientReadyHandlers",[]);Ie(this,"openPeekDrawerHandlers",[]);Ie(this,"toggleFullscreenHandlers",[]);Ie(this,"openPresenterHandlers",[]);Ie(this,"captureProgressHandlers",[]);Ie(this,"capturePageDoneHandlers",[]);Ie(this,"captureCompleteHandlers",[]);Ie(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(a=>a.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||Uo()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",a={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const Bh={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Lh={key:0},Dh={key:1},Nh={key:2},Oh={key:3},Ph={key:4},Rh={key:5},zh={key:6},Hh={key:7},Fh={key:8},jh={key:9},Uh={key:10},Wh={key:11},qh={key:12},Vh={key:13},Kh={key:14},Gh={key:15},Yh={key:16},Zh={key:17},Jh={key:18},Xh={key:19},Qh={key:20},ep={key:21},tp={key:22},op={key:23},ip={key:24},np={key:25},sp={key:26},rp={key:27},ap={key:28},lp={key:29},cp={key:30},dp={key:31},up={key:32},fp={key:33},hp={key:34},pp={key:35},mp={key:36},gp={key:37},yp={key:38},bp={key:39},vp={key:40},kp={key:41},wp={key:42},xp={key:43},Sp={key:44},Cp={key:45},_p={key:46},Ip={key:47},$p={key:48},Tp={key:49},Ap={key:50},Mp={key:51},Ep={key:52},Bp={key:53},Lp={key:54},Dp={key:55},Np={key:56},Op={key:57},Pp={key:58},Rp={key:59},zp={key:60},Hp={key:61},Fp={key:62},jp={key:63},Up={key:64},Wp={key:65},qp={key:66},Vp={key:67},Kp={key:68},Gp={key:69},Yp={key:70},Zp={key:71},Jp={key:72},Xp={key:73},Qp={key:74},em=Ht({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),X("svg",Bh,[e.name==="fullscreen"||e.name==="maximize"?(J(),X("g",Lh,[...o[0]||(o[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),X("g",Dh,[...o[1]||(o[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),X("g",Nh,[...o[2]||(o[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),X("g",Oh,[...o[3]||(o[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),X("g",Ph,[...o[4]||(o[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),X("g",Rh,[...o[5]||(o[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),X("g",zh,[...o[6]||(o[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),X("g",Hh,[...o[7]||(o[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),X("g",Fh,[...o[8]||(o[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),X("g",jh,[...o[9]||(o[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),X("g",Uh,[...o[10]||(o[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),X("g",Wh,[...o[11]||(o[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),X("g",qh,[...o[12]||(o[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),X("g",Vh,[...o[13]||(o[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),X("g",Kh,[...o[14]||(o[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),X("g",Gh,[...o[15]||(o[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),X("g",Yh,[...o[16]||(o[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="layout-grid"||e.name==="grid-2x2"||e.name==="grid"||e.name==="overview"?(J(),X("g",Zh,[...o[17]||(o[17]=[h("rect",{x:"3",y:"3",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"14",y:"14",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"3",y:"14",width:"7",height:"7",rx:"1"},null,-1)])])):e.name==="code"?(J(),X("g",Jh,[...o[18]||(o[18]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),X("g",Xh,[...o[19]||(o[19]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-730eaece></line><line x1="8" y1="12" x2="21" y2="12" data-v-730eaece></line><line x1="8" y1="18" x2="21" y2="18" data-v-730eaece></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-730eaece></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-730eaece></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-730eaece></line>',6)])])):e.name==="insert-above"?(J(),X("g",Qh,[...o[20]||(o[20]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),X("g",ep,[...o[21]||(o[21]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),X("g",tp,[...o[22]||(o[22]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),X("g",op,[...o[23]||(o[23]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),X("g",ip,[...o[24]||(o[24]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),X("g",np,[...o[25]||(o[25]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-730eaece></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-730eaece></path>',5)])])):e.name==="ratio"?(J(),X("g",sp,[...o[26]||(o[26]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),X("g",rp,[...o[27]||(o[27]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),X("g",ap,[...o[28]||(o[28]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),X("g",lp,[...o[29]||(o[29]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),X("g",cp,[...o[30]||(o[30]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),X("g",dp,[...o[31]||(o[31]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),X("g",up,[...o[32]||(o[32]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),X("g",fp,[...o[33]||(o[33]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),X("g",hp,[...o[34]||(o[34]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),X("g",pp,[...o[35]||(o[35]=[h("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),X("g",mp,[...o[36]||(o[36]=[h("polyline",{points:"11 17 6 12 11 7"},null,-1),h("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),X("g",gp,[...o[37]||(o[37]=[h("polyline",{points:"13 17 18 12 13 7"},null,-1),h("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),X("g",yp,[...o[38]||(o[38]=[h("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),X("g",bp,[...o[39]||(o[39]=[h("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),h("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),X("g",vp,[...o[40]||(o[40]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),X("g",kp,[...o[41]||(o[41]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),X("g",wp,[...o[42]||(o[42]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),X("g",xp,[...o[43]||(o[43]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),X("g",Sp,[...o[44]||(o[44]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),X("g",Cp,[...o[45]||(o[45]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-730eaece></path><polyline points="14 2 14 8 20 8" data-v-730eaece></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-730eaece></line><line x1="16" y1="17" x2="8" y2="17" data-v-730eaece></line><line x1="10" y1="9" x2="8" y2="9" data-v-730eaece></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),X("g",_p,[...o[46]||(o[46]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),X("g",Ip,[...o[47]||(o[47]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6",y1:"9",x2:"18",y2:"9","stroke-width":"2.2"},null,-1),h("line",{x1:"8",y1:"13",x2:"16",y2:"13","stroke-width":"1.2",opacity:"0.8"},null,-1),h("line",{x1:"9.5",y1:"16.5",x2:"14.5",y2:"16.5","stroke-width":"1",opacity:"0.6"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),X("g",$p,[...o[48]||(o[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="12" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="5" y1="11" x2="19" y2="11" stroke-width="1.2" data-v-730eaece></line><line x1="5" y1="14" x2="19" y2="14" stroke-width="1.2" data-v-730eaece></line><line x1="5" y1="17" x2="14" y2="17" stroke-width="1.2" opacity="0.75" data-v-730eaece></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),X("g",Tp,[...o[49]||(o[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-730eaece></line><line x1="5" y1="8" x2="9.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-730eaece></line><line x1="5" y1="15" x2="8" y2="15" data-v-730eaece></line><line x1="14.5" y1="8" x2="19" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-730eaece></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-730eaece></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),X("g",Ap,[...o[50]||(o[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="13" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-730eaece></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-730eaece></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-730eaece></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-730eaece></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),X("g",Mp,[...o[51]||(o[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="14" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-730eaece></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-730eaece></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-730eaece></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-730eaece></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-730eaece></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-730eaece></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),X("g",Ep,[...o[52]||(o[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7" x2="13" y2="7" stroke-width="1.6" data-v-730eaece></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-730eaece></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-730eaece></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-730eaece></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-730eaece></line>',8)])])):e.name==="layout-timeline"||e.name==="timeline"||e.name==="layout-steps"||e.name==="steps"?(J(),X("g",Bp,[...o[53]||(o[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7" x2="12" y2="7" stroke-width="1.6" data-v-730eaece></line><line x1="6" y1="11.5" x2="18" y2="11.5" stroke-width="1.2" opacity="0.65" data-v-730eaece></line><circle cx="6" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="4.5" y1="15.5" x2="7.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line><circle cx="12" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line><circle cx="18" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="16.5" y1="15.5" x2="19.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line>',9)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),X("g",Lp,[...o[54]||(o[54]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" data-v-730eaece></line><line x1="4.5" y1="8" x2="9.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-730eaece></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-730eaece></line><circle cx="15.5" cy="8.5" r="1.2" data-v-730eaece></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-730eaece></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),X("g",Dp,[...o[55]||(o[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" data-v-730eaece></line><circle cx="6" cy="8.5" r="1.2" data-v-730eaece></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-730eaece></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-730eaece></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-730eaece></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),X("g",Np,[...o[56]||(o[56]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"7",y1:"10",x2:"17",y2:"10","stroke-width":"1.8"},null,-1),h("line",{x1:"5.5",y1:"13.5",x2:"18.5",y2:"13.5","stroke-width":"1.2"},null,-1),h("line",{x1:"8",y1:"16.5",x2:"16",y2:"16.5","stroke-width":"1",opacity:"0.8"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),X("g",Op,[...o[57]||(o[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><circle cx="8" cy="9" r="1.6" stroke-width="1.5" data-v-730eaece></circle><line x1="15" y1="7.5" x2="9" y2="14.5" stroke-width="1.8" data-v-730eaece></line><circle cx="16" cy="13" r="1.6" stroke-width="1.5" data-v-730eaece></circle><line x1="6" y1="17.5" x2="18" y2="17.5" stroke-width="1.2" opacity="0.85" data-v-730eaece></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),X("g",Pp,[...o[58]||(o[58]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><circle cx="7.5" cy="10" r="2.5" stroke-width="1.5" data-v-730eaece></circle><path d="M4 17c0-2 1.5-3.2 3.5-3.2s3.5 1.2 3.5 3.2" stroke-width="1.2" data-v-730eaece></path><line x1="13.5" y1="8.5" x2="19" y2="8.5" stroke-width="1.8" data-v-730eaece></line><line x1="13.5" y1="12" x2="19.5" y2="12" stroke-width="1.2" data-v-730eaece></line><line x1="13.5" y1="15.5" x2="17.5" y2="15.5" stroke-width="1.2" opacity="0.8" data-v-730eaece></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),X("g",Rp,[...o[59]||(o[59]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><path d="M5.5 8h2v2H6c0 1.2-.3 1.8-1.2 2.3" stroke-width="1.4" data-v-730eaece></path><path d="M8.5 8h2v2H9c0 1.2-.3 1.8-1.2 2.3" stroke-width="1.4" data-v-730eaece></path><line x1="6" y1="13" x2="18" y2="13" stroke-width="1.5" data-v-730eaece></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" stroke-width="1.2" opacity="0.8" data-v-730eaece></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),X("g",zp,[...o[60]||(o[60]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),X("g",Hp,[...o[61]||(o[61]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),X("g",Fp,[...o[62]||(o[62]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),X("g",jp,[...o[63]||(o[63]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),X("g",Up,[...o[64]||(o[64]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),X("g",Wp,[...o[65]||(o[65]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),X("g",qp,[...o[66]||(o[66]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-730eaece></line><line x1="4" y1="10" x2="4" y2="3" data-v-730eaece></line><line x1="12" y1="21" x2="12" y2="12" data-v-730eaece></line><line x1="12" y1="8" x2="12" y2="3" data-v-730eaece></line><line x1="20" y1="21" x2="20" y2="16" data-v-730eaece></line><line x1="20" y1="12" x2="20" y2="3" data-v-730eaece></line><line x1="1" y1="14" x2="7" y2="14" data-v-730eaece></line><line x1="9" y1="8" x2="15" y2="8" data-v-730eaece></line><line x1="17" y1="16" x2="23" y2="16" data-v-730eaece></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),X("g",Vp,[...o[67]||(o[67]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),X("g",Kp,[...o[68]||(o[68]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),X("g",Gp,[...o[69]||(o[69]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),X("g",Yp,[...o[70]||(o[70]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),X("g",Zp,[...o[71]||(o[71]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-730eaece></rect><line x1="13" y1="8" x2="19" y2="8" data-v-730eaece></line><line x1="13" y1="12" x2="19" y2="12" data-v-730eaece></line><line x1="13" y1="16" x2="17" y2="16" data-v-730eaece></line>',5)])])):e.name==="image-right"?(J(),X("g",Jp,[...o[72]||(o[72]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-730eaece></rect><line x1="5" y1="8" x2="11" y2="8" data-v-730eaece></line><line x1="5" y1="12" x2="11" y2="12" data-v-730eaece></line><line x1="5" y1="16" x2="9" y2="16" data-v-730eaece></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),X("g",Xp,[...o[73]||(o[73]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),X("g",Qp,[...o[74]||(o[74]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),lo=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},de=lo(em,[["__scopeId","data-v-730eaece"]]),tm={class:"spm-immersion-header"},om={class:"spm-immersion-header__left"},im={class:"spm-immersion-title"},nm={class:"spm-immersion-header__center"},sm={class:"spm-immersion-header__actions"},rm=["aria-label"],am={class:"spm-immersion-body"},lm=Ht({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function a(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),n())}return(l,c)=>Wt((J(),X("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:no(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",tm,[h("div",om,[hn(l.$slots,"header-left",{},()=>[h("span",im,ve(e.title),1)])]),h("div",nm,[hn(l.$slots,"header-center",{},void 0)]),h("div",sm,[hn(l.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[le(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,rm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[le(de,{name:"close"})])])]),h("div",am,[hn(l.$slots,"default",{},void 0)])],2)],34)),[[Us,e.visible]])}}),cm=lo(lm,[["__scopeId","data-v-1359fecb"]]);function dm(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function an(e){const t=dm();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function um(){var t;if(typeof window<"u"&&window.process)return window.process;const e=an("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function fm(){var t,o;const e=um();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=an("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function hm(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const pm={class:"spm-protyle-drawer"},mm={class:"spm-protyle-drawer__subbar"},gm={class:"spm-protyle-drawer__nav"},ym=["title"],bm={class:"spm-protyle-drawer__actions"},vm=["aria-label"],km=["aria-label"],wm=Ht({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(i.blockId),s=pe(i.title||""),a=pe(!1),r=pe(!0),l=pe(!1),c=pe(""),u=Ft,f=pe([]),p=pe(null);let d=null;Ho(()=>i.blockId,C=>{C&&C!==n.value&&(n.value=C,s.value=i.title||"",f.value=[],m(C))}),ti(()=>{n.value&&m(n.value)}),pr(()=>{y()});async function b(C){try{const D=await vi(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const P=D[0];c.value=P.root_id||"";const R=P.id===P.root_id||P.type==="d";l.value=R,r.value=!R,!s.value&&P.content&&(s.value=P.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}l.value=!1,r.value=!0}async function m(C,D){if(!p.value||!C)return;y(),await b(C),typeof D=="boolean"&&(r.value=!l.value&&D);let P,R;r.value&&!l.value?(P=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(P=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ie.Protyle(i.plugin.app,p.value,{blockId:C,action:P,render:R}),!a.value&&d&&typeof d.disable=="function"&&d.disable()}catch(j){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",j)}}function y(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}d=null}p.value&&(p.value.innerHTML="")}function g(){l.value||(r.value=!r.value,m(n.value,r.value))}function v(){a.value=!a.value,d&&(a.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function x(){if(n.value)try{ie.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function _(){var P;if(!n.value)return;const C=Fo(),D=ec(C.webServeUrl,n.value,{focus:!l.value});if(typeof window<"u"){const R=an("electron");(P=R==null?void 0:R.shell)!=null&&P.openExternal?R.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}o("external-jump",D)}function T(){if(f.value.length>0){const C=f.value.pop();C&&(n.value=C.blockId,s.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function k(C){const D=C.target;if(!D)return;const P=D.closest('[data-type="block-ref"]');if(P){const j=P.getAttribute("data-id");if(j&&j!==n.value){C.preventDefault(),C.stopPropagation(),f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=j,s.value=P.innerText.trim()||j,m(j);return}}const R=D.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const j=R.href.replace("siyuan://blocks/","").split("?")[0];j&&j!==n.value&&(f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:l.value}),n.value=j,s.value=R.innerText.trim()||j,m(j))}}return(C,D)=>(J(),X("div",pm,[h("div",mm,[h("div",gm,[f.value.length>0?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:T},[le(de,{name:"arrow-left"}),D[0]||(D[0]=h("span",null,"返回",-1))])):Ae("",!0),h("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},ve(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||n.value},ve(s.value||n.value),9,ym)]),h("div",bm,[l.value?Ae("",!0):(J(),X("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:g},[le(de,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,ve(r.value?"块聚焦":"展开全文"),1)],10,vm)),h("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:v},[le(de,{name:a.value?"edit":"eye"},null,8,["name"]),h("span",null,ve(a.value?"编辑中":"只读"),1)],10,km),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[le(de,{name:"window"}),D[1]||(D[1]=h("span",null,"独立窗口",-1))]),ue(u).enableWebServeJump?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:_},[le(de,{name:"external-link"}),D[2]||(D[2]=h("span",null,"外跳",-1))])):Ae("",!0)])]),h("div",{ref_key:"mountEl",ref:p,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:k},null,2)]))}}),xm=lo(wm,[["__scopeId","data-v-0d6e2df3"]]),Sm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Cm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Ia(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function rc(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function _m(e){const t=e.split(/[/?#]/)[0];return!t||Cm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function Im(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,a=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function ac(e){const t=$m(e);return t.external||!t.url?t:{url:Im(t.url),external:!1}}function $m(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Ka(t))return{url:`/${Ga(t)}`,external:!1};if(/^file:/i.test(t)){const i=Ia(rc(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=Ia(t);return i?{url:i,external:!1}:{url:t,external:!0}}return Sm.test(t)?{url:t,external:!0}:_m(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Tm={class:"spm-webview-drawer"},Am={class:"spm-webview-toolbar"},Mm={class:"spm-webview-toolbar__nav"},Em=["disabled"],Bm=["disabled"],Lm=["aria-label"],Dm={class:"spm-webview-toolbar__address"},Nm=["aria-label"],Om={class:"spm-webview-toolbar__actions"},Pm=["aria-label"],Rm={class:"spm-zoom-controller"},zm=["disabled"],Hm=["disabled"],Fm={key:1,class:"spm-webview-fallback"},jm=["src"],Um={key:2,class:"spm-load-error"},Wm={class:"spm-load-error__code"},qm={class:"spm-load-error__code-num"},Vm={class:"spm-load-error__url"},Km={class:"spm-load-error__hint"},Gm={class:"spm-load-error__actions"},$a="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",lc="siyuan-slides-peek-view-mode";let cc="desktop";function Ym(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(lc);if(e==="mobile"||e==="desktop")return e}catch{}return cc}function Zm(e){if(cc=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(lc,e)}catch{}}function Jm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Xm=Ht({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(fm()&&!hm()),s=pe(i.url),a=pe(i.url),r=i.url,l=pe(!1),c=pe(null),u=pe(!1),f=pe(!1),p=pe(1),d=pe(!1),b=pe(Ym());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=ye(()=>b.value==="mobile"?$a:m||void 0),g=pe(null),v=pe(null);let x=null,_=null,T=null;Ho(()=>i.url,z=>{z&&z!==s.value&&(s.value=z,a.value=z,b.value==="mobile"&&R(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z))}),Ho(()=>i.visible,z=>{if(z)re(),b.value==="mobile"&&R(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),ti(()=>{k(),v.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const z=g.value;if(z&&typeof z.invalidate=="function")try{z.invalidate()}catch{}}),x.observe(v.value)),_=z=>{var L;const ne=z.message||((L=z.error)==null?void 0:L.message);if(typeof ne=="string"&&ne.includes("Invalid guestInstanceId"))return z.preventDefault(),z.stopImmediatePropagation(),!0},window.addEventListener("error",_,!0),T=z=>{const ne=z.reason,L=typeof ne=="string"?ne:ne==null?void 0:ne.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&z.preventDefault()},window.addEventListener("unhandledrejection",T)}),pr(()=>{if(C(),x&&(x.disconnect(),x=null),_&&(window.removeEventListener("error",_,!0),_=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function k(){const z=g.value;z&&(z.addEventListener("dom-ready",D),z.addEventListener("did-start-loading",j),z.addEventListener("did-stop-loading",S),z.addEventListener("did-navigate",Z),z.addEventListener("did-navigate-in-page",W),z.addEventListener("new-window",$),z.addEventListener("did-fail-load",B),z.addEventListener("did-fail-provisional-load",B))}function C(){const z=g.value;if(z)try{z.removeEventListener("dom-ready",D),z.removeEventListener("did-start-loading",j),z.removeEventListener("did-stop-loading",S),z.removeEventListener("did-navigate",Z),z.removeEventListener("did-navigate-in-page",W),z.removeEventListener("new-window",$),z.removeEventListener("did-fail-load",B),z.removeEventListener("did-fail-provisional-load",B)}catch{}}function D(){const z=g.value;if(z&&typeof z.getUserAgent=="function"&&!m)try{const ne=z.getUserAgent();ne&&!ne.includes("iPhone")&&(m=ne)}catch{}b.value==="mobile"&&R(!1),re(),M()}function P(){const z=b.value==="mobile"?"desktop":"mobile";b.value=z,Zm(z),R(!0)}function R(z=!1){const ne=g.value;if(!ne)return;const L=b.value==="mobile"?$a:m;if(typeof ne.setUserAgent=="function"&&L)try{ne.setUserAgent(L)}catch(U){console.warn("[WebviewPeekDrawer] setUserAgent error:",U)}if(z&&typeof ne.reload=="function")try{ne.reload()}catch(U){console.warn("[WebviewPeekDrawer] reload error:",U)}}function j(){l.value=!0,c.value=null}function B(z){if(z&&z.isMainFrame===!1||z&&Number(z.errorCode)===-3)return;const ne=String((z==null?void 0:z.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((z==null?void 0:z.errorCode)??0),description:ne,validatedURL:String((z==null?void 0:z.validatedURL)||s.value),hint:Jm(ne)},l.value=!1}function N(){c.value=null,F()}function S(){if(l.value=!1,M(),g.value&&typeof g.value.getURL=="function"){const z=g.value.getURL();z&&z!=="about:blank"&&(s.value=z,a.value=z)}}function Z(z){z!=null&&z.url&&(s.value=z.url,a.value=z.url),M()}function W(z){z!=null&&z.url&&(s.value=z.url,a.value=z.url),M()}function $(z){z&&z.url&&(z.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z.url))}function M(){const z=g.value;z&&(typeof z.canGoBack=="function"&&(u.value=z.canGoBack()),typeof z.canGoForward=="function"&&(f.value=z.canGoForward()))}function E(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function Q(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function F(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function V(){const z=ac(a.value);if(z.url){if(z.external){s.value=z.url,Ce();return}s.value=z.url,a.value=z.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z.url)}}function re(){const z=g.value;if(z&&typeof z.setZoomFactor=="function")try{z.setZoomFactor(p.value)}catch(ne){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ne)}}function oe(){p.value=Math.min(2.5,Math.round((p.value+.1)*10)/10),re()}function ae(){p.value=Math.max(.5,Math.round((p.value-.1)*10)/10),re()}function Se(){p.value=1,re()}function $e(z){z.preventDefault(),z.deltaY<0?oe():z.deltaY>0&&ae()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(z){console.warn("Copy url failed:",z)}}function Ce(){var ne;const z=s.value;if(typeof window<"u"){const L=an("electron");(ne=L==null?void 0:L.shell)!=null&&ne.openExternal?L.shell.openExternal(z).catch(()=>{window.open(z,"_blank")}):window.open(z,"_blank")}o("external-jump",z)}return(z,ne)=>{const L=Uu("webview");return J(),X("div",Tm,[h("div",Am,[h("div",Mm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:E},[le(de,{name:"arrow-left"})],8,Em),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:Q},[le(de,{name:"arrow-right"})],8,Bm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:F},[le(de,{name:"refresh"})],8,Lm)]),h("div",Dm,[Wt(h("input",{"onUpdate:modelValue":ne[0]||(ne[0]=U=>a.value=U),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:sh(V,["enter"])},null,544),[[Ws,a.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ke},[le(de,{name:"copy"})],8,Nm)]),h("div",Om,[h("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:P},[le(de,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Pm),h("div",Rm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:p.value<=.5,onClick:ae},[le(de,{name:"minus"})],8,zm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},ve(Math.round(p.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:p.value>=2.5,onClick:oe},[le(de,{name:"plus"})],8,Hm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Ce},[le(de,{name:"external-link"}),ne[1]||(ne[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:xe(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:no($e,["ctrl"])},[h("div",{class:xe(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[n.value?(J(),Vt(L,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:ue(r),useragent:y.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),X("div",Fm,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,jm),h("div",{class:"spm-fallback-bar"},[ne[2]||(ne[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:Ce}," 在新标签页中打开 ↗ ")])])),c.value?(J(),X("div",Um,[le(de,{name:"alert",class:"spm-load-error__icon"}),ne[5]||(ne[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",Wm,[St(ve(c.value.description)+" ",1),h("span",qm,"("+ve(c.value.errorCode)+")",1)]),h("div",Vm,ve(c.value.validatedURL),1),h("p",Km,ve(c.value.hint),1),h("div",Gm,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:N},[le(de,{name:"refresh"}),ne[3]||(ne[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:Ce},[le(de,{name:"external-link"}),ne[4]||(ne[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Ae("",!0)],2)],34)])}}}),Qm=lo(Xm,[["__scopeId","data-v-6e363f73"]]);class eg{constructor(){Ie(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class tg{constructor(t){Ie(this,"blockToPageMap",new Map);Ie(this,"debounceCtrl",new eg);Ie(this,"activeBlockId","");Ie(this,"activePageIndex",1);Ie(this,"currentDocId","");Ie(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t,t&&this.blockToPageMap.delete(t)}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&o.startBlockId!==this.currentDocId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;if(this.activeBlockId=t,t===this.currentDocId){this.debounceCtrl.cancel("cursor-navigate");return}const o=this.getPageByBlockId(t);if(!o){this.debounceCtrl.cancel("cursor-navigate");return}this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Rt=null,xn=null,Sn="";function qi(){var e,t;if(xn&&(clearTimeout(xn),xn=null),Rt){try{Rt.classList.remove("protyle-wysiwyg--select"),Sn?Rt.style.outline=Sn:typeof((e=Rt.style)==null?void 0:e.removeProperty)=="function"?Rt.style.removeProperty("outline"):Rt.style&&(Rt.style.outline=""),typeof((t=Rt.style)==null?void 0:t.removeProperty)=="function"?Rt.style.removeProperty("transition"):Rt.style&&(Rt.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Rt=null,Sn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,a;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((a=i.style)==null?void 0:a.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function Ro(e,t){var a,r,l,c;if(!e||typeof document>"u")return qi(),!1;qi();const o=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return ie.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(l=i.focus)==null||l.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return Sn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Rt=i,xn=setTimeout(()=>{qi()},500),!0}function Ta(e){var i,n,s;const t=typeof document<"u"?document:null,o=e||t;if(!o&&!t)return!1;try{const a=(typeof(o==null?void 0:o.querySelectorAll)=="function"?o.querySelectorAll(".protyle-wysiwyg--select"):null)||(typeof(t==null?void 0:t.querySelectorAll)=="function"?t.querySelectorAll(".protyle-wysiwyg--select"):[]);if(a&&a.length>1){const r=new Set;for(let l=0;l<a.length;l++){const c=a[l],u=typeof c.closest=="function"?c.closest("[data-node-id]"):c,f=(i=u==null?void 0:u.getAttribute)==null?void 0:i.call(u,"data-node-id");f?r.add(f):r.add(`elem-${l}`)}if(r.size>1)return!0}}catch{}try{const a=typeof window<"u"?window:globalThis.window,r=typeof(a==null?void 0:a.getSelection)=="function"?a.getSelection():null;if(r&&r.rangeCount>0&&!r.isCollapsed&&typeof r.getRangeAt=="function"){const l=r.getRangeAt(0);if(l){const c=l.startContainer,u=l.endContainer;if(c&&u&&c!==u){const f=c.nodeType===1?c:c.parentElement,p=u.nodeType===1?u:u.parentElement,d=typeof(f==null?void 0:f.closest)=="function"?f.closest("[data-node-id]"):null,b=typeof(p==null?void 0:p.closest)=="function"?p.closest("[data-node-id]"):null,m=(n=d==null?void 0:d.getAttribute)==null?void 0:n.call(d,"data-node-id"),y=(s=b==null?void 0:b.getAttribute)==null?void 0:s.call(b,"data-node-id");if(m&&y&&m!==y)return!0}}}}catch{}return!1}function og(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>dt(a)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const a=n.map(r=>dt(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${a}</p>`),n=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){s();const l=r[1].length,c=r[2].trim();i.push(`<h${l} class="slide-list-item-title">${dt(c)}</h${l}>`)}else n.push(a)}return s(),i.join(`
`)}function ig(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const a=()=>{if(s.length>0){const r=s.map(l=>dt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else s.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function dc(e,t,o){var p,d,b,m;const i=e.split(`
`);if(!i.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const s=[],a=[];let r=!1;for(let y=0;y<i.length;y++){const g=i[y];if(!g.trim())continue;const v=g.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(v){const k=v[1].length,C=Math.floor(k/2);a.push({type:"task",level:C,checked:v[2].toLowerCase()==="x",text:v[3],media:[]});continue}const x=g.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const k=x[1].length,C=Math.floor(k/2);a.push({type:"unordered",level:C,text:x[2],media:[]});continue}const _=g.match(/^(\s*)\d+\.\s+(.*)$/);if(_){a.length===0&&(r=!0);const k=_[1].length,C=Math.floor(k/2);a.push({type:"ordered",level:C,text:_[2],media:[]});continue}const T=g.trim();if(!(!T||/^\{:.*?\}$/.test(T)))if(a.length>0){const k=T.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(k){const P=/\.gif(?:\?|$)/i.test(k[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(k[1])}" src="${k[2]}" class="${P}" /></div>`);continue}if(T.match(/^<img\b[\s\S]*?\/?>$/i)){const D=T.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${D}</div>`);continue}if(/<video\b/i.test(T)){let D=T;if(!/<\/video>/i.test(D))for(;y+1<i.length&&!/<\/video>/i.test(D);)y++,D+=" "+i[y].trim();const P=((p=o==null?void 0:o.attributes)==null?void 0:p["custom-slides-autoplay"])==="true"||/autoplay/i.test(D),R=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(D),j=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-muted"])==="true"||P||/muted/i.test(D),B=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-controls"])==="false",N=D.match(/\bsrc=["']([^"']+)["']/i),S=N?N[1]:"",Z=['class="slide-video-player"'];B||Z.push("controls"),P&&(Z.push("autoplay"),Z.push("playsinline")),R&&Z.push("loop"),j&&Z.push("muted"),Z.push('preload="metadata"'),S&&Z.push(`src="${S}"`);const W=D.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=W?W[1].trim():"";!$&&S&&($=`<source src="${S}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${P?"true":"false"}" data-muted="${j?"true":"false"}"><video ${Z.join(" ")}>${$}</video></div>`);continue}a[a.length-1].text+=`
`+T}else s.push(T)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(y=>{const g=og(y.text),v=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",x=y.level||0,_=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",T=x>0?" slide-list-item--nested":"";if(y.type==="task"){const C=y.checked?' checked=""':"";return`<li class="pdf-task-item${T}"${_}><label><input type="checkbox" disabled=""${C}/> <span>${g}</span></label>${v}</li>`}return`<li${T?` class="${T.trim()}"`:""}${_}>${g}${v}</li>`}).join(`
`);return`${ig(s)}<${l} class="${c}">
${u}
</${l}>`}function ng(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let a=[];for(let c=0;c<n.length;c++){const u=n[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){a.length>0&&(s.push(a.join(`
`)),a=[]),s.push(f);continue}if(!f){a.length>0&&(s.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){a.length>0&&(s.push(a.join(`
`)),a=[]),s.push(f);continue}if(/<video\b/i.test(f)){a.length>0&&(s.push(a.join(`
`)),a=[]);let p=f;if(!/<\/video>/i.test(p))for(;c+1<n.length&&!/<\/video>/i.test(p);)c++,p+=`
`+n[c];s.push(p);continue}a.push(u)}a.length>0&&s.push(a.join(`
`));let r=!0;return s.map(c=>{var b,m,y,g;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const v=f[1].length;return`<h${v} class="slide-list-item-title">${dt(f[2].trim())}</h${v}>`}const p=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(p){const v=/\.gif(?:\?|$)/i.test(p[2]),x=(t==null?void 0:t.imageClassName)||(v?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(p[1])}" src="${p[2]}" class="${x}" /></div>`}if(/<video\b/i.test(u)){const v=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),x=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),_=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-muted"])==="true"||v||/muted/i.test(u),T=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-controls"])==="false",k=u.match(/\bsrc=["']([^"']+)["']/i),C=k?k[1]:"",D=['class="slide-video-player"'];T||D.push("controls"),v&&D.push("autoplay playsinline"),x&&D.push("loop"),_&&D.push("muted"),D.push('preload="metadata"'),C&&D.push(`src="${C}"`);const P=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let R=P?P[1].trim():"";return!R&&C&&(R=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${_?"true":"false"}"><video ${D.join(" ")}>${R}</video></div>`}const d=dc(u,t,o);if(d)return r=!1,d;if(r){r=!1;const v=u.split(/\r?\n/).map(k=>k.trim()).filter(Boolean);if(v.length===1)return`<p class="slide-list-item-title">${dt(v[0])}</p>`;const x=v[0],T=v.slice(1).map(k=>dt(k)).join("<br/>");return`<p class="slide-list-item-title">${dt(x)}</p>
<p class="slide-list-item-desc">${T}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function ws(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function uc(e,t){var r,l,c,u,f,p,d,b,m,y,g;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(v=>v.slot!=="slot-divider-right"),a=o==="cover"?null:n.find(ws);if(o==="two-cols"){const v=n.some(S=>S.slot==="right");let x=[],_=[];if(v)x=n.filter(S=>S.slot!=="right"),_=n.filter(S=>S.slot==="right");else{const S=Math.ceil(n.length/2);x=n.slice(0,S),_=n.slice(S)}const T=S=>{const Z=S.filter(W=>!!(W.rawMarkdown||W.content||"").trim());if(Z.length>0){const W=Z[0],$=(W.rawMarkdown||W.content||"").trim();(jo(W)||/^(?:[-*+]|\d+\.)\s+/.test($))&&(W.rawMarkdown=ji(W.rawMarkdown||W.content||""),W.content=W.rawMarkdown)}};T(x),T(_);const k=x.map(S=>Tt(S,t)).join(`
`),C=_.map(S=>Tt(S,t)).join(`
`),D=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",P=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",R=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",j=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${vs((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${D}${P}" ${N}>
        <div class="${R}">${k}</div>
        <div class="${j}">${C}</div>
      </div>
    `}if(o==="clover"||fi(o)){const v=o==="clover";let x=[];const _=n.filter(M=>M.slot==="header");if(_.length>0)x=_;else if(n.length>0){const M=n.find(E=>E.type==="h"&&(!E.slot||E.slot==="default"));M&&(x=[M])}const T=n.filter(M=>!x.includes(M));let k=2;if(v)k=4;else if(o==="three-cols-header")k=3;else if(o==="two-cols-header")k=2;else{let M=0;for(const E of T){const Q=(E.slot||"").match(/^col-(\d+)$/i);Q&&(M=Math.max(M,parseInt(Q[1],10)))}if(M>=2)k=M;else if((u=e.frontmatter)!=null&&u.layoutRatio){const E=e.frontmatter.layoutRatio.trim();if(E.includes(":")){const Q=E.split(":").map(F=>parseFloat(F.trim())).filter(F=>!isNaN(F)&&F>0);Q.length>=2&&(k=Q.length)}else{const Q=E.split(/\s+/).filter(Boolean);Q.length>=2&&(k=Q.length)}}else T.length===1&&T[0].children&&T[0].children.length>=2&&(k=Math.min(6,T[0].children.length))}const C=Ks(T,k),D=T.some(M=>M.slot&&/^(?:col-\d+|left|right)$/i.test(M.slot)),P=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||fi(o)&&D,R=M=>{const E=M.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(P&&E.length>0){const F=E[0],V=(F.rawMarkdown||F.content||"").trim();(jo(F)||/^(?:[-*+]|\d+\.)\s+/.test(V))&&(F.rawMarkdown=ji(F.rawMarkdown||F.content||""),F.content=F.rawMarkdown),F.isColFirst=!0}const Q=P?E.find(ws):null;return E.map(F=>Tt(F,{...t,extraClassName:F===Q?"slides-col-first-heading-block":""})).join(`
`)},j=x.find(ws),B=x.map(M=>Tt(M,{...t,extraClassName:M===j?"slides-page-first-heading-block":""})).join(`
`),N=v?"repeat(2, minmax(0, 1fr))":vs((f=e.frontmatter)==null?void 0:f.layoutRatio,k),S=v?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,Z=[v?"layout-clover-container":"layout-cols-header-container",k===2?"layout-two-cols-header-container":"",k===3?"layout-three-cols-header-container":"",`layout-${o}-container`,P?"has-superblock-cols":""].filter(Boolean).join(" "),W=[v?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",k===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",k===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",P?"has-superblock-cols":""].filter(Boolean).join(" "),$=C.map((M,E)=>{const Q=E+1;return`<div class="${["pdf-col",k===2&&Q===1?"pdf-col--left":"",k===2&&Q===2?"pdf-col--right":"",`pdf-col--${Q}`,`col-${Q}`].filter(Boolean).join(" ")}">${R(M)}</div>`}).join(`
`);return`
      <div class="${Z}">
        <div class="layout-header-section">${B}</div>
        <div class="${W}" ${S}>
          ${$}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const v=o==="image-right",x=n.map(P=>Tt(P,t)).join(`
`),_=((p=e.frontmatter)==null?void 0:p.image)||((d=e.frontmatter)==null?void 0:d.background)||"",T=`<div class="pdf-image-col" style="background-image:url('${nt(_)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(_)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,k=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${x}</div>`,C=v?`${k}
${T}`:`${T}
${k}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${vs((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${C}
      </div>
    `}if(o==="fact"){const v=n.filter(C=>!!(C.rawMarkdown||C.content||"").trim()),x=v[0],_=v.slice(1),T=x?Tt(x,{...t,extraClassName:"fact-value"}):"",k=_.map(C=>Tt(C,{...t,extraClassName:"fact-label"})).join(`
`);return`
      <div class="layout-fact-container">
        <div class="fact-hero-glow" aria-hidden="true"></div>
        <div class="fact-content-box">
          <div class="fact-value-wrapper">${T}</div>
          ${k?`<div class="fact-divider-line"></div><div class="fact-label-wrapper">${k}</div>`:""}
        </div>
      </div>
    `}if(o==="timeline"||o==="steps"){let v=[];const x=n.filter(P=>P.slot==="header");if(x.length>0)v=x;else if(n.length>0){const P=n.find(R=>R.type==="h"&&(!R.slot||R.slot==="default"));P&&(v=[P])}const _=n.filter(P=>!v.includes(P)),T=v.map(P=>Tt(P,{...t,extraClassName:"slides-page-first-heading-block"})).join(`
`);let k=[];if(_.length===1&&_[0].children&&_[0].children.length>=2)k=_[0].children;else if(_.length>=2)k=_;else if(_.length===1){const R=(_[0].rawMarkdown||_[0].content||"").trim().split(`
`).filter(j=>/^(\s*)([-*+]|\d+\.)\s+/.test(j));R.length>=2?k=R.map((j,B)=>({id:`${_[0].id}-step-${B}`,type:"p",rawMarkdown:j.replace(/^(\s*)([-*+]|\d+\.)\s+/,"").trim(),content:j.replace(/^(\s*)([-*+]|\d+\.)\s+/,"").trim()})):k=_}const C=Math.max(1,Math.min(6,k.length)),D=k.map((P,R)=>{const j=R+1,B=Tt(P,t);return`
        <div class="timeline-step-item" style="--step-index: ${j};">
          <div class="timeline-node-container">
            <div class="timeline-node-badge">${j}</div>
            ${j<k.length?'<div class="timeline-connector-line"></div>':""}
          </div>
          <div class="timeline-step-content">${B}</div>
        </div>
      `}).join(`
`);return`
      <div class="layout-timeline-container layout-steps-container">
        ${T?`<div class="layout-header-section">${T}</div>`:""}
        <div class="timeline-track-wrapper" style="--timeline-steps: ${C};">
          ${D}
        </div>
      </div>
    `}if(o==="quote"){const v=n.filter(C=>!!(C.rawMarkdown||C.content||"").trim());let x=v,_=null;if(v.length>=2){const C=v[v.length-1],D=(C.rawMarkdown||C.content||"").trim();(/^(?:—|--|——|-)\s*/.test(D)||((m=C.ial)==null?void 0:m["custom-slides-role"])==="author")&&(_=C,x=v.slice(0,-1))}const T=x.map(C=>Tt(C,{...t,extraClassName:"quote-body"})).join(`
`),k=_?Tt(_,{...t,extraClassName:"quote-author"}):"";return`
      <div class="layout-quote-container">
        <div class="quote-watermark-icon" aria-hidden="true">“</div>
        <div class="quote-content-body">
          <div class="quote-text">${T}</div>
          ${k?`<div class="quote-footer">${k}</div>`:""}
        </div>
      </div>
    `}if(o==="intro"){const v=((y=e.frontmatter)==null?void 0:y.image)||((g=e.frontmatter)==null?void 0:g.background)||"",_=n.filter(k=>{const C=(k.rawMarkdown||k.content||"").trim();return!(v&&C.includes(v))}).map(k=>Tt(k,t)).join(`
`);return`
      <div class="layout-intro-container">
        <div class="intro-avatar-col">${v?`<div class="intro-avatar-box"><img class="intro-avatar-img" src="${nt(v)}" alt="Avatar" onerror="this.style.display='none'" /></div>`:'<div class="intro-avatar-box intro-avatar-box--placeholder"><svg class="intro-avatar-svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg></div>'}</div>
        <div class="intro-info-col">${_}</div>
      </div>
    `}return o==="center"?`<div class="layout-center-container">${n.map(x=>Tt(x,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(x=>Tt(x,t)).join(`
`)}</div>`:n.map(v=>Tt(v,{...t,extraClassName:v===a?"slides-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function sg(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,a]=n.split("-"),r=parseInt(s,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const rg=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=ic(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,a)=>{const r=a.toLowerCase();if(!rg.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const l=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=nt(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,a,r,l,c,u,f)=>{const d=(r??l??c??u??f??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,a)=>{const r=parseInt(a,10);return o[r]||""}),n}function ag(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(l=>/^:?-+:?$/.test(l))&&(n=o[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),s=2);const a=`<thead><tr>${i.map((l,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(l)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(l=>`<tr>${l.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function xs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Aa(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${xs(e)}</span>`;const o=[];function i(s,a){return o.push(`<span class="${s}">${xs(a)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,a,r)=>i("token-string",`${a}${r}${a}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=xs(n),n=n.replace(/__TOK_(\d+)__/g,(s,a)=>o[parseInt(a,10)]||""),n}function lg(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const a of s){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){n||(n=l[1].length),i=l[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function cg(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=lg(c,u+1);f&&s.push(f)});const a=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>n)return[];const f=[];for(const p of c){const d=l(p.children,u+1);u>=i?f.push({...p,children:d}):f.push(...d)}return f}return l(a,1)}function dg(e,t=1,o={}){const i=cg(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",a=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,p=c.map(d=>{const b=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let y=dt(d.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${y}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${p}</ol>`}const l=r(i,1);return`<div class="slides-toc${a}"${s}>${l}</div>`}function Tt(e,t){var T,k,C,D,P,R,j,B,N,S,Z,W;let o="",i="",n="";const s=[];(T=e.motion)!=null&&T.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const a=((k=e.attributes)==null?void 0:k.style)||"";a&&(s.push(a),n=" slide-styled-block"),s.length>0&&(i=` style="${nt(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${o}${n}${l}${u}`,p=(e.rawMarkdown||e.content||"").trim();if(!p)return`<div class="${f}"${i}></div>`;if(p.includes('class="slides-block-ref"')||p.includes('class="slides-ref-tag"'))return`<div class="${f}"${i}>${p}</div>`;if(p.startsWith("$$")&&p.endsWith("$$")){const $=p.slice(2,-2).trim();return`<div class="${f} katex-display-container"${i}><div class="katex-display font-math"><em>${nt($)}</em></div></div>`}const d=p.match(/^(#{1,6})\s+(.*)$/);if(d){const $=d[1].length,M=dt(d[2]),Q=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><h${$}${Q}>${M}</h${$}></div>`}if(p.startsWith(":::")){const $=p.split(`
`),E=$[0].replace(/^:::\s*/,"").trim()||"info",Q=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),F=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${i}><div class="${F} ${F}--${E}"><div class="${F}-title">${E.toUpperCase()}</div><div class="${F}-body">${dt(Q)}</div></div></div>`}if(p.startsWith("<<<")){const E=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,ae)=>`<span class="code-line shiki-focus"><span class="line-no">${ae+1}</span><span class="line-content">${Aa(oe,"ts")}</span></span>`).join(`
`),Q=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",F=((D=e.attrs)==null?void 0:D["custom-slides-max-height"])||((P=e.attributes)==null?void 0:P["custom-slides-max-height"])||e.maxHeight||"",V=Vs(String(F||"")),re=V?` style="max-height:${nt(V)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${Q}"${re}><span class="lang-badge">TS</span><code>${E}</code></pre></div>`}if(p.startsWith("<style")||p.startsWith("<!-- Inline style -->")||p.startsWith(`<!--
Notes`))return"";if(p.startsWith("```")){const $=p.split(`
`),M=$[0].slice(3).trim(),E=M.match(/^([^\s{\[]+)/),Q=E?E[1]:"",F=M.match(/\[([^\]]+)\]/),V=F?F[1]:"",re=M.includes("twoslash"),oe=e.shikiLines||((R=M.match(/\{([^}]+)\}/))==null?void 0:R[1])||"",ae=sg(oe),Se=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[p.slice(3).replace(/```$/,"")],$e=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=V?`${$e} has-filename`:$e,Ce=ae!=="all",z=Se.map((H,I)=>{const A=I+1,G=ae==="all"||ae.has(A)?"code-line shiki-focus":Ce?"code-line shiki-dimmed":"code-line";let Y=(t==null?void 0:t.highlight)===!0?Aa(H,Q):nt(H);return re&&H.includes("doubled.value = 2")?(Y=Y.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${A}</span><span class="line-content">${Y}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${A}</span><span class="line-content">${Y}</span></span>`}).join(`
`),ne=Q?`<span class="lang-badge">${nt(Q)}</span>`:"",L=V?`<span class="code-filename">${nt(V)}</span>`:"",U=((j=e.attrs)==null?void 0:j["custom-slides-max-height"])||((B=e.attributes)==null?void 0:B["custom-slides-max-height"])||e.maxHeight||"",w=Vs(String(U||"")),q=w?` style="max-height:${nt(w)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${ke}"${q}>${L}${ne}<code>${z}</code></pre></div>`}if(p.includes("|")&&p.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=p.split(`
`).filter(E=>E.trim().startsWith("|")),M=ag($,t==null?void 0:t.tableClassName);return`<div class="${f}"${i}>${M}</div>`}if(p.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${i}><blockquote class="${$}"><p>${dt(p.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(p)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(p),y=/(?:^|\n)\s*#{1,6}\s+/.test(p);if(b&&!m&&!y&&!p.includes(`
`)){const $=((N=e.attributes)==null?void 0:N["custom-slides-autoplay"])==="true"||/autoplay/i.test(p),M=((S=e.attributes)==null?void 0:S["custom-slides-loop"])==="true"||/loop/i.test(p),E=((Z=e.attributes)==null?void 0:Z["custom-slides-muted"])==="true"||$||/muted/i.test(p),Q=((W=e.attributes)==null?void 0:W["custom-slides-controls"])==="false",F=p.match(/\bsrc=["']([^"']+)["']/i),V=F?F[1]:"",re=['class="slide-video-player"'];Q||re.push("controls"),$&&(re.push("autoplay"),re.push("playsinline")),M&&re.push("loop"),E&&re.push("muted"),re.push('preload="auto"'),V&&re.push(`src="${V}"`);const oe=p.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let ae=oe?oe[1].trim():"";return!ae&&V&&(ae=`<source src="${V}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${E?"true":"false"}"${i}><video ${re.join(" ")}>${ae}</video></div>`}const g=p.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${i}><img alt="${nt(g[1])}" src="${g[2]}" class="${$}" /></div>`}const v=dc(p,t,e);if(v)return`<div class="${f} pdf-list-item"${i}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(p)&&!p.startsWith("```")){const $=p.match(/minDepth=["']?(\d+)["']?/i),M=p.match(/maxDepth=["']?(\d+)["']?/i),E=p.match(/columns=["']?(\d+)["']?/i),Q=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${i}>${dg(Q,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:M?parseInt(M[1],10):1/0,columns:E?parseInt(E[1],10):1,textSm:p.includes("text-sm")})}</div>`}if(p.includes(`
`)||y){const $=ng(p,t,e);if($)return`<div class="${f}"${i}>${$}</div>`}const _=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><p${_}>${dt(p)}</p></div>`}function ug(e){return`
    ${Wi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    /* Cover, Center, Fact, Quote, Intro 版式样式全链路对齐 */
    .layout-cover,
    .layout-center,
    .layout-fact,
    .layout-cover-container,
    .layout-center-container,
    .layout-fact-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      min-height: 0;
      box-sizing: border-box;
      flex: 1;
    }

    .layout-cover h1, .layout-cover .slide-block h1, .layout-cover-container h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2, .layout-cover-container h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p, .layout-cover-container p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }

    /* Center 版式：保持标准字阶梯但全屏绝对居中对齐 */
    .layout-center-container { padding: 40px 60px; }
    .layout-center-container h1, .layout-center h1 { font-size: 2.8rem !important; font-weight: 700 !important; margin-bottom: 16px !important; }
    .layout-center-container p, .layout-center p { font-size: 1.35rem !important; line-height: 1.6 !important; max-width: 800px; margin-left: auto; margin-right: auto; }

    /* Fact 大字报版式：震撼巨型数字看板与径向光晕氛围 */
    .layout-fact,
    .layout-fact-container {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 40px;
      overflow: hidden;
    }
    .fact-hero-glow {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 600px;
      height: 600px;
      transform: translate(-50%, -50%);
      background: radial-gradient(circle, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.22) 0%, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.05) 45%, transparent 70%);
      pointer-events: none;
      filter: blur(20px);
      z-index: 0;
    }
    .fact-content-box {
      position: relative;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      max-width: 900px;
    }
    .fact-value-wrapper,
    .layout-fact-container .fact-value,
    .layout-fact .fact-value,
    .layout-fact .slide-block:first-child,
    .layout-fact-container h1,
    .layout-fact h1 {
      font-size: clamp(5.5rem, 11vw, 8.5rem) !important;
      font-weight: 900 !important;
      line-height: 1.05 !important;
      letter-spacing: -0.03em !important;
      color: var(--slide-accent) !important;
      background: linear-gradient(135deg, var(--slide-accent), #60a5fa) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
      filter: drop-shadow(0 4px 20px rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.35));
      margin-bottom: 8px !important;
    }
    .fact-value-wrapper p,
    .layout-fact-container .fact-value p,
    .layout-fact .fact-value p,
    .layout-fact .slide-block:first-child p {
      font-size: inherit !important;
      font-weight: inherit !important;
      line-height: inherit !important;
      color: inherit !important;
      background: inherit !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
      margin: 0 !important;
    }
    .fact-divider-line {
      width: 72px;
      height: 4px;
      border-radius: 2px;
      background: var(--slide-accent);
      opacity: 0.8;
      margin: 18px auto 20px;
    }
    .fact-label-wrapper,
    .layout-fact-container .fact-label,
    .layout-fact .fact-label,
    .layout-fact .slide-block:not(:first-child),
    .layout-fact-container p,
    .layout-fact p {
      font-size: 1.75rem !important;
      font-weight: 500 !important;
      opacity: 0.88 !important;
      letter-spacing: 0.04em !important;
      max-width: 780px;
      line-height: 1.5 !important;
    }

    /* Timeline / Steps 时间线与步骤流程版式 */
    .layout-timeline-container,
    .layout-steps-container,
    .slide-content-wrapper.layout-timeline,
    .slide-content-wrapper.layout-steps {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 32px 56px;
      overflow: hidden;
      flex: 1;
    }
    .timeline-track-wrapper {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      justify-content: space-between;
      width: 100%;
      flex: 1;
      gap: 24px;
      margin-top: auto;
      margin-bottom: auto;
      padding: 24px 0 36px;
      position: relative;
    }
    .timeline-step-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      min-width: 0;
      position: relative;
      text-align: center;
    }
    .timeline-node-container {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      margin-bottom: 24px;
    }
    .timeline-node-badge {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: var(--slide-accent, var(--b3-theme-primary));
      color: #ffffff;
      font-size: 1.35rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 16px rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.4);
      z-index: 2;
      flex-shrink: 0;
      transition: all 0.2s ease;
    }
    .timeline-connector-line {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 100%;
      height: 3px;
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6), rgba(125, 125, 125, 0.25));
      transform: translateY(-50%);
      z-index: 1;
    }
    .timeline-step-content {
      width: 100%;
      padding: 16px;
      background: rgba(125, 125, 125, 0.05);
      border: 1px solid rgba(125, 125, 125, 0.12);
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      backdrop-filter: blur(6px);
    }
    .timeline-step-content h1,
    .timeline-step-content h2,
    .timeline-step-content h3,
    .timeline-step-content h4 {
      font-size: 1.35rem !important;
      font-weight: 700 !important;
      margin-bottom: 8px !important;
      color: var(--b3-theme-on-surface);
    }
    .timeline-step-content p,
    .timeline-step-content li {
      font-size: 1.05rem !important;
      line-height: 1.55 !important;
      opacity: 0.85;
      margin-bottom: 4px;
    }
    .timeline-step-content ul {
      padding-left: 0;
      list-style: none;
    }

    /* Quote 引言版式：居中大字、衬线字体、水印双引号与右对齐出处 */
    .layout-quote,
    .layout-quote-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      position: relative;
      box-sizing: border-box;
      padding: 48px 72px;
      overflow: hidden;
      flex: 1;
    }
    .quote-watermark-icon {
      position: absolute;
      top: 10%;
      left: 8%;
      font-size: 16rem;
      line-height: 1;
      font-family: Georgia, serif;
      opacity: 0.08;
      pointer-events: none;
      user-select: none;
      color: currentColor;
    }
    .quote-content-body {
      position: relative;
      z-index: 1;
      max-width: 850px;
      width: 100%;
      text-align: center;
    }
    .quote-text,
    .layout-quote-container .quote-body {
      font-size: 2.2rem !important;
      font-style: italic !important;
      line-height: 1.6 !important;
      font-family: var(--slides-font-serif, "Noto Serif SC", Georgia, serif) !important;
      letter-spacing: 0.01em;
      margin-bottom: 24px !important;
    }
    .quote-text p,
    .layout-quote-container .quote-body p {
      font-size: inherit !important;
      font-style: inherit !important;
      line-height: inherit !important;
    }
    .quote-footer,
    .quote-author {
      font-size: 1.25rem !important;
      opacity: 0.75 !important;
      text-align: right !important;
      font-style: normal !important;
      letter-spacing: 0.05em;
    }

    /* Intro 个人/章节介绍版式：头像配图与右侧个人履历卡片 */
    .layout-intro,
    .layout-intro-container {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: 56px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 40px 64px;
      overflow: hidden;
      flex: 1;
    }
    .intro-avatar-col {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-box {
      width: 240px;
      height: 240px;
      border-radius: 50%;
      overflow: hidden;
      box-shadow: 0 16px 36px rgba(0, 0, 0, 0.16);
      border: 4px solid rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.35);
      background: rgba(125, 125, 125, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .intro-avatar-svg {
      width: 120px;
      height: 120px;
      opacity: 0.35;
      fill: currentColor;
    }
    .intro-info-col {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .intro-info-col h1 {
      font-size: 3rem !important;
      font-weight: 800 !important;
      line-height: 1.2 !important;
      margin-bottom: 8px !important;
    }
    .intro-info-col h2, .intro-info-col h3 {
      font-size: 1.5rem !important;
      font-weight: 600 !important;
      color: var(--slide-accent) !important;
      margin-bottom: 16px !important;
    }
    .intro-info-col p {
      font-size: 1.25rem !important;
      line-height: 1.6 !important;
      opacity: 0.9 !important;
    }
    .intro-info-col ul {
      margin-top: 12px;
      padding-left: 20px;
    }
    .intro-info-col li {
      font-size: 1.15rem !important;
      line-height: 1.6 !important;
      margin-bottom: 6px;
      opacity: 0.9 !important;
    }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function fg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function hg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function pg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function mg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ \\t]*[-*+]\\s+|^[ \\t]*\\d+\\.\\s+/, "");
        cleaned = cleaned.replace(/\\n[ \\t]{2,4}/g, "\\n");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}\\s+/.test(md)) return true;
        if (/^(?:[-*+]|\\d+\\.)\\s+#{1,6}\\s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|\\d+\\.)\\s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const allInteractive = div.querySelectorAll("*");
          allInteractive.forEach(btn => {
            let hasNext = false;
            let hasPrev = false;
            for (let i = 0; i < btn.attributes.length; i++) {
              const a = btn.attributes[i];
              const attrName = a.name.toLowerCase();
              if (attrName.indexOf("@click") !== -1 || attrName.indexOf("v-on:click") !== -1) {
                if (a.value.indexOf("next") !== -1) hasNext = true;
                if (a.value.indexOf("prev") !== -1) hasPrev = true;
              }
            }
            if (hasNext) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex + 1);
              });
            } else if (hasPrev) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex - 1);
              });
            }
          });

          return div;
        }

        const hasHeadingTag = /(?:^|\\n)\\s*#{1,6}\\s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\\x60\\x60\\x60")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) && !hasHeadingTag && !md.includes("\\n")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) ||
          (md.includes("\\n") && /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md.split("\\n").slice(1).join("\\n"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("\\n");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^\\{:.*?\\}$/.test(tr)) continue;
            const um = line.match(/^(\\s*)[-*+]\\s+(.*)$/);
            const om = line.match(/^(\\s*)\\d+\\.\\s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^!\\[(.*?)\\]\\((.*?)\\)(?:\\{:?[^}]*\\})?$/);
              if (im) {
                const isGif = /\\.gif(?:\\?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\\b[\\s\\S]*?\\/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/\\s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\\b/i.test(tr)) {
                let vHtml = tr;
                if (!/<\\/video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/<\\/video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "\\n" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})\\s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})\\s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("\\n") + "\\n";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "\\n" + it.media.join("\\n") : "";
            const lines = (it.text || "").split("\\n").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}\\s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("\\n") + med + '</li>';
          }).join("\\n");
          div.innerHTML = leadHtml + '<' + tag + ' class="' + listCls + '">\\n' + liHtml + '\\n</' + tag + '>';
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\\r?\\n/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}\\s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              continue;
            }
            if (/^!\\[.*?\\]\\(.*?\\)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              let vRaw = trimmed;
              if (!/<\\/video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/<\\/video>/i.test(vRaw)) {
                  i++;
                  vRaw += "\\n" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("\\n"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}\\s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\\r?\\n/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>\\n<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("\\n");
          } else {
            const imgMatch = md.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }
`}function gg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "fact") {
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const first = validBlocks[0];
          const rest = validBlocks.slice(1);

          const factContainer = document.createElement("div");
          factContainer.className = "layout-fact-container";

          const glow = document.createElement("div");
          glow.className = "fact-hero-glow";
          glow.setAttribute("aria-hidden", "true");
          factContainer.appendChild(glow);

          const box = document.createElement("div");
          box.className = "fact-content-box";

          if (first) {
            const valWrap = document.createElement("div");
            valWrap.className = "fact-value-wrapper";
            valWrap.appendChild(renderBlock(first, ""));
            box.appendChild(valWrap);
          }

          if (rest.length > 0) {
            const divLine = document.createElement("div");
            divLine.className = "fact-divider-line";
            box.appendChild(divLine);

            const lblWrap = document.createElement("div");
            lblWrap.className = "fact-label-wrapper";
            for (const b of rest) {
              lblWrap.appendChild(renderBlock(b, ""));
            }
            box.appendChild(lblWrap);
          }

          factContainer.appendChild(box);
          container.appendChild(factContainer);
        } else if (slide.frontmatter?.layout === "timeline" || slide.frontmatter?.layout === "steps") {
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          const tlContainer = document.createElement("div");
          tlContainer.className = "layout-timeline-container layout-steps-container";

          if (headerBlocks.length > 0) {
            const headerDiv = document.createElement("div");
            headerDiv.className = "layout-header-section";
            for (const hb of headerBlocks) {
              headerDiv.appendChild(renderBlock(hb, "slides-page-first-heading-block"));
            }
            tlContainer.appendChild(headerDiv);
          }

          let stepItems = rem;
          if (rem.length === 1 && rem[0].children && rem[0].children.length >= 2) {
            stepItems = rem[0].children;
          }

          const track = document.createElement("div");
          track.className = "timeline-track-wrapper";
          track.style.setProperty("--timeline-steps", String(Math.max(1, Math.min(6, stepItems.length))));

          stepItems.forEach((item, idx) => {
            const stepNum = idx + 1;
            const itemEl = document.createElement("div");
            itemEl.className = "timeline-step-item";
            itemEl.style.setProperty("--step-index", String(stepNum));

            const nodeContainer = document.createElement("div");
            nodeContainer.className = "timeline-node-container";

            const badge = document.createElement("div");
            badge.className = "timeline-node-badge";
            badge.textContent = String(stepNum);
            nodeContainer.appendChild(badge);

            if (idx < stepItems.length - 1) {
              const line = document.createElement("div");
              line.className = "timeline-connector-line";
              nodeContainer.appendChild(line);
            }
            itemEl.appendChild(nodeContainer);

            const contentEl = document.createElement("div");
            contentEl.className = "timeline-step-content";
            contentEl.appendChild(renderBlock(item, ""));
            itemEl.appendChild(contentEl);

            track.appendChild(itemEl);
          });

          tlContainer.appendChild(track);
          container.appendChild(tlContainer);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function yg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function bg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function vg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else if (layout === "fact") {
          bodyEl = document.createElement("div");
          bodyEl.className = "layout-fact-container";
          const glow = document.createElement("div");
          glow.className = "fact-hero-glow";
          bodyEl.appendChild(glow);
          const box = document.createElement("div");
          box.className = "fact-content-box";
          if (blocks.length > 0) {
            const vWrap = document.createElement("div");
            vWrap.className = "fact-value-wrapper";
            vWrap.appendChild(renderBlock(blocks[0], ""));
            box.appendChild(vWrap);
          }
          if (blocks.length > 1) {
            const divLine = document.createElement("div");
            divLine.className = "fact-divider-line";
            box.appendChild(divLine);
            const lWrap = document.createElement("div");
            lWrap.className = "fact-label-wrapper";
            for (let i = 1; i < blocks.length; i++) lWrap.appendChild(renderBlock(blocks[i], ""));
            box.appendChild(lWrap);
          }
          bodyEl.appendChild(box);
        } else if (layout === "timeline" || layout === "steps") {
          bodyEl = document.createElement("div");
          bodyEl.className = "layout-timeline-container";
          const track = document.createElement("div");
          track.className = "timeline-track-wrapper";
          let stepItems = blocks;
          if (blocks.length === 1 && blocks[0].children && blocks[0].children.length >= 2) {
            stepItems = blocks[0].children;
          }
          stepItems.forEach((item, idx) => {
            const stepEl = document.createElement("div");
            stepEl.className = "timeline-step-item";
            const node = document.createElement("div");
            node.className = "timeline-node-container";
            const badge = document.createElement("div");
            badge.className = "timeline-node-badge";
            badge.textContent = String(idx + 1);
            node.appendChild(badge);
            stepEl.appendChild(node);
            const content = document.createElement("div");
            content.className = "timeline-step-content";
            content.appendChild(renderBlock(item, ""));
            stepEl.appendChild(content);
            track.appendChild(stepEl);
          });
          bodyEl.appendChild(track);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|\\/|data:|assets\\/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function kg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function wg(){return[fg(),hg(),pg(),mg(),gg(),yg(),bg(),vg(),kg()].join("")}function xg(e,t=!1){var a;const o=new Set,i=r=>{if(!r||typeof r!="string")return;const l=r.trim();!l||l.startsWith("data:")||(l.includes("/assets/")||l.startsWith("assets/")||l.startsWith("./assets/")||l.startsWith("/assets/")||t&&/^https?:\/\//i.test(l))&&o.add(l)},n=r=>{if(!r||typeof r!="string")return;const l=/!\[.*?\]\((.+?)\)/g;let c;for(;(c=l.exec(r))!==null;)c[1]&&i(c[1]);const u=/<(?:img|video|audio|source)\b[^>]*?\bsrc=["'](.*?)["']/gi;for(;(c=u.exec(r))!==null;)c[1]&&i(c[1]);const f=/url\(\s*["']?(.*?)["']?\s*\)/gi;for(;(c=f.exec(r))!==null;)c[1]&&i(c[1])},s=r=>{if(r&&(r.rawMarkdown&&n(r.rawMarkdown),r.content&&n(r.content),Array.isArray(r.children)))for(const l of r.children)s(l)};(a=e.config)!=null&&a.background&&i(e.config.background);for(const r of e.slides||[]){if(r.frontmatter)for(const l of Object.values(r.frontmatter))typeof l=="string"&&i(l);if(r.rawMarkdown&&n(r.rawMarkdown),Array.isArray(r.blocks))for(const l of r.blocks)s(l);if(Array.isArray(r.noteBlocks))for(const l of r.noteBlocks)s(l);r.notes&&n(r.notes)}try{const r=JSON.stringify(e),l=/(?:https?:\/\/[^\s"'<>\)\\]+)?(?:\.\/|\/)?assets\/[^\s"'<>\)\\]+/g,c=r.match(l);if(c)for(const u of c)i(u);if(t){const u=/https?:\/\/[^\s"'<>\)\\]+\.(?:png|jpe?g|gif|webp|svg|avif|ico|bmp)(?:\?[^\s"'<>\)\\]*)?/gi,f=r.match(u);if(f)for(const p of f)i(p)}}catch{}return Array.from(o)}async function Ys(e){if(typeof FileReader<"u")return new Promise((n,s)=>{const a=new FileReader;a.onloadend=()=>{typeof a.result=="string"?n(a.result):s(new Error("Failed to convert blob to data URL"))},a.onerror=()=>s(a.error||new Error("FileReader error")),a.readAsDataURL(e)});const t=await e.arrayBuffer(),o=Buffer.from(t);return`data:${e.type||"image/png"};base64,${o.toString("base64")}`}async function Ma(e){if(typeof e=="string")return e.startsWith("data:")?e:`data:image/png;base64,${e}`;if(e instanceof ArrayBuffer){const t=new Blob([e]);return Ys(t)}return e instanceof Blob?Ys(e):""}async function Sg(e,t){var a,r;const o=xg(e,t==null?void 0:t.includeRemote);if(o.length===0)return{};const i={},n=typeof window<"u"&&((r=(a=window.siyuan)==null?void 0:a.config)==null?void 0:r.apiToken)||"",s=n?{Authorization:`Token ${n}`}:{};for(const l of o){let c="",u=!1;const f=l.indexOf("/assets/");f!==-1?(c=l.slice(f+1),u=!0):l.startsWith("assets/")?(c=l,u=!0):l.startsWith("./assets/")?(c=l.slice(2),u=!0):l.startsWith("/assets/")&&(c=l.slice(1),u=!0);try{let p=null;if(t!=null&&t.fetcher){const d=await t.fetcher(l).catch(()=>null);if(d)p=await Ma(d);else if(c&&c!==l){const b=await t.fetcher(`/${c}`).catch(()=>null);b&&(p=await Ma(b))}}else if(typeof fetch<"u"){const d=[];(l.startsWith("http://")||l.startsWith("https://"))&&d.push({url:l,headers:u?s:void 0}),u&&c&&(d.push({url:`/${c}`,headers:s}),d.push({url:`./${c}`,headers:s}),d.push({url:c,headers:s})),u||d.push({url:l});for(const b of d)try{const m=await fetch(b.url,{credentials:"include",headers:b.headers});if(m.ok){const y=await m.blob();if(p=await Ys(y),p)break}}catch{}}if(p){const d=[l];c&&d.push(`/${c}`,`./${c}`,c);for(const b of d){i[b]=p;try{i[decodeURI(b)]=p,i[encodeURI(b)]=p}catch{}}}}catch(p){console.warn(`[single-html-exporter] Failed to inline asset "${l}":`,p)}}return i}function Cg(e,t){const o=(t==null?void 0:t.title)||"即现文稿";let i=e.slides,n={...e.config},s=e.customThemeCss;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const c=t.inlineAssetBase64Map,u=Object.entries(c).sort((d,b)=>b[0].length-d[0].length),f=d=>{if(!d||typeof d!="string")return d;let b=d;for(const[m,y]of u)b.includes(m)&&(b=b.split(m).join(y));return b},p=d=>{const b=f(d.rawMarkdown||""),m=f(d.content||""),y=Array.isArray(d.children)?d.children.map(g=>p(g)):d.children;return{...d,rawMarkdown:b,content:m,children:y}};n.background&&typeof n.background=="string"&&(n.background=f(n.background)),s&&(s=f(s)),i=(e.slides||[]).map(d=>{const b=f(d.rawMarkdown||""),m=(d.blocks||[]).map(p),y=Array.isArray(d.noteBlocks)?d.noteBlocks.map(p):d.noteBlocks,g=f(d.notes||"");let v=d.frontmatter?{...d.frontmatter}:d.frontmatter;if(v)for(const[x,_]of Object.entries(v))typeof _=="string"&&(v[x]=f(_));return{...d,rawMarkdown:b,blocks:m,noteBlocks:y,notes:g,frontmatter:v}})}const a=_r(n.colorSchema),r=JSON.stringify(i),l=JSON.stringify({...n,hostThemeMode:n.hostThemeMode||a});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(o)}</title>
  <style>
${ug(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${r},
      config: ${l}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${a}" data-normalize-headings="${n.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${n.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${n.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${n.theme||"apple-basic"}" id="viewport" data-theme="${a}" data-slides-theme="${n.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${wg()}
  <\/script>
</body>
</html>`}async function fc(e,t){let o=t==null?void 0:t.inlineAssetBase64Map;return(!o||Object.keys(o).length===0)&&(o=await Sg(e,t)),Cg(e,{...t,inlineAssetBase64Map:o})}function hc(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function _g(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Ig(e){const t=_g(e==null?void 0:e.pageRatio);return`
    ${Wi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body,
    .layout-center .pdf-slide-body,
    .layout-fact .pdf-slide-body,
    .layout-cover-container,
    .layout-center-container,
    .layout-fact-container {
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    .layout-cover h1,
    .layout-cover-container h1 {
      font-size: 3.2rem;
      font-weight: 800;
      margin-bottom: 16px;
    }
    .layout-center-container h1,
    .layout-center h1 {
      font-size: 2.6rem;
      font-weight: 700;
    }
    .layout-fact .fact-value,
    .layout-fact-container .fact-value,
    .layout-fact .fact-value-wrapper,
    .layout-fact h1,
    .layout-fact-container h1 {
      font-size: 5.5rem;
      font-weight: 900;
      color: var(--slide-accent, #ef4444);
      margin-bottom: 8px;
      line-height: 1.05;
    }
    .layout-fact .fact-divider-line,
    .layout-fact-container .fact-divider-line {
      width: 60px;
      height: 3px;
      background: var(--slide-accent, #ef4444);
      margin: 12px auto 16px;
    }
    .layout-fact .fact-label,
    .layout-fact-container .fact-label,
    .layout-fact .fact-label-wrapper {
      font-size: 1.55rem;
      opacity: 0.88;
      line-height: 1.4;
    }

    /* Timeline / Steps 时间线 (PDF 导出) */
    .layout-timeline-container,
    .layout-steps-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 28px 48px;
    }
    .timeline-track-wrapper {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      justify-content: space-between;
      width: 100%;
      gap: 20px;
      margin: auto 0;
      position: relative;
    }
    .timeline-step-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      text-align: center;
      position: relative;
    }
    .timeline-node-container {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      margin-bottom: 18px;
    }
    .timeline-node-badge {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: var(--slide-accent, #3b82f6);
      color: #ffffff;
      font-size: 1.2rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2;
    }
    .timeline-connector-line {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 100%;
      height: 2px;
      background: #94a3b8;
      transform: translateY(-50%);
      z-index: 1;
    }
    .timeline-step-content {
      width: 100%;
      padding: 12px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      box-sizing: border-box;
    }
    .timeline-step-content h1,
    .timeline-step-content h2,
    .timeline-step-content h3 {
      font-size: 1.2rem !important;
      font-weight: 700 !important;
      margin-bottom: 6px !important;
    }
    .timeline-step-content p,
    .timeline-step-content li {
      font-size: 1rem !important;
      line-height: 1.4 !important;
    }

    /* Quote 版式 (PDF 导出) */
    .layout-quote,
    .layout-quote-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      position: relative;
      padding: 40px 60px;
      box-sizing: border-box;
    }
    .layout-quote .quote-watermark-icon,
    .layout-quote-container .quote-watermark-icon {
      position: absolute;
      top: 10%;
      left: 6%;
      font-size: 14rem;
      line-height: 1;
      font-family: Georgia, serif;
      opacity: 0.08;
      color: currentColor;
    }
    .layout-quote .quote-content-body,
    .layout-quote-container .quote-content-body {
      max-width: 800px;
      width: 100%;
      text-align: center;
      position: relative;
      z-index: 1;
    }
    .quote-text,
    .layout-quote-container .quote-body {
      font-size: 2rem !important;
      font-style: italic !important;
      line-height: 1.6 !important;
      margin-bottom: 20px;
    }
    .quote-footer,
    .quote-author {
      font-size: 1.2rem;
      opacity: 0.75;
      text-align: right;
    }

    /* Intro 版式 (PDF 导出) */
    .layout-intro,
    .layout-intro-container {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: 48px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 36px 54px;
    }
    .intro-avatar-col {
      flex-shrink: 0;
    }
    .intro-avatar-box {
      width: 220px;
      height: 220px;
      border-radius: 50%;
      overflow: hidden;
      border: 3px solid rgba(66, 133, 244, 0.35);
      background: rgba(125, 125, 125, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .intro-avatar-svg {
      width: 100px;
      height: 100px;
      opacity: 0.35;
      fill: currentColor;
    }
    .intro-info-col {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .intro-info-col h1 {
      font-size: 2.6rem;
      font-weight: 800;
      margin-bottom: 8px;
    }
    .intro-info-col h2, .intro-info-col h3 {
      font-size: 1.35rem;
      font-weight: 600;
      color: var(--slide-accent, #3b82f6);
      margin-bottom: 14px;
    }
    .intro-info-col p {
      font-size: 1.15rem;
      line-height: 1.5;
      opacity: 0.9;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function $g(e,t){const o="即现讲义",i="16:9",n=_r(e.config.colorSchema),s=e.config.theme||"apple-basic",a=e.slides.map((r,l)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,f=u&&u!=="inherit"?u:e.config.spacing||"normal",p=uc(r),d=`${l+1} / ${e.slides.length}`,b=r.frontmatter.background||e.config.background,m=nc(b),y=m===!0?"light":m===!1?"dark":n,g=b&&!/^(http|\/|data:|assets\/)/.test(b)?`background: ${nt(b)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${y} spacing-${f} slides-theme-${s}" data-slides-theme="${s}" style="${g}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(o)} - 高保真讲义</title>
  <style>
    ${Ig({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${a}
</body>
</html>`}function pc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=$g(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const a=(n=s.contentWindow)==null?void 0:n.document;if(a)return a.open(),a.write(o),a.close(),setTimeout(()=>{var r,l;try{(r=s.contentWindow)==null||r.focus(),(l=s.contentWindow)==null||l.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var mn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Tg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function gn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ss={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Ea;function Ag(){return Ea||(Ea=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function a(c,u){if(!n[c]){if(!i[c]){var f=typeof gn=="function"&&gn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var p=new Error("Cannot find module '"+c+"'");throw p.code="MODULE_NOT_FOUND",p}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(b){var m=i[c][1][b];return a(m||b)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof gn=="function"&&gn,l=0;l<s.length;l++)a(s[l]);return a})({1:[function(o,i,n){var s=o("./utils"),a=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(l){for(var c,u,f,p,d,b,m,y=[],g=0,v=l.length,x=v,_=s.getTypeOf(l)!=="string";g<l.length;)x=v-g,f=_?(c=l[g++],u=g<v?l[g++]:0,g<v?l[g++]:0):(c=l.charCodeAt(g++),u=g<v?l.charCodeAt(g++):0,g<v?l.charCodeAt(g++):0),p=c>>2,d=(3&c)<<4|u>>4,b=1<x?(15&u)<<2|f>>6:64,m=2<x?63&f:64,y.push(r.charAt(p)+r.charAt(d)+r.charAt(b)+r.charAt(m));return y.join("")},n.decode=function(l){var c,u,f,p,d,b,m=0,y=0,g="data:";if(l.substr(0,g.length)===g)throw new Error("Invalid base64 input, it looks like a data url.");var v,x=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&x--,l.charAt(l.length-2)===r.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(v=a.uint8array?new Uint8Array(0|x):new Array(0|x);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(p=r.indexOf(l.charAt(m++)))>>4,u=(15&p)<<4|(d=r.indexOf(l.charAt(m++)))>>2,f=(3&d)<<6|(b=r.indexOf(l.charAt(m++))),v[y++]=c,d!==64&&(v[y++]=u),b!==64&&(v[y++]=f);return v}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),a=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),l=o("./stream/DataLengthProbe");function c(u,f,p,d,b){this.compressedSize=u,this.uncompressedSize=f,this.crc32=p,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new a(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,p){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(f.compressWorker(p)).pipe(new l("compressedSize")).withStreamInfo("compression",f)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();i.exports=function(r,l){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,f,p){var d=a,b=p+f;c^=-1;for(var m=p;m<b;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,f,p){var d=a,b=p+f;c^=-1;for(var m=p;m<b;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=o("pako"),r=o("./utils"),l=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(f,p){l.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=p,this.meta={}}n.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(p){f.push({data:p,meta:f.meta})}},n.compressWorker=function(f){return new u("Deflate",f)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,b){var m,y="";for(m=0;m<b;m++)y+=String.fromCharCode(255&d),d>>>=8;return y}function a(d,b,m,y,g,v){var x,_,T=d.file,k=d.compression,C=v!==c.utf8encode,D=r.transformTo("string",v(T.name)),P=r.transformTo("string",c.utf8encode(T.name)),R=T.comment,j=r.transformTo("string",v(R)),B=r.transformTo("string",c.utf8encode(R)),N=P.length!==T.name.length,S=B.length!==R.length,Z="",W="",$="",M=T.dir,E=T.date,Q={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(Q.crc32=d.crc32,Q.compressedSize=d.compressedSize,Q.uncompressedSize=d.uncompressedSize);var F=0;b&&(F|=8),C||!N&&!S||(F|=2048);var V=0,re=0;M&&(V|=16),g==="UNIX"?(re=798,V|=(function(ae,Se){var $e=ae;return ae||($e=Se?16893:33204),(65535&$e)<<16})(T.unixPermissions,M)):(re=20,V|=(function(ae){return 63&(ae||0)})(T.dosPermissions)),x=E.getUTCHours(),x<<=6,x|=E.getUTCMinutes(),x<<=5,x|=E.getUTCSeconds()/2,_=E.getUTCFullYear()-1980,_<<=4,_|=E.getUTCMonth()+1,_<<=5,_|=E.getUTCDate(),N&&(W=s(1,1)+s(u(D),4)+P,Z+="up"+s(W.length,2)+W),S&&($=s(1,1)+s(u(j),4)+B,Z+="uc"+s($.length,2)+$);var oe="";return oe+=`
\0`,oe+=s(F,2),oe+=k.magic,oe+=s(x,2),oe+=s(_,2),oe+=s(Q.crc32,4),oe+=s(Q.compressedSize,4),oe+=s(Q.uncompressedSize,4),oe+=s(D.length,2),oe+=s(Z.length,2),{fileRecord:f.LOCAL_FILE_HEADER+oe+D+Z,dirRecord:f.CENTRAL_FILE_HEADER+s(re,2)+oe+s(j.length,2)+"\0\0\0\0"+s(V,4)+s(y,4)+D+Z+j}}var r=o("../utils"),l=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),f=o("../signature");function p(d,b,m,y){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=y,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(p,l),p.prototype.push=function(d){var b=d.meta.percent||0,m=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,l.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-y-1))/m:100}}))},p.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var m=a(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},p.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,m=a(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(y){return f.DATA_DESCRIPTOR+s(y.crc32,4)+s(y.compressedSize,4)+s(y.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},p.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-d,y=(function(g,v,x,_,T){var k=r.transformTo("string",T(_));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(g,2)+s(g,2)+s(v,4)+s(x,4)+s(k.length,2)+k})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},p.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},p.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(m){b.processChunk(m)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(m){b.error(m)}),this},p.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},p.prototype.error=function(d){var b=this._sources;if(!l.prototype.error.call(this,d))return!1;for(var m=0;m<b.length;m++)try{b[m].error(d)}catch{}return!0},p.prototype.lock=function(){l.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},i.exports=p},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),a=o("./ZipFileWorker");n.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),f=0;try{r.forEach(function(p,d){f++;var b=(function(v,x){var _=v||x,T=s[_];if(!T)throw new Error(_+" is not a valid compression method !");return T})(d.options.compression,l.compression),m=d.options.compressionOptions||l.compressionOptions||{},y=d.dir,g=d.date;d._compressWorker(b,m).withStreamInfo("file",{name:p,dir:y,date:g,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(p){u.error(p)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new s;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(a,r){return new s().loadAsync(a,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),a=o("./external"),r=o("./utf8"),l=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function f(p){return new a.Promise(function(d,b){var m=p.decompressed.getContentWorker().pipe(new c);m.on("error",function(y){b(y)}).on("end",function(){m.streamInfo.crc32!==p.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(p,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(p)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",p,!0,d.optimizedBinaryString,d.base64).then(function(m){var y=new l(d);return y.load(m),y}).then(function(m){var y=[a.Promise.resolve(m)],g=m.files;if(d.checkCRC32)for(var v=0;v<g.length;v++)y.push(f(g[v]));return a.Promise.all(y)}).then(function(m){for(var y=m.shift(),g=y.files,v=0;v<g.length;v++){var x=g[v],_=x.fileNameStr,T=s.resolve(x.fileNameStr);b.file(T,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:d.createFolders}),x.dir||(b.file(T).unsafeOriginalName=_)}return y.zipComment.length&&(b.comment=y.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),a=o("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function a(r,l,c){s.call(this,l),this._helper=r;var u=this;r.on("data",function(f,p){u.push(f)||u._helper.pause(),c&&c(p)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}o("../utils").inherits(a,s),a.prototype._read=function(){this._helper.resume()},i.exports=a},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,a);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,a)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var a=new Buffer(s);return a.fill(0),a},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(T,k,C){var D,P=r.getTypeOf(k),R=r.extend(C||{},u);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(T=g(T)),R.createFolders&&(D=y(T))&&v.call(this,D,!0);var j=P==="string"&&R.binary===!1&&R.base64===!1;C&&C.binary!==void 0||(R.binary=!j),(k instanceof f&&k.uncompressedSize===0||R.dir||!k||k.length===0)&&(R.base64=!1,R.binary=!0,k="",R.compression="STORE",P="string");var B=null;B=k instanceof f||k instanceof l?k:b.isNode&&b.isStream(k)?new m(T,k):r.prepareContent(T,k,R.binary,R.optimizedBinaryString,R.base64);var N=new p(T,B,R);this.files[T]=N}var a=o("./utf8"),r=o("./utils"),l=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),f=o("./compressedObject"),p=o("./zipObject"),d=o("./generate"),b=o("./nodejsUtils"),m=o("./nodejs/NodejsStreamInputAdapter"),y=function(T){T.slice(-1)==="/"&&(T=T.substring(0,T.length-1));var k=T.lastIndexOf("/");return 0<k?T.substring(0,k):""},g=function(T){return T.slice(-1)!=="/"&&(T+="/"),T},v=function(T,k){return k=k!==void 0?k:u.createFolders,T=g(T),this.files[T]||s.call(this,T,null,{dir:!0,createFolders:k}),this.files[T]};function x(T){return Object.prototype.toString.call(T)==="[object RegExp]"}var _={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(T){var k,C,D;for(k in this.files)D=this.files[k],(C=k.slice(this.root.length,k.length))&&k.slice(0,this.root.length)===this.root&&T(C,D)},filter:function(T){var k=[];return this.forEach(function(C,D){T(C,D)&&k.push(D)}),k},file:function(T,k,C){if(arguments.length!==1)return T=this.root+T,s.call(this,T,k,C),this;if(x(T)){var D=T;return this.filter(function(R,j){return!j.dir&&D.test(R)})}var P=this.files[this.root+T];return P&&!P.dir?P:null},folder:function(T){if(!T)return this;if(x(T))return this.filter(function(P,R){return R.dir&&T.test(P)});var k=this.root+T,C=v.call(this,k),D=this.clone();return D.root=C.name,D},remove:function(T){T=this.root+T;var k=this.files[T];if(k||(T.slice(-1)!=="/"&&(T+="/"),k=this.files[T]),k&&!k.dir)delete this.files[T];else for(var C=this.filter(function(P,R){return R.name.slice(0,T.length)===T}),D=0;D<C.length;D++)delete this.files[C[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(T){var k,C={};try{if((C=r.extend(T||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var D=C.comment||this.comment||"";k=d.generateWorker(this,C,D)}catch(P){(k=new l("error")).error(P)}return new c(k,C.type||"string",C.mimeType)},generateAsync:function(T,k){return this.generateInternalStream(T).accumulate(k)},generateNodeStream:function(T,k){return(T=T||{}).type||(T.type="nodebuffer"),this.generateInternalStream(T).toNodejsStream(k)}};i.exports=_},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function a(r){s.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}o("../utils").inherits(a,s),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),p=this.length-4;0<=p;--p)if(this.data[p]===l&&this.data[p+1]===c&&this.data[p+2]===u&&this.data[p+3]===f)return p-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),p=this.readData(4);return l===p[0]&&c===p[1]&&u===p[2]&&f===p[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},i.exports=a},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=a},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function a(r){s.call(this,r)}o("../utils").inherits(a,s),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},i.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function a(r){s.call(this,r)}o("../utils").inherits(a,s),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},i.exports=a},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function a(r){s.call(this,r)}o("../utils").inherits(a,s),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},i.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),a=o("../support"),r=o("./ArrayReader"),l=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(f){var p=s.getTypeOf(f);return s.checkSupport(p),p!=="string"||a.uint8array?p==="nodebuffer"?new c(f):a.uint8array?new u(s.transformTo("uint8array",f)):new r(s.transformTo("array",f)):new l(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),a=o("../utils");function r(l){s.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,s),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),a=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),a=o("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}s.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),a=o("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),a=o("./ConvertWorker"),r=o("./GenericWorker"),l=o("../base64"),c=o("../support"),u=o("../external"),f=null;if(c.nodestream)try{f=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function p(b,m){return new u.Promise(function(y,g){var v=[],x=b._internalType,_=b._outputType,T=b._mimeType;b.on("data",function(k,C){v.push(k),m&&m(C)}).on("error",function(k){v=[],g(k)}).on("end",function(){try{var k=(function(C,D,P){switch(C){case"blob":return s.newBlob(s.transformTo("arraybuffer",D),P);case"base64":return l.encode(D);default:return s.transformTo(C,D)}})(_,(function(C,D){var P,R=0,j=null,B=0;for(P=0;P<D.length;P++)B+=D[P].length;switch(C){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(j=new Uint8Array(B),P=0;P<D.length;P++)j.set(D[P],R),R+=D[P].length;return j;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+C+"'")}})(x,v),T);y(k)}catch(C){g(C)}v=[]}).resume()})}function d(b,m,y){var g=m;switch(m){case"blob":case"arraybuffer":g="uint8array";break;case"base64":g="string"}try{this._internalType=g,this._outputType=m,this._mimeType=y,s.checkSupport(g),this._worker=b.pipe(new a(g)),b.lock()}catch(v){this._worker=new r("error"),this._worker.error(v)}}d.prototype={accumulate:function(b){return p(this,b)},on:function(b,m){var y=this;return b==="data"?this._worker.on(b,function(g){m.call(y,g.data,g.meta)}):this._worker.on(b,function(){s.delay(m,arguments,y)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},b)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(s),n.blob=a.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),a=o("./support"),r=o("./nodejsUtils"),l=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){l.call(this,"utf-8 decode"),this.leftOver=null}function p(){l.call(this,"utf-8 encode")}n.utf8encode=function(d){return a.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var m,y,g,v,x,_=b.length,T=0;for(v=0;v<_;v++)(64512&(y=b.charCodeAt(v)))==55296&&v+1<_&&(64512&(g=b.charCodeAt(v+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),v++),T+=y<128?1:y<2048?2:y<65536?3:4;for(m=a.uint8array?new Uint8Array(T):new Array(T),v=x=0;x<T;v++)(64512&(y=b.charCodeAt(v)))==55296&&v+1<_&&(64512&(g=b.charCodeAt(v+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),v++),y<128?m[x++]=y:(y<2048?m[x++]=192|y>>>6:(y<65536?m[x++]=224|y>>>12:(m[x++]=240|y>>>18,m[x++]=128|y>>>12&63),m[x++]=128|y>>>6&63),m[x++]=128|63&y);return m})(d)},n.utf8decode=function(d){return a.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var m,y,g,v,x=b.length,_=new Array(2*x);for(m=y=0;m<x;)if((g=b[m++])<128)_[y++]=g;else if(4<(v=c[g]))_[y++]=65533,m+=v-1;else{for(g&=v===2?31:v===3?15:7;1<v&&m<x;)g=g<<6|63&b[m++],v--;1<v?_[y++]=65533:g<65536?_[y++]=g:(g-=65536,_[y++]=55296|g>>10&1023,_[y++]=56320|1023&g)}return _.length!==y&&(_.subarray?_=_.subarray(0,y):_.length=y),s.applyFromCharCode(_)})(d=s.transformTo(a.uint8array?"uint8array":"array",d))},s.inherits(f,l),f.prototype.processChunk=function(d){var b=s.transformTo(a.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var y=(function(v,x){var _;for((x=x||v.length)>v.length&&(x=v.length),_=x-1;0<=_&&(192&v[_])==128;)_--;return _<0||_===0?x:_+c[v[_]]>x?_:x})(b),g=b;y!==b.length&&(a.uint8array?(g=b.subarray(0,y),this.leftOver=b.subarray(y,b.length)):(g=b.slice(0,y),this.leftOver=b.slice(y,b.length))),this.push({data:n.utf8decode(g),meta:d.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,s.inherits(p,l),p.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=p},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),a=o("./base64"),r=o("./nodejsUtils"),l=o("./external");function c(m){return m}function u(m,y){for(var g=0;g<m.length;++g)y[g]=255&m.charCodeAt(g);return y}o("setimmediate"),n.newBlob=function(m,y){n.checkSupport("blob");try{return new Blob([m],{type:y})}catch{try{var g=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return g.append(m),g.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,y,g){var v=[],x=0,_=m.length;if(_<=g)return String.fromCharCode.apply(null,m);for(;x<_;)y==="array"||y==="nodebuffer"?v.push(String.fromCharCode.apply(null,m.slice(x,Math.min(x+g,_)))):v.push(String.fromCharCode.apply(null,m.subarray(x,Math.min(x+g,_)))),x+=g;return v.join("")},stringifyByChar:function(m){for(var y="",g=0;g<m.length;g++)y+=String.fromCharCode(m[g]);return y},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function p(m){var y=65536,g=n.getTypeOf(m),v=!0;if(g==="uint8array"?v=f.applyCanBeUsed.uint8array:g==="nodebuffer"&&(v=f.applyCanBeUsed.nodebuffer),v)for(;1<y;)try{return f.stringifyByChunk(m,g,y)}catch{y=Math.floor(y/2)}return f.stringifyByChar(m)}function d(m,y){for(var g=0;g<m.length;g++)y[g]=m[g];return y}n.applyFromCharCode=p;var b={};b.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},b.array={string:p,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return p(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:p,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:p,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,y){if(y=y||"",!m)return y;n.checkSupport(m);var g=n.getTypeOf(y);return b[g][m](y)},n.resolve=function(m){for(var y=m.split("/"),g=[],v=0;v<y.length;v++){var x=y[v];x==="."||x===""&&v!==0&&v!==y.length-1||(x===".."?g.pop():g.push(x))}return g.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var y,g,v="";for(g=0;g<(m||"").length;g++)v+="\\x"+((y=m.charCodeAt(g))<16?"0":"")+y.toString(16).toUpperCase();return v},n.delay=function(m,y,g){setImmediate(function(){m.apply(g||null,y||[])})},n.inherits=function(m,y){function g(){}g.prototype=y.prototype,m.prototype=new g},n.extend=function(){var m,y,g={};for(m=0;m<arguments.length;m++)for(y in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],y)&&g[y]===void 0&&(g[y]=arguments[m][y]);return g},n.prepareContent=function(m,y,g,v,x){return l.Promise.resolve(y).then(function(_){return s.blob&&(_ instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(_))!==-1)&&typeof FileReader<"u"?new l.Promise(function(T,k){var C=new FileReader;C.onload=function(D){T(D.target.result)},C.onerror=function(D){k(D.target.error)},C.readAsArrayBuffer(_)}):_}).then(function(_){var T=n.getTypeOf(_);return T?(T==="arraybuffer"?_=n.transformTo("uint8array",_):T==="string"&&(x?_=a.decode(_):g&&v!==!0&&(_=(function(k){return u(k,s.uint8array?new Uint8Array(k.length):new Array(k.length))})(_))),_):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),a=o("./utils"),r=o("./signature"),l=o("./zipEntry"),c=o("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var p=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(p)+", expected "+a.pretty(f)+")")}},isSignature:function(f,p){var d=this.reader.index;this.reader.setIndex(f);var b=this.reader.readString(4)===p;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),p=c.uint8array?"uint8array":"array",d=a.transformTo(p,f);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,p,d,b=this.zip64EndOfCentralSize-44;0<b;)f=this.reader.readInt(2),p=this.reader.readInt(4),d=this.reader.readData(p),this.zip64ExtensibleData[f]={id:f,length:p,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,p;for(f=0;f<this.files.length;f++)p=this.files[f],this.reader.setIndex(p.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),p.readLocalPart(this.reader),p.handleUTF8(),p.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var p=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=p-d;if(0<b)this.isSignature(p,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(f){this.reader=s(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),a=o("./utils"),r=o("./compressedObject"),l=o("./crc32"),c=o("./utf8"),u=o("./compressions"),f=o("./support");function p(d,b){this.options=d,this.loadOptions=b}p.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(y){for(var g in u)if(Object.prototype.hasOwnProperty.call(u,g)&&u[g].magic===y)return u[g];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,m,y,g=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<g;)b=d.readInt(2),m=d.readInt(2),y=d.readData(m),this.extraFields[b]={id:b,length:m,value:y};d.setIndex(g)},handleUTF8:function(){var d=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=a.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var g=a.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(g)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||l(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||l(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},i.exports=p},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(b,m,y){this.name=b,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=m,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var a=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),l=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(b){var m=null,y="string";try{if(!b)throw new Error("No output type specified.");var g=(y=b.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),m=this._decompressWorker();var v=!this._dataBinary;v&&!g&&(m=m.pipe(new l.Utf8EncodeWorker)),!v&&g&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(x){(m=new u("error")).error(x)}return new a(m,y,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(y,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],p=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<f.length;d++)s.prototype[f[d]]=p;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var a,r,l=s.MutationObserver||s.WebKitMutationObserver;if(l){var c=0,u=new l(b),f=s.document.createTextNode("");u.observe(f,{characterData:!0}),a=function(){f.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)a="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var p=new s.MessageChannel;p.port1.onmessage=b,a=function(){p.port2.postMessage(0)}}var d=[];function b(){var m,y;r=!0;for(var g=d.length;g;){for(y=d,d=[],m=-1;++m<g;)y[m]();g=d.length}r=!1}i.exports=function(m){d.push(m)!==1||r||a()}}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(g){if(typeof g!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,g!==a&&m(this,g)}function p(g,v,x){this.promise=g,typeof v=="function"&&(this.onFulfilled=v,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function d(g,v,x){s(function(){var _;try{_=v(x)}catch(T){return r.reject(g,T)}_===g?r.reject(g,new TypeError("Cannot resolve promise with itself")):r.resolve(g,_)})}function b(g){var v=g&&g.then;if(g&&(typeof g=="object"||typeof g=="function")&&typeof v=="function")return function(){v.apply(g,arguments)}}function m(g,v){var x=!1;function _(C){x||(x=!0,r.reject(g,C))}function T(C){x||(x=!0,r.resolve(g,C))}var k=y(function(){v(T,_)});k.status==="error"&&_(k.value)}function y(g,v){var x={};try{x.value=g(v),x.status="success"}catch(_){x.status="error",x.value=_}return x}(i.exports=f).prototype.finally=function(g){if(typeof g!="function")return this;var v=this.constructor;return this.then(function(x){return v.resolve(g()).then(function(){return x})},function(x){return v.resolve(g()).then(function(){throw x})})},f.prototype.catch=function(g){return this.then(null,g)},f.prototype.then=function(g,v){if(typeof g!="function"&&this.state===c||typeof v!="function"&&this.state===l)return this;var x=new this.constructor(a);return this.state!==u?d(x,this.state===c?g:v,this.outcome):this.queue.push(new p(x,g,v)),x},p.prototype.callFulfilled=function(g){r.resolve(this.promise,g)},p.prototype.otherCallFulfilled=function(g){d(this.promise,this.onFulfilled,g)},p.prototype.callRejected=function(g){r.reject(this.promise,g)},p.prototype.otherCallRejected=function(g){d(this.promise,this.onRejected,g)},r.resolve=function(g,v){var x=y(b,v);if(x.status==="error")return r.reject(g,x.value);var _=x.value;if(_)m(g,_);else{g.state=c,g.outcome=v;for(var T=-1,k=g.queue.length;++T<k;)g.queue[T].callFulfilled(v)}return g},r.reject=function(g,v){g.state=l,g.outcome=v;for(var x=-1,_=g.queue.length;++x<_;)g.queue[x].callRejected(v);return g},f.resolve=function(g){return g instanceof this?g:r.resolve(new this(a),g)},f.reject=function(g){var v=new this(a);return r.reject(v,g)},f.all=function(g){var v=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=g.length,_=!1;if(!x)return this.resolve([]);for(var T=new Array(x),k=0,C=-1,D=new this(a);++C<x;)P(g[C],C);return D;function P(R,j){v.resolve(R).then(function(B){T[j]=B,++k!==x||_||(_=!0,r.resolve(D,T))},function(B){_||(_=!0,r.reject(D,B))})}},f.race=function(g){var v=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=g.length,_=!1;if(!x)return this.resolve([]);for(var T=-1,k=new this(a);++T<x;)C=g[T],v.resolve(C).then(function(D){_||(_=!0,r.resolve(k,D))},function(D){_||(_=!0,r.reject(k,D))});var C;return k}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),a=o("./utils/common"),r=o("./utils/strings"),l=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,f=0,p=-1,d=0,b=8;function m(g){if(!(this instanceof m))return new m(g);this.options=a.assign({level:p,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},g||{});var v=this.options;v.raw&&0<v.windowBits?v.windowBits=-v.windowBits:v.gzip&&0<v.windowBits&&v.windowBits<16&&(v.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=s.deflateInit2(this.strm,v.level,v.method,v.windowBits,v.memLevel,v.strategy);if(x!==f)throw new Error(l[x]);if(v.header&&s.deflateSetHeader(this.strm,v.header),v.dictionary){var _;if(_=typeof v.dictionary=="string"?r.string2buf(v.dictionary):u.call(v.dictionary)==="[object ArrayBuffer]"?new Uint8Array(v.dictionary):v.dictionary,(x=s.deflateSetDictionary(this.strm,_))!==f)throw new Error(l[x]);this._dict_set=!0}}function y(g,v){var x=new m(v);if(x.push(g,!0),x.err)throw x.msg||l[x.err];return x.result}m.prototype.push=function(g,v){var x,_,T=this.strm,k=this.options.chunkSize;if(this.ended)return!1;_=v===~~v?v:v===!0?4:0,typeof g=="string"?T.input=r.string2buf(g):u.call(g)==="[object ArrayBuffer]"?T.input=new Uint8Array(g):T.input=g,T.next_in=0,T.avail_in=T.input.length;do{if(T.avail_out===0&&(T.output=new a.Buf8(k),T.next_out=0,T.avail_out=k),(x=s.deflate(T,_))!==1&&x!==f)return this.onEnd(x),!(this.ended=!0);T.avail_out!==0&&(T.avail_in!==0||_!==4&&_!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(T.output,T.next_out))):this.onData(a.shrinkBuf(T.output,T.next_out)))}while((0<T.avail_in||T.avail_out===0)&&x!==1);return _===4?(x=s.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===f):_!==2||(this.onEnd(f),!(T.avail_out=0))},m.prototype.onData=function(g){this.chunks.push(g)},m.prototype.onEnd=function(g){g===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=g,this.msg=this.strm.msg},n.Deflate=m,n.deflate=y,n.deflateRaw=function(g,v){return(v=v||{}).raw=!0,y(g,v)},n.gzip=function(g,v){return(v=v||{}).gzip=!0,y(g,v)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),a=o("./utils/common"),r=o("./utils/strings"),l=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),f=o("./zlib/gzheader"),p=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||m&&m.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var g=s.inflateInit2(this.strm,y.windowBits);if(g!==l.Z_OK)throw new Error(c[g]);this.header=new f,s.inflateGetHeader(this.strm,this.header)}function b(m,y){var g=new d(y);if(g.push(m,!0),g.err)throw g.msg||c[g.err];return g.result}d.prototype.push=function(m,y){var g,v,x,_,T,k,C=this.strm,D=this.options.chunkSize,P=this.options.dictionary,R=!1;if(this.ended)return!1;v=y===~~y?y:y===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):p.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(D),C.next_out=0,C.avail_out=D),(g=s.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&P&&(k=typeof P=="string"?r.string2buf(P):p.call(P)==="[object ArrayBuffer]"?new Uint8Array(P):P,g=s.inflateSetDictionary(this.strm,k)),g===l.Z_BUF_ERROR&&R===!0&&(g=l.Z_OK,R=!1),g!==l.Z_STREAM_END&&g!==l.Z_OK)return this.onEnd(g),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&g!==l.Z_STREAM_END&&(C.avail_in!==0||v!==l.Z_FINISH&&v!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=r.utf8border(C.output,C.next_out),_=C.next_out-x,T=r.buf2string(C.output,x),C.next_out=_,C.avail_out=D-_,_&&a.arraySet(C.output,C.output,x,_,0),this.onData(T)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(R=!0)}while((0<C.avail_in||C.avail_out===0)&&g!==l.Z_STREAM_END);return g===l.Z_STREAM_END&&(v=l.Z_FINISH),v===l.Z_FINISH?(g=s.inflateEnd(this.strm),this.onEnd(g),this.ended=!0,g===l.Z_OK):v!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=d,n.inflate=b,n.inflateRaw=function(m,y){return(y=y||{}).raw=!0,b(m,y)},n.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(l[f]=u[f])}}return l},n.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,f,p){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+f),p);else for(var d=0;d<f;d++)l[p+d]=c[u+d]},flattenChunks:function(l){var c,u,f,p,d,b;for(c=f=0,u=l.length;c<u;c++)f+=l[c].length;for(b=new Uint8Array(f),c=p=0,u=l.length;c<u;c++)d=l[c],b.set(d,p),p+=d.length;return b}},r={arraySet:function(l,c,u,f,p){for(var d=0;d<f;d++)l[p+d]=c[u+d]},flattenChunks:function(l){return[].concat.apply([],l)}};n.setTyped=function(l){l?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,a)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new s.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,p){if(p<65537&&(f.subarray&&r||!f.subarray&&a))return String.fromCharCode.apply(null,s.shrinkBuf(f,p));for(var d="",b=0;b<p;b++)d+=String.fromCharCode(f[b]);return d}l[254]=l[254]=1,n.string2buf=function(f){var p,d,b,m,y,g=f.length,v=0;for(m=0;m<g;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),v+=d<128?1:d<2048?2:d<65536?3:4;for(p=new s.Buf8(v),m=y=0;y<v;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),d<128?p[y++]=d:(d<2048?p[y++]=192|d>>>6:(d<65536?p[y++]=224|d>>>12:(p[y++]=240|d>>>18,p[y++]=128|d>>>12&63),p[y++]=128|d>>>6&63),p[y++]=128|63&d);return p},n.buf2binstring=function(f){return u(f,f.length)},n.binstring2buf=function(f){for(var p=new s.Buf8(f.length),d=0,b=p.length;d<b;d++)p[d]=f.charCodeAt(d);return p},n.buf2string=function(f,p){var d,b,m,y,g=p||f.length,v=new Array(2*g);for(d=b=0;d<g;)if((m=f[d++])<128)v[b++]=m;else if(4<(y=l[m]))v[b++]=65533,d+=y-1;else{for(m&=y===2?31:y===3?15:7;1<y&&d<g;)m=m<<6|63&f[d++],y--;1<y?v[b++]=65533:m<65536?v[b++]=m:(m-=65536,v[b++]=55296|m>>10&1023,v[b++]=56320|1023&m)}return u(v,b)},n.utf8border=function(f,p){var d;for((p=p||f.length)>f.length&&(p=f.length),d=p-1;0<=d&&(192&f[d])==128;)d--;return d<0||d===0?p:d+l[f[d]]>p?d:p}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,a,r,l){for(var c=65535&s|0,u=s>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();i.exports=function(a,r,l,c){var u=s,f=c+l;a^=-1;for(var p=c;p<f;p++)a=a>>>8^u[255&(a^r[p])];return-1^a}},{}],46:[function(o,i,n){var s,a=o("../utils/common"),r=o("./trees"),l=o("./adler32"),c=o("./crc32"),u=o("./messages"),f=0,p=4,d=0,b=-2,m=-1,y=4,g=2,v=8,x=9,_=286,T=30,k=19,C=2*_+1,D=15,P=3,R=258,j=R+P+1,B=42,N=113,S=1,Z=2,W=3,$=4;function M(w,q){return w.msg=u[q],q}function E(w){return(w<<1)-(4<w?9:0)}function Q(w){for(var q=w.length;0<=--q;)w[q]=0}function F(w){var q=w.state,H=q.pending;H>w.avail_out&&(H=w.avail_out),H!==0&&(a.arraySet(w.output,q.pending_buf,q.pending_out,H,w.next_out),w.next_out+=H,q.pending_out+=H,w.total_out+=H,w.avail_out-=H,q.pending-=H,q.pending===0&&(q.pending_out=0))}function V(w,q){r._tr_flush_block(w,0<=w.block_start?w.block_start:-1,w.strstart-w.block_start,q),w.block_start=w.strstart,F(w.strm)}function re(w,q){w.pending_buf[w.pending++]=q}function oe(w,q){w.pending_buf[w.pending++]=q>>>8&255,w.pending_buf[w.pending++]=255&q}function ae(w,q){var H,I,A=w.max_chain_length,O=w.strstart,G=w.prev_length,K=w.nice_match,Y=w.strstart>w.w_size-j?w.strstart-(w.w_size-j):0,ee=w.window,ce=w.w_mask,se=w.prev,me=w.strstart+R,_e=ee[O+G-1],we=ee[O+G];w.prev_length>=w.good_match&&(A>>=2),K>w.lookahead&&(K=w.lookahead);do if(ee[(H=q)+G]===we&&ee[H+G-1]===_e&&ee[H]===ee[O]&&ee[++H]===ee[O+1]){O+=2,H++;do;while(ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&ee[++O]===ee[++H]&&O<me);if(I=R-(me-O),O=me-R,G<I){if(w.match_start=q,K<=(G=I))break;_e=ee[O+G-1],we=ee[O+G]}}while((q=se[q&ce])>Y&&--A!=0);return G<=w.lookahead?G:w.lookahead}function Se(w){var q,H,I,A,O,G,K,Y,ee,ce,se=w.w_size;do{if(A=w.window_size-w.lookahead-w.strstart,w.strstart>=se+(se-j)){for(a.arraySet(w.window,w.window,se,se,0),w.match_start-=se,w.strstart-=se,w.block_start-=se,q=H=w.hash_size;I=w.head[--q],w.head[q]=se<=I?I-se:0,--H;);for(q=H=se;I=w.prev[--q],w.prev[q]=se<=I?I-se:0,--H;);A+=se}if(w.strm.avail_in===0)break;if(G=w.strm,K=w.window,Y=w.strstart+w.lookahead,ee=A,ce=void 0,ce=G.avail_in,ee<ce&&(ce=ee),H=ce===0?0:(G.avail_in-=ce,a.arraySet(K,G.input,G.next_in,ce,Y),G.state.wrap===1?G.adler=l(G.adler,K,ce,Y):G.state.wrap===2&&(G.adler=c(G.adler,K,ce,Y)),G.next_in+=ce,G.total_in+=ce,ce),w.lookahead+=H,w.lookahead+w.insert>=P)for(O=w.strstart-w.insert,w.ins_h=w.window[O],w.ins_h=(w.ins_h<<w.hash_shift^w.window[O+1])&w.hash_mask;w.insert&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[O+P-1])&w.hash_mask,w.prev[O&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=O,O++,w.insert--,!(w.lookahead+w.insert<P)););}while(w.lookahead<j&&w.strm.avail_in!==0)}function $e(w,q){for(var H,I;;){if(w.lookahead<j){if(Se(w),w.lookahead<j&&q===f)return S;if(w.lookahead===0)break}if(H=0,w.lookahead>=P&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+P-1])&w.hash_mask,H=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),H!==0&&w.strstart-H<=w.w_size-j&&(w.match_length=ae(w,H)),w.match_length>=P)if(I=r._tr_tally(w,w.strstart-w.match_start,w.match_length-P),w.lookahead-=w.match_length,w.match_length<=w.max_lazy_match&&w.lookahead>=P){for(w.match_length--;w.strstart++,w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+P-1])&w.hash_mask,H=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart,--w.match_length!=0;);w.strstart++}else w.strstart+=w.match_length,w.match_length=0,w.ins_h=w.window[w.strstart],w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+1])&w.hash_mask;else I=r._tr_tally(w,0,w.window[w.strstart]),w.lookahead--,w.strstart++;if(I&&(V(w,!1),w.strm.avail_out===0))return S}return w.insert=w.strstart<P-1?w.strstart:P-1,q===p?(V(w,!0),w.strm.avail_out===0?W:$):w.last_lit&&(V(w,!1),w.strm.avail_out===0)?S:Z}function ke(w,q){for(var H,I,A;;){if(w.lookahead<j){if(Se(w),w.lookahead<j&&q===f)return S;if(w.lookahead===0)break}if(H=0,w.lookahead>=P&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+P-1])&w.hash_mask,H=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),w.prev_length=w.match_length,w.prev_match=w.match_start,w.match_length=P-1,H!==0&&w.prev_length<w.max_lazy_match&&w.strstart-H<=w.w_size-j&&(w.match_length=ae(w,H),w.match_length<=5&&(w.strategy===1||w.match_length===P&&4096<w.strstart-w.match_start)&&(w.match_length=P-1)),w.prev_length>=P&&w.match_length<=w.prev_length){for(A=w.strstart+w.lookahead-P,I=r._tr_tally(w,w.strstart-1-w.prev_match,w.prev_length-P),w.lookahead-=w.prev_length-1,w.prev_length-=2;++w.strstart<=A&&(w.ins_h=(w.ins_h<<w.hash_shift^w.window[w.strstart+P-1])&w.hash_mask,H=w.prev[w.strstart&w.w_mask]=w.head[w.ins_h],w.head[w.ins_h]=w.strstart),--w.prev_length!=0;);if(w.match_available=0,w.match_length=P-1,w.strstart++,I&&(V(w,!1),w.strm.avail_out===0))return S}else if(w.match_available){if((I=r._tr_tally(w,0,w.window[w.strstart-1]))&&V(w,!1),w.strstart++,w.lookahead--,w.strm.avail_out===0)return S}else w.match_available=1,w.strstart++,w.lookahead--}return w.match_available&&(I=r._tr_tally(w,0,w.window[w.strstart-1]),w.match_available=0),w.insert=w.strstart<P-1?w.strstart:P-1,q===p?(V(w,!0),w.strm.avail_out===0?W:$):w.last_lit&&(V(w,!1),w.strm.avail_out===0)?S:Z}function Ce(w,q,H,I,A){this.good_length=w,this.max_lazy=q,this.nice_length=H,this.max_chain=I,this.func=A}function z(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=v,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*T+1)),this.bl_tree=new a.Buf16(2*(2*k+1)),Q(this.dyn_ltree),Q(this.dyn_dtree),Q(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(D+1),this.heap=new a.Buf16(2*_+1),Q(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*_+1),Q(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ne(w){var q;return w&&w.state?(w.total_in=w.total_out=0,w.data_type=g,(q=w.state).pending=0,q.pending_out=0,q.wrap<0&&(q.wrap=-q.wrap),q.status=q.wrap?B:N,w.adler=q.wrap===2?0:1,q.last_flush=f,r._tr_init(q),d):M(w,b)}function L(w){var q=ne(w);return q===d&&(function(H){H.window_size=2*H.w_size,Q(H.head),H.max_lazy_match=s[H.level].max_lazy,H.good_match=s[H.level].good_length,H.nice_match=s[H.level].nice_length,H.max_chain_length=s[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=P-1,H.match_available=0,H.ins_h=0})(w.state),q}function U(w,q,H,I,A,O){if(!w)return b;var G=1;if(q===m&&(q=6),I<0?(G=0,I=-I):15<I&&(G=2,I-=16),A<1||x<A||H!==v||I<8||15<I||q<0||9<q||O<0||y<O)return M(w,b);I===8&&(I=9);var K=new z;return(w.state=K).strm=w,K.wrap=G,K.gzhead=null,K.w_bits=I,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=A+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+P-1)/P),K.window=new a.Buf8(2*K.w_size),K.head=new a.Buf16(K.hash_size),K.prev=new a.Buf16(K.w_size),K.lit_bufsize=1<<A+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new a.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=q,K.strategy=O,K.method=H,L(w)}s=[new Ce(0,0,0,0,function(w,q){var H=65535;for(H>w.pending_buf_size-5&&(H=w.pending_buf_size-5);;){if(w.lookahead<=1){if(Se(w),w.lookahead===0&&q===f)return S;if(w.lookahead===0)break}w.strstart+=w.lookahead,w.lookahead=0;var I=w.block_start+H;if((w.strstart===0||w.strstart>=I)&&(w.lookahead=w.strstart-I,w.strstart=I,V(w,!1),w.strm.avail_out===0)||w.strstart-w.block_start>=w.w_size-j&&(V(w,!1),w.strm.avail_out===0))return S}return w.insert=0,q===p?(V(w,!0),w.strm.avail_out===0?W:$):(w.strstart>w.block_start&&(V(w,!1),w.strm.avail_out),S)}),new Ce(4,4,8,4,$e),new Ce(4,5,16,8,$e),new Ce(4,6,32,32,$e),new Ce(4,4,16,16,ke),new Ce(8,16,32,32,ke),new Ce(8,16,128,128,ke),new Ce(8,32,128,256,ke),new Ce(32,128,258,1024,ke),new Ce(32,258,258,4096,ke)],n.deflateInit=function(w,q){return U(w,q,v,15,8,0)},n.deflateInit2=U,n.deflateReset=L,n.deflateResetKeep=ne,n.deflateSetHeader=function(w,q){return w&&w.state?w.state.wrap!==2?b:(w.state.gzhead=q,d):b},n.deflate=function(w,q){var H,I,A,O;if(!w||!w.state||5<q||q<0)return w?M(w,b):b;if(I=w.state,!w.output||!w.input&&w.avail_in!==0||I.status===666&&q!==p)return M(w,w.avail_out===0?-5:b);if(I.strm=w,H=I.last_flush,I.last_flush=q,I.status===B)if(I.wrap===2)w.adler=0,re(I,31),re(I,139),re(I,8),I.gzhead?(re(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),re(I,255&I.gzhead.time),re(I,I.gzhead.time>>8&255),re(I,I.gzhead.time>>16&255),re(I,I.gzhead.time>>24&255),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(re(I,255&I.gzhead.extra.length),re(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(w.adler=c(w.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(re(I,0),re(I,0),re(I,0),re(I,0),re(I,0),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,3),I.status=N);else{var G=v+(I.w_bits-8<<4)<<8;G|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(G|=32),G+=31-G%31,I.status=N,oe(I,G),I.strstart!==0&&(oe(I,w.adler>>>16),oe(I,65535&w.adler)),w.adler=1}if(I.status===69)if(I.gzhead.extra){for(A=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),F(w),A=I.pending,I.pending!==I.pending_buf_size));)re(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){A=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),F(w),A=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,re(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),O===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){A=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),F(w),A=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,re(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>A&&(w.adler=c(w.adler,I.pending_buf,I.pending-A,A)),O===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&F(w),I.pending+2<=I.pending_buf_size&&(re(I,255&w.adler),re(I,w.adler>>8&255),w.adler=0,I.status=N)):I.status=N),I.pending!==0){if(F(w),w.avail_out===0)return I.last_flush=-1,d}else if(w.avail_in===0&&E(q)<=E(H)&&q!==p)return M(w,-5);if(I.status===666&&w.avail_in!==0)return M(w,-5);if(w.avail_in!==0||I.lookahead!==0||q!==f&&I.status!==666){var K=I.strategy===2?(function(Y,ee){for(var ce;;){if(Y.lookahead===0&&(Se(Y),Y.lookahead===0)){if(ee===f)return S;break}if(Y.match_length=0,ce=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++,ce&&(V(Y,!1),Y.strm.avail_out===0))return S}return Y.insert=0,ee===p?(V(Y,!0),Y.strm.avail_out===0?W:$):Y.last_lit&&(V(Y,!1),Y.strm.avail_out===0)?S:Z})(I,q):I.strategy===3?(function(Y,ee){for(var ce,se,me,_e,we=Y.window;;){if(Y.lookahead<=R){if(Se(Y),Y.lookahead<=R&&ee===f)return S;if(Y.lookahead===0)break}if(Y.match_length=0,Y.lookahead>=P&&0<Y.strstart&&(se=we[me=Y.strstart-1])===we[++me]&&se===we[++me]&&se===we[++me]){_e=Y.strstart+R;do;while(se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&me<_e);Y.match_length=R-(_e-me),Y.match_length>Y.lookahead&&(Y.match_length=Y.lookahead)}if(Y.match_length>=P?(ce=r._tr_tally(Y,1,Y.match_length-P),Y.lookahead-=Y.match_length,Y.strstart+=Y.match_length,Y.match_length=0):(ce=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++),ce&&(V(Y,!1),Y.strm.avail_out===0))return S}return Y.insert=0,ee===p?(V(Y,!0),Y.strm.avail_out===0?W:$):Y.last_lit&&(V(Y,!1),Y.strm.avail_out===0)?S:Z})(I,q):s[I.level].func(I,q);if(K!==W&&K!==$||(I.status=666),K===S||K===W)return w.avail_out===0&&(I.last_flush=-1),d;if(K===Z&&(q===1?r._tr_align(I):q!==5&&(r._tr_stored_block(I,0,0,!1),q===3&&(Q(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),F(w),w.avail_out===0))return I.last_flush=-1,d}return q!==p?d:I.wrap<=0?1:(I.wrap===2?(re(I,255&w.adler),re(I,w.adler>>8&255),re(I,w.adler>>16&255),re(I,w.adler>>24&255),re(I,255&w.total_in),re(I,w.total_in>>8&255),re(I,w.total_in>>16&255),re(I,w.total_in>>24&255)):(oe(I,w.adler>>>16),oe(I,65535&w.adler)),F(w),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?d:1)},n.deflateEnd=function(w){var q;return w&&w.state?(q=w.state.status)!==B&&q!==69&&q!==73&&q!==91&&q!==103&&q!==N&&q!==666?M(w,b):(w.state=null,q===N?M(w,-3):d):b},n.deflateSetDictionary=function(w,q){var H,I,A,O,G,K,Y,ee,ce=q.length;if(!w||!w.state||(O=(H=w.state).wrap)===2||O===1&&H.status!==B||H.lookahead)return b;for(O===1&&(w.adler=l(w.adler,q,ce,0)),H.wrap=0,ce>=H.w_size&&(O===0&&(Q(H.head),H.strstart=0,H.block_start=0,H.insert=0),ee=new a.Buf8(H.w_size),a.arraySet(ee,q,ce-H.w_size,H.w_size,0),q=ee,ce=H.w_size),G=w.avail_in,K=w.next_in,Y=w.input,w.avail_in=ce,w.next_in=0,w.input=q,Se(H);H.lookahead>=P;){for(I=H.strstart,A=H.lookahead-(P-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[I+P-1])&H.hash_mask,H.prev[I&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=I,I++,--A;);H.strstart=I,H.lookahead=P-1,Se(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=P-1,H.match_available=0,w.next_in=K,w.input=Y,w.avail_in=G,H.wrap=O,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,a){var r,l,c,u,f,p,d,b,m,y,g,v,x,_,T,k,C,D,P,R,j,B,N,S,Z;r=s.state,l=s.next_in,S=s.input,c=l+(s.avail_in-5),u=s.next_out,Z=s.output,f=u-(a-s.avail_out),p=u+(s.avail_out-257),d=r.dmax,b=r.wsize,m=r.whave,y=r.wnext,g=r.window,v=r.hold,x=r.bits,_=r.lencode,T=r.distcode,k=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{x<15&&(v+=S[l++]<<x,x+=8,v+=S[l++]<<x,x+=8),D=_[v&k];t:for(;;){if(v>>>=P=D>>>24,x-=P,(P=D>>>16&255)===0)Z[u++]=65535&D;else{if(!(16&P)){if((64&P)==0){D=_[(65535&D)+(v&(1<<P)-1)];continue t}if(32&P){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}R=65535&D,(P&=15)&&(x<P&&(v+=S[l++]<<x,x+=8),R+=v&(1<<P)-1,v>>>=P,x-=P),x<15&&(v+=S[l++]<<x,x+=8,v+=S[l++]<<x,x+=8),D=T[v&C];o:for(;;){if(v>>>=P=D>>>24,x-=P,!(16&(P=D>>>16&255))){if((64&P)==0){D=T[(65535&D)+(v&(1<<P)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(j=65535&D,x<(P&=15)&&(v+=S[l++]<<x,(x+=8)<P&&(v+=S[l++]<<x,x+=8)),d<(j+=v&(1<<P)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(v>>>=P,x-=P,(P=u-f)<j){if(m<(P=j-P)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(N=g,(B=0)===y){if(B+=b-P,P<R){for(R-=P;Z[u++]=g[B++],--P;);B=u-j,N=Z}}else if(y<P){if(B+=b+y-P,(P-=y)<R){for(R-=P;Z[u++]=g[B++],--P;);if(B=0,y<R){for(R-=P=y;Z[u++]=g[B++],--P;);B=u-j,N=Z}}}else if(B+=y-P,P<R){for(R-=P;Z[u++]=g[B++],--P;);B=u-j,N=Z}for(;2<R;)Z[u++]=N[B++],Z[u++]=N[B++],Z[u++]=N[B++],R-=3;R&&(Z[u++]=N[B++],1<R&&(Z[u++]=N[B++]))}else{for(B=u-j;Z[u++]=Z[B++],Z[u++]=Z[B++],Z[u++]=Z[B++],2<(R-=3););R&&(Z[u++]=Z[B++],1<R&&(Z[u++]=Z[B++]))}break}}break}}while(l<c&&u<p);l-=R=x>>3,v&=(1<<(x-=R<<3))-1,s.next_in=l,s.next_out=u,s.avail_in=l<c?c-l+5:5-(l-c),s.avail_out=u<p?p-u+257:257-(u-p),r.hold=v,r.bits=x}},{}],49:[function(o,i,n){var s=o("../utils/common"),a=o("./adler32"),r=o("./crc32"),l=o("./inffast"),c=o("./inftrees"),u=1,f=2,p=0,d=-2,b=1,m=852,y=592;function g(B){return(B>>>24&255)+(B>>>8&65280)+((65280&B)<<8)+((255&B)<<24)}function v(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x(B){var N;return B&&B.state?(N=B.state,B.total_in=B.total_out=N.total=0,B.msg="",N.wrap&&(B.adler=1&N.wrap),N.mode=b,N.last=0,N.havedict=0,N.dmax=32768,N.head=null,N.hold=0,N.bits=0,N.lencode=N.lendyn=new s.Buf32(m),N.distcode=N.distdyn=new s.Buf32(y),N.sane=1,N.back=-1,p):d}function _(B){var N;return B&&B.state?((N=B.state).wsize=0,N.whave=0,N.wnext=0,x(B)):d}function T(B,N){var S,Z;return B&&B.state?(Z=B.state,N<0?(S=0,N=-N):(S=1+(N>>4),N<48&&(N&=15)),N&&(N<8||15<N)?d:(Z.window!==null&&Z.wbits!==N&&(Z.window=null),Z.wrap=S,Z.wbits=N,_(B))):d}function k(B,N){var S,Z;return B?(Z=new v,(B.state=Z).window=null,(S=T(B,N))!==p&&(B.state=null),S):d}var C,D,P=!0;function R(B){if(P){var N;for(C=new s.Buf32(512),D=new s.Buf32(32),N=0;N<144;)B.lens[N++]=8;for(;N<256;)B.lens[N++]=9;for(;N<280;)B.lens[N++]=7;for(;N<288;)B.lens[N++]=8;for(c(u,B.lens,0,288,C,0,B.work,{bits:9}),N=0;N<32;)B.lens[N++]=5;c(f,B.lens,0,32,D,0,B.work,{bits:5}),P=!1}B.lencode=C,B.lenbits=9,B.distcode=D,B.distbits=5}function j(B,N,S,Z){var W,$=B.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new s.Buf8($.wsize)),Z>=$.wsize?(s.arraySet($.window,N,S-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(Z<(W=$.wsize-$.wnext)&&(W=Z),s.arraySet($.window,N,S-Z,W,$.wnext),(Z-=W)?(s.arraySet($.window,N,S-Z,Z,0),$.wnext=Z,$.whave=$.wsize):($.wnext+=W,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=W))),0}n.inflateReset=_,n.inflateReset2=T,n.inflateResetKeep=x,n.inflateInit=function(B){return k(B,15)},n.inflateInit2=k,n.inflate=function(B,N){var S,Z,W,$,M,E,Q,F,V,re,oe,ae,Se,$e,ke,Ce,z,ne,L,U,w,q,H,I,A=0,O=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!B||!B.state||!B.output||!B.input&&B.avail_in!==0)return d;(S=B.state).mode===12&&(S.mode=13),M=B.next_out,W=B.output,Q=B.avail_out,$=B.next_in,Z=B.input,E=B.avail_in,F=S.hold,V=S.bits,re=E,oe=Q,q=p;e:for(;;)switch(S.mode){case b:if(S.wrap===0){S.mode=13;break}for(;V<16;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(2&S.wrap&&F===35615){O[S.check=0]=255&F,O[1]=F>>>8&255,S.check=r(S.check,O,2,0),V=F=0,S.mode=2;break}if(S.flags=0,S.head&&(S.head.done=!1),!(1&S.wrap)||(((255&F)<<8)+(F>>8))%31){B.msg="incorrect header check",S.mode=30;break}if((15&F)!=8){B.msg="unknown compression method",S.mode=30;break}if(V-=4,w=8+(15&(F>>>=4)),S.wbits===0)S.wbits=w;else if(w>S.wbits){B.msg="invalid window size",S.mode=30;break}S.dmax=1<<w,B.adler=S.check=1,S.mode=512&F?10:12,V=F=0;break;case 2:for(;V<16;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(S.flags=F,(255&S.flags)!=8){B.msg="unknown compression method",S.mode=30;break}if(57344&S.flags){B.msg="unknown header flags set",S.mode=30;break}S.head&&(S.head.text=F>>8&1),512&S.flags&&(O[0]=255&F,O[1]=F>>>8&255,S.check=r(S.check,O,2,0)),V=F=0,S.mode=3;case 3:for(;V<32;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.head&&(S.head.time=F),512&S.flags&&(O[0]=255&F,O[1]=F>>>8&255,O[2]=F>>>16&255,O[3]=F>>>24&255,S.check=r(S.check,O,4,0)),V=F=0,S.mode=4;case 4:for(;V<16;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.head&&(S.head.xflags=255&F,S.head.os=F>>8),512&S.flags&&(O[0]=255&F,O[1]=F>>>8&255,S.check=r(S.check,O,2,0)),V=F=0,S.mode=5;case 5:if(1024&S.flags){for(;V<16;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.length=F,S.head&&(S.head.extra_len=F),512&S.flags&&(O[0]=255&F,O[1]=F>>>8&255,S.check=r(S.check,O,2,0)),V=F=0}else S.head&&(S.head.extra=null);S.mode=6;case 6:if(1024&S.flags&&(E<(ae=S.length)&&(ae=E),ae&&(S.head&&(w=S.head.extra_len-S.length,S.head.extra||(S.head.extra=new Array(S.head.extra_len)),s.arraySet(S.head.extra,Z,$,ae,w)),512&S.flags&&(S.check=r(S.check,Z,ae,$)),E-=ae,$+=ae,S.length-=ae),S.length))break e;S.length=0,S.mode=7;case 7:if(2048&S.flags){if(E===0)break e;for(ae=0;w=Z[$+ae++],S.head&&w&&S.length<65536&&(S.head.name+=String.fromCharCode(w)),w&&ae<E;);if(512&S.flags&&(S.check=r(S.check,Z,ae,$)),E-=ae,$+=ae,w)break e}else S.head&&(S.head.name=null);S.length=0,S.mode=8;case 8:if(4096&S.flags){if(E===0)break e;for(ae=0;w=Z[$+ae++],S.head&&w&&S.length<65536&&(S.head.comment+=String.fromCharCode(w)),w&&ae<E;);if(512&S.flags&&(S.check=r(S.check,Z,ae,$)),E-=ae,$+=ae,w)break e}else S.head&&(S.head.comment=null);S.mode=9;case 9:if(512&S.flags){for(;V<16;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(F!==(65535&S.check)){B.msg="header crc mismatch",S.mode=30;break}V=F=0}S.head&&(S.head.hcrc=S.flags>>9&1,S.head.done=!0),B.adler=S.check=0,S.mode=12;break;case 10:for(;V<32;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}B.adler=S.check=g(F),V=F=0,S.mode=11;case 11:if(S.havedict===0)return B.next_out=M,B.avail_out=Q,B.next_in=$,B.avail_in=E,S.hold=F,S.bits=V,2;B.adler=S.check=1,S.mode=12;case 12:if(N===5||N===6)break e;case 13:if(S.last){F>>>=7&V,V-=7&V,S.mode=27;break}for(;V<3;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}switch(S.last=1&F,V-=1,3&(F>>>=1)){case 0:S.mode=14;break;case 1:if(R(S),S.mode=20,N!==6)break;F>>>=2,V-=2;break e;case 2:S.mode=17;break;case 3:B.msg="invalid block type",S.mode=30}F>>>=2,V-=2;break;case 14:for(F>>>=7&V,V-=7&V;V<32;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if((65535&F)!=(F>>>16^65535)){B.msg="invalid stored block lengths",S.mode=30;break}if(S.length=65535&F,V=F=0,S.mode=15,N===6)break e;case 15:S.mode=16;case 16:if(ae=S.length){if(E<ae&&(ae=E),Q<ae&&(ae=Q),ae===0)break e;s.arraySet(W,Z,$,ae,M),E-=ae,$+=ae,Q-=ae,M+=ae,S.length-=ae;break}S.mode=12;break;case 17:for(;V<14;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(S.nlen=257+(31&F),F>>>=5,V-=5,S.ndist=1+(31&F),F>>>=5,V-=5,S.ncode=4+(15&F),F>>>=4,V-=4,286<S.nlen||30<S.ndist){B.msg="too many length or distance symbols",S.mode=30;break}S.have=0,S.mode=18;case 18:for(;S.have<S.ncode;){for(;V<3;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.lens[G[S.have++]]=7&F,F>>>=3,V-=3}for(;S.have<19;)S.lens[G[S.have++]]=0;if(S.lencode=S.lendyn,S.lenbits=7,H={bits:S.lenbits},q=c(0,S.lens,0,19,S.lencode,0,S.work,H),S.lenbits=H.bits,q){B.msg="invalid code lengths set",S.mode=30;break}S.have=0,S.mode=19;case 19:for(;S.have<S.nlen+S.ndist;){for(;Ce=(A=S.lencode[F&(1<<S.lenbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=V);){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(z<16)F>>>=ke,V-=ke,S.lens[S.have++]=z;else{if(z===16){for(I=ke+2;V<I;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(F>>>=ke,V-=ke,S.have===0){B.msg="invalid bit length repeat",S.mode=30;break}w=S.lens[S.have-1],ae=3+(3&F),F>>>=2,V-=2}else if(z===17){for(I=ke+3;V<I;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}V-=ke,w=0,ae=3+(7&(F>>>=ke)),F>>>=3,V-=3}else{for(I=ke+7;V<I;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}V-=ke,w=0,ae=11+(127&(F>>>=ke)),F>>>=7,V-=7}if(S.have+ae>S.nlen+S.ndist){B.msg="invalid bit length repeat",S.mode=30;break}for(;ae--;)S.lens[S.have++]=w}}if(S.mode===30)break;if(S.lens[256]===0){B.msg="invalid code -- missing end-of-block",S.mode=30;break}if(S.lenbits=9,H={bits:S.lenbits},q=c(u,S.lens,0,S.nlen,S.lencode,0,S.work,H),S.lenbits=H.bits,q){B.msg="invalid literal/lengths set",S.mode=30;break}if(S.distbits=6,S.distcode=S.distdyn,H={bits:S.distbits},q=c(f,S.lens,S.nlen,S.ndist,S.distcode,0,S.work,H),S.distbits=H.bits,q){B.msg="invalid distances set",S.mode=30;break}if(S.mode=20,N===6)break e;case 20:S.mode=21;case 21:if(6<=E&&258<=Q){B.next_out=M,B.avail_out=Q,B.next_in=$,B.avail_in=E,S.hold=F,S.bits=V,l(B,oe),M=B.next_out,W=B.output,Q=B.avail_out,$=B.next_in,Z=B.input,E=B.avail_in,F=S.hold,V=S.bits,S.mode===12&&(S.back=-1);break}for(S.back=0;Ce=(A=S.lencode[F&(1<<S.lenbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=V);){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(Ce&&(240&Ce)==0){for(ne=ke,L=Ce,U=z;Ce=(A=S.lencode[U+((F&(1<<ne+L)-1)>>ne)])>>>16&255,z=65535&A,!(ne+(ke=A>>>24)<=V);){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}F>>>=ne,V-=ne,S.back+=ne}if(F>>>=ke,V-=ke,S.back+=ke,S.length=z,Ce===0){S.mode=26;break}if(32&Ce){S.back=-1,S.mode=12;break}if(64&Ce){B.msg="invalid literal/length code",S.mode=30;break}S.extra=15&Ce,S.mode=22;case 22:if(S.extra){for(I=S.extra;V<I;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.length+=F&(1<<S.extra)-1,F>>>=S.extra,V-=S.extra,S.back+=S.extra}S.was=S.length,S.mode=23;case 23:for(;Ce=(A=S.distcode[F&(1<<S.distbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=V);){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if((240&Ce)==0){for(ne=ke,L=Ce,U=z;Ce=(A=S.distcode[U+((F&(1<<ne+L)-1)>>ne)])>>>16&255,z=65535&A,!(ne+(ke=A>>>24)<=V);){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}F>>>=ne,V-=ne,S.back+=ne}if(F>>>=ke,V-=ke,S.back+=ke,64&Ce){B.msg="invalid distance code",S.mode=30;break}S.offset=z,S.extra=15&Ce,S.mode=24;case 24:if(S.extra){for(I=S.extra;V<I;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}S.offset+=F&(1<<S.extra)-1,F>>>=S.extra,V-=S.extra,S.back+=S.extra}if(S.offset>S.dmax){B.msg="invalid distance too far back",S.mode=30;break}S.mode=25;case 25:if(Q===0)break e;if(ae=oe-Q,S.offset>ae){if((ae=S.offset-ae)>S.whave&&S.sane){B.msg="invalid distance too far back",S.mode=30;break}Se=ae>S.wnext?(ae-=S.wnext,S.wsize-ae):S.wnext-ae,ae>S.length&&(ae=S.length),$e=S.window}else $e=W,Se=M-S.offset,ae=S.length;for(Q<ae&&(ae=Q),Q-=ae,S.length-=ae;W[M++]=$e[Se++],--ae;);S.length===0&&(S.mode=21);break;case 26:if(Q===0)break e;W[M++]=S.length,Q--,S.mode=21;break;case 27:if(S.wrap){for(;V<32;){if(E===0)break e;E--,F|=Z[$++]<<V,V+=8}if(oe-=Q,B.total_out+=oe,S.total+=oe,oe&&(B.adler=S.check=S.flags?r(S.check,W,oe,M-oe):a(S.check,W,oe,M-oe)),oe=Q,(S.flags?F:g(F))!==S.check){B.msg="incorrect data check",S.mode=30;break}V=F=0}S.mode=28;case 28:if(S.wrap&&S.flags){for(;V<32;){if(E===0)break e;E--,F+=Z[$++]<<V,V+=8}if(F!==(4294967295&S.total)){B.msg="incorrect length check",S.mode=30;break}V=F=0}S.mode=29;case 29:q=1;break e;case 30:q=-3;break e;case 31:return-4;case 32:default:return d}return B.next_out=M,B.avail_out=Q,B.next_in=$,B.avail_in=E,S.hold=F,S.bits=V,(S.wsize||oe!==B.avail_out&&S.mode<30&&(S.mode<27||N!==4))&&j(B,B.output,B.next_out,oe-B.avail_out)?(S.mode=31,-4):(re-=B.avail_in,oe-=B.avail_out,B.total_in+=re,B.total_out+=oe,S.total+=oe,S.wrap&&oe&&(B.adler=S.check=S.flags?r(S.check,W,oe,B.next_out-oe):a(S.check,W,oe,B.next_out-oe)),B.data_type=S.bits+(S.last?64:0)+(S.mode===12?128:0)+(S.mode===20||S.mode===15?256:0),(re==0&&oe===0||N===4)&&q===p&&(q=-5),q)},n.inflateEnd=function(B){if(!B||!B.state)return d;var N=B.state;return N.window&&(N.window=null),B.state=null,p},n.inflateGetHeader=function(B,N){var S;return B&&B.state?(2&(S=B.state).wrap)==0?d:((S.head=N).done=!1,p):d},n.inflateSetDictionary=function(B,N){var S,Z=N.length;return B&&B.state?(S=B.state).wrap!==0&&S.mode!==11?d:S.mode===11&&a(1,N,Z,0)!==S.check?-3:j(B,N,Z,Z)?(S.mode=31,-4):(S.havedict=1,p):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,f,p,d,b,m,y,g){var v,x,_,T,k,C,D,P,R,j=g.bits,B=0,N=0,S=0,Z=0,W=0,$=0,M=0,E=0,Q=0,F=0,V=null,re=0,oe=new s.Buf16(16),ae=new s.Buf16(16),Se=null,$e=0;for(B=0;B<=15;B++)oe[B]=0;for(N=0;N<d;N++)oe[f[p+N]]++;for(W=j,Z=15;1<=Z&&oe[Z]===0;Z--);if(Z<W&&(W=Z),Z===0)return b[m++]=20971520,b[m++]=20971520,g.bits=1,0;for(S=1;S<Z&&oe[S]===0;S++);for(W<S&&(W=S),B=E=1;B<=15;B++)if(E<<=1,(E-=oe[B])<0)return-1;if(0<E&&(u===0||Z!==1))return-1;for(ae[1]=0,B=1;B<15;B++)ae[B+1]=ae[B]+oe[B];for(N=0;N<d;N++)f[p+N]!==0&&(y[ae[f[p+N]]++]=N);if(C=u===0?(V=Se=y,19):u===1?(V=a,re-=257,Se=r,$e-=257,256):(V=l,Se=c,-1),B=S,k=m,M=N=F=0,_=-1,T=(Q=1<<($=W))-1,u===1&&852<Q||u===2&&592<Q)return 1;for(;;){for(D=B-M,R=y[N]<C?(P=0,y[N]):y[N]>C?(P=Se[$e+y[N]],V[re+y[N]]):(P=96,0),v=1<<B-M,S=x=1<<$;b[k+(F>>M)+(x-=v)]=D<<24|P<<16|R|0,x!==0;);for(v=1<<B-1;F&v;)v>>=1;if(v!==0?(F&=v-1,F+=v):F=0,N++,--oe[B]==0){if(B===Z)break;B=f[p+y[N]]}if(W<B&&(F&T)!==_){for(M===0&&(M=W),k+=S,E=1<<($=B-M);$+M<Z&&!((E-=oe[$+M])<=0);)$++,E<<=1;if(Q+=1<<$,u===1&&852<Q||u===2&&592<Q)return 1;b[_=F&T]=W<<24|$<<16|k-m|0}}return F!==0&&(b[k+F]=B-M<<24|64<<16|0),g.bits=W,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),a=0,r=1;function l(A){for(var O=A.length;0<=--O;)A[O]=0}var c=0,u=29,f=256,p=f+1+u,d=30,b=19,m=2*p+1,y=15,g=16,v=7,x=256,_=16,T=17,k=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],P=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],j=new Array(2*(p+2));l(j);var B=new Array(2*d);l(B);var N=new Array(512);l(N);var S=new Array(256);l(S);var Z=new Array(u);l(Z);var W,$,M,E=new Array(d);function Q(A,O,G,K,Y){this.static_tree=A,this.extra_bits=O,this.extra_base=G,this.elems=K,this.max_length=Y,this.has_stree=A&&A.length}function F(A,O){this.dyn_tree=A,this.max_code=0,this.stat_desc=O}function V(A){return A<256?N[A]:N[256+(A>>>7)]}function re(A,O){A.pending_buf[A.pending++]=255&O,A.pending_buf[A.pending++]=O>>>8&255}function oe(A,O,G){A.bi_valid>g-G?(A.bi_buf|=O<<A.bi_valid&65535,re(A,A.bi_buf),A.bi_buf=O>>g-A.bi_valid,A.bi_valid+=G-g):(A.bi_buf|=O<<A.bi_valid&65535,A.bi_valid+=G)}function ae(A,O,G){oe(A,G[2*O],G[2*O+1])}function Se(A,O){for(var G=0;G|=1&A,A>>>=1,G<<=1,0<--O;);return G>>>1}function $e(A,O,G){var K,Y,ee=new Array(y+1),ce=0;for(K=1;K<=y;K++)ee[K]=ce=ce+G[K-1]<<1;for(Y=0;Y<=O;Y++){var se=A[2*Y+1];se!==0&&(A[2*Y]=Se(ee[se]++,se))}}function ke(A){var O;for(O=0;O<p;O++)A.dyn_ltree[2*O]=0;for(O=0;O<d;O++)A.dyn_dtree[2*O]=0;for(O=0;O<b;O++)A.bl_tree[2*O]=0;A.dyn_ltree[2*x]=1,A.opt_len=A.static_len=0,A.last_lit=A.matches=0}function Ce(A){8<A.bi_valid?re(A,A.bi_buf):0<A.bi_valid&&(A.pending_buf[A.pending++]=A.bi_buf),A.bi_buf=0,A.bi_valid=0}function z(A,O,G,K){var Y=2*O,ee=2*G;return A[Y]<A[ee]||A[Y]===A[ee]&&K[O]<=K[G]}function ne(A,O,G){for(var K=A.heap[G],Y=G<<1;Y<=A.heap_len&&(Y<A.heap_len&&z(O,A.heap[Y+1],A.heap[Y],A.depth)&&Y++,!z(O,K,A.heap[Y],A.depth));)A.heap[G]=A.heap[Y],G=Y,Y<<=1;A.heap[G]=K}function L(A,O,G){var K,Y,ee,ce,se=0;if(A.last_lit!==0)for(;K=A.pending_buf[A.d_buf+2*se]<<8|A.pending_buf[A.d_buf+2*se+1],Y=A.pending_buf[A.l_buf+se],se++,K===0?ae(A,Y,O):(ae(A,(ee=S[Y])+f+1,O),(ce=C[ee])!==0&&oe(A,Y-=Z[ee],ce),ae(A,ee=V(--K),G),(ce=D[ee])!==0&&oe(A,K-=E[ee],ce)),se<A.last_lit;);ae(A,x,O)}function U(A,O){var G,K,Y,ee=O.dyn_tree,ce=O.stat_desc.static_tree,se=O.stat_desc.has_stree,me=O.stat_desc.elems,_e=-1;for(A.heap_len=0,A.heap_max=m,G=0;G<me;G++)ee[2*G]!==0?(A.heap[++A.heap_len]=_e=G,A.depth[G]=0):ee[2*G+1]=0;for(;A.heap_len<2;)ee[2*(Y=A.heap[++A.heap_len]=_e<2?++_e:0)]=1,A.depth[Y]=0,A.opt_len--,se&&(A.static_len-=ce[2*Y+1]);for(O.max_code=_e,G=A.heap_len>>1;1<=G;G--)ne(A,ee,G);for(Y=me;G=A.heap[1],A.heap[1]=A.heap[A.heap_len--],ne(A,ee,1),K=A.heap[1],A.heap[--A.heap_max]=G,A.heap[--A.heap_max]=K,ee[2*Y]=ee[2*G]+ee[2*K],A.depth[Y]=(A.depth[G]>=A.depth[K]?A.depth[G]:A.depth[K])+1,ee[2*G+1]=ee[2*K+1]=Y,A.heap[1]=Y++,ne(A,ee,1),2<=A.heap_len;);A.heap[--A.heap_max]=A.heap[1],(function(we,De){var He,Ge,rt,Pe,ft,tt,Ye=De.dyn_tree,fe=De.max_code,he=De.stat_desc.static_tree,Qe=De.stat_desc.has_stree,at=De.stat_desc.extra_bits,$t=De.stat_desc.extra_base,lt=De.stat_desc.max_length,co=0;for(Pe=0;Pe<=y;Pe++)we.bl_count[Pe]=0;for(Ye[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<m;He++)lt<(Pe=Ye[2*Ye[2*(Ge=we.heap[He])+1]+1]+1)&&(Pe=lt,co++),Ye[2*Ge+1]=Pe,fe<Ge||(we.bl_count[Pe]++,ft=0,$t<=Ge&&(ft=at[Ge-$t]),tt=Ye[2*Ge],we.opt_len+=tt*(Pe+ft),Qe&&(we.static_len+=tt*(he[2*Ge+1]+ft)));if(co!==0){do{for(Pe=lt-1;we.bl_count[Pe]===0;)Pe--;we.bl_count[Pe]--,we.bl_count[Pe+1]+=2,we.bl_count[lt]--,co-=2}while(0<co);for(Pe=lt;Pe!==0;Pe--)for(Ge=we.bl_count[Pe];Ge!==0;)fe<(rt=we.heap[--He])||(Ye[2*rt+1]!==Pe&&(we.opt_len+=(Pe-Ye[2*rt+1])*Ye[2*rt],Ye[2*rt+1]=Pe),Ge--)}})(A,O),$e(ee,_e,A.bl_count)}function w(A,O,G){var K,Y,ee=-1,ce=O[1],se=0,me=7,_e=4;for(ce===0&&(me=138,_e=3),O[2*(G+1)+1]=65535,K=0;K<=G;K++)Y=ce,ce=O[2*(K+1)+1],++se<me&&Y===ce||(se<_e?A.bl_tree[2*Y]+=se:Y!==0?(Y!==ee&&A.bl_tree[2*Y]++,A.bl_tree[2*_]++):se<=10?A.bl_tree[2*T]++:A.bl_tree[2*k]++,ee=Y,_e=(se=0)===ce?(me=138,3):Y===ce?(me=6,3):(me=7,4))}function q(A,O,G){var K,Y,ee=-1,ce=O[1],se=0,me=7,_e=4;for(ce===0&&(me=138,_e=3),K=0;K<=G;K++)if(Y=ce,ce=O[2*(K+1)+1],!(++se<me&&Y===ce)){if(se<_e)for(;ae(A,Y,A.bl_tree),--se!=0;);else Y!==0?(Y!==ee&&(ae(A,Y,A.bl_tree),se--),ae(A,_,A.bl_tree),oe(A,se-3,2)):se<=10?(ae(A,T,A.bl_tree),oe(A,se-3,3)):(ae(A,k,A.bl_tree),oe(A,se-11,7));ee=Y,_e=(se=0)===ce?(me=138,3):Y===ce?(me=6,3):(me=7,4)}}l(E);var H=!1;function I(A,O,G,K){oe(A,(c<<1)+(K?1:0),3),(function(Y,ee,ce,se){Ce(Y),re(Y,ce),re(Y,~ce),s.arraySet(Y.pending_buf,Y.window,ee,ce,Y.pending),Y.pending+=ce})(A,O,G)}n._tr_init=function(A){H||((function(){var O,G,K,Y,ee,ce=new Array(y+1);for(Y=K=0;Y<u-1;Y++)for(Z[Y]=K,O=0;O<1<<C[Y];O++)S[K++]=Y;for(S[K-1]=Y,Y=ee=0;Y<16;Y++)for(E[Y]=ee,O=0;O<1<<D[Y];O++)N[ee++]=Y;for(ee>>=7;Y<d;Y++)for(E[Y]=ee<<7,O=0;O<1<<D[Y]-7;O++)N[256+ee++]=Y;for(G=0;G<=y;G++)ce[G]=0;for(O=0;O<=143;)j[2*O+1]=8,O++,ce[8]++;for(;O<=255;)j[2*O+1]=9,O++,ce[9]++;for(;O<=279;)j[2*O+1]=7,O++,ce[7]++;for(;O<=287;)j[2*O+1]=8,O++,ce[8]++;for($e(j,p+1,ce),O=0;O<d;O++)B[2*O+1]=5,B[2*O]=Se(O,5);W=new Q(j,C,f+1,p,y),$=new Q(B,D,0,d,y),M=new Q(new Array(0),P,0,b,v)})(),H=!0),A.l_desc=new F(A.dyn_ltree,W),A.d_desc=new F(A.dyn_dtree,$),A.bl_desc=new F(A.bl_tree,M),A.bi_buf=0,A.bi_valid=0,ke(A)},n._tr_stored_block=I,n._tr_flush_block=function(A,O,G,K){var Y,ee,ce=0;0<A.level?(A.strm.data_type===2&&(A.strm.data_type=(function(se){var me,_e=4093624447;for(me=0;me<=31;me++,_e>>>=1)if(1&_e&&se.dyn_ltree[2*me]!==0)return a;if(se.dyn_ltree[18]!==0||se.dyn_ltree[20]!==0||se.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(se.dyn_ltree[2*me]!==0)return r;return a})(A)),U(A,A.l_desc),U(A,A.d_desc),ce=(function(se){var me;for(w(se,se.dyn_ltree,se.l_desc.max_code),w(se,se.dyn_dtree,se.d_desc.max_code),U(se,se.bl_desc),me=b-1;3<=me&&se.bl_tree[2*R[me]+1]===0;me--);return se.opt_len+=3*(me+1)+5+5+4,me})(A),Y=A.opt_len+3+7>>>3,(ee=A.static_len+3+7>>>3)<=Y&&(Y=ee)):Y=ee=G+5,G+4<=Y&&O!==-1?I(A,O,G,K):A.strategy===4||ee===Y?(oe(A,2+(K?1:0),3),L(A,j,B)):(oe(A,4+(K?1:0),3),(function(se,me,_e,we){var De;for(oe(se,me-257,5),oe(se,_e-1,5),oe(se,we-4,4),De=0;De<we;De++)oe(se,se.bl_tree[2*R[De]+1],3);q(se,se.dyn_ltree,me-1),q(se,se.dyn_dtree,_e-1)})(A,A.l_desc.max_code+1,A.d_desc.max_code+1,ce+1),L(A,A.dyn_ltree,A.dyn_dtree)),ke(A),K&&Ce(A)},n._tr_tally=function(A,O,G){return A.pending_buf[A.d_buf+2*A.last_lit]=O>>>8&255,A.pending_buf[A.d_buf+2*A.last_lit+1]=255&O,A.pending_buf[A.l_buf+A.last_lit]=255&G,A.last_lit++,O===0?A.dyn_ltree[2*G]++:(A.matches++,O--,A.dyn_ltree[2*(S[G]+f+1)]++,A.dyn_dtree[2*V(O)]++),A.last_lit===A.lit_bufsize-1},n._tr_align=function(A){oe(A,2,3),ae(A,x,j),(function(O){O.bi_valid===16?(re(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})(A)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(a,r){if(!a.setImmediate){var l,c,u,f,p=1,d={},b=!1,m=a.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(a);y=y&&y.setTimeout?y:a,l={}.toString.call(a.process)==="[object process]"?function(_){process.nextTick(function(){v(_)})}:(function(){if(a.postMessage&&!a.importScripts){var _=!0,T=a.onmessage;return a.onmessage=function(){_=!1},a.postMessage("","*"),a.onmessage=T,_}})()?(f="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",x,!1):a.attachEvent("onmessage",x),function(_){a.postMessage(f+_,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(_){v(_.data)},function(_){u.port2.postMessage(_)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(_){var T=m.createElement("script");T.onreadystatechange=function(){v(_),T.onreadystatechange=null,c.removeChild(T),T=null},c.appendChild(T)}):function(_){setTimeout(v,0,_)},y.setImmediate=function(_){typeof _!="function"&&(_=new Function(""+_));for(var T=new Array(arguments.length-1),k=0;k<T.length;k++)T[k]=arguments[k+1];var C={callback:_,args:T};return d[p]=C,l(p),p++},y.clearImmediate=g}function g(_){delete d[_]}function v(_){if(b)setTimeout(v,0,_);else{var T=d[_];if(T){b=!0;try{(function(k){var C=k.callback,D=k.args;switch(D.length){case 0:C();break;case 1:C(D[0]);break;case 2:C(D[0],D[1]);break;case 3:C(D[0],D[1],D[2]);break;default:C.apply(r,D)}})(T)}finally{g(_),b=!1}}}}function x(_){_.source===a&&typeof _.data=="string"&&_.data.indexOf(f)===0&&v(+_.data.slice(f.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ss)),Ss.exports}var Mg=Ag();const mc=Tg(Mg);function gc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function yc(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],a=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const s=await vi(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function Eg(e,t,o){var c,u,f;const i=A2(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const a=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await yc(e,a));const l=gc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const p=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of p){const b=d.querySelector(".item__text"),m=((f=b==null?void 0:b.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){b&&(b.textContent=l),d.setAttribute("title",l);break}}}}function Ni(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function zo(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const a=await o.fetchDocumentTitle(i);if(a&&a.trim())return Ni(a)}catch{}if(typeof document<"u")try{const a=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return Ni(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Ni(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return Ni(l)}return"presentation"}function Bg(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function Ba(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function Lg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Zs(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(l=>l()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{s(),o({success:!0,dataUrl:l.dataUrl})});i.push(a);const r=e.onCaptureError(l=>{s(),o({success:!1,error:l})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function bc(e,t){const o=[],i=Ni((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),s.forEach(d=>d()),s=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(d=>{var b;l(),(b=t==null?void 0:t.onProgress)==null||b.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{l(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const f=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new mc,b=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const g of o){const v=String(g.pageIndex).padStart(2,"0"),x=g.dataUrl.split(",")[1];d.file(`slide-${v}.${b}`,x,{base64:!0})}const m=await d.generateAsync({type:"blob",compression:"DEFLATE"}),y=Bg(`${i}.zip`,m);n({success:y,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(f));const p=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(p),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function vc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new ns;i.attach(o);try{if(await new Promise((n,s)=>{const a=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(a),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Zs(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await zo(e,e.docId);return await bc(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const Dg=1500,Ng=500,Og=4,Pg=new Set(["INPUT","TEXTAREA","SELECT"]);function kc(e){const t=e;return!t||!t.tagName?!1:Pg.has(t.tagName)||t.isContentEditable===!0}function Rg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function a(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){a(),t="",o=!1,s()}function l(){i&&clearTimeout(i),i=setTimeout(r,Dg)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,Ng)}function u(f){if(e.isEnabled&&!e.isEnabled()||kc(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return o||t.length>=Og||(t+=f.key,s(),l()),!0;if(f.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),b=e.getTotalPages();return!isNaN(d)&&d>=1&&b>0&&d<=b?(r(),e.onJump(d),!0):(c(),!0)}return f.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const zg={class:"spm-slides-tab__toolbar"},Hg={class:"spm-slides-tab__nav"},Fg=["disabled"],jg={class:"spm-page-badge"},Ug=["disabled"],Wg=["aria-label"],qg={class:"spm-slides-tab__tools"},Vg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Kg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Gg=["src"],Yg=Ht({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Gt("plugin"),i=Gt("sandboxBridge",new ns),n=new tg(i),s=pe(null),a=pe(!1),r=pe(null),l=pe(1),c=pe(1),u=pe(!1),f=pe(!1),p=pe(!1),d=pe("siyuan"),b=pe(""),m=pe(""),y=pe(""),g=pe(!1),v=pe(!1),x=pe(""),_=pe(""),T=pe(!1),k=Rg({getTotalPages:()=>c.value,isEnabled:()=>!f.value,onJump:I=>P(I),onStateChange:I=>{_.value=I.display,T.value=I.invalid}});function C(I){if(I.key==="o"||I.key==="O"){if(f.value||I.isComposing||I.ctrlKey||I.metaKey||I.altKey||kc(I.target))return;I.preventDefault(),D();return}k.handleKeydown(I)&&I.preventDefault()}function D(){var I;i.toggleOverview(),(I=r.value)==null||I.focus()}function P(I){var A;l.value=I,i.navigatePage(I),(A=r.value)==null||A.focus()}const R=pe("/plugins/siyuan-live-slides/slides-client/index.html");let j=null,B=null,N=null,S=null,Z=null,W=null,$=null,M=null;ti(()=>{r.value&&i.attach(r.value),j=i.onSlideChanged((I,A)=>{l.value=I,c.value=A}),B=i.onBlockClicked((I,A)=>{l.value=A,n.setActiveBlockId(I),I||qi(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide(I,A):I&&Ro(I,o==null?void 0:o.app)}),N=i.onOpenInEditor((I,A)=>{l.value=A,n.setActiveBlockId(I),Ro(I,o==null?void 0:o.app)}),S=i.onOpenPeekDrawer(async I=>{const A=Fo();if(I.peekType==="siyuan"&&A.enableWebServeJump){let O=!1;if(M&&M.docId===I.target)O=!0;else if(M&&M.slides&&M.slides.some(G=>{var K;return(K=G.blocks)==null?void 0:K.some(Y=>Y.id===I.target)}))O=!1;else try{const G=await vi(`SELECT id, root_id, type FROM blocks WHERE id = '${I.target}' LIMIT 1`);G&&G.length>0&&(O=G[0].type==="d"||G[0].id===G[0].root_id)}catch(G){console.warn("[SlidesPreviewTab] detect block type failed:",G)}d.value="web",g.value=!0,m.value=ec(A.webServeUrl,I.target,{focus:!O}),y.value=I.title||`${O?"思源文档":"思源块"}: ${I.target.slice(0,8)}`,f.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=I.peekType,I.peekType==="siyuan")b.value=I.target,y.value=I.title||`块速览: ${I.target.slice(0,8)}`;else{const O=ac(I.target);if(O.external){$e(I.target);return}g.value=!0,m.value=O.url,y.value=I.title||O.url}f.value=!0,i.freezeKeyboardNav(!0)}}),Z=i.onRequestToggleFullscreen(()=>{Ce()}),W=i.onOpenPresenter(()=>{z()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ke),$=sc(I=>{M&&i.updateSlides(M.slides,{...M.config,hostThemeMode:I},M.customThemeCss)})}),sn(()=>{$&&($(),$=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ke),S&&S(),Z&&Z(),W&&W(),j&&j(),B&&B(),N&&N(),i.detach(),k.clear(),n.destroy()});function E(){v.value=!v.value,v.value?(x.value=(M==null?void 0:M.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",x.value)):(x.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let Q=0;function F(I){if(f.value||Math.abs(I.deltaY)<Math.abs(I.deltaX)||Math.abs(I.deltaY)<15)return;const A=Date.now();A-Q<280||(Q=A,I.deltaY>0?re():V())}function V(){if(l.value>1){const I=l.value-1;l.value=I,i.navigatePage(I)}}function re(){if(l.value<c.value){const I=l.value+1;l.value=I,i.navigatePage(I)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function ae(){f.value=!1,i.freezeKeyboardNav(!1)}function Se(){ae()}function $e(I){var K,Y;const A=/^file:/i.test(I),O=A||/^[a-zA-Z]:[\\/]/.test(I),G=an("electron");if(O&&typeof((K=G==null?void 0:G.shell)==null?void 0:K.openPath)=="function"){G.shell.openPath(A?rc(I):I),ie.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Y=G==null?void 0:G.shell)==null?void 0:Y.openExternal)=="function"?G.shell.openExternal(I).catch(()=>{typeof window<"u"&&window.open(I,"_blank")}):typeof window<"u"&&window.open(I,"_blank"),ie.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ke(){typeof document<"u"&&(a.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:a.value}))}function Ce(){const I=s.value||r.value;I&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):I.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function z(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function ne(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const I=await zo(M,o==null?void 0:o.currentDocId,o);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const A=await fc(M,{title:I});hc(`${I}.html`,A)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${I}.html)`)}function L(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}pc(M)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const U=pe(!1);async function w(){if(U.value){ie.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}U.value=!0;try{ie.showMessage("正在逐页导出幻灯片图片...",2e3);const I=await zo(M,o==null?void 0:o.currentDocId,o),A=await bc(i,{title:I,onProgress:(O,G)=>{ie.showMessage(`正在导出幻灯片图片 (${O} / ${G})...`,1500)}});A.success?ie.showMessage(`🎉 成功导出 ${A.total||0} 张高清图片并保存为 ${I}.zip！`,4e3):ie.showMessage(`导出图片失败：${A.error||"未知异常"}`)}finally{U.value=!1}}async function q(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在导出当前幻灯片图片...",1500);const I=await Zs(i);if(I.success&&I.dataUrl){const A=await zo(M,o==null?void 0:o.currentDocId,o),O=l.value||1,K=(c.value||1)>1?`${A}-${O}.png`:`${A}.png`;Ba(K,I.dataUrl),ie.showMessage(`已下载当前页高清图片 (${K})`)}else ie.showMessage(`导出当前页图片失败：${I.error||"未知异常"}`)}async function H(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const I=await Zs(i);if(I.success&&I.dataUrl)if(await Lg(I.dataUrl))ie.showMessage(`已成功将第 ${l.value||1} 页幻灯片复制到剪贴板！`);else{const O=await zo(M,o==null?void 0:o.currentDocId,o),G=l.value||1,Y=(c.value||1)>1?`${O}-${G}.png`:`${O}.png`;Ba(Y,I.dataUrl),ie.showMessage(`剪贴板权限不可用，已自动下载为 ${Y}`)}else ie.showMessage(`复制失败：${I.error||"未知异常"}`)}return t({updateDocument(I,A){v.value&&x.value&&A&&A!==x.value||(M=I,v.value&&!x.value&&(x.value=I.docId),c.value=I.slides.length,n.setDocId(I.docId),n.updateSlidesIndex(I.slides),i.updateSlides(I.slides,{...I.config,hostThemeMode:Uo()},I.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",I.docId))},navigateToBlock(I){n.onCursorFocusBlock(I)},isPinned:v,pinnedDocId:x}),(I,A)=>(J(),X("div",{class:"spm-slides-preview-tab",onKeydown:C},[h("div",zg,[h("div",Hg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:l.value<=1,"aria-label":"上一页",onClick:V},[le(de,{name:"chevron-left"})],8,Fg),h("span",jg,ve(l.value)+" / "+ve(c.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:l.value>=c.value,"aria-label":"下一页",onClick:re},[le(de,{name:"chevron-right"})],8,Ug),h("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":v.value}]),"aria-label":v.value?"已锁定当前文档（点击解除）："+x.value:"点击锁定当前文档（不随主编辑区切换）",onClick:E},[le(de,{name:"pin"}),h("span",null,ve(v.value?"已锁定":"跟随"),1)],10,Wg)]),h("div",qg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:D},[le(de,{name:"layout-grid"})]),ue(Ot)("presenterMode")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:z},[le(de,{name:"presenter"})])):Ae("",!0),ue(Ot)("exportHtml")?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ne},[le(de,{name:"export-html"})])):Ae("",!0),ue(Ot)("exportPdf")?(J(),X("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:L},[le(de,{name:"export-pdf"})])):Ae("",!0),ue(Ot)("exportImage")?(J(),X("div",Vg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:w},[le(de,{name:"export-image"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:A[0]||(A[0]=no(O=>u.value=!u.value,["stop"]))},[le(de,{name:"chevron-down"})]),u.value?(J(),X("div",Kg,[h("button",{class:"b3-menu__item",onClick:A[1]||(A[1]=O=>{w(),u.value=!1})},[...A[6]||(A[6]=[h("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),h("button",{class:"b3-menu__item",onClick:A[2]||(A[2]=O=>{q(),u.value=!1})},[...A[7]||(A[7]=[h("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),h("button",{class:"b3-menu__item",onClick:A[3]||(A[3]=O=>{H(),u.value=!1})},[...A[8]||(A[8]=[h("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Ae("",!0)])):Ae("",!0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[le(de,{name:"refresh"})]),h("button",{class:"spm-icon-btn is-primary spm-btn-fullscreen b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:Ce},[le(de,{name:"fullscreen"}),A[9]||(A[9]=h("span",{class:"spm-btn-fullscreen__label"},"全屏放映",-1))])])]),h("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:F},[h("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:R.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Gg),le(cm,{visible:f.value,"onUpdate:visible":A[4]||(A[4]=O=>f.value=O),"is-maximized":p.value,"onUpdate:isMaximized":A[5]||(A[5]=O=>p.value=O),title:y.value,onClose:ae},{default:Sl(()=>[d.value==="siyuan"&&b.value?(J(),Vt(xm,{key:0,"block-id":b.value,title:y.value,plugin:ue(o),onExternalJump:Se},null,8,["block-id","title","plugin"])):Ae("",!0),g.value?Wt((J(),Vt(Qm,{key:1,visible:f.value&&d.value==="web",url:m.value,title:y.value,onExternalJump:Se},null,8,["visible","url","title"])),[[Us,d.value==="web"]]):Ae("",!0)]),_:1},8,["visible","is-maximized","title"]),Wt(h("div",{class:xe(["spm-jump-badge",{"is-invalid":T.value}])},ve(_.value),3),[[Us,_.value]])],544)],32))}}),Zg=lo(Yg,[["__scopeId","data-v-7d559c8a"]]);function wc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&o.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const p=parseInt(f,10);n=Math.max(n,p),i.set(r.parentContainerId,p)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const f=i.get(r.parentContainerId);s(r,{type:"step",step:f})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const p=Math.min(Number(f[0]),Number(f[1])),d=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(p)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:p,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;n+=f,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;n=Math.max(1,n-f),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){n=Math.max(n,f),s(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function Jg(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Js=980;function Xg(e){if(!e)return 0;const o=wc(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=Od(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function Qg(e,t=Js){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",a=o.split(s).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(i=a[0]/a[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function La(e,t,o=Js,i=552,n=16){const s=o>0?o:Js,a=i>0?i:552,r=Math.max(0,e-n),l=Math.max(0,t-n);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/s,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(a*u))}}function ey(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function Da(e,t){if(!e)return"";const o=ey(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?wc(o.blocks||[]):null,u=uc(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:l?x=>{if(Jg(x,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const T=x.id||x.blockId,k=l.blockMap.get(x)||(T?l.idMap.get(T):void 0);if((k==null?void 0:k.type)==="step"&&k.step===r||(k==null?void 0:k.type)==="range"&&k.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(x,_)=>{let T=_.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(T)||(T+=" muted"),`<video ${T.trim()}>`}),f=i.spacing,p=f&&f!=="inherit"?f:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${p}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),b=[],m=(i.background||s.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const x=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;b.push(`background-image:url('${nt(x)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${nt(m)};`);const y=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,g=!isNaN(y)&&y>0?y:1;g!==1&&b.push(`width:${(100/g).toFixed(2)}%;height:${(100/g).toFixed(2)}%;transform-origin:top left;transform:scale(${g});`);const v=b.length>0?` style="${b.join("")}"`:"";return`<div class="${nt(d)}"${v}>${u}</div>`}const ty={class:"presenter-header"},oy={class:"presenter-title-area"},iy={class:"presenter-brand"},ny={class:"header-pills"},sy={class:"pill pill-page"},ry={key:0,class:"pill pill-step"},ay={class:"header-toolbar"},ly={class:"timer-capsule"},cy={class:"timer-digits"},dy={class:"timer-actions"},uy=["aria-label"],fy={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},hy={key:0,class:"presenter-grid"},py={class:"slide-panels"},my={class:"panel-box current-slide-panel"},gy={class:"panel-header"},yy={class:"panel-header-left"},by={class:"panel-page-num"},vy={class:"panel-header-meta"},ky={key:0,class:"panel-step-pill"},wy={class:"panel-layout-pill"},xy=["aria-label"],Sy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Cy={key:1,class:"panel-fallback"},_y=["aria-label"],Iy={class:"panel-header"},$y={class:"panel-header-left"},Ty={key:0,class:"panel-page-num"},Ay={class:"panel-header-meta"},My={key:0,class:"panel-end-pill"},Ey={key:1,class:"panel-layout-pill"},By=["aria-label"],Ly=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Dy={key:1,class:"panel-fallback"},Ny={class:"notes-panel"},Oy={class:"panel-header"},Py={class:"panel-header-left"},Ry={class:"notes-size-controls"},zy=["disabled"],Hy={class:"notes-size-value"},Fy=["disabled"],jy={key:1,class:"presenter-empty"},Uy={class:"empty-icon-wrap"},Wy={class:"empty-actions"},qy={class:"presenter-actions"},Vy={class:"nav-btn-group"},Ky=["disabled"],Gy=["disabled"],Yy={class:"actions-center"},Zy={class:"center-meta"},Jy={class:"progress-pill"},Xy={class:"nav-btn-group"},Qy=["aria-label"],eb={class:"step-dots-text"},tb=["disabled"],ob=["disabled"],ib=280,nb=15,sb=Ht({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Gt("plugin"),i=Gt("sandboxBridge",new ns),n=pe([]),s=pe({}),a=pe(1),r=pe(0),l=pe(0),c=pe(0),u=ye(()=>n.value.length||l.value),f=pe(null),p=pe(null),d=pe({width:0,height:0}),b=pe({width:0,height:0}),m=pe(Uo()),y=ye(()=>{var fe;return Qg((fe=s.value)==null?void 0:fe.aspectRatio)}),g=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.theme)||"apple-basic"}),v=ye(()=>{var fe;return _r((fe=s.value)==null?void 0:fe.colorSchema,m.value)}),x=ye(()=>{var fe;return!!((fe=s.value)!=null&&fe.normalizeHeadingSizes)}),_=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showUnorderedListMarkers)===!1}),T=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showOrderedListMarkers)===!1}),k=ye(()=>La(d.value.width,d.value.height,y.value.baseWidth,y.value.baseHeight,14)),C=ye(()=>La(b.value.width,b.value.height,y.value.baseWidth,y.value.baseHeight,14));function D(){f.value&&(d.value={width:f.value.clientWidth,height:f.value.clientHeight}),p.value&&(b.value={width:p.value.clientWidth,height:p.value.clientHeight})}let P=null;function R(){typeof window>"u"||typeof window.ResizeObserver!="function"||(P||(P=new window.ResizeObserver(()=>{D()})),P.disconnect(),f.value&&P.observe(f.value),p.value&&P.observe(p.value))}Ho([f,p,u],()=>{On(()=>{R(),D()})},{flush:"post"});const j=pe(0),B=pe(!0);let N=null,S=Date.now(),Z=0;const W=ye(()=>{const fe=String(Math.floor(j.value/60)).padStart(2,"0"),he=String(j.value%60).padStart(2,"0");return`${fe}:${he}`});function $(){if(B.value){const fe=Z+(Date.now()-S);j.value=Math.floor(fe/1e3)}}function M(){B.value?(Z+=Date.now()-S,B.value=!1):(S=Date.now(),B.value=!0,$())}function E(){S=Date.now(),Z=0,j.value=0}const Q=pe("");let F=null;function V(){const fe=new Date,he=String(fe.getHours()).padStart(2,"0"),Qe=String(fe.getMinutes()).padStart(2,"0");Q.value=`${he}:${Qe}`}const re=ye(()=>n.value.length===0?null:n.value[a.value-1]||null),oe=ye(()=>a.value>=n.value.length?null:n.value[a.value]||null);function ae(fe){var $t;const he=fe==null?void 0:fe.frontmatter;if((he==null?void 0:he.colorSchema)==="light")return"light";if((he==null?void 0:he.colorSchema)==="dark")return"dark";if(typeof(he==null?void 0:he.class)=="string"){const lt=he.class.split(/\s+/);if(lt.includes("light"))return"light";if(lt.includes("dark"))return"dark"}const Qe=(he==null?void 0:he.background)||(($t=s.value)==null?void 0:$t.background),at=nc(Qe);return at===!0?"light":at===!1?"dark":v.value}const Se=ye(()=>ae(re.value)),$e=ye(()=>ae(oe.value)),ke=ye(()=>re.value?Xg(re.value):c.value),Ce=ye(()=>a.value>1||r.value>0),z=ye(()=>a.value<u.value||r.value<ke.value),ne=ye(()=>Da(re.value,{config:s.value,allSlides:n.value,pageIndex:a.value,currentStep:r.value})),L=ye(()=>Da(oe.value,{config:s.value,allSlides:n.value,pageIndex:a.value+1})),U=ye(()=>{var he;if(!re.value)return"无内容";const fe=(he=re.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${a.value} 页`});function w(fe){return(fe||[]).slice(1).map(he=>(he.content||he.rawMarkdown||"").trim()).filter(he=>he&&!/^(image\s+)?assets\/\S*$/i.test(he)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(he)).join(" | ").slice(0,120)}const q=ye(()=>{var fe;return w((fe=re.value)==null?void 0:fe.blocks)}),H=ye(()=>{var he;if(!oe.value)return"演示结束";const fe=(he=oe.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${a.value+1} 页`}),I=ye(()=>oe.value?w(oe.value.blocks):"这是最后一页"),A=ye(()=>{var fe;return((fe=re.value)==null?void 0:fe.notes)||""}),O=pe(20);function G(){O.value<36&&(O.value+=2)}function K(){O.value>14&&(O.value-=2)}const Y=ye(()=>u.value<=1?100:Math.round(a.value/u.value*100));let ee=null;try{ee=new BroadcastChannel("siyuan-slides-sync"),ee.onmessage=fe=>{const he=fe.data;if(he&&(he.type==="SYNC_PAGE"&&typeof he.page=="number"&&(a.value=he.page,r.value=typeof he.step=="number"?Math.max(0,he.step):0,typeof he.maxStep=="number"&&(c.value=Math.max(0,he.maxStep))),he.type==="SYNC_SLIDES"&&Array.isArray(he.slides)&&(n.value=he.slides,he.config&&typeof he.config=="object"&&(s.value=he.config)),he.type==="REQUEST_SYNC"&&n.value.length>0))try{ee==null||ee.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),ee==null||ee.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:ke.value})}catch{}}}catch{ee=null}function ce(fe,he=0){const Qe=Number(fe)||1,at=Math.max(0,Number(he)||0);i.navigatePage(Qe,at);try{ee==null||ee.postMessage({type:"SYNC_PAGE",page:Qe,step:at,maxStep:ke.value})}catch{}}function se(){if(r.value<ke.value){r.value++,ce(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,ce(a.value,0))}function me(){if(r.value>0){r.value--,ce(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,ce(a.value,0))}function _e(){a.value<u.value&&(a.value++,r.value=0,ce(a.value,0))}function we(){a.value>1&&(a.value--,r.value=0,ce(a.value,0))}function De(){a.value=1,r.value=0,E(),ce(1,0)}function He(){const fe=o;typeof(fe==null?void 0:fe.openBottomPreviewTab)=="function"&&fe.openBottomPreviewTab()}function Ge(){const fe=o;typeof(fe==null?void 0:fe.openStandalonePreviewWindow)=="function"&&fe.openStandalonePreviewWindow()}function rt(fe){var he,Qe;if(!(fe.key===" "&&((Qe=(he=fe.target)==null?void 0:he.closest)!=null&&Qe.call(he,"button")))){if(fe.shiftKey&&fe.key==="ArrowRight"||fe.key==="ArrowDown"){fe.preventDefault(),_e();return}if(fe.shiftKey&&fe.key==="ArrowLeft"||fe.key==="ArrowUp"){fe.preventDefault(),we();return}fe.key==="ArrowRight"||fe.key===" "||fe.key==="PageDown"?(fe.preventDefault(),se()):(fe.key==="ArrowLeft"||fe.key==="PageUp")&&(fe.preventDefault(),me())}}let Pe=0;function ft(fe){var at,$t;if(Math.abs(fe.deltaY)<nb)return;const he=($t=(at=fe.target)==null?void 0:at.closest)==null?void 0:$t.call(at,".notes-content");if(he){const lt=he.scrollHeight-he.clientHeight;if(lt>2&&(fe.deltaY>0&&he.scrollTop<lt-1||fe.deltaY<0&&he.scrollTop>1))return}const Qe=Date.now();Qe-Pe<ib||(Pe=Qe,fe.deltaY>0?se():me())}let tt=null,Ye=null;return ti(()=>{var he;m.value=Uo(),Ye=sc(Qe=>{m.value=Qe}),S=Date.now(),Z=0,N=window.setInterval($,500),typeof document<"u"&&document.addEventListener("visibilitychange",$),V(),F=window.setInterval(V,1e3),tt=i.onSlideChanged((Qe,at,$t,lt,co)=>{a.value=Qe,at>0&&(l.value=at),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof co=="number"&&(c.value=Math.max(0,co))});try{ee==null||ee.postMessage({type:"REQUEST_SYNC"})}catch{}const fe=o==null?void 0:o.latestCompiledDoc;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides,fe.config&&(s.value=fe.config)),typeof window<"u"&&window.addEventListener("resize",D),On(()=>{R(),D()})}),sn(()=>{Ye&&(Ye(),Ye=null),N&&(window.clearInterval(N),N=null),typeof document<"u"&&document.removeEventListener("visibilitychange",$),F&&(window.clearInterval(F),F=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",D),P&&(P.disconnect(),P=null);try{ee==null||ee.close()}catch{}ee=null}),t({updateDocument(fe){var he;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides),fe!=null&&fe.config&&(s.value=fe.config)}}),(fe,he)=>{var Qe,at,$t;return J(),X("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:ft},[h("header",ty,[h("div",oy,[h("div",iy,[le(de,{name:"presenter",class:"brand-icon"}),he[1]||(he[1]=h("span",{class:"title-name"},"演讲者控制台",-1))]),h("div",ny,[h("span",sy,"P."+ve(a.value)+" / "+ve(u.value||1),1),ke.value>0?(J(),X("span",ry,[le(de,{name:"step",class:"pill-icon"}),St(" 步进 "+ve(r.value)+" / "+ve(ke.value),1)])):Ae("",!0)])]),h("div",ay,[h("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ge},[le(de,{name:"window"}),he[2]||(he[2]=h("span",{class:"btn-tool-label"},"独立放映",-1))]),h("div",ly,[le(de,{name:"clock",class:"timer-icon"}),h("span",cy,ve(W.value),1),h("div",dy,[h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":B.value?"暂停计时":"继续计时",onClick:M},[le(de,{name:B.value?"pause":"play"},null,8,["name"])],8,uy),h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:E},[le(de,{name:"reset"})])])]),h("div",fy,[h("span",null,ve(Q.value),1)])])]),u.value>0?(J(),X("main",hy,[h("section",py,[h("div",my,[h("div",gy,[h("div",yy,[he[3]||(he[3]=h("span",{class:"panel-tag is-current"},"当前放映",-1)),h("span",by,"P."+ve(a.value),1)]),h("div",vy,[ke.value>0?(J(),X("span",ky," 步进 "+ve(r.value)+" / "+ve(ke.value),1)):Ae("",!0),h("span",wy,ve(((at=(Qe=re.value)==null?void 0:Qe.frontmatter)==null?void 0:at.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":U.value},[re.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:io({width:k.value.boxWidth+"px",height:k.value.boxHeight+"px"})},[h("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+g.value]),"data-theme":Se.value,"data-slides-theme":g.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":_.value?"true":"false","data-hide-ordered-markers":T.value?"true":"false",style:io({width:y.value.baseWidth+"px",height:y.value.baseHeight+"px",transform:"scale("+k.value.scale+")"}),innerHTML:ne.value},null,14,Sy)],4)):(J(),X("div",Cy,[h("h2",null,ve(U.value),1),h("p",null,ve(q.value),1)]))],8,xy)]),h("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:he[0]||(he[0]=lt=>oe.value&&_e())},[h("div",Iy,[h("div",$y,[he[4]||(he[4]=h("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(J(),X("span",Ty,"P."+ve(a.value+1),1)):Ae("",!0)]),h("div",Ay,[a.value>=u.value?(J(),X("span",My,"已到尾页")):oe.value?(J(),X("span",Ey,ve((($t=oe.value.frontmatter)==null?void 0:$t.layout)||"default"),1)):Ae("",!0)])]),h("div",{ref_key:"nextPreviewRef",ref:p,class:"panel-preview panel-preview--dim","aria-label":H.value},[oe.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:io({width:C.value.boxWidth+"px",height:C.value.boxHeight+"px"})},[h("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+g.value]),"data-theme":$e.value,"data-slides-theme":g.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":_.value?"true":"false","data-hide-ordered-markers":T.value?"true":"false",style:io({width:y.value.baseWidth+"px",height:y.value.baseHeight+"px",transform:"scale("+C.value.scale+")"}),innerHTML:L.value},null,14,Ly)],4)):(J(),X("div",Dy,[h("h2",null,ve(H.value),1),h("p",null,ve(I.value),1)]))],8,By)],10,_y)]),h("section",Ny,[h("div",Oy,[h("div",Py,[le(de,{name:"notes",class:"panel-title-icon"}),he[5]||(he[5]=h("span",null,"讲稿备忘",-1))]),h("div",Ry,[h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:O.value<=14,onClick:K},[le(de,{name:"minus"})],8,zy),h("span",Hy,ve(O.value)+"px",1),h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:O.value>=36,onClick:G},[le(de,{name:"plus"})],8,Fy)])]),h("div",{class:xe(["notes-content",{"is-empty":!A.value}]),style:io({fontSize:O.value+"px"})},ve(A.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),X("main",jy,[h("div",Uy,[le(de,{name:"refresh",class:"empty-icon"})]),he[8]||(he[8]=h("h2",null,"等待大屏放映数据",-1)),he[9]||(he[9]=h("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),h("div",Wy,[h("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[le(de,{name:"presenter"}),he[6]||(he[6]=h("span",null,"打开大屏放映页签",-1))]),h("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ge},[le(de,{name:"window"}),he[7]||(he[7]=h("span",null,"弹出独立放映窗口",-1))])])])),h("footer",qy,[h("div",Vy,[h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[le(de,{name:"chevrons-left"}),he[10]||(he[10]=h("span",null,"上一页",-1))],8,Ky),h("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Ce.value,"aria-label":"回退一步 (←)",onClick:me},[le(de,{name:"chevron-left"}),he[11]||(he[11]=h("span",null,"上一步",-1))],8,Gy)]),h("div",Yy,[h("div",Zy,[h("span",Jy,ve(Y.value)+"%",1)]),h("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:De},[le(de,{name:"reset"}),he[12]||(he[12]=h("span",null,"重头放映",-1))])]),h("div",Xy,[ke.value>0?(J(),X("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ke.value}`},[(J(!0),X(Ve,null,_t(ke.value,lt=>(J(),X("span",{key:lt,class:xe(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),h("span",eb,ve(r.value)+"/"+ve(ke.value),1)],8,Qy)):Ae("",!0),h("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!z.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:se},[he[13]||(he[13]=h("span",null,"下一步",-1)),le(de,{name:"chevron-right"})],8,tb),h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:_e},[he[14]||(he[14]=h("span",null,"下一页",-1)),le(de,{name:"chevrons-right"})],8,ob)])])],32)}}}),rb=lo(sb,[["__scopeId","data-v-f44df852"]]),ab={class:"spm-layout-picker"},lb={class:"spm-layout-group__title"},cb={class:"spm-layout-picker__grid"},db=["title","onClick"],ub={class:"spm-layout-icon"},fb={class:"spm-layout-label"},hb=Ht({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{id:"columns",title:"内容分栏",items:[{name:"default",label:"标准",desc:"标题在上，内容自适应流式排版"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示，支持比例调节"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"timeline",label:"时间线",desc:"步骤流程、里程碑演进或时间轴"}]},{id:"visuals",title:"图文排版",items:[{name:"image-right",label:"图右",desc:"左侧文字内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧文字内容"}]},{id:"focus",title:"聚焦与强调",items:[{name:"cover",label:"封面",desc:"全屏居中大标题与副标题封面页"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示 (KPI看板)"},{name:"quote",label:"引言",desc:"名人名言、金句与右对齐出处"},{name:"intro",label:"介绍",desc:"演讲者头像与个人履历名片"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"}]}];function s(r){return o.modelValue===r||r==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")||r==="timeline"&&o.modelValue==="steps"}function a(r){i("update:modelValue",r),i("change",r)}return(r,l)=>(J(),X("div",ab,[l[0]||(l[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),(J(),X(Ve,null,_t(n,c=>h("div",{key:c.id,class:"spm-layout-group"},[h("div",lb,[h("span",null,ve(c.title),1)]),h("div",cb,[(J(!0),X(Ve,null,_t(c.items,u=>(J(),X("div",{key:u.name,class:xe(["spm-layout-item",{active:s(u.name)}]),title:`${u.label}：${u.desc}`,onClick:f=>a(u.name)},[h("div",ub,[le(de,{name:"layout-"+u.name},null,8,["name"])]),h("span",fb,ve(u.label),1)],10,db))),128))])])),64))]))}}),pb=lo(hb,[["__scopeId","data-v-35f2913e"]]),mb={key:0,class:"spm-transition-selector__header"},gb={class:"spm-transition-list"},yb=["onClick"],bb={class:"spm-transition-meta"},vb={class:"spm-transition-label"},kb={class:"spm-transition-preview-box"},wb=Ht({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,a)=>(J(),X("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Ae("",!0):(J(),X("div",mb,ve(e.title||"转场动效"),1)),h("div",gb,[(J(),X(Ve,null,_t(i,r=>h("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>n(r.name)},[h("div",bb,[h("span",vb,ve(r.label),1)]),h("div",kb,[h("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,yb)),64))])],2))}}),xc=lo(wb,[["__scopeId","data-v-b5051f69"]]),xb={class:"spm-section spm-section--page"},Sb={class:"spm-section-header"},Cb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},_b={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Ib={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},$b={key:1,class:"spm-card-control"},Tb={class:"spm-control-header"},Ab={class:"spm-control-title-group"},Mb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设置各列横向空间占比，默认平均分配"},Eb={class:"spm-quick-chips"},Bb=["onClick"],Lb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Db=["value"],Nb=["aria-label"],Ob={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Pb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Rb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},zb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Hb={class:"spm-card-control"},Fb={class:"spm-control-header"},jb={class:"spm-control-title-group"},Ub={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"覆盖本页内衬、内容间隙与正文行距"},Wb={class:"spm-segmented-group"},qb={class:"spm-card-control"},Vb={class:"spm-control-header"},Kb={class:"spm-control-title-group"},Gb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"随着点击操作分段展露正文内容"},Yb={class:"spm-segmented-group"},Zb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Jb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Xb=["aria-label"],Qb={class:"spm-quick-chips"},ev=["onClick"],tv=["value"],ov={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},iv={style:{display:"flex",gap:"8px","margin-top":"2px"}},nv={style:{flex:"1"}},sv={class:"spm-segmented-group"},rv={style:{flex:"1"}},av={class:"spm-segmented-group"},lv={key:2,class:"spm-card-control"},cv={class:"spm-control-header"},dv={class:"spm-control-title-group"},uv=["aria-label"],fv={class:"spm-quick-chips"},hv=["onClick"],pv=["value","placeholder"],mv={class:"spm-card-control"},gv={class:"spm-control-header"},yv={class:"spm-control-title-group"},bv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"正文备注块驱动 · 仅演讲者视图可见"},vv={key:0,class:"spm-notes-header-actions"},kv=["disabled"],wv={key:0,class:"spm-btn-spinner"},xv={key:0,class:"spm-note-loading-box"},Sv={key:1,class:"spm-note-status-box"},Cv=["title"],_v={class:"spm-action-grid",style:{"margin-top":"6px"}},Iv={key:2,class:"spm-note-empty-box"},$v={class:"spm-card-control"},Tv={class:"spm-action-grid"},Av=["disabled","aria-label"],Mv=Ht({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean},isGeneratingNotes:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","openSetting","insertDividerAfter","deleteDivider","convertToSuperBlock"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>{const v=o.pageMask;return v==="clockwise"||v==="counter-clockwise"||v==="cw"||v==="ccw"}),a=ye(()=>s.value?"1:1:1:1":"1:1"),r=ye(()=>o.pageMaskRatio||a.value);function l(v){i("update:pageMask",v),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(v){i("update:pageMask",v),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ye(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),p=ye(()=>{var _,T;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const v=(o.pageLayoutRatio||"").trim();if(v.includes(":")){const k=v.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const x=(o.detectedSbRatio||"").trim();if(x.includes(":")){const k=x.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((_=o.detectedSbInfo)!=null&&_.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((T=o.detectedSbInfo)!=null&&T.slots&&Array.isArray(o.detectedSbInfo.slots)){const k=o.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),d=ye(()=>{const v=p.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ye(()=>o.pageLayoutRatio||"");function m(){const v=p.value||2,x=Array(v).fill("1").join(":");i("update:pageLayoutRatio",x),i("resetSuperblockRatio")}const y=ye(()=>{if(!o.pageNotes)return"";const v=o.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),g=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(v,x)=>(J(),X("div",xb,[h("div",Sb,[h("span",null,"幻灯片页面设置"+ve(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(pb,{"model-value":e.pageLayout,onChange:x[0]||(x[0]=_=>v.$emit("update:pageLayout",_))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),X("div",Cb,[h("div",_b,[h("div",Ib,[le(de,{name:"sparkles"}),h("span",null,[x[31]||(x[31]=St("检测到本页横向超级块列宽比例：",-1)),h("b",null,ve(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:x[1]||(x[1]=_=>v.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(de,{name:"columns"}),x[32]||(x[32]=h("span",null,"设为分栏",-1))])])])):Ae("",!0),f.value?(J(),X("div",$b,[h("div",Tb,[h("div",Ab,[h("div",Mb,[le(de,{name:"ratio"}),x[33]||(x[33]=h("span",null,"分栏比例",-1))])])]),h("div",Eb,[(J(!0),X(Ve,null,_t(d.value,_=>(J(),X("button",{key:_.value,class:xe(["spm-chip",{active:b.value===_.value}]),onClick:T=>v.$emit("update:pageLayoutRatio",_.value)},ve(_.label),11,Bb))),128))]),h("div",Lb,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:x[2]||(x[2]=_=>v.$emit("update:pageLayoutRatio",_.target.value)),onChange:x[3]||(x[3]=_=>v.$emit("update:pageLayoutRatio",_.target.value))},null,40,Db),e.detectedSbRatio?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:x[4]||(x[4]=_=>v.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(de,{name:"sparkles"}),x[34]||(x[34]=h("span",null,"读取",-1))],8,Nb)):(J(),X("button",Ob,[le(de,{name:"sparkles"}),x[35]||(x[35]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[le(de,{name:"reset"}),x[36]||(x[36]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),X("div",Pb,[le(de,{name:"ratio"}),x[37]||(x[37]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Rb,ve(e.detectedSbRatio),1)])):(J(),X("div",zb,[le(de,{name:"ratio"}),x[38]||(x[38]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ae("",!0),h("div",Hb,[h("div",Fb,[h("div",jb,[h("div",Ub,[le(de,{name:"ratio"}),x[39]||(x[39]=h("span",null,"页面间距",-1))])])]),h("div",Wb,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:x[5]||(x[5]=_=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:x[6]||(x[6]=_=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:x[7]||(x[7]=_=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:x[8]||(x[8]=_=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),le(xc,{"model-value":e.pageTransition,onChange:x[9]||(x[9]=_=>v.$emit("update:pageTransition",_))},null,8,["model-value"]),h("div",qb,[h("div",Vb,[h("div",Kb,[h("div",Gb,[le(de,{name:"sparkles"}),x[40]||(x[40]=h("span",null,"页面动态蒙版",-1))])])]),h("div",Yb,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:x[10]||(x[10]=_=>v.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:x[11]||(x[11]=_=>c("down"))}," 从上至下 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:x[12]||(x[12]=_=>c("right"))}," 从左至右 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:x[13]||(x[13]=_=>l("clockwise"))}," 顺时针 ↻ ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:x[14]||(x[14]=_=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),X("div",Zb,[h("div",Jb,[x[42]||(x[42]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[le(de,{name:"help"}),x[41]||(x[41]=h("span",null,"输入规则",-1))],8,Xb)]),h("div",Qb,[(J(),X(Ve,null,_t(n,_=>h("button",{key:_.value,class:xe(["spm-chip",{active:r.value===_.value}]),onClick:T=>v.$emit("update:pageMaskRatio",_.value)},ve(_.label),11,ev)),64))]),h("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:x[15]||(x[15]=_=>v.$emit("update:pageMaskRatio",_.target.value)),onChange:x[16]||(x[16]=_=>v.$emit("update:pageMaskRatio",_.target.value))},null,40,tv),h("div",ov,ve(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),h("div",iv,[h("div",nv,[x[43]||(x[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",sv,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:x[17]||(x[17]=_=>v.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:x[18]||(x[18]=_=>v.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",rv,[x[44]||(x[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",av,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:x[19]||(x[19]=_=>v.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:x[20]||(x[20]=_=>v.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Ae("",!0)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageLayout==="intro"||e.pageImage?(J(),X("div",lv,[h("div",cv,[h("div",dv,[h("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":e.pageLayout==="intro"?"演讲者个人头像或形象照 URL / 资源路径":"图文分栏或页面专属配图 URL / 资源路径"},[le(de,{name:"image"}),h("span",null,ve(e.pageLayout==="intro"?"头像与配图":"页面图片"),1)],8,uv)])]),h("div",fv,[(J(),X(Ve,null,_t(g,_=>h("button",{key:_.value,class:xe(["spm-chip",{active:e.pageImage===_.value}]),onClick:T=>v.$emit("update:pageImage",_.value)},ve(_.label),11,hv)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:e.pageLayout==="intro"?"头像图片 URL 或思源本地图片路径 (如 assets/...)":"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:x[21]||(x[21]=_=>v.$emit("update:pageImage",_.target.value)),onChange:x[22]||(x[22]=_=>v.$emit("update:pageImage",_.target.value))},null,40,pv)])):Ae("",!0),h("div",mv,[h("div",gv,[h("div",yv,[h("div",bv,[le(de,{name:"presenter"}),x[45]||(x[45]=h("span",null,"演讲者提词",-1))])]),ue(Ot)("aiScript")?(J(),X("div",vv,[h("button",{type:"button",class:xe(["spm-btn-primary b3-tooltips b3-tooltips__s",{"is-loading":e.isGeneratingNotes}]),disabled:e.isGeneratingNotes,"aria-label":"AI 自动生成本页讲稿提示块",onClick:x[23]||(x[23]=_=>v.$emit("generateNotes"))},[e.isGeneratingNotes?(J(),X("span",wv)):(J(),Vt(de,{key:1,name:"sparkles"})),h("span",null,ve(e.isGeneratingNotes?"提炼中...":"AI 讲稿"),1)],10,kv),h("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开 AI 讲稿服务配置",onClick:x[24]||(x[24]=_=>v.$emit("openSetting"))},[le(de,{name:"settings"})])])):Ae("",!0)]),e.isGeneratingNotes?(J(),X("div",xv,[...x[46]||(x[46]=[h("div",{class:"spm-loading-spinner"},null,-1),h("div",{class:"spm-loading-text"},[h("span",{class:"spm-loading-title"},"AI 正在提炼本页演讲提词..."),h("span",{class:"spm-loading-desc"},"根据幻灯片上下文智能编写口播要点，请稍候")],-1)])])):e.pageNotes?(J(),X("div",Sv,[x[49]||(x[49]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},ve(y.value),9,Cv),h("div",_v,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:x[25]||(x[25]=_=>v.$emit("locateNoteBlock"))},[le(de,{name:"search"}),x[47]||(x[47]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:x[26]||(x[26]=_=>v.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[48]||(x[48]=h("span",null,"追加讲稿块",-1))])])])):(J(),X("div",Iv,[x[51]||(x[51]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:x[27]||(x[27]=_=>v.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[50]||(x[50]=h("span",null,"添加讲稿备注块",-1))])]))]),h("div",$v,[x[55]||(x[55]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",Tv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:x[28]||(x[28]=_=>v.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),x[52]||(x[52]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:x[29]||(x[29]=_=>v.$emit("deleteDivider"))},[le(de,{name:"trash"}),x[53]||(x[53]=h("span",null,"删除此页",-1))]),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:x[30]||(x[30]=_=>v.$emit("convertToSuperBlock"))},[le(de,{name:"columns"}),x[54]||(x[54]=h("span",null,"转为超级块",-1))],10,Av)])])]))}}),Ev=lo(Mv,[["__scopeId","data-v-d619d441"]]),Bv={class:"spm-section spm-section--block"},Lv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Dv={class:"spm-control-header"},Nv={class:"spm-control-title-group"},Ov={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"读取思源超级块列宽并一键同步到幻灯片分栏"},Pv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Rv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},zv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Hv={key:0},Fv={key:1},jv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Uv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Wv={class:"spm-action-grid"},qv={key:1,class:"spm-card-control"},Vv={class:"spm-control-header"},Kv={class:"spm-control-title-group"},Gv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设为幻灯片背景图或图文分栏配图"},Yv={class:"spm-quick-chips"},Zv={key:2,class:"spm-card-control"},Jv={class:"spm-control-header"},Xv={class:"spm-control-title-group"},Qv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"配置播放器控制条、自动播放与循环"},e1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},t1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},o1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},i1=["aria-label"],n1=["checked"],s1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},r1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},a1=["aria-label"],l1=["checked"],c1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},d1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},u1=["aria-label"],f1=["checked"],h1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},p1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},m1=["aria-label"],g1=["checked"],y1={class:"spm-card-control"},b1={class:"spm-control-header"},v1={class:"spm-control-title-group"},k1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"放映时按步长逐个呈现"},w1=["aria-label"],x1=["checked"],S1={key:0,class:"spm-quick-chips"},C1=["onClick"],_1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},I1={class:"spm-card-control"},$1={class:"spm-control-header"},T1={class:"spm-control-title-group"},A1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"为当前块添加平滑位移与渐入动画"},M1=["aria-label"],E1=["checked"],B1={key:0,class:"spm-quick-chips"},L1=["onClick"],D1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},N1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},O1={style:{display:"flex",gap:"6px"}},P1=["value"],R1=["value"],z1={key:3,class:"spm-card-control"},H1={class:"spm-control-header"},F1={class:"spm-control-title-group"},j1=["aria-label"],U1={class:"spm-segmented-group"},W1=["onClick"],q1={key:4,class:"spm-card-control"},V1={class:"spm-control-header"},K1={class:"spm-control-title-group"},G1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"翻页时动态聚光高亮特定行"},Y1={class:"spm-quick-chips"},Z1=["onClick"],J1=["value"],X1={key:5,class:"spm-card-control"},Q1={class:"spm-control-header"},e0={class:"spm-control-title-group"},t0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"超出限高自动竖向滚动，弱提示滚动条"},o0={class:"spm-quick-chips"},i0=["onClick"],n0=["value"],s0={class:"spm-card-control"},r0={class:"spm-action-grid"},a0=["aria-label"],l0=["disabled","aria-label"],c0=["disabled","aria-label"],d0=Ht({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","convertToSuperBlock","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ye(()=>{const k=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":k}),n=ye(()=>{const k=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(k)}),s=ye(()=>{var C,D,P,R;if((C=o.detectedSbInfo)!=null&&C.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const k=(D=o.elemSlot)==null?void 0:D.match(/^col-(\d+)$/);if(k){const j=parseInt(k[1],10);if(j>=2&&j<=6)return Math.max(j,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((R=(P=o.detectedSbInfo)==null?void 0:P.ratio)!=null&&R.includes(":")){const j=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(j.length>=2)return Math.min(j.length,6)}return 3}),a=ye(()=>{const k=i.value;return k==="cols-header"?"多栏插槽归属":k==="three-cols-header"?"三栏插槽归属":k==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const k=i.value;return k==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:k==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":k==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":k==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const k=i.value;if(k==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(k==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(k==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=s.value,D=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let P=1;P<=C;P++)D.push({value:`col-${P}`,label:`第 ${P} 栏`});return D});function c(k){const C=o.elemSlot||"";return k?C===k||k==="col-1"&&C==="left"||k==="col-2"&&C==="center"||k==="col-3"&&C==="right"&&s.value===3||k==="col-2"&&C==="right"&&s.value===2||k==="left"&&C==="col-1"||k==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],p=ye(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const k=JSON.parse(o.elemMotion);if(typeof k=="object"&&k!==null)return{preset:k.preset||k.type||"slide-up",duration:typeof k.duration=="number"?k.duration:0,delay:typeof k.delay=="number"?k.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!p.value),b=ye(()=>{var k;return((k=p.value)==null?void 0:k.preset)||"slide-up"}),m=ye(()=>{var k;return((k=p.value)==null?void 0:k.duration)||0}),y=ye(()=>{var k;return((k=p.value)==null?void 0:k.delay)||0});function g(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function v(k){T(k,m.value,y.value)}function x(k){T(b.value,k,y.value)}function _(k){T(b.value,m.value,k)}function T(k,C,D){if(!k||k==="none"){u("update:elemMotion","");return}if(!C&&!D){u("update:elemMotion",k);return}const P={preset:k};C>0&&(P.duration=C),D>0&&(P.delay=D),u("update:elemMotion",JSON.stringify(P))}return(k,C)=>{var D,P,R,j,B,N;return J(),X("div",Bv,[C[53]||(C[53]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(D=e.detectedSbInfo)!=null&&D.hasSuperBlock?(J(),X("div",Lv,[h("div",Dv,[h("div",Nv,[h("div",Ov,[le(de,{name:"ratio"}),C[24]||(C[24]=h("span",null,"超级块列宽与布局",-1))])])]),h("div",Pv,[h("div",Rv,[h("div",zv,[le(de,{name:"ratio"}),(P=e.detectedSbInfo)!=null&&P.isCustomWidth?(J(),X("span",Hv,"已识别自定义列宽比例")):(J(),X("span",Fv,"识别到 "+ve(((R=e.detectedSbInfo)==null?void 0:R.colCount)||2)+" 列超级块分栏",1))]),h("code",jv,ve(((j=e.detectedSbInfo)==null?void 0:j.ratio)||"1:1"),1)]),h("div",Uv,ve((B=e.detectedSbInfo)!=null&&B.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",Wv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=S=>k.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(de,{name:"sparkles"}),C[25]||(C[25]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=S=>{var Z;return k.$emit("applySuperBlockRatio",((Z=e.detectedSbInfo)==null?void 0:Z.ratio)||"1:1")})},[le(de,{name:"check"}),h("span",null,"应用比例 ("+ve(((N=e.detectedSbInfo)==null?void 0:N.ratio)||"1:1")+")",1)])])])):Ae("",!0),e.isImage||e.imageRole?(J(),X("div",qv,[h("div",Vv,[h("div",Kv,[h("div",Gv,[le(de,{name:"image"}),C[26]||(C[26]=h("span",null,"图片角色与分栏",-1))])])]),h("div",Yv,[h("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:C[2]||(C[2]=S=>k.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[3]||(C[3]=S=>k.$emit("update:imageRole","background"))},[le(de,{name:"image"}),C[27]||(C[27]=h("span",null,"背景图",-1))],2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[4]||(C[4]=S=>k.$emit("update:imageRole","image-left"))},[le(de,{name:"image-left"}),C[28]||(C[28]=h("span",null,"图左",-1))],2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[5]||(C[5]=S=>k.$emit("update:imageRole","image-right"))},[le(de,{name:"image-right"}),C[29]||(C[29]=h("span",null,"图右",-1))],2)])])):Ae("",!0),e.isVideo?(J(),X("div",Zv,[h("div",Jv,[h("div",Xv,[h("div",Qv,[le(de,{name:"video"}),C[30]||(C[30]=h("span",null,"视频播放设置",-1))])])]),h("div",e1,[h("div",t1,[h("span",o1,[le(de,{name:"sliders"}),C[31]||(C[31]=St(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[6]||(C[6]=S=>k.$emit("toggleVideoControls"))},null,40,n1),C[32]||(C[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,i1)]),h("div",s1,[h("span",r1,[le(de,{name:"video"}),C[33]||(C[33]=St(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[7]||(C[7]=S=>k.$emit("toggleVideoAutoplay"))},null,40,l1),C[34]||(C[34]=h("span",{class:"spm-switch-slider"},null,-1))],8,a1)]),h("div",c1,[h("span",d1,[le(de,{name:"repeat"}),C[35]||(C[35]=St(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[8]||(C[8]=S=>k.$emit("toggleVideoLoop"))},null,40,f1),C[36]||(C[36]=h("span",{class:"spm-switch-slider"},null,-1))],8,u1)]),h("div",h1,[h("span",p1,[le(de,{name:"volume-x"}),C[37]||(C[37]=St(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[9]||(C[9]=S=>k.$emit("toggleVideoMuted"))},null,40,g1),C[38]||(C[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,m1)])])])):Ae("",!0),h("div",y1,[h("div",b1,[h("div",v1,[h("div",k1,[le(de,{name:"step"}),C[39]||(C[39]=h("span",null,"逐步呈现",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[10]||(C[10]=S=>k.$emit("toggleElemClick"))},null,40,x1),C[40]||(C[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,w1)]),e.elemClick?(J(),X("div",S1,[(J(),X(Ve,null,_t(["+1","1","2","hide"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemClick===S}]),onClick:Z=>k.$emit("update:elemClick",S)},ve(S==="+1"?"顺延 (+1)":S==="hide"?"隐藏":"第 "+S+" 步"),11,C1)),64))])):e.parentElemClick?(J(),X("div",_1,[le(de,{name:"check"}),C[41]||(C[41]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ae("",!0)]),h("div",I1,[h("div",$1,[h("div",T1,[h("div",A1,[le(de,{name:"motion"}),C[42]||(C[42]=h("span",null,"入场微动效",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[h("input",{type:"checkbox",checked:d.value,onChange:g},null,40,E1),C[43]||(C[43]=h("span",{class:"spm-switch-slider"},null,-1))],8,M1)]),d.value?(J(),X("div",B1,[(J(),X(Ve,null,_t(f,S=>h("button",{key:S.value,class:xe(["spm-chip",{active:b.value===S.value}]),onClick:Z=>v(S.value)},ve(S.label),11,L1)),64))])):Ae("",!0),d.value?(J(),X("div",D1,[h("div",N1,[h("span",null,"时长: "+ve(m.value?m.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+ve(y.value?y.value+"ms":"0ms"),1)]),h("div",O1,[h("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[11]||(C[11]=S=>x(Number(S.target.value)))},[...C[44]||(C[44]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,P1),h("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:C[12]||(C[12]=S=>_(Number(S.target.value)))},[...C[45]||(C[45]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,R1)])])):Ae("",!0)]),n.value||e.elemSlot?(J(),X("div",z1,[h("div",H1,[h("div",F1,[h("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":r.value},[le(de,{name:"columns"}),h("span",null,ve(a.value),1)],8,j1)])]),h("div",U1,[(J(!0),X(Ve,null,_t(l.value,S=>(J(),X("button",{key:S.value,class:xe(["spm-segmented-item",{active:c(S.value)}]),onClick:Z=>k.$emit("update:elemSlot",S.value)},ve(S.label),11,W1))),128))])])):Ae("",!0),e.isCodeBlock?(J(),X("div",q1,[h("div",V1,[h("div",K1,[h("div",G1,[le(de,{name:"code"}),C[46]||(C[46]=h("span",null,"代码逐行聚光",-1))])])]),h("div",Y1,[(J(),X(Ve,null,_t(["1-3","all","1|2|3","2-5"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemShikiLines===S}]),onClick:Z=>k.$emit("update:elemShikiLines",S)},ve(S),11,Z1)),64)),e.elemShikiLines?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[13]||(C[13]=S=>k.$emit("update:elemShikiLines",""))}," 清空 ")):Ae("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[14]||(C[14]=S=>k.$emit("update:elemShikiLines",S.target.value)),onChange:C[15]||(C[15]=S=>k.$emit("update:elemShikiLines",S.target.value))},null,40,J1)])):Ae("",!0),e.isCodeBlock?(J(),X("div",X1,[h("div",Q1,[h("div",e0,[h("div",t0,[le(de,{name:"code"}),C[47]||(C[47]=h("span",null,"代码块限高",-1))])])]),h("div",o0,[(J(),X(Ve,null,_t(["240px","320px","400px","50%"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemMaxHeight===S||S==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:Z=>k.$emit("update:elemMaxHeight",S)},ve(S),11,i0)),64)),e.elemMaxHeight?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[16]||(C[16]=S=>k.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ae("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:C[17]||(C[17]=S=>k.$emit("update:elemMaxHeight",S.target.value)),onChange:C[18]||(C[18]=S=>k.$emit("update:elemMaxHeight",S.target.value))},null,40,n0)])):Ae("",!0),h("div",s0,[C[52]||(C[52]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",r0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[19]||(C[19]=S=>k.$emit("insertDividerBefore"))},[le(de,{name:"insert-above"}),C[48]||(C[48]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=S=>k.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),C[49]||(C[49]=h("span",null,"下方分页",-1))]),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:C[21]||(C[21]=S=>k.$emit("toggleNote"))},[le(de,{name:"presenter"}),h("span",null,ve(e.isNote?"取消备注":"设为备注"),1)],10,a0),h("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:C[22]||(C[22]=S=>k.$emit("clearBlockAttrs"))},[le(de,{name:"broom"}),C[50]||(C[50]=h("span",null,"清除属性",-1))],10,l0),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:C[23]||(C[23]=S=>k.$emit("convertToSuperBlock"))},[le(de,{name:"columns"}),C[51]||(C[51]=h("span",null,"转为超级块",-1))],10,c0)])])])}}}),u0={class:"spm-section spm-section--doc"},f0={class:"spm-card-control"},h0={class:"spm-control-header"},p0={class:"spm-control-title-group"},m0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全局幻灯片视觉设计范式"},g0={class:"spm-theme-card-grid"},y0=["aria-label","onClick"],b0={key:0,class:"spm-bg-swatch-check"},v0={class:"spm-theme-card-label"},k0={class:"spm-card-control"},w0={class:"spm-control-header"},x0={class:"spm-control-title-group"},S0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全篇幻灯片统一底色、微渐变或壁纸"},C0={class:"spm-bg-swatch-grid"},_0=["aria-label","onClick"],I0={key:0,class:"spm-bg-swatch-check"},$0={class:"spm-bg-swatch-label"},T0={class:"spm-bg-input-row"},A0=["value"],M0={class:"spm-card-control"},E0={class:"spm-control-header"},B0={class:"spm-control-title-group"},L0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"演讲屏幕投影宽高比"},D0={class:"spm-segmented-group"},N0={class:"spm-card-control"},O0={class:"spm-control-header"},P0={class:"spm-control-title-group"},R0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"内衬、内容间隙与正文行距预设"},z0={class:"spm-segmented-group"},H0={class:"spm-card-control"},F0={class:"spm-control-header"},j0={class:"spm-control-title-group"},U0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"页面切换过渡动效（未单设转场的页面将继承此动效）"},W0={class:"spm-card-control"},q0={class:"spm-action-grid"},V0=["disabled"],K0=["disabled"],G0=["disabled"],Y0=["disabled"],Z0=["disabled"],J0=["aria-expanded"],X0={class:"spm-advanced-toggle-label"},Q0={key:0,class:"spm-advanced-content"},ek={class:"spm-card-control"},tk={class:"spm-control-header"},ok={class:"spm-control-title-group"},ik={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"点击文档/块链接以 Webview 抽屉呈现，支持外跳"},nk=["aria-label"],sk=["checked"],rk={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},ak=["value"],lk={class:"spm-card-control"},ck={class:"spm-control-header"},dk={class:"spm-control-title-group"},uk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示"},fk=["aria-label"],hk=["checked"],pk={class:"spm-card-control"},mk={class:"spm-control-header"},gk={class:"spm-control-title-group"},yk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"分别控制正文中无序列表圆点与有序列表数字序号的呈现"},bk={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},vk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},kk=["aria-label"],wk=["checked"],xk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},Sk=["aria-label"],Ck=["checked"],_k={class:"spm-card-control"},Ik={class:"spm-control-header"},$k={class:"spm-control-title-group"},Tk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"提炼演讲口播提词卡，支持 API 旋钮接管调度"},Ak={key:0,class:"api-switch-managed-tip",style:{"margin-top":"8px","background-color":"var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08))",border:"1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2))","border-radius":"6px",padding:"8px 10px","font-size":"11px","line-height":"1.4",color:"var(--b3-theme-on-background)"}},Mk={class:"spm-control-body",style:{"margin-top":"8px",display:"flex","flex-direction":"column",gap:"6px"}},Ek={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Bk=["value","disabled"],Lk={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Dk=["value","disabled"],Nk={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Ok=["value","disabled"],Pk=Ht({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf","openSetting"],setup(e,{emit:t}){const o=Gt("plugin"),i=Ft,n=is,s=pe(!1);function a(){_("openSetting")}async function r(T){const k=i.aiConfig,C=bi({...k,model:T});pt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}async function l(T){const k=i.aiConfig,C=bi({...k,baseUrl:T});pt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}async function c(T){const k=i.aiConfig,C=bi({...k,apiKey:T});pt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}function u(T){typeof window<"u"&&window.siyuanApiSwitch&&(o!=null&&o.name)&&window.siyuanApiSwitch.updateLocalConfig(o.name,{provider:"custom",baseUrl:T.baseUrl,apiKey:T.apiKey,model:T.model,requestTimeoutSeconds:T.requestTimeoutSeconds,temperature:T.temperature,maxTokens:T.maxTokens})}const f=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function p(T){pt({enableWebServeJump:T}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({enableWebServeJump:T})}async function d(T){var k;pt({normalizeHeadingSizes:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({normalizeHeadingSizes:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((k=o.getActiveDocumentId)==null?void 0:k.call(o)))}async function b(T){var k;pt({showUnorderedListMarkers:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showUnorderedListMarkers:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((k=o.getActiveDocumentId)==null?void 0:k.call(o)))}async function m(T){var k;pt({showOrderedListMarkers:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showOrderedListMarkers:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((k=o.getActiveDocumentId)==null?void 0:k.call(o)))}function y(T){pt({webServeUrl:T})}function g(T){pt({webServeUrl:T}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({webServeUrl:T})}const v=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function x(T){const k=(T||"").trim();return k?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(k)?{backgroundImage:`url("${k.startsWith("assets/")?`/${k}`:k.startsWith("./assets/")?k.slice(1):k}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:k}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}const _=t;return(T,k)=>(J(),X("div",u0,[k[65]||(k[65]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",f0,[h("div",h0,[h("div",p0,[h("div",m0,[le(de,{name:"palette"}),k[32]||(k[32]=h("span",null,"幻灯片主题",-1))])])]),h("div",g0,[(J(),X(Ve,null,_t(f,(C,D)=>h("button",{key:C.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+C.value,D===0?"b3-tooltips__ne":D===f.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===C.value}]]),"aria-label":C.desc,onClick:P=>T.$emit("update:docTheme",C.value)},[h("span",{class:xe(["spm-theme-card-preview","theme-preview--"+C.value]),"aria-hidden":"true"},[k[33]||(k[33]=ht('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===C.value?(J(),X("span",b0,"✓")):Ae("",!0)],2),h("span",v0,ve(C.label),1)],10,y0)),64))])]),h("div",k0,[h("div",w0,[h("div",x0,[h("div",S0,[le(de,{name:"palette"}),k[34]||(k[34]=h("span",null,"演示背景",-1))])])]),h("div",C0,[(J(),X(Ve,null,_t(v,C=>h("button",{key:C.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===C.value,"is-default":!C.value}]),"aria-label":C.desc,onClick:D=>T.$emit("update:docBackground",C.value)},[h("span",{class:"spm-bg-swatch-preview",style:io(x(C.value))},[h("span",{class:xe(["spm-bg-swatch-aa","is-"+C.mode])},"Aa",2),(e.docBackground||"")===C.value?(J(),X("span",I0,"✓")):Ae("",!0)],4),h("span",$0,ve(C.label),1)],10,_0)),64))]),h("div",T0,[h("span",{class:"spm-bg-input-preview",style:io(x(e.docBackground||"")),"aria-hidden":"true"},null,4),h("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:k[0]||(k[0]=C=>T.$emit("update:docBackground",C.target.value)),onChange:k[1]||(k[1]=C=>T.$emit("update:docBackground",C.target.value))},null,40,A0),e.docBackground?(J(),X("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:k[2]||(k[2]=C=>T.$emit("update:docBackground",""))}," ✕ ")):Ae("",!0)])]),h("div",M0,[h("div",E0,[h("div",B0,[h("div",L0,[le(de,{name:"ratio"}),k[35]||(k[35]=h("span",null,"画幅比例",-1))])])]),h("div",D0,[h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:k[3]||(k[3]=C=>T.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:k[4]||(k[4]=C=>T.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:k[5]||(k[5]=C=>T.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",N0,[h("div",O0,[h("div",P0,[h("div",R0,[le(de,{name:"ratio"}),k[36]||(k[36]=h("span",null,"间距风格",-1))])])]),h("div",z0,[h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:k[6]||(k[6]=C=>T.$emit("update:docSpacing","compact"))}," 紧凑 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:k[7]||(k[7]=C=>T.$emit("update:docSpacing","normal"))}," 标准 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:k[8]||(k[8]=C=>T.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),h("div",H0,[h("div",F0,[h("div",j0,[h("div",U0,[le(de,{name:"transition"}),k[37]||(k[37]=h("span",null,"全局默认转场",-1))])])]),le(xc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:k[9]||(k[9]=C=>T.$emit("update:docDefaultTransition",C))},null,8,["model-value"])]),h("div",W0,[k[48]||(k[48]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",q0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:k[10]||(k[10]=C=>T.$emit("openBottomPreview"))},[le(de,{name:"split-preview"}),k[38]||(k[38]=h("span",null,"分屏预览",-1))]),ue(Ot)("presenterMode")?(J(),X("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:k[11]||(k[11]=C=>T.$emit("openPresenter"))},[le(de,{name:"presenter"}),k[39]||(k[39]=h("span",null,"演讲者视图",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),X("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:k[12]||(k[12]=C=>T.$emit("aiAutoSplit"))},[le(de,{name:"sparkles"}),k[40]||(k[40]=h("span",null,"智能分页",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),X("button",{key:2,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线（需二次确认）",disabled:e.isBatchProcessing,onClick:k[13]||(k[13]=C=>T.$emit("clearDividers"))},[le(de,{name:"trash"}),k[41]||(k[41]=h("span",null,"清除分页",-1))],8,V0)):Ae("",!0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:k[14]||(k[14]=C=>T.$emit("autoAnimate"))},[le(de,{name:"step"}),k[42]||(k[42]=h("span",null,"智能动效",-1))],8,K0),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:k[15]||(k[15]=C=>T.$emit("clearAnimations"))},[le(de,{name:"trash"}),k[43]||(k[43]=h("span",null,"清除动效",-1))],8,G0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:k[16]||(k[16]=C=>T.$emit("addOrIdentifyNotes"))},[le(de,{name:"notes"}),k[44]||(k[44]=h("span",null,"增加讲稿块",-1))],8,Y0),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:k[17]||(k[17]=C=>T.$emit("clearNotes"))},[le(de,{name:"trash"}),k[45]||(k[45]=h("span",null,"清除讲稿块",-1))],8,Z0),ue(Ot)("exportHtml")?(J(),X("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:k[18]||(k[18]=C=>T.$emit("exportHtml"))},[le(de,{name:"export-html"}),k[46]||(k[46]=h("span",null,"导出 HTML",-1))])):Ae("",!0),ue(Ot)("exportPdf")?(J(),X("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:k[19]||(k[19]=C=>T.$emit("exportPdf"))},[le(de,{name:"export-pdf"}),k[47]||(k[47]=h("span",null,"导出 PDF",-1))])):Ae("",!0)])]),h("div",{class:xe(["spm-advanced-menu",{"is-expanded":s.value}])},[h("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":s.value,onClick:k[20]||(k[20]=C=>s.value=!s.value)},[h("span",X0,[le(de,{name:"settings"}),k[49]||(k[49]=h("span",null,"高级设置",-1))]),le(de,{name:"chevron-right",class:"spm-advanced-chevron"})],8,J0),s.value?(J(),X("div",Q0,[h("div",ek,[h("div",tk,[h("div",ok,[h("div",ik,[le(de,{name:"external-link"}),k[50]||(k[50]=h("span",null,"本地网络伺服预览",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:ue(i).enableWebServeJump,onChange:k[21]||(k[21]=C=>p(C.target.checked))},null,40,sk),k[51]||(k[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,nk)]),ue(i).enableWebServeJump?(J(),X("div",rk,[h("input",{value:ue(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:k[22]||(k[22]=no(()=>{},["stop"])),onKeyup:k[23]||(k[23]=no(()=>{},["stop"])),onInput:k[24]||(k[24]=C=>y(C.target.value)),onChange:k[25]||(k[25]=C=>g(C.target.value))},null,40,ak)])):Ae("",!0)]),h("div",lk,[h("div",ck,[h("div",dk,[h("div",uk,[le(de,{name:"type"}),k[52]||(k[52]=h("span",null,"固定特定标题大小",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:ue(i).normalizeHeadingSizes,onChange:k[26]||(k[26]=C=>d(C.target.checked))},null,40,hk),k[53]||(k[53]=h("span",{class:"spm-switch-slider"},null,-1))],8,fk)])]),h("div",pk,[h("div",mk,[h("div",gk,[h("div",yk,[le(de,{name:"list"}),k[54]||(k[54]=h("span",null,"列表前缀标记",-1))])])]),h("div",bk,[h("div",vk,[k[56]||(k[56]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[h("input",{type:"checkbox",checked:ue(i).showUnorderedListMarkers,onChange:k[27]||(k[27]=C=>b(C.target.checked))},null,40,wk),k[55]||(k[55]=h("span",{class:"spm-switch-slider"},null,-1))],8,kk)]),h("div",xk,[k[58]||(k[58]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[h("input",{type:"checkbox",checked:ue(i).showOrderedListMarkers,onChange:k[28]||(k[28]=C=>m(C.target.checked))},null,40,Ck),k[57]||(k[57]=h("span",{class:"spm-switch-slider"},null,-1))],8,Sk)])])]),h("div",_k,[h("div",Ik,[h("div",$k,[h("div",Tk,[le(de,{name:"sparkles"}),k[59]||(k[59]=h("span",null,"AI 演讲提词服务",-1))])]),h("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开完整设置弹窗",onClick:a},[le(de,{name:"settings"})])]),ue(n)?(J(),X("div",Ak,[k[60]||(k[60]=St(" 💡 通用 AI API 已由 ",-1)),k[61]||(k[61]=h("strong",null,"API 旋钮 (siyuan-api-switch)",-1)),St(" 接管 (Profile: "+ve(ue(n).profileName||"未命名")+")。相关输入框已置灰只读。 ",1)])):Ae("",!0),h("div",Mk,[h("div",Ek,[k[62]||(k[62]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"模型:",-1)),h("input",{value:ue(n)?ue(n).model:ue(i).aiConfig.model,class:"spm-input",disabled:!!ue(n),placeholder:"例如 deepseek-chat",onChange:k[29]||(k[29]=C=>r(C.target.value))},null,40,Bk)]),h("div",Lk,[k[63]||(k[63]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"Base URL:",-1)),h("input",{value:ue(n)?ue(n).baseUrl:ue(i).aiConfig.baseUrl,class:"spm-input",disabled:!!ue(n),placeholder:"https://api.openai.com/v1",onChange:k[30]||(k[30]=C=>l(C.target.value))},null,40,Dk)]),h("div",Nk,[k[64]||(k[64]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"API Key:",-1)),h("input",{value:ue(n)?ue(n).apiKey:ue(i).aiConfig.apiKey,type:"password",class:"spm-input",disabled:!!ue(n),placeholder:"sk-...",onChange:k[31]||(k[31]=C=>c(C.target.value))},null,40,Ok)])])])])):Ae("",!0)],2)]))}}),Rk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,zk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Hk(e){const t=await mc.loadAsync(e),o={},i=[];let n="",s="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||zk.test(c)||c.includes("snippets/")){const u=await l.file.async("string");o[c]=u;const f=c.split("/");f.length>1&&(o[f.slice(1).join("/")]=u)}else if(Rk.test(c)){const u=await l.file.async("uint8array"),f=c.split("/").pop()||c,p=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:f,data:u,blob:p})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function Fk(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),a=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=o(l);return c?`![${r}](${c})`:a}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=o(r);return l?`src="${l}"`:a}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],a=o(s);a&&(n.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const jk={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function Sc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function Uk(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,a=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[s]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const d=r.split("/").pop();for(const[b,m]of Object.entries(l))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const b=require("path");d.push(b.resolve(t.baseDir,r)),d.push(b.resolve(t.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const m=Sc(b);if(m!==null){c=m;break}}}if(!c){const d=jk||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,y]of Object.entries(d))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=y;break}}}if(!c)return null;let u=c;if(a){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),b=c.match(d);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+b[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function Wk(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function Cn(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const a=n.indexOf(":");if(a>0){const r=n.slice(0,a).trim();let l=n.slice(a+1).trim();if(l==="|"||l===">"){i++;const c=[];let u=-1;for(;i<o.length;){const f=o[i];if(!f.trim()){c.push(""),i++;continue}const d=f.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(f.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=Wk(l),!l){let c=i+1;const u=[];let f=-1;for(;c<o.length;){const p=o[c],d=p.trim();if(!d||d.startsWith("#")){f!==-1&&u.push(""),c++;continue}const b=p.match(/^(\s+)/),m=b?b[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(p.slice(f)),c++}if(u.length>0){t[r]=Cn(u.join(`
`)),i=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}i++}return t}const qk=/^\s*```ya?ml([\s\S]*?)```/;function Na(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=Cn(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(qk);if(n)t=Cn(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),a=[];let r=0;for(let l=0;l<s.length;l++){const c=s[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=Cn(a.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function Vk(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(a){if(i>=a)return;const r=t.slice(i,a).join(`
`).trim();r&&o.push(r),i=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(n){l.includes("-->")&&(n=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(n=!0);continue}if(l.startsWith("---")){s(a);const c=t[a+1];let u=!1,f=-1;const p=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&p.length>0){for(let d=a+1;d<t.length;d++){const b=t[d].trimEnd();if(b.startsWith("```"))break;if(b==="---"){f=d;break}}f!==-1&&f-a<=60&&t.slice(a+1,f).some(m=>{const y=m.trim();return y.length>0&&!y.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(y)})&&(u=!0)}u&&f!==-1&&(i=a,a=f)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let f=a+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(a=f)}}return i<t.length&&s(t.length),o}function _n(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=Vk(u),p={};let d="",b="",m=0;if(f.length>0){const j=f[0],B=Na(j),N=Object.keys(B.frontmatter).length>0,S=B.content.length>0;N&&!S&&f.length>1?(m=1,g(B.frontmatter)):N&&g(B.frontmatter)}function y(j,B,N){const S=String(j);S==="two-cols-header"?B[be]="cols-header":S==="three-cols-header"?(B[be]="cols-header",!N.layoutRatio&&!N["layout-ratio"]&&(B[yt]="1:1:1")):B[be]=S}function g(j){d=j.title||"",j.theme&&(p[Vi]=String(j.theme)),j.aspectRatio&&(p[Ki]=String(j.aspectRatio)),j.transition&&(p[Gi]=String(j.transition)),j.colorSchema&&(p[qa]=String(j.colorSchema)),j.layout&&y(j.layout,p,j),j.background&&(p[ct]=String(j.background)),j.image&&(p[qt]=String(j.image)),j.class&&(p[li]=String(j.class));for(const[B,N]of Object.entries(j))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(B)||(p[`custom-slides-${B}`]=typeof N=="object"?JSON.stringify(N):String(N))}const v=[];let x=0,_=0,T=0,k=0;const C=new Set,D={};let P=1;for(let j=m;j<f.length;j++){const B=f[j],{frontmatter:N,content:S}=Na(B),Z=B.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),W=N.src||(Z?Z[1]:void 0);if(W){const z=String(W).trim().replace(/^['"]|['"]$/g,"");let ne=c[z]||c[z.replace(/^\.\//,"")]||c[`pages/${z.replace(/^.*pages\//,"")}`];if(!ne){const U=z.replace(/^\.\//,""),w=[];if(t.baseDir)try{const q=require("path");w.push(q.resolve(t.baseDir,U)),w.push(q.resolve(t.baseDir,z))}catch{}try{const q=require("path");w.push(q.resolve(process.cwd(),U)),w.push(q.resolve(process.cwd(),z))}catch{}for(const q of w){const H=Sc(q);if(H!==null){ne=H;break}}}const L={};N.layout&&y(N.layout,L,N),N.transition&&(L[Ct]=String(N.transition)),N.background&&(L[ct]=String(N.background)),N.image&&(L[qt]=String(N.image)),N.class&&(L[li]=String(N.class));for(const[U,w]of Object.entries(N))["src","layout","transition","background","image","class"].includes(U)||(L[`custom-slides-${U}`]=typeof w=="object"?JSON.stringify(w):String(w));if(ne){const U=_n(ne,{...t,virtualFiles:c});for(const w of U.slides){w.pageIndex=P++,w.pageAttrs={...L,...w.pageAttrs},v.push(w);const q=w.pageAttrs[be]||"default";D[q]=(D[q]||0)+1}continue}else{v.push({pageIndex:P++,pageAttrs:{...L,"custom-slides-src":z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const U=L[be]||"default";D[U]=(D[U]||0)+1;continue}}const $={};N.layout&&y(N.layout,$,N),N.transition&&($[Ct]=String(N.transition)),N.background&&($[ct]=String(N.background)),N.image&&($[qt]=String(N.image)),N.class&&($[li]=String(N.class)),N.mask&&($[ci]=String(N.mask)),(N.maskRatio||N["mask-ratio"])&&($[Jo]=String(N.maskRatio||N["mask-ratio"])),(N.maskStyle||N["mask-style"])&&($[di]=String(N.maskStyle||N["mask-style"])),(N.maskInitial||N["mask-initial"])&&($[ui]=String(N.maskInitial||N["mask-initial"]));for(const[z,ne]of Object.entries(N))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(z)||($[`custom-slides-${z}`]=typeof ne=="object"?JSON.stringify(ne):String(ne));let M=S;const E=[];let Q=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,z=>{const ne=`__CODE_TOKEN_NOTE_${E.length}__`;return E.push(z),ne});Q=Q.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,z=>{const ne=`__CODE_TOKEN_NOTE_${E.length}__`;return E.push(z),ne});let F="";const V=Array.from(Q.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const z=V[V.length-1],ne=Q.slice(z.index+z[0].length).trim();if(!ne||!ne.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const U=z[1].trim();U.startsWith("TODO:")||(F=U,x++),o&&(Q=Q.slice(0,z.index).trimEnd()+Q.slice(z.index+z[0].length))}}o&&(Q=Q.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let z=0;z<E.length;z++)Q=Q.replace(`__CODE_TOKEN_NOTE_${z}__`,()=>E[z]);if(M=Q,F){for(let L=0;L<E.length;L++)F=F.replace(`__CODE_TOKEN_NOTE_${L}__`,()=>E[L]);const ne=`> [!NOTE] 💡 演讲备注
${F.split(/\r?\n/).map(L=>`> ${L}`).join(`
`)}
{: custom-slides-note="true"}`;M=M?`${M}

${ne}`:ne}let re=!1;if(/<style\b/i.test(M)){re=!0;const z=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(z){for(const ne of z){const L=ne.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${L}`:L}a&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(_+=oe.length);const ae=M.match(/```\w+\s+\{[^}]+\}/g);ae&&(T+=ae.length);const Se=M.match(/::\w+::|<template\s+#[^>]+>/g);if(Se&&(k+=Se.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,z=>Uk(z,{...t,virtualFiles:c})||z),i&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=xh(M)),l){let z=M.trim(),ne="";const L=z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(L!==-1&&(ne=z.slice(L),z=z.slice(0,L).trim()),(N.layout==="image-left"||N.layout==="image-right")&&N.image){const U=String(N.image).trim(),w=N.layout==="image-left"?"image-left":"image-right",q=`![配图](${U})
{: custom-slides-layout="${w}" }`;N.layout==="image-left"?z=`{{{col

${q}

${z}

}}}`:z=`{{{col

${z}

${q}

}}}`}if(N.background){const w=`![背景图](${String(N.background).trim()})
{: custom-slides-role="background" }`;z=z?`${w}

${z}`:w}M=ne?`${z}

${ne}`:z}const $e=Kk(M);$[ct]&&$e.push($[ct]),$[qt]&&$e.push($[qt]);for(const z of $e)C.add(z);const ke=/<[A-Z][a-zA-Z0-9]+/.test(M),Ce=$[be]||(P===1?p[be]||"cover":"default");D[Ce]=(D[Ce]||0)+1,v.push({pageIndex:P++,pageAttrs:$,notes:F,rawMarkdown:M,hasVueComponent:ke,hasStyleTag:re,assetReferences:$e})}if(!d&&v.length>0){const j=v[0].rawMarkdown.match(/^#\s+(.+)$/m);j&&(d=j[1].trim())}b&&(p["custom-slides-custom-css"]=b);let R=v.map(j=>`---

${j.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:p,slides:v,totalSlides:v.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:T,totalSlots:k,discoveredAssets:Array.from(C),layoutDistribution:D},flattenedMarkdown:R,customCss:b}}function Kk(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function Cc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function Gk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Yk(e,t,o=ze){const i=e.filter(Cc);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const a=t[s],r=i[s];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await o(r.id,a.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const a=t[s],r=i[s-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await o(r.id,a.pageAttrs),n++)}return n}async function Zk(e,t=ze){let o=!1,i=0;for(const n of e){if(Cc(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Te]:"right"}).catch(()=>{}),i++)}return i}async function Jk(e,t,o=Fa){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const a=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(a)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[a,r]of Object.entries(s.succMap))i[a]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&Fk(e,i),i}async function Xk(e){var v;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||Fa,u=l.createDocFn||Md,f=l.setAttrsFn||ze,p=l.getChildBlocksFn||Si,d=l.openTabFn||ie.openTab,b=l.showMessageFn||ie.showMessage;s&&n.length>0&&await Jk(t,n,c);const m=Gk(i),y=`/${m}`,g=await u(o,y,t.flattenedMarkdown);if(!g)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const x=((v=t.slides[0])==null?void 0:v.pageAttrs)||{};await f(g,{...x,...t.docRootAttrs});const _=await p(g).catch(()=>[]);Array.isArray(_)&&_.length>0&&(await Yk(_,t.slides,f),await Zk(_,f))}catch(x){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",x),b(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${x.message||String(x)}`,6e3)}return b(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=g,await d({app:r.app,doc:{id:g}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),g}function Qk(e){const t=pe("file"),o=pe(!1),i=pe(!1),n=pe(""),s=pe(null),a=pe(null),r=pe(""),l=pe(0),c=pe(""),u=pe([]),f=pe(null),p=pe(""),d=pe([]),b=pe(""),m=pe(!0),y=pe(!0),g=pe(!0),v=pe(!0),x=ye(()=>{const $=l.value;if($===0)return"0 B";const M=1024,E=["B","KB","MB","GB"],Q=Math.floor(Math.log($)/Math.log(M));return`${($/M**Q).toFixed(1)} ${E[Q]}`}),_=ye(()=>{var $;return(($=f.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),T=ye(()=>{var $;return u.value.length>0?u.value.length:(($=f.value)==null?void 0:$.stats.discoveredAssets.length)||0}),k=ye(()=>{var M;const $=((M=f.value)==null?void 0:M.stats.layoutDistribution)||{};return Object.entries($).map(([E,Q])=>({name:E,count:Q}))});async function C($=Ad){try{const M=await $();M!=null&&M.notebooks&&Array.isArray(M.notebooks)&&(d.value=M.notebooks.filter(E=>!E.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(M){console.warn("获取笔记本列表失败:",M)}}function D(){var $;($=s.value)==null||$.click()}function P(){a.value=null,r.value="",l.value=0,f.value=null,u.value=[],n.value=""}let R=0;async function j($){const M=++R;n.value="",a.value=$,r.value=$.name,l.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const Q=await $.arrayBuffer();if(M!==R)return;const F=await Hk(Q);if(M!==R)return;if(!F.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=F.assets;const V=_n(F.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:F.virtualFiles});if(M!==R)return;f.value=V,p.value=V.docTitle||$.name.replace(/\.zip$/i,"")}else{const Q=await $.text();if(M!==R)return;u.value=[];const F=$.path||"",V=F?F.replace(/[\\/][^\\/]+$/,""):"",re=_n(Q,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:V||void 0});if(M!==R)return;f.value=re,p.value=re.docTitle||$.name.replace(/\.md$/i,"")}}catch(E){if(M!==R)return;console.error("解析文件失败:",E),n.value=`解析文件失败: ${E.message||String(E)}`}}function B(){if(n.value="",!c.value.trim()){f.value=null;return}try{const $=_n(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=$,p.value=$.docTitle||"Slidev 演示文稿"}catch($){n.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function N(){a.value?await j(a.value):c.value&&B()}async function S($){const M=$.target;M.files&&M.files[0]&&await j(M.files[0])}async function Z($){var M;o.value=!1,(M=$.dataTransfer)!=null&&M.files&&$.dataTransfer.files[0]&&await j($.dataTransfer.files[0])}async function W($=e){if(f.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await Xk({presentation:f.value,notebookId:b.value,docTitle:p.value,extractedAssets:u.value,uploadAssets:g.value,autoPreview:v.value,plugin:$})}catch(M){console.error("导入 Slidev 演示失败:",M),n.value=`导入执行失败: ${M.message||String(M)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:p,notebooks:d,selectedNotebookId:b,optCleanHtml:m,optStripNotes:y,optUploadAssets:g,optAutoPreview:v,formattedFileSize:x,currentTheme:_,extractedAssetsCount:T,layoutChips:k,fetchNotebooks:C,triggerFileInput:D,clearFile:P,processFile:j,onFileSelected:S,onFileDrop:Z,onTextChange:B,reprocessCurrentInput:N,handleConfirmImport:W}}const ew={class:"spm-import-dialog"},tw={class:"spm-tabs-header"},ow={class:"spm-dialog-body"},iw={key:0,class:"spm-file-section"},nw={key:0,class:"spm-dropzone-prompt"},sw={class:"spm-dropzone-icon"},rw={key:1,class:"spm-dropzone-active"},aw={class:"spm-file-badge"},lw={class:"spm-file-size"},cw={key:1,class:"spm-text-section"},dw={key:2,class:"spm-error-banner"},uw={key:3,class:"spm-preview-card"},fw={class:"spm-preview-card__header"},hw={style:{display:"inline-flex","align-items":"center",gap:"4px"}},pw={class:"spm-config-grid"},mw={class:"spm-form-item"},gw={class:"spm-form-item"},yw=["value"],bw={class:"spm-stats-grid"},vw={class:"spm-stat-box"},kw={class:"spm-stat-value"},ww={class:"spm-stat-box"},xw={class:"spm-stat-value"},Sw={class:"spm-stat-box"},Cw={class:"spm-stat-value"},_w={class:"spm-stat-box"},Iw={class:"spm-stat-value"},$w={key:0,class:"spm-chips-row"},Tw={class:"spm-options-group"},Aw={class:"spm-checkbox-label"},Mw={class:"spm-checkbox-label"},Ew={class:"spm-checkbox-label"},Bw={class:"spm-checkbox-label"},Lw={class:"spm-dialog-footer"},Dw=["disabled"],Nw=["disabled"],Ow={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Pw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Rw=Ht({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Gt("plugin"),{inputMode:n,isDragging:s,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:p,customDocTitle:d,notebooks:b,selectedNotebookId:m,optCleanHtml:y,optStripNotes:g,optUploadAssets:v,optAutoPreview:x,formattedFileSize:_,currentTheme:T,layoutChips:k,fetchNotebooks:C,triggerFileInput:D,clearFile:P,onFileSelected:R,onFileDrop:j,onTextChange:B,reprocessCurrentInput:N,handleConfirmImport:S}=Qk(i);ti(async()=>{await C()});async function Z(){const $=await S();$&&(o("success",{docId:$}),o("close"))}function W(){o("close")}return($,M)=>(J(),X("div",{class:"spm-modal-overlay",onClick:no(W,["self"])},[h("div",ew,[h("div",{class:"spm-dialog-header"},[M[18]||(M[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlides"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:W},"✕")]),h("div",tw,[h("button",{class:xe(["spm-tab-btn",{active:ue(n)==="file"}]),onClick:M[0]||(M[0]=E=>n.value="file")},[le(de,{name:"package"}),M[19]||(M[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:xe(["spm-tab-btn",{active:ue(n)==="text"}]),onClick:M[1]||(M[1]=E=>n.value="text")},[le(de,{name:"notes"}),M[20]||(M[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",ow,[ue(n)==="file"?(J(),X("div",iw,[h("div",{class:xe(["spm-dropzone",{dragover:ue(s),"has-file":!!ue(c)}]),onDragover:M[4]||(M[4]=no(E=>s.value=!0,["prevent"])),onDragleave:M[5]||(M[5]=no(E=>s.value=!1,["prevent"])),onDrop:M[6]||(M[6]=no((...E)=>ue(j)&&ue(j)(...E),["prevent"])),onClick:M[7]||(M[7]=(...E)=>ue(D)&&ue(D)(...E))},[h("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:M[2]||(M[2]=(...E)=>ue(R)&&ue(R)(...E))},null,544),ue(c)?(J(),X("div",rw,[h("span",aw,[le(de,{name:"notes"}),St(" "+ve(ue(c)),1)]),h("span",lw,"("+ve(ue(_))+")",1),h("button",{class:"spm-btn-text",onClick:M[3]||(M[3]=no((...E)=>ue(P)&&ue(P)(...E),["stop"]))},"更换文件")])):(J(),X("div",nw,[h("span",sw,[le(de,{name:"folder",style:{"font-size":"32px"}})]),M[21]||(M[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),M[22]||(M[22]=h("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(J(),X("div",cw,[Wt(h("textarea",{"onUpdate:modelValue":M[8]||(M[8]=E=>ot(u)?u.value=E:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:M[9]||(M[9]=(...E)=>ue(B)&&ue(B)(...E))},null,544),[[Ws,ue(u)]])])),ue(r)?(J(),X("div",dw," ⚠️ "+ve(ue(r)),1)):Ae("",!0),ue(p)?(J(),X("div",uw,[h("div",fw,[h("span",hw,[le(de,{name:"sparkles"}),M[23]||(M[23]=St(" 演示解析摘要",-1))]),M[24]||(M[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",pw,[h("div",mw,[M[25]||(M[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Wt(h("input",{"onUpdate:modelValue":M[10]||(M[10]=E=>ot(d)?d.value=E:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ws,ue(d)]])]),h("div",gw,[M[26]||(M[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Wt(h("select",{"onUpdate:modelValue":M[11]||(M[11]=E=>ot(m)?m.value=E:null),class:"spm-select"},[(J(!0),X(Ve,null,_t(ue(b),E=>(J(),X("option",{key:E.id,value:E.id},ve(E.name),9,yw))),128))],512),[[th,ue(m)]])])]),h("div",bw,[h("div",vw,[h("span",kw,ve(ue(p).totalSlides),1),M[27]||(M[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",ww,[h("span",xw,ve(ue(T)),1),M[28]||(M[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Sw,[h("span",Cw,ve(ue(p).stats.totalNotes),1),M[29]||(M[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",_w,[h("span",Iw,ve(ue(f)),1),M[30]||(M[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ue(k).length>0?(J(),X("div",$w,[M[31]||(M[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),X(Ve,null,_t(ue(k),E=>(J(),X("span",{key:E.name,class:"spm-chip-badge"},ve(E.name)+": "+ve(E.count),1))),128))])):Ae("",!0),h("div",Tw,[h("label",Aw,[Wt(h("input",{"onUpdate:modelValue":M[12]||(M[12]=E=>ot(y)?y.value=E:null),type:"checkbox",onChange:M[13]||(M[13]=(...E)=>ue(N)&&ue(N)(...E))},null,544),[[pn,ue(y)]]),M[32]||(M[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",Mw,[Wt(h("input",{"onUpdate:modelValue":M[14]||(M[14]=E=>ot(g)?g.value=E:null),type:"checkbox",onChange:M[15]||(M[15]=(...E)=>ue(N)&&ue(N)(...E))},null,544),[[pn,ue(g)]]),M[33]||(M[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",Ew,[Wt(h("input",{"onUpdate:modelValue":M[16]||(M[16]=E=>ot(v)?v.value=E:null),type:"checkbox"},null,512),[[pn,ue(v)]]),M[34]||(M[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Bw,[Wt(h("input",{"onUpdate:modelValue":M[17]||(M[17]=E=>ot(x)?x.value=E:null),type:"checkbox"},null,512),[[pn,ue(x)]]),M[35]||(M[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ae("",!0)]),h("div",Lw,[h("button",{class:"spm-btn-secondary",disabled:ue(a),onClick:W}," 取消 ",8,Dw),h("button",{class:"spm-btn-primary",disabled:!ue(p)||ue(a),onClick:Z},[ue(a)?(J(),X("span",Ow,[le(de,{name:"refresh"}),M[36]||(M[36]=St(" 正在导入生成中...",-1))])):(J(),X("span",Pw,[le(de,{name:"rocket"}),M[37]||(M[37]=St(" 确认导入思源笔记",-1))]))],8,Nw)])])]))}}),zw=lo(Rw,[["__scopeId","data-v-c56a3d7e"]]);function Ir(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function _c(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Ir(s)&&o){let l=e.find(c=>c.startBlockId===o);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===o}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),l))return l}if(n){let l=e.find(c=>c.startBlockId===n);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===n}),l))return l}if(o){let l=e.find(u=>u.startBlockId===o);if(l||(l=e.find(u=>{var f,p;return((f=u.blocks)==null?void 0:f.some(d=>d.id===o))||((p=u.allBlockIds)==null?void 0:p.includes(o))}),l)||i&&i!==o&&(l=e.find(u=>{var f,p;return((f=u.blocks)==null?void 0:f.some(d=>d.id===i))||((p=u.allBlockIds)==null?void 0:p.includes(i))}),l)||(l=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(p=>p.id===o||p.id===i)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Te];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var f,p;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((p=u.blocks)==null?void 0:p.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),l))return l}return e[0]||null}function Cs(){var s;if(typeof window<"u"&&typeof((s=window.Lute)==null?void 0:s.NewNodeID)=="function")return window.Lute.NewNodeID();const e=new Date,t=a=>a.toString().padStart(2,"0"),o=`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`,i="0123456789abcdefghijklmnopqrstuvwxyz";let n="";for(let a=0;a<7;a++)n+=i[Math.floor(Math.random()*i.length)];return`${o}-${n}`}function Ic(){return typeof document>"u"?null:document.querySelector(".layout__wnd--active .protyle-wysiwyg")||document.querySelector(".protyle:not(.fn__none) .protyle-wysiwyg")||document.querySelector(".protyle-wysiwyg")}function Hw(e,t){var a;if(typeof document>"u")return!1;const o=Ic();if(!o)return!1;const i=Array.from(o.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));if(i.length>=2)return!0;const n=((a=i[0])==null?void 0:a.getAttribute("data-node-id"))||e,s=t==="NodeList"||t==="l"||t==="list";if(n){const r=o.querySelector(`[data-node-id="${n}"]`);if(r){const l=(s||r.getAttribute("data-type")==="NodeList"||r.classList.contains("list"))&&r.getAttribute("data-type")==="NodeList"?r:r.closest('[data-type="NodeList"], .list');if(l&&l.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li").length>=2)return!0}}return!1}async function Fw(e){const t=Ic();if(!t)return{success:!1,error:"未找到主编辑区"};const o=Array.from(t.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));let i=!1,n=null,s=[];if(o.length>=2){const x=o[0].closest('[data-type="NodeList"], .list');if(x){const _=new Set;let T=!0;for(const k of o){const C=k.getAttribute("data-type")==="NodeListItem"||k.classList.contains("li")?k:k.closest('[data-type="NodeListItem"], .li');if(!C||C.closest('[data-type="NodeList"], .list')!==x){T=!1;break}_.add(C)}T&&_.size>=2&&(i=!0,n=x,s=Array.from(x.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")).filter(k=>_.has(k)))}}let a=!1;if(!i){const x=(o.length===1?o[0]:null)||(e.activeBlockId?t.querySelector(`[data-node-id="${e.activeBlockId}"]`):null);if(x){const _=x.getAttribute("data-type")==="NodeList"||x.classList.contains("list")?x:x.closest('[data-type="NodeList"], .list');if(_){const T=Array.from(_.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li"));T.length>=2&&(a=!0,n=_,s=T)}}}if(i||a){if(!n||s.length<2)return{success:!1,error:"选中的列表项不足 2 项，无法合并为横向超级块"};const x=Array.from(n.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")),_=s.length===x.length,T=n.getAttribute("data-subtype")||"u",k=n.getAttribute("data-node-id")||"",C=n.parentElement,D=(C==null?void 0:C.getAttribute("data-node-id"))||e.currentDocId;let P=n.previousElementSibling;for(;P&&!P.getAttribute("data-node-id");)P=P.previousElementSibling;const R=(P==null?void 0:P.getAttribute("data-node-id"))||"";let j=n.nextElementSibling;for(;j&&!j.getAttribute("data-node-id");)j=j.nextElementSibling;const B=(j==null?void 0:j.getAttribute("data-node-id"))||"",N=Cs(),S=s.map($=>({li:$,liId:$.getAttribute("data-node-id")||"",newListId:Cs()})),Z=[],W=[];if(_){Z.push({action:"insert",id:N,data:`<div data-node-id="${N}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:R||void 0,nextID:R?void 0:B||void 0});for(let $=0;$<S.length;$++){const{liId:M,newListId:E}=S[$];Z.push({action:"insert",id:E,data:`<div data-node-id="${E}" data-type="NodeList" data-subtype="${T}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:$===0?void 0:S[$-1].newListId}),Z.push({action:"move",id:M,parentID:E})}k&&Z.push({action:"delete",id:k}),k&&W.push({action:"insert",id:k,data:n.outerHTML,parentID:D,previousID:R||void 0,nextID:R?void 0:B||void 0});for(let $=0;$<S.length;$++)W.push({action:"move",id:S[$].liId,parentID:k,previousID:$===0?void 0:S[$-1].liId});for(const{newListId:$}of S)W.push({action:"delete",id:$});W.push({action:"delete",id:N})}else{Z.push({action:"insert",id:N,data:`<div data-node-id="${N}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:k});for(let $=0;$<S.length;$++){const{liId:M,newListId:E}=S[$];Z.push({action:"insert",id:E,data:`<div data-node-id="${E}" data-type="NodeList" data-subtype="${T}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:$===0?void 0:S[$-1].newListId}),Z.push({action:"move",id:M,parentID:E})}for(let $=0;$<S.length;$++)W.push({action:"move",id:S[$].liId,parentID:k});for(const{newListId:$}of S)W.push({action:"delete",id:$});W.push({action:"delete",id:N})}return await Dr([{doOperations:Z,undoOperations:W}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach($=>$.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:S.length,superBlockId:N}}const r=o.filter(x=>{let _=x.parentElement;for(;_&&_!==t;){if(o.includes(_))return!1;_=_.parentElement}return!0});if(r.length<2)return{success:!1,error:"请在编辑区选中多个块，或选中一个包含多个列表项的列表"};const l=r[0],c=r[r.length-1],u=l.parentElement,f=(u==null?void 0:u.getAttribute("data-node-id"))||e.currentDocId;let p=l.previousElementSibling;for(;p&&!p.getAttribute("data-node-id");)p=p.previousElementSibling;const d=(p==null?void 0:p.getAttribute("data-node-id"))||"";let b=c.nextElementSibling;for(;b&&!b.getAttribute("data-node-id");)b=b.nextElementSibling;const m=(b==null?void 0:b.getAttribute("data-node-id"))||"",y=Cs(),g=[],v=[];g.push({action:"insert",id:y,data:`<div data-node-id="${y}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:f,previousID:d||void 0,nextID:d?void 0:m||void 0});for(let x=0;x<r.length;x++){const _=r[x].getAttribute("data-node-id");g.push({action:"move",id:_,parentID:y,previousID:x===0?void 0:r[x-1].getAttribute("data-node-id")})}for(let x=0;x<r.length;x++){const _=r[x].getAttribute("data-node-id");v.push({action:"move",id:_,parentID:f,previousID:x===0?d||void 0:r[x-1].getAttribute("data-node-id")})}return v.push({action:"delete",id:y}),await Dr([{doOperations:g,undoOperations:v}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(x=>x.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:r.length,superBlockId:y}}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(a,String(r)):s.removeAttribute(a)})}function jw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ze),i.removeAttribute("custom-slides-role");return}const s=e.get(n),a=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==a&&(a?i.setAttribute(be,a):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const l=(s==null?void 0:s[Ze])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ze)||i.getAttribute("custom-slides-role");c&&c!==l&&(l?i.setAttribute(Ze,l):(i.removeAttribute(Ze),i.removeAttribute("custom-slides-role")))})}function Uw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function Ww(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[b,m]of Object.entries(c))e.activeBlockAttrs.value[b]=m;Ee.setBlockAttrOverride(u,c),et(u,c);const f=(d=e.parentContainerId)==null?void 0:d.value,p=!!(f&&Uw(u,f));if(Ne in c&&p&&f){const b=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Ee.setBlockAttrOverride(f,{[Ne]:b}),et(f,{[Ne]:b}),ze(f,{[Ne]:b}).catch(()=>{})}if(be in c){const b=c[be];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(yt in c){const b=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const f=s();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(f,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const f=s();if(!f)return;const p={[be]:c,[yt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[yt]=u),e.currentPageDividerLayout.value=c,Ee.setBlockAttrOverride(f,p),et(f,p),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(f,p),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function l(c,u){var p;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),(p=e.latestDoc.value)!=null&&p.config&&(c===Vi&&(e.latestDoc.value.config.theme=u),c===Ki&&(e.latestDoc.value.config.aspectRatio=u),c===Gi&&(e.latestDoc.value.config.defaultTransition=u),c===An&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(f,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function qw(e){const t=(e||"").trim().toLowerCase();return t==="anthropic"||t==="anthropic-messages"?"anthropic-messages":t==="openai-responses"?"openai-responses":t==="systemone"||t==="system-one"||t==="jev"||t==="typesafe"?"systemone":"openai"}function Vw(e){const t=[{"content-type":"application/json"},{Authorization:`Bearer ${e.apiKey.trim()}`},{Accept:"application/json"}];if(e.headers&&typeof e.headers=="object")for(const[o,i]of Object.entries(e.headers))o&&i!==void 0&&i!==null&&t.push({[o]:String(i)});return t}function Kw(e){var i,n;if(!e||typeof e!="object")return null;const t=(i=e.choices)==null?void 0:i[0];if(!t)return null;const o=((n=t.message)==null?void 0:n.content)??t.text;return typeof o=="string"&&o.trim().length>0?o.trim():null}async function Gw(e,t,o){const i=t.baseUrl.replace(/\/+$/,""),n=i.endsWith("/chat/completions")?i:`${i}/chat/completions`,s={model:t.model,messages:e,max_tokens:t.maxTokens??4096,temperature:t.temperature??.7},a=Math.max(1,t.requestTimeoutSeconds||60)*1e3,r=Vw(t),l=await ja(n,"POST",s,r,a,"application/json");if(!l||l.status<200||l.status>=300){const f=typeof(l==null?void 0:l.body)=="string"?l.body.slice(0,200):"";throw new Error(`AI 请求失败 (HTTP ${(l==null?void 0:l.status)??"未知"})${f?`: ${f}`:""}`)}let c;try{c=typeof l.body=="string"?JSON.parse(l.body||"{}"):l.body}catch{throw new Error("AI 接口返回了非法的 JSON 响应")}const u=Kw(c);if(!u)throw new Error("AI 接口未返回有效的文本内容");return u}async function ss(e){const t=kr();if(!t)return null;try{return await Gw([{role:"system",content:"你是一位专业的幻灯片演讲教练与内容设计专家。请根据用户提供的幻灯片内容提供精炼、准确的输出。"},{role:"user",content:e}],t.config)}catch(o){throw console.warn("[LiveSlides AI] request failed:",(o==null?void 0:o.message)||o),o}}async function Yw(e){var r,l;if(!Un(e))return{success:!1,message:"配置不完整：请先补充 Base URL、API Key 和 Model"};const t=Date.now(),o=e.baseUrl.trim().replace(/\/+$/,""),i=e.apiKey.trim(),n=e.model.trim(),s=qw(e.protocol),a=Math.max(5,e.requestTimeoutSeconds||15);try{const c={displayName:"Live Slides AI",apiKey:i,baseURL:o,protocol:s,requestTimeout:a,headers:e.headers||{},models:[]},u=await ie.fetchSyncPost("/api/ai/testModel",{providerConfig:c,model:n});if(u&&u.code===0&&((r=u.data)!=null&&r.matched)&&!((l=u.data)!=null&&l.msg)){const f=Date.now()-t;return{success:!0,message:`测试成功（耗时 ${f}ms）：已通过思源内核验证模型并完成对话测试`,elapsed:f}}}catch{}try{let c,u,f;if(s==="anthropic-messages"?(c=/\/v1$/i.test(o)?`${o}/messages`:`${o}/v1/messages`,u=[{"content-type":"application/json"},{"anthropic-version":"2023-06-01"}],i&&u.push({"x-api-key":i}),f={model:n,max_tokens:1,messages:[{role:"user",content:"hi"}]}):s==="openai-responses"?(c=/\/responses$/i.test(o)?o:`${o}/responses`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_output_tokens:16,stream:!1,input:"hi"}):(c=/\/chat\/completions$/i.test(o)?o:`${o}/chat/completions`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_tokens:1,stream:!1,messages:[{role:"user",content:"hi"}]}),e.headers&&typeof e.headers=="object")for(const[g,v]of Object.entries(e.headers))g&&v!==void 0&&v!==null&&u.push({[g]:String(v)});const p=await ja(c,"POST",f,u,a*1e3,"application/json"),d=Date.now()-t,b=(p==null?void 0:p.status)??0,m=typeof(p==null?void 0:p.body)=="string"?p.body:"";if(b>=200&&b<300)return{success:!0,message:`连接成功（耗时 ${d}ms），服务商响应正常`,elapsed:d};const y=m.slice(0,160);return b===401||b===403?{success:!1,message:`鉴权失败 (HTTP ${b})：请检查 API Key 是否有效${y?` (${y})`:""}`,elapsed:d}:b===404?{success:!1,message:"端点未找到 (HTTP 404)：请检查 API 基础地址 (Base URL) 是否正确（OpenAI 兼容地址通常需以 /v1 结尾）",elapsed:d}:b===429?{success:!1,message:"请求被限流或余额不足 (HTTP 429)：请检查服务商账户额度与频率限制",elapsed:d}:b===400?{success:!1,message:`请求参数错误 (HTTP 400)：模型「${n}」可能不存在或不可用 (${y})`,elapsed:d}:b>=500?{success:!1,message:`服务商服务器错误 (HTTP ${b})：${y}`,elapsed:d}:{success:!1,message:`服务响应异常 (HTTP ${b})：${y||"请检查配置或网络"}`,elapsed:d}}catch(c){const u=Date.now()-t;return{success:!1,message:`网络或思源内核代理请求失败: ${(c==null?void 0:c.message)||c}`,elapsed:u}}}function $c(e){var i,n;if(!e)return"";const t=[],o=(e.content||e.rawMarkdown||e.markdown||((i=e.rawNode)==null?void 0:i.content)||((n=e.rawNode)==null?void 0:n.markdown)||"").trim();if(o&&o!=="---"){const s=o.replace(/\{:\s*[^}]+\s*\}\s*$/g,"").trim();s&&s!=="---"&&t.push(s)}if(Array.isArray(e.children)&&e.children.length>0)for(const s of e.children){const a=$c(s);a&&t.push(a)}return t.join(`
`)}function Tc(e){if(!e)return"";const t=[];if(Array.isArray(e.blocks)&&e.blocks.length>0)for(const i of e.blocks){if(i.slot==="slot-divider-right"||i.content==="::right::"||i.isNote)continue;const n=$c(i);n&&t.push(n)}let o=t.join(`

`).trim();if(!o&&e.rawMarkdown&&(o=e.rawMarkdown.replace(/^---\s*$/gm,"").trim()),!o&&e.frontmatter){const i=[];e.frontmatter.title&&i.push(`幻灯片标题: ${e.frontmatter.title}`),e.frontmatter.description&&i.push(`幻灯片描述: ${e.frontmatter.description}`),e.frontmatter.layout&&e.frontmatter.layout!=="default"&&i.push(`版式布局: ${e.frontmatter.layout}`),e.frontmatter.image&&i.push(`页面配图: ${e.frontmatter.image}`),i.length>0&&(o=i.join(`
`))}return o}async function Ac(e,t=ss){const o=Tc(e);if(!o)return{notes:"",isAiGenerated:!1,error:"当前幻灯片尚未填写正文内容，请先输入幻灯片标题或段落后再调用 AI 提炼"};if(t){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);return n&&n.trim()?{notes:n.trim(),isAiGenerated:!0}:{notes:"",isAiGenerated:!1,error:"AI 服务未配置或未返回可用提词内容"}}catch(n){return{notes:"",isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:"",isAiGenerated:!1,error:"未配置 AI 提词服务"}}async function Zw(e,t=ss){const o=await Ac(e,t);if(o.error)throw new Error(o.error);return o.notes}function Jw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Xw(e,t){if(!((t==null?void 0:t[Fe])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function Mc(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||Si)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(vo({...r,ial:{...r.ial||{},...Ee.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const a=[];for(let r=0;r<n.length;r++){const l=n[r];if(!l||l.length===0)continue;let c=null;for(let b=l.length-1;b>=0;b--){const m=l[b];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!Jw(c))continue;const u=Ee.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[Fe]&&(t!=null&&t.getBlockAttrsFn)){const b=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...b,...u}}let p=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const b=await t.getBlockKramdownFn(c.id);b!=null&&b.kramdown&&(p=b.kramdown)}catch{}if(Xw(p,f))continue;const d=Sr(p)||p.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:p,cleanContent:d||"在此输入本页讲稿提词..."})}return a}async function Ec(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||Ms,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${Fe}="true"}`;await i("markdown",r,e),await n(e,{[Fe]:"true"}),Ee.setBlockAttrOverride(e,{[Fe]:"true"}),s(e,{[Fe]:"true"})}async function Bc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await Mc(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(a=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,l=0;for(const u of n)try{await Ec(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:s,matchedCount:s,successCount:r,errorCount:l})},()=>{a({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function Qw(e,t){const o=pe(!1),i=pe(!1),{triggerSaveNotice:n}=t;async function s(g){var R,j,B,N,S,Z,W,$;const _=`> [!NOTE] 💡 演讲备注
${(g||"在此输入本页讲稿提词...").split(/\r?\n/).map(M=>`> ${M}`).join(`
`)}
{: custom-slides-note="true"}`,T=((R=e.latestDoc.value)==null?void 0:R.slides)||[],k=e.targetSlide.value,C=k?T.findIndex(M=>M===k):-1;let D=null;if(C!==-1&&C<T.length-1){const M=T[C+1];D=await ho("markdown",_,M.startBlockId)}else{const M=((j=k==null?void 0:k.noteBlocks)==null?void 0:j.slice(-1)[0])||((B=k==null?void 0:k.blocks)==null?void 0:B.slice(-1)[0]),E=(M==null?void 0:M.id)||(k==null?void 0:k.startBlockId);E?D=await ho("markdown",_,void 0,E):D=await bn("markdown",_,e.currentDocId.value)}const P=((Z=(S=(N=D==null?void 0:D[0])==null?void 0:N.doOperations)==null?void 0:S[0])==null?void 0:Z.id)||((W=D==null?void 0:D[0])==null?void 0:W.id);return P&&(await ze(P,{[Fe]:"true"}),Ee.setBlockAttrOverride(P,{[Fe]:"true"}),Ro(P,($=e.plugin)==null?void 0:$.app)),e.plugin&&await e.plugin.compileCurrentDocument(),P}async function a(){const g=e.activeBlockId.value;if(g)if(e.isNoteBlock.value){n("取消中...");try{await ze(g,{[Fe]:""}),Ee.setBlockAttrOverride(g,{[Fe]:""}),et(g,{[Fe]:""}),delete e.activeBlockAttrs.value[Fe],n("已取消备注"),ie.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",v),n("取消失败"),ie.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let v=e.rawSnippet.value;try{const k=await Ed(g);k!=null&&k.kramdown&&(v=k.kramdown)}catch{}const T=`> [!NOTE] 💡 演讲备注
${(Sr(v)||v.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",T,g),await ze(g,{[Fe]:"true"}),Ee.setBlockAttrOverride(g,{[Fe]:"true"}),et(g,{[Fe]:"true"}),e.activeBlockAttrs.value[Fe]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ie.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",v),n("设置失败"),ie.showMessage("转为讲稿备注提示块失败")}}}async function r(){try{await s(),ie.showMessage("已在正文末尾插入讲稿备注提示块")}catch(g){ie.showMessage("插入讲稿备注块失败"),console.error(g)}}function l(){var x;const g=e.currentSlideNoteBlockId.value;if(!g){ie.showMessage("未找到本页关联的讲稿备注块");return}Ro(g,(x=e.plugin)==null?void 0:x.app)?ie.showMessage("已在编辑区定位讲稿备注块"):ie.showMessage("定位讲稿备注块失败")}async function c(){var k,C,D,P,R,j,B,N,S,Z,W;const g=e.currentDocId.value||((k=e.plugin)==null?void 0:k.currentDocId)||"";if(!g){ie.showMessage("未检测到当前文档，请先在编辑器中打开幻灯片文档",5e3,"error");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往高级设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}if(i.value)return;const{slides:x}=await f();let _=e.targetSlide.value;!_&&x.length>0&&(_=_c(x,{activeBlockId:e.activeBlockId.value,activeBlockType:e.activeBlockType.value,currentPageDividerId:e.currentPageDividerId.value,activeBlockAttrs:e.activeBlockAttrs.value}));const T=Tc(_);if(!_||!T){ie.showMessage("当前幻灯片无有效正文内容，请先输入标题或段落后再提炼讲稿",5e3,"info");return}i.value=!0;try{ie.showMessage("正在调用 AI 提炼本页讲稿提词...");const $=await Ac(_,ss);if($.error){ie.showMessage(`AI 提炼提词卡失败：${$.error}`,6e3,"error");return}if($.notes){const M=((D=(C=_.noteBlocks)==null?void 0:C[0])==null?void 0:D.id)||e.currentSlideNoteBlockId.value;if(M){const E=`> [!NOTE] 💡 演讲备注
${$.notes.split(/\r?\n/).map(Q=>`> ${Q}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",E,M),await ze(M,{[Fe]:"true"}),Ee.setBlockAttrOverride(M,{[Fe]:"true"}),Ro(M,(P=e.plugin)==null?void 0:P.app)}else{const E=x.findIndex(Q=>Q===_);if(E!==-1){const F=`> [!NOTE] 💡 演讲备注
${$.notes.split(/\r?\n/).map(oe=>`> ${oe}`).join(`
`)}
{: custom-slides-note="true"}`;let V=null;if(E<x.length-1){const oe=x[E+1];V=await ho("markdown",F,oe.startBlockId)}else{const oe=((R=_.noteBlocks)==null?void 0:R.slice(-1)[0])||((j=_.blocks)==null?void 0:j.slice(-1)[0]),ae=(oe==null?void 0:oe.id)||_.startBlockId;ae?V=await ho("markdown",F,void 0,ae):V=await bn("markdown",F,g)}const re=((S=(N=(B=V==null?void 0:V[0])==null?void 0:B.doOperations)==null?void 0:N[0])==null?void 0:S.id)||((Z=V==null?void 0:V[0])==null?void 0:Z.id);re&&(await ze(re,{[Fe]:"true"}),Ee.setBlockAttrOverride(re,{[Fe]:"true"}),Ro(re,(W=e.plugin)==null?void 0:W.app))}else await s($.notes)}ie.showMessage("AI 演讲提词卡生成成功！"),e.plugin&&await e.plugin.compileCurrentDocument()}}catch($){ie.showMessage(`AI 提炼提词卡异常：${($==null?void 0:$.message)||$}`,6e3,"error")}finally{i.value=!1}}const u=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(x=>`> ${x}`).join(`
`)}
{: custom-slides-note="true"}`;async function f(){var _,T;const g=e.currentDocId.value||((_=e.plugin)==null?void 0:_.currentDocId)||"",v=(T=e.latestDoc.value)==null?void 0:T.slides;if(Array.isArray(v)&&v.length>0)return{docId:g,slides:v};if(!g)return{docId:"",slides:[]};const x=await Ee.compile(g).catch(()=>null);return{docId:g,slides:(x==null?void 0:x.slides)||[]}}async function p(g,v,x,_){var C,D,P,R,j,B;let T=null;if(v<x.length-1){const N=x[v+1];T=await ho("markdown",u,N.startBlockId)}else{const N=((C=g==null?void 0:g.noteBlocks)==null?void 0:C.slice(-1)[0])||((D=g==null?void 0:g.blocks)==null?void 0:D.slice(-1)[0]),S=(N==null?void 0:N.id)||(g==null?void 0:g.startBlockId);S?T=await ho("markdown",u,void 0,S):T=await bn("markdown",u,_||e.currentDocId.value)}const k=((j=(R=(P=T==null?void 0:T[0])==null?void 0:P.doOperations)==null?void 0:R[0])==null?void 0:j.id)||((B=T==null?void 0:T[0])==null?void 0:B.id);k&&(await ze(k,{[Fe]:"true"}),Ee.setBlockAttrOverride(k,{[Fe]:"true"}))}async function d(){if(o.value)return;const{docId:g,slides:v}=await f();if(v.length===0){ie.showMessage("当前文档无幻灯片页面");return}const x=v.map((T,k)=>({slide:T,idx:k})).filter(({slide:T})=>{var D;const k=Array.isArray(T.noteBlocks)&&T.noteBlocks.length>0,C=!!((D=T.notes)!=null&&D.trim());return!k&&!C});if(x.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const _=x.length;ie.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${_} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量追加讲稿块...");let T=0;try{for(const{slide:k,idx:C}of x)try{await p(k,C,v,g),T++}catch(D){console.error(`[SiYuanLiveSlides] 为第 ${C+1} 页追加讲稿块失败:`,D)}e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功为 ${T} 页追加讲稿备注块`)}catch(k){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",k),ie.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function b(){if(o.value)return;const{slides:g}=await f();if(g.length===0){ie.showMessage("当前文档无幻灯片页面");return}const v=[];for(const T of g)if(T.noteBlocks&&T.noteBlocks.length>0)for(const k of T.noteBlocks)k.id&&v.push({id:k.id,pageIndex:T.pageIndex});if(v.length===0){ie.showMessage("当前文档中没有讲稿备注块，无需删除");return}const x=new Set(v.map(T=>T.pageIndex)).size,_=v.length;ie.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${_} 个讲稿备注块（涉及 ${x} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量删除讲稿块...");let T=0;try{for(const k of v)try{await Qs(k.id),Ee.clearBlockAttrOverride(k.id),T++}catch(C){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${k.id} 失败:`,C)}e.activeBlockId.value&&v.some(k=>k.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[Fe],e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功删除全部 ${T} 个讲稿备注块`)}catch(k){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",k),ie.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function m(){var v;const g=e.currentDocId.value||((v=e.plugin)==null?void 0:v.currentDocId);if(!g){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await Bc(g,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function y(){if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}const{docId:g,slides:v}=await f();if(!g){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(v.length===0){ie.showMessage("当前文档无幻灯片页面");return}const x=await Mc(g),_=new Set(x.map(C=>C.pageIndex)),T=v.map((C,D)=>({slide:C,idx:D})).filter(({slide:C,idx:D})=>{var B;const P=Array.isArray(C.noteBlocks)&&C.noteBlocks.length>0,R=!!((B=C.notes)!=null&&B.trim()),j=C.pageIndex??D+1;return!P&&!R&&!_.has(j)});if(x.length===0&&T.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let k="";x.length>0&&T.length>0?k=`扫描检测到 ${x.length} 处已有候选讲稿待规范化，另有 ${T.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:x.length>0?k=`扫描检测到 ${x.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:k=`将在未配置讲稿的 ${T.length} 页末尾自动增加默认讲稿提示块，是否继续？`,ie.confirm("增加讲稿块",k,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在处理讲稿块...");let C=0,D=0;try{for(const P of x)try{await Ec(P.id,P.cleanContent),C++}catch(R){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${P.id} 失败:`,R)}for(const{slide:P,idx:R}of T)try{await p(P,R,v,g),D++}catch(j){console.error(`[SiYuanLiveSlides] 为第 ${R+1} 页增加讲稿块失败:`,j)}e.plugin&&await e.plugin.compileCurrentDocument(),n("已更新讲稿"),C>0&&D>0?ie.showMessage(`已规范化 ${C} 处现有讲稿，并为 ${D} 页新增讲稿块`):C>0?ie.showMessage(`已成功识别并规范化 ${C} 个讲稿块`):ie.showMessage(`已成功为 ${D} 页增加讲稿备注块`)}catch(P){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",P),ie.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,isGeneratingNotes:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:a,onAddNoteBlock:r,onLocateNoteBlock:l,onGenerateNotesWithAI:c,onBatchAppendNotes:d,onBatchDeleteNotes:b,onIdentifyNotesBlocks:m,onAddOrIdentifyNotesBlocks:y}}function e2(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function t2(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function o2(e){const t=[],o=i=>{var n,s,a,r,l,c,u,f,p;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[Fe])==="true"||((s=d.ial)==null?void 0:s[Fe])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(e2(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Ne])||((r=d.ial)==null?void 0:r[Ne]),rawBlock:d});continue}if(t2(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Ne])||((c=d.ial)==null?void 0:c[Ne]),rawBlock:d});continue}const b=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(b)&&b.length>0){o(b);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((f=d.attributes)==null?void 0:f[Ne])||((p=d.ial)==null?void 0:p[Ne]),rawBlock:d})}};return o(e||[]),t}function i2(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=o2(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const a=t[s];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&i.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function n2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Ee.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const a of i.slides){const r=i2(a);r.length>0&&(n.push(...r),s.add(a.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function Lc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await n2(e,t);if(a.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var p;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const d of a.targets)try{await n(d.blockId,{[Ne]:d.targetClick}),Ee.setBlockAttrOverride(d.blockId,{[Ne]:d.targetClick}),s(d.blockId,{[Ne]:d.targetClick}),u++}catch(b){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,b),f++}(p=t==null?void 0:t.onSuccessNotice)==null||p.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:f})},()=>{c({...a,successCount:0,errorCount:0})})})}async function s2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Ee.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,a=new Set,r=(l,c)=>{var u,f,p,d,b;for(const m of l){if(!m)continue;if(m.id&&!s.has(m.id)){const g=Ee.getBlockAttrOverride(m.id),v=(g==null?void 0:g[Ne])??m.clicks??((u=m.attributes)==null?void 0:u[Ne])??((f=m.ial)==null?void 0:f[Ne]),x=(g==null?void 0:g[Et])??m.motion??((p=m.attributes)==null?void 0:p[Et])??((d=m.ial)==null?void 0:d[Et]),_=!!(v&&String(v).trim()!==""),T=!!(x&&String(x).trim()!=="");(_||T)&&(s.add(m.id),n.push({blockId:m.id,pageIndex:c,hasClick:_,hasMotion:T}),a.add(c))}const y=m.children&&m.children.length>0?m.children:(b=m.rawNode)==null?void 0:b.children;Array.isArray(y)&&y.length>0&&r(y,c)}};for(const l of i.slides)r(l.blocks||[],l.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:a.size,targets:n}}async function r2(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await s2(e,t);if(a.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${l} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,f=0;const p={[Ne]:"",[Et]:""};for(const b of a.targets)try{await n(b.blockId,p),Ee.setBlockAttrOverride(b.blockId,p),s(b.blockId,p),u++}catch(m){console.error(`[SiYuanLiveSlides] 清除块 ${b.blockId} 动效失败:`,m),f++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:f})},()=>{c({...a,successCount:0,errorCount:0})})})}function a2(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Yo]:"true",[ai]:"true"}),e.activeBlockAttrs.value[Yo]="true",e.activeBlockAttrs.value[ai]="true"):(await o(Yo,"false"),e.activeBlockAttrs.value[Yo]="false")}async function a(){const R=e.videoLoop.value?"false":"true";await o(Mn,R)}async function r(){const R=e.videoMuted.value?"false":"true";await o(ai,R)}async function l(){const R=e.videoControls.value?"false":"true";await o(En,R)}async function c(R){var Z,W;const j=e.activeBlockId.value;if(!j)return;const B=e.rawSnippet.value||"",N=xo(B)||"",S=e.currentPageDividerId.value||e.currentDocId.value;if(R)if(R==="background"){const $={[Ze]:"background",[be]:""};S&&N&&(e.pageBackground&&(e.pageBackground.value=N),await ze(S,{[ct]:N}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[ct]:N}),et(S,{[ct]:N}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=N)),await i($)}else(R===Bn||R===Ln)&&await i({[be]:R,[Ze]:""});else{const $={[Ze]:"",[be]:""};if(e.activeBlockAttrs.value[ct]==="true"&&($[ct]=""),S&&N&&((Z=e.pageBackground)==null?void 0:Z.value)===N&&(e.pageBackground&&(e.pageBackground.value=""),await ze(S,{[ct]:""}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[ct]:""}),et(S,{[ct]:""}),(W=e.targetSlide.value)!=null&&W.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i($),typeof document<"u"){const M=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`),E=M==null?void 0:M.closest('[data-type="NodeListItem"]'),Q=E==null?void 0:E.getAttribute("data-node-id");if(Q&&Q!==j){const F={[be]:"",[Ze]:""};et(Q,F),Ee.setBlockAttrOverride(Q,F),await ze(Q,F).catch(()=>{})}}}}function u(){e.elemClick.value?o(Ne,""):o(Ne,"+1")}function f(R){o(Ne,R)}function p(R){o(Et,R)}function d(R){(e.activeBlockAttrs.value[Te]||"")===R?o(Te,""):o(Te,R)}function b(R){e.elemShikiLines.value=R,o(ei,R)}function m(R){const j=R?R.trim():"",B=/^\d+$/.test(j)?`${j}px`:j;e.elemMaxHeight.value=B,o(Yi,B)}async function y(){const R=e.currentSlideLayout.value==="three-cols-header";await o(Te,R?"col-1":"left"),ie.showMessage(R?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function g(){const R=e.activeBlockId.value;R&&ie.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const j={[Ne]:"",[Et]:"",[Te]:"",[ei]:"",[Yi]:"",[Fe]:"",[be]:"",[yt]:"",[Ze]:"",[Ct]:"",[ct]:"",[qt]:"",[Yo]:"",[Mn]:"",[ai]:"",[En]:""};if(et(R,j),await ze(R,j),Ee.clearBlockAttrOverride(R),typeof document<"u"){const B=document.querySelector(`.protyle-wysiwyg [data-node-id="${R}"]`),N=B==null?void 0:B.closest('[data-type="NodeListItem"]'),S=N==null?void 0:N.getAttribute("data-node-id");S&&S!==R&&(et(S,j),await ze(S,j).catch(()=>{}),Ee.clearBlockAttrOverride(S))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ie.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function v(){if(e.activeBlockId.value)try{await ho("markdown","---",e.activeBlockId.value,void 0),ie.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function x(){const R=e.activeBlockId.value||e.currentDocId.value;if(R)try{await ho("markdown","---",void 0,R),ie.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function _(){if(e.activeBlockId.value)try{await Qs(e.activeBlockId.value),ie.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("删除失败")}}async function T(){var R,j;try{let B=null;if(typeof document<"u"){const S=e.activeBlockId.value;if(S){const Z=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);Z&&(B=Z.getAttribute("data-type")==="NodeSuperBlock"?Z:Z.closest('[data-type="NodeSuperBlock"]'))}if(!B){const Z=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(Z){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${Z}"]`);if(W){let $=W.nextElementSibling;for(;$&&!($.getAttribute("data-type")==="NodeThematicBreak"||(R=$.classList)!=null&&R.contains("protyle-wysiwyg__block--hr"));){const M=$.getAttribute("data-type")==="NodeSuperBlock"?$:$.querySelector('[data-type="NodeSuperBlock"]');if(M){B=M;break}$=$.nextElementSibling}}}else{const W=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),$=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of $)if(!W||M.compareDocumentPosition(W)&Node.DOCUMENT_POSITION_FOLLOWING){B=M;break}}}}const N=[];if(B){const S=Array.from(B.querySelectorAll(":scope > [data-node-id]"));for(const Z of S){const W=Z.getAttribute("data-node-id");W&&(N.push(W),Z.removeAttribute("style"))}}else if((j=e.targetSlide.value)!=null&&j.blocks){for(const S of e.targetSlide.value.blocks)if(S.children&&S.children.length>=2){for(const Z of S.children)Z.id&&N.push(Z.id);break}}if(N.length>0)for(const S of N)await ze(S,{style:""}).catch(()=>{});await n(yt,""),ie.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(B){console.error("[layout-actions] resetSuperBlockWidth error:",B),ie.showMessage("重置超级块比例失败")}}async function k(){var R,j,B;try{let N=null;if(typeof document<"u"){const Z=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),W=e.activeBlockId.value;let $=[];if(Z){const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${Z}"]`);if(Q){let F=Q.nextElementSibling;for(;F&&!(F.getAttribute("data-type")==="NodeThematicBreak"||(R=F.classList)!=null&&R.contains("protyle-wysiwyg__block--hr"));)$.push(F),F=F.nextElementSibling}}else{const Q=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),F=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const V of F)if(!Q||V.compareDocumentPosition(Q)&Node.DOCUMENT_POSITION_FOLLOWING)$.push(V);else break}const M=[];let E;for(const Q of $){const F=Q.getAttribute("data-type");F==="NodeHeading"&&(E=Q.getAttribute("data-node-id")||void 0);const V=[];F==="NodeSuperBlock"?V.push(Q):V.push(...Array.from(Q.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const re of V){if((re.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ae=re.getAttribute("data-node-id")||"";let Se=[];const $e=Array.from(re.querySelectorAll('[data-type="NodeListItem"]'));if($e.length===4&&(Se=$e.map(ke=>ke.getAttribute("data-node-id")).filter(Boolean)),Se.length!==4){const ke=Array.from(re.querySelectorAll(":scope > [data-node-id]"));ke.length===4&&(Se=ke.map(Ce=>Ce.getAttribute("data-node-id")).filter(Boolean))}Se.length===4&&M.push({sbId:ae,itemIds:Se,headerId:E})}}M.length>0&&(W&&(N=M.find(Q=>{if(Q.sbId===W||Q.itemIds.includes(W))return!0;const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q.sbId}"]`),V=document.querySelector(`.protyle-wysiwyg [data-node-id="${W}"]`);return!!(F&&V&&F.contains(V))})||null),N||(N=M[0]))}if(!N&&((j=e.targetSlide.value)!=null&&j.blocks)){const Z=e.targetSlide.value,W=[];for(const M of Z.blocks)M.rawNode?W.push(M.rawNode):W.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const $=bh(W,e.activeBlockId.value);$&&$.items.length===4&&(N={sbId:$.superBlockNode.id,itemIds:$.items.map(M=>M.id),headerId:(B=$.headerNode)==null?void 0:B.id})}const S=e.currentPageDividerId.value||e.currentDocId.value;if(S&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Ee.setBlockAttrOverride(S,{[be]:"clover"}),et(S,{[be]:"clover"}),await ze(S,{[be]:"clover"}).catch(()=>{})),N&&N.itemIds.length>0){N.headerId&&(Ee.setBlockAttrOverride(N.headerId,{[Te]:"header"}),et(N.headerId,{[Te]:"header"}),await ze(N.headerId,{[Te]:"header"}).catch(()=>{}));const Z=Math.min(4,N.itemIds.length);for(let W=0;W<Z;W++){const $=N.itemIds[W],M=`col-${W+1}`;Ee.setBlockAttrOverride($,{[Te]:M}),et($,{[Te]:M}),await ze($,{[Te]:M}).catch(()=>{})}}return ie.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(N){return console.error("[layout-actions] applyCloverLayout error:",N),ie.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var j,B;const R=e.currentDocId.value||((j=e.plugin)==null?void 0:j.currentDocId);if(!R){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((B=t.isBatchProcessing)!=null&&B.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await Lc(R,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function D(){var j,B;const R=e.currentDocId.value||((j=e.plugin)==null?void 0:j.currentDocId);if(!R){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((B=t.isBatchProcessing)!=null&&B.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const N=await r2(R,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});N.successCount>0&&e.activeBlockId.value&&N.targets.some(S=>S.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ne],delete e.activeBlockAttrs.value[Et])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function P(){var B,N,S,Z;const R=await Fw({currentDocId:((B=e.currentDocId)==null?void 0:B.value)||"",activeBlockId:((N=e.activeBlockId)==null?void 0:N.value)||""});if(!R.success){ie.showMessage(R.error||"合并为横向超级块失败");return}const j=`🎉 已成功合并为横向超级块 (${R.colCount||2} 列)`;ie.showMessage(j),t.triggerSaveNotice&&t.triggerSaveNotice(j),(S=e.plugin)!=null&&S.compileCurrentDocument&&await e.plugin.compileCurrentDocument((Z=e.currentDocId)==null?void 0:Z.value)}return{onToggleVideoAutoplay:s,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:p,onElemSlotChange:d,onElemShikiLinesChange:b,onElemMaxHeightChange:m,onSetTwoColsContrast:y,onClearBlockAttrs:g,onInsertDividerBefore:v,onInsertDividerAfter:x,onDeleteCurrentBlock:_,onConvertToSuperBlock:P,resetSuperBlockWidth:T,applyCloverLayout:k,onAutoAnimateDocument:C,onClearAnimationsDocument:D}}function l2(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:a}=Ww(e),r=Qw(e,{triggerSaveNotice:t}),l=a2(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var g;if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,b=await zo(d,(g=e.currentDocId)==null?void 0:g.value,e.plugin);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const m=await fc(d,{title:b});hc(`${b}.html`,m)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function u(){if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}pc(e.latestDoc.value)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=pe(!1);async function p(){var d;if(f.value){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,m=await zo(b,(d=e.currentDocId)==null?void 0:d.value,e.plugin),y=await vc(b,{title:m,onProgress:(g,v)=>{ie.showMessage(`正在导出幻灯片图片 (${g} / ${v})...`,2e3)}});y.success?ie.showMessage(`🎉 成功导出 ${y.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ie.showMessage(`导出图片失败：${y.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isGeneratingNotes:r.isGeneratingNotes,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,onConvertToSuperBlock:l.onConvertToSuperBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,onClearAnimationsDocument:l.onClearAnimationsDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:p}}function c2(e){const t=ye(()=>Ir(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:a="defined"}=i,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Ee.getBlockAttrOverride(l);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function _s(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function d2(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(vo(i)||(i.content||i.markdown||"").trim())return i}return null}function Is(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function Oa(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const l=t[r],c=(l.markdown||l.content||"").trim();if(c.includes("![")||c.includes("<img")||l.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,a=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(a=!0);return s||n>=3?"two-cols":a&&t.length<=2?"quote":"default"}function u2(e,t){const o=[],i=new Set,n=6,s=6;let a=0,r=0,l=0,c=0,u=null;function f(p){const d=[];for(let b=p+1;b<e.length;b++){const m=e[b];if(vo(m))break;const y=_s(m);if(y!==null&&(y===1||y===2||y===3))break;d.push(m)}return d}if(e.length>0){let p=!1,d=-1;for(let b=0;b<e.length;b++){const m=e[b];if(vo(m)){p=!0;break}if((m.content||m.markdown||"").trim()){d=b;break}}if(!p&&d>=0){const b=e[d],m=_s(b);let y=m===1?"cover":"default";if(m!==1){const v=f(d);y=Oa(m,v)}const g=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:b.id,recommendedLayout:y,reason:g}),i.add(b.id)}}for(let p=0;p<e.length;p++){const d=e[p];if(vo(d)){a=0,r=0,l=0,c=0,u=null;continue}const b=d2(e,p),m=!b||vo(b),y=_s(d);if(y===1||y===2||y===3){if(!(l===1&&c===0&&u!==null&&!(u===1&&y===2))&&!m&&a>0&&!i.has(d.id)){let T=y===1?"cover":"default";{const C=f(p);T=Oa(y,C)}let k=y===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":y===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";T==="image-right"||T==="image-left"?k+=" (推荐图文版式)":T==="two-cols"?k+=" (推荐双栏版式)":T==="quote"&&(k+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:T,reason:k}),i.add(d.id),a=1,r=Is(d),l=1,c=0,u=y;continue}a++,r+=Is(d),l++,u=y;continue}const v=Is(d);if((a>=n||r+v>s&&a>0)&&!m&&a>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),a=1,r=v,l=0,c=1,u=null;continue}a++,r+=v,c++}return o}async function Dc(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=u2(o);if(i.length===0){ie.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ie.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await ho("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(a){console.warn("Failed to insert divider:",a)}ie.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function Nc(e){var s,a,r,l,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容");return}const o=[],i=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((s=f.markdown)==null?void 0:s.trim())==="---"||((a=f.markdown)==null?void 0:a.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((l=f.content)==null?void 0:l.trim())==="---")?o.push(f.id):((c=f.ial)!=null&&c[mo]||(u=f.ial)!=null&&u[be])&&i.push(f.id);if(o.length===0&&i.length===0){ie.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}const n=o.length;return new Promise(f=>{ie.confirm("危险操作：清除所有分页线",`此操作将从正文中彻底删除全部 ${n} 处幻灯片分页线（全篇将合并为单页），删除后无法撤销。是否确认继续？`,async()=>{ie.showMessage(`正在清除文档中的 ${n} 处分页线...`);let p=0;for(const d of o)try{await Qs(d),p++}catch(b){console.warn("Failed to delete divider block:",b)}for(const d of i)try{await ze(d,{[mo]:"",[be]:""})}catch(b){console.warn("Failed to clear slide attrs:",b)}ie.showMessage(`已成功清除文档中的 ${p} 处分页线并重新编译`),await e.compileCurrentDocument(e.currentDocId),f()},()=>{f()})})}const f2={class:"spm-slides-inspector"},h2={class:"spm-inspector-topbar"},p2={class:"spm-inspector-title"},m2={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},g2={class:"spm-inspector-topbar-actions"},y2={class:"spm-target-banner"},b2={class:"spm-target-info"},v2=["aria-label"],k2={key:0,class:"spm-save-status"},w2=["title"],x2={class:"spm-inspector-body"},S2=Ht({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Gt("plugin"),i=pe(!1);function n(te){i.value=!1,c.value=te.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(te.docId)}const s=pe(""),a=pe(""),r=pe({}),l=pe(""),c=pe(""),u=pe(""),f=pe(""),p=pe(""),d=pe(""),b=pe(""),m=pe(""),y=pe(null),g=pe(""),v=pe("");function x(){var ge;const te=s.value||c.value;te&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(te).then(()=>{v.value="已复制！",setTimeout(()=>{v.value=""},1500)}).catch(()=>{})}const _=ye(()=>Ir(a.value)),T=ye(()=>a.value==="NodeCodeBlock"),k=pe(!1),C=ye(()=>{if(k.value||Ge.value)return!0;const te=l.value||"";return!!xo(te)}),D=ye(()=>{const te=a.value||"";if(te==="NodeVideo"||te==="video")return!0;const ge=l.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),P=ye(()=>!s.value||s.value===c.value||a.value==="doc"||a.value==="NodeDocument"),R=ye(()=>{const te=s.value||c.value||"";return te.length>8?te.slice(-8):te||"无"}),j=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),B=ye(()=>{if(_.value)return"分页符 (---)";if(P.value)return"全局文档";if(D.value)return"视频块";let te="内容块";switch(a.value){case"NodeHeading":te="标题块";break;case"NodeParagraph":te="段落块";break;case"NodeCodeBlock":te="代码块";break;case"NodeVideo":te="视频块";break;case"NodeList":case"NodeListItem":te="列表项";break;case"NodeBlockquote":te="引述块";break;case"NodeTable":te="表格块";break;case"NodeSuperBlock":case"s":case"sb":te="超级块";break;default:te="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${te}`:`分栏容器 › ${te}`:te}),N=ye(()=>_.value?"tag-divider":P.value?"tag-doc":"tag-block"),S=ye(()=>r.value[be]||"default"),Z=ye(()=>r.value[Ct]||"slide-left"),W=pe(""),$=pe(""),M=ye(()=>r.value[Oi]||"inherit"),E=ye(()=>{var te;return _c((te=y.value)==null?void 0:te.slides,{activeBlockId:s.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),Q=ye(()=>{var te;return((te=E.value)==null?void 0:te.notes)||""}),F=ye(()=>{var te,ge,Be;return((Be=(ge=(te=E.value)==null?void 0:te.noteBlocks)==null?void 0:ge[0])==null?void 0:Be.id)||""}),V=ye(()=>{var We,qe,Re,kt,cn,Ao;if(_.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const te=r.value[Te]||r.value["custom-slides-slot"];if(te&&(["col-1","col-2","col-3"].includes(te)||/^col-\d+$/.test(te)))return"cols-header";if(p.value)return p.value;const ge=f.value||(_.value?s.value:"");if(ge){const it=Ee.getBlockAttrOverride(ge);if(it!=null&&it[be])return it[be]}if(ge&&((We=y.value)!=null&&We.slides)){const it=y.value.slides.find(oi=>oi.startBlockId===ge);if((qe=it==null?void 0:it.frontmatter)!=null&&qe.layout)return it.frontmatter.layout}if((kt=(Re=E.value)==null?void 0:Re.frontmatter)!=null&&kt.layout)return E.value.frontmatter.layout;if((Ao=(cn=E.value)==null?void 0:cn.blocks)!=null&&Ao.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Be=Ee.getBlockAttrOverride(c.value);return Be!=null&&Be[be]?Be[be]:"default"}),re=c2({activeBlockId:s,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:f}),oe=re.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var te,ge;return((ge=(te=E.value)==null?void 0:te.frontmatter)==null?void 0:ge.layoutRatio)||""}}),ae=re.resolvePageAttr({attrKey:ci,fallback:()=>{var te,ge;return((ge=(te=E.value)==null?void 0:te.frontmatter)==null?void 0:ge.mask)||""}}),Se=re.resolvePageAttr({attrKey:Jo,fallback:()=>{var te,ge;return((ge=(te=E.value)==null?void 0:te.frontmatter)==null?void 0:ge.maskRatio)||""}}),$e=re.resolvePageAttr({attrKey:di,fallback:()=>{var te,ge;return((ge=(te=E.value)==null?void 0:te.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),ke=re.resolvePageAttr({attrKey:ui,fallback:()=>{var te,ge;return((ge=(te=E.value)==null?void 0:te.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function Ce(te){if(!te||(te.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Be=Array.from(te.querySelectorAll(":scope > [data-node-id]"));if(Be.length<2)return null;const We=Be.length,qe=Be.map(Ao=>{const it=Ao.getAttribute("style")||"",oi=it.match(/calc\(\s*([\d.]+)%/);if(oi)return parseFloat(oi[1]);const Ti=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ti?parseFloat(Ti[1]):null});let Re="",kt=!1;if(qe.some(Ao=>Ao!==null)){kt=!0;const Ao=qe.reduce((Oe,wt)=>Oe+(wt||0),0),it=qe.filter(Oe=>Oe===null).length,oi=it>0?Math.max(0,100-Ao)/it:100/Be.length,Ti=qe.map(Oe=>Oe!==null?Oe:oi),Id=Ti.reduce((Oe,wt)=>Oe+wt,0)||1,Ai=Ti.map(Oe=>Oe/Id*100);if(Ai.length===2){const[Oe]=Ai;if(Oe>=48&&Oe<=52)Re="1:1";else if(Oe>=31&&Oe<=35)Re="1:2";else if(Oe>=65&&Oe<=69)Re="2:1";else if(Oe>=28&&Oe<=32)Re="3:7";else if(Oe>=68&&Oe<=72)Re="7:3";else if(Oe>=38&&Oe<=42)Re="4:6";else if(Oe>=58&&Oe<=62)Re="6:4";else{const wt=Math.round(Oe);Re=`${wt}:${100-wt}`}}else if(Ai.length===3){const[Oe,wt,Mo]=Ai;if(Oe>=31&&Oe<=35&&wt>=31&&wt<=35&&Mo>=31&&Mo<=35)Re="1:1:1";else if(Oe>=23&&Oe<=27&&wt>=48&&wt<=52&&Mo>=23&&Mo<=27)Re="1:2:1";else if(Oe>=48&&Oe<=52&&wt>=23&&wt<=27&&Mo>=23&&Mo<=27)Re="2:1:1";else if(Oe>=23&&Oe<=27&&wt>=23&&wt<=27&&Mo>=48&&Mo<=52)Re="1:1:2";else{const Br=Math.round(Oe),Lr=Math.round(wt);Re=`${Br}:${Lr}:${100-Br-Lr}`}}else Re=Ai.map(Oe=>Math.round(Oe)).join(":")}else kt=!1,Re=Array.from({length:We},()=>1).join(":");const cn=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Re,isCustomWidth:kt,recommendedLayout:cn}}function z(te){if(!(te!=null&&te.blocks))return null;for(const ge of te.blocks){const Be=ge.rawNode;if(Be&&ut(Be)&&ro(Be)){const qe=Ii(Be).length,Re=xr(Be);return{hasSuperBlock:!0,colCount:qe,ratio:Re||Array.from({length:qe},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:qe>=2?"cols-header":"two-cols"}}}return null}const ne=ye(()=>{var te;if(typeof document<"u"){const ge=s.value;if(ge){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(We){const qe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(qe){const Re=Ce(qe);if(Re)return Re}}}const Be=f.value||(_.value?s.value:"");if(Be){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Be}"]`);if(We){let qe=We.nextElementSibling;for(;qe&&!(qe.getAttribute("data-type")==="NodeThematicBreak"||(te=qe.classList)!=null&&te.contains("protyle-wysiwyg__block--hr"));){const Re=qe.getAttribute("data-type")==="NodeSuperBlock"?qe:qe.querySelector('[data-type="NodeSuperBlock"]');if(Re){const kt=Ce(Re);if(kt)return kt}qe=qe.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),qe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of qe)if(!We||Re.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const kt=Ce(Re);if(kt)return kt}}}return z(E.value)}),L=ye(()=>{var te;return((te=ne.value)==null?void 0:te.ratio)||""}),U=ye(()=>{const te=a.value||"";if(te==="NodeSuperBlock"||te==="s"||te==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),w=ye(()=>{var te;return((te=E.value)==null?void 0:te.pageIndex)||1}),q=ye(()=>!!r.value[Fe]);function H(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!te)return!1;const ge=te.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const I=ye(()=>{var ge;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(d.value&&H())return m.value||"";if(d.value)return"";const te=s.value;if(te&&((ge=E.value)!=null&&ge.blocks)){const Be=E.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.clicks)return Be.clicks}return""}),A=ye(()=>{var ge;if(r.value[Et])return r.value[Et];const te=s.value;if(te&&((ge=E.value)!=null&&ge.blocks)){const Be=E.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.motion)return typeof Be.motion=="string"?Be.motion:JSON.stringify(Be.motion)}return""}),O=ye(()=>{var ge;if(r.value[Te])return r.value[Te];const te=s.value;if(te&&((ge=E.value)!=null&&ge.blocks)){const Be=E.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.slot)return Be.slot}return""}),G=pe(""),K=pe(""),Y=ye(()=>r.value[Yo]==="true"),ee=ye(()=>r.value[Mn]==="true"),ce=ye(()=>r.value[ai]==="true"),se=ye(()=>r.value[En]!=="false"),me=ye(()=>{var te,ge;return((ge=(te=y.value)==null?void 0:te.config)==null?void 0:ge.theme)||r.value[Vi]||"apple-basic"}),_e=ye(()=>{var te,ge;return((ge=(te=y.value)==null?void 0:te.config)==null?void 0:ge.aspectRatio)||r.value[Ki]||"16/9"}),we=ye(()=>{var te,ge;return((ge=(te=y.value)==null?void 0:te.config)==null?void 0:ge.defaultTransition)||r.value[Gi]||"slide-left"}),De=ye(()=>{var te,ge;return((ge=(te=y.value)==null?void 0:te.config)==null?void 0:ge.spacing)||r.value[Es]||"normal"}),He=ye(()=>{var te,ge;return((ge=(te=y.value)==null?void 0:te.config)==null?void 0:ge.background)||r.value[An]||""}),Ge=ye(()=>{var qe,Re;if((r.value[Ze]||r.value["slides-role"])===Va||r.value[ct]==="true")return"background";const ge=r.value[be]||r.value["slides-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Be=l.value||"",We=xo(Be);if(We&&((Re=(qe=E.value)==null?void 0:qe.frontmatter)!=null&&Re.background)){const kt=E.value.frontmatter.background;if(kt===We||kt.endsWith(We)||We.endsWith(kt))return"background"}return""}),rt=ye(()=>!!(r.value[Ne]||r.value[Et]||r.value[Te]||r.value[ei]||r.value[Fe]||r.value["slides-note"]||r.value[Ze]||r.value[be]||r.value[Yo]||r.value[Mn]||r.value[ai]||r.value[En])),{saveAttr:Pe,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ye,resetSuperBlockWidth:fe,saveDocAttr:he,onToggleVideoAutoplay:Qe,onToggleVideoLoop:at,onToggleVideoMuted:$t,onToggleVideoControls:lt,onImageRoleChange:co,onToggleNoteBlock:Hc,onAddNoteBlock:Fc,onLocateNoteBlock:jc,onGenerateNotesWithAI:Uc,isGeneratingNotes:Wc,isBatchProcessing:ln,onBatchDeleteNotes:qc,onAddOrIdentifyNotesBlocks:Vc,onAutoAnimateDocument:Kc,onClearAnimationsDocument:Gc,toggleElemClick:Yc,onElemClickStepChange:Zc,onElemMotionChange:Jc,onElemSlotChange:Xc,onElemShikiLinesChange:Qc,onElemMaxHeightChange:ed,onSetTwoColsContrast:td,onClearBlockAttrs:od,onInsertDividerBefore:id,onInsertDividerAfter:$r,onDeleteCurrentBlock:nd,onConvertToSuperBlock:Tr,onExportHtml:sd,onExportPdf:rd}=l2({activeBlockId:s,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:p,parentContainerId:d,parentContainerClicks:m,latestDoc:y,targetSlide:E,currentSlideNoteBlockId:F,currentSlideLayout:V,isNoteBlock:q,elemClick:I,videoAutoplay:Y,videoLoop:ee,videoMuted:ce,videoControls:se,pageBackground:W,pageImage:$,elemShikiLines:G,elemMaxHeight:K,saveStatus:g,plugin:o}),rs=pe(!1);function To(){rs.value=Hw(s.value,a.value)}ti(()=>{typeof document<"u"&&(document.addEventListener("selectionchange",To),document.addEventListener("mouseup",To),document.addEventListener("keyup",To)),To()}),sn(()=>{typeof document<"u"&&(document.removeEventListener("selectionchange",To),document.removeEventListener("mouseup",To),document.removeEventListener("keyup",To))}),Ho([s,a],()=>{To()});async function ad(te){if(te==="clover"){if(!await Ye())return}else ft(be,te)}function ld(te){ft(yt,te)}async function cd(te){await ft(ci,te),(te==="clockwise"||te==="counter-clockwise"||te==="cw"||te==="ccw")&&(!Se.value||Se.value==="1:1")&&await ft(Jo,"1:1:1:1")}function dd(te){ft(Jo,te)}function ud(te){ft(di,te)}function fd(te){ft(ui,te)}function Ar(te){if(!te)return;const ge=te.recommendedLayout||(te.colCount&&te.colCount>=2?"cols-header":"two-cols"),Be=te.ratio||(te.colCount?Array(te.colCount).fill(1).join(":"):"1:1");tt(ge,Be)}function hd(te){ft(yt,te)}async function pd(){await fe()}function md(te){Pe(Ct,te)}function gd(te){$.value=te,Pe(qt,te)}function yd(te){Pe(Oi,te==="inherit"?"":te)}function bd(te){he(Vi,te)}function vd(te){he(An,te)}function kd(te){he(Ki,te)}function wd(te){he(Gi,te)}function xd(te){he(Es,te)}function Mr(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function Sd(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}let as=!1;function Er(){if(!as){as=!0;try{o&&typeof o.openSetting=="function"?o.openSetting():o&&o.setting&&typeof o.setting.open=="function"&&o.setting.open(o.name||"siyuan-live-slides")}finally{setTimeout(()=>{as=!1},500)}}}function Cd(){o&&Ot("aiScript")&&Dc(o)}async function _d(){if(o&&Ot("aiScript")){if(ln.value)return;ln.value=!0;try{await Nc(o)}finally{ln.value=!1}}}return t({setActiveBlock(te){s.value=te.id,a.value=te.type,r.value={...te.attrs},l.value=te.content||te.markdown||"",u.value=te.topBlockId||te.id,f.value=te.pageDividerId||"",p.value=te.pageDividerLayout||"",d.value=te.parentContainerId||"",b.value=te.parentContainerSlot||"",m.value=te.parentContainerClicks||"",te.rootId?c.value=te.rootId:(te.type==="doc"||te.type==="NodeDocument")&&te.id&&(c.value=te.id),W.value=te.attrs[ct]||"",$.value=te.attrs[qt]||"",G.value=te.attrs[ei]||"",K.value=te.attrs[Yi]||"",k.value=!!te.isImage},updateDocument(te){y.value=te,c.value=te.docId},openImportDialog(){i.value=!0},setCurrentDocId(te){c.value=te}}),(te,ge)=>(J(),X("div",f2,[h("div",h2,[h("div",p2,[(J(),X("svg",m2,[...ge[2]||(ge[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=h("span",null,"演示配置",-1))]),h("div",g2,[ue(Ot)("import")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Be=>i.value=!0)},[le(de,{name:"import"}),ge[4]||(ge[4]=h("span",null,"导入",-1))])):Ae("",!0),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Mr},[le(de,{name:"split-preview"}),ge[5]||(ge[5]=h("span",null,"分屏预览",-1))])])]),h("div",y2,[h("div",b2,[h("span",{class:xe(["spm-target-tag",N.value])},ve(B.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":v.value||"点击复制 ID: "+(s.value||c.value),onClick:x},[le(de,{name:"copy"}),h("span",null,"#"+ve(R.value),1)],8,v2)]),g.value?(J(),X("span",k2,"● "+ve(g.value),1)):Ae("",!0)]),j.value?(J(),X("div",{key:0,class:"spm-context-quote",title:l.value},ve(j.value),9,w2)):Ae("",!0),h("div",x2,[_.value?(J(),Vt(Ev,{key:0,"page-layout":S.value,"page-layout-ratio":ue(oe),"page-mask":ue(ae),"page-mask-ratio":ue(Se),"page-mask-style":ue($e),"page-mask-initial":ue(ke),"detected-sb-ratio":L.value,"detected-sb-info":ne.value,"page-transition":Z.value,"page-spacing":M.value,"page-image":$.value,"page-notes":Q.value,"page-index":w.value,"is-generating-notes":ue(Wc),"can-convert-to-super-block":rs.value,"onUpdate:pageLayout":ad,"onUpdate:pageLayoutRatio":ld,"onUpdate:pageMask":cd,"onUpdate:pageMaskRatio":dd,"onUpdate:pageMaskStyle":ud,"onUpdate:pageMaskInitial":fd,onApplySuperBlockLayout:Ar,onResetSuperblockRatio:pd,"onUpdate:pageTransition":md,"onUpdate:pageSpacing":yd,"onUpdate:pageImage":gd,onAddNoteBlock:ue(Fc),onLocateNoteBlock:ue(jc),onGenerateNotes:ue(Uc),onOpenSetting:Er,onInsertDividerAfter:ue($r),onDeleteDivider:ue(nd),onConvertToSuperBlock:ue(Tr)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","is-generating-notes","can-convert-to-super-block","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider","onConvertToSuperBlock"])):s.value&&!P.value?(J(),Vt(d0,{key:1,"elem-click":I.value,"elem-motion":A.value,"elem-slot":O.value,"elem-shiki-lines":G.value,"elem-max-height":K.value,"is-code-block":T.value,"is-image":C.value,"is-video":D.value,"is-super-block":U.value,"detected-sb-info":ne.value,"video-autoplay":Y.value,"video-loop":ee.value,"video-muted":ce.value,"video-controls":se.value,"has-block-attrs":rt.value,"is-note":q.value,"image-role":Ge.value,"current-slide-layout":V.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":d.value,"can-convert-to-super-block":rs.value,onToggleNote:ue(Hc),onToggleElemClick:ue(Yc),onToggleVideoAutoplay:ue(Qe),onToggleVideoLoop:ue(at),onToggleVideoMuted:ue($t),onToggleVideoControls:ue(lt),"onUpdate:imageRole":ue(co),"onUpdate:elemClick":ue(Zc),"onUpdate:elemMotion":ue(Jc),"onUpdate:elemSlot":ue(Xc),"onUpdate:elemShikiLines":ue(Qc),"onUpdate:elemMaxHeight":ue(ed),onApplySuperBlockLayout:Ar,onApplySuperBlockRatio:hd,onInsertDividerBefore:ue(id),onInsertDividerAfter:ue($r),onSetTwoColsContrast:ue(td),onClearBlockAttrs:ue(od),onConvertToSuperBlock:ue(Tr)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","can-convert-to-super-block","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs","onConvertToSuperBlock"])):(J(),Vt(Pk,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":_e.value,"doc-default-transition":we.value,"doc-spacing":De.value,"is-batch-processing":ue(ln),"onUpdate:docTheme":bd,"onUpdate:docBackground":vd,"onUpdate:docAspectRatio":kd,"onUpdate:docDefaultTransition":wd,"onUpdate:docSpacing":xd,onOpenBottomPreview:Mr,onOpenPresenter:Sd,onAddOrIdentifyNotes:ue(Vc),onClearNotes:ue(qc),onAutoAnimate:ue(Kc),onClearAnimations:ue(Gc),onAiAutoSplit:Cd,onClearDividers:_d,onExportHtml:ue(sd),onExportPdf:ue(rd),onOpenSetting:Er},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&ue(Ot)("import")?(J(),Vt(zw,{key:1,onClose:ge[1]||(ge[1]=Be=>i.value=!1),onSuccess:n})):Ae("",!0)]))}}),C2=2e3,_2=600;function I2(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function $s(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Pa(e))return!0;const t=e.firstElementChild;return!!(t&&Pa(t))}function Pa(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function $2(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class T2{constructor(){Ie(this,"consumers",new Map);Ie(this,"seq",0);Ie(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=$2(),a={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(a.observer=new s(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(o)):a.visible=$s(o),this.consumers.set(n,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?$s(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!I2(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&$s(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},C2))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const In=new T2,$i=new ns;function Oc(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=In.register(e,t,i);return i(),n}let No=null,jt=null,$n=null;function A2(){return jt}function M2(e,t){No&&Pc(),No=vr(Zg),No.provide("plugin",t),No.provide("sandboxBridge",$i);const o=No.mount(e);return jt=o,$n=Oc("preview",e,t),o}function Pc(e){$n&&($n(),$n=null),No&&(No.unmount(),No=null,jt=null)}function E2(){return jt!==null}let Oo=null,Zo=null;function B2(e,t){return Oo&&Rc(),Oo=vr(rb),Oo.provide("plugin",t),Oo.provide("sandboxBridge",$i),Zo=Oo.mount(e),Zo}function Rc(e){Oo&&(Oo.unmount(),Oo=null,Zo=null)}function L2(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||Uo()}}),o.close()}catch{}}let Po=null,Pt=null,Tn=null;function D2(e,t){Po&&zc(),Po=vr(S2),Po.provide("plugin",t),Po.provide("sandboxBridge",$i);const o=Po.mount(e);return Pt=o,Tn=Oc("dock",e,t),o}function zc(e){Tn&&(Tn(),Tn=null),Po&&(Po.unmount(),Po=null,Pt=null)}function N2(e,t){Pt!=null&&Pt.updateDocument&&Pt.updateDocument(e),jt!=null&&jt.updateDocument?jt.updateDocument(e,t):($i.updateSlides(e.slides,e.config),L2(e)),Zo!=null&&Zo.updateDocument&&Zo.updateDocument(e)}function Xs(e){jt!=null&&jt.navigateToBlock?jt.navigateToBlock(e):$i.highlightElement(e)}function ri(e){Pt!=null&&Pt.setActiveBlock&&Pt.setActiveBlock(e)}function O2(){return Do("import")?!1:Pt!=null&&Pt.openImportDialog?(Pt.openImportDialog(),!0):!1}const P2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:mo,value:"true"},{key:be,value:"cover"},{key:Ct,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:mo,value:"true"},{key:be,value:"two-cols"},{key:Ct,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:mo,value:"true"},{key:be,value:"fact"},{key:Ct,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:mo,value:"true"},{key:be,value:"intro"},{key:Ct,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:mo,value:"true"},{key:be,value:"quote"},{key:Ct,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Te,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:ei,value:"1-3"}]}];class Ts{getPresetTemplates(){return P2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Ct}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${Ct}' AND value = '${t}'`,a=await i(s);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[Ct]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,a=await i(s);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function R2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),Do("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{O2()||ie.showMessage("请先在右侧栏打开「即现配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ie.showMessage("已为当前文档初始化即现属性"),e.compileCurrentDocument(e.currentDocId))}}),Do("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>Dc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>Nc(e)})),Do("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var n,s,a,r;if(!e.currentDocId){const l=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(l==null?void 0:l.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}ie.showMessage("正在调用 AI 提炼演讲者口播提词...");const o=await Si(e.currentDocId).catch(()=>[]),i={pageIndex:1,startBlockId:e.currentDocId,frontmatter:{},notes:"",blocks:o.map(l=>({id:l.id,type:l.type,content:l.content||"",rawMarkdown:l.markdown||""})),rawMarkdown:""};try{const l=await Zw(i,ss);if(!l){ie.showMessage("AI 未返回可用的提词内容",5e3,"error");return}const u=`> [!NOTE] 💡 演讲备注
${l.split(/\r?\n/).map(d=>`> ${d}`).join(`
`)}
{: custom-slides-note="true"}`,f=await bn("markdown",u,e.currentDocId).catch(()=>null),p=((a=(s=(n=f==null?void 0:f[0])==null?void 0:n.doOperations)==null?void 0:s[0])==null?void 0:a.id)||((r=f==null?void 0:f[0])==null?void 0:r.id);p&&(await ze(p,{"custom-slides-note":"true"}),Ee.setBlockAttrOverride(p,{"custom-slides-note":"true"}),Ro(p,e.app)),ie.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}catch(l){ie.showMessage(`AI 提词生成失败: ${(l==null?void 0:l.message)||l}`,6e3,"error")}}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Bc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Lc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new Ts,o=t.buildTransitionStatsSql(),i=await vi(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);ie.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new Ts().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),ie.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ie.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new Ts().batchUpdateTransitions("fade","slide-left",i=>vi(i).catch(()=>[]),(i,n)=>ze(i,n));ie.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),Do("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!Do("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ie.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await zo(o,e.currentDocId,e),n=await vc(o,{title:i,onProgress:(s,a)=>{ie.showMessage(`正在导出幻灯片图片 (${s} / ${a})...`,2e3)}});n.success?ie.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):ie.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class z2{constructor(t=400){Ie(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function H2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class F2{constructor(t=150){Ie(this,"lastBlockId","");Ie(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class j2{constructor(){Ie(this,"attrCache",new z2);Ie(this,"compiledIalIndex",{doc:null,map:new Map});Ie(this,"locatingLockUntil",0);Ie(this,"lockedTargetBlockId","");Ie(this,"lastKnownPageDividerId","");Ie(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Ee.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const a=await er(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:H2(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),a=s==null?void 0:s.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),a=s==null?void 0:s.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=a==null?void 0:a.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);ri({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Xs(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,f,p;if(!t){qi();const d=typeof s=="number"&&s>0?s:1,b=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(b){const m=b.startBlockId||"",y=((f=b.frontmatter)==null?void 0:f.layout)||"",g={"custom-slides-layout":y,...b.frontmatter};return ri({id:m,rootId:i,type:"NodeThematicBreak",attrs:g,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y}),this.resolveBlockAttrs(m,n).then(v=>{v&&Object.keys(v).length>0&&ri({id:m,rootId:i,type:"NodeThematicBreak",attrs:{...g,...v},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Ro(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,i,n);else{let d="",b="";if(n!=null&&n.slides){const m=n.slides.find(y=>{var g,v,x;return y.startBlockId===t||((g=y.blocks)==null?void 0:g.some(_=>_.id===t))||((v=y.allBlockIds)==null?void 0:v.includes(t))||((x=y.noteBlocks)==null?void 0:x.some(_=>_.id===t))});m!=null&&m.startBlockId&&(d=m.startBlockId),(p=m==null?void 0:m.frontmatter)!=null&&p.layout&&(b=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(d&&!b){const y=Ee.getBlockAttrOverride(d);if(y!=null&&y[be]||y!=null&&y["custom-slides-layout"])b=y[be]||y["custom-slides-layout"]||"";else{const g=await this.resolveBlockAttrs(d,n);b=g[be]||g["custom-slides-layout"]||"",g&&Object.keys(g).length>0&&Ee.setBlockAttrOverride(d,g)}}ri({id:t,rootId:i,type:l||"NodeParagraph",attrs:m||{},pageDividerId:d,pageDividerLayout:b})}).catch(()=>{})}return a}async syncInspectorBlock(t,o,i,n,s){var Z,W,$,M,E,Q,F,V,re;if(this.isLocatingLocked(o))return;let a=t,r=o,l=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const ae=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{};({...ae,...Se})[Fe]&&(a=c,r=oe,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,p=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((Z=u==null?void 0:u.classList)!=null&&Z.contains("hr")),d=l==="NodeCodeBlock",b=((W=a.innerText)==null?void 0:W.trim())||"",m=await this.resolveBlockAttrs(r,s),y=Ee.getBlockAttrOverride(r)||{},g={...m,...y};let v="",x="";if(p)v=r,x=g[be]||g["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const ae=oe.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||($=oe.classList)!=null&&$.contains("hr")){v=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,f];let ae=a.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const $e=ae.getAttribute("data-node-id");$e&&!oe.includes($e)&&oe.push($e),ae=ae.parentElement}const Se=s.slides.find($e=>{var ke,Ce,z;return oe.includes($e.startBlockId)||((ke=$e.blocks)==null?void 0:ke.some(ne=>oe.includes(ne.id)))||((Ce=$e.allBlockIds)==null?void 0:Ce.some(ne=>oe.includes(ne)))||((z=$e.noteBlocks)==null?void 0:z.some(ne=>oe.includes(ne.id)))});Se&&(!v&&Se.startBlockId&&(v=Se.startBlockId),!x&&((M=Se.frontmatter)!=null&&M.layout)&&(x=Se.frontmatter.layout))}if(v?(this.lastKnownDocId=n,this.lastKnownPageDividerId=v):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((E=u.parentElement)==null?void 0:E.scrollTop)||0)===0||(v=this.lastKnownPageDividerId)),v){const oe=Ee.getBlockAttrOverride(v);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(x=oe[be]||oe["custom-slides-layout"]||""),!x&&(s!=null&&s.slides)){const ae=s.slides.find(Se=>Se.startBlockId===v);(Q=ae==null?void 0:ae.frontmatter)!=null&&Q.layout&&(x=ae.frontmatter.layout)}if(!x){const ae=await this.resolveBlockAttrs(v,s);x=ae[be]||ae["custom-slides-layout"]||"",ae&&Object.keys(ae).length>0&&Ee.setBlockAttrOverride(v,ae)}et(v,{[be]:x||""})}else if(n){const oe=Ee.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?x=oe[be]||oe["custom-slides-layout"]||"":!x&&((re=(V=(F=s==null?void 0:s.slides)==null?void 0:F[0])==null?void 0:V.frontmatter)!=null&&re.layout)&&(x=s.slides[0].frontmatter.layout)}const _=a.getAttribute(be)||a.getAttribute("custom-slides-layout"),T=g[be]||g["custom-slides-layout"]||"";_&&_!==T&&et(r,{[be]:T});const k=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=g[Ze]||g["custom-slides-role"]||"";k&&k!==C&&et(r,{[Ze]:C});let D="",P="",R="";const j=a.closest('[data-type="NodeListItem"]');if(j&&j!==a){const oe=j.getAttribute("data-node-id");if(oe){D=oe;const ae=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{},$e={...ae,...Se};P=$e[Te]||"",R=$e[Ne]||"";const ke=$e[be]||$e["custom-slides-layout"]||"",Ce=j.getAttribute(be)||j.getAttribute("custom-slides-layout");Ce&&Ce!==ke&&et(oe,{[be]:ke});const z=$e[Ze]||$e["custom-slides-role"]||"",ne=j.getAttribute(Ze)||j.getAttribute("custom-slides-role");ne&&ne!==z&&et(oe,{[Ze]:z})}}const B=!!a.querySelector("img, span[data-type='img']"),N=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),S=B&&N.length<=50;ri({id:r,rootId:n,type:l,content:b,attrs:g,isDivider:p,isCode:d,isImage:S,topBlockId:f,pageDividerId:v,pageDividerLayout:x,parentContainerId:D,parentContainerSlot:P,parentContainerClicks:R})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},a={};for(const r of Object.keys(n))r in s||(a[r]="");for(const[r,l]of Object.entries(s))a[r]=String(l??"");et(i.id,a),Ee.setBlockAttrOverride(i.id,a)}}}}purgeStaleDomSlidesAttrs(t){var n,s,a;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(l[be]=r.frontmatter.layout),o.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=o.get(l.id)||{};(s=l.ial)!=null&&s[be]&&(c[be]=l.ial[be]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&o.set(l.id,c)}}}const i=Ee.getAllAttrOverrides();for(const[r,l]of i.entries()){const c=o.get(r)||{};l[be]!==void 0&&(c[be]=l[be]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),o.set(r,c)}jw(o)}}const Eo=new j2;class U2{constructor(){Ie(this,"state","IDLE");Ie(this,"inFlightDocId",null);Ie(this,"pendingDocs",new Set);Ie(this,"lastPendingDocId",null);Ie(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}function W2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200"),e.style.width="100%",e.style.height="auto",e.style.minHeight="0",e.style.flex="none",e.style.alignSelf="stretch";const t=e.parentElement,o=e.closest(".config-item, .config__item, .b3-label")||t,i=(o==null?void 0:o.querySelector(":scope > .fn__flex-1, :scope > .fn__block, :scope .config-name, :scope .fn__flex-1"))||(o==null?void 0:o.querySelector(".config-name, .fn__flex-1")),n=o==null?void 0:o.querySelector(".fn__space");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-item"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="stretch",o.style.flexDirection="column"),t instanceof HTMLElement&&t!==o&&(t.classList.add("slides-settings__host-block"),t.style.width="100%",t.style.height="auto",t.style.minHeight="0"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left"),n instanceof HTMLElement&&(n.style.display="none")}function q2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200","fn__block");const t=e.matches(".b3-switch")?e:e.querySelector(".b3-switch");t&&t.classList.remove("fn__flex-center","fn__size200","fn__block");const o=e.closest(".config-item, .config__item, .b3-label")||e.parentElement,i=o==null?void 0:o.querySelector(":scope > .fn__flex-1, .config-name");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-row"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="center"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left")}function V2(e,t,o){if(!e||typeof e.open!="function")return;const i=e.open.bind(e),n=()=>{t.forEach(s=>W2(s)),o.forEach(s=>q2(s))};e.open=(s=>{i(s),n(),typeof setTimeout=="function"&&setTimeout(()=>{n()},0)})}function yn(e){const t=document.createElement("div");return t.className="slides-settings__switch-wrap",t.style.cssText="display: inline-flex; align-items: center; justify-content: flex-end;",t.appendChild(e),t}const Ra='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.25 12s3.75-6.75 9.75-6.75S21.75 12 21.75 12 18 18.75 12 18.75 2.25 12Z"/><circle cx="12" cy="12" r="3.25"/></svg>',K2='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.7 5.52A10.56 10.56 0 0 1 12 5.25c6 0 9.75 6.75 9.75 6.75a18.78 18.78 0 0 1-4.02 4.85M6.68 6.69C4.04 8.42 2.25 12 2.25 12s3.75 6.75 9.75 6.75c1.85 0 3.47-.64 4.85-1.55M9.88 9.88A3 3 0 0 0 9 12a3 3 0 0 0 3 3c.8 0 1.53-.31 2.07-.82"/></svg>';function G2(e){const t=new ie.Setting({width:"680px"}),o=Fo();let i=fh();const n=document.createElement("div");n.className="slides-settings__ai-panel",n.style.cssText="display: flex; flex-direction: column; gap: 12px; width: 100%; text-align: left; box-sizing: border-box;";const s=document.createElement("div");s.className="slides-settings__tip-container",s.style.cssText="width: 100%; text-align: left;",n.appendChild(s);function a($){var M,E;if(s.innerHTML="",$){const Q=document.createElement("div");Q.className="api-switch-managed-tip",Q.style.cssText=`
        background-color: var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08));
        border: 1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2));
        border-radius: 6px;
        padding: 8px 12px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--b3-theme-on-background);
        text-align: left;
      `;const F=((E=(M=window.siyuan)==null?void 0:M.config)==null?void 0:E.lang)==="en_US",V=$.profileName||(F?"Unnamed":"未命名");Q.innerHTML=F?`💡 General AI API is managed by <strong>API Switch (siyuan-api-switch)</strong> (Profile: ${V}). Related inputs are read-only. Please configure in the API Switch panel.`:`💡 通用 AI API 已由 <strong>API 旋钮 (siyuan-api-switch)</strong> 接管 (Profile: ${V})。相关输入框已置灰只读，如需修改请前往 API 旋钮面板。`,s.appendChild(Q)}}a(i);function r($,M,E){const Q=document.createElement("div");Q.className="slides-settings__field-row",Q.style.cssText="display: flex; flex-direction: column; gap: 4px; width: 100%; text-align: left;";const F=document.createElement("div");F.className="slides-settings__field-main",F.style.cssText="display: flex; align-items: center; justify-content: space-between; gap: 16px; width: 100%;";const V=document.createElement("span");if(V.className="slides-settings__field-label",V.style.cssText="font-size: 13px; font-weight: 500; min-width: 160px; color: var(--b3-theme-on-background); text-align: left; flex-shrink: 0;",V.textContent=$,F.appendChild(V),F.appendChild(M),Q.appendChild(F),E){const re=document.createElement("span");re.className="slides-settings__field-desc",re.style.cssText="font-size: 11px; color: var(--b3-theme-on-surface); line-height: 1.4; text-align: left;",re.textContent=E,Q.appendChild(re)}return Q}const l=document.createElement("input");l.className="b3-text-field fn__flex-1",l.placeholder="https://api.openai.com/v1",l.dataset.settingKey="ai-base-url",l.value=i?i.baseUrl:o.aiConfig.baseUrl,l.disabled=!!i,l.addEventListener("change",async()=>{const $=l.value.trim();await W({baseUrl:$})});const c=document.createElement("div");c.className="slides-settings__api-key-wrap",c.style.cssText="position: relative; display: flex; align-items: center; width: 100%; flex: 1;";const u=document.createElement("input");u.className="b3-text-field slides-settings__api-key-input fn__flex-1",u.type="password",u.placeholder="sk-...",u.dataset.settingKey="ai-api-key",u.style.cssText="width: 100%; padding-right: 36px; box-sizing: border-box;",u.value=i?i.apiKey:o.aiConfig.apiKey,u.disabled=!!i,u.addEventListener("change",async()=>{const $=u.value.trim();await W({apiKey:$})});let f=!1;const p=document.createElement("button");p.className="slides-settings__api-key-toggle",p.type="button",p.innerHTML=Ra,p.title="显示 API Key",typeof p.setAttribute=="function"&&p.setAttribute("aria-label","显示 API Key"),p.disabled=!!i,p.addEventListener("click",()=>{f=!f,u.type=f?"text":"password",p.innerHTML=f?K2:Ra,p.title=f?"隐藏 API Key":"显示 API Key",typeof p.setAttribute=="function"&&p.setAttribute("aria-label",f?"隐藏 API Key":"显示 API Key")}),c.appendChild(u),c.appendChild(p);const d=document.createElement("input");d.className="b3-text-field fn__flex-1",d.placeholder="gpt-4o-mini / deepseek-chat",d.dataset.settingKey="ai-model",d.value=i?i.model:o.aiConfig.model,d.disabled=!!i,d.addEventListener("change",async()=>{const $=d.value.trim();await W({model:$})});const b=document.createElement("details");b.style.cssText="margin-top: 4px; font-size: 12px;";const m=document.createElement("summary");m.style.cssText="cursor: pointer; color: var(--b3-theme-primary); font-weight: 500; padding: 4px 0;",m.textContent="高级模型参数 (超时/采样温度/Token)",b.appendChild(m);const y=document.createElement("div");y.className="slides-settings__advanced-body",y.style.cssText="display: flex; flex-direction: column; gap: 8px; padding-top: 8px; text-align: left; width: 100%;";const g=document.createElement("input");g.className="b3-text-field fn__flex-1",g.type="number",g.dataset.settingKey="ai-timeout",g.value=String((i==null?void 0:i.requestTimeoutSeconds)??o.aiConfig.requestTimeoutSeconds??mt.requestTimeoutSeconds),g.disabled=!!i,g.addEventListener("change",async()=>{const $=Number.parseInt(g.value,10)||mt.requestTimeoutSeconds;await W({requestTimeoutSeconds:$})});const v=document.createElement("input");v.className="b3-text-field fn__flex-1",v.type="number",v.step="0.1",v.dataset.settingKey="ai-temperature",v.value=String((i==null?void 0:i.temperature)??o.aiConfig.temperature??mt.temperature),v.disabled=!!i,v.addEventListener("change",async()=>{const $=Number.parseFloat(v.value)||mt.temperature;await W({temperature:$})});const x=document.createElement("input");x.className="b3-text-field fn__flex-1",x.type="number",x.dataset.settingKey="ai-max-tokens",x.value=String((i==null?void 0:i.maxTokens)??o.aiConfig.maxTokens??mt.maxTokens),x.disabled=!!i,x.addEventListener("change",async()=>{const $=Number.parseInt(x.value,10)||mt.maxTokens;await W({maxTokens:$})}),y.appendChild(r("请求超时时间 (秒)",g)),y.appendChild(r("采样温度 (Temperature)",v,"范围 0.0 - 2.0，数值越高越富有创意")),y.appendChild(r("单次最大输出 Token",x)),b.appendChild(y);const _=document.createElement("div");_.className="slides-settings__test-row",_.style.cssText="display: flex; align-items: center; gap: 12px; margin-top: 8px; text-align: left; width: 100%;";const T=document.createElement("button");T.className="b3-button b3-button--outline",T.type="button",T.textContent="测试连接";const k=document.createElement("span");k.className="slides-settings__test-status",k.style.cssText="font-size: 12px; color: var(--b3-theme-on-surface); flex: 1; word-break: break-all; text-align: left;",T.addEventListener("click",async()=>{const $=i||{baseUrl:l.value.trim(),apiKey:u.value.trim(),model:d.value.trim(),requestTimeoutSeconds:Number.parseInt(g.value,10)||15,temperature:Number.parseFloat(v.value)||.7,maxTokens:10};if(!Un($)){k.style.color="var(--b3-theme-error, #f44336)",k.textContent="请先填写完整的 Base URL、API Key 与 Model";return}T.disabled=!0,k.style.color="var(--b3-theme-primary)",k.textContent="正在发起测试请求...";const M=await Yw($);T.disabled=!1,M.success?(k.style.color="var(--b3-theme-primary, #4caf50)",k.textContent=M.message):(k.style.color="var(--b3-theme-error, #f44336)",k.textContent=M.message)}),_.appendChild(T),_.appendChild(k),n.appendChild(r("API 基础地址 (Base URL)",l)),n.appendChild(r("API 鉴权密钥 (API Key)",c)),n.appendChild(r("模型名称 (Model)",d)),n.appendChild(b),n.appendChild(_),t.addItem({title:"AI 演讲提词服务",direction:"row",description:"配置兼容 OpenAI API 的大模型服务，用于提炼演讲口播提词卡 (Notes)。支持被「API 旋钮」集中调度接管。",actionElement:n});const C=document.createElement("input");C.className="b3-switch fn__flex-center",C.type="checkbox",C.checked=o.enableWebServeJump,C.addEventListener("change",async()=>{const $=C.checked;D.disabled=!$,pt({enableWebServeJump:$}),await e.saveGlobalSettings({enableWebServeJump:$})});const D=document.createElement("input");D.className="b3-text-field fn__size200",D.value=o.webServeUrl,D.placeholder="http://127.0.0.1:6806",D.disabled=!o.enableWebServeJump,D.addEventListener("change",async()=>{const $=D.value.trim()||bo.webServeUrl;pt({webServeUrl:$}),await e.saveGlobalSettings({webServeUrl:$})});const P=yn(C);t.addItem({title:"启用网络伺服链接外跳",description:"开启后，幻灯片中的思源块引用链接可以点击以外部网络伺服抽屉呈现",actionElement:P}),t.addItem({title:"伺服主机地址",description:"思源笔记桌面端 WebServe 伺服地址 (如 http://127.0.0.1:6806)",actionElement:D});const R=document.createElement("input");R.className="b3-switch fn__flex-center",R.type="checkbox",R.checked=o.normalizeHeadingSizes,R.addEventListener("change",async()=>{const $=R.checked;pt({normalizeHeadingSizes:$}),await e.saveGlobalSettings({normalizeHeadingSizes:$})});const j=document.createElement("input");j.className="b3-switch fn__flex-center",j.type="checkbox",j.checked=o.showUnorderedListMarkers,j.addEventListener("change",async()=>{const $=j.checked;pt({showUnorderedListMarkers:$}),await e.saveGlobalSettings({showUnorderedListMarkers:$})});const B=document.createElement("input");B.className="b3-switch fn__flex-center",B.type="checkbox",B.checked=o.showOrderedListMarkers,B.addEventListener("change",async()=>{const $=B.checked;pt({showOrderedListMarkers:$}),await e.saveGlobalSettings({showOrderedListMarkers:$})});const N=yn(R),S=yn(j),Z=yn(B);t.addItem({title:"固定特定标题大小",description:"开启后限制正文大标题在幻灯片中不超出安全展示画幅",actionElement:N}),t.addItem({title:"无序列表圆点前缀标记",description:"开启后在无序列表项前展示圆点前缀标记",actionElement:S}),t.addItem({title:"有序列表数字序号标记",description:"开启后在有序列表项前展示数字序号标记",actionElement:Z}),V2(t,[n],[P,D,N,S,Z]);async function W($){const M=Fo().aiConfig,E=bi({...M,...$});pt({aiConfig:E}),await e.saveGlobalSettings({aiConfig:E}),window.siyuanApiSwitch&&window.siyuanApiSwitch.updateLocalConfig(e.name,{provider:"custom",baseUrl:E.baseUrl,apiKey:E.apiKey,model:E.model,requestTimeoutSeconds:E.requestTimeoutSeconds,temperature:E.temperature,maxTokens:E.maxTokens})}return t.updateManagedConfig=$=>{i=$,a($);const M=!!$,E=Fo().aiConfig;l.disabled=M,u.disabled=M,p.disabled=M,d.disabled=M,g.disabled=M,v.disabled=M,x.disabled=M,l.value=$?$.baseUrl:E.baseUrl,u.value=$?$.apiKey:E.apiKey,d.value=$?$.model:E.model,g.value=String(($==null?void 0:$.requestTimeoutSeconds)??E.requestTimeoutSeconds),v.value=String(($==null?void 0:$.temperature)??E.temperature),x.value=String(($==null?void 0:$.maxTokens)??E.maxTokens),k.textContent=""},t}const Y2=150,Z2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,J2="slides-dock",As="slides-preview-tab",za="slides-presenter-tab",Ha=dh;class X2 extends ie.Plugin{constructor(){super(...arguments);Ie(this,"isMobile",!1);Ie(this,"currentDocId","");Ie(this,"previewTab",null);Ie(this,"latestCompiledDoc",null);Ie(this,"setting",null);Ie(this,"debounceTimer",null);Ie(this,"activeCursorBlockId","");Ie(this,"cancelledCursorBlockId","");Ie(this,"compileScheduler",new U2);Ie(this,"dirtyDocId",null);Ie(this,"inspectorSyncThrottle",new F2);Ie(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Ie(this,"onWsMainBound",this.onWsMain.bind(this));Ie(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Ie(this,"onEditorClickBound",this.onEditorClick.bind(this));Ie(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Ie(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Ie(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this));Ie(this,"isOpeningSetting",!1)}async onload(){const o=ie.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.initApiSwitchSync(),this.addIcons(Z2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现",position:"right",callback:()=>{this.openBottomPreviewTab()}}),R2(this);const i=this;if(this.addTab({type:As,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,M2(s.element,i);const a=(r=s==null?void 0:s.data)==null?void 0:r.docId;a&&!i.getActiveDocumentId()&&i.compileCurrentDocument(a,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),Pc(this.element)}}),this.addTab({type:za,init(n){B2((this||n).element,i)},destroy(){Rc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现配置"},data:{},type:J2,init(){D2(this.element,i)},destroy(){zc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(Ha),i=hh(o);return pt(i),i}catch{return pt(bo),bo}}async saveGlobalSettings(o){const i=Fo(),n=pt({...i,...o||{}});try{await this.saveData(Ha,n)}catch(a){console.error("保存即现全局配置失败",a)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}openSetting(){if(!this.isOpeningSetting){this.isOpeningSetting=!0;try{this.setting=G2(this),this.setting.open(this.name)}finally{setTimeout(()=>{this.isOpeningSetting=!1},500)}}}initApiSwitchSync(){const o=s=>{if(uh(s),this.setting){const a=this.setting.updateManagedConfig;typeof a=="function"&&a(s)}},i=()=>{const s=Fo().aiConfig;return{provider:"custom",baseUrl:s.baseUrl,apiKey:s.apiKey,model:s.model,requestTimeoutSeconds:s.requestTimeoutSeconds,temperature:s.temperature,maxTokens:s.maxTokens}},n=()=>{window.siyuanApiSwitch&&window.siyuanApiSwitch.register(this.name,this.displayName||"即现 (SiYuan Live Slides)",o,i())};window.siyuanApiSwitch?n():window.addEventListener("siyuan-api-switch:ready",()=>{n()},{once:!0})}onunload(){window.siyuanApiSwitch&&window.siyuanApiSwitch.unregister(this.name),this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,In.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),$i.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await ie.openTab({app:this.app,custom:{id:this.name+As,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){Do("presenterMode")||(E2()||await this.openBottomPreviewTab(),await ie.openTab({app:this.app,custom:{id:this.name+za,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=ie.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),a=await ie.openTab({app:this.app,custom:{id:this.name+As,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||a}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),ie.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var a,r,l,c,u;const i=(a=o.detail)==null?void 0:a.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(l=i==null?void 0:i.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const f=await er(n).catch(()=>({}));ri({id:n,rootId:n,type:"doc",attrs:f}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,a;const i=o==null?void 0:o.detail;if(!i)return;const n=(a=(s=i.protyle)==null?void 0:s.block)==null?void 0:a.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return gc(o)}async fetchDocumentTitle(o){return yc(this,o)}async updatePreviewTabHeader(o,i){return Eg(this,o,i)}getActiveDocumentId(){return Eo.getActiveDocumentId()}resolveDocIdFromElement(o){return Eo.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await Eo.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&(Eo.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=Y2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=In.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,_2);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Eo.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){var f,p;const i=o.target;if(!i)return;const n=((f=i.closest)==null?void 0:f.call(i,".protyle"))||((p=i.closest)==null?void 0:p.call(i,".protyle-wysiwyg"));if(Ta(n))return;const s=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!s){const d=this.resolveDocIdFromElement(i);if(d&&this.activeCursorBlockId!==d){const b=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),y=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,y)}return}if(!i.closest(".protyle-wysiwyg"))return;const l=i.closest("[data-node-id]");if(!l)return;const c=l.getAttribute("data-node-id"),u=l.getAttribute("data-type")||"";c&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId&&(this.activeCursorBlockId=c,Xs(c)),this.syncInspectorBlock(l,c,u))}onSelectionChange(){var f,p;if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=((f=n.closest)==null?void 0:f.call(n,".protyle"))||((p=n.closest)==null?void 0:p.call(n,".protyle-wysiwyg"));if(Ta(s))return;const a=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!a){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const b=a||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),y=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,y)}return}if(!n.closest(".protyle-wysiwyg"))return;const l=n.closest("[data-node-id]"),c=l==null?void 0:l.getAttribute("data-node-id"),u=(l==null?void 0:l.getAttribute("data-type"))||"";if(l&&c){if(Eo.isLocatingLocked(c))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId){if(c===this.cancelledCursorBlockId)return;this.activeCursorBlockId=c,Xs(c)}this.syncInspectorBlock(l,c,u)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await Eo.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&In.getVisibility()==="none"){this.dirtyDocId=s;return}const a=this.compileScheduler.tryBegin(s);if(a!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Ee.compile(s),l=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,N2(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){Eo.purgeStaleDomSlidesAttrs(o)}}module.exports=X2;
