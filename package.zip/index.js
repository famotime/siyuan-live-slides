"use strict";var Rc=Object.create;var Ws=Object.defineProperty;var Oc=Object.getOwnPropertyDescriptor;var Nc=Object.getOwnPropertyNames;var zc=Object.getPrototypeOf,Hc=Object.prototype.hasOwnProperty;var Fc=(e,t,i)=>t in e?Ws(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var jc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Nc(t))!Hc.call(e,s)&&s!==i&&Ws(e,s,{get:()=>t[s],enumerable:!(n=Oc(t,s))||n.enumerable});return e};var Gn=(e,t,i)=>(i=e!=null?Rc(zc(e)):{},jc(t||!e||!e.__esModule?Ws(i,"default",{value:e,enumerable:!0}):i,e));var ye=(e,t,i)=>Fc(e,typeof t!="symbol"?t+"":t,i);const ue=require("siyuan");async function mt(e,t){const i=await ue.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Wc(){return mt("/api/notebook/lsNotebooks","")}async function Uc(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function sl(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return mt("/api/asset/upload",i)}async function Mi(e,t,i,n,s){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function co(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function dr(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ol(e){return mt("/api/block/deleteBlock",{id:e})}async function Vc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function us(e){return mt("/api/block/getChildBlocks",{id:e})}async function Kc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function je(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Do(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function nn(e){return mt("/api/query/sql",{stmt:e})}async function uo(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function rl(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Gc(){return mt("/api/storage/getInlineStyles","")}const ll=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function qc(e){const t=[];if(!e)return t;const i=new RegExp(ll.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function Yc(e,t){if(!e)return"";const i=new RegExp(ll.source,"g");return e.replace(i,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(t&&t[s]){const d=t[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}const En="custom-slidev-theme",An="custom-slidev-aspect-ratio",al="custom-slidev-highlighter",Mn="custom-slidev-default-transition",cl="custom-slidev-color-schema",fo="custom-slidev-spacing",Ei="custom-slidev-slide",ke="custom-slidev-layout",pt="custom-slidev-transition",et="custom-slidev-background",Bt="custom-slidev-image",Us="custom-slidev-notes",Ki="custom-slidev-class",kn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",Gi="custom-slidev-mask",qi="custom-slidev-mask-ratio",Yi="custom-slidev-mask-style",Zi="custom-slidev-mask-initial",Ye="custom-slidev-click",Gt="custom-slidev-motion",Ni="custom-slidev-shiki-lines",$e="custom-slidev-slot",it="custom-slidev-note",qe="custom-slidev-role",Bn="custom-slidev-max-height",Ai="custom-slidev-autoplay",fs="custom-slidev-loop",Vi="custom-slidev-muted",ps="custom-slidev-controls",dl="background",hs="image-left",ms="image-right";function Dn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Zc(e){if(!e||typeof e!="string")return{steps:2,breakpoints:[50,100]};const t=e.trim();if(!t)return{steps:2,breakpoints:[50,100]};const i=t.split(":").map(c=>parseFloat(c.trim())).filter(c=>!isNaN(c)&&c>0);if(i.length===0)return{steps:2,breakpoints:[50,100]};if(i.length===1){const c=Math.min(100,Math.max(1,i[0]));return c===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(c*100)/100,100]}}const n=i.every((c,d)=>d===0||c>i[d-1]),s=i[i.length-1];if(n&&(s===100||i.some(c=>c>10))){const c=i.map(d=>Math.min(100,Math.round(d*100)/100));return c[c.length-1]<100&&c.push(100),{steps:c.length,breakpoints:c}}const l=i.reduce((c,d)=>c+d,0);if(l<=0)return{steps:2,breakpoints:[50,100]};let r=0;const a=[];for(let c=0;c<i.length;c++)r+=i[c],c===i.length-1?a.push(100):a.push(Math.round(r/l*1e4)/100);return{steps:a.length,breakpoints:a}}function Jc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Xc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function ul(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function fl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Tt(e,t){if(!ul(e))return e;const i=fl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Qc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Tt(o,t);return`![${s}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Lo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ve={},Ji=[],qt=()=>{},pl=()=>!1,$s=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Is=e=>e.startsWith("onUpdate:"),ct=Object.assign,Po=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},ed=Object.prototype.hasOwnProperty,He=(e,t)=>ed.call(e,t),Ie=Array.isArray,Xi=e=>Fn(e)==="[object Map]",an=e=>Fn(e)==="[object Set]",ur=e=>Fn(e)==="[object Date]",Ae=e=>typeof e=="function",Qe=e=>typeof e=="string",Pt=e=>typeof e=="symbol",Ue=e=>e!==null&&typeof e=="object",hl=e=>(Ue(e)||Ae(e))&&Ae(e.then)&&Ae(e.catch),ml=Object.prototype.toString,Fn=e=>ml.call(e),td=e=>Fn(e).slice(8,-1),gl=e=>Fn(e)==="[object Object]",Ro=e=>Qe(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,wn=Lo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Ts=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},id=/-\w/g,wt=Ts(e=>e.replace(id,t=>t.slice(1).toUpperCase())),nd=/\B([A-Z])/g,wi=Ts(e=>e.replace(nd,"-$1").toLowerCase()),Es=Ts(e=>e.charAt(0).toUpperCase()+e.slice(1)),Vs=Ts(e=>e?`on${Es(e)}`:""),Wt=(e,t)=>!Object.is(e,t),is=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},vl=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},As=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let fr;const Ms=()=>fr||(fr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Ut(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=Qe(n)?ld(n):Ut(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(Qe(e)||Ue(e))return e}const sd=/;(?![^(]*\))/g,od=/:([^]+)/,rd=/\/\*[^]*?\*\//g;function ld(e){const t={};return e.replace(rd,"").split(sd).forEach(i=>{if(i){const n=i.split(od);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(Qe(e))t=e;else if(Ie(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(Ue(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const ad="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",cd=Lo(ad);function bl(e){return!!e||e===""}function dd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=cn(e[n],t[n]);return i}function cn(e,t){if(e===t)return!0;let i=ur(e),n=ur(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Pt(e),n=Pt(t),i||n)return e===t;if(i=Ie(e),n=Ie(t),i||n)return i&&n?dd(e,t):!1;if(i=Ue(e),n=Ue(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!cn(e[l],t[l]))return!1}}return String(e)===String(t)}function Oo(e,t){return e.findIndex(i=>cn(i,t))}const yl=e=>!!(e&&e.__v_isRef===!0),Se=e=>Qe(e)?e:e==null?"":Ie(e)||Ue(e)&&(e.toString===ml||!Ae(e.toString))?yl(e)?Se(e.value):JSON.stringify(e,kl,2):String(e),kl=(e,t)=>yl(t)?kl(e,t.value):Xi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[Ks(n,o)+" =>"]=s,i),{})}:an(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Ks(i))}:Pt(t)?Ks(t):Ue(t)&&!Ie(t)&&!gl(t)?String(t):t,Ks=(e,t="")=>{var i;return Pt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class ud{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function fd(){return lt}let Ge;const Gs=new WeakSet;class wl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Gs.has(this)&&(Gs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Sl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,pr(this),_l(this);const t=Ge,i=Dt;Ge=this,Dt=!0;try{return this.fn()}finally{Cl(this),Ge=t,Dt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ho(t);this.deps=this.depsTail=void 0,pr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Gs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){po(this)&&this.run()}get dirty(){return po(this)}}let xl=0,xn,Sn;function Sl(e,t=!1){if(e.flags|=8,t){e.next=Sn,Sn=e;return}e.next=xn,xn=e}function No(){xl++}function zo(){if(--xl>0)return;if(Sn){let t=Sn;for(Sn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;xn;){let t=xn;for(xn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function _l(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Cl(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Ho(n),pd(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function po(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&($l(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function $l(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Ln)||(e.globalVersion=Ln,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!po(e))))return;e.flags|=2;const t=e.dep,i=Ge,n=Dt;Ge=e,Dt=!0;try{_l(e);const s=e.fn(e._value);(t.version===0||Wt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Ge=i,Dt=n,Cl(e),e.flags&=-3}}function Ho(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Ho(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function pd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Dt=!0;const Il=[];function oi(){Il.push(Dt),Dt=!1}function ri(){const e=Il.pop();Dt=e===void 0?!0:e}function pr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ge;Ge=void 0;try{t()}finally{Ge=i}}}let Ln=0;class hd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Fo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ge||!Dt||Ge===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ge)i=this.activeLink=new hd(Ge,this),Ge.deps?(i.prevDep=Ge.depsTail,Ge.depsTail.nextDep=i,Ge.depsTail=i):Ge.deps=Ge.depsTail=i,Tl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ge.depsTail,i.nextDep=void 0,Ge.depsTail.nextDep=i,Ge.depsTail=i,Ge.deps===i&&(Ge.deps=n)}return i}trigger(t){this.version++,Ln++,this.notify(t)}notify(t){No();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{zo()}}}function Tl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Tl(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const ho=new WeakMap,Li=Symbol(""),mo=Symbol(""),Pn=Symbol("");function ft(e,t,i){if(Dt&&Ge){let n=ho.get(e);n||ho.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Fo),s.map=n,s.key=i),s.track()}}function ti(e,t,i,n,s,o){const l=ho.get(e);if(!l){Ln++;return}const r=a=>{a&&a.trigger()};if(No(),t==="clear")l.forEach(r);else{const a=Ie(e),c=a&&Ro(i);if(a&&i==="length"){const d=Number(n);l.forEach((f,g)=>{(g==="length"||g===Pn||!Pt(g)&&g>=d)&&r(f)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Pn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Li)),Xi(e)&&r(l.get(mo)));break;case"delete":a||(r(l.get(Li)),Xi(e)&&r(l.get(mo)));break;case"set":Xi(e)&&r(l.get(Li));break}}zo()}function Wi(e){const t=ze(e);return t===e?t:(ft(t,"iterate",Pn),At(e)?t:t.map(Rt))}function Bs(e){return ft(e=ze(e),"iterate",Pn),e}function Ft(e,t){return li(e)?sn(Pi(e)?Rt(t):t):Rt(t)}const md={__proto__:null,[Symbol.iterator](){return qs(this,Symbol.iterator,e=>Ft(this,e))},concat(...e){return Wi(this).concat(...e.map(t=>Ie(t)?Wi(t):t))},entries(){return qs(this,"entries",e=>(e[1]=Ft(this,e[1]),e))},every(e,t){return Xt(this,"every",e,t,void 0,arguments)},filter(e,t){return Xt(this,"filter",e,t,i=>i.map(n=>Ft(this,n)),arguments)},find(e,t){return Xt(this,"find",e,t,i=>Ft(this,i),arguments)},findIndex(e,t){return Xt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Xt(this,"findLast",e,t,i=>Ft(this,i),arguments)},findLastIndex(e,t){return Xt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Xt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Ys(this,"includes",e)},indexOf(...e){return Ys(this,"indexOf",e)},join(e){return Wi(this).join(e)},lastIndexOf(...e){return Ys(this,"lastIndexOf",e)},map(e,t){return Xt(this,"map",e,t,void 0,arguments)},pop(){return mn(this,"pop")},push(...e){return mn(this,"push",e)},reduce(e,...t){return hr(this,"reduce",e,t)},reduceRight(e,...t){return hr(this,"reduceRight",e,t)},shift(){return mn(this,"shift")},some(e,t){return Xt(this,"some",e,t,void 0,arguments)},splice(...e){return mn(this,"splice",e)},toReversed(){return Wi(this).toReversed()},toSorted(e){return Wi(this).toSorted(e)},toSpliced(...e){return Wi(this).toSpliced(...e)},unshift(...e){return mn(this,"unshift",e)},values(){return qs(this,"values",e=>Ft(this,e))}};function qs(e,t,i){const n=Bs(e),s=n[t]();return n!==e&&!At(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const gd=Array.prototype;function Xt(e,t,i,n,s,o){const l=Bs(e),r=l!==e&&!At(e),a=l[t];if(a!==gd[t]){const f=a.apply(e,o);return r?Rt(f):f}let c=i;l!==e&&(r?c=function(f,g){return i.call(this,Ft(e,f),g,e)}:i.length>2&&(c=function(f,g){return i.call(this,f,g,e)}));const d=a.call(l,c,n);return r&&s?s(d):d}function hr(e,t,i,n){const s=Bs(e),o=s!==e&&!At(e);let l=i,r=!1;s!==e&&(o?(r=n.length===0,l=function(c,d,f){return r&&(r=!1,c=Ft(e,c)),i.call(this,c,Ft(e,d),f,e)}):i.length>3&&(l=function(c,d,f){return i.call(this,c,d,f,e)}));const a=s[t](l,...n);return r?Ft(e,a):a}function Ys(e,t,i){const n=ze(e);ft(n,"iterate",Pn);const s=n[t](...i);return(s===-1||s===!1)&&Uo(i[0])?(i[0]=ze(i[0]),n[t](...i)):s}function mn(e,t,i=[]){oi(),No();const n=ze(e)[t].apply(e,i);return zo(),ri(),n}const vd=Lo("__proto__,__v_isRef,__isVue"),El=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Pt));function bd(e){Pt(e)||(e=String(e));const t=ze(this);return ft(t,"has",e),t.hasOwnProperty(e)}class Al{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Td:Ll:o?Dl:Bl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Ie(t);if(!s){let a;if(l&&(a=md[i]))return a;if(i==="hasOwnProperty")return bd}const r=Reflect.get(t,i,Ze(t)?t:n);if((Pt(i)?El.has(i):vd(i))||(s||ft(t,"get",i),o))return r;if(Ze(r)){const a=l&&Ro(i)?r:r.value;return s&&Ue(a)?vo(a):a}return Ue(r)?s?vo(r):Ds(r):r}}class Ml extends Al{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const l=Ie(t)&&Ro(i);if(!this._isShallow){const c=li(o);if(!At(n)&&!li(n)&&(o=ze(o),n=ze(n)),!l&&Ze(o)&&!Ze(n))return c||(o.value=n),!0}const r=l?Number(i)<t.length:He(t,i),a=Reflect.set(t,i,n,Ze(t)?t:s);return t===ze(s)&&a&&(r?Wt(n,o)&&ti(t,"set",i,n):ti(t,"add",i,n)),a}deleteProperty(t,i){const n=He(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ti(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Pt(i)||!El.has(i))&&ft(t,"has",i),n}ownKeys(t){return ft(t,"iterate",Ie(t)?"length":Li),Reflect.ownKeys(t)}}class yd extends Al{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const kd=new Ml,wd=new yd,xd=new Ml(!0);const go=e=>e,qn=e=>Reflect.getPrototypeOf(e);function Sd(e,t,i){return function(...n){const s=this.__v_raw,o=ze(s),l=Xi(o),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=s[e](...n),d=i?go:t?sn:Rt;return!t&&ft(o,"iterate",a?mo:Li),ct(Object.create(c),{next(){const{value:f,done:g}=c.next();return g?{value:f,done:g}:{value:r?[d(f[0]),d(f[1])]:d(f),done:g}}})}}function Yn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function _d(e,t){const i={get(s){const o=this.__v_raw,l=ze(o),r=ze(s);e||(Wt(s,r)&&ft(l,"get",s),ft(l,"get",r));const{has:a}=qn(l),c=t?go:e?sn:Rt;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!e&&ft(ze(s),"iterate",Li),s.size},has(s){const o=this.__v_raw,l=ze(o),r=ze(s);return e||(Wt(s,r)&&ft(l,"has",s),ft(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=ze(r),c=t?go:e?sn:Rt;return!e&&ft(a,"iterate",Li),r.forEach((d,f)=>s.call(o,c(d),c(f),l))}};return ct(i,e?{add:Yn("add"),set:Yn("set"),delete:Yn("delete"),clear:Yn("clear")}:{add(s){const o=ze(this),l=qn(o),r=ze(s),a=!t&&!At(s)&&!li(s)?r:s;return l.has.call(o,a)||Wt(s,a)&&l.has.call(o,s)||Wt(r,a)&&l.has.call(o,r)||(o.add(a),ti(o,"add",a,a)),this},set(s,o){!t&&!At(o)&&!li(o)&&(o=ze(o));const l=ze(this),{has:r,get:a}=qn(l);let c=r.call(l,s);c||(s=ze(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Wt(o,d)&&ti(l,"set",s,o):ti(l,"add",s,o),this},delete(s){const o=ze(this),{has:l,get:r}=qn(o);let a=l.call(o,s);a||(s=ze(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&ti(o,"delete",s,void 0),c},clear(){const s=ze(this),o=s.size!==0,l=s.clear();return o&&ti(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=Sd(s,e,t)}),i}function jo(e,t){const i=_d(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(He(i,s)&&s in n?i:n,s,o)}const Cd={get:jo(!1,!1)},$d={get:jo(!1,!0)},Id={get:jo(!0,!1)};const Bl=new WeakMap,Dl=new WeakMap,Ll=new WeakMap,Td=new WeakMap;function Ed(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ds(e){return li(e)?e:Wo(e,!1,kd,Cd,Bl)}function Ad(e){return Wo(e,!1,xd,$d,Dl)}function vo(e){return Wo(e,!0,wd,Id,Ll)}function Wo(e,t,i,n,s){if(!Ue(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const l=Ed(td(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return s.set(e,r),r}function Pi(e){return li(e)?Pi(e.__v_raw):!!(e&&e.__v_isReactive)}function li(e){return!!(e&&e.__v_isReadonly)}function At(e){return!!(e&&e.__v_isShallow)}function Uo(e){return e?!!e.__v_raw:!1}function ze(e){const t=e&&e.__v_raw;return t?ze(t):e}function Md(e){return!He(e,"__v_skip")&&Object.isExtensible(e)&&vl(e,"__v_skip",!0),e}const Rt=e=>Ue(e)?Ds(e):e,sn=e=>Ue(e)?vo(e):e;function Ze(e){return e?e.__v_isRef===!0:!1}function he(e){return Bd(e,!1)}function Bd(e,t){return Ze(e)?e:new Dd(e,t)}class Dd{constructor(t,i){this.dep=new Fo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:ze(t),this._value=i?t:Rt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||At(t)||li(t);t=n?t:ze(t),Wt(t,i)&&(this._rawValue=t,this._value=n?t:Rt(t),this.dep.trigger())}}function ve(e){return Ze(e)?e.value:e}const Ld={get:(e,t,i)=>t==="__v_raw"?e:ve(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return Ze(s)&&!Ze(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Pl(e){return Pi(e)?e:new Proxy(e,Ld)}class Pd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Fo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Ln-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ge!==this)return Sl(this,!0),!0}get value(){const t=this.dep.track();return $l(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Rd(e,t,i=!1){let n,s;return Ae(e)?n=e:(n=e.get,s=e.set),new Pd(n,s,i)}const Zn={},gs=new WeakMap;let Ti;function Od(e,t=!1,i=Ti){if(i){let n=gs.get(i);n||gs.set(i,n=[]),n.push(e)}}function Nd(e,t,i=Ve){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=i,c=M=>s?M:At(M)||s===!1||s===0?ii(M,1):ii(M);let d,f,g,u,h=!1,m=!1;if(Ze(e)?(f=()=>e.value,h=At(e)):Pi(e)?(f=()=>c(e),h=!0):Ie(e)?(m=!0,h=e.some(M=>Pi(M)||At(M)),f=()=>e.map(M=>{if(Ze(M))return M.value;if(Pi(M))return c(M);if(Ae(M))return a?a(M,2):M()})):Ae(e)?t?f=a?()=>a(e,2):e:f=()=>{if(g){oi();try{g()}finally{ri()}}const M=Ti;Ti=d;try{return a?a(e,3,[u]):e(u)}finally{Ti=M}}:f=qt,t&&s){const M=f,A=s===!0?1/0:s;f=()=>ii(M(),A)}const b=fd(),y=()=>{d.stop(),b&&b.active&&Po(b.effects,d)};if(o&&t){const M=t;t=(...A)=>{const I=M(...A);return y(),I}}let x=m?new Array(e.length).fill(Zn):Zn;const _=M=>{if(!(!(d.flags&1)||!d.dirty&&!M))if(t){const A=d.run();if(M||s||h||(m?A.some((I,w)=>Wt(I,x[w])):Wt(A,x))){g&&g();const I=Ti;Ti=d;try{const w=[A,x===Zn?void 0:m&&x[0]===Zn?[]:x,u];x=A,a?a(t,3,w):t(...w)}finally{Ti=I}}}else d.run()};return r&&r(_),d=new wl(f),d.scheduler=l?()=>l(_,!1):_,u=M=>Od(M,!1,d),g=d.onStop=()=>{const M=gs.get(d);if(M){if(a)a(M,4);else for(const A of M)A();gs.delete(d)}},t?n?_(!0):x=d.run():l?l(_.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function ii(e,t=1/0,i){if(t<=0||!Ue(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ze(e))ii(e.value,t,i);else if(Ie(e))for(let n=0;n<e.length;n++)ii(e[n],t,i);else if(an(e)||Xi(e))e.forEach(n=>{ii(n,t,i)});else if(gl(e)){for(const n in e)ii(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ii(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function jn(e,t,i,n){try{return n?e(...n):e()}catch(s){Ls(s,t,i)}}function Ot(e,t,i,n){if(Ae(e)){const s=jn(e,t,i,n);return s&&hl(s)&&s.catch(o=>{Ls(o,t,i)}),s}if(Ie(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Ot(e[o],t,i,n));return s}}function Ls(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ve;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let f=0;f<d.length;f++)if(d[f](e,a,c)===!1)return}r=r.parent}if(o){oi(),jn(o,null,10,[e,a,c]),ri();return}}zd(e,i,s,n,l)}function zd(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const bt=[];let Ht=-1;const Qi=[];let hi=null,Ui=0;const Rl=Promise.resolve();let vs=null;function bs(e){const t=vs||Rl;return e?t.then(this?e.bind(this):e):t}function Hd(e){let t=Ht+1,i=bt.length;for(;t<i;){const n=t+i>>>1,s=bt[n],o=Rn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function Vo(e){if(!(e.flags&1)){const t=Rn(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Rn(i)?bt.push(e):bt.splice(Hd(t),0,e),e.flags|=1,Ol()}}function Ol(){vs||(vs=Rl.then(zl))}function Fd(e){Ie(e)?Qi.push(...e):hi&&e.id===-1?hi.splice(Ui+1,0,e):e.flags&1||(Qi.push(e),e.flags|=1),Ol()}function mr(e,t,i=Ht+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Nl(e){if(Qi.length){const t=[...new Set(Qi)].sort((i,n)=>Rn(i)-Rn(n));if(Qi.length=0,hi){hi.push(...t);return}for(hi=t,Ui=0;Ui<hi.length;Ui++){const i=hi[Ui];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}hi=null,Ui=0}}const Rn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function zl(e){try{for(Ht=0;Ht<bt.length;Ht++){const t=bt[Ht];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ht<bt.length;Ht++){const t=bt[Ht];t&&(t.flags&=-2)}Ht=-1,bt.length=0,Nl(),vs=null,(bt.length||Qi.length)&&zl()}}let at=null,Hl=null;function ys(e){const t=at;return at=e,Hl=e&&e.type.__scopeId||null,t}function Fl(e,t=at,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Ir(-1);const o=ys(t),l=ni.length;let r;try{r=e(...s)}finally{for(let a=ni.length;a>l;a--)Zo();ys(o),n._d&&Ir(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Mt(e,t){if(at===null)return e;const i=zs(at),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,l,r,a=Ve]=t[s];o&&(Ae(o)&&(o={mounted:o,updated:o}),o.deep&&ii(l),n.push({dir:o,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Si(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(oi(),Ot(a,i,8,[e.el,r,e,t]),ri())}}function jd(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function Lt(e,t,i=!1){const n=Hu();if(n||tn){let s=tn?tn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Ae(t)?t.call(n&&n.proxy):t}}const Wd=Symbol.for("v-scx"),Ud=()=>Lt(Wd);function Ri(e,t,i){return jl(e,t,i)}function jl(e,t,i=Ve){const{immediate:n,deep:s,flush:o,once:l}=i,r=ct({},i),a=t&&n||!t&&o!=="post";let c;if(Nn){if(o==="sync"){const u=Ud();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=qt,u.resume=qt,u.pause=qt,u}}const d=ht;r.call=(u,h,m)=>Ot(u,d,h,m);let f=!1;o==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:o!=="sync"&&(f=!0,r.scheduler=(u,h)=>{h?u():Vo(u)}),r.augmentJob=u=>{t&&(u.flags|=4),f&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Nd(e,t,r);return Nn&&(c?c.push(g):a&&g()),g}function Vd(e,t,i){const n=this.proxy,s=Qe(e)?e.includes(".")?Wl(n,e):()=>n[e]:e.bind(n,n);let o;Ae(t)?o=t:(o=t.handler,i=t);const l=Wn(this),r=jl(s,o.bind(n),i);return l(),r}function Wl(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const Kd=Symbol("_vte"),Gd=e=>e.__isTeleport,Zs=Symbol("_leaveCb");function Ko(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Ko(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function It(e,t){return Ae(e)?ct({name:e.name},t,{setup:e}):e}function Ul(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function gr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const ks=new WeakMap;function _n(e,t,i,n,s=!1){if(Ie(e)){e.forEach((m,b)=>_n(m,t&&(Ie(t)?t[b]:t),i,n,s));return}if(en(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&_n(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?zs(n.component):n.el,l=s?null:o,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ve?r.refs={}:r.refs,f=r.setupState,g=ze(f),u=f===Ve?pl:m=>gr(d,m)?!1:He(g,m),h=(m,b)=>!(b&&gr(d,b));if(c!=null&&c!==a){if(vr(t),Qe(c))d[c]=null,u(c)&&(f[c]=null);else if(Ze(c)){const m=t;h(c,m.k)&&(c.value=null),m.k&&(d[m.k]=null)}}if(Ae(a))jn(a,r,12,[l,d]);else{const m=Qe(a),b=Ze(a);if(m||b){const y=()=>{if(e.f){const x=m?u(a)?f[a]:d[a]:h()||!e.k?a.value:d[e.k];if(s)Ie(x)&&Po(x,o);else if(Ie(x))x.includes(o)||x.push(o);else if(m)d[a]=[o],u(a)&&(f[a]=d[a]);else{const _=[o];h(a,e.k)&&(a.value=_),e.k&&(d[e.k]=_)}}else m?(d[a]=l,u(a)&&(f[a]=l)):b&&(h(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{y(),ks.delete(e)};x.id=-1,ks.set(e,x),xt(x,i)}else vr(e),y()}}}function vr(e){const t=ks.get(e);t&&(t.flags|=8,ks.delete(e))}Ms().requestIdleCallback;Ms().cancelIdleCallback;const en=e=>!!e.type.__asyncLoader,Vl=e=>e.type.__isKeepAlive;function qd(e,t){Kl(e,"a",t)}function Yd(e,t){Kl(e,"da",t)}function Kl(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ps(t,n,i),i){let s=i.parent;for(;s&&s.parent;)Vl(s.parent.vnode)&&Zd(n,t,i,s),s=s.parent}}function Zd(e,t,i,n){const s=Ps(t,e,n,!0);Rs(()=>{Po(n[t],s)},i)}function Ps(e,t,i=ht,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...l)=>{oi();const r=Wn(i),a=Ot(t,i,e,l);return r(),ri(),a});return n?s.unshift(o):s.push(o),o}}const ci=e=>(t,i=ht)=>{(!Nn||e==="sp")&&Ps(e,(...n)=>t(...n),i)},Jd=ci("bm"),dn=ci("m"),Xd=ci("bu"),Qd=ci("u"),Go=ci("bum"),Rs=ci("um"),eu=ci("sp"),tu=ci("rtg"),iu=ci("rtc");function nu(e,t=ht){Ps("ec",e,t)}const su="components";function ou(e,t){return lu(su,e,!0,t)||e}const ru=Symbol.for("v-ndc");function lu(e,t,i=!0,n=!1){const s=at||ht;if(s){const o=s.type;{const r=Vu(o,!1);if(r&&(r===t||r===wt(t)||r===Es(wt(t))))return o}const l=br(s[e]||o[e],t)||br(s.appContext[e],t);return!l&&n?o:l}}function br(e,t){return e&&(e[t]||e[wt(t)]||e[Es(wt(t))])}function kt(e,t,i,n){let s;const o=i,l=Ie(e);if(l||Qe(e)){const r=l&&Pi(e);let a=!1,c=!1;r&&(a=!At(e),c=li(e),e=Bs(e)),s=new Array(e.length);for(let d=0,f=e.length;d<f;d++)s[d]=t(a?c?sn(Rt(e[d])):Rt(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ue(e))if(e[Symbol.iterator])s=Array.from(e,(r,a)=>t(r,a,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=t(e[d],d,a,o)}}else s=[];return s}function Jn(e,t,i={},n,s,o){if(at.ce||at.parent&&en(at.parent)&&at.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),ee(),Kt(Ke,null,[le("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ni.length;ee();let a;try{const c=l&&Gl(l(i)),d=i.key||o||c&&c.key;a=Kt(Ke,{key:(d&&!Pt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ni.length;d>r;d--)Zo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Gl(e){return e.some(t=>Jo(t)?!(t.type===ai||t.type===Ke&&!Gl(t.children)):!0)?e:null}const bo=e=>e?pa(e)?zs(e):bo(e.parent):null,Cn=ct(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>bo(e.parent),$root:e=>bo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Yl(e),$forceUpdate:e=>e.f||(e.f=()=>{Vo(e.update)}),$nextTick:e=>e.n||(e.n=bs.bind(e.proxy)),$watch:e=>Vd.bind(e)}),Js=(e,t)=>e!==Ve&&!e.__isScriptSetup&&He(e,t),au={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const g=l[t];if(g!==void 0)switch(g){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(Js(n,t))return l[t]=1,n[t];if(s!==Ve&&He(s,t))return l[t]=2,s[t];if(He(o,t))return l[t]=3,o[t];if(i!==Ve&&He(i,t))return l[t]=4,i[t];yo&&(l[t]=0)}}const c=Cn[t];let d,f;if(c)return t==="$attrs"&&ft(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ve&&He(i,t))return l[t]=4,i[t];if(f=a.config.globalProperties,He(f,t))return f[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return Js(s,t)?(s[t]=i,!0):n!==Ve&&He(n,t)?(n[t]=i,!0):He(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(i[r]||e!==Ve&&r[0]!=="$"&&He(e,r)||Js(t,r)||He(o,r)||He(n,r)||He(Cn,r)||He(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:He(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function yr(e){return Ie(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let yo=!0;function cu(e){const t=Yl(e),i=e.proxy,n=e.ctx;yo=!1,t.beforeCreate&&kr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:f,mounted:g,beforeUpdate:u,updated:h,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:_,unmounted:M,render:A,renderTracked:I,renderTriggered:w,errorCaptured:N,serverPrefetch:O,expose:F,inheritAttrs:q,components:S,directives:H,filters:k}=t;if(c&&du(c,n,null),l)for(const T in l){const B=l[T];Ae(B)&&(n[T]=B.bind(i))}if(s){const T=s.call(i,i);Ue(T)&&(e.data=Ds(T))}if(yo=!0,o)for(const T in o){const B=o[T],R=Ae(B)?B.bind(i,i):Ae(B.get)?B.get.bind(i,i):qt,X=!Ae(B)&&Ae(B.set)?B.set.bind(i):qt,U=we({get:R,set:X});Object.defineProperty(n,T,{enumerable:!0,configurable:!0,get:()=>U.value,set:Y=>U.value=Y})}if(r)for(const T in r)ql(r[T],n,i,T);if(a){const T=Ae(a)?a.call(i):a;Reflect.ownKeys(T).forEach(B=>{jd(B,T[B])})}d&&kr(d,e,"c");function j(T,B){Ie(B)?B.forEach(R=>T(R.bind(i))):B&&T(B.bind(i))}if(j(Jd,f),j(dn,g),j(Xd,u),j(Qd,h),j(qd,m),j(Yd,b),j(nu,N),j(iu,I),j(tu,w),j(Go,x),j(Rs,M),j(eu,O),Ie(F))if(F.length){const T=e.exposed||(e.exposed={});F.forEach(B=>{Object.defineProperty(T,B,{get:()=>i[B],set:R=>i[B]=R,enumerable:!0})})}else e.exposed||(e.exposed={});A&&e.render===qt&&(e.render=A),q!=null&&(e.inheritAttrs=q),S&&(e.components=S),H&&(e.directives=H),O&&Ul(e)}function du(e,t,i=qt){Ie(e)&&(e=ko(e));for(const n in e){const s=e[n];let o;Ue(s)?"default"in s?o=Lt(s.from||n,s.default,!0):o=Lt(s.from||n):o=Lt(s),Ze(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):t[n]=o}}function kr(e,t,i){Ot(Ie(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function ql(e,t,i,n){let s=n.includes(".")?Wl(i,n):()=>i[n];if(Qe(e)){const o=t[e];Ae(o)&&Ri(s,o)}else if(Ae(e))Ri(s,e.bind(i));else if(Ue(e))if(Ie(e))e.forEach(o=>ql(o,t,i,n));else{const o=Ae(e.handler)?e.handler.bind(i):t[e.handler];Ae(o)&&Ri(s,o,e)}}function Yl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=e.appContext,r=o.get(t);let a;return r?a=r:!s.length&&!i&&!n?a=t:(a={},s.length&&s.forEach(c=>ws(a,c,l,!0)),ws(a,t,l)),Ue(t)&&o.set(t,a),a}function ws(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&ws(e,o,i,!0),s&&s.forEach(l=>ws(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=uu[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const uu={data:wr,props:xr,emits:xr,methods:bn,computed:bn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:bn,directives:bn,watch:pu,provide:wr,inject:fu};function wr(e,t){return t?e?function(){return ct(Ae(e)?e.call(this,this):e,Ae(t)?t.call(this,this):t)}:t:e}function fu(e,t){return bn(ko(e),ko(t))}function ko(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function bn(e,t){return e?ct(Object.create(null),e,t):t}function xr(e,t){return e?Ie(e)&&Ie(t)?[...new Set([...e,...t])]:ct(Object.create(null),yr(e),yr(t??{})):t}function pu(e,t){if(!e)return t;if(!t)return e;const i=ct(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function Zl(){return{app:null,config:{isNativeTag:pl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let hu=0;function mu(e,t){return function(n,s=null){Ae(n)||(n=ct({},n)),s!=null&&!Ue(s)&&(s=null);const o=Zl(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:hu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:Gu,get config(){return o.config},set config(d){},use(d,...f){return l.has(d)||(d&&Ae(d.install)?(l.add(d),d.install(c,...f)):Ae(d)&&(l.add(d),d(c,...f))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,f){return f?(o.components[d]=f,c):o.components[d]},directive(d,f){return f?(o.directives[d]=f,c):o.directives[d]},mount(d,f,g){if(!a){const u=c._ceVNode||le(n,s);return u.appContext=o,g===!0?g="svg":g===!1&&(g=void 0),e(u,d,g),a=!0,c._container=d,d.__vue_app__=c,zs(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Ot(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,f){return o.provides[d]=f,c},runWithContext(d){const f=tn;tn=c;try{return d()}finally{tn=f}}};return c}}let tn=null;const gu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${wi(t)}Modifiers`];function vu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ve;let s=i;const o=t.startsWith("update:"),l=o&&gu(n,t.slice(7));l&&(l.trim&&(s=i.map(d=>Qe(d)?d.trim():d)),l.number&&(s=i.map(As)));let r,a=n[r=Vs(t)]||n[r=Vs(wt(t))];!a&&o&&(a=n[r=Vs(wi(t))]),a&&Ot(a,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ot(c,e,6,s)}}const bu=new WeakMap;function Jl(e,t,i=!1){const n=i?bu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let l={},r=!1;if(!Ae(e)){const a=c=>{const d=Jl(c,t,!0);d&&(r=!0,ct(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!o&&!r?(Ue(e)&&n.set(e,null),null):(Ie(o)?o.forEach(a=>l[a]=null):ct(l,o),Ue(e)&&n.set(e,l),l)}function Os(e,t){return!e||!$s(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),He(e,t[0].toLowerCase()+t.slice(1))||He(e,wi(t))||He(e,t))}function Sr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:f,data:g,setupState:u,ctx:h,inheritAttrs:m}=e,b=ys(e);let y,x;try{if(i.shapeFlag&4){const M=s||n,A=M;y=jt(c.call(A,M,d,f,u,g,h)),x=r}else{const M=t;y=jt(M.length>1?M(f,{attrs:r,slots:l,emit:a}):M(f,null)),x=t.props?r:yu(r)}}catch(M){ni.length=0,Ls(M,e,1),y=le(ai)}let _=y;if(x&&m!==!1){const M=Object.keys(x),{shapeFlag:A}=_;M.length&&A&7&&(o&&M.some(Is)&&(x=ku(x,o)),_=on(_,x,!1,!0))}return i.dirs&&(_=on(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(i.dirs):i.dirs),i.transition&&Ko(_,i.transition),y=_,ys(b),y}const yu=e=>{let t;for(const i in e)(i==="class"||i==="style"||$s(i))&&((t||(t={}))[i]=e[i]);return t},ku=(e,t)=>{const i={};for(const n in e)(!Is(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function wu(e,t,i){const{props:n,children:s,component:o}=e,{props:l,children:r,patchFlag:a}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?_r(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let f=0;f<d.length;f++){const g=d[f];if(Xl(l,n,g)&&!Os(c,g))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?_r(n,l,c):!0:!!l;return!1}function _r(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(Xl(t,e,o)&&!Os(i,o))return!0}return!1}function Xl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ue(n)&&Ue(s)?!cn(n,s):n!==s}function xu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Ql={},ea=()=>Object.create(Ql),ta=e=>Object.getPrototypeOf(e)===Ql;function Su(e,t,i,n=!1){const s={},o=ea();e.propsDefaults=Object.create(null),ia(e,t,s,o);for(const l in e.propsOptions[0])l in s||(s[l]=void 0);i?e.props=n?s:Ad(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function _u(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=e,r=ze(s),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let f=0;f<d.length;f++){let g=d[f];if(Os(e.emitsOptions,g))continue;const u=t[g];if(a)if(He(o,g))u!==o[g]&&(o[g]=u,c=!0);else{const h=wt(g);s[h]=wo(a,r,h,u,e,!1)}else u!==o[g]&&(o[g]=u,c=!0)}}}else{ia(e,t,s,o)&&(c=!0);let d;for(const f in r)(!t||!He(t,f)&&((d=wi(f))===f||!He(t,d)))&&(a?i&&(i[f]!==void 0||i[d]!==void 0)&&(s[f]=wo(a,r,f,void 0,e,!0)):delete s[f]);if(o!==r)for(const f in o)(!t||!He(t,f))&&(delete o[f],c=!0)}c&&ti(e.attrs,"set","")}function ia(e,t,i,n){const[s,o]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(wn(a))continue;const c=t[a];let d;s&&He(s,d=wt(a))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Os(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=ze(i),c=r||Ve;for(let d=0;d<o.length;d++){const f=o[d];i[f]=wo(s,a,f,c[f],e,!He(c,f))}}return l}function wo(e,t,i,n,s,o){const l=e[i];if(l!=null){const r=He(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ae(a)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Wn(s);n=c[i]=a.call(null,t),d()}}else n=a;s.ce&&s.ce._setProp(i,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===wi(i))&&(n=!0))}return n}const Cu=new WeakMap;function na(e,t,i=!1){const n=i?Cu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,l={},r=[];let a=!1;if(!Ae(e)){const d=f=>{a=!0;const[g,u]=na(f,t,!0);ct(l,g),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!a)return Ue(e)&&n.set(e,Ji),Ji;if(Ie(o))for(let d=0;d<o.length;d++){const f=wt(o[d]);Cr(f)&&(l[f]=Ve)}else if(o)for(const d in o){const f=wt(d);if(Cr(f)){const g=o[d],u=l[f]=Ie(g)||Ae(g)?{type:g}:ct({},g),h=u.type;let m=!1,b=!0;if(Ie(h))for(let y=0;y<h.length;++y){const x=h[y],_=Ae(x)&&x.name;if(_==="Boolean"){m=!0;break}else _==="String"&&(b=!1)}else m=Ae(h)&&h.name==="Boolean";u[0]=m,u[1]=b,(m||He(u,"default"))&&r.push(f)}}const c=[l,r];return Ue(e)&&n.set(e,c),c}function Cr(e){return e[0]!=="$"&&!wn(e)}const qo=e=>e==="_"||e==="_ctx"||e==="$stable",Yo=e=>Ie(e)?e.map(jt):[jt(e)],$u=(e,t,i)=>{if(t._n)return t;const n=Fl((...s)=>Yo(t(...s)),i);return n._c=!1,n},sa=(e,t,i)=>{const n=e._ctx;for(const s in e){if(qo(s))continue;const o=e[s];if(Ae(o))t[s]=$u(s,o,n);else if(o!=null){const l=Yo(o);t[s]=()=>l}}},oa=(e,t)=>{const i=Yo(t);e.slots.default=()=>i},ra=(e,t,i)=>{for(const n in t)(i||!qo(n))&&(e[n]=t[n])},Iu=(e,t,i)=>{const n=e.slots=ea();if(e.vnode.shapeFlag&32){const s=t._;s?(ra(n,t,i),i&&vl(n,"_",s,!0)):sa(t,n)}else t&&oa(e,t)},Tu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,l=Ve;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:ra(s,t,i):(o=!t.$stable,sa(t,s)),l=t}else t&&(oa(e,t),l={default:1});if(o)for(const r in s)!qo(r)&&l[r]==null&&delete s[r]},xt=Du;function Eu(e){return Au(e)}function Au(e,t){const i=Ms();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:f,nextSibling:g,setScopeId:u=qt,insertStaticContent:h}=e,m=(L,K,v,G=null,W=null,C=null,$=void 0,P=null,D=!!K.dynamicChildren)=>{if(L===K)return;L&&!gn(L,K)&&(G=Te(L),Y(L,W,C,!0),L=null),K.patchFlag===-2&&(D=!1,K.dynamicChildren=null);const{type:z,ref:V,shapeFlag:J}=K;switch(z){case Ns:b(L,K,v,G);break;case ai:y(L,K,v,G);break;case ns:L==null&&x(K,v,G,$);break;case Ke:S(L,K,v,G,W,C,$,P,D);break;default:J&1?A(L,K,v,G,W,C,$,P,D):J&6?H(L,K,v,G,W,C,$,P,D):(J&64||J&128)&&z.process(L,K,v,G,W,C,$,P,D,Z)}V!=null&&W?_n(V,L&&L.ref,C,K||L,!K):V==null&&L&&L.ref!=null&&_n(L.ref,null,C,L,!0)},b=(L,K,v,G)=>{if(L==null)n(K.el=r(K.children),v,G);else{const W=K.el=L.el;K.children!==L.children&&c(W,K.children)}},y=(L,K,v,G)=>{L==null?n(K.el=a(K.children||""),v,G):K.el=L.el},x=(L,K,v,G)=>{[L.el,L.anchor]=h(L.children,K,v,G,L.el,L.anchor)},_=({el:L,anchor:K},v,G)=>{let W;for(;L&&L!==K;)W=g(L),n(L,v,G),L=W;n(K,v,G)},M=({el:L,anchor:K})=>{let v;for(;L&&L!==K;)v=g(L),s(L),L=v;s(K)},A=(L,K,v,G,W,C,$,P,D)=>{if(K.type==="svg"?$="svg":K.type==="math"&&($="mathml"),L==null)I(K,v,G,W,C,$,P,D);else{const z=L.el&&L.el._isVueCE?L.el:null;try{z&&z._beginPatch(),O(L,K,W,C,$,P,D)}finally{z&&z._endPatch()}}},I=(L,K,v,G,W,C,$,P)=>{let D,z;const{props:V,shapeFlag:J,transition:re,dirs:oe}=L;if(D=L.el=l(L.type,C,V&&V.is,V),J&8?d(D,L.children):J&16&&N(L.children,D,null,G,W,Xs(L,C),$,P),oe&&Si(L,null,G,"created"),w(D,L,L.scopeId,$,G),V){for(const ie in V)ie!=="value"&&!wn(ie)&&o(D,ie,null,V[ie],C,G);"value"in V&&o(D,"value",null,V.value,C),(z=V.onVnodeBeforeMount)&&zt(z,G,L)}oe&&Si(L,null,G,"beforeMount");const me=Mu(W,re);me&&re.beforeEnter(D),n(D,K,v),((z=V&&V.onVnodeMounted)||me||oe)&&xt(()=>{try{z&&zt(z,G,L),me&&re.enter(D),oe&&Si(L,null,G,"mounted")}finally{}},W)},w=(L,K,v,G,W)=>{if(v&&u(L,v),G)for(let C=0;C<G.length;C++)u(L,G[C]);if(W){let C=W.subTree;if(K===C||da(C.type)&&(C.ssContent===K||C.ssFallback===K)){const $=W.vnode;w(L,$,$.scopeId,$.slotScopeIds,W.parent)}}},N=(L,K,v,G,W,C,$,P,D=0)=>{for(let z=D;z<L.length;z++){const V=L[z]=P?ei(L[z]):jt(L[z]);m(null,V,K,v,G,W,C,$,P)}},O=(L,K,v,G,W,C,$)=>{const P=K.el=L.el;let{patchFlag:D,dynamicChildren:z,dirs:V}=K;D|=L.patchFlag&16;const J=L.props||Ve,re=K.props||Ve;let oe;if(v&&_i(v,!1),(oe=re.onVnodeBeforeUpdate)&&zt(oe,v,K,L),V&&Si(K,L,v,"beforeUpdate"),v&&_i(v,!0),z&&(!L.dynamicChildren||L.dynamicChildren.length!==z.length)&&(D=0,$=!1,z=null),(J.innerHTML&&re.innerHTML==null||J.textContent&&re.textContent==null)&&d(P,""),z?F(L.dynamicChildren,z,P,v,G,Xs(K,W),C):$||B(L,K,P,null,v,G,Xs(K,W),C,!1),D>0){if(D&16)q(P,J,re,v,W);else if(D&2&&J.class!==re.class&&o(P,"class",null,re.class,W),D&4&&o(P,"style",J.style,re.style,W),D&8){const me=K.dynamicProps;for(let ie=0;ie<me.length;ie++){const ne=me[ie],Ce=J[ne],Me=re[ne];(Me!==Ce||ne==="value")&&o(P,ne,Ce,Me,W,v)}}D&1&&L.children!==K.children&&d(P,K.children)}else!$&&z==null&&q(P,J,re,v,W);((oe=re.onVnodeUpdated)||V)&&xt(()=>{oe&&zt(oe,v,K,L),V&&Si(K,L,v,"updated")},G)},F=(L,K,v,G,W,C,$)=>{for(let P=0;P<K.length;P++){const D=L[P],z=K[P],V=D.el&&(D.type===Ke||!gn(D,z)||D.shapeFlag&198)?f(D.el):v;m(D,z,V,null,G,W,C,$,!0)}},q=(L,K,v,G,W)=>{if(K!==v){if(K!==Ve)for(const C in K)!wn(C)&&!(C in v)&&o(L,C,K[C],null,W,G);for(const C in v){if(wn(C))continue;const $=v[C],P=K[C];$!==P&&C!=="value"&&o(L,C,P,$,W,G)}"value"in v&&o(L,"value",K.value,v.value,W)}},S=(L,K,v,G,W,C,$,P,D)=>{const z=K.el=L?L.el:r(""),V=K.anchor=L?L.anchor:r("");let{patchFlag:J,dynamicChildren:re,slotScopeIds:oe}=K;oe&&(P=P?P.concat(oe):oe),L==null?(n(z,v,G),n(V,v,G),N(K.children||[],v,V,W,C,$,P,D)):J>0&&J&64&&re&&L.dynamicChildren&&L.dynamicChildren.length===re.length?(F(L.dynamicChildren,re,v,W,C,$,P),(K.key!=null||W&&K===W.subTree)&&la(L,K,!0)):B(L,K,v,V,W,C,$,P,D)},H=(L,K,v,G,W,C,$,P,D)=>{K.slotScopeIds=P,L==null?K.shapeFlag&512?W.ctx.activate(K,v,G,$,D):k(K,v,G,W,C,$,D):E(L,K,D)},k=(L,K,v,G,W,C,$)=>{const P=L.component=zu(L,G,W);if(Vl(L)&&(P.ctx.renderer=Z),Fu(P,!1,$),P.asyncDep){if(W&&W.registerDep(P,j,$),!L.el){const D=P.subTree=le(ai);y(null,D,K,v),L.placeholder=D.el}}else j(P,L,K,v,W,C,$)},E=(L,K,v)=>{const G=K.component=L.component;if(wu(L,K,v))if(G.asyncDep&&!G.asyncResolved){T(G,K,v);return}else G.next=K,G.update();else K.el=L.el,G.vnode=K},j=(L,K,v,G,W,C,$)=>{const P=()=>{if(L.isMounted){let{next:J,bu:re,u:oe,parent:me,vnode:ie}=L;{const Oe=aa(L);if(Oe){J&&(J.el=ie.el,T(L,J,$)),Oe.asyncDep.then(()=>{xt(()=>{L.isUnmounted||z()},W)});return}}let ne=J,Ce;_i(L,!1),J?(J.el=ie.el,T(L,J,$)):J=ie,re&&is(re),(Ce=J.props&&J.props.onVnodeBeforeUpdate)&&zt(Ce,me,J,ie),_i(L,!0);const Me=Sr(L),Ne=L.subTree;L.subTree=Me,m(Ne,Me,f(Ne.el),Te(Ne),L,W,C),J.el=Me.el,ne===null&&xu(L,Me.el),oe&&xt(oe,W),(Ce=J.props&&J.props.onVnodeUpdated)&&xt(()=>zt(Ce,me,J,ie),W)}else{let J;const{el:re,props:oe}=K,{bm:me,m:ie,parent:ne,root:Ce,type:Me}=L,Ne=en(K);_i(L,!1),me&&is(me),!Ne&&(J=oe&&oe.onVnodeBeforeMount)&&zt(J,ne,K),_i(L,!0);{Ce.ce&&Ce.ce._hasShadowRoot()&&Ce.ce._injectChildStyle(Me,L.parent?L.parent.type:void 0);const Oe=L.subTree=Sr(L);m(null,Oe,v,G,L,W,C),K.el=Oe.el}if(ie&&xt(ie,W),!Ne&&(J=oe&&oe.onVnodeMounted)){const Oe=K;xt(()=>zt(J,ne,Oe),W)}(K.shapeFlag&256||ne&&en(ne.vnode)&&ne.vnode.shapeFlag&256)&&L.a&&xt(L.a,W),L.isMounted=!0,K=v=G=null}};L.scope.on();const D=L.effect=new wl(P);L.scope.off();const z=L.update=D.run.bind(D),V=L.job=D.runIfDirty.bind(D);V.i=L,V.id=L.uid,D.scheduler=()=>Vo(V),_i(L,!0),z()},T=(L,K,v)=>{K.component=L;const G=L.vnode.props;L.vnode=K,L.next=null,_u(L,K.props,G,v),Tu(L,K.children,v),oi(),mr(L),ri()},B=(L,K,v,G,W,C,$,P,D=!1)=>{const z=L&&L.children,V=L?L.shapeFlag:0,J=K.children,{patchFlag:re,shapeFlag:oe}=K;if(re>0){if(re&128){X(z,J,v,G,W,C,$,P,D);return}else if(re&256){R(z,J,v,G,W,C,$,P,D);return}}oe&8?(V&16&&ge(z,W,C),J!==z&&d(v,J)):V&16?oe&16?X(z,J,v,G,W,C,$,P,D):ge(z,W,C,!0):(V&8&&d(v,""),oe&16&&N(J,v,G,W,C,$,P,D))},R=(L,K,v,G,W,C,$,P,D)=>{L=L||Ji,K=K||Ji;const z=L.length,V=K.length,J=Math.min(z,V);let re;for(re=0;re<J;re++){const oe=K[re]=D?ei(K[re]):jt(K[re]);m(L[re],oe,v,null,W,C,$,P,D)}z>V?ge(L,W,C,!0,!1,J):N(K,v,G,W,C,$,P,D,J)},X=(L,K,v,G,W,C,$,P,D)=>{let z=0;const V=K.length;let J=L.length-1,re=V-1;for(;z<=J&&z<=re;){const oe=L[z],me=K[z]=D?ei(K[z]):jt(K[z]);if(gn(oe,me))m(oe,me,v,null,W,C,$,P,D);else break;z++}for(;z<=J&&z<=re;){const oe=L[J],me=K[re]=D?ei(K[re]):jt(K[re]);if(gn(oe,me))m(oe,me,v,null,W,C,$,P,D);else break;J--,re--}if(z>J){if(z<=re){const oe=re+1,me=oe<V?K[oe].el:G;for(;z<=re;)m(null,K[z]=D?ei(K[z]):jt(K[z]),v,me,W,C,$,P,D),z++}}else if(z>re)for(;z<=J;)Y(L[z],W,C,!0),z++;else{const oe=z,me=z,ie=new Map;for(z=me;z<=re;z++){const ot=K[z]=D?ei(K[z]):jt(K[z]);ot.key!=null&&ie.set(ot.key,z)}let ne,Ce=0;const Me=re-me+1;let Ne=!1,Oe=0;const De=new Array(Me);for(z=0;z<Me;z++)De[z]=0;for(z=oe;z<=J;z++){const ot=L[z];if(Ce>=Me){Y(ot,W,C,!0);continue}let Je;if(ot.key!=null)Je=ie.get(ot.key);else for(ne=me;ne<=re;ne++)if(De[ne-me]===0&&gn(ot,K[ne])){Je=ne;break}Je===void 0?Y(ot,W,C,!0):(De[Je-me]=z+1,Je>=Oe?Oe=Je:Ne=!0,m(ot,K[Je],v,null,W,C,$,P,D),Ce++)}const Jt=Ne?Bu(De):Ji;for(ne=Jt.length-1,z=Me-1;z>=0;z--){const ot=me+z,Je=K[ot],Nt=K[ot+1],Hi=ot+1<V?Nt.el||ca(Nt):G;De[z]===0?m(null,Je,v,Hi,W,C,$,P,D):Ne&&(ne<0||z!==Jt[ne]?U(Je,v,Hi,2):ne--)}}},U=(L,K,v,G,W=null)=>{const{el:C,type:$,transition:P,children:D,shapeFlag:z}=L;if(z&6){U(L.component.subTree,K,v,G);return}if(z&128){L.suspense.move(K,v,G);return}if(z&64){$.move(L,K,v,Z);return}if($===Ke){n(C,K,v);for(let J=0;J<D.length;J++)U(D[J],K,v,G);n(L.anchor,K,v);return}if($===ns){_(L,K,v);return}if(G!==2&&z&1&&P)if(G===0)P.persisted&&!C[Zs]?n(C,K,v):(P.beforeEnter(C),n(C,K,v),xt(()=>P.enter(C),W));else{const{leave:J,delayLeave:re,afterLeave:oe}=P,me=()=>{L.ctx.isUnmounted?s(C):n(C,K,v)},ie=()=>{const ne=C._isLeaving||!!C[Zs];C._isLeaving&&C[Zs](!0),P.persisted&&!ne?me():J(C,()=>{me(),oe&&oe()})};re?re(C,me,ie):ie()}else n(C,K,v)},Y=(L,K,v,G=!1,W=!1)=>{const{type:C,props:$,ref:P,children:D,dynamicChildren:z,shapeFlag:V,patchFlag:J,dirs:re,cacheIndex:oe,memo:me}=L;if(J===-2&&(W=!1),P!=null&&(oi(),_n(P,null,v,L,!0),ri()),oe!=null&&(K.renderCache[oe]=void 0),V&256){K.ctx.deactivate(L);return}const ie=V&1&&re,ne=!en(L);let Ce;if(ne&&(Ce=$&&$.onVnodeBeforeUnmount)&&zt(Ce,K,L),V&6)ce(L.component,v,G);else{if(V&128){L.suspense.unmount(v,G);return}ie&&Si(L,null,K,"beforeUnmount"),V&64?L.type.remove(L,K,v,Z,G):z&&!z.hasOnce&&(C!==Ke||J>0&&J&64)?ge(z,K,v,!1,!0):(C===Ke&&J&384||!W&&V&16)&&ge(D,K,v),G&&se(L)}const Me=me!=null&&oe==null;(ne&&(Ce=$&&$.onVnodeUnmounted)||ie||Me)&&xt(()=>{Ce&&zt(Ce,K,L),ie&&Si(L,null,K,"unmounted"),Me&&(L.el=null)},v)},se=L=>{const{type:K,el:v,anchor:G,transition:W}=L;if(K===Ke){ae(v,G);return}if(K===ns){M(L);return}const C=()=>{s(v),W&&!W.persisted&&W.afterLeave&&W.afterLeave()};if(L.shapeFlag&1&&W&&!W.persisted){const{leave:$,delayLeave:P}=W,D=()=>$(v,C);P?P(L.el,C,D):D()}else C()},ae=(L,K)=>{let v;for(;L!==K;)v=g(L),s(L),L=v;s(K)},ce=(L,K,v)=>{const{bum:G,scope:W,job:C,subTree:$,um:P,m:D,a:z}=L;$r(D),$r(z),G&&is(G),W.stop(),C&&(C.flags|=8,Y($,L,K,v)),P&&xt(P,K),xt(()=>{L.isUnmounted=!0},K)},ge=(L,K,v,G=!1,W=!1,C=0)=>{for(let $=C;$<L.length;$++)Y(L[$],K,v,G,W)},Te=L=>{if(L.shapeFlag&6)return Te(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const K=g(L.anchor||L.el),v=K&&K[Kd];return v?g(v):K};let xe=!1;const fe=(L,K,v)=>{let G;L==null?K._vnode&&(Y(K._vnode,null,null,!0),G=K._vnode.component):m(K._vnode||null,L,K,null,null,null,v),K._vnode=L,xe||(xe=!0,mr(G),Nl(),xe=!1)},Z={p:m,um:Y,m:U,r:se,mt:k,mc:N,pc:B,pbc:F,n:Te,o:e};return{render:fe,hydrate:void 0,createApp:mu(fe)}}function Xs({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function _i({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Mu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function la(e,t,i=!1){const n=e.children,s=t.children;if(Ie(n)&&Ie(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=ei(s[o]),r.el=l.el),!i&&r.patchFlag!==-2&&la(l,r)),r.type===Ns&&(r.patchFlag===-1&&(r=s[o]=ei(r)),r.el=l.el),r.type===ai&&!r.el&&(r.el=l.el)}}function Bu(e){const t=e.slice(),i=[0];let n,s,o,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,l=i.length-1;o<l;)r=o+l>>1,e[i[r]]<c?o=r+1:l=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,l=i[o-1];o-- >0;)i[o]=l,l=t[l];return i}function aa(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:aa(t)}function $r(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ca(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ca(t.subTree):null}const da=e=>e.__isSuspense;function Du(e,t){t&&t.pendingBranch?Ie(e)?t.effects.push(...e):t.effects.push(e):Fd(e)}const Ke=Symbol.for("v-fgt"),Ns=Symbol.for("v-txt"),ai=Symbol.for("v-cmt"),ns=Symbol.for("v-stc"),ni=[];let $t=null;function ee(e=!1){ni.push($t=e?null:[])}function Zo(){ni.pop(),$t=ni[ni.length-1]||null}let On=1;function Ir(e,t=!1){On+=e,e<0&&$t&&t&&($t.hasOnce=!0)}function ua(e){return e.dynamicChildren=On>0?$t||Ji:null,Zo(),On>0&&$t&&$t.push(e),e}function te(e,t,i,n,s,o){return ua(p(e,t,i,n,s,o,!0))}function Kt(e,t,i,n,s){return ua(le(e,t,i,n,s,!0))}function Jo(e){return e?e.__v_isVNode===!0:!1}function gn(e,t){return e.type===t.type&&e.key===t.key}const fa=({key:e})=>e??null,ss=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?Qe(e)||Ze(e)||Ae(e)?{i:at,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,n=0,s=null,o=e===Ke?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&fa(t),ref:t&&ss(t),scopeId:Hl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:at};return r?(xs(a,i),o&128&&e.normalize(a)):i&&(a.shapeFlag|=Qe(i)?8:16),On>0&&!l&&$t&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&$t.push(a),a}const le=Lu;function Lu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===ru)&&(e=ai),Jo(e)){const r=on(e,t,!0);return i&&xs(r,i),On>0&&!o&&$t&&(r.shapeFlag&6?$t[$t.indexOf(e)]=r:$t.push(r)),r.patchFlag=-2,r}if(Ku(e)&&(e=e.__vccOpts),t){t=Pu(t);let{class:r,style:a}=t;r&&!Qe(r)&&(t.class=_e(r)),Ue(a)&&(Uo(a)&&!Ie(a)&&(a=ct({},a)),t.style=Ut(a))}const l=Qe(e)?1:da(e)?128:Gd(e)?64:Ue(e)?4:Ae(e)?2:0;return p(e,t,i,n,s,l,o,!0)}function Pu(e){return e?Uo(e)||ta(e)?ct({},e):e:null}function on(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=e,c=t?Ru(s||{},t):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&fa(c),ref:t&&t.ref?i&&o?Ie(o)?o.concat(ss(t)):[o,ss(t)]:ss(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ke?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&on(e.ssContent),ssFallback:e.ssFallback&&on(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Ko(d,a.clone(d)),d}function St(e=" ",t=0){return le(Ns,null,e,t)}function gt(e,t){const i=le(ns,null,e);return i.staticCount=t,i}function Le(e="",t=!1){return t?(ee(),Kt(ai,null,e)):le(ai,null,e)}function jt(e){return e==null||typeof e=="boolean"?le(ai):Ie(e)?le(Ke,null,e.slice()):Jo(e)?ei(e):le(Ns,null,String(e))}function ei(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:on(e)}function xs(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ie(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),xs(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!ta(t)?t._ctx=at:s===3&&at&&(at.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ae(t)){if(n&65){xs(e,{default:t});return}t={default:t,_ctx:at},i=32}else t=String(t),n&64?(i=16,t=[St(t)]):i=8;e.children=t,e.shapeFlag|=i}function Ru(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(s==="style")t.style=Ut([t.style,n.style]);else if($s(s)){const o=t[s],l=n[s];l&&o!==l&&!(Ie(o)&&o.includes(l))?t[s]=o?[].concat(o,l):l:l==null&&o==null&&!Is(s)&&(t[s]=l)}else s!==""&&(t[s]=n[s])}return t}function zt(e,t,i,n=null){Ot(e,t,7,[i,n])}const Ou=Zl();let Nu=0;function zu(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Ou,o={uid:Nu++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new ud(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:na(n,s),emitsOptions:Jl(n,s),emit:null,emitted:null,propsDefaults:Ve,inheritAttrs:n.inheritAttrs,ctx:Ve,data:Ve,props:Ve,attrs:Ve,slots:Ve,refs:Ve,setupState:Ve,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=vu.bind(null,o),e.ce&&e.ce(o),o}let ht=null;const Hu=()=>ht||at;let Ss,xo;{const e=Ms(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};Ss=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),xo=t("__VUE_SSR_SETTERS__",i=>Nn=i)}const Wn=e=>{const t=ht;return Ss(e),e.scope.on(),()=>{e.scope.off(),Ss(t)}},Tr=()=>{ht&&ht.scope.off(),Ss(null)};function pa(e){return e.vnode.shapeFlag&4}let Nn=!1;function Fu(e,t=!1,i=!1){t&&xo(t);const{props:n,children:s}=e.vnode,o=pa(e);Su(e,n,o,t),Iu(e,s,i||t);const l=o?ju(e,t):void 0;return t&&xo(!1),l}function ju(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,au);const{setup:n}=i;if(n){oi();const s=e.setupContext=n.length>1?Uu(e):null,o=Wn(e),l=jn(n,e,0,[e.props,s]),r=hl(l);if(ri(),o(),(r||e.sp)&&!en(e)&&Ul(e),r){if(l.then(Tr,Tr),t)return l.then(a=>{Er(e,a)}).catch(a=>{Ls(a,e,0)});e.asyncDep=l}else Er(e,l)}else ha(e)}function Er(e,t,i){Ae(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ue(t)&&(e.setupState=Pl(t)),ha(e)}function ha(e,t,i){const n=e.type;e.render||(e.render=n.render||qt);{const s=Wn(e);oi();try{cu(e)}finally{ri(),s()}}}const Wu={get(e,t){return ft(e,"get",""),e[t]}};function Uu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Wu),slots:e.slots,emit:e.emit,expose:t}}function zs(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Pl(Md(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Cn)return Cn[i](e)},has(t,i){return i in t||i in Cn}})):e.proxy}function Vu(e,t=!0){return Ae(e)?e.displayName||e.name:e.name||t&&e.__name}function Ku(e){return Ae(e)&&"__vccOpts"in e}const we=(e,t)=>Rd(e,t,Nn),Gu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let So;const Ar=typeof window<"u"&&window.trustedTypes;if(Ar)try{So=Ar.createPolicy("vue",{createHTML:e=>e})}catch{}const ma=So?e=>So.createHTML(e):e=>e,qu="http://www.w3.org/2000/svg",Yu="http://www.w3.org/1998/Math/MathML",Qt=typeof document<"u"?document:null,Mr=Qt&&Qt.createElement("template"),Zu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?Qt.createElementNS(qu,e):t==="mathml"?Qt.createElementNS(Yu,e):i?Qt.createElement(e,{is:i}):Qt.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>Qt.createTextNode(e),createComment:e=>Qt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Qt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const l=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Mr.innerHTML=ma(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Mr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Ju=Symbol("_vtc");function Xu(e,t,i){const n=e[Ju];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const _s=Symbol("_vod"),ga=Symbol("_vsh"),_o={name:"show",beforeMount(e,{value:t},{transition:i}){e[_s]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):vn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),vn(e,!0),n.enter(e)):n.leave(e,()=>{vn(e,!1)}):vn(e,t))},beforeUnmount(e,{value:t}){vn(e,t)}};function vn(e,t){e.style.display=t?e[_s]:"none",e[ga]=!t}const Qu=Symbol(""),ef=/(?:^|;)\s*display\s*:/;function tf(e,t,i){const n=e.style,s=Qe(i);let o=!1;if(i&&!s){if(t)if(Qe(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&yn(n,r,"")}else for(const l in t)i[l]==null&&yn(n,l,"");for(const l in i){l==="display"&&(o=!0);const r=i[l];r!=null?sf(e,l,!Qe(t)&&t?t[l]:void 0,r)||yn(n,l,r):yn(n,l,"")}}else if(s){if(t!==i){const l=n[Qu];l&&(i+=";"+l),n.cssText=i,o=ef.test(i)}}else t&&e.removeAttribute("style");_s in e&&(e[_s]=o?n.display:"",e[ga]&&(n.display="none"))}const Br=/\s*!important$/;function yn(e,t,i){if(Ie(i))i.forEach(n=>yn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=nf(e,t);Br.test(i)?e.setProperty(wi(n),i.replace(Br,""),"important"):e[n]=i}}const Dr=["Webkit","Moz","ms"],Qs={};function nf(e,t){const i=Qs[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return Qs[t]=n;n=Es(n);for(let s=0;s<Dr.length;s++){const o=Dr[s]+n;if(o in e)return Qs[t]=o}return t}function sf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&Qe(n)&&i===n}const Lr="http://www.w3.org/1999/xlink";function Pr(e,t,i,n,s,o=cd(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Lr,t.slice(6,t.length)):e.setAttributeNS(Lr,t,i):i==null||o&&!bl(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Pt(i)?String(i):i)}function Rr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?ma(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=bl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(s||t)}function mi(e,t,i,n){e.addEventListener(t,i,n)}function of(e,t,i,n){e.removeEventListener(t,i,n)}const Or=Symbol("_vei");function rf(e,t,i,n,s=null){const o=e[Or]||(e[Or]={}),l=o[t];if(n&&l)l.value=n;else{const[r,a]=cf(t);if(n){const c=o[t]=ff(n,s);mi(e,r,c,a)}else l&&(of(e,r,l,a),o[t]=void 0)}}const lf=/(Once|Passive|Capture)$/,af=/^on:?(?:Once|Passive|Capture)$/;function cf(e){let t,i;for(;(i=e.match(lf))&&!af.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):wi(e.slice(2)),t]}let eo=0;const df=Promise.resolve(),uf=()=>eo||(df.then(()=>eo=0),eo=Date.now());function ff(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ie(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Ot(c,t,5,r)}}else Ot(s,t,5,[n])};return i.value=e,i.attached=uf(),i}const Nr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,pf=(e,t,i,n,s,o)=>{const l=s==="svg";t==="class"?Xu(e,n,l):t==="style"?tf(e,i,n):$s(t)?Is(t)||rf(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):hf(e,t,n,l))?(Rr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Pr(e,t,n,l,o,t!=="value")):e._isVueCE&&(mf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!Qe(n)))?Rr(e,wt(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Pr(e,t,n,l))};function hf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Nr(t)&&Ae(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Nr(t)&&Qe(i)?!1:t in e}function mf(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(s=>wt(s)===n):Object.keys(i).some(s=>wt(s)===n)}const rn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ie(t)?i=>is(t,i):t};function gf(e){e.target.composing=!0}function zr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const si=Symbol("_assign");function Hr(e,t,i){return t&&(e=e.trim()),i&&(e=As(e)),e}const Co={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[si]=rn(s);const o=n||s.props&&s.props.type==="number";mi(e,t?"change":"input",l=>{l.target.composing||e[si](Hr(e.value,i,o))}),(i||o)&&mi(e,"change",()=>{e.value=Hr(e.value,i,o)}),t||(mi(e,"compositionstart",gf),mi(e,"compositionend",zr),mi(e,"change",zr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},l){if(e[si]=rn(l),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?As(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===a)||(e.value=a)}},Xn={deep:!0,created(e,t,i){e[si]=rn(i),mi(e,"change",()=>{const n=e._modelValue,s=zn(e),o=e.checked,l=e[si];if(Ie(n)){const r=Oo(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(an(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(va(e,o))})},mounted:Fr,beforeUpdate(e,t,i){e[si]=rn(i),Fr(e,t,i)}};function Fr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ie(t))s=Oo(t,n.props.value)>-1;else if(an(t))s=t.has(n.props.value);else{if(t===i)return;s=cn(t,va(e,!0))}e.checked!==s&&(e.checked=s)}const vf={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,mi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?As(zn(o)):zn(o));e[si](e.multiple?an(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,bs(()=>{e._assigning=!1})}),e[si]=rn(n)},mounted(e,{value:t}){jr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[si]=rn(i)},updated(e,{value:t}){e._assigning||jr(e,t)}};function jr(e,t){const i=e.multiple,n=Ie(t);if(!(i&&!n&&!an(t))){for(let s=0,o=e.options.length;s<o;s++){const l=e.options[s],r=zn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Oo(t,r)>-1}else l.selected=t.has(r);else if(cn(zn(l),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function zn(e){return"_value"in e?e._value:e.value}function va(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const bf=["ctrl","shift","alt","meta"],yf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>bf.some(i=>e[`${i}Key`]&&!t.includes(i))},Vt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let l=0;l<t.length;l++){const r=yf[t[l]];if(r&&r(s,t))return}return e(s,...o)}))},kf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},wf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=wi(s.key);if(t.some(l=>l===o||kf[l]===o))return e(s)}))},xf=ct({patchProp:pf},Zu);let Wr;function Sf(){return Wr||(Wr=Eu(xf))}const Xo=((...e)=>{const t=Sf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Cf(n);if(!s)return;const o=t._component;!Ae(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=i(s,!1,_f(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},t});function _f(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Cf(e){return Qe(e)?document.querySelector(e):e}const $f="slidev-config.json",ln={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},gi=Ds({...ln});function If(e){if(!e||typeof e!="object")return{...ln};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():ln.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Bi(e){if(!e||typeof e!="object")return{...gi};const t=e;return t.enableWebServeJump!==void 0&&(gi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(gi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(gi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...gi}}function Hs(){return{...gi}}function ba(e,t,i){const n=(e||ln.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${o}`}}const Ci={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Tf(e){var i,n,s,o,l,r;const t=Hs();return e?{theme:((i=e[En])==null?void 0:i.trim())||Ci.theme,aspectRatio:((n=e[An])==null?void 0:n.trim())||Ci.aspectRatio,highlighter:((s=e[al])==null?void 0:s.trim())||Ci.highlighter,defaultTransition:((o=e[Mn])==null?void 0:o.trim())||Ci.defaultTransition,colorSchema:((l=e[cl])==null?void 0:l.trim())||Ci.colorSchema,spacing:((r=e[fo])==null?void 0:r.trim())||Ci.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Ci,normalizeHeadingSizes:t.normalizeHeadingSizes}}function Cs(e){var i,n,s,o,l;const t=(i=e.ial)==null?void 0:i[Ei];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Ur(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[pt]&&(t.transition=e[pt].trim()),e[et]&&(t.background=e[et].trim()),e[Bt]&&(t.image=e[Bt].trim()),e[Ki]&&(t.class=e[Ki].trim()),e[kn]&&(t.spacing=e[kn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[Gi]&&(t.mask=e[Gi].trim()),e[qi]&&(t.maskRatio=e[qi].trim()),e[Yi]&&(t.maskStyle=e[Yi].trim()),e[Zi]&&(t.maskInitial=e[Zi].trim()),e[Us]&&(i=e[Us].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![ke,yt,Gi,qi,Yi,Zi,pt,et,Bt,Ki,kn,Us,Ei].includes(n)){const o=n.replace(/^custom-slidev-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function Ef(e){const t={};if(!e)return t;const i=e[it]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[qe]??e["slidev-role"],s=e[et]??e["slidev-background"];(n===dl||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ke]??e["slidev-layout"];o===hs||o===ms?t.imageLayout=o:(n===hs||n===ms)&&(t.imageLayout=n);const l=e[Ye]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Gt])try{const r=JSON.parse(e[Gt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Gt].trim()}}return e[Ni]&&(t.shikiLines=e[Ni].trim()),e[Bn]&&(t.maxHeight=e[Bn].trim()),e[$e]&&(t.slot=e[$e].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function ki(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function $n(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),f=d?d[1].length:0;f>=l?r.push(c.slice(l)):f>s?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function zi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function to(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function In(e){if(!e)return[];if(st(e)&&Yt(e)&&!di(e)){const n=un(e),s=[];for(const o of n)s.push(...In(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(zi);if(l.length>0)return l}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return zi(e)?[e]:[]}function Qo(e){var s;if(!e||!st(e)||!Yt(e)||di(e))return null;const t=un(e);if(t.length===0)return null;if(t.length===1&&st(t[0])&&Yt(t[0])){const o=Qo(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(st(o)){i.push(o);const l=((s=o.children)==null?void 0:s.filter(st))||[];i.push(...l)}const n=t.map(In);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=In(t[0]),l=In(t[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:i}}return null}function Af(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Qo(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=er(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:s}}function ya(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=un(e);if(t.length===0)return null;const i=[];for(const n of t){const s=In(n);if(s.length===0)return null;i.push(...s)}return i}function Mf(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=ya(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function Bf(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Qo(e);if(t&&t.items.length===4)return t.items;const i=ya(e);if(i&&i.length===4)return i;const n=un(e);return n.length===4?n:null}function Df(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(st(r)){const c=Bf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=i[0]);const l=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>ka(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function Lf(e,t,i){var d,f,g,u,h;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(Cs(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(m){const b=[];for(const y of m)st(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...a(y.children));return b}function c(m,b,y){const x={blockId:m,attrs:b,previousAttrs:y};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const m of l){const b=m.pageTargetId,y=t.find(I=>I.id===b),x=o.find(I=>I.pageTargetId===b);if(m.blocks.some(I=>{var w,N;return!!(di(I)||$o(I)&&(((w=I.ial)==null?void 0:w[ke])==="image-left"||((N=I.ial)==null?void 0:N[ke])==="image-right"))})){if(x){const I=x.headerId;if(I){c(I,{[$e]:""});const w=t.find(N=>N.id===I);w!=null&&w.ial&&(w.ial[$e]="")}for(const w of x.itemIds){c(w,{[$e]:""});const N=t.find(O=>O.id===w);N!=null&&N.ial&&(N.ial[$e]="")}}continue}let M=null,A=-1;for(let I=0;I<m.blocks.length;I++){const w=m.blocks[I],N=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const O of N){const F=Af(O);if(F){M=F,A=I;break}}if(M)break}if(M){const{superBlockNode:I,layout:w,items:N,slots:O}=M,q=m.blocks.slice(0,A).find(T=>ka(T)),S=q==null?void 0:q.id,H=((d=y==null?void 0:y.ial)==null?void 0:d[ke])||"",k=H==="clover",E=k?"clover":w;if(H!==E&&(c(b,{[ke]:E},{[ke]:H}),y&&(y.ial||(y.ial={}),y.ial[ke]=E)),q){const T=((f=q.ial)==null?void 0:f[$e])||"";T!=="header"&&(c(q.id,{[$e]:"header"},{[$e]:T}),q.ial||(q.ial={}),q.ial[$e]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[$e]:""});const T=t.find(B=>B.id===x.headerId);T&&(T.ial||(T.ial={}),T.ial[$e]="")}const j=[];for(let T=0;T<N.length;T++){const B=N[T],R=O[T];j.push(B.id);const X=((g=B.ial)==null?void 0:g[$e])||"";if(X!==R&&(c(B.id,{[$e]:R},{[$e]:X}),B.ial||(B.ial={}),B.ial[$e]=R),B.children&&B.children.length>0)for(const U of B.children)U.ial||(U.ial={}),U.ial[$e]!==R&&(U.ial[$e]=R)}if(x!=null&&x.itemIds){for(const T of x.itemIds)if(!j.includes(T)){c(T,{[$e]:""});const B=t.find(R=>R.id===T);B&&(B.ial||(B.ial={}),B.ial[$e]="")}}s.push({superBlockId:I.id,nestedSuperBlockIds:(u=M.nestedSuperBlocks)==null?void 0:u.map(T=>T.id),pageTargetId:b,headerId:S,itemIds:j,layout:k?"clover":w})}else{let I=!1;const w=[];for(const F of m.blocks){const q=st(F)?[F,...a(F.children||[])]:F.children?a(F.children):[];for(const S of q){const H=Mf(S);if(H){I=!0;for(const k of H.items)w.push(k.id)}}}const N=((h=y==null?void 0:y.ial)==null?void 0:h[ke])||"",O=Dn(N);if(x||I&&O){c(b,{[ke]:""},{[ke]:N}),y&&(y.ial||(y.ial={}),y.ial[ke]="");const F=x==null?void 0:x.headerId;if(F){c(F,{[$e]:""});const S=t.find(H=>H.id===F);S&&(S.ial||(S.ial={}),S.ial[$e]="")}const q=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of q){c(S,{[$e]:""});const H=t.find(k=>k.id===S);H&&(H.ial||(H.ial={}),H.ial[$e]="")}}}}return{changes:n,newTracked:s}}function st(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Yt(e){if(!st(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function $o(e){return!e||zi(e)||st(e)||!ki(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function er(e){var g;if(!e||!st(e)||!Yt(e))return null;const t=un(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const h=(((g=u.ial)==null?void 0:g.style)||u.style||"").trim();let m=null;if(h){const b=h.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((u,h)=>u+(h||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=i.map(u=>u!==null?u:a),d=c.reduce((u,h)=>u+h,0);if(d<=0)return null;const f=c.map(u=>u/d*100);if(f.length===2){const[u]=f;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const h=Math.round(u),m=100-h;return`${h}:${m}`}if(f.length===3){const[u,h,m]=f;if(u>=31&&u<=35&&h>=31&&h<=35&&m>=31&&m<=35)return"1:1:1";if(u>=23&&u<=27&&h>=48&&h<=52&&m>=23&&m<=27)return"1:2:1";if(u>=48&&u<=52&&h>=23&&h<=27&&m>=23&&m<=27)return"2:1:1";if(u>=23&&u<=27&&h>=23&&h<=27&&m>=48&&m<=52)return"1:1:2";if(u>=18&&u<=22&&h>=58&&h<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(u),y=Math.round(h),x=100-b-y;return`${b}:${y}:${x}`}return f.map(u=>Math.round(u)).join(":")}function di(e){if(!e||!st(e)||!Yt(e))return null;const t=(e.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=$o(t[0]),n=$o(t[t.length-1]),s=er(e)||void 0;if(i&&!n){const o=ki(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:hs,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=ki(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:ms,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Pf(e,t){const i=[];function n(s){for(const o of s){const l=di(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[ke];if(d!==a){const g={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[ke]=a,i.push(g),t&&t(g)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function un(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ka(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function $i(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,a);const d=a+c;let f=1,g=-1,u=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=d;let m;for(;(m=h.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){g=m.index,u=m.index+m[0].length;break}}else f++;if(g!==-1&&u!==-1){const b=e.slice(d,g);n+=i(b),s=u}else n+=e.slice(a,d),s=d}return n}function Rf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=o.index,a=o[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,f=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let h;for(;(h=u.exec(e))!==null;)if(h[0].startsWith("</")){if(d--,d===0){f=h.index,g=h.index+h[0].length;break}}else d++;if(f!==-1&&g!==-1){const m=e.slice(r,g),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,n=g}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Of(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=Rf(i);i=s;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=$i(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),f=c[3].trim();return`**${d}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=$i(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=$i(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let f="-";return d.includes("warn")?f="- ⚠️":d.includes("bad")?f="- ❌":d.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=$i(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=$i(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=$i(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=$i(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,g)=>Math.max(f,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,f)=>{const g=f.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function wa(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function Nf(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function zf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function xa(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Hf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function Qn(e,t,i,n){const s=t!=null&&t.trim()!=="",o=Hf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${e}

</div>`:e;if(s&&!o){if(r){const h=t.trim();let m="v-click";return h==="hide"?m="v-click.hide":h!==""&&h!=="+1"&&(m=`v-click="${h}"`),`<div ${m}${a}>

${e}

</div>`}return xa(e,t)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),f=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${f}${a}>

${e}

</div>`;const g=t.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${f}${a}>

${e}

</div>`}function Sa(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Ff(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function _a(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),f=Math.min(i,c.length),g=Math.floor(c.length/f),u=c.length%f;let h=0;for(let m=0;m<f;m++){const b=g+(m<u?1:0);d[m]=c.slice(h,h+b),h+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const f=d.match(/^col-(\d+)$/i);if(f){const g=parseInt(f[1],10);if(g>=1&&g<=i)return g}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let h=1;for(const m of e){const b=n(m);b!==null&&(h=b),u[h-1].push(m)}return u}const d=e.filter(u=>n(u)===1),f=e.filter(u=>n(u)===null),g=i-1;if(f.length>=g){const u=Math.floor(f.length/g),h=f.length%g,m=[d];let b=0;for(let y=0;y<g;y++){const x=u+(y<h?1:0);m.push(f.slice(b,b+x)),b+=x}return m}else if(f.length>0){const u=[d];for(let h=0;h<g;h++)u.push(h<f.length?[f[h]]:[]);return u}else return[d,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const f=r[d],g=d+1<i?r[d+1]:e.length;c[d]=e.slice(f,g)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let f=0;f<i;f++){const g=i-f,u=e.length-d,h=Math.ceil(u/g);c[f]=e.slice(d,d+h),d+=h}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),f=d.split(/\r?\n/),g=[];for(let m=0;m<f.length;m++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(f[m])&&g.push(m);if(g.length>=i){const m=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=g.length-b,M=Math.ceil(_/x),A=g[b],I=b+M<g.length?g[b+M]:f.length,w=f.slice(A,I).join(`
`);m[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:w,content:w}],b+=M}return m}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const m=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=u.length-b,M=Math.ceil(_/x),A=`<ul>
${u.slice(b,b+M).join(`
`)}
</ul>`;m[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:A,content:A}],b+=M}return m}const h=d.split(/\r?\n\s*\r?\n/).filter(m=>m.trim()!=="");if(h.length>=i){const m=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=h.length-b,M=Math.ceil(_/x),A=h.slice(b,b+M).join(`

`);m[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:A,content:A}],b+=M}return m}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Vr(e,t,i,n){var d;const s=Tf(t),o=[],l=Ur(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);let a=[];for(const f of i){if(Cs(f)){a=[];const u=Ur(f.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=f.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(f.id)||r.allBlockIds.push(f.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:f.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[f.id]},r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);continue}const g=(u,h)=>{var j,T,B,R;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const X=U=>{for(const Y of U)Y.id&&!r.allBlockIds.includes(Y.id)&&r.allBlockIds.push(Y.id),Y.children&&Y.children.length>0&&X(Y.children)};X(u.children)}let m=Jc(u),b=u.ial?{...u.ial}:{};const y=m.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...Xc(y[0]),...b},m=m.slice(0,y.index).trim()),u.type!=="c"&&!m.startsWith("```")&&(m=wa(m));let x=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(m=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=m.trim());const _=Ef(b);if(m=Qc(m,n),m=Yc(m,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const X=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],U=Y=>{for(const se of Y){if(se.ial)for(const[ae,ce]of Object.entries(se.ial))X.includes(ae)&&!b[ae]&&(b[ae]=ce);se.children&&se.children.length>0&&U(se.children)}};U(u.children)}const M=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(m);if(M){const X=b["custom-slidev-autoplay"]==="true",U=b["custom-slidev-loop"]==="true",Y=b["custom-slidev-muted"]==="true"||X,se=b["custom-slidev-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(ae,ce)=>{let ge=ce;return se?ge=ge.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ge)||(ge+=" controls"),X&&!/autoplay/i.test(ge)?ge+=" autoplay playsinline":!X&&b["custom-slidev-autoplay"]==="false"&&(ge=ge.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),U&&!/loop/i.test(ge)?ge+=" loop":!U&&b["custom-slidev-loop"]==="false"&&(ge=ge.replace(/\bloop\b/gi,"").trim()),Y&&!/muted/i.test(ge)?ge+=" muted":!Y&&b["custom-slidev-muted"]==="false"&&(ge=ge.replace(/\bmuted\b/gi,"").trim()),`<video ${ge.trim()}>`})}if(_.isBackground){const X=ki(m,u.content);if(X){r.frontmatter.background=Tt(X,n);return}}const A=di(u);if(A){r.frontmatter.layout=A.layout,r.frontmatter.image=Tt(A.imageUrl,n),!r.frontmatter.layoutRatio&&A.ratio&&(r.frontmatter.layoutRatio=A.ratio);for(const X of A.contentNodes)g(X);return}if(_.imageLayout==="image-left"||_.imageLayout==="image-right"){const X=ki(m,u.content);if(X){r.frontmatter.layout=_.imageLayout,r.frontmatter.image=Tt(X,n),!r.frontmatter.layoutRatio&&((j=u.ial)!=null&&j[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const X of u.children)g(X);return}const I=!!(_.slot||h!=null&&h.defaultSlot||r.frontmatter.layout==="clover"||Dn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(X=>{var U,Y;return((U=X.ial)==null?void 0:U[$e])||((Y=X.ial)==null?void 0:Y[Ye])})||_.slot||_.clicks||I)){for(const X of u.children)_.slot&&(!X.ial||!X.ial[$e])&&(X.ial||(X.ial={}),X.ial[$e]=_.slot),g(X,{...h,parentClicks:_.clicks||(h==null?void 0:h.parentClicks),defaultSlot:_.slot||(h==null?void 0:h.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!_.clicks||!!((T=u.children)!=null&&T.some(X=>{var U;return(U=X.ial)==null?void 0:U[Ye]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(zi(u)&&u.children&&u.children.length>0&&(I||_.clicks||u.children.some(X=>{var U;return(U=X.ial)==null?void 0:U[Ye]}))&&w){const X=!!(u.children&&u.children.length>=2),U=u.children.find(xe=>!!(xe.markdown||xe.content||"").trim())||u.children[0],Y=((B=U==null?void 0:U.ial)==null?void 0:B[Ye])||((R=U==null?void 0:U.ial)==null?void 0:R["custom-slidev-click"]),se=!!(!_.clicks&&X&&Y),ae=_.clicks||(se?Y:void 0)||(h==null?void 0:h.parentClicks),ce=u.id||(h==null?void 0:h.parentContainerId),ge=_.slot||(h==null?void 0:h.defaultSlot);let Te=!0;for(const xe of u.children){ge&&(!xe.ial||!xe.ial[$e])&&(xe.ial||(xe.ial={}),xe.ial[$e]=ge);const fe=!!(xe.markdown||xe.content||"").trim(),Z=Te&&fe;Z&&(xe.markdown&&(xe.markdown=$n(xe.markdown)),xe.content&&(xe.content=$n(xe.content)),Te=!1);let pe=xe;Z&&ae&&X&&(pe={...xe,ial:{...xe.ial||{}}},delete pe.ial[Ye],delete pe.ial["custom-slidev-click"]),g(pe,{parentClicks:ae,parentContainerId:ce,defaultSlot:ge})}return}if(_.isNote){const X=Sa(m);X&&(r.notes?r.notes+=`

`+X:r.notes=X),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:X||u.content||"",rawMarkdown:m,isNote:!0,attributes:u.ial});return}_.shikiLines&&(m=zf(m,_.shikiLines)),x=m.trim();const N=(u.content||"").trim();if(x==="::right::"||N==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const F=Ff(u);let q=_.slot,S=_.clicks,H=_.motion,k={...u.ial||{}};if(F!==null){for(;a.length>0&&a[a.length-1].level>=F;)a.pop();const X=a.length>0?a[a.length-1]:void 0;!q&&(X!=null&&X.slot)&&(q=X.slot),!S&&(X!=null&&X.clicks)&&!(h!=null&&h.parentContainerId)&&(S=X.clicks),!H&&(X!=null&&X.motion)&&(H=X.motion);const U={...(X==null?void 0:X.customAttrs)||{}};if(u.ial)for(const[Y,se]of Object.entries(u.ial))Y.startsWith("custom-slidev-")&&!Y.startsWith("custom-slidev-slide")&&(U[Y]=se);h!=null&&h.parentContainerId||a.push({level:F,slot:q,clicks:S,motion:H,customAttrs:U})}else{const X=a.length>0?a[a.length-1]:void 0;X&&(!q&&X.slot&&X.slot!=="header"&&(q=X.slot),!S&&X.clicks&&!(h!=null&&h.parentContainerId)&&(S=X.clicks),!H&&X.motion&&(H=X.motion),X.customAttrs&&(k={...X.customAttrs,...k}))}!q&&r.blocks.some(X=>X.slot==="slot-divider-right")&&(q="right"),!q&&(h!=null&&h.defaultSlot)&&(q=h.defaultSlot),q&&(k[$e]=q),S&&!k[Ye]&&(k[Ye]=S),H&&!k[Gt]&&(k[Gt]=JSON.stringify(H)),(M||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(k["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(k["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(k["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(k["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(k["custom-slidev-controls"]=b["custom-slidev-controls"]));const E={id:u.id,type:u.type,content:u.content||"",rawMarkdown:m,clicks:S,parentClicks:h==null?void 0:h.parentClicks,parentContainerId:h==null?void 0:h.parentContainerId,motion:H,shikiLines:_.shikiLines,slot:q,attributes:k,rawNode:u};r.blocks.push(E)};g(f)}for(let f=0;f<o.length;f++){const g=o[f],u=[],h={...g.frontmatter};f===0&&(h.theme=s.theme,h.aspectRatio=s.aspectRatio,h.highlighter=s.highlighter,h.transition=g.frontmatter.transition||s.defaultTransition);const m=Nf(h);m&&u.push(m);const b=g.blocks.filter(A=>A.slot!=="slot-divider-right"),y=A=>A.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return Qn(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),x=A=>{const I=A.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(I.length===0)return;const w=I[0],N=(w.rawMarkdown||w.content||"").trim();(zi(w)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(w.rawMarkdown=$n(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},_=A=>{var F,q;if(A.length===0)return"";x(A);const I=(F=A.find(S=>S.parentClicks))==null?void 0:F.parentClicks;if(!I)return A.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var H;return Qn(S.rawMarkdown,S.clicks,S.motion,(H=S.attributes)==null?void 0:H.style)}).join(`

`);const w=[];let N=[];const O=()=>{if(N.length===0)return;const S=N.map(H=>(H.rawMarkdown||H.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(xa(S,I)),N=[]};for(const S of A){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(O(),w.push(Qn(S.rawMarkdown,S.clicks,S.motion,(q=S.attributes)==null?void 0:q.style))):N.push(S)}return O(),w.join(`

`)},M=g.frontmatter.layout||"default";if(M==="clover"||Dn(M)){let A=[];const I=b.filter(S=>S.slot==="header");if(I.length>0)A=I;else if(b.length>0){const S=b.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));S&&(A=[S])}const w=b.filter(S=>!A.includes(S));let N=2;if(M==="clover")N=4;else if(M==="three-cols-header")N=3;else if(M==="two-cols-header")N=2;else{let S=0;for(const H of w){const k=(H.slot||"").match(/^col-(\d+)$/i);k&&(S=Math.max(S,parseInt(k[1],10)))}if(S>=2)N=S;else if(g.frontmatter.layoutRatio){const H=g.frontmatter.layoutRatio.trim();if(H.includes(":")){const k=H.split(":").map(E=>parseFloat(E.trim())).filter(E=>!isNaN(E)&&E>0);k.length>=2&&(N=k.length)}else{const k=H.split(/\s+/).filter(Boolean);k.length>=2&&(N=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(N=Math.min(6,w[0].children.length))}const O=_a(w,N);O.forEach((S,H)=>{const k=`col-${H+1}`;for(const E of S)(!E.slot||E.slot==="default")&&(E.slot=k);x(S)});const F=O.flat();if(w.length===1&&F.length>1){const S=g.blocks.findIndex(H=>H.id===w[0].id);S!==-1&&g.blocks.splice(S,1,...F)}const q=y(A);if(q&&u.push(q),M==="two-cols-header"&&N===2){const S=_(O[0]||[]),H=_(O[1]||[]);S&&u.push(`::left::

${S}`),H&&u.push(`::right::

${H}`)}else O.forEach((S,H)=>{const k=_(S);k&&u.push(`::col-${H+1}::

${k}`)})}else if(M==="two-cols"){const A=b.filter(O=>O.slot==="left"),I=b.filter(O=>O.slot==="right");x(A),x(I);const w=y(A.length>0?A:b.filter(O=>O.slot!=="right")),N=y(I);u.push(w),N&&u.push(`::right::

${N}`)}else for(const A of b)u.push(Qn(A.rawMarkdown,A.clicks,A.motion,(d=A.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=o.map(f=>f.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Io=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function jf(e){var s,o,l,r,a,c,d,f,g,u,h,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(g=b.light)!=null&&g.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(h=b.dark)!=null&&h.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Tn(e){const t=jf(e);return t?`${Io}

/* Custom Workspace Inline Styles */
${t}`:Io}function io(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function Wf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Uf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Wf(l)?n.push(o.id):i.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Vf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function To(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Kf(e,t,i,n=8,s){const o=new Map;for(const g of t)g!=null&&g.id&&o.set(g.id,g);const l=g=>({id:g.id,parent_id:g.parent_id,root_id:g.root_id||e,type:g.type,subType:g.subtype??g.subType??"",content:g.content||"",markdown:g.markdown||"",ial:i(g.id,g.ial),children:[]}),r=g=>{let u=g.parent_id,h=0;for(;u&&u!==e&&h++<16;){const m=o.get(u);if(!m||!Vf(m))return u;u=m.parent_id}return u||e},a=new Map;for(const g of t){if(!(g!=null&&g.id)||g.id===e||s&&s.size>0&&!s.has(g.id))continue;const u=r(g),h=a.get(u);h?h.push(g):a.set(u,[g])}if(s&&s.size>0)for(const g of a.values())g.sort((u,h)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(g,u)=>{const h=l(g);if(c.set(h.id,h),u>=n||!To(h))return h;const m=a.get(h.id);return m&&m.length>0&&(h.children=m.map(b=>d(b,u+1))),h};return{topLevel:(a.get(e)||[]).map(g=>d(g,0)),byId:c}}const Gf={getBlockAttrs:Do,getChildBlocks:us,getDocBlocksOrders:Kc,setBlockAttrs:je,sql:nn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Gc};class qf{constructor(t){ye(this,"deps");ye(this,"attrOverrides",new Map);ye(this,"trackedListSuperBlocks",new Map);ye(this,"fallbackWarnedDocId","");this.deps={...Gf,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,l]of Object.entries(i))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let E=0;E<o.length;E++)o[E]&&l.set(o[E],E);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Uf(s,c),f=new Map;if(Array.isArray(c))for(const E of c)E.id&&E.ial&&f.set(E.id,io(E.ial));const g=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(g).catch(()=>[])||[];if(Array.isArray(u)){for(const E of u)if(E.block_id&&E.name){let j=f.get(E.block_id);j||(j={},f.set(E.block_id,j)),j[E.name]=E.value||""}}const h=(E,j)=>{const T={...f.get(E)||(j?io(j):{})},B=this.attrOverrides.get(E);return B&&Object.assign(T,B),T},m=Array.isArray(c)&&c.length>0?Kf(t,c,h,8,l):null,b=s.map(E=>E.id).filter(Boolean),y=E=>({id:E.id,parent_id:E.parent_id,root_id:E.root_id||t,type:E.type,subType:E.subType,content:E.content||"",markdown:E.markdown||"",ial:h(E.id,E.ial),children:E.children}),x=async(E,j=0)=>{if(!E||j>8||!To(E))return;const T=await this.deps.getChildBlocks(E.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){E.children=T.filter(B=>B==null?void 0:B.id).map(B=>({id:B.id,parent_id:E.id,root_id:t,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:h(B.id,B.ial),children:[]}));for(const B of E.children)await x(B,j+1)}},_=new Map;for(const E of c)E!=null&&E.id&&_.set(E.id,E);const M=b.every(E=>{const j=_.get(E);return!j||!!j.type});let A=[],I=!1;if(m&&d.usable&&r&&M){this.fallbackWarnedDocId="";for(const[j,T]of d.leafPatch){const B=m.byId.get(j);B&&(B.content=T.content,B.markdown=T.markdown)}const E=new Map;for(const j of s)j!=null&&j.id&&E.set(j.id,j);for(const j of d.rebuildRoots){const T=m.byId.get(j),B=E.get(j);T&&B&&(T.content=B.content||"",T.markdown=B.markdown||""),await x(T)}for(const j of s){if(!(j!=null&&j.id)||m.byId.has(j.id))continue;const T=y(j);await x(T),m.byId.set(T.id,T),m.topLevel.push(T)}A=m.topLevel.filter(j=>l.has(j.id)).sort((j,T)=>(l.get(j.id)??0)-(l.get(T.id)??0))}else b.length>0?(I=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),A=s.map(E=>y(E))):m&&(A=m.topLevel);const w=async(E,j=0)=>{if(!(!E||E.length===0||j>8))for(const T of E){if(To(T)&&(!T.children||T.children.length===0)){let R=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!R||R.length===0){const X=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;R=await this.deps.sql(X).catch(()=>[])||[]}if(Array.isArray(R)&&R.length>0){const X=new Set(A.map(Y=>Y.id)),U=R.filter(Y=>Y.id!==T.id&&!X.has(Y.id));U.length>0&&(T.children=U.map(Y=>{const se=f.get(Y.id)||(Y.ial?io(Y.ial):{}),ae=this.attrOverrides.get(Y.id);return ae&&Object.assign(se,ae),{id:Y.id,parent_id:Y.parent_id||T.id,root_id:Y.root_id||t,type:Y.type,subType:Y.subType,content:Y.content||"",markdown:Y.markdown||"",ial:se}}))}}T.children&&T.children.length>0&&await w(T.children,j+1)}};I&&await w(A);const N=E=>{var j,T;for(const B of E)if(B.children&&B.children.length>0){N(B.children);for(const R of B.children)if(R.ial)for(const[X,U]of Object.entries(R.ial))X.startsWith("custom-slidev-")&&!((j=B.ial)!=null&&j[X])&&(B.ial||(B.ial={}),B.ial[X]=U);if(B.ial){for(const[R,X]of Object.entries(B.ial))if(R.startsWith("custom-slidev-"))for(const U of B.children)(U.type==="video"||U.type==="NodeVideo"||/<video\b/i.test(U.markdown||U.content||""))&&!((T=U.ial)!=null&&T[R])&&(U.ial||(U.ial={}),U.ial[R]=X)}}};N(A),Pf(A,E=>{const j={[ke]:E.layout};this.setBlockAttrOverride(E.blockId,j),(this.deps.setBlockAttrs||je)(E.blockId,j).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",B)})});const O=this.trackedListSuperBlocks.get(t)||[],F=Lf(t,A,{tracked:O,onTagChange:E=>{this.setBlockAttrOverride(E.blockId,E.attrs),E.blockId===t&&Object.assign(i,E.attrs);const j=B=>{for(const R of B)R.id===E.blockId&&(R.ial||(R.ial={}),Object.assign(R.ial,E.attrs)),R.children&&R.children.length>0&&j(R.children)};j(A),(this.deps.setBlockAttrs||je)(E.blockId,E.attrs).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",B)})}});this.trackedListSuperBlocks.set(t,F.newTracked);const q=new Set;for(const E of A){const j=E.markdown||E.content||"";if(j.includes("((")){const T=qc(j);for(const B of T)q.add(B.blockId)}}const S={};if(q.size>0){const E=Array.from(q).map(T=>`'${T}'`).join(","),j=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${E})`).catch(()=>[])||[];if(Array.isArray(j))for(const T of j)T.id&&(S[T.id]=T.markdown||T.content||"")}const H=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=Vr(t,i,A,{baseUrl:H,refContentMap:S});try{const E=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=Tn(E)}catch{k.customThemeCss=Tn(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Vr(t,{},[],{});return n.customThemeCss=Tn(null),n}}}const Pe=new qf;class tr{constructor(t){ye(this,"devServerUrl","http://localhost:3030");ye(this,"isConnected",!1);ye(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],f=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let g="";d.length>0?g=f?"":`---
${d.join(`
`)}
---

`:f||(g=`---

`);let u="";if(c.layout==="two-cols"){const m=r.blocks.filter(_=>_.slot!=="right"),b=r.blocks.filter(_=>_.slot==="right"),y=m.map(_=>_.rawMarkdown||_.content||"").join(`

`),x=b.map(_=>_.rawMarkdown||_.content||"").join(`

`);u=`${y}

::right::

${x}`}else u=r.blocks.map(m=>m.rawMarkdown||m.content||"").join(`

`);let h="";return r.notes&&r.notes.trim()&&(h=`

<!--
${r.notes.trim()}
-->`),`${g}${u}${h}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}function Yf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ct(e){const t=Yf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function ir(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Ct("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Ca(){var t,i;const e=ir();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ct("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Zf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Hn(){const e=ir();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Ct("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function $a(){var n,s;const e=ir(),t={...(e==null?void 0:e.env)||{}};if(Hn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Eo(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function Jf(){const e=Ct("os"),t=Ct("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class nr{constructor(t){ye(this,"runner");this.runner=t||nr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Ct("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Hn()==="win32",r=$a();return await new Promise(a=>{s(t,i,{timeout:5e3,shell:l,env:r},(c,d,f)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:f?String(f).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Ca(),i=Hn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:i,isDesktop:t}}}class Xf{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pageChangedHandlers",[]);ye(this,"readyHandlers",[]);ye(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidevBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Qf{constructor(t){ye(this,"childProcess",null);ye(this,"activePort",null);ye(this,"isRunning",!1);ye(this,"defaultPort");ye(this,"maxPortRetries");ye(this,"probeTimeoutMs");ye(this,"customSpawner");ye(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Ct("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=Hn()==="win32"?"npx.cmd":"npx",l=Eo(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let f=(a=Ct("child_process"))==null?void 0:a.spawn;if(!f){const h=await import("node:child_process").catch(()=>({}));f=h==null?void 0:h.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=$a();this.childProcess=f(o,r,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Hn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=Ct("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Un{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pendingMessages",[]);ye(this,"slideChangedHandlers",[]);ye(this,"blockClickedHandlers",[]);ye(this,"openInEditorHandlers",[]);ye(this,"clientReadyHandlers",[]);ye(this,"openPeekDrawerHandlers",[]);ye(this,"toggleFullscreenHandlers",[]);ye(this,"openPresenterHandlers",[]);ye(this,"captureProgressHandlers",[]);ye(this,"capturePageDoneHandlers",[]);ye(this,"captureCompleteHandlers",[]);ye(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var s;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const s=i.payload.blockId||i.payload.clickedBlockId||"";for(const o of this.openInEditorHandlers)o(s,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const s=i.payload.blockId||i.payload.url||"",o={peekType:i.payload.peekType,target:s,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(o)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const s of this.captureProgressHandlers)s(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(i.payload.captureError||"未知沙箱截图异常");break}}}const Ia={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},ep=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,tp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,ip=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,np=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,sp=`${Io}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function op(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class rp{constructor(t){ye(this,"workspacePath");ye(this,"slidesFileName");ye(this,"cliBridge",new tr);const i=Jf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Eo(o),a=Eo(l),c=op(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const _ of c){const M=Ia[_]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${_}
// #endregion snippet
`;d.set(_,M)}t.slides.some(_=>{var M;return((M=_.frontmatter)==null?void 0:M.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",ep),t.slides.some(_=>{var M;return((M=_.frontmatter)==null?void 0:M.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",tp),t.slides.some(_=>{var M;return((M=_.frontmatter)==null?void 0:M.layout)==="clover"})&&d.set("layouts/clover.vue",ip),d.set("setup/root.ts",np),d.set("styles/index.css",sp);const h=Ct("fs"),m=Ct("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(h&&m&&x)try{h.existsSync(y)||h.mkdirSync(y,{recursive:!0}),h.writeFileSync(a,s,"utf-8"),h.writeFileSync(r,n,"utf-8");for(const[_,M]of d.entries()){const A=m.join(y,_),I=m.dirname(A);h.existsSync(I)||h.mkdirSync(I,{recursive:!0}),h.existsSync(A)||h.writeFileSync(A,M,"utf-8")}b=!0}catch{}if(!b&&i)try{const _=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),M=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(l,!1,M),await i(o,!1,_);for(const[A,I]of d.entries()){const w=`${this.workspacePath}/${A}`,N=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await i(w,!1,N).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch(_){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String(_)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class lp{constructor(){ye(this,"mode","web-sandbox");ye(this,"webBridge");ye(this,"cliBridge");ye(this,"nativeBridge");ye(this,"processManager");ye(this,"scaffolder");ye(this,"envDetector");this.webBridge=new Un,this.cliBridge=new tr,this.nativeBridge=new Xf,this.processManager=new Qf,this.scaffolder=new rp,this.envDetector=new nr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const ap={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},cp={key:0},dp={key:1},up={key:2},fp={key:3},pp={key:4},hp={key:5},mp={key:6},gp={key:7},vp={key:8},bp={key:9},yp={key:10},kp={key:11},wp={key:12},xp={key:13},Sp={key:14},_p={key:15},Cp={key:16},$p={key:17},Ip={key:18},Tp={key:19},Ep={key:20},Ap={key:21},Mp={key:22},Bp={key:23},Dp={key:24},Lp={key:25},Pp={key:26},Rp={key:27},Op={key:28},Np={key:29},zp={key:30},Hp={key:31},Fp={key:32},jp={key:33},Wp={key:34},Up={key:35},Vp={key:36},Kp={key:37},Gp={key:38},qp={key:39},Yp={key:40},Zp={key:41},Jp={key:42},Xp={key:43},Qp={key:44},eh={key:45},th={key:46},ih={key:47},nh={key:48},sh={key:49},oh={key:50},rh={key:51},lh={key:52},ah={key:53},ch={key:54},dh={key:55},uh={key:56},fh={key:57},ph={key:58},hh={key:59},mh={key:60},gh={key:61},vh={key:62},bh={key:63},yh={key:64},kh={key:65},wh={key:66},xh={key:67},Sh={key:68},_h={key:69},Ch={key:70},$h={key:71},Ih=It({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(ee(),te("svg",ap,[e.name==="fullscreen"||e.name==="maximize"?(ee(),te("g",cp,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(ee(),te("g",dp,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(ee(),te("g",up,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(ee(),te("g",fp,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(ee(),te("g",pp,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(ee(),te("g",hp,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(ee(),te("g",mp,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(ee(),te("g",gp,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(ee(),te("g",vp,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(ee(),te("g",bp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(ee(),te("g",yp,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(ee(),te("g",kp,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(ee(),te("g",wp,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(ee(),te("g",xp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(ee(),te("g",Sp,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(ee(),te("g",_p,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(ee(),te("g",Cp,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(ee(),te("g",$p,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(ee(),te("g",Ip,[...i[18]||(i[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(ee(),te("g",Tp,[...i[19]||(i[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(ee(),te("g",Ep,[...i[20]||(i[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(ee(),te("g",Ap,[...i[21]||(i[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(ee(),te("g",Mp,[...i[22]||(i[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(ee(),te("g",Bp,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-c9ae5e24></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-c9ae5e24></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-c9ae5e24></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-c9ae5e24></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-c9ae5e24></path>',5)])])):e.name==="ratio"?(ee(),te("g",Dp,[...i[24]||(i[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(ee(),te("g",Lp,[...i[25]||(i[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(ee(),te("g",Pp,[...i[26]||(i[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(ee(),te("g",Rp,[...i[27]||(i[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(ee(),te("g",Op,[...i[28]||(i[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(ee(),te("g",Np,[...i[29]||(i[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(ee(),te("g",zp,[...i[30]||(i[30]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(ee(),te("g",Hp,[...i[31]||(i[31]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(ee(),te("g",Fp,[...i[32]||(i[32]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(ee(),te("g",jp,[...i[33]||(i[33]=[p("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(ee(),te("g",Wp,[...i[34]||(i[34]=[p("polyline",{points:"11 17 6 12 11 7"},null,-1),p("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(ee(),te("g",Up,[...i[35]||(i[35]=[p("polyline",{points:"13 17 18 12 13 7"},null,-1),p("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(ee(),te("g",Vp,[...i[36]||(i[36]=[p("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(ee(),te("g",Kp,[...i[37]||(i[37]=[p("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),p("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(ee(),te("g",Gp,[...i[38]||(i[38]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(ee(),te("g",qp,[...i[39]||(i[39]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(ee(),te("g",Yp,[...i[40]||(i[40]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(ee(),te("g",Zp,[...i[41]||(i[41]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(ee(),te("g",Jp,[...i[42]||(i[42]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(ee(),te("g",Xp,[...i[43]||(i[43]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-c9ae5e24></path><polyline points="14 2 14 8 20 8" data-v-c9ae5e24></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-c9ae5e24></line><line x1="16" y1="17" x2="8" y2="17" data-v-c9ae5e24></line><line x1="10" y1="9" x2="8" y2="9" data-v-c9ae5e24></line>',5)])])):e.name==="focus"||e.name==="target"?(ee(),te("g",Qp,[...i[44]||(i[44]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(ee(),te("g",eh,[...i[45]||(i[45]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(ee(),te("g",th,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-c9ae5e24></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-c9ae5e24></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-c9ae5e24></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-c9ae5e24></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(ee(),te("g",ih,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-c9ae5e24></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-c9ae5e24></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-c9ae5e24></line><line x1="5" y1="15" x2="8" y2="15" data-v-c9ae5e24></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-c9ae5e24></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-c9ae5e24></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-c9ae5e24></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(ee(),te("g",nh,[...i[48]||(i[48]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-c9ae5e24></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-c9ae5e24></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-c9ae5e24></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-c9ae5e24></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-c9ae5e24></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-c9ae5e24></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(ee(),te("g",sh,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-c9ae5e24></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-c9ae5e24></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-c9ae5e24></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-c9ae5e24></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-c9ae5e24></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-c9ae5e24></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-c9ae5e24></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-c9ae5e24></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-c9ae5e24></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(ee(),te("g",oh,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="5" y1="7" x2="13" y2="7" data-v-c9ae5e24></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-c9ae5e24></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-c9ae5e24></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-c9ae5e24></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-c9ae5e24></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-c9ae5e24></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-c9ae5e24></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(ee(),te("g",rh,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="12" y1="4" x2="12" y2="20" data-v-c9ae5e24></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-c9ae5e24></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-c9ae5e24></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-c9ae5e24></line><circle cx="15.5" cy="8.5" r="1.2" data-v-c9ae5e24></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-c9ae5e24></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(ee(),te("g",lh,[...i[52]||(i[52]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><line x1="12" y1="4" x2="12" y2="20" data-v-c9ae5e24></line><circle cx="6" cy="8.5" r="1.2" data-v-c9ae5e24></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-c9ae5e24></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-c9ae5e24></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-c9ae5e24></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-c9ae5e24></line>',7)])])):e.name==="layout-center"||e.name==="center"?(ee(),te("g",ah,[...i[53]||(i[53]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(ee(),te("g",ch,[...i[54]||(i[54]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><circle cx="8" cy="9" r="1.5" data-v-c9ae5e24></circle><line x1="14" y1="8" x2="9" y2="14" data-v-c9ae5e24></line><circle cx="15" cy="13" r="1.5" data-v-c9ae5e24></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-c9ae5e24></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(ee(),te("g",dh,[...i[55]||(i[55]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><circle cx="7.5" cy="9.5" r="2" data-v-c9ae5e24></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-c9ae5e24></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-c9ae5e24></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-c9ae5e24></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-c9ae5e24></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(ee(),te("g",uh,[...i[56]||(i[56]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-c9ae5e24></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-c9ae5e24></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-c9ae5e24></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-c9ae5e24></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(ee(),te("g",fh,[...i[57]||(i[57]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(ee(),te("g",ph,[...i[58]||(i[58]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(ee(),te("g",hh,[...i[59]||(i[59]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(ee(),te("g",mh,[...i[60]||(i[60]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(ee(),te("g",gh,[...i[61]||(i[61]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(ee(),te("g",vh,[...i[62]||(i[62]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(ee(),te("g",bh,[...i[63]||(i[63]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-c9ae5e24></line><line x1="4" y1="10" x2="4" y2="3" data-v-c9ae5e24></line><line x1="12" y1="21" x2="12" y2="12" data-v-c9ae5e24></line><line x1="12" y1="8" x2="12" y2="3" data-v-c9ae5e24></line><line x1="20" y1="21" x2="20" y2="16" data-v-c9ae5e24></line><line x1="20" y1="12" x2="20" y2="3" data-v-c9ae5e24></line><line x1="1" y1="14" x2="7" y2="14" data-v-c9ae5e24></line><line x1="9" y1="8" x2="15" y2="8" data-v-c9ae5e24></line><line x1="17" y1="16" x2="23" y2="16" data-v-c9ae5e24></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(ee(),te("g",yh,[...i[64]||(i[64]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(ee(),te("g",kh,[...i[65]||(i[65]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(ee(),te("g",wh,[...i[66]||(i[66]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(ee(),te("g",xh,[...i[67]||(i[67]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(ee(),te("g",Sh,[...i[68]||(i[68]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-c9ae5e24></rect><line x1="13" y1="8" x2="19" y2="8" data-v-c9ae5e24></line><line x1="13" y1="12" x2="19" y2="12" data-v-c9ae5e24></line><line x1="13" y1="16" x2="17" y2="16" data-v-c9ae5e24></line>',5)])])):e.name==="image-right"?(ee(),te("g",_h,[...i[69]||(i[69]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-c9ae5e24></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-c9ae5e24></rect><line x1="5" y1="8" x2="11" y2="8" data-v-c9ae5e24></line><line x1="5" y1="12" x2="11" y2="12" data-v-c9ae5e24></line><line x1="5" y1="16" x2="9" y2="16" data-v-c9ae5e24></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(ee(),te("g",Ch,[...i[70]||(i[70]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(ee(),te("g",$h,[...i[71]||(i[71]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Zt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},de=Zt(Ih,[["__scopeId","data-v-c9ae5e24"]]),Th={class:"spm-immersion-header"},Eh={class:"spm-immersion-header__left"},Ah={class:"spm-immersion-title"},Mh={class:"spm-immersion-header__center"},Bh={class:"spm-immersion-header__actions"},Dh=["aria-label"],Lh={class:"spm-immersion-body"},Ph=It({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Mt((ee(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Vt(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:o}),p("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",Th,[p("div",Eh,[Jn(a.$slots,"header-left",{},()=>[p("span",Ah,Se(e.title),1)])]),p("div",Mh,[Jn(a.$slots,"header-center",{},void 0)]),p("div",Bh,[Jn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Dh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[le(de,{name:"close"})])])]),p("div",Lh,[Jn(a.$slots,"default",{},void 0)])],2)],34)),[[_o,e.visible]])}}),Rh=Zt(Ph,[["__scopeId","data-v-3f1665db"]]),Oh={class:"spm-protyle-drawer"},Nh={class:"spm-protyle-drawer__subbar"},zh={class:"spm-protyle-drawer__nav"},Hh=["title"],Fh={class:"spm-protyle-drawer__actions"},jh=["aria-label"],Wh=["aria-label"],Uh=It({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=he(n.blockId),o=he(n.title||""),l=he(!1),r=he(!0),a=he(!1),c=he(""),d=gi,f=he([]),g=he(null);let u=null;Ri(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",f.value=[],m(w))}),dn(()=>{s.value&&m(s.value)}),Go(()=>{b()});async function h(w){try{const N=await nn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const O=N[0];c.value=O.root_id||"";const F=O.id===O.root_id||O.type==="d";a.value=F,r.value=!F,!o.value&&O.content&&(o.value=O.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function m(w,N){if(!g.value||!w)return;b(),await h(w),typeof N=="boolean"&&(r.value=!a.value&&N);let O,F;r.value&&!a.value?(O=["cb-get-all","cb-get-hl","cb-get-focus"],F={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(O=["cb-get-context","cb-get-hl"],F={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new ue.Protyle(n.plugin.app,g.value,{blockId:w,action:O,render:F}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(q){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",q)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}g.value&&(g.value.innerHTML="")}function y(){a.value||(r.value=!r.value,m(s.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function _(){if(s.value)try{ue.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function M(){var O;if(!s.value)return;const w=Hs(),N=ba(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const F=Ct("electron");(O=F==null?void 0:F.shell)!=null&&O.openExternal?F.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}i("external-jump",N)}function A(){if(f.value.length>0){const w=f.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,m(w.blockId,w.isFocusMode))}}function I(w){const N=w.target;if(!N)return;const O=N.closest('[data-type="block-ref"]');if(O){const q=O.getAttribute("data-id");if(q&&q!==s.value){w.preventDefault(),w.stopPropagation(),f.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=q,o.value=O.innerText.trim()||q,m(q);return}}const F=N.closest("a");if(F&&F.href&&F.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const q=F.href.replace("siyuan://blocks/","").split("?")[0];q&&q!==s.value&&(f.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=q,o.value=F.innerText.trim()||q,m(q))}}return(w,N)=>(ee(),te("div",Oh,[p("div",Nh,[p("div",zh,[f.value.length>0?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:A},[le(de,{name:"arrow-left"}),N[0]||(N[0]=p("span",null,"返回",-1))])):Le("",!0),p("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},Se(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:o.value||s.value},Se(o.value||s.value),9,Hh)]),p("div",Fh,[a.value?Le("",!0):(ee(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[le(de,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,Se(r.value?"块聚焦":"展开全文"),1)],10,jh)),p("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[le(de,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,Se(l.value?"编辑中":"只读"),1)],10,Wh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[le(de,{name:"window"}),N[1]||(N[1]=p("span",null,"独立窗口",-1))]),ve(d).enableWebServeJump?(ee(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:M},[le(de,{name:"external-link"}),N[2]||(N[2]=p("span",null,"外跳",-1))])):Le("",!0)])]),p("div",{ref_key:"mountEl",ref:g,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),Vh=Zt(Uh,[["__scopeId","data-v-7e586ef3"]]),Kh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Gh=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Kr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Ta(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function qh(e){const t=e.split(/[/?#]/)[0];return!t||Gh.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function Yh(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Ea(e){const t=Zh(e);return t.external||!t.url?t:{url:Yh(t.url),external:!1}}function Zh(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(ul(t))return{url:`/${fl(t)}`,external:!1};if(/^file:/i.test(t)){const n=Kr(Ta(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Kr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return Kh.test(t)?{url:t,external:!0}:qh(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Jh={class:"spm-webview-drawer"},Xh={class:"spm-webview-toolbar"},Qh={class:"spm-webview-toolbar__nav"},em=["disabled"],tm=["disabled"],im=["aria-label"],nm={class:"spm-webview-toolbar__address"},sm=["aria-label"],om={class:"spm-webview-toolbar__actions"},rm=["aria-label"],lm={class:"spm-zoom-controller"},am=["disabled"],cm=["disabled"],dm={key:1,class:"spm-webview-fallback"},um=["src"],fm={key:2,class:"spm-load-error"},pm={class:"spm-load-error__code"},hm={class:"spm-load-error__code-num"},mm={class:"spm-load-error__url"},gm={class:"spm-load-error__hint"},vm={class:"spm-load-error__actions"},Gr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Aa="siyuan-slidev-peek-view-mode";let Ma="desktop";function bm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Aa);if(e==="mobile"||e==="desktop")return e}catch{}return Ma}function ym(e){if(Ma=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Aa,e)}catch{}}function km(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const wm=It({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=he(Ca()&&!Zf()),o=he(n.url),l=he(n.url),r=n.url,a=he(!1),c=he(null),d=he(!1),f=he(!1),g=he(1),u=he(!1),h=he(bm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=we(()=>h.value==="mobile"?Gr:m||void 0),y=he(null),x=he(null);let _=null,M=null,A=null;Ri(()=>n.url,Z=>{Z&&Z!==o.value&&(o.value=Z,l.value=Z,h.value==="mobile"&&F(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z))}),Ri(()=>n.visible,Z=>{if(Z)se(),h.value==="mobile"&&F(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),dn(()=>{I(),x.value&&typeof ResizeObserver<"u"&&(_=new ResizeObserver(()=>{const Z=y.value;if(Z&&typeof Z.invalidate=="function")try{Z.invalidate()}catch{}}),_.observe(x.value)),M=Z=>{var L;const pe=Z.message||((L=Z.error)==null?void 0:L.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return Z.preventDefault(),Z.stopImmediatePropagation(),!0},window.addEventListener("error",M,!0),A=Z=>{const pe=Z.reason,L=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&Z.preventDefault()},window.addEventListener("unhandledrejection",A)}),Go(()=>{if(w(),_&&(_.disconnect(),_=null),M&&(window.removeEventListener("error",M,!0),M=null),A&&(window.removeEventListener("unhandledrejection",A),A=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function I(){const Z=y.value;Z&&(Z.addEventListener("dom-ready",N),Z.addEventListener("did-start-loading",q),Z.addEventListener("did-stop-loading",k),Z.addEventListener("did-navigate",E),Z.addEventListener("did-navigate-in-page",j),Z.addEventListener("new-window",T),Z.addEventListener("did-fail-load",S),Z.addEventListener("did-fail-provisional-load",S))}function w(){const Z=y.value;if(Z)try{Z.removeEventListener("dom-ready",N),Z.removeEventListener("did-start-loading",q),Z.removeEventListener("did-stop-loading",k),Z.removeEventListener("did-navigate",E),Z.removeEventListener("did-navigate-in-page",j),Z.removeEventListener("new-window",T),Z.removeEventListener("did-fail-load",S),Z.removeEventListener("did-fail-provisional-load",S)}catch{}}function N(){const Z=y.value;if(Z&&typeof Z.getUserAgent=="function"&&!m)try{const pe=Z.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}h.value==="mobile"&&F(!1),se(),B()}function O(){const Z=h.value==="mobile"?"desktop":"mobile";h.value=Z,ym(Z),F(!0)}function F(Z=!1){const pe=y.value;if(!pe)return;const L=h.value==="mobile"?Gr:m;if(typeof pe.setUserAgent=="function"&&L)try{pe.setUserAgent(L)}catch(K){console.warn("[WebviewPeekDrawer] setUserAgent error:",K)}if(Z&&typeof pe.reload=="function")try{pe.reload()}catch(K){console.warn("[WebviewPeekDrawer] reload error:",K)}}function q(){a.value=!0,c.value=null}function S(Z){if(Z&&Z.isMainFrame===!1||Z&&Number(Z.errorCode)===-3)return;const pe=String((Z==null?void 0:Z.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Z==null?void 0:Z.errorCode)??0),description:pe,validatedURL:String((Z==null?void 0:Z.validatedURL)||o.value),hint:km(pe)},a.value=!1}function H(){c.value=null,U()}function k(){if(a.value=!1,B(),y.value&&typeof y.value.getURL=="function"){const Z=y.value.getURL();Z&&Z!=="about:blank"&&(o.value=Z,l.value=Z)}}function E(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),B()}function j(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),B()}function T(Z){Z&&Z.url&&(Z.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url))}function B(){const Z=y.value;Z&&(typeof Z.canGoBack=="function"&&(d.value=Z.canGoBack()),typeof Z.canGoForward=="function"&&(f.value=Z.canGoForward()))}function R(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function X(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function U(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function Y(){const Z=Ea(l.value);if(Z.url){if(Z.external){o.value=Z.url,fe();return}o.value=Z.url,l.value=Z.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url)}}function se(){const Z=y.value;if(Z&&typeof Z.setZoomFactor=="function")try{Z.setZoomFactor(g.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ae(){g.value=Math.min(2.5,Math.round((g.value+.1)*10)/10),se()}function ce(){g.value=Math.max(.5,Math.round((g.value-.1)*10)/10),se()}function ge(){g.value=1,se()}function Te(Z){Z.preventDefault(),Z.deltaY<0?ae():Z.deltaY>0&&ce()}async function xe(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Z){console.warn("Copy url failed:",Z)}}function fe(){var pe;const Z=o.value;if(typeof window<"u"){const L=Ct("electron");(pe=L==null?void 0:L.shell)!=null&&pe.openExternal?L.shell.openExternal(Z).catch(()=>{window.open(Z,"_blank")}):window.open(Z,"_blank")}i("external-jump",Z)}return(Z,pe)=>{const L=ou("webview");return ee(),te("div",Jh,[p("div",Xh,[p("div",Qh,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:R},[le(de,{name:"arrow-left"})],8,em),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:X},[le(de,{name:"arrow-right"})],8,tm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:U},[le(de,{name:"refresh"})],8,im)]),p("div",nm,[Mt(p("input",{"onUpdate:modelValue":pe[0]||(pe[0]=K=>l.value=K),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:wf(Y,["enter"])},null,544),[[Co,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:xe},[le(de,{name:"copy"})],8,sm)]),p("div",om,[p("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":h.value==="mobile"}]),"aria-label":h.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:O},[le(de,{name:h.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,rm),p("div",lm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:g.value<=.5,onClick:ce},[le(de,{name:"minus"})],8,am),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ge},Se(Math.round(g.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:g.value>=2.5,onClick:ae},[le(de,{name:"plus"})],8,cm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[le(de,{name:"external-link"}),pe[1]||(pe[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:x,class:_e(["spm-webview-body",{"is-mobile":h.value==="mobile"}]),onWheel:Vt(Te,["ctrl"])},[p("div",{class:_e(["spm-webview-viewport",{"is-mobile":h.value==="mobile"}])},[s.value?(ee(),Kt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:ve(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ee(),te("div",dm,[p("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,um),p("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(ee(),te("div",fm,[le(de,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",pm,[St(Se(c.value.description)+" ",1),p("span",hm,"("+Se(c.value.errorCode)+")",1)]),p("div",mm,Se(c.value.validatedURL),1),p("p",gm,Se(c.value.hint),1),p("div",vm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:H},[le(de,{name:"refresh"}),pe[3]||(pe[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[le(de,{name:"external-link"}),pe[4]||(pe[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Le("",!0)],2)],34)])}}}),xm=Zt(wm,[["__scopeId","data-v-192d3665"]]);class Sm{constructor(){ye(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class _m{constructor(t){ye(this,"blockToPageMap",new Map);ye(this,"debounceCtrl",new Sm);ye(this,"activeBlockId","");ye(this,"activePageIndex",1);ye(this,"currentDocId","");ye(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Oi(e,t){var o,l;if(!e||typeof document>"u")return!1;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ue.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function Cm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function $m(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else o.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Ba(e,t,i){var g,u,h,m;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const I=x[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const _=y.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const I=_[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:_[2],media:[]});continue}const M=y.match(/^(\s*)\d+\.\s+(.*)$/);if(M){l.length===0&&(r=!0);const I=M[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:M[2],media:[]});continue}const A=y.trim();if(!(!A||/^\{:.*?\}$/.test(A)))if(l.length>0){const I=A.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const O=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(I[1])}" src="${I[2]}" class="${O}" /></div>`);continue}if(A.match(/^<img\b[\s\S]*?\/?>$/i)){const N=A.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(A)){let N=A;if(!/<\/video>/i.test(N))for(;b+1<n.length&&!/<\/video>/i.test(N);)b++,N+=" "+n[b].trim();const O=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(N),F=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(N),q=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||O||/muted/i.test(N),S=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-controls"])==="false",H=N.match(/\bsrc=["']([^"']+)["']/i),k=H?H[1]:"",E=['class="slide-video-player"'];S||E.push("controls"),O&&(E.push("autoplay"),E.push("playsinline")),F&&E.push("loop"),q&&E.push("muted"),E.push('preload="metadata"'),k&&E.push(`src="${k}"`);const j=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let T=j?j[1].trim():"";!T&&k&&(T=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${q?"true":"false"}"><video ${E.join(" ")}>${T}</video></div>`);continue}l[l.length-1].text+=`
`+A}else o.push(A)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const y=Cm(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",_=b.level||0,M=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",A=_>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${A}"${M}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${x}</li>`}return`<li${A?` class="${A.trim()}"`:""}${M}>${y}${x}</li>`}).join(`
`);return`${$m(o)}<${a} class="${c}">
${d}
</${a}>`}function Im(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],f=d.trim();if(/^#{1,6}\s+/.test(f)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(f);continue}if(!f){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(f);continue}if(/<video\b/i.test(f)){l.length>0&&(o.push(l.join(`
`)),l=[]);let g=f;if(!/<\/video>/i.test(g))for(;c+1<s.length&&!/<\/video>/i.test(g);)c++,g+=`
`+s[c];o.push(g);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var h,m,b,y;const d=c.trim();if(!d)return"";const f=d.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const x=f[1].length;return`<h${x} class="slide-list-item-title">${rt(f[2].trim())}</h${x}>`}const g=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const x=/\.gif(?:\?|$)/i.test(g[2]),_=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(g[1])}" src="${g[2]}" class="${_}" /></div>`}if(/<video\b/i.test(d)){const x=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-loop"])==="true"||/loop/i.test(d),M=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),A=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-controls"])==="false",I=d.match(/\bsrc=["']([^"']+)["']/i),w=I?I[1]:"",N=['class="slide-video-player"'];A||N.push("controls"),x&&N.push("autoplay playsinline"),_&&N.push("loop"),M&&N.push("muted"),N.push('preload="metadata"'),w&&N.push(`src="${w}"`);const O=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let F=O?O[1].trim():"";return!F&&w&&(F=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${M?"true":"false"}"><video ${N.join(" ")}>${F}</video></div>`}const u=Ba(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(I=>I.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${rt(x[0])}</p>`;const _=x[0],A=x.slice(1).map(I=>rt(I)).join("<br/>");return`<p class="slide-list-item-title">${rt(_)}</p>
<p class="slide-list-item-desc">${A}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function no(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Da(e,t){var r,a,c,d,f,g,u,h;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=i==="cover"?null:s.find(no);if(i==="two-cols"){const m=s.some(q=>q.slot==="right");let b=[],y=[];if(m)b=s.filter(q=>q.slot!=="right"),y=s.filter(q=>q.slot==="right");else{const q=Math.ceil(s.length/2);b=s.slice(0,q),y=s.slice(q)}const x=q=>{const S=q.filter(H=>!!(H.rawMarkdown||H.content||"").trim());if(S.length>0){const H=S[0],k=(H.rawMarkdown||H.content||"").trim();(zi(H)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(H.rawMarkdown=$n(H.rawMarkdown||H.content||""),H.content=H.rawMarkdown)}};x(b),x(y);const _=b.map(q=>pi(q,t)).join(`
`),M=y.map(q=>pi(q,t)).join(`
`),A=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",I=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",N=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",F=`style="grid-template-columns: ${to((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${A}${I}" ${F}>
        <div class="${w}">${_}</div>
        <div class="${N}">${M}</div>
      </div>
    `}if(i==="clover"||Dn(i)){const m=i==="clover";let b=[];const y=s.filter(E=>E.slot==="header");if(y.length>0)b=y;else if(s.length>0){const E=s.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));E&&(b=[E])}const x=s.filter(E=>!b.includes(E));let _=2;if(m)_=4;else if(i==="three-cols-header")_=3;else if(i==="two-cols-header")_=2;else{let E=0;for(const j of x){const T=(j.slot||"").match(/^col-(\d+)$/i);T&&(E=Math.max(E,parseInt(T[1],10)))}if(E>=2)_=E;else if((d=e.frontmatter)!=null&&d.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const T=j.split(":").map(B=>parseFloat(B.trim())).filter(B=>!isNaN(B)&&B>0);T.length>=2&&(_=T.length)}else{const T=j.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(_=Math.min(6,x[0].children.length))}const M=_a(x,_),A=x.some(E=>E.slot&&/^(?:col-\d+|left|right)$/i.test(E.slot)),I=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Dn(i)&&A,w=E=>{const j=E.filter(B=>!!(B.rawMarkdown||B.content||"").trim());if(I&&j.length>0){const B=j[0],R=(B.rawMarkdown||B.content||"").trim();(zi(B)||/^(?:[-*+]|\d+\.)\s+/.test(R))&&(B.rawMarkdown=$n(B.rawMarkdown||B.content||""),B.content=B.rawMarkdown),B.isColFirst=!0}const T=I?j.find(no):null;return j.map(B=>pi(B,{...t,extraClassName:B===T?"slidev-col-first-heading-block":""})).join(`
`)},N=b.find(no),O=b.map(E=>pi(E,{...t,extraClassName:E===N?"slidev-page-first-heading-block":""})).join(`
`),F=m?"repeat(2, minmax(0, 1fr))":to((f=e.frontmatter)==null?void 0:f.layoutRatio,_),q=m?`style="grid-template-columns: ${F}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${F};"`,S=[m?"layout-clover-container":"layout-cols-header-container",_===2?"layout-two-cols-header-container":"",_===3?"layout-three-cols-header-container":"",`layout-${i}-container`,I?"has-superblock-cols":""].filter(Boolean).join(" "),H=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",_===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",_===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",I?"has-superblock-cols":""].filter(Boolean).join(" "),k=M.map((E,j)=>{const T=j+1;return`<div class="${["pdf-col",_===2&&T===1?"pdf-col--left":"",_===2&&T===2?"pdf-col--right":"",`pdf-col--${T}`,`col-${T}`].filter(Boolean).join(" ")}">${w(E)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${O}</div>
        <div class="${H}" ${q}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=s.map(I=>pi(I,t)).join(`
`),y=((g=e.frontmatter)==null?void 0:g.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${nt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,_=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,M=m?`${_}
${x}`:`${x}
${_}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${to((h=e.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${M}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:s.map(m=>pi(m,{...t,extraClassName:m===l?"slidev-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Tm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const Em=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=wa(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!Em.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=nt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,f)=>{const u=(r??a??c??d??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return i[r]||""}),s}function Am(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(s=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function so(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function qr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${so(e)}</span>`;const i=[];function n(o,l){return i.push(`<span class="${o}">${so(l)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=so(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>i[parseInt(l,10)]||""),s}function Mm(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Bm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const f=Mm(c,d+1);f&&o.push(f)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const f=[];for(const g of c){const u=a(g.children,d+1);d>=n?f.push({...g,children:u}):f.push(...u)}return f}return a(l,1)}function Dm(e,t=1,i={}){const n=Bm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const f=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const h=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",m=u.children&&u.children.length>0?r(u.children,d+1):"";let b=rt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${h}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${o}>${a}</div>`}function pi(e,t){var A,I,w,N,O,F,q,S,H,k;let i="",n="",s="";const o=[];(A=e.motion)!=null&&A.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const l=((I=e.attributes)==null?void 0:I.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${nt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",f=`${r}${i}${s}${a}${d}`,g=(e.rawMarkdown||e.content||"").trim();if(!g)return`<div class="${f}"${n}></div>`;if(g.includes('class="slidev-block-ref"')||g.includes('class="slidev-ref-tag"'))return`<div class="${f}"${n}>${g}</div>`;if(g.startsWith("$$")&&g.endsWith("$$")){const E=g.slice(2,-2).trim();return`<div class="${f} katex-display-container"${n}><div class="katex-display font-math"><em>${nt(E)}</em></div></div>`}const u=g.match(/^(#{1,6})\s+(.*)$/);if(u){const E=u[1].length,j=rt(u[2]),B=!!(e.isColFirst||e.type==="i"&&((w=t==null?void 0:t.extraClassName)!=null&&w.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><h${E}${B}>${j}</h${E}></div>`}if(g.startsWith(":::")){const E=g.split(`
`),T=E[0].replace(/^:::\s*/,"").trim()||"info",B=E.slice(1,E[E.length-1].startsWith(":::")?-1:void 0).join(`
`),R=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${n}><div class="${R} ${R}--${T}"><div class="${R}-title">${T.toUpperCase()}</div><div class="${R}-body">${rt(B)}</div></div></div>`}if(g.startsWith("<<<")){const T=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((U,Y)=>`<span class="code-line shiki-focus"><span class="line-no">${Y+1}</span><span class="line-content">${qr(U,"ts")}</span></span>`).join(`
`),B=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",R=((N=e.attrs)==null?void 0:N["custom-slidev-max-height"])||e.maxHeight||"",X=R?` style="max-height:${nt(R)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${B}"${X}><span class="lang-badge">TS</span><code>${T}</code></pre></div>`}if(g.startsWith("<style")||g.startsWith("<!-- Inline style -->")||g.startsWith(`<!--
Notes`))return"";if(g.startsWith("```")){const E=g.split(`
`),j=E[0].slice(3).trim(),T=j.match(/^([^\s{\[]+)/),B=T?T[1]:"",R=j.match(/\[([^\]]+)\]/),X=R?R[1]:"",U=j.includes("twoslash"),Y=e.shikiLines||((O=j.match(/\{([^}]+)\}/))==null?void 0:O[1])||"",se=Tm(Y),ae=E.length>2?E[E.length-1]==="```"?E.slice(1,-1):E.slice(1):[g.slice(3).replace(/```$/,"")],ce=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ge=X?`${ce} has-filename`:ce,Te=se!=="all",xe=ae.map((K,v)=>{const G=v+1,C=se==="all"||se.has(G)?"code-line shiki-focus":Te?"code-line shiki-dimmed":"code-line";let P=(t==null?void 0:t.highlight)===!0?qr(K,B):nt(K);return U&&K.includes("doubled.value = 2")?(P=P.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${C}"><span class="line-no">${G}</span><span class="line-content">${P}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${C}"><span class="line-no">${G}</span><span class="line-content">${P}</span></span>`}).join(`
`),fe=B?`<span class="lang-badge">${nt(B)}</span>`:"",Z=X?`<span class="code-filename">${nt(X)}</span>`:"",pe=((F=e.attrs)==null?void 0:F["custom-slidev-max-height"])||e.maxHeight||"",L=pe?` style="max-height:${nt(pe)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${ge}"${L}>${Z}${fe}<code>${xe}</code></pre></div>`}if(g.includes("|")&&g.split(`
`).filter(E=>E.trim().startsWith("|")).length>=2){const E=g.split(`
`).filter(T=>T.trim().startsWith("|")),j=Am(E,t==null?void 0:t.tableClassName);return`<div class="${f}"${n}>${j}</div>`}if(g.startsWith("> ")){const E=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${n}><blockquote class="${E}"><p>${rt(g.slice(2))}</p></blockquote></div>`}const h=/<video\b/i.test(g)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(g),b=/(?:^|\n)\s*#{1,6}\s+/.test(g);if(h&&!m&&!b&&!g.includes(`
`)){const E=((q=e.attributes)==null?void 0:q["custom-slidev-autoplay"])==="true"||/autoplay/i.test(g),j=((S=e.attributes)==null?void 0:S["custom-slidev-loop"])==="true"||/loop/i.test(g),T=((H=e.attributes)==null?void 0:H["custom-slidev-muted"])==="true"||E||/muted/i.test(g),B=((k=e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",R=g.match(/\bsrc=["']([^"']+)["']/i),X=R?R[1]:"",U=['class="slide-video-player"'];B||U.push("controls"),E&&(U.push("autoplay"),U.push("playsinline")),j&&U.push("loop"),T&&U.push("muted"),U.push('preload="metadata"'),X&&U.push(`src="${X}"`);const Y=g.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let se=Y?Y[1].trim():"";return!se&&X&&(se=`<source src="${X}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${E?"true":"false"}" data-muted="${T?"true":"false"}"${n}><video ${U.join(" ")}>${se}</video></div>`}const y=g.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const E=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${n}><img alt="${nt(y[1])}" src="${y[2]}" class="${E}" /></div>`}const x=Ba(g,t,e);if(x)return`<div class="${f} pdf-list-item"${n}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(g)&&!g.startsWith("```")){const E=g.match(/minDepth=["']?(\d+)["']?/i),j=g.match(/maxDepth=["']?(\d+)["']?/i),T=g.match(/columns=["']?(\d+)["']?/i),B=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${n}>${Dm(B,(t==null?void 0:t.currentPageIndex)||1,{minDepth:E?parseInt(E[1],10):1,maxDepth:j?parseInt(j[1],10):1/0,columns:T?parseInt(T[1],10):1,textSm:g.includes("text-sm")})}</div>`}if(g.includes(`
`)||b){const E=Im(g,t,e);if(E)return`<div class="${f}"${n}>${E}</div>`}const M=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><p${M}>${rt(g)}</p></div>`}function Lm(e){return`
    ${Tn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function Pm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Rm(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Om(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function Nm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function zm(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function Hm(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slidev-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slidev-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slidev-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slidev-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slidev-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function Fm(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function jm(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function Wm(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Um(){return[Pm(),Rm(),Om(),Nm(),zm(),Hm(),Fm(),jm(),Wm()].join("")}function La(e,t){const i="Slidev 演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(i)}</title>
  <style>
${Lm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Um()}
  <\/script>
</body>
</html>`}function Pa(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function Vm(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Km(e){const t=Vm(e==null?void 0:e.pageRatio);return`
    ${Tn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Gm(e,t){const i="Slidev 演示讲义",n="16:9",s="light",o=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",f=Da(l),g=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${f}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(i)} - 高保真讲义</title>
  <style>
    ${Km({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function Ra(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=Gm(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var es=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function qm(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ts(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var oo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Yr;function Ym(){return Yr||(Yr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var f=typeof ts=="function"&&ts;if(!d&&f)return f(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(h){var m=n[c][1][h];return l(m||h)},u,u.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ts=="function"&&ts,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(i,n,s){var o=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,f,g,u,h,m,b=[],y=0,x=a.length,_=x,M=o.getTypeOf(a)!=="string";y<a.length;)_=x-y,f=M?(c=a[y++],d=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),d=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),g=c>>2,u=(3&c)<<4|d>>4,h=1<_?(15&d)<<2|f>>6:64,m=2<_?63&f:64,b.push(r.charAt(g)+r.charAt(u)+r.charAt(h)+r.charAt(m));return b.join("")},s.decode=function(a){var c,d,f,g,u,h,m=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&_--,a.charAt(a.length-2)===r.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|_):new Array(0|_);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(g=r.indexOf(a.charAt(m++)))>>4,d=(15&g)<<4|(u=r.indexOf(a.charAt(m++)))>>2,f=(3&u)<<6|(h=r.indexOf(a.charAt(m++))),x[b++]=c,u!==64&&(x[b++]=d),h!==64&&(x[b++]=f);return x}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,f,g,u,h){this.compressedSize=d,this.uncompressedSize=f,this.crc32=g,this.compression=u,this.compressedContent=h}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return d.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,f,g){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(f.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,f,g){var u=l,h=g+f;c^=-1;for(var m=g;m<h;m++)c=c>>>8^u[255&(c^d[m])];return-1^c})(0|a,r,r.length,0):(function(c,d,f,g){var u=l,h=g+f;c^=-1;for(var m=g;m<h;m++)c=c>>>8^u[255&(c^d.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(f,g){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=g,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(g){f.push({data:g,meta:f.meta})}},s.compressWorker=function(f){return new d("Deflate",f)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(u,h){var m,b="";for(m=0;m<h;m++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,h,m,b,y,x){var _,M,A=u.file,I=u.compression,w=x!==c.utf8encode,N=r.transformTo("string",x(A.name)),O=r.transformTo("string",c.utf8encode(A.name)),F=A.comment,q=r.transformTo("string",x(F)),S=r.transformTo("string",c.utf8encode(F)),H=O.length!==A.name.length,k=S.length!==F.length,E="",j="",T="",B=A.dir,R=A.date,X={crc32:0,compressedSize:0,uncompressedSize:0};h&&!m||(X.crc32=u.crc32,X.compressedSize=u.compressedSize,X.uncompressedSize=u.uncompressedSize);var U=0;h&&(U|=8),w||!H&&!k||(U|=2048);var Y=0,se=0;B&&(Y|=16),y==="UNIX"?(se=798,Y|=(function(ce,ge){var Te=ce;return ce||(Te=ge?16893:33204),(65535&Te)<<16})(A.unixPermissions,B)):(se=20,Y|=(function(ce){return 63&(ce||0)})(A.dosPermissions)),_=R.getUTCHours(),_<<=6,_|=R.getUTCMinutes(),_<<=5,_|=R.getUTCSeconds()/2,M=R.getUTCFullYear()-1980,M<<=4,M|=R.getUTCMonth()+1,M<<=5,M|=R.getUTCDate(),H&&(j=o(1,1)+o(d(N),4)+O,E+="up"+o(j.length,2)+j),k&&(T=o(1,1)+o(d(q),4)+S,E+="uc"+o(T.length,2)+T);var ae="";return ae+=`
\0`,ae+=o(U,2),ae+=I.magic,ae+=o(_,2),ae+=o(M,2),ae+=o(X.crc32,4),ae+=o(X.compressedSize,4),ae+=o(X.uncompressedSize,4),ae+=o(N.length,2),ae+=o(E.length,2),{fileRecord:f.LOCAL_FILE_HEADER+ae+N+E,dirRecord:f.CENTRAL_FILE_HEADER+o(se,2)+ae+o(q.length,2)+"\0\0\0\0"+o(Y,4)+o(b,4)+N+E+q}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),f=i("../signature");function g(u,h,m,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(u){var h=u.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:m?(h+100*(m-b-1))/m:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var h=this.streamFiles&&!u.file.dir;if(h){var m=l(u,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var h=this.streamFiles&&!u.file.dir,m=l(u,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),h)this.push({data:(function(b){return f.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var m=this.bytesWritten-u,b=(function(y,x,_,M,A){var I=r.transformTo("string",A(M));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(x,4)+o(_,4)+o(I.length,2)+I})(this.dirRecords.length,m,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var h=this;return u.on("data",function(m){h.processChunk(m)}),u.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),u.on("error",function(m){h.error(m)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var h=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var m=0;m<h.length;m++)try{h[m].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,h=0;h<u.length;h++)u[h].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),l=i("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{r.forEach(function(g,u){f++;var h=(function(x,_){var M=x||_,A=o[M];if(!A)throw new Error(M+" is not a valid compression method !");return A})(u.options.compression,a.compression),m=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,y=u.date;u._compressWorker(h,m).withStreamInfo("file",{name:g,dir:b,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=f}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function f(g){return new l.Promise(function(u,h){var m=g.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){h(b)}).on("end",function(){m.streamInfo.crc32!==g.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(g,u){var h=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(m){var b=new a(u);return b.load(m),b}).then(function(m){var b=[l.Promise.resolve(m)],y=m.files;if(u.checkCRC32)for(var x=0;x<y.length;x++)b.push(f(y[x]));return l.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,x=0;x<y.length;x++){var _=y[x],M=_.fileNameStr,A=o.resolve(_.fileNameStr);h.file(A,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:u.createFolders}),_.dir||(h.file(A).unsafeOriginalName=M)}return b.zipComment.length&&(h.comment=b.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(f,g){d.push(f)||d._helper.pause(),c&&c(g)}).on("error",function(f){d.emit("error",f)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(A,I,w){var N,O=r.getTypeOf(I),F=r.extend(w||{},d);F.date=F.date||new Date,F.compression!==null&&(F.compression=F.compression.toUpperCase()),typeof F.unixPermissions=="string"&&(F.unixPermissions=parseInt(F.unixPermissions,8)),F.unixPermissions&&16384&F.unixPermissions&&(F.dir=!0),F.dosPermissions&&16&F.dosPermissions&&(F.dir=!0),F.dir&&(A=y(A)),F.createFolders&&(N=b(A))&&x.call(this,N,!0);var q=O==="string"&&F.binary===!1&&F.base64===!1;w&&w.binary!==void 0||(F.binary=!q),(I instanceof f&&I.uncompressedSize===0||F.dir||!I||I.length===0)&&(F.base64=!1,F.binary=!0,I="",F.compression="STORE",O="string");var S=null;S=I instanceof f||I instanceof a?I:h.isNode&&h.isStream(I)?new m(A,I):r.prepareContent(A,I,F.binary,F.optimizedBinaryString,F.base64);var H=new g(A,S,F);this.files[A]=H}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),f=i("./compressedObject"),g=i("./zipObject"),u=i("./generate"),h=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function(A){A.slice(-1)==="/"&&(A=A.substring(0,A.length-1));var I=A.lastIndexOf("/");return 0<I?A.substring(0,I):""},y=function(A){return A.slice(-1)!=="/"&&(A+="/"),A},x=function(A,I){return I=I!==void 0?I:d.createFolders,A=y(A),this.files[A]||o.call(this,A,null,{dir:!0,createFolders:I}),this.files[A]};function _(A){return Object.prototype.toString.call(A)==="[object RegExp]"}var M={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(A){var I,w,N;for(I in this.files)N=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&A(w,N)},filter:function(A){var I=[];return this.forEach(function(w,N){A(w,N)&&I.push(N)}),I},file:function(A,I,w){if(arguments.length!==1)return A=this.root+A,o.call(this,A,I,w),this;if(_(A)){var N=A;return this.filter(function(F,q){return!q.dir&&N.test(F)})}var O=this.files[this.root+A];return O&&!O.dir?O:null},folder:function(A){if(!A)return this;if(_(A))return this.filter(function(O,F){return F.dir&&A.test(O)});var I=this.root+A,w=x.call(this,I),N=this.clone();return N.root=w.name,N},remove:function(A){A=this.root+A;var I=this.files[A];if(I||(A.slice(-1)!=="/"&&(A+="/"),I=this.files[A]),I&&!I.dir)delete this.files[A];else for(var w=this.filter(function(O,F){return F.name.slice(0,A.length)===A}),N=0;N<w.length;N++)delete this.files[w[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(A){var I,w={};try{if((w=r.extend(A||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var N=w.comment||this.comment||"";I=u.generateWorker(this,w,N)}catch(O){(I=new a("error")).error(O)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(A,I){return this.generateInternalStream(A).accumulate(I)},generateNodeStream:function(A,I){return(A=A||{}).type||(A.type="nodebuffer"),this.generateInternalStream(A).toNodejsStream(I)}};n.exports=M},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),f=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===f)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),f=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&f===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(f){var g=o.getTypeOf(f);return o.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(f):l.uint8array?new d(o.transformTo("uint8array",f)):new r(o.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),l=i("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),l=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(h,m){return new d.Promise(function(b,y){var x=[],_=h._internalType,M=h._outputType,A=h._mimeType;h.on("data",function(I,w){x.push(I),m&&m(w)}).on("error",function(I){x=[],y(I)}).on("end",function(){try{var I=(function(w,N,O){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",N),O);case"base64":return a.encode(N);default:return o.transformTo(w,N)}})(M,(function(w,N){var O,F=0,q=null,S=0;for(O=0;O<N.length;O++)S+=N[O].length;switch(w){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(q=new Uint8Array(S),O=0;O<N.length;O++)q.set(N[O],F),F+=N[O].length;return q;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+w+"'")}})(_,x),A);b(I)}catch(w){y(w)}x=[]}).resume()})}function u(h,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=h.pipe(new l(y)),h.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(h){return g(this,h)},on:function(h,m){var b=this;return h==="data"?this._worker.on(h,function(y){m.call(b,y.data,y.meta)}):this._worker.on(h,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},h)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(h){var m,b,y,x,_,M=h.length,A=0;for(x=0;x<M;x++)(64512&(b=h.charCodeAt(x)))==55296&&x+1<M&&(64512&(y=h.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),A+=b<128?1:b<2048?2:b<65536?3:4;for(m=l.uint8array?new Uint8Array(A):new Array(A),x=_=0;_<A;x++)(64512&(b=h.charCodeAt(x)))==55296&&x+1<M&&(64512&(y=h.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?m[_++]=b:(b<2048?m[_++]=192|b>>>6:(b<65536?m[_++]=224|b>>>12:(m[_++]=240|b>>>18,m[_++]=128|b>>>12&63),m[_++]=128|b>>>6&63),m[_++]=128|63&b);return m})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(h){var m,b,y,x,_=h.length,M=new Array(2*_);for(m=b=0;m<_;)if((y=h[m++])<128)M[b++]=y;else if(4<(x=c[y]))M[b++]=65533,m+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&m<_;)y=y<<6|63&h[m++],x--;1<x?M[b++]=65533:y<65536?M[b++]=y:(y-=65536,M[b++]=55296|y>>10&1023,M[b++]=56320|1023&y)}return M.length!==b&&(M.subarray?M=M.subarray(0,b):M.length=b),o.applyFromCharCode(M)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(f,a),f.prototype.processChunk=function(u){var h=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=h;(h=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),h.set(m,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var b=(function(x,_){var M;for((_=_||x.length)>x.length&&(_=x.length),M=_-1;0<=M&&(192&x[M])==128;)M--;return M<0||M===0?_:M+c[x[M]]>_?M:_})(h),y=h;b!==h.length&&(l.uint8array?(y=h.subarray(0,b),this.leftOver=h.subarray(b,h.length)):(y=h.slice(0,b),this.leftOver=h.slice(b,h.length))),this.push({data:s.utf8decode(y),meta:u.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=f,o.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(m){return m}function d(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(m,b){s.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,b,y){var x=[],_=0,M=m.length;if(M<=y)return String.fromCharCode.apply(null,m);for(;_<M;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,m.slice(_,Math.min(_+y,M)))):x.push(String.fromCharCode.apply(null,m.subarray(_,Math.min(_+y,M)))),_+=y;return x.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(m){var b=65536,y=s.getTypeOf(m),x=!0;if(y==="uint8array"?x=f.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=f.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return f.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return f.stringifyByChar(m)}function u(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}s.applyFromCharCode=g;var h={};h.string={string:c,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return h.string.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:function(m){return d(m,r.allocBuffer(m.length))}},h.array={string:g,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},h.arraybuffer={string:function(m){return g(new Uint8Array(m))},array:function(m){return u(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},h.uint8array={string:g,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},h.nodebuffer={string:g,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return h.nodebuffer.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,b){if(b=b||"",!m)return b;s.checkSupport(m);var y=s.getTypeOf(b);return h[y][m](b)},s.resolve=function(m){for(var b=m.split("/"),y=[],x=0;x<b.length;x++){var _=b[x];_==="."||_===""&&x!==0&&x!==b.length-1||(_===".."?y.pop():y.push(_))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var b,y,x="";for(y=0;y<(m||"").length;y++)x+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},s.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},s.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},s.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},s.prepareContent=function(m,b,y,x,_){return a.Promise.resolve(b).then(function(M){return o.blob&&(M instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(M))!==-1)&&typeof FileReader<"u"?new a.Promise(function(A,I){var w=new FileReader;w.onload=function(N){A(N.target.result)},w.onerror=function(N){I(N.target.error)},w.readAsArrayBuffer(M)}):M}).then(function(M){var A=s.getTypeOf(M);return A?(A==="arraybuffer"?M=s.transformTo("uint8array",M):A==="string"&&(_?M=l.decode(M):y&&x!==!0&&(M=(function(I){return d(I,o.uint8array?new Uint8Array(I.length):new Array(I.length))})(M))),M):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(f){this.files=[],this.loadOptions=f}d.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(f)+")")}},isSignature:function(f,g){var u=this.reader.index;this.reader.setIndex(f);var h=this.reader.readString(4)===g;return this.reader.setIndex(u),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,f);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,g,u,h=this.zip64EndOfCentralSize-44;0<h;)f=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[f]={id:f,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,g;for(f=0;f<this.files.length;f++)g=this.files[f],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var g=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var h=g-u;if(0<h)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(f){this.reader=o(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),f=i("./support");function g(u,h){this.options=u,this.loadOptions=h}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var h,m;if(u.skip(22),this.fileNameLength=u.readInt(2),m=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var h=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(h),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var h,m,b,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)h=u.readInt(2),m=u.readInt(2),b=u.readData(m),this.extraFields[h]={id:h,length:m,value:b};u.setIndex(y)},handleUTF8:function(){var u=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var m=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var h=o(u.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var h=o(u.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(h,m,b){this.name=h,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(h){var m=null,b="string";try{if(!h)throw new Error("No output type specified.");var y=(b=h.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(m=m.pipe(new a.Utf8EncodeWorker)),!x&&y&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(_){(m=new d("error")).error(_)}return new l(m,b,"")},async:function(h,m){return this.internalStream(h).accumulate(m)},nodeStream:function(h,m){return this.internalStream(h||"nodebuffer").toNodejsStream(m)},_compressWorker:function(h,m){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,h,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<f.length;u++)o.prototype[f[u]]=g;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(h),f=o.document.createTextNode("");d.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){h(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(h,0)};else{var g=new o.MessageChannel;g.port1.onmessage=h,l=function(){g.port2.postMessage(0)}}var u=[];function h(){var m,b;r=!0;for(var y=u.length;y;){for(b=u,u=[],m=-1;++m<y;)b[m]();y=u.length}r=!1}n.exports=function(m){u.push(m)!==1||r||l()}}).call(this,typeof es<"u"?es:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function f(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&m(this,y)}function g(y,x,_){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function u(y,x,_){o(function(){var M;try{M=x(_)}catch(A){return r.reject(y,A)}M===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,M)})}function h(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function m(y,x){var _=!1;function M(w){_||(_=!0,r.reject(y,w))}function A(w){_||(_=!0,r.resolve(y,w))}var I=b(function(){x(A,M)});I.status==="error"&&M(I.value)}function b(y,x){var _={};try{_.value=y(x),_.status="success"}catch(M){_.status="error",_.value=M}return _}(n.exports=f).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(_){return x.resolve(y()).then(function(){return _})},function(_){return x.resolve(y()).then(function(){throw _})})},f.prototype.catch=function(y){return this.then(null,y)},f.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?u(_,this.state===c?y:x,this.outcome):this.queue.push(new g(_,y,x)),_},g.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},g.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},g.prototype.callRejected=function(y){r.reject(this.promise,y)},g.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,x){var _=b(h,x);if(_.status==="error")return r.reject(y,_.value);var M=_.value;if(M)m(y,M);else{y.state=c,y.outcome=x;for(var A=-1,I=y.queue.length;++A<I;)y.queue[A].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var _=-1,M=y.queue.length;++_<M;)y.queue[_].callRejected(x);return y},f.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},f.reject=function(y){var x=new this(l);return r.reject(x,y)},f.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,M=!1;if(!_)return this.resolve([]);for(var A=new Array(_),I=0,w=-1,N=new this(l);++w<_;)O(y[w],w);return N;function O(F,q){x.resolve(F).then(function(S){A[q]=S,++I!==_||M||(M=!0,r.resolve(N,A))},function(S){M||(M=!0,r.reject(N,S))})}},f.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,M=!1;if(!_)return this.resolve([]);for(var A=-1,I=new this(l);++A<_;)w=y[A],x.resolve(w).then(function(N){M||(M=!0,r.resolve(I,N))},function(N){M||(M=!0,r.reject(I,N))});var w;return I}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,f=0,g=-1,u=0,h=8;function m(y){if(!(this instanceof m))return new m(y);this.options=l.assign({level:g,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=o.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(_!==f)throw new Error(a[_]);if(x.header&&o.deflateSetHeader(this.strm,x.header),x.dictionary){var M;if(M=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(_=o.deflateSetDictionary(this.strm,M))!==f)throw new Error(a[_]);this._dict_set=!0}}function b(y,x){var _=new m(x);if(_.push(y,!0),_.err)throw _.msg||a[_.err];return _.result}m.prototype.push=function(y,x){var _,M,A=this.strm,I=this.options.chunkSize;if(this.ended)return!1;M=x===~~x?x:x===!0?4:0,typeof y=="string"?A.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?A.input=new Uint8Array(y):A.input=y,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(I),A.next_out=0,A.avail_out=I),(_=o.deflate(A,M))!==1&&_!==f)return this.onEnd(_),!(this.ended=!0);A.avail_out!==0&&(A.avail_in!==0||M!==4&&M!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(A.output,A.next_out))):this.onData(l.shrinkBuf(A.output,A.next_out)))}while((0<A.avail_in||A.avail_out===0)&&_!==1);return M===4?(_=o.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===f):M!==2||(this.onEnd(f),!(A.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=b,s.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},s.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),f=i("./zlib/gzheader"),g=Object.prototype.toString;function u(m){if(!(this instanceof u))return new u(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new f,o.inflateGetHeader(this.strm,this.header)}function h(m,b){var y=new u(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(m,b){var y,x,_,M,A,I,w=this.strm,N=this.options.chunkSize,O=this.options.dictionary,F=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?w.input=r.binstring2buf(m):g.call(m)==="[object ArrayBuffer]"?w.input=new Uint8Array(m):w.input=m,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(N),w.next_out=0,w.avail_out=N),(y=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&O&&(I=typeof O=="string"?r.string2buf(O):g.call(O)==="[object ArrayBuffer]"?new Uint8Array(O):O,y=o.inflateSetDictionary(this.strm,I)),y===a.Z_BUF_ERROR&&F===!0&&(y=a.Z_OK,F=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=r.utf8border(w.output,w.next_out),M=w.next_out-_,A=r.buf2string(w.output,_),w.next_out=M,w.avail_out=N-M,M&&l.arraySet(w.output,w.output,_,M,0),this.onData(A)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(F=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(m){this.chunks.push(m)},u.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=u,s.inflate=h,s.inflateRaw=function(m,b){return(b=b||{}).raw=!0,h(m,b)},s.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var f in d)d.hasOwnProperty(f)&&(a[f]=d[f])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,f,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+f),g);else for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,f,g,u,h;for(c=f=0,d=a.length;c<d;c++)f+=a[c].length;for(h=new Uint8Array(f),c=g=0,d=a.length;c<d;c++)u=a[c],h.set(u,g),g+=u.length;return h}},r={arraySet:function(a,c,d,f,g){for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(f,g){if(g<65537&&(f.subarray&&r||!f.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(f,g));for(var u="",h=0;h<g;h++)u+=String.fromCharCode(f[h]);return u}a[254]=a[254]=1,s.string2buf=function(f){var g,u,h,m,b,y=f.length,x=0;for(m=0;m<y;m++)(64512&(u=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(h=f.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),m++),x+=u<128?1:u<2048?2:u<65536?3:4;for(g=new o.Buf8(x),m=b=0;b<x;m++)(64512&(u=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(h=f.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),m++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},s.buf2binstring=function(f){return d(f,f.length)},s.binstring2buf=function(f){for(var g=new o.Buf8(f.length),u=0,h=g.length;u<h;u++)g[u]=f.charCodeAt(u);return g},s.buf2string=function(f,g){var u,h,m,b,y=g||f.length,x=new Array(2*y);for(u=h=0;u<y;)if((m=f[u++])<128)x[h++]=m;else if(4<(b=a[m]))x[h++]=65533,u+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&u<y;)m=m<<6|63&f[u++],b--;1<b?x[h++]=65533:m<65536?x[h++]=m:(m-=65536,x[h++]=55296|m>>10&1023,x[h++]=56320|1023&m)}return d(x,h)},s.utf8border=function(f,g){var u;for((g=g||f.length)>f.length&&(g=f.length),u=g-1;0<=u&&(192&f[u])==128;)u--;return u<0||u===0?g:u+a[f[u]]>g?u:g}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--f;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,f=c+a;l^=-1;for(var g=c;g<f;g++)l=l>>>8^d[255&(l^r[g])];return-1^l}},{}],46:[function(i,n,s){var o,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),f=0,g=4,u=0,h=-2,m=-1,b=4,y=2,x=8,_=9,M=286,A=30,I=19,w=2*M+1,N=15,O=3,F=258,q=F+O+1,S=42,H=113,k=1,E=2,j=3,T=4;function B(v,G){return v.msg=d[G],G}function R(v){return(v<<1)-(4<v?9:0)}function X(v){for(var G=v.length;0<=--G;)v[G]=0}function U(v){var G=v.state,W=G.pending;W>v.avail_out&&(W=v.avail_out),W!==0&&(l.arraySet(v.output,G.pending_buf,G.pending_out,W,v.next_out),v.next_out+=W,G.pending_out+=W,v.total_out+=W,v.avail_out-=W,G.pending-=W,G.pending===0&&(G.pending_out=0))}function Y(v,G){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,G),v.block_start=v.strstart,U(v.strm)}function se(v,G){v.pending_buf[v.pending++]=G}function ae(v,G){v.pending_buf[v.pending++]=G>>>8&255,v.pending_buf[v.pending++]=255&G}function ce(v,G){var W,C,$=v.max_chain_length,P=v.strstart,D=v.prev_length,z=v.nice_match,V=v.strstart>v.w_size-q?v.strstart-(v.w_size-q):0,J=v.window,re=v.w_mask,oe=v.prev,me=v.strstart+F,ie=J[P+D-1],ne=J[P+D];v.prev_length>=v.good_match&&($>>=2),z>v.lookahead&&(z=v.lookahead);do if(J[(W=G)+D]===ne&&J[W+D-1]===ie&&J[W]===J[P]&&J[++W]===J[P+1]){P+=2,W++;do;while(J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&J[++P]===J[++W]&&P<me);if(C=F-(me-P),P=me-F,D<C){if(v.match_start=G,z<=(D=C))break;ie=J[P+D-1],ne=J[P+D]}}while((G=oe[G&re])>V&&--$!=0);return D<=v.lookahead?D:v.lookahead}function ge(v){var G,W,C,$,P,D,z,V,J,re,oe=v.w_size;do{if($=v.window_size-v.lookahead-v.strstart,v.strstart>=oe+(oe-q)){for(l.arraySet(v.window,v.window,oe,oe,0),v.match_start-=oe,v.strstart-=oe,v.block_start-=oe,G=W=v.hash_size;C=v.head[--G],v.head[G]=oe<=C?C-oe:0,--W;);for(G=W=oe;C=v.prev[--G],v.prev[G]=oe<=C?C-oe:0,--W;);$+=oe}if(v.strm.avail_in===0)break;if(D=v.strm,z=v.window,V=v.strstart+v.lookahead,J=$,re=void 0,re=D.avail_in,J<re&&(re=J),W=re===0?0:(D.avail_in-=re,l.arraySet(z,D.input,D.next_in,re,V),D.state.wrap===1?D.adler=a(D.adler,z,re,V):D.state.wrap===2&&(D.adler=c(D.adler,z,re,V)),D.next_in+=re,D.total_in+=re,re),v.lookahead+=W,v.lookahead+v.insert>=O)for(P=v.strstart-v.insert,v.ins_h=v.window[P],v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+O-1])&v.hash_mask,v.prev[P&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=P,P++,v.insert--,!(v.lookahead+v.insert<O)););}while(v.lookahead<q&&v.strm.avail_in!==0)}function Te(v,G){for(var W,C;;){if(v.lookahead<q){if(ge(v),v.lookahead<q&&G===f)return k;if(v.lookahead===0)break}if(W=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),W!==0&&v.strstart-W<=v.w_size-q&&(v.match_length=ce(v,W)),v.match_length>=O)if(C=r._tr_tally(v,v.strstart-v.match_start,v.match_length-O),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=O){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else C=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(C&&(Y(v,!1),v.strm.avail_out===0))return k}return v.insert=v.strstart<O-1?v.strstart:O-1,G===g?(Y(v,!0),v.strm.avail_out===0?j:T):v.last_lit&&(Y(v,!1),v.strm.avail_out===0)?k:E}function xe(v,G){for(var W,C,$;;){if(v.lookahead<q){if(ge(v),v.lookahead<q&&G===f)return k;if(v.lookahead===0)break}if(W=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=O-1,W!==0&&v.prev_length<v.max_lazy_match&&v.strstart-W<=v.w_size-q&&(v.match_length=ce(v,W),v.match_length<=5&&(v.strategy===1||v.match_length===O&&4096<v.strstart-v.match_start)&&(v.match_length=O-1)),v.prev_length>=O&&v.match_length<=v.prev_length){for($=v.strstart+v.lookahead-O,C=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-O),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=$&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=O-1,v.strstart++,C&&(Y(v,!1),v.strm.avail_out===0))return k}else if(v.match_available){if((C=r._tr_tally(v,0,v.window[v.strstart-1]))&&Y(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return k}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(C=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<O-1?v.strstart:O-1,G===g?(Y(v,!0),v.strm.avail_out===0?j:T):v.last_lit&&(Y(v,!1),v.strm.avail_out===0)?k:E}function fe(v,G,W,C,$){this.good_length=v,this.max_lazy=G,this.nice_length=W,this.max_chain=C,this.func=$}function Z(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*A+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*M+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*M+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(v){var G;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=y,(G=v.state).pending=0,G.pending_out=0,G.wrap<0&&(G.wrap=-G.wrap),G.status=G.wrap?S:H,v.adler=G.wrap===2?0:1,G.last_flush=f,r._tr_init(G),u):B(v,h)}function L(v){var G=pe(v);return G===u&&(function(W){W.window_size=2*W.w_size,X(W.head),W.max_lazy_match=o[W.level].max_lazy,W.good_match=o[W.level].good_length,W.nice_match=o[W.level].nice_length,W.max_chain_length=o[W.level].max_chain,W.strstart=0,W.block_start=0,W.lookahead=0,W.insert=0,W.match_length=W.prev_length=O-1,W.match_available=0,W.ins_h=0})(v.state),G}function K(v,G,W,C,$,P){if(!v)return h;var D=1;if(G===m&&(G=6),C<0?(D=0,C=-C):15<C&&(D=2,C-=16),$<1||_<$||W!==x||C<8||15<C||G<0||9<G||P<0||b<P)return B(v,h);C===8&&(C=9);var z=new Z;return(v.state=z).strm=v,z.wrap=D,z.gzhead=null,z.w_bits=C,z.w_size=1<<z.w_bits,z.w_mask=z.w_size-1,z.hash_bits=$+7,z.hash_size=1<<z.hash_bits,z.hash_mask=z.hash_size-1,z.hash_shift=~~((z.hash_bits+O-1)/O),z.window=new l.Buf8(2*z.w_size),z.head=new l.Buf16(z.hash_size),z.prev=new l.Buf16(z.w_size),z.lit_bufsize=1<<$+6,z.pending_buf_size=4*z.lit_bufsize,z.pending_buf=new l.Buf8(z.pending_buf_size),z.d_buf=1*z.lit_bufsize,z.l_buf=3*z.lit_bufsize,z.level=G,z.strategy=P,z.method=W,L(v)}o=[new fe(0,0,0,0,function(v,G){var W=65535;for(W>v.pending_buf_size-5&&(W=v.pending_buf_size-5);;){if(v.lookahead<=1){if(ge(v),v.lookahead===0&&G===f)return k;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var C=v.block_start+W;if((v.strstart===0||v.strstart>=C)&&(v.lookahead=v.strstart-C,v.strstart=C,Y(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-q&&(Y(v,!1),v.strm.avail_out===0))return k}return v.insert=0,G===g?(Y(v,!0),v.strm.avail_out===0?j:T):(v.strstart>v.block_start&&(Y(v,!1),v.strm.avail_out),k)}),new fe(4,4,8,4,Te),new fe(4,5,16,8,Te),new fe(4,6,32,32,Te),new fe(4,4,16,16,xe),new fe(8,16,32,32,xe),new fe(8,16,128,128,xe),new fe(8,32,128,256,xe),new fe(32,128,258,1024,xe),new fe(32,258,258,4096,xe)],s.deflateInit=function(v,G){return K(v,G,x,15,8,0)},s.deflateInit2=K,s.deflateReset=L,s.deflateResetKeep=pe,s.deflateSetHeader=function(v,G){return v&&v.state?v.state.wrap!==2?h:(v.state.gzhead=G,u):h},s.deflate=function(v,G){var W,C,$,P;if(!v||!v.state||5<G||G<0)return v?B(v,h):h;if(C=v.state,!v.output||!v.input&&v.avail_in!==0||C.status===666&&G!==g)return B(v,v.avail_out===0?-5:h);if(C.strm=v,W=C.last_flush,C.last_flush=G,C.status===S)if(C.wrap===2)v.adler=0,se(C,31),se(C,139),se(C,8),C.gzhead?(se(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),se(C,255&C.gzhead.time),se(C,C.gzhead.time>>8&255),se(C,C.gzhead.time>>16&255),se(C,C.gzhead.time>>24&255),se(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),se(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(se(C,255&C.gzhead.extra.length),se(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(v.adler=c(v.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(se(C,0),se(C,0),se(C,0),se(C,0),se(C,0),se(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),se(C,3),C.status=H);else{var D=x+(C.w_bits-8<<4)<<8;D|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(D|=32),D+=31-D%31,C.status=H,ae(C,D),C.strstart!==0&&(ae(C,v.adler>>>16),ae(C,65535&v.adler)),v.adler=1}if(C.status===69)if(C.gzhead.extra){for($=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),U(v),$=C.pending,C.pending!==C.pending_buf_size));)se(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),U(v),$=C.pending,C.pending===C.pending_buf_size)){P=1;break}P=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,se(C,P)}while(P!==0);C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),P===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),U(v),$=C.pending,C.pending===C.pending_buf_size)){P=1;break}P=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,se(C,P)}while(P!==0);C.gzhead.hcrc&&C.pending>$&&(v.adler=c(v.adler,C.pending_buf,C.pending-$,$)),P===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&U(v),C.pending+2<=C.pending_buf_size&&(se(C,255&v.adler),se(C,v.adler>>8&255),v.adler=0,C.status=H)):C.status=H),C.pending!==0){if(U(v),v.avail_out===0)return C.last_flush=-1,u}else if(v.avail_in===0&&R(G)<=R(W)&&G!==g)return B(v,-5);if(C.status===666&&v.avail_in!==0)return B(v,-5);if(v.avail_in!==0||C.lookahead!==0||G!==f&&C.status!==666){var z=C.strategy===2?(function(V,J){for(var re;;){if(V.lookahead===0&&(ge(V),V.lookahead===0)){if(J===f)return k;break}if(V.match_length=0,re=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++,re&&(Y(V,!1),V.strm.avail_out===0))return k}return V.insert=0,J===g?(Y(V,!0),V.strm.avail_out===0?j:T):V.last_lit&&(Y(V,!1),V.strm.avail_out===0)?k:E})(C,G):C.strategy===3?(function(V,J){for(var re,oe,me,ie,ne=V.window;;){if(V.lookahead<=F){if(ge(V),V.lookahead<=F&&J===f)return k;if(V.lookahead===0)break}if(V.match_length=0,V.lookahead>=O&&0<V.strstart&&(oe=ne[me=V.strstart-1])===ne[++me]&&oe===ne[++me]&&oe===ne[++me]){ie=V.strstart+F;do;while(oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&oe===ne[++me]&&me<ie);V.match_length=F-(ie-me),V.match_length>V.lookahead&&(V.match_length=V.lookahead)}if(V.match_length>=O?(re=r._tr_tally(V,1,V.match_length-O),V.lookahead-=V.match_length,V.strstart+=V.match_length,V.match_length=0):(re=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++),re&&(Y(V,!1),V.strm.avail_out===0))return k}return V.insert=0,J===g?(Y(V,!0),V.strm.avail_out===0?j:T):V.last_lit&&(Y(V,!1),V.strm.avail_out===0)?k:E})(C,G):o[C.level].func(C,G);if(z!==j&&z!==T||(C.status=666),z===k||z===j)return v.avail_out===0&&(C.last_flush=-1),u;if(z===E&&(G===1?r._tr_align(C):G!==5&&(r._tr_stored_block(C,0,0,!1),G===3&&(X(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),U(v),v.avail_out===0))return C.last_flush=-1,u}return G!==g?u:C.wrap<=0?1:(C.wrap===2?(se(C,255&v.adler),se(C,v.adler>>8&255),se(C,v.adler>>16&255),se(C,v.adler>>24&255),se(C,255&v.total_in),se(C,v.total_in>>8&255),se(C,v.total_in>>16&255),se(C,v.total_in>>24&255)):(ae(C,v.adler>>>16),ae(C,65535&v.adler)),U(v),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?u:1)},s.deflateEnd=function(v){var G;return v&&v.state?(G=v.state.status)!==S&&G!==69&&G!==73&&G!==91&&G!==103&&G!==H&&G!==666?B(v,h):(v.state=null,G===H?B(v,-3):u):h},s.deflateSetDictionary=function(v,G){var W,C,$,P,D,z,V,J,re=G.length;if(!v||!v.state||(P=(W=v.state).wrap)===2||P===1&&W.status!==S||W.lookahead)return h;for(P===1&&(v.adler=a(v.adler,G,re,0)),W.wrap=0,re>=W.w_size&&(P===0&&(X(W.head),W.strstart=0,W.block_start=0,W.insert=0),J=new l.Buf8(W.w_size),l.arraySet(J,G,re-W.w_size,W.w_size,0),G=J,re=W.w_size),D=v.avail_in,z=v.next_in,V=v.input,v.avail_in=re,v.next_in=0,v.input=G,ge(W);W.lookahead>=O;){for(C=W.strstart,$=W.lookahead-(O-1);W.ins_h=(W.ins_h<<W.hash_shift^W.window[C+O-1])&W.hash_mask,W.prev[C&W.w_mask]=W.head[W.ins_h],W.head[W.ins_h]=C,C++,--$;);W.strstart=C,W.lookahead=O-1,ge(W)}return W.strstart+=W.lookahead,W.block_start=W.strstart,W.insert=W.lookahead,W.lookahead=0,W.match_length=W.prev_length=O-1,W.match_available=0,v.next_in=z,v.input=V,v.avail_in=D,W.wrap=P,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,l){var r,a,c,d,f,g,u,h,m,b,y,x,_,M,A,I,w,N,O,F,q,S,H,k,E;r=o.state,a=o.next_in,k=o.input,c=a+(o.avail_in-5),d=o.next_out,E=o.output,f=d-(l-o.avail_out),g=d+(o.avail_out-257),u=r.dmax,h=r.wsize,m=r.whave,b=r.wnext,y=r.window,x=r.hold,_=r.bits,M=r.lencode,A=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),N=M[x&I];t:for(;;){if(x>>>=O=N>>>24,_-=O,(O=N>>>16&255)===0)E[d++]=65535&N;else{if(!(16&O)){if((64&O)==0){N=M[(65535&N)+(x&(1<<O)-1)];continue t}if(32&O){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}F=65535&N,(O&=15)&&(_<O&&(x+=k[a++]<<_,_+=8),F+=x&(1<<O)-1,x>>>=O,_-=O),_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),N=A[x&w];i:for(;;){if(x>>>=O=N>>>24,_-=O,!(16&(O=N>>>16&255))){if((64&O)==0){N=A[(65535&N)+(x&(1<<O)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(q=65535&N,_<(O&=15)&&(x+=k[a++]<<_,(_+=8)<O&&(x+=k[a++]<<_,_+=8)),u<(q+=x&(1<<O)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=O,_-=O,(O=d-f)<q){if(m<(O=q-O)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(H=y,(S=0)===b){if(S+=h-O,O<F){for(F-=O;E[d++]=y[S++],--O;);S=d-q,H=E}}else if(b<O){if(S+=h+b-O,(O-=b)<F){for(F-=O;E[d++]=y[S++],--O;);if(S=0,b<F){for(F-=O=b;E[d++]=y[S++],--O;);S=d-q,H=E}}}else if(S+=b-O,O<F){for(F-=O;E[d++]=y[S++],--O;);S=d-q,H=E}for(;2<F;)E[d++]=H[S++],E[d++]=H[S++],E[d++]=H[S++],F-=3;F&&(E[d++]=H[S++],1<F&&(E[d++]=H[S++]))}else{for(S=d-q;E[d++]=E[S++],E[d++]=E[S++],E[d++]=E[S++],2<(F-=3););F&&(E[d++]=E[S++],1<F&&(E[d++]=E[S++]))}break}}break}}while(a<c&&d<g);a-=F=_>>3,x&=(1<<(_-=F<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<g?g-d+257:257-(d-g),r.hold=x,r.bits=_}},{}],49:[function(i,n,s){var o=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,f=2,g=0,u=-2,h=1,m=852,b=592;function y(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(S){var H;return S&&S.state?(H=S.state,S.total_in=S.total_out=H.total=0,S.msg="",H.wrap&&(S.adler=1&H.wrap),H.mode=h,H.last=0,H.havedict=0,H.dmax=32768,H.head=null,H.hold=0,H.bits=0,H.lencode=H.lendyn=new o.Buf32(m),H.distcode=H.distdyn=new o.Buf32(b),H.sane=1,H.back=-1,g):u}function M(S){var H;return S&&S.state?((H=S.state).wsize=0,H.whave=0,H.wnext=0,_(S)):u}function A(S,H){var k,E;return S&&S.state?(E=S.state,H<0?(k=0,H=-H):(k=1+(H>>4),H<48&&(H&=15)),H&&(H<8||15<H)?u:(E.window!==null&&E.wbits!==H&&(E.window=null),E.wrap=k,E.wbits=H,M(S))):u}function I(S,H){var k,E;return S?(E=new x,(S.state=E).window=null,(k=A(S,H))!==g&&(S.state=null),k):u}var w,N,O=!0;function F(S){if(O){var H;for(w=new o.Buf32(512),N=new o.Buf32(32),H=0;H<144;)S.lens[H++]=8;for(;H<256;)S.lens[H++]=9;for(;H<280;)S.lens[H++]=7;for(;H<288;)S.lens[H++]=8;for(c(d,S.lens,0,288,w,0,S.work,{bits:9}),H=0;H<32;)S.lens[H++]=5;c(f,S.lens,0,32,N,0,S.work,{bits:5}),O=!1}S.lencode=w,S.lenbits=9,S.distcode=N,S.distbits=5}function q(S,H,k,E){var j,T=S.state;return T.window===null&&(T.wsize=1<<T.wbits,T.wnext=0,T.whave=0,T.window=new o.Buf8(T.wsize)),E>=T.wsize?(o.arraySet(T.window,H,k-T.wsize,T.wsize,0),T.wnext=0,T.whave=T.wsize):(E<(j=T.wsize-T.wnext)&&(j=E),o.arraySet(T.window,H,k-E,j,T.wnext),(E-=j)?(o.arraySet(T.window,H,k-E,E,0),T.wnext=E,T.whave=T.wsize):(T.wnext+=j,T.wnext===T.wsize&&(T.wnext=0),T.whave<T.wsize&&(T.whave+=j))),0}s.inflateReset=M,s.inflateReset2=A,s.inflateResetKeep=_,s.inflateInit=function(S){return I(S,15)},s.inflateInit2=I,s.inflate=function(S,H){var k,E,j,T,B,R,X,U,Y,se,ae,ce,ge,Te,xe,fe,Z,pe,L,K,v,G,W,C,$=0,P=new o.Buf8(4),D=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return u;(k=S.state).mode===12&&(k.mode=13),B=S.next_out,j=S.output,X=S.avail_out,T=S.next_in,E=S.input,R=S.avail_in,U=k.hold,Y=k.bits,se=R,ae=X,G=g;e:for(;;)switch(k.mode){case h:if(k.wrap===0){k.mode=13;break}for(;Y<16;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(2&k.wrap&&U===35615){P[k.check=0]=255&U,P[1]=U>>>8&255,k.check=r(k.check,P,2,0),Y=U=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&U)<<8)+(U>>8))%31){S.msg="incorrect header check",k.mode=30;break}if((15&U)!=8){S.msg="unknown compression method",k.mode=30;break}if(Y-=4,v=8+(15&(U>>>=4)),k.wbits===0)k.wbits=v;else if(v>k.wbits){S.msg="invalid window size",k.mode=30;break}k.dmax=1<<v,S.adler=k.check=1,k.mode=512&U?10:12,Y=U=0;break;case 2:for(;Y<16;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(k.flags=U,(255&k.flags)!=8){S.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){S.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=U>>8&1),512&k.flags&&(P[0]=255&U,P[1]=U>>>8&255,k.check=r(k.check,P,2,0)),Y=U=0,k.mode=3;case 3:for(;Y<32;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.head&&(k.head.time=U),512&k.flags&&(P[0]=255&U,P[1]=U>>>8&255,P[2]=U>>>16&255,P[3]=U>>>24&255,k.check=r(k.check,P,4,0)),Y=U=0,k.mode=4;case 4:for(;Y<16;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.head&&(k.head.xflags=255&U,k.head.os=U>>8),512&k.flags&&(P[0]=255&U,P[1]=U>>>8&255,k.check=r(k.check,P,2,0)),Y=U=0,k.mode=5;case 5:if(1024&k.flags){for(;Y<16;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.length=U,k.head&&(k.head.extra_len=U),512&k.flags&&(P[0]=255&U,P[1]=U>>>8&255,k.check=r(k.check,P,2,0)),Y=U=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(R<(ce=k.length)&&(ce=R),ce&&(k.head&&(v=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,E,T,ce,v)),512&k.flags&&(k.check=r(k.check,E,ce,T)),R-=ce,T+=ce,k.length-=ce),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(R===0)break e;for(ce=0;v=E[T+ce++],k.head&&v&&k.length<65536&&(k.head.name+=String.fromCharCode(v)),v&&ce<R;);if(512&k.flags&&(k.check=r(k.check,E,ce,T)),R-=ce,T+=ce,v)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(R===0)break e;for(ce=0;v=E[T+ce++],k.head&&v&&k.length<65536&&(k.head.comment+=String.fromCharCode(v)),v&&ce<R;);if(512&k.flags&&(k.check=r(k.check,E,ce,T)),R-=ce,T+=ce,v)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;Y<16;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(U!==(65535&k.check)){S.msg="header crc mismatch",k.mode=30;break}Y=U=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),S.adler=k.check=0,k.mode=12;break;case 10:for(;Y<32;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}S.adler=k.check=y(U),Y=U=0,k.mode=11;case 11:if(k.havedict===0)return S.next_out=B,S.avail_out=X,S.next_in=T,S.avail_in=R,k.hold=U,k.bits=Y,2;S.adler=k.check=1,k.mode=12;case 12:if(H===5||H===6)break e;case 13:if(k.last){U>>>=7&Y,Y-=7&Y,k.mode=27;break}for(;Y<3;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}switch(k.last=1&U,Y-=1,3&(U>>>=1)){case 0:k.mode=14;break;case 1:if(F(k),k.mode=20,H!==6)break;U>>>=2,Y-=2;break e;case 2:k.mode=17;break;case 3:S.msg="invalid block type",k.mode=30}U>>>=2,Y-=2;break;case 14:for(U>>>=7&Y,Y-=7&Y;Y<32;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if((65535&U)!=(U>>>16^65535)){S.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&U,Y=U=0,k.mode=15,H===6)break e;case 15:k.mode=16;case 16:if(ce=k.length){if(R<ce&&(ce=R),X<ce&&(ce=X),ce===0)break e;o.arraySet(j,E,T,ce,B),R-=ce,T+=ce,X-=ce,B+=ce,k.length-=ce;break}k.mode=12;break;case 17:for(;Y<14;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(k.nlen=257+(31&U),U>>>=5,Y-=5,k.ndist=1+(31&U),U>>>=5,Y-=5,k.ncode=4+(15&U),U>>>=4,Y-=4,286<k.nlen||30<k.ndist){S.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;Y<3;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.lens[D[k.have++]]=7&U,U>>>=3,Y-=3}for(;k.have<19;)k.lens[D[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,W={bits:k.lenbits},G=c(0,k.lens,0,19,k.lencode,0,k.work,W),k.lenbits=W.bits,G){S.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;fe=($=k.lencode[U&(1<<k.lenbits)-1])>>>16&255,Z=65535&$,!((xe=$>>>24)<=Y);){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(Z<16)U>>>=xe,Y-=xe,k.lens[k.have++]=Z;else{if(Z===16){for(C=xe+2;Y<C;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(U>>>=xe,Y-=xe,k.have===0){S.msg="invalid bit length repeat",k.mode=30;break}v=k.lens[k.have-1],ce=3+(3&U),U>>>=2,Y-=2}else if(Z===17){for(C=xe+3;Y<C;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}Y-=xe,v=0,ce=3+(7&(U>>>=xe)),U>>>=3,Y-=3}else{for(C=xe+7;Y<C;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}Y-=xe,v=0,ce=11+(127&(U>>>=xe)),U>>>=7,Y-=7}if(k.have+ce>k.nlen+k.ndist){S.msg="invalid bit length repeat",k.mode=30;break}for(;ce--;)k.lens[k.have++]=v}}if(k.mode===30)break;if(k.lens[256]===0){S.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,W={bits:k.lenbits},G=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,W),k.lenbits=W.bits,G){S.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,W={bits:k.distbits},G=c(f,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,W),k.distbits=W.bits,G){S.msg="invalid distances set",k.mode=30;break}if(k.mode=20,H===6)break e;case 20:k.mode=21;case 21:if(6<=R&&258<=X){S.next_out=B,S.avail_out=X,S.next_in=T,S.avail_in=R,k.hold=U,k.bits=Y,a(S,ae),B=S.next_out,j=S.output,X=S.avail_out,T=S.next_in,E=S.input,R=S.avail_in,U=k.hold,Y=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;fe=($=k.lencode[U&(1<<k.lenbits)-1])>>>16&255,Z=65535&$,!((xe=$>>>24)<=Y);){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(fe&&(240&fe)==0){for(pe=xe,L=fe,K=Z;fe=($=k.lencode[K+((U&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&$,!(pe+(xe=$>>>24)<=Y);){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}U>>>=pe,Y-=pe,k.back+=pe}if(U>>>=xe,Y-=xe,k.back+=xe,k.length=Z,fe===0){k.mode=26;break}if(32&fe){k.back=-1,k.mode=12;break}if(64&fe){S.msg="invalid literal/length code",k.mode=30;break}k.extra=15&fe,k.mode=22;case 22:if(k.extra){for(C=k.extra;Y<C;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.length+=U&(1<<k.extra)-1,U>>>=k.extra,Y-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;fe=($=k.distcode[U&(1<<k.distbits)-1])>>>16&255,Z=65535&$,!((xe=$>>>24)<=Y);){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if((240&fe)==0){for(pe=xe,L=fe,K=Z;fe=($=k.distcode[K+((U&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&$,!(pe+(xe=$>>>24)<=Y);){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}U>>>=pe,Y-=pe,k.back+=pe}if(U>>>=xe,Y-=xe,k.back+=xe,64&fe){S.msg="invalid distance code",k.mode=30;break}k.offset=Z,k.extra=15&fe,k.mode=24;case 24:if(k.extra){for(C=k.extra;Y<C;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}k.offset+=U&(1<<k.extra)-1,U>>>=k.extra,Y-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){S.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(X===0)break e;if(ce=ae-X,k.offset>ce){if((ce=k.offset-ce)>k.whave&&k.sane){S.msg="invalid distance too far back",k.mode=30;break}ge=ce>k.wnext?(ce-=k.wnext,k.wsize-ce):k.wnext-ce,ce>k.length&&(ce=k.length),Te=k.window}else Te=j,ge=B-k.offset,ce=k.length;for(X<ce&&(ce=X),X-=ce,k.length-=ce;j[B++]=Te[ge++],--ce;);k.length===0&&(k.mode=21);break;case 26:if(X===0)break e;j[B++]=k.length,X--,k.mode=21;break;case 27:if(k.wrap){for(;Y<32;){if(R===0)break e;R--,U|=E[T++]<<Y,Y+=8}if(ae-=X,S.total_out+=ae,k.total+=ae,ae&&(S.adler=k.check=k.flags?r(k.check,j,ae,B-ae):l(k.check,j,ae,B-ae)),ae=X,(k.flags?U:y(U))!==k.check){S.msg="incorrect data check",k.mode=30;break}Y=U=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;Y<32;){if(R===0)break e;R--,U+=E[T++]<<Y,Y+=8}if(U!==(4294967295&k.total)){S.msg="incorrect length check",k.mode=30;break}Y=U=0}k.mode=29;case 29:G=1;break e;case 30:G=-3;break e;case 31:return-4;case 32:default:return u}return S.next_out=B,S.avail_out=X,S.next_in=T,S.avail_in=R,k.hold=U,k.bits=Y,(k.wsize||ae!==S.avail_out&&k.mode<30&&(k.mode<27||H!==4))&&q(S,S.output,S.next_out,ae-S.avail_out)?(k.mode=31,-4):(se-=S.avail_in,ae-=S.avail_out,S.total_in+=se,S.total_out+=ae,k.total+=ae,k.wrap&&ae&&(S.adler=k.check=k.flags?r(k.check,j,ae,S.next_out-ae):l(k.check,j,ae,S.next_out-ae)),S.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(se==0&&ae===0||H===4)&&G===g&&(G=-5),G)},s.inflateEnd=function(S){if(!S||!S.state)return u;var H=S.state;return H.window&&(H.window=null),S.state=null,g},s.inflateGetHeader=function(S,H){var k;return S&&S.state?(2&(k=S.state).wrap)==0?u:((k.head=H).done=!1,g):u},s.inflateSetDictionary=function(S,H){var k,E=H.length;return S&&S.state?(k=S.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,H,E,0)!==k.check?-3:q(S,H,E,E)?(k.mode=31,-4):(k.havedict=1,g):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,f,g,u,h,m,b,y){var x,_,M,A,I,w,N,O,F,q=y.bits,S=0,H=0,k=0,E=0,j=0,T=0,B=0,R=0,X=0,U=0,Y=null,se=0,ae=new o.Buf16(16),ce=new o.Buf16(16),ge=null,Te=0;for(S=0;S<=15;S++)ae[S]=0;for(H=0;H<u;H++)ae[f[g+H]]++;for(j=q,E=15;1<=E&&ae[E]===0;E--);if(E<j&&(j=E),E===0)return h[m++]=20971520,h[m++]=20971520,y.bits=1,0;for(k=1;k<E&&ae[k]===0;k++);for(j<k&&(j=k),S=R=1;S<=15;S++)if(R<<=1,(R-=ae[S])<0)return-1;if(0<R&&(d===0||E!==1))return-1;for(ce[1]=0,S=1;S<15;S++)ce[S+1]=ce[S]+ae[S];for(H=0;H<u;H++)f[g+H]!==0&&(b[ce[f[g+H]]++]=H);if(w=d===0?(Y=ge=b,19):d===1?(Y=l,se-=257,ge=r,Te-=257,256):(Y=a,ge=c,-1),S=k,I=m,B=H=U=0,M=-1,A=(X=1<<(T=j))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(N=S-B,F=b[H]<w?(O=0,b[H]):b[H]>w?(O=ge[Te+b[H]],Y[se+b[H]]):(O=96,0),x=1<<S-B,k=_=1<<T;h[I+(U>>B)+(_-=x)]=N<<24|O<<16|F|0,_!==0;);for(x=1<<S-1;U&x;)x>>=1;if(x!==0?(U&=x-1,U+=x):U=0,H++,--ae[S]==0){if(S===E)break;S=f[g+b[H]]}if(j<S&&(U&A)!==M){for(B===0&&(B=j),I+=k,R=1<<(T=S-B);T+B<E&&!((R-=ae[T+B])<=0);)T++,R<<=1;if(X+=1<<T,d===1&&852<X||d===2&&592<X)return 1;h[M=U&A]=j<<24|T<<16|I-m|0}}return U!==0&&(h[I+U]=S-B<<24|64<<16|0),y.bits=j,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),l=0,r=1;function a($){for(var P=$.length;0<=--P;)$[P]=0}var c=0,d=29,f=256,g=f+1+d,u=30,h=19,m=2*g+1,b=15,y=16,x=7,_=256,M=16,A=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],O=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],F=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],q=new Array(2*(g+2));a(q);var S=new Array(2*u);a(S);var H=new Array(512);a(H);var k=new Array(256);a(k);var E=new Array(d);a(E);var j,T,B,R=new Array(u);function X($,P,D,z,V){this.static_tree=$,this.extra_bits=P,this.extra_base=D,this.elems=z,this.max_length=V,this.has_stree=$&&$.length}function U($,P){this.dyn_tree=$,this.max_code=0,this.stat_desc=P}function Y($){return $<256?H[$]:H[256+($>>>7)]}function se($,P){$.pending_buf[$.pending++]=255&P,$.pending_buf[$.pending++]=P>>>8&255}function ae($,P,D){$.bi_valid>y-D?($.bi_buf|=P<<$.bi_valid&65535,se($,$.bi_buf),$.bi_buf=P>>y-$.bi_valid,$.bi_valid+=D-y):($.bi_buf|=P<<$.bi_valid&65535,$.bi_valid+=D)}function ce($,P,D){ae($,D[2*P],D[2*P+1])}function ge($,P){for(var D=0;D|=1&$,$>>>=1,D<<=1,0<--P;);return D>>>1}function Te($,P,D){var z,V,J=new Array(b+1),re=0;for(z=1;z<=b;z++)J[z]=re=re+D[z-1]<<1;for(V=0;V<=P;V++){var oe=$[2*V+1];oe!==0&&($[2*V]=ge(J[oe]++,oe))}}function xe($){var P;for(P=0;P<g;P++)$.dyn_ltree[2*P]=0;for(P=0;P<u;P++)$.dyn_dtree[2*P]=0;for(P=0;P<h;P++)$.bl_tree[2*P]=0;$.dyn_ltree[2*_]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function fe($){8<$.bi_valid?se($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function Z($,P,D,z){var V=2*P,J=2*D;return $[V]<$[J]||$[V]===$[J]&&z[P]<=z[D]}function pe($,P,D){for(var z=$.heap[D],V=D<<1;V<=$.heap_len&&(V<$.heap_len&&Z(P,$.heap[V+1],$.heap[V],$.depth)&&V++,!Z(P,z,$.heap[V],$.depth));)$.heap[D]=$.heap[V],D=V,V<<=1;$.heap[D]=z}function L($,P,D){var z,V,J,re,oe=0;if($.last_lit!==0)for(;z=$.pending_buf[$.d_buf+2*oe]<<8|$.pending_buf[$.d_buf+2*oe+1],V=$.pending_buf[$.l_buf+oe],oe++,z===0?ce($,V,P):(ce($,(J=k[V])+f+1,P),(re=w[J])!==0&&ae($,V-=E[J],re),ce($,J=Y(--z),D),(re=N[J])!==0&&ae($,z-=R[J],re)),oe<$.last_lit;);ce($,_,P)}function K($,P){var D,z,V,J=P.dyn_tree,re=P.stat_desc.static_tree,oe=P.stat_desc.has_stree,me=P.stat_desc.elems,ie=-1;for($.heap_len=0,$.heap_max=m,D=0;D<me;D++)J[2*D]!==0?($.heap[++$.heap_len]=ie=D,$.depth[D]=0):J[2*D+1]=0;for(;$.heap_len<2;)J[2*(V=$.heap[++$.heap_len]=ie<2?++ie:0)]=1,$.depth[V]=0,$.opt_len--,oe&&($.static_len-=re[2*V+1]);for(P.max_code=ie,D=$.heap_len>>1;1<=D;D--)pe($,J,D);for(V=me;D=$.heap[1],$.heap[1]=$.heap[$.heap_len--],pe($,J,1),z=$.heap[1],$.heap[--$.heap_max]=D,$.heap[--$.heap_max]=z,J[2*V]=J[2*D]+J[2*z],$.depth[V]=($.depth[D]>=$.depth[z]?$.depth[D]:$.depth[z])+1,J[2*D+1]=J[2*z+1]=V,$.heap[1]=V++,pe($,J,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(ne,Ce){var Me,Ne,Oe,De,Jt,ot,Je=Ce.dyn_tree,Nt=Ce.max_code,Hi=Ce.stat_desc.static_tree,Fs=Ce.stat_desc.has_stree,js=Ce.stat_desc.extra_bits,Vn=Ce.stat_desc.extra_base,xi=Ce.stat_desc.max_length,Fi=0;for(De=0;De<=b;De++)ne.bl_count[De]=0;for(Je[2*ne.heap[ne.heap_max]+1]=0,Me=ne.heap_max+1;Me<m;Me++)xi<(De=Je[2*Je[2*(Ne=ne.heap[Me])+1]+1]+1)&&(De=xi,Fi++),Je[2*Ne+1]=De,Nt<Ne||(ne.bl_count[De]++,Jt=0,Vn<=Ne&&(Jt=js[Ne-Vn]),ot=Je[2*Ne],ne.opt_len+=ot*(De+Jt),Fs&&(ne.static_len+=ot*(Hi[2*Ne+1]+Jt)));if(Fi!==0){do{for(De=xi-1;ne.bl_count[De]===0;)De--;ne.bl_count[De]--,ne.bl_count[De+1]+=2,ne.bl_count[xi]--,Fi-=2}while(0<Fi);for(De=xi;De!==0;De--)for(Ne=ne.bl_count[De];Ne!==0;)Nt<(Oe=ne.heap[--Me])||(Je[2*Oe+1]!==De&&(ne.opt_len+=(De-Je[2*Oe+1])*Je[2*Oe],Je[2*Oe+1]=De),Ne--)}})($,P),Te(J,ie,$.bl_count)}function v($,P,D){var z,V,J=-1,re=P[1],oe=0,me=7,ie=4;for(re===0&&(me=138,ie=3),P[2*(D+1)+1]=65535,z=0;z<=D;z++)V=re,re=P[2*(z+1)+1],++oe<me&&V===re||(oe<ie?$.bl_tree[2*V]+=oe:V!==0?(V!==J&&$.bl_tree[2*V]++,$.bl_tree[2*M]++):oe<=10?$.bl_tree[2*A]++:$.bl_tree[2*I]++,J=V,ie=(oe=0)===re?(me=138,3):V===re?(me=6,3):(me=7,4))}function G($,P,D){var z,V,J=-1,re=P[1],oe=0,me=7,ie=4;for(re===0&&(me=138,ie=3),z=0;z<=D;z++)if(V=re,re=P[2*(z+1)+1],!(++oe<me&&V===re)){if(oe<ie)for(;ce($,V,$.bl_tree),--oe!=0;);else V!==0?(V!==J&&(ce($,V,$.bl_tree),oe--),ce($,M,$.bl_tree),ae($,oe-3,2)):oe<=10?(ce($,A,$.bl_tree),ae($,oe-3,3)):(ce($,I,$.bl_tree),ae($,oe-11,7));J=V,ie=(oe=0)===re?(me=138,3):V===re?(me=6,3):(me=7,4)}}a(R);var W=!1;function C($,P,D,z){ae($,(c<<1)+(z?1:0),3),(function(V,J,re,oe){fe(V),se(V,re),se(V,~re),o.arraySet(V.pending_buf,V.window,J,re,V.pending),V.pending+=re})($,P,D)}s._tr_init=function($){W||((function(){var P,D,z,V,J,re=new Array(b+1);for(V=z=0;V<d-1;V++)for(E[V]=z,P=0;P<1<<w[V];P++)k[z++]=V;for(k[z-1]=V,V=J=0;V<16;V++)for(R[V]=J,P=0;P<1<<N[V];P++)H[J++]=V;for(J>>=7;V<u;V++)for(R[V]=J<<7,P=0;P<1<<N[V]-7;P++)H[256+J++]=V;for(D=0;D<=b;D++)re[D]=0;for(P=0;P<=143;)q[2*P+1]=8,P++,re[8]++;for(;P<=255;)q[2*P+1]=9,P++,re[9]++;for(;P<=279;)q[2*P+1]=7,P++,re[7]++;for(;P<=287;)q[2*P+1]=8,P++,re[8]++;for(Te(q,g+1,re),P=0;P<u;P++)S[2*P+1]=5,S[2*P]=ge(P,5);j=new X(q,w,f+1,g,b),T=new X(S,N,0,u,b),B=new X(new Array(0),O,0,h,x)})(),W=!0),$.l_desc=new U($.dyn_ltree,j),$.d_desc=new U($.dyn_dtree,T),$.bl_desc=new U($.bl_tree,B),$.bi_buf=0,$.bi_valid=0,xe($)},s._tr_stored_block=C,s._tr_flush_block=function($,P,D,z){var V,J,re=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(oe){var me,ie=4093624447;for(me=0;me<=31;me++,ie>>>=1)if(1&ie&&oe.dyn_ltree[2*me]!==0)return l;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(oe.dyn_ltree[2*me]!==0)return r;return l})($)),K($,$.l_desc),K($,$.d_desc),re=(function(oe){var me;for(v(oe,oe.dyn_ltree,oe.l_desc.max_code),v(oe,oe.dyn_dtree,oe.d_desc.max_code),K(oe,oe.bl_desc),me=h-1;3<=me&&oe.bl_tree[2*F[me]+1]===0;me--);return oe.opt_len+=3*(me+1)+5+5+4,me})($),V=$.opt_len+3+7>>>3,(J=$.static_len+3+7>>>3)<=V&&(V=J)):V=J=D+5,D+4<=V&&P!==-1?C($,P,D,z):$.strategy===4||J===V?(ae($,2+(z?1:0),3),L($,q,S)):(ae($,4+(z?1:0),3),(function(oe,me,ie,ne){var Ce;for(ae(oe,me-257,5),ae(oe,ie-1,5),ae(oe,ne-4,4),Ce=0;Ce<ne;Ce++)ae(oe,oe.bl_tree[2*F[Ce]+1],3);G(oe,oe.dyn_ltree,me-1),G(oe,oe.dyn_dtree,ie-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,re+1),L($,$.dyn_ltree,$.dyn_dtree)),xe($),z&&fe($)},s._tr_tally=function($,P,D){return $.pending_buf[$.d_buf+2*$.last_lit]=P>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&P,$.pending_buf[$.l_buf+$.last_lit]=255&D,$.last_lit++,P===0?$.dyn_ltree[2*D]++:($.matches++,P--,$.dyn_ltree[2*(k[D]+f+1)]++,$.dyn_dtree[2*Y(P)]++),$.last_lit===$.lit_bufsize-1},s._tr_align=function($){ae($,2,3),ce($,_,q),(function(P){P.bi_valid===16?(se(P,P.bi_buf),P.bi_buf=0,P.bi_valid=0):8<=P.bi_valid&&(P.pending_buf[P.pending++]=255&P.bi_buf,P.bi_buf>>=8,P.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,f,g=1,u={},h=!1,m=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(M){process.nextTick(function(){x(M)})}:(function(){if(l.postMessage&&!l.importScripts){var M=!0,A=l.onmessage;return l.onmessage=function(){M=!1},l.postMessage("","*"),l.onmessage=A,M}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(M){l.postMessage(f+M,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(M){x(M.data)},function(M){d.port2.postMessage(M)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(M){var A=m.createElement("script");A.onreadystatechange=function(){x(M),A.onreadystatechange=null,c.removeChild(A),A=null},c.appendChild(A)}):function(M){setTimeout(x,0,M)},b.setImmediate=function(M){typeof M!="function"&&(M=new Function(""+M));for(var A=new Array(arguments.length-1),I=0;I<A.length;I++)A[I]=arguments[I+1];var w={callback:M,args:A};return u[g]=w,a(g),g++},b.clearImmediate=y}function y(M){delete u[M]}function x(M){if(h)setTimeout(x,0,M);else{var A=u[M];if(A){h=!0;try{(function(I){var w=I.callback,N=I.args;switch(N.length){case 0:w();break;case 1:w(N[0]);break;case 2:w(N[0],N[1]);break;case 3:w(N[0],N[1],N[2]);break;default:w.apply(r,N)}})(A)}finally{y(M),h=!1}}}}function _(M){M.source===l&&typeof M.data=="string"&&M.data.indexOf(f)===0&&x(+M.data.slice(f.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof es<"u"?es:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(oo)),oo.exports}var Zm=Ym();const Oa=qm(Zm);function Jm(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function Zr(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function Xm(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Ao(e,t){return new Promise(i=>{let n=[];const s=()=>{n.forEach(r=>r()),n=[]},o=e.onCapturePageDone(r=>{s(),i({success:!0,dataUrl:r.dataUrl})});n.push(o);const l=e.onCaptureError(r=>{s(),i({success:!1,error:r})});n.push(l),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Na(e,t){const i=[],n=((t==null?void 0:t.title)||"presentation").replace(/[/\\?%*:|"<>]/g,"_").trim()||"presentation";return new Promise(s=>{let o=[];const l=()=>{o.forEach(f=>f()),o=[]},r=e.onCaptureProgress(f=>{var g;(g=t==null?void 0:t.onProgress)==null||g.call(t,f.current,f.total,f.pageIndex)});o.push(r);const a=e.onCapturePageDone(f=>{(f.mode==="all"||!f.mode)&&i.push({pageIndex:f.pageIndex,dataUrl:f.dataUrl})});o.push(a);const c=async()=>{l();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const f=new Oa,g=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const m of i){const b=String(m.pageIndex).padStart(2,"0"),y=m.dataUrl.split(",")[1];f.file(`slide-${b}.${g}`,y,{base64:!0})}const u=await f.generateAsync({type:"blob",compression:"DEFLATE"}),h=Jm(`${n}-slides.zip`,u);s({success:h,total:i.length})}catch(f){s({success:!1,error:(f==null?void 0:f.message)||String(f)})}};o.push(e.onCaptureComplete(c));const d=e.onCaptureError(f=>{l(),s({success:!1,error:f})});o.push(d),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function za(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-slidev/slidev-client/index.html",document.body.appendChild(i);const n=new Un;n.attach(i);try{if(await new Promise((s,o)=>{const l=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(l),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await Ao(n,t);return{success:s.success,total:1,error:s.error}}else return await Na(n,{...t,title:(t==null?void 0:t.title)||e.config.title})}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const Qm=1500,eg=500,tg=4,ig=new Set(["INPUT","TEXTAREA","SELECT"]);function Ha(e){const t=e;return!t||!t.tagName?!1:ig.has(t.tagName)||t.isContentEditable===!0}function ng(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){l(),t="",i=!1,o()}function a(){n&&clearTimeout(n),n=setTimeout(r,Qm)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,eg)}function d(f){if(e.isEnabled&&!e.isEnabled()||Ha(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return i||t.length>=tg||(t+=f.key,o(),a()),!0;if(f.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),h=e.getTotalPages();return!isNaN(u)&&u>=1&&h>0&&u<=h?(r(),e.onJump(u),!0):(c(),!0)}return f.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const sg={class:"spm-slidev-tab__toolbar"},og={class:"spm-slidev-tab__nav"},rg=["disabled"],lg={class:"spm-page-badge"},ag=["disabled"],cg=["aria-label"],dg=["aria-label"],ug={class:"spm-slidev-tab__tools"},fg={class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},pg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},hg=["src"],mg=It({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=Lt("plugin"),n=Lt("sandboxBridge",new Un),s=new _m(n),o=new lp,l=he("web-sandbox"),r=he(3030),a=he(null),c=he(!1),d=he(null),f=he(1),g=he(1),u=he(!1),h=he(!1),m=he(!1),b=he("siyuan"),y=he(""),x=he(""),_=he(""),M=he(!1),A=he(!1),I=he(""),w=he(""),N=he(!1),O=ng({getTotalPages:()=>g.value,isEnabled:()=>!h.value,onJump:D=>S(D),onStateChange:D=>{w.value=D.display,N.value=D.invalid}});function F(D){if(D.key==="o"||D.key==="O"){if(h.value||D.isComposing||D.ctrlKey||D.metaKey||D.altKey||Ha(D.target))return;D.preventDefault(),q();return}O.handleKeydown(D)&&D.preventDefault()}function q(){var D,z;if(l.value==="pro-cli"){(D=d.value)==null||D.focus(),ue.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(z=d.value)==null||z.focus()}function S(D){var z;f.value=D,l.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D),(z=d.value)==null||z.focus()}const H=he("/plugins/siyuan-slidev/slidev-client/index.html");let k=null,E=null,j=null,T=null,B=null,R=null,X=null,U=null;dn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),k=n.onSlideChanged((D,z)=>{f.value=D,g.value=z}),E=n.onBlockClicked((D,z)=>{f.value=z,s.setActiveBlockId(D),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(D,z):Oi(D,i==null?void 0:i.app)}),j=n.onOpenInEditor((D,z)=>{f.value=z,s.setActiveBlockId(D),Oi(D,i==null?void 0:i.app)}),T=o.nativeBridge.onPageChanged((D,z)=>{f.value=D,g.value=z}),B=n.onOpenPeekDrawer(async D=>{const z=Hs();if(D.peekType==="siyuan"&&z.enableWebServeJump){let V=!1;if(U&&U.docId===D.target)V=!0;else if(U&&U.slides&&U.slides.some(J=>{var re;return(re=J.blocks)==null?void 0:re.some(oe=>oe.id===D.target)}))V=!1;else try{const J=await nn(`SELECT id, root_id, type FROM blocks WHERE id = '${D.target}' LIMIT 1`);J&&J.length>0&&(V=J[0].type==="d"||J[0].id===J[0].root_id)}catch(J){console.warn("[SlidevPreviewTab] detect block type failed:",J)}b.value="web",M.value=!0,x.value=ba(z.webServeUrl,D.target,{focus:!V}),_.value=D.title||`${V?"思源文档":"思源块"}: ${D.target.slice(0,8)}`,h.value=!0,n.freezeKeyboardNav(!0)}else{if(b.value=D.peekType,D.peekType==="siyuan")y.value=D.target,_.value=D.title||`块速览: ${D.target.slice(0,8)}`;else{const V=Ea(D.target);if(V.external){pe(D.target);return}M.value=!0,x.value=V.url,_.value=D.title||V.url}h.value=!0,n.freezeKeyboardNav(!0)}}),R=n.onRequestToggleFullscreen(()=>{K()}),X=n.onOpenPresenter(()=>{v()}),typeof document<"u"&&document.addEventListener("fullscreenchange",L)}),Rs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",L),B&&B(),R&&R(),X&&X(),k&&k(),E&&E(),j&&j(),T&&T(),n.detach(),O.clear(),s.destroy(),o.destroy()});async function Y(){if(l.value==="web-sandbox"){if(!U){ue.showMessage("请先在主编辑区打开演示文档");return}ue.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const D=await o.startProMode(U,uo);if(!D.success){ue.showMessage(`无法启动官方 Pro 模式：${D.error}`);return}l.value="pro-cli",r.value=D.port||3030,H.value=D.url,d.value&&o.nativeBridge.attach(d.value),ue.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",H.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),ue.showMessage("已切回内置高保真沙箱")}function se(){A.value=!A.value,A.value?(I.value=(U==null?void 0:U.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",I.value)):(I.value="",xe(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ae=0;function ce(D){if(h.value||Math.abs(D.deltaY)<Math.abs(D.deltaX)||Math.abs(D.deltaY)<15)return;const z=Date.now();z-ae<280||(ae=z,D.deltaY>0?Te():ge())}function ge(){if(f.value>1){const D=f.value-1;f.value=D,l.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D)}}function Te(){if(f.value<g.value){const D=f.value+1;f.value=D,l.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D)}}function xe(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function fe(){h.value=!1,n.freezeKeyboardNav(!1)}function Z(){fe()}function pe(D){var re,oe;const z=/^file:/i.test(D),V=z||/^[a-zA-Z]:[\\/]/.test(D),J=Ct("electron");if(V&&typeof((re=J==null?void 0:J.shell)==null?void 0:re.openPath)=="function"){J.shell.openPath(z?Ta(D):D),ue.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((oe=J==null?void 0:J.shell)==null?void 0:oe.openExternal)=="function"?J.shell.openExternal(D).catch(()=>{typeof window<"u"&&window.open(D,"_blank")}):typeof window<"u"&&window.open(D,"_blank"),ue.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function L(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function K(){const D=a.value||d.value;D&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):D.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function v(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function G(){if(!U){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const D=La(U);Pa("presentation.html",D)&&ue.showMessage("已开始下载单文件离线 HTML 演示包")}function W(){if(!U){ue.showMessage("请先在主编辑区打开幻灯片文档");return}Ra(U)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function C(){if(!U){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在逐页导出幻灯片图片...",2e3);const D=U.config.title||(i==null?void 0:i.currentDocId)||"presentation",z=await Na(n,{title:D,onProgress:(V,J)=>{ue.showMessage(`正在导出幻灯片图片 (${V} / ${J})...`,1500)}});z.success?ue.showMessage(`🎉 成功导出 ${z.total||0} 张高清图片并打包为 ZIP！`,4e3):ue.showMessage(`导出图片失败：${z.error||"未知异常"}`)}async function $(){if(!U){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在导出当前幻灯片图片...",1500);const D=await Ao(n);if(D.success&&D.dataUrl){const z=U.config.title||"presentation",V=f.value||1;Zr(`${z}-slide-${V}.png`,D.dataUrl),ue.showMessage(`已下载当前页（第 ${V} 页）高清图片`)}else ue.showMessage(`导出当前页图片失败：${D.error||"未知异常"}`)}async function P(){if(!U){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const D=await Ao(n);if(D.success&&D.dataUrl)if(await Xm(D.dataUrl))ue.showMessage(`已成功将第 ${f.value||1} 页幻灯片复制到剪贴板！`);else{const V=f.value||1;Zr(`slide-${V}.png`,D.dataUrl),ue.showMessage(`剪贴板权限不可用，已自动下载为 slide-${V}.png`)}else ue.showMessage(`复制失败：${D.error||"未知异常"}`)}return t({updateDocument(D,z){A.value&&I.value&&z&&z!==I.value||(U=D,A.value&&!I.value&&(I.value=D.docId),g.value=D.slides.length,s.setDocId(D.docId),s.updateSlidesIndex(D.slides),l.value==="pro-cli"?o.scaffolder.scaffold(D,uo).catch(()=>{}):n.updateSlides(D.slides,D.config,D.fullMarkdown,D.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",D.docId))},navigateToBlock(D){s.onCursorFocusBlock(D)},isPinned:A,pinnedDocId:I,engineMode:l,toggleEngineMode:Y}),(D,z)=>(ee(),te("div",{class:"spm-slidev-preview-tab",onKeydown:F},[p("div",sg,[p("div",og,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:ge},[le(de,{name:"chevron-left"})],8,rg),p("span",lg,Se(f.value)+" / "+Se(g.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=g.value,"aria-label":"下一页",onClick:Te},[le(de,{name:"chevron-right"})],8,ag),p("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":A.value}]),"aria-label":A.value?"已锁定当前文档（点击解除）："+I.value:"点击锁定当前文档（不随主编辑区切换）",onClick:se},[le(de,{name:"pin"}),p("span",null,Se(A.value?"已锁定":"跟随"),1)],10,cg),p("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[le(de,{name:"rocket"}),p("span",null,Se(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,dg)]),p("div",ug,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:q},[le(de,{name:"columns"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:v},[le(de,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:G},[le(de,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:W},[le(de,{name:"export-pdf"})]),p("div",fg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:C},[le(de,{name:"export-image"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:z[0]||(z[0]=Vt(V=>u.value=!u.value,["stop"]))},[le(de,{name:"chevron-down"})]),u.value?(ee(),te("div",pg,[p("button",{class:"b3-menu__item",onClick:z[1]||(z[1]=V=>{C(),u.value=!1})},[...z[6]||(z[6]=[p("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),p("button",{class:"b3-menu__item",onClick:z[2]||(z[2]=V=>{$(),u.value=!1})},[...z[7]||(z[7]=[p("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),p("button",{class:"b3-menu__item",onClick:z[3]||(z[3]=V=>{P(),u.value=!1})},[...z[8]||(z[8]=[p("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Le("",!0)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:xe},[le(de,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:K},[le(de,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:ce},[p("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:H.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,hg),le(Rh,{visible:h.value,"onUpdate:visible":z[4]||(z[4]=V=>h.value=V),"is-maximized":m.value,"onUpdate:isMaximized":z[5]||(z[5]=V=>m.value=V),title:_.value,onClose:fe},{default:Fl(()=>[b.value==="siyuan"&&y.value?(ee(),Kt(Vh,{key:0,"block-id":y.value,title:_.value,plugin:ve(i),onExternalJump:Z},null,8,["block-id","title","plugin"])):Le("",!0),M.value?Mt((ee(),Kt(xm,{key:1,visible:h.value&&b.value==="web",url:x.value,title:_.value,onExternalJump:Z},null,8,["visible","url","title"])),[[_o,b.value==="web"]]):Le("",!0)]),_:1},8,["visible","is-maximized","title"]),Mt(p("div",{class:_e(["spm-jump-badge",{"is-invalid":N.value}])},Se(w.value),3),[[_o,w.value]])],544)],32))}}),gg=Zt(mg,[["__scopeId","data-v-915718c1"]]);function Fa(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&i.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const g=parseInt(f,10);s=Math.max(s,g),n.set(r.parentContainerId,g)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const f=n.get(r.parentContainerId);o(r,{type:"step",step:f})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const g=Math.min(Number(f[0]),Number(f[1])),u=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(g)&&!isNaN(u)){s=Math.max(s,u),o(r,{type:"range",min:g,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;s+=f,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;s=Math.max(1,s-f),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){s=Math.max(s,f),o(r,{type:"step",step:f});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function vg(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Mo=980;function bg(e){if(!e)return 0;const i=Fa(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=Zc(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function yg(e,t=Mo){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",l=i.split(o).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function Jr(e,t,i=Mo,n=552,s=16){const o=i>0?i:Mo,l=n>0?n:552,r=Math.max(0,e-s),a=Math.max(0,t-s);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/o,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(l*d))}}function kg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function Xr(e,t){if(!e)return"";const i=kg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?Fa(i.blocks||[]):null,d=Da(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:a?_=>{if(vg(_,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const A=_.id||_.blockId,I=a.blockMap.get(_)||(A?a.idMap.get(A):void 0);if((I==null?void 0:I.type)==="step"&&I.step===r||(I==null?void 0:I.type)==="range"&&I.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(_,M)=>{let A=M.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(A)||(A+=" muted"),`<video ${A.trim()}>`}),f=n.spacing,g=f&&f!=="inherit"?f:o.spacing||"normal",u=["slide-content",`layout-${s}`,`spacing-${g}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),h=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const _=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;h.push(`background-image:url('${nt(_)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else h.push(`background:${nt(m)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&h.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=h.length>0?` style="${h.join("")}"`:"";return`<div class="${nt(u)}"${x}>${d}</div>`}const wg={class:"presenter-header"},xg={class:"presenter-title-area"},Sg={class:"presenter-brand"},_g={class:"header-pills"},Cg={class:"pill pill-page"},$g={key:0,class:"pill pill-step"},Ig={class:"header-toolbar"},Tg={class:"timer-capsule"},Eg={class:"timer-digits"},Ag={class:"timer-actions"},Mg=["aria-label"],Bg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Dg={key:0,class:"presenter-grid"},Lg={class:"slide-panels"},Pg={class:"panel-box current-slide-panel"},Rg={class:"panel-header"},Og={class:"panel-header-left"},Ng={class:"panel-page-num"},zg={class:"panel-header-meta"},Hg={key:0,class:"panel-step-pill"},Fg={class:"panel-layout-pill"},jg=["aria-label"],Wg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Ug={key:1,class:"panel-fallback"},Vg=["aria-label"],Kg={class:"panel-header"},Gg={class:"panel-header-left"},qg={key:0,class:"panel-page-num"},Yg={class:"panel-header-meta"},Zg={key:0,class:"panel-end-pill"},Jg={key:1,class:"panel-layout-pill"},Xg=["aria-label"],Qg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],ev={key:1,class:"panel-fallback"},tv={class:"notes-panel"},iv={class:"panel-header"},nv={class:"panel-header-left"},sv={class:"notes-size-controls"},ov=["disabled"],rv={class:"notes-size-value"},lv=["disabled"],av={key:1,class:"presenter-empty"},cv={class:"empty-icon-wrap"},dv={class:"empty-actions"},uv={class:"presenter-actions"},fv={class:"nav-btn-group"},pv=["disabled"],hv=["disabled"],mv={class:"actions-center"},gv={class:"center-meta"},vv={class:"progress-pill"},bv={class:"nav-btn-group"},yv=["aria-label"],kv={class:"step-dots-text"},wv=["disabled"],xv=["disabled"],Sv=280,_v=15,Cv=It({__name:"SlidevPresenterTab",setup(e,{expose:t}){const i=Lt("plugin"),n=Lt("sandboxBridge",new Un),s=he([]),o=he({}),l=he(1),r=he(0),a=he(0),c=he(0),d=we(()=>s.value.length||a.value),f=he(null),g=he(null),u=he({width:0,height:0}),h=he({width:0,height:0}),m=we(()=>{var ie;return yg((ie=o.value)==null?void 0:ie.aspectRatio)}),b=we(()=>{var ie;return((ie=o.value)==null?void 0:ie.theme)||"default"}),y=we(()=>{var ie;return((ie=o.value)==null?void 0:ie.colorSchema)==="light"?"light":"dark"}),x=we(()=>{var ie;return!!((ie=o.value)!=null&&ie.normalizeHeadingSizes)}),_=we(()=>Jr(u.value.width,u.value.height,m.value.baseWidth,m.value.baseHeight,14)),M=we(()=>Jr(h.value.width,h.value.height,m.value.baseWidth,m.value.baseHeight,14));function A(){f.value&&(u.value={width:f.value.clientWidth,height:f.value.clientHeight}),g.value&&(h.value={width:g.value.clientWidth,height:g.value.clientHeight})}let I=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(I||(I=new window.ResizeObserver(()=>{A()})),I.disconnect(),f.value&&I.observe(f.value),g.value&&I.observe(g.value))}Ri([f,g,d],()=>{bs(()=>{w(),A()})},{flush:"post"});const N=he(0),O=he(!0);let F=null;const q=we(()=>{const ie=String(Math.floor(N.value/60)).padStart(2,"0"),ne=String(N.value%60).padStart(2,"0");return`${ie}:${ne}`});function S(){O.value=!O.value}function H(){N.value=0}const k=he("");let E=null;function j(){const ie=new Date,ne=String(ie.getHours()).padStart(2,"0"),Ce=String(ie.getMinutes()).padStart(2,"0");k.value=`${ne}:${Ce}`}const T=we(()=>s.value.length===0?null:s.value[l.value-1]||null),B=we(()=>l.value>=s.value.length?null:s.value[l.value]||null),R=we(()=>T.value?bg(T.value):c.value),X=we(()=>l.value>1||r.value>0),U=we(()=>l.value<d.value||r.value<R.value),Y=we(()=>Xr(T.value,{config:o.value,allSlides:s.value,pageIndex:l.value,currentStep:r.value})),se=we(()=>Xr(B.value,{config:o.value,allSlides:s.value,pageIndex:l.value+1})),ae=we(()=>{var ne;if(!T.value)return"无内容";const ie=(ne=T.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value} 页`});function ce(ie){return(ie||[]).slice(1).map(ne=>(ne.content||ne.rawMarkdown||"").trim()).filter(ne=>ne&&!/^(image\s+)?assets\/\S*$/i.test(ne)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ne)).join(" | ").slice(0,120)}const ge=we(()=>{var ie;return ce((ie=T.value)==null?void 0:ie.blocks)}),Te=we(()=>{var ne;if(!B.value)return"演示结束";const ie=(ne=B.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value+1} 页`}),xe=we(()=>B.value?ce(B.value.blocks):"这是最后一页"),fe=we(()=>{var ie;return((ie=T.value)==null?void 0:ie.notes)||""}),Z=he(20);function pe(){Z.value<36&&(Z.value+=2)}function L(){Z.value>14&&(Z.value-=2)}const K=we(()=>d.value<=1?100:Math.round(l.value/d.value*100));let v=null;try{v=new BroadcastChannel("siyuan-slidev-sync"),v.onmessage=ie=>{const ne=ie.data;if(ne&&(ne.type==="SYNC_PAGE"&&typeof ne.page=="number"&&(l.value=ne.page,r.value=typeof ne.step=="number"?Math.max(0,ne.step):0,typeof ne.maxStep=="number"&&(c.value=Math.max(0,ne.maxStep))),ne.type==="SYNC_SLIDES"&&Array.isArray(ne.slides)&&(s.value=ne.slides,ne.config&&typeof ne.config=="object"&&(o.value=ne.config)),ne.type==="REQUEST_SYNC"&&s.value.length>0))try{v==null||v.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),v==null||v.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:R.value})}catch{}}}catch{v=null}function G(ie,ne=0){const Ce=Number(ie)||1,Me=Math.max(0,Number(ne)||0);n.navigatePage(Ce,Me);try{v==null||v.postMessage({type:"SYNC_PAGE",page:Ce,step:Me,maxStep:R.value})}catch{}}function W(){if(r.value<R.value){r.value++,G(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function C(){if(r.value>0){r.value--,G(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,G(l.value,0))}function $(){l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function P(){l.value>1&&(l.value--,r.value=0,G(l.value,0))}function D(){l.value=1,r.value=0,H(),G(1,0)}function z(){const ie=i;typeof(ie==null?void 0:ie.openBottomPreviewTab)=="function"&&ie.openBottomPreviewTab()}function V(){const ie=i;typeof(ie==null?void 0:ie.openStandalonePreviewWindow)=="function"&&ie.openStandalonePreviewWindow()}function J(ie){var ne,Ce;if(!(ie.key===" "&&((Ce=(ne=ie.target)==null?void 0:ne.closest)!=null&&Ce.call(ne,"button")))){if(ie.shiftKey&&ie.key==="ArrowRight"||ie.key==="ArrowDown"){ie.preventDefault(),$();return}if(ie.shiftKey&&ie.key==="ArrowLeft"||ie.key==="ArrowUp"){ie.preventDefault(),P();return}ie.key==="ArrowRight"||ie.key===" "||ie.key==="PageDown"?(ie.preventDefault(),W()):(ie.key==="ArrowLeft"||ie.key==="PageUp")&&(ie.preventDefault(),C())}}let re=0;function oe(ie){var Me,Ne;if(Math.abs(ie.deltaY)<_v)return;const ne=(Ne=(Me=ie.target)==null?void 0:Me.closest)==null?void 0:Ne.call(Me,".notes-content");if(ne){const Oe=ne.scrollHeight-ne.clientHeight;if(Oe>2&&(ie.deltaY>0&&ne.scrollTop<Oe-1||ie.deltaY<0&&ne.scrollTop>1))return}const Ce=Date.now();Ce-re<Sv||(re=Ce,ie.deltaY>0?W():C())}let me=null;return dn(()=>{var ne;F=window.setInterval(()=>{O.value&&N.value++},1e3),j(),E=window.setInterval(j,1e3),me=n.onSlideChanged((Ce,Me,Ne,Oe,De)=>{l.value=Ce,Me>0&&(a.value=Me),typeof Oe=="number"&&(r.value=Math.max(0,Oe)),typeof De=="number"&&(c.value=Math.max(0,De))});try{v==null||v.postMessage({type:"REQUEST_SYNC"})}catch{}const ie=i==null?void 0:i.latestCompiledDoc;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides,ie.config&&(o.value=ie.config)),typeof window<"u"&&window.addEventListener("resize",A),bs(()=>{w(),A()})}),Rs(()=>{F&&(window.clearInterval(F),F=null),E&&(window.clearInterval(E),E=null),me&&me(),typeof window<"u"&&window.removeEventListener("resize",A),I&&(I.disconnect(),I=null);try{v==null||v.close()}catch{}v=null}),t({updateDocument(ie){var ne;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides),ie!=null&&ie.config&&(o.value=ie.config)}}),(ie,ne)=>{var Ce,Me,Ne;return ee(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:J,onWheel:oe},[p("header",wg,[p("div",xg,[p("div",Sg,[le(de,{name:"presenter",class:"brand-icon"}),ne[1]||(ne[1]=p("span",{class:"title-name"},"演讲者控制台",-1))]),p("div",_g,[p("span",Cg,"P."+Se(l.value)+" / "+Se(d.value||1),1),R.value>0?(ee(),te("span",$g,[le(de,{name:"step",class:"pill-icon"}),St(" 步进 "+Se(r.value)+" / "+Se(R.value),1)])):Le("",!0)])]),p("div",Ig,[p("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:V},[le(de,{name:"window"}),ne[2]||(ne[2]=p("span",{class:"btn-tool-label"},"独立放映",-1))]),p("div",Tg,[le(de,{name:"clock",class:"timer-icon"}),p("span",Eg,Se(q.value),1),p("div",Ag,[p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":O.value?"暂停计时":"继续计时",onClick:S},[le(de,{name:O.value?"pause":"play"},null,8,["name"])],8,Mg),p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:H},[le(de,{name:"reset"})])])]),p("div",Bg,[p("span",null,Se(k.value),1)])])]),d.value>0?(ee(),te("main",Dg,[p("section",Lg,[p("div",Pg,[p("div",Rg,[p("div",Og,[ne[3]||(ne[3]=p("span",{class:"panel-tag is-current"},"当前放映",-1)),p("span",Ng,"P."+Se(l.value),1)]),p("div",zg,[R.value>0?(ee(),te("span",Hg," 步进 "+Se(r.value)+" / "+Se(R.value),1)):Le("",!0),p("span",Fg,Se(((Me=(Ce=T.value)==null?void 0:Ce.frontmatter)==null?void 0:Me.layout)||"default"),1)])]),p("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":ae.value},[T.value?(ee(),te("div",{key:0,class:"presenter-thumb-box",style:Ut({width:_.value.boxWidth+"px",height:_.value.boxHeight+"px"})},[p("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Ut({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+_.value.scale+")"}),innerHTML:Y.value},null,14,Wg)],4)):(ee(),te("div",Ug,[p("h2",null,Se(ae.value),1),p("p",null,Se(ge.value),1)]))],8,jg)]),p("div",{class:_e(["panel-box next-slide-panel",{"is-clickable":!!B.value,"b3-tooltips b3-tooltips__n":!!B.value}]),"aria-label":B.value?"点击直接跳至下一页":"",onClick:ne[0]||(ne[0]=Oe=>B.value&&$())},[p("div",Kg,[p("div",Gg,[ne[4]||(ne[4]=p("span",{class:"panel-tag"},"下一页预告",-1)),l.value<d.value?(ee(),te("span",qg,"P."+Se(l.value+1),1)):Le("",!0)]),p("div",Yg,[l.value>=d.value?(ee(),te("span",Zg,"已到尾页")):B.value?(ee(),te("span",Jg,Se(((Ne=B.value.frontmatter)==null?void 0:Ne.layout)||"default"),1)):Le("",!0)])]),p("div",{ref_key:"nextPreviewRef",ref:g,class:"panel-preview panel-preview--dim","aria-label":Te.value},[B.value?(ee(),te("div",{key:0,class:"presenter-thumb-box",style:Ut({width:M.value.boxWidth+"px",height:M.value.boxHeight+"px"})},[p("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Ut({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+M.value.scale+")"}),innerHTML:se.value},null,14,Qg)],4)):(ee(),te("div",ev,[p("h2",null,Se(Te.value),1),p("p",null,Se(xe.value),1)]))],8,Xg)],10,Vg)]),p("section",tv,[p("div",iv,[p("div",nv,[le(de,{name:"notes",class:"panel-title-icon"}),ne[5]||(ne[5]=p("span",null,"讲稿备忘",-1))]),p("div",sv,[p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:Z.value<=14,onClick:L},[le(de,{name:"minus"})],8,ov),p("span",rv,Se(Z.value)+"px",1),p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:Z.value>=36,onClick:pe},[le(de,{name:"plus"})],8,lv)])]),p("div",{class:_e(["notes-content",{"is-empty":!fe.value}]),style:Ut({fontSize:Z.value+"px"})},Se(fe.value||"（本页未设置演讲者备忘录）"),7)])])):(ee(),te("main",av,[p("div",cv,[le(de,{name:"refresh",class:"empty-icon"})]),ne[8]||(ne[8]=p("h2",null,"等待大屏放映数据",-1)),ne[9]||(ne[9]=p("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),p("div",dv,[p("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:z},[le(de,{name:"presenter"}),ne[6]||(ne[6]=p("span",null,"打开大屏放映页签",-1))]),p("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:V},[le(de,{name:"window"}),ne[7]||(ne[7]=p("span",null,"弹出独立放映窗口",-1))])])])),p("footer",uv,[p("div",fv,[p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:P},[le(de,{name:"chevrons-left"}),ne[10]||(ne[10]=p("span",null,"上一页",-1))],8,pv),p("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!X.value,"aria-label":"回退一步 (←)",onClick:C},[le(de,{name:"chevron-left"}),ne[11]||(ne[11]=p("span",null,"上一步",-1))],8,hv)]),p("div",mv,[p("div",gv,[p("span",vv,Se(K.value)+"%",1)]),p("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:D},[le(de,{name:"reset"}),ne[12]||(ne[12]=p("span",null,"重头放映",-1))])]),p("div",bv,[R.value>0?(ee(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${R.value}`},[(ee(!0),te(Ke,null,kt(R.value,Oe=>(ee(),te("span",{key:Oe,class:_e(["step-dot",{"is-active":Oe<=r.value}])},null,2))),128)),p("span",kv,Se(r.value)+"/"+Se(R.value),1)],8,yv)):Le("",!0),p("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!U.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:W},[ne[13]||(ne[13]=p("span",null,"下一步",-1)),le(de,{name:"chevron-right"})],8,wv),p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:$},[ne[14]||(ne[14]=p("span",null,"下一页",-1)),le(de,{name:"chevrons-right"})],8,xv)])])],32)}}}),$v=Zt(Cv,[["__scopeId","data-v-aa1ee0a8"]]),Iv={class:"spm-layout-picker"},Tv={class:"spm-layout-picker__grid"},Ev=["title","onClick"],Av={class:"spm-layout-icon"},Mv={class:"spm-layout-label"},Bv=It({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ee(),te("div",Iv,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",Tv,[(ee(),te(Ke,null,kt(s,c=>p("div",{key:c.name,class:_e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[p("div",Av,[le(de,{name:"layout-"+c.name},null,8,["name"])]),p("span",Mv,Se(c.label),1)],10,Ev)),64))])]))}}),Dv=Zt(Bv,[["__scopeId","data-v-1964d02c"]]),Lv={key:0,class:"spm-transition-selector__header"},Pv={class:"spm-transition-list"},Rv=["onClick"],Ov={class:"spm-transition-meta"},Nv={class:"spm-transition-label"},zv={class:"spm-transition-name"},Hv={class:"spm-transition-preview-box"},Fv=It({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,l)=>(ee(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Le("",!0):(ee(),te("div",Lv,Se(e.title||"转场动效"),1)),p("div",Pv,[(ee(),te(Ke,null,kt(n,r=>p("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>s(r.name)},[p("div",Ov,[p("span",Nv,Se(r.label),1),p("span",zv,"("+Se(r.name)+")",1)]),p("div",Hv,[p("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Rv)),64))])],2))}}),ja=Zt(Fv,[["__scopeId","data-v-8597e99e"]]),jv={class:"spm-section spm-section--page"},Wv={class:"spm-section-header"},Uv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Vv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Kv={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Gv={key:1,class:"spm-card-control"},qv={class:"spm-control-header"},Yv={class:"spm-control-title-group"},Zv={class:"spm-control-title"},Jv={class:"spm-quick-chips"},Xv=["onClick"],Qv={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},eb=["value"],tb=["aria-label"],ib={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},nb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},sb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},ob={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},rb={class:"spm-card-control"},lb={class:"spm-control-header"},ab={class:"spm-control-title-group"},cb={class:"spm-control-title"},db={class:"spm-segmented-group"},ub={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},fb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},pb={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},hb={class:"spm-quick-chips"},mb=["onClick"],gb={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},vb=["value"],bb={style:{display:"flex",gap:"8px","margin-top":"2px"}},yb={style:{flex:"1"}},kb={class:"spm-segmented-group"},wb={style:{flex:"1"}},xb={class:"spm-segmented-group"},Sb={class:"spm-card-control"},_b={class:"spm-control-header"},Cb={class:"spm-control-title-group"},$b={class:"spm-control-title"},Ib={class:"spm-segmented-group"},Tb={class:"spm-card-control"},Eb={class:"spm-control-header"},Ab={class:"spm-control-title-group"},Mb={class:"spm-control-title"},Bb={class:"spm-quick-chips"},Db=["onClick"],Lb=["value"],Pb={key:2,class:"spm-card-control"},Rb={class:"spm-control-header"},Ob={class:"spm-control-title-group"},Nb={class:"spm-control-title"},zb={class:"spm-quick-chips"},Hb=["onClick"],Fb=["value"],jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Kb={key:0,class:"spm-note-status-box"},Gb=["title"],qb={class:"spm-action-grid",style:{"margin-top":"6px"}},Yb={key:1,class:"spm-note-empty-box"},Zb={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Jb={class:"spm-action-grid"},Xb=["disabled"],Qb=["disabled"],e1={class:"spm-card-control"},t1={class:"spm-action-grid"},i1=It({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=we(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=we(()=>{var m,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const y=u.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}const h=(i.detectedSbRatio||"").trim();if(h.includes(":")){const y=h.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}if((m=i.detectedSbInfo)!=null&&m.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const y=i.detectedSbInfo.slots.length;if(y>=2&&y<=6)return y}return 2}),r=we(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=we(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,h=Array(u).fill("1").join(":");n("update:pageLayoutRatio",h),n("resetSuperblockRatio")}const d=we(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),f=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],g=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,h)=>(ee(),te("div",jv,[p("div",Wv,[p("span",null,"幻灯片页面设置"+Se(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(Dv,{"model-value":e.pageLayout,onChange:h[0]||(h[0]=m=>u.$emit("update:pageLayout",m))},null,8,["model-value"]),!o.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(ee(),te("div",Uv,[p("div",Vv,[p("div",Kv,[le(de,{name:"sparkles"}),p("span",null,[h[31]||(h[31]=St("检测到本页横向超级块列宽比例：",-1)),p("b",null,Se(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:h[1]||(h[1]=m=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(de,{name:"columns"}),h[32]||(h[32]=p("span",null,"设为分栏",-1))])])])):Le("",!0),o.value?(ee(),te("div",Gv,[p("div",qv,[p("div",Yv,[p("div",Zv,[le(de,{name:"ratio"}),h[33]||(h[33]=p("span",null,"分栏比例 (Ratio)",-1))]),h[34]||(h[34]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",Jv,[(ee(!0),te(Ke,null,kt(r.value,m=>(ee(),te("button",{key:m.value,class:_e(["spm-chip",{active:a.value===m.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",m.value)},Se(m.label),11,Xv))),128))]),p("div",Qv,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:h[2]||(h[2]=m=>u.$emit("update:pageLayoutRatio",m.target.value)),onChange:h[3]||(h[3]=m=>u.$emit("update:pageLayoutRatio",m.target.value))},null,40,eb),e.detectedSbRatio?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:h[4]||(h[4]=m=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(de,{name:"sparkles"}),h[35]||(h[35]=p("span",null,"读取",-1))],8,tb)):(ee(),te("button",ib,[le(de,{name:"sparkles"}),h[36]||(h[36]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[le(de,{name:"reset"}),h[37]||(h[37]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(ee(),te("div",nb,[le(de,{name:"ratio"}),h[38]||(h[38]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",sb,Se(e.detectedSbRatio),1)])):(ee(),te("div",ob,[le(de,{name:"ratio"}),h[39]||(h[39]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Le("",!0),le(ja,{"model-value":e.pageTransition,onChange:h[5]||(h[5]=m=>u.$emit("update:pageTransition",m))},null,8,["model-value"]),p("div",rb,[p("div",lb,[p("div",ab,[p("div",cb,[le(de,{name:"sparkles"}),h[40]||(h[40]=p("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),h[41]||(h[41]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",db,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:h[6]||(h[6]=m=>u.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:h[7]||(h[7]=m=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:h[8]||(h[8]=m=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(ee(),te("div",ub,[p("div",fb,[h[43]||(h[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",pb,[le(de,{name:"help"}),h[42]||(h[42]=p("span",null,"输入规则",-1))])]),p("div",hb,[(ee(),te(Ke,null,kt(s,m=>p("button",{key:m.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===m.value}]),onClick:b=>u.$emit("update:pageMaskRatio",m.value)},Se(m.label),11,mb)),64))]),p("div",gb,[p("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:h[9]||(h[9]=m=>u.$emit("update:pageMaskRatio",m.target.value)),onChange:h[10]||(h[10]=m=>u.$emit("update:pageMaskRatio",m.target.value))},null,40,vb)]),h[46]||(h[46]=p("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),p("div",bb,[p("div",yb,[h[44]||(h[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",kb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:h[11]||(h[11]=m=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:h[12]||(h[12]=m=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",wb,[h[45]||(h[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",xb,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:h[13]||(h[13]=m=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:h[14]||(h[14]=m=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Le("",!0)]),p("div",Sb,[p("div",_b,[p("div",Cb,[p("div",$b,[le(de,{name:"ratio"}),h[47]||(h[47]=p("span",null,"页面间距 (Spacing)",-1))]),h[48]||(h[48]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",Ib,[p("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:h[15]||(h[15]=m=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:h[16]||(h[16]=m=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:h[17]||(h[17]=m=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:h[18]||(h[18]=m=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Tb,[p("div",Eb,[p("div",Ab,[p("div",Mb,[le(de,{name:"palette"}),h[49]||(h[49]=p("span",null,"页面背景 (Background)",-1))]),h[50]||(h[50]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",Bb,[(ee(),te(Ke,null,kt(f,m=>p("button",{key:m.value,class:_e(["spm-chip",{active:e.pageBackground===m.value}]),onClick:b=>u.$emit("update:pageBackground",m.value)},Se(m.label),11,Db)),64))]),p("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:h[19]||(h[19]=m=>u.$emit("update:pageBackground",m.target.value)),onChange:h[20]||(h[20]=m=>u.$emit("update:pageBackground",m.target.value))},null,40,Lb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(ee(),te("div",Pb,[p("div",Rb,[p("div",Ob,[p("div",Nb,[le(de,{name:"image"}),h[51]||(h[51]=p("span",null,"页面图片 (Image)",-1))]),h[52]||(h[52]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",zb,[(ee(),te(Ke,null,kt(g,m=>p("button",{key:m.value,class:_e(["spm-chip",{active:e.pageImage===m.value}]),onClick:b=>u.$emit("update:pageImage",m.value)},Se(m.label),11,Hb)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:h[21]||(h[21]=m=>u.$emit("update:pageImage",m.target.value)),onChange:h[22]||(h[22]=m=>u.$emit("update:pageImage",m.target.value))},null,40,Fb)])):Le("",!0),p("div",jb,[p("div",Wb,[p("div",Ub,[p("div",Vb,[le(de,{name:"presenter"}),h[53]||(h[53]=p("span",null,"演讲者提词 (Notes)",-1))]),h[54]||(h[54]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:h[23]||(h[23]=m=>u.$emit("generateNotes"))},[le(de,{name:"sparkles"}),h[55]||(h[55]=p("span",null,"AI 讲稿",-1))])]),e.pageNotes?(ee(),te("div",Kb,[h[58]||(h[58]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},Se(d.value),9,Gb),p("div",qb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:h[24]||(h[24]=m=>u.$emit("locateNoteBlock"))},[le(de,{name:"search"}),h[56]||(h[56]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:h[25]||(h[25]=m=>u.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),h[57]||(h[57]=p("span",null,"追加讲稿块",-1))])])])):(ee(),te("div",Yb,[h[60]||(h[60]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:h[26]||(h[26]=m=>u.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),h[59]||(h[59]=p("span",null,"添加讲稿备注块",-1))])])),p("div",Zb,[p("div",Jb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Ut(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:h[27]||(h[27]=m=>u.$emit("batchAppendNotes"))},[le(de,{name:"insert-below"}),h[61]||(h[61]=p("span",null,"全部追加",-1))],12,Xb),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Ut(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:h[28]||(h[28]=m=>u.$emit("batchDeleteNotes"))},[le(de,{name:"trash"}),h[62]||(h[62]=p("span",null,"全部删除",-1))],12,Qb)])])]),p("div",e1,[h[65]||(h[65]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",t1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:h[29]||(h[29]=m=>u.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),h[63]||(h[63]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:h[30]||(h[30]=m=>u.$emit("deleteDivider"))},[le(de,{name:"trash"}),h[64]||(h[64]=p("span",null,"删除此页",-1))])])])]))}}),n1=Zt(i1,[["__scopeId","data-v-1f9d4630"]]),s1={class:"spm-section spm-section--block"},o1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title"},c1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},d1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},u1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},f1={key:0},p1={key:1},h1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},m1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},g1={class:"spm-action-grid"},v1={class:"spm-card-control"},b1={class:"spm-control-header"},y1={class:"spm-control-title-group"},k1={class:"spm-control-title"},w1=["aria-label"],x1=["checked"],S1={key:1,class:"spm-card-control"},_1={class:"spm-control-header"},C1={class:"spm-control-title-group"},$1={class:"spm-control-title"},I1={class:"spm-quick-chips"},T1={key:2,class:"spm-card-control"},E1={class:"spm-control-header"},A1={class:"spm-control-title-group"},M1={class:"spm-control-title"},B1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},D1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},L1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},P1=["aria-label"],R1=["checked"],O1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},N1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},z1=["aria-label"],H1=["checked"],F1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},j1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},W1=["aria-label"],U1=["checked"],V1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},K1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},G1=["aria-label"],q1=["checked"],Y1={class:"spm-card-control"},Z1={class:"spm-control-header"},J1={class:"spm-control-title-group"},X1={class:"spm-control-title"},Q1=["aria-label"],ey=["checked"],ty={key:0,class:"spm-quick-chips"},iy=["onClick"],ny={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},sy={class:"spm-card-control"},oy={class:"spm-control-header"},ry={class:"spm-control-title-group"},ly={class:"spm-control-title"},ay=["aria-label"],cy=["checked"],dy={key:0,class:"spm-quick-chips"},uy=["onClick"],fy={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},py={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},hy={style:{display:"flex",gap:"6px"}},my=["value"],gy=["value"],vy={key:3,class:"spm-card-control"},by={class:"spm-control-header"},yy={class:"spm-control-title-group"},ky={class:"spm-control-title"},wy={class:"spm-control-desc"},xy={class:"spm-segmented-group"},Sy=["onClick"],_y={key:4,class:"spm-card-control"},Cy={class:"spm-control-header"},$y={class:"spm-control-title-group"},Iy={class:"spm-control-title"},Ty={class:"spm-quick-chips"},Ey=["onClick"],Ay=["value"],My={key:5,class:"spm-card-control"},By={class:"spm-control-header"},Dy={class:"spm-control-title-group"},Ly={class:"spm-control-title"},Py={class:"spm-quick-chips"},Ry=["onClick"],Oy=["value"],Ny={class:"spm-card-control"},zy={class:"spm-action-grid"},Hy=["aria-label"],Fy=It({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=we(()=>{const I=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":I}),s=we(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),o=we(()=>{var w,N,O,F;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const I=(N=i.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(I){const q=parseInt(I[1],10);if(q>=2&&q<=6)return Math.max(q,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((F=(O=i.detectedSbInfo)==null?void 0:O.ratio)!=null&&F.includes(":")){const q=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(q.length>=2)return Math.min(q.length,6)}return 3}),l=we(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=we(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=we(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let O=1;O<=w;O++)N.push({value:`col-${O}`,label:`第 ${O} 栏`});return N});function c(I){const w=i.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&o.value===3||I==="col-2"&&w==="right"&&o.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,f=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=we(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const I=JSON.parse(i.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=we(()=>!!g.value),h=we(()=>{var I;return((I=g.value)==null?void 0:I.preset)||"slide-up"}),m=we(()=>{var I;return((I=g.value)==null?void 0:I.duration)||0}),b=we(()=>{var I;return((I=g.value)==null?void 0:I.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(I){A(I,m.value,b.value)}function _(I){A(h.value,I,b.value)}function M(I){A(h.value,m.value,I)}function A(I,w,N){if(!I||I==="none"){d("update:elemMotion","");return}if(!w&&!N){d("update:elemMotion",I);return}const O={preset:I};w>0&&(O.duration=w),N>0&&(O.delay=N),d("update:elemMotion",JSON.stringify(O))}return(I,w)=>{var N,O,F,q,S,H;return ee(),te("div",s1,[w[62]||(w[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(N=e.detectedSbInfo)!=null&&N.hasSuperBlock?(ee(),te("div",o1,[p("div",r1,[p("div",l1,[p("div",a1,[le(de,{name:"ratio"}),w[24]||(w[24]=p("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",c1,[p("div",d1,[p("div",u1,[le(de,{name:"ratio"}),(O=e.detectedSbInfo)!=null&&O.isCustomWidth?(ee(),te("span",f1,"已识别自定义列宽比例")):(ee(),te("span",p1,"识别到 "+Se(((F=e.detectedSbInfo)==null?void 0:F.colCount)||2)+" 列超级块分栏",1))]),p("code",h1,Se(((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1"),1)]),p("div",m1,Se((S=e.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",g1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>I.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(de,{name:"sparkles"}),w[26]||(w[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var E;return I.$emit("applySuperBlockRatio",((E=e.detectedSbInfo)==null?void 0:E.ratio)||"1:1")})},[le(de,{name:"check"}),p("span",null,"应用比例 ("+Se(((H=e.detectedSbInfo)==null?void 0:H.ratio)||"1:1")+")",1)])])])):Le("",!0),p("div",v1,[p("div",b1,[p("div",y1,[p("div",k1,[le(de,{name:"presenter"}),w[27]||(w[27]=p("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>I.$emit("toggleNote"))},null,40,x1),w[29]||(w[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,w1)])]),e.isImage||e.imageRole?(ee(),te("div",S1,[p("div",_1,[p("div",C1,[p("div",$1,[le(de,{name:"image"}),w[30]||(w[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",I1,[p("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>I.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>I.$emit("update:imageRole","background"))},[le(de,{name:"image"}),w[32]||(w[32]=p("span",null,"背景图",-1))],2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>I.$emit("update:imageRole","image-left"))},[le(de,{name:"image-left"}),w[33]||(w[33]=p("span",null,"图左",-1))],2),p("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>I.$emit("update:imageRole","image-right"))},[le(de,{name:"image-right"}),w[34]||(w[34]=p("span",null,"图右",-1))],2)])])):Le("",!0),e.isVideo?(ee(),te("div",T1,[p("div",E1,[p("div",A1,[p("div",M1,[le(de,{name:"video"}),w[35]||(w[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",B1,[p("div",D1,[p("span",L1,[le(de,{name:"sliders"}),w[37]||(w[37]=St(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>I.$emit("toggleVideoControls"))},null,40,R1),w[38]||(w[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,P1)]),p("div",O1,[p("span",N1,[le(de,{name:"video"}),w[39]||(w[39]=St(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>I.$emit("toggleVideoAutoplay"))},null,40,H1),w[40]||(w[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,z1)]),p("div",F1,[p("span",j1,[le(de,{name:"repeat"}),w[41]||(w[41]=St(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>I.$emit("toggleVideoLoop"))},null,40,U1),w[42]||(w[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,W1)]),p("div",V1,[p("span",K1,[le(de,{name:"volume-x"}),w[43]||(w[43]=St(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>I.$emit("toggleVideoMuted"))},null,40,q1),w[44]||(w[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,G1)])])])):Le("",!0),p("div",Y1,[p("div",Z1,[p("div",J1,[p("div",X1,[le(de,{name:"step"}),w[45]||(w[45]=p("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>I.$emit("toggleElemClick"))},null,40,ey),w[47]||(w[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,Q1)]),e.elemClick?(ee(),te("div",ty,[(ee(),te(Ke,null,kt(["+1","1","2","hide"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemClick===k}]),onClick:E=>I.$emit("update:elemClick",k)},Se(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,iy)),64))])):e.parentElemClick?(ee(),te("div",ny,[le(de,{name:"check"}),w[48]||(w[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Le("",!0)]),p("div",sy,[p("div",oy,[p("div",ry,[p("div",ly,[le(de,{name:"motion"}),w[49]||(w[49]=p("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:u.value,onChange:y},null,40,cy),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,ay)]),u.value?(ee(),te("div",dy,[(ee(),te(Ke,null,kt(f,k=>p("button",{key:k.value,class:_e(["spm-chip",{active:h.value===k.value}]),onClick:E=>x(k.value)},Se(k.label),11,uy)),64))])):Le("",!0),u.value?(ee(),te("div",fy,[p("div",py,[p("span",null,"时长: "+Se(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+Se(b.value?b.value+"ms":"0ms"),1)]),p("div",hy,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:w[12]||(w[12]=k=>_(Number(k.target.value)))},[...w[52]||(w[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,my),p("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=k=>M(Number(k.target.value)))},[...w[53]||(w[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,gy)])])):Le("",!0)]),s.value||e.elemSlot?(ee(),te("div",vy,[p("div",by,[p("div",yy,[p("div",ky,[le(de,{name:"columns"}),p("span",null,Se(l.value),1)]),p("span",wy,Se(r.value),1)])]),p("div",xy,[(ee(!0),te(Ke,null,kt(a.value,k=>(ee(),te("button",{key:k.value,class:_e(["spm-segmented-item",{active:c(k.value)}]),onClick:E=>I.$emit("update:elemSlot",k.value)},Se(k.label),11,Sy))),128))])])):Le("",!0),e.isCodeBlock?(ee(),te("div",_y,[p("div",Cy,[p("div",$y,[p("div",Iy,[le(de,{name:"code"}),w[54]||(w[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Ty,[(ee(),te(Ke,null,kt(["1-3","all","1|2|3","2-5"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:E=>I.$emit("update:elemShikiLines",k)},Se(k),11,Ey)),64)),e.elemShikiLines?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Le("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>I.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>I.$emit("update:elemShikiLines",k.target.value))},null,40,Ay)])):Le("",!0),e.isCodeBlock?(ee(),te("div",My,[p("div",By,[p("div",Dy,[p("div",Ly,[le(de,{name:"code"}),w[56]||(w[56]=p("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",Py,[(ee(),te(Ke,null,kt(["240px","320px","400px","50vh"],k=>p("button",{key:k,class:_e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:E=>I.$emit("update:elemMaxHeight",k)},Se(k),11,Ry)),64)),e.elemMaxHeight?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Le("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>I.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>I.$emit("update:elemMaxHeight",k.target.value))},null,40,Oy)])):Le("",!0),p("div",Ny,[w[61]||(w[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",zy,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>I.$emit("insertDividerBefore"))},[le(de,{name:"insert-above"}),w[58]||(w[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>I.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),w[59]||(w[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>I.$emit("setTwoColsContrast"))},[le(de,{name:"columns"}),p("span",null,Se(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Hy),e.hasBlockAttrs?(ee(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=k=>I.$emit("clearBlockAttrs"))},[le(de,{name:"broom"}),w[60]||(w[60]=p("span",null,"清除属性",-1))])):Le("",!0)])])])}}}),jy={class:"spm-section spm-section--doc"},Wy={class:"spm-card-control"},Uy={class:"spm-control-header"},Vy={class:"spm-control-title-group"},Ky={class:"spm-control-title"},Gy={class:"spm-segmented-group"},qy=["aria-label","onClick"],Yy={class:"spm-card-control"},Zy={class:"spm-control-header"},Jy={class:"spm-control-title-group"},Xy={class:"spm-control-title"},Qy={class:"spm-segmented-group"},e0={class:"spm-card-control"},t0={class:"spm-control-header"},i0={class:"spm-control-title-group"},n0={class:"spm-control-title"},s0={class:"spm-segmented-group"},o0={class:"spm-card-control"},r0={class:"spm-control-header"},l0={class:"spm-control-title-group"},a0={class:"spm-control-title"},c0={class:"spm-card-control"},d0={class:"spm-control-header"},u0={class:"spm-control-title-group"},f0={class:"spm-control-title"},p0=["aria-label"],h0=["checked"],m0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},g0=["value"],v0={class:"spm-card-control"},b0={class:"spm-control-header"},y0={class:"spm-control-title-group"},k0={class:"spm-control-title"},w0=["aria-label"],x0=["checked"],S0={class:"spm-card-control"},_0={class:"spm-action-grid"},C0=It({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=Lt("plugin"),i=gi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Bi({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Bi({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Bi({webServeUrl:a})}function r(a){Bi({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ee(),te("div",jy,[c[41]||(c[41]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",Wy,[p("div",Uy,[p("div",Vy,[p("div",Ky,[le(de,{name:"palette"}),c[19]||(c[19]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[20]||(c[20]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",Gy,[(ee(),te(Ke,null,kt(n,d=>p("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:f=>a.$emit("update:docTheme",d.value)},Se(d.label),11,qy)),64))])]),p("div",Yy,[p("div",Zy,[p("div",Jy,[p("div",Xy,[le(de,{name:"ratio"}),c[21]||(c[21]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[22]||(c[22]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",Qy,[p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",e0,[p("div",t0,[p("div",i0,[p("div",n0,[le(de,{name:"ratio"}),c[23]||(c[23]=p("span",null,"间距风格 (Spacing)",-1))]),c[24]||(c[24]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",s0,[p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",o0,[p("div",r0,[p("div",l0,[p("div",a0,[le(de,{name:"transition"}),c[25]||(c[25]=p("span",null,"全局默认转场",-1))]),c[26]||(c[26]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),le(ja,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),p("div",c0,[p("div",d0,[p("div",u0,[p("div",f0,[le(de,{name:"external-link"}),c[27]||(c[27]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[28]||(c[28]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:ve(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,h0),c[29]||(c[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,p0)]),ve(i).enableWebServeJump?(ee(),te("div",m0,[p("input",{value:ve(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Vt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Vt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,g0),c[30]||(c[30]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Le("",!0)]),p("div",v0,[p("div",b0,[p("div",y0,[p("div",k0,[le(de,{name:"type"}),c[31]||(c[31]=p("span",null,"固定特定标题大小",-1))]),c[32]||(c[32]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:ve(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,x0),c[33]||(c[33]=p("span",{class:"spm-switch-slider"},null,-1))],8,w0)])]),p("div",S0,[c[40]||(c[40]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",_0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[le(de,{name:"split-preview"}),c[34]||(c[34]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[le(de,{name:"presenter"}),c[35]||(c[35]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[le(de,{name:"sparkles"}),c[36]||(c[36]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[le(de,{name:"export-html"}),c[37]||(c[37]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[le(de,{name:"export-pdf"}),c[38]||(c[38]=p("span",null,"导出 PDF",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"逐页导出高清图片包 (ZIP)",onClick:c[18]||(c[18]=d=>a.$emit("exportImages"))},[le(de,{name:"export-image"}),c[39]||(c[39]=p("span",null,"导出图片",-1))])])])]))}}),$0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,I0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function T0(e){const t=await Oa.loadAsync(e),i={},n=[];let s="",o="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||I0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=d)}else if($0.test(c)){const d=await a.file.async("uint8array"),f=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:f,data:d,blob:g})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function E0(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const o=s.pageAttrs["custom-slidev-background"],l=i(o);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const s=e.docRootAttrs["custom-slidev-background"],o=i(s);o&&(e.docRootAttrs["custom-slidev-background"]=o)}return e}function Wa(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function A0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[h,m]of Object.entries(a))if(h.endsWith(`/${r}`)||u&&h.endsWith(`/${u}`)){c=m;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const h=require("path");u.push(h.resolve(t.baseDir,r)),u.push(h.resolve(t.baseDir,o))}catch{}try{const h=require("path");u.push(h.resolve(process.cwd(),r))}catch{}for(const h of u){const m=Wa(h);if(m!==null){c=m;break}}}if(!c){const u=Ia||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[m,b]of Object.entries(u))if(m.endsWith(`/${r}`)||h&&m.endsWith(`/${h}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(u);if(h){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(m?m[1]:"")+h[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${d}
\`\`\``}function M0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function os(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const f=i[n];if(!f.trim()){c.push(""),n++;continue}const u=f.match(/^(\s+)/),h=u?u[1].length:0;if(d===-1&&(d=h),h<d)break;c.push(f.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=M0(a),!a){let c=n+1;const d=[];let f=-1;for(;c<i.length;){const g=i[c],u=g.trim();if(!u||u.startsWith("#")){f!==-1&&d.push(""),c++;continue}const h=g.match(/^(\s+)/),m=h?h[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;d.push(g.slice(f)),c++}if(d.length>0){t[r]=os(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const B0=/^\s*```ya?ml([\s\S]*?)```/;function Qr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=os(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(B0);if(s)t=os(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=os(l.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function D0(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let f=l+1;for(;f<t.length&&!t[f].trimStart().startsWith(d);f++);f<t.length&&(l=f)}}return n<t.length&&o(t.length),i}function rs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const f=D0(d),g={};let u="",h="",m=0;if(f.length>0){const F=f[0],q=Qr(F),S=Object.keys(q.frontmatter).length>0,H=q.content.length>0;S&&!H&&f.length>1?(m=1,b(q.frontmatter)):S&&b(q.frontmatter)}function b(F){u=F.title||"",F.theme&&(g[En]=String(F.theme)),F.aspectRatio&&(g[An]=String(F.aspectRatio)),F.highlighter&&(g[al]=String(F.highlighter)),F.transition&&(g[Mn]=String(F.transition)),F.colorSchema&&(g[cl]=String(F.colorSchema)),F.layout&&(g[ke]=String(F.layout)),F.background&&(g[et]=String(F.background)),F.image&&(g[Bt]=String(F.image)),F.class&&(g[Ki]=String(F.class));for(const[q,S]of Object.entries(F))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(q)||(g[`custom-slidev-${q}`]=typeof S=="object"?JSON.stringify(S):String(S))}const y=[];let x=0,_=0,M=0,A=0;const I=new Set,w={};let N=1;for(let F=m;F<f.length;F++){const q=f[F],{frontmatter:S,content:H}=Qr(q),k=q.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),E=S.src||(k?k[1]:void 0);if(E){const fe=String(E).trim().replace(/^['"]|['"]$/g,"");let Z=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!Z){const L=fe.replace(/^\.\//,""),K=[];if(t.baseDir)try{const v=require("path");K.push(v.resolve(t.baseDir,L)),K.push(v.resolve(t.baseDir,fe))}catch{}try{const v=require("path");K.push(v.resolve(process.cwd(),L)),K.push(v.resolve(process.cwd(),fe))}catch{}for(const v of K){const G=Wa(v);if(G!==null){Z=G;break}}}const pe={};S.layout&&(pe[ke]=String(S.layout)),S.transition&&(pe[pt]=String(S.transition)),S.background&&(pe[et]=String(S.background)),S.image&&(pe[Bt]=String(S.image)),S.class&&(pe[Ki]=String(S.class));for(const[L,K]of Object.entries(S))["src","layout","transition","background","image","class"].includes(L)||(pe[`custom-slidev-${L}`]=typeof K=="object"?JSON.stringify(K):String(K));if(Z){const L=rs(Z,{...t,virtualFiles:c});for(const K of L.slides){K.pageIndex=N++,K.pageAttrs={...pe,...K.pageAttrs},y.push(K);const v=K.pageAttrs[ke]||"default";w[v]=(w[v]||0)+1}continue}else{y.push({pageIndex:N++,pageAttrs:{...pe,"custom-slidev-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=pe[ke]||"default";w[L]=(w[L]||0)+1;continue}}const j={};S.layout&&(j[ke]=String(S.layout)),S.transition&&(j[pt]=String(S.transition)),S.background&&(j[et]=String(S.background)),S.image&&(j[Bt]=String(S.image)),S.class&&(j[Ki]=String(S.class)),S.mask&&(j[Gi]=String(S.mask)),(S.maskRatio||S["mask-ratio"])&&(j[qi]=String(S.maskRatio||S["mask-ratio"])),(S.maskStyle||S["mask-style"])&&(j[Yi]=String(S.maskStyle||S["mask-style"])),(S.maskInitial||S["mask-initial"])&&(j[Zi]=String(S.maskInitial||S["mask-initial"]));for(const[fe,Z]of Object.entries(S))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(j[`custom-slidev-${fe}`]=typeof Z=="object"?JSON.stringify(Z):String(Z));let T=H;const B=[];let R=T.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const Z=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(fe),Z});R=R.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const Z=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(fe),Z});let X="";const U=Array.from(R.matchAll(/<!--([\s\S]*?)-->/g));if(U.length>0){const fe=U[U.length-1],Z=R.slice(fe.index+fe[0].length).trim();if(!Z||!Z.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=fe[1].trim();L.startsWith("TODO:")||(X=L,x++),i&&(R=R.slice(0,fe.index).trimEnd()+R.slice(fe.index+fe[0].length))}}i&&(R=R.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<B.length;fe++)R=R.replace(`__CODE_TOKEN_NOTE_${fe}__`,B[fe]);if(T=R,X){for(let pe=0;pe<B.length;pe++)X=X.replace(`__CODE_TOKEN_NOTE_${pe}__`,B[pe]);const Z=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slidev-note="true"}`;T=T?`${T}

${Z}`:Z}let Y=!1;if(/<style\b/i.test(T)){Y=!0;const fe=T.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const Z of fe){const pe=Z.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${pe}`:pe}l&&(T=T.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const se=T.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);se&&(_+=se.length);const ae=T.match(/```\w+\s+\{[^}]+\}/g);ae&&(M+=ae.length);const ce=T.match(/::\w+::|<template\s+#[^>]+>/g);if(ce&&(A+=ce.length),T=T.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>A0(fe,{...t,virtualFiles:c})||fe),n&&(T=T.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(T=T.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),T=T.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(T=T.replace(/^::\w+::\s*$/gm,"")),r&&(T=Of(T)),a){let fe=T.trim(),Z="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(Z=fe.slice(pe),fe=fe.slice(0,pe).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const L=String(S.image).trim(),K=S.layout==="image-left"?"image-left":"image-right",v=`![配图](${L})
{: custom-slidev-layout="${K}" }`;S.layout==="image-left"?fe=`{{{col

${v}

${fe}

}}}`:fe=`{{{col

${fe}

${v}

}}}`}if(S.background){const K=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;fe=fe?`${K}

${fe}`:K}T=Z?`${fe}

${Z}`:fe}const ge=L0(T);j[et]&&ge.push(j[et]),j[Bt]&&ge.push(j[Bt]);for(const fe of ge)I.add(fe);const Te=/<[A-Z][a-zA-Z0-9]+/.test(T),xe=j[ke]||(N===1?g[ke]||"cover":"default");w[xe]=(w[xe]||0)+1,y.push({pageIndex:N++,pageAttrs:j,notes:X,rawMarkdown:T,hasVueComponent:Te,hasStyleTag:Y,assetReferences:ge})}if(!u&&y.length>0){const F=y[0].rawMarkdown.match(/^#\s+(.+)$/m);F&&(u=F[1].trim())}h&&(g["custom-slidev-custom-css"]=h);let O=y.map(F=>`---

${F.rawMarkdown}`).join(`

`);return O.trimStart().startsWith("---")||(O=`---

${O.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:M,totalSlots:A,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:O,customCss:h}}function L0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function Ua(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function P0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function R0(e,t,i=je){const n=e.filter(Ua);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const l=t[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const l=t[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}return s}async function O0(e,t=je){let i=!1,n=0;for(const s of e){if(Ua(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[$e]:"right"}).catch(()=>{}),n++)}return n}async function N0(e,t,i=sl){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&E0(e,n),n}async function z0(e){var M;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||sl,d=a.createDocFn||Uc,f=a.setAttrsFn||je,g=a.getChildBlocksFn||us,u=a.openTabFn||ue.openTab,h=a.showMessageFn||ue.showMessage;o&&s.length>0&&await N0(t,s,c);const m=P0(n),b=`/${m}`,y=await d(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((M=t.slides[0])==null?void 0:M.pageAttrs)||{};await f(y,{...x,...t.docRootAttrs});const _=await g(y).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await R0(_,t.slides,f),await O0(_,f)),h(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function H0(e){const t=he("file"),i=he(!1),n=he(!1),s=he(""),o=he(null),l=he(null),r=he(""),a=he(0),c=he(""),d=he([]),f=he(null),g=he(""),u=he([]),h=he(""),m=he(!0),b=he(!0),y=he(!0),x=he(!0),_=we(()=>{const j=a.value;if(j===0)return"0 B";const T=1024,B=["B","KB","MB","GB"],R=Math.floor(Math.log(j)/Math.log(T));return`${(j/T**R).toFixed(1)} ${B[R]}`}),M=we(()=>{var j;return((j=f.value)==null?void 0:j.docRootAttrs["custom-slidev-theme"])||"default"}),A=we(()=>{var j;return d.value.length>0?d.value.length:((j=f.value)==null?void 0:j.stats.discoveredAssets.length)||0}),I=we(()=>{var T;const j=((T=f.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries(j).map(([B,R])=>({name:B,count:R}))});async function w(j=Wc){try{const T=await j();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(u.value=T.notebooks.filter(B=>!B.closed),u.value.length>0&&!h.value&&(h.value=u.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function N(){var j;(j=o.value)==null||j.click()}function O(){l.value=null,r.value="",a.value=0,f.value=null,d.value=[],s.value=""}async function F(j){s.value="",l.value=j,r.value=j.name,a.value=j.size;try{if(j.name.toLowerCase().endsWith(".zip")){const B=await j.arrayBuffer(),R=await T0(B);if(!R.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=R.assets;const X=rs(R.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:R.virtualFiles});f.value=X,g.value=X.docTitle||j.name.replace(/\.zip$/i,"")}else{const B=await j.text();d.value=[];const R=j.path||"",X=R?R.replace(/[\\/][^\\/]+$/,""):"",U=rs(B,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:X||void 0});f.value=U,g.value=U.docTitle||j.name.replace(/\.md$/i,"")}}catch(T){console.error("解析文件失败:",T),s.value=`解析文件失败: ${T.message||String(T)}`}}function q(){if(s.value="",!c.value.trim()){f.value=null;return}try{const j=rs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=j,g.value=j.docTitle||"Slidev 演示文稿"}catch(j){s.value=`解析 Markdown 源码失败: ${j.message||String(j)}`}}async function S(){l.value?await F(l.value):c.value&&q()}async function H(j){const T=j.target;T.files&&T.files[0]&&await F(T.files[0])}async function k(j){var T;i.value=!1,(T=j.dataTransfer)!=null&&T.files&&j.dataTransfer.files[0]&&await F(j.dataTransfer.files[0])}async function E(j=e){if(f.value){if(!h.value&&u.value.length>0&&(h.value=u.value[0].id),!h.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await z0({presentation:f.value,notebookId:h.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:x.value,plugin:j})}catch(T){console.error("导入 Slidev 演示失败:",T),s.value=`导入执行失败: ${T.message||String(T)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:f,customDocTitle:g,notebooks:u,selectedNotebookId:h,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:_,currentTheme:M,extractedAssetsCount:A,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:O,processFile:F,onFileSelected:H,onFileDrop:k,onTextChange:q,reprocessCurrentInput:S,handleConfirmImport:E}}const F0={class:"spm-import-dialog"},j0={class:"spm-tabs-header"},W0={class:"spm-dialog-body"},U0={key:0,class:"spm-file-section"},V0={key:0,class:"spm-dropzone-prompt"},K0={class:"spm-dropzone-icon"},G0={key:1,class:"spm-dropzone-active"},q0={class:"spm-file-badge"},Y0={class:"spm-file-size"},Z0={key:1,class:"spm-text-section"},J0={key:2,class:"spm-error-banner"},X0={key:3,class:"spm-preview-card"},Q0={class:"spm-preview-card__header"},ek={style:{display:"inline-flex","align-items":"center",gap:"4px"}},tk={class:"spm-config-grid"},ik={class:"spm-form-item"},nk={class:"spm-form-item"},sk=["value"],ok={class:"spm-stats-grid"},rk={class:"spm-stat-box"},lk={class:"spm-stat-value"},ak={class:"spm-stat-box"},ck={class:"spm-stat-value"},dk={class:"spm-stat-box"},uk={class:"spm-stat-value"},fk={class:"spm-stat-box"},pk={class:"spm-stat-value"},hk={key:0,class:"spm-chips-row"},mk={class:"spm-options-group"},gk={class:"spm-checkbox-label"},vk={class:"spm-checkbox-label"},bk={class:"spm-checkbox-label"},yk={class:"spm-checkbox-label"},kk={class:"spm-dialog-footer"},wk=["disabled"],xk=["disabled"],Sk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},_k={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Ck=It({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Lt("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:f,parsedPresentation:g,customDocTitle:u,notebooks:h,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:_,formattedFileSize:M,currentTheme:A,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:O,onFileSelected:F,onFileDrop:q,onTextChange:S,reprocessCurrentInput:H,handleConfirmImport:k}=H0(n);dn(async()=>{await w()});async function E(){const T=await k();T&&(i("success",{docId:T}),i("close"))}function j(){i("close")}return(T,B)=>(ee(),te("div",{class:"spm-modal-overlay",onClick:Vt(j,["self"])},[p("div",F0,[p("div",{class:"spm-dialog-header"},[B[18]||(B[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),p("div",j0,[p("button",{class:_e(["spm-tab-btn",{active:ve(s)==="file"}]),onClick:B[0]||(B[0]=R=>s.value="file")},[le(de,{name:"package"}),B[19]||(B[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:_e(["spm-tab-btn",{active:ve(s)==="text"}]),onClick:B[1]||(B[1]=R=>s.value="text")},[le(de,{name:"notes"}),B[20]||(B[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",W0,[ve(s)==="file"?(ee(),te("div",U0,[p("div",{class:_e(["spm-dropzone",{dragover:ve(o),"has-file":!!ve(c)}]),onDragover:B[4]||(B[4]=Vt(R=>o.value=!0,["prevent"])),onDragleave:B[5]||(B[5]=Vt(R=>o.value=!1,["prevent"])),onDrop:B[6]||(B[6]=Vt((...R)=>ve(q)&&ve(q)(...R),["prevent"])),onClick:B[7]||(B[7]=(...R)=>ve(N)&&ve(N)(...R))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:B[2]||(B[2]=(...R)=>ve(F)&&ve(F)(...R))},null,544),ve(c)?(ee(),te("div",G0,[p("span",q0,[le(de,{name:"notes"}),St(" "+Se(ve(c)),1)]),p("span",Y0,"("+Se(ve(M))+")",1),p("button",{class:"spm-btn-text",onClick:B[3]||(B[3]=Vt((...R)=>ve(O)&&ve(O)(...R),["stop"]))},"更换文件")])):(ee(),te("div",V0,[p("span",K0,[le(de,{name:"folder",style:{"font-size":"32px"}})]),B[21]||(B[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),B[22]||(B[22]=p("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(ee(),te("div",Z0,[Mt(p("textarea",{"onUpdate:modelValue":B[8]||(B[8]=R=>Ze(d)?d.value=R:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:B[9]||(B[9]=(...R)=>ve(S)&&ve(S)(...R))},null,544),[[Co,ve(d)]])])),ve(r)?(ee(),te("div",J0," ⚠️ "+Se(ve(r)),1)):Le("",!0),ve(g)?(ee(),te("div",X0,[p("div",Q0,[p("span",ek,[le(de,{name:"sparkles"}),B[23]||(B[23]=St(" 演示解析摘要",-1))]),B[24]||(B[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",tk,[p("div",ik,[B[25]||(B[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Mt(p("input",{"onUpdate:modelValue":B[10]||(B[10]=R=>Ze(u)?u.value=R:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Co,ve(u)]])]),p("div",nk,[B[26]||(B[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Mt(p("select",{"onUpdate:modelValue":B[11]||(B[11]=R=>Ze(m)?m.value=R:null),class:"spm-select"},[(ee(!0),te(Ke,null,kt(ve(h),R=>(ee(),te("option",{key:R.id,value:R.id},Se(R.name),9,sk))),128))],512),[[vf,ve(m)]])])]),p("div",ok,[p("div",rk,[p("span",lk,Se(ve(g).totalSlides),1),B[27]||(B[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",ak,[p("span",ck,Se(ve(A)),1),B[28]||(B[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",dk,[p("span",uk,Se(ve(g).stats.totalNotes),1),B[29]||(B[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",fk,[p("span",pk,Se(ve(f)),1),B[30]||(B[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ve(I).length>0?(ee(),te("div",hk,[B[31]||(B[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ee(!0),te(Ke,null,kt(ve(I),R=>(ee(),te("span",{key:R.name,class:"spm-chip-badge"},Se(R.name)+": "+Se(R.count),1))),128))])):Le("",!0),p("div",mk,[p("label",gk,[Mt(p("input",{"onUpdate:modelValue":B[12]||(B[12]=R=>Ze(b)?b.value=R:null),type:"checkbox",onChange:B[13]||(B[13]=(...R)=>ve(H)&&ve(H)(...R))},null,544),[[Xn,ve(b)]]),B[32]||(B[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",vk,[Mt(p("input",{"onUpdate:modelValue":B[14]||(B[14]=R=>Ze(y)?y.value=R:null),type:"checkbox",onChange:B[15]||(B[15]=(...R)=>ve(H)&&ve(H)(...R))},null,544),[[Xn,ve(y)]]),B[33]||(B[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",bk,[Mt(p("input",{"onUpdate:modelValue":B[16]||(B[16]=R=>Ze(x)?x.value=R:null),type:"checkbox"},null,512),[[Xn,ve(x)]]),B[34]||(B[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",yk,[Mt(p("input",{"onUpdate:modelValue":B[17]||(B[17]=R=>Ze(_)?_.value=R:null),type:"checkbox"},null,512),[[Xn,ve(_)]]),B[35]||(B[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Le("",!0)]),p("div",kk,[p("button",{class:"spm-btn-secondary",disabled:ve(l),onClick:j}," 取消 ",8,wk),p("button",{class:"spm-btn-primary",disabled:!ve(g)||ve(l),onClick:E},[ve(l)?(ee(),te("span",Sk,[le(de,{name:"refresh"}),B[36]||(B[36]=St(" 正在导入生成中...",-1))])):(ee(),te("span",_k,[le(de,{name:"rocket"}),B[37]||(B[37]=St(" 确认导入思源笔记",-1))]))],8,xk)])])]))}}),$k=Zt(Ck,[["__scopeId","data-v-2eff6f1e"]]);function sr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Ik(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(sr(o)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(s){let a=e.find(c=>c.startBlockId===s);if(a||(a=e.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===s}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===i))||((g=d.allBlockIds)==null?void 0:g.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=e.find(d=>{var f;return(f=d.noteBlocks)==null?void 0:f.some(g=>g.id===i||g.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[$e];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var f,g;return((f=d.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function tt(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function Tk(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${qe}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ke),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qe),n.removeAttribute("custom-slidev-role");return}const o=e.get(s),l=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slidev-layout"])||"",r=n.getAttribute(ke)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ke,l):(n.removeAttribute(ke),n.removeAttribute("custom-slidev-layout")));const a=(o==null?void 0:o[qe])||(o==null?void 0:o["custom-slidev-role"])||"",c=n.getAttribute(qe)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qe,a):(n.removeAttribute(qe),n.removeAttribute("custom-slidev-role")))})}function Ek(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function Ak(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[h,m]of Object.entries(c))e.activeBlockAttrs.value[h]=m;Pe.setBlockAttrOverride(d,c),tt(d,c);const f=(u=e.parentContainerId)==null?void 0:u.value,g=!!(f&&Ek(d,f));if(Ye in c&&g&&f){const h=c[Ye];e.parentContainerClicks&&(e.parentContainerClicks.value=h),Pe.setBlockAttrOverride(f,{[Ye]:h}),tt(f,{[Ye]:h}),je(f,{[Ye]:h}).catch(()=>{})}if(ke in c){const h=c[ke];e.currentPageDividerLayout.value=h,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=h)}if(yt in c){const h=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=h)}i("保存中...");try{await je(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const f=o();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Pe.setBlockAttrOverride(f,{[c]:d}),tt(f,{[c]:d}),c===ke&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await je(f,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const f=o();if(!f)return;const g={[ke]:c,[yt]:d};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(f,g),tt(f,g),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await je(f,g),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var g;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=d,Pe.setBlockAttrOverride(f,{[c]:d}),tt(f,{[c]:d}),(g=e.latestDoc.value)!=null&&g.config&&(c===En&&(e.latestDoc.value.config.theme=d),c===An&&(e.latestDoc.value.config.aspectRatio=d),c===Mn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await je(f,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function el(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function Va(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:el(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:el(e),isAiGenerated:!1}}async function Mk(e,t){return(await Va(e,t)).notes}function Bk(e,t){const i=he(!1),{triggerSaveNotice:n}=t;async function s(f){var M,A,I,w,N,O,F,q;const h=`> [!NOTE] 💡 演讲备注
${(f||"在此输入本页讲稿提词...").split(/\r?\n/).map(S=>`> ${S}`).join(`
`)}
{: custom-slidev-note="true"}`,m=((M=e.latestDoc.value)==null?void 0:M.slides)||[],b=e.targetSlide.value,y=b?m.findIndex(S=>S===b):-1;let x=null;if(y!==-1&&y<m.length-1){const S=m[y+1];x=await Mi("markdown",h,S.startBlockId)}else{const S=((A=b==null?void 0:b.noteBlocks)==null?void 0:A.slice(-1)[0])||((I=b==null?void 0:b.blocks)==null?void 0:I.slice(-1)[0]),H=(S==null?void 0:S.id)||(b==null?void 0:b.startBlockId);H?x=await Mi("markdown",h,void 0,H):x=await co("markdown",h,e.currentDocId.value)}const _=((O=(N=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:N[0])==null?void 0:O.id)||((F=x==null?void 0:x[0])==null?void 0:F.id);return _&&(await je(_,{[it]:"true"}),Pe.setBlockAttrOverride(_,{[it]:"true"}),Oi(_,(q=e.plugin)==null?void 0:q.app)),e.plugin&&await e.plugin.compileCurrentDocument(),_}async function o(){const f=e.activeBlockId.value;if(f)if(e.isNoteBlock.value){n("取消中...");try{await je(f,{[it]:"","slidev-note":""}),Pe.setBlockAttrOverride(f,{[it]:"","slidev-note":""}),tt(f,{[it]:"","slidev-note":""}),delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ue.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 取消讲稿备注失败:",g),n("取消失败"),ue.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let g=e.rawSnippet.value;try{const b=await Vc(f);b!=null&&b.kramdown&&(g=b.kramdown)}catch{}const m=`> [!NOTE] 💡 演讲备注
${(Sa(g)||g.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",m,f),await je(f,{[it]:"true"}),Pe.setBlockAttrOverride(f,{[it]:"true"}),tt(f,{[it]:"true"}),e.activeBlockAttrs.value[it]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ue.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",g),n("设置失败"),ue.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await s(),ue.showMessage("已在正文末尾插入讲稿备注提示块")}catch(f){ue.showMessage("插入讲稿备注块失败"),console.error(f)}}function r(){var u;const f=e.currentSlideNoteBlockId.value;if(!f){ue.showMessage("未找到本页关联的讲稿备注块");return}Oi(f,(u=e.plugin)==null?void 0:u.app)?ue.showMessage("已在编辑区定位讲稿备注块"):ue.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const f=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ue.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const g=await Va(f,rl);if(g.notes){const h=e.currentSlideNoteBlockId.value;if(h){const m=`> [!NOTE] 💡 演讲备注
${g.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",m,h),await je(h,{[it]:"true"}),Pe.setBlockAttrOverride(h,{[it]:"true"}),Oi(h,(u=e.plugin)==null?void 0:u.app)}else await s(g.notes);g.isAiGenerated?ue.showMessage("思源 AI 演讲提词卡生成成功！"):ue.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var h;if(i.value)return;const f=((h=e.latestDoc.value)==null?void 0:h.slides)||[];if(f.length===0){ue.showMessage("当前文档无幻灯片页面");return}const g=f.map((m,b)=>({slide:m,idx:b})).filter(({slide:m})=>{var x;const b=Array.isArray(m.noteBlocks)&&m.noteBlocks.length>0,y=!!((x=m.notes)!=null&&x.trim());return!b&&!y});if(g.length===0){ue.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=g.length;ue.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,y,x,_,M,A;if(i.value)return;i.value=!0,ue.showMessage("正在批量追加讲稿块...");let m=0;try{const N=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(O=>`> ${O}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:O,idx:F}of g)try{let q=null;if(F<f.length-1){const H=f[F+1];q=await Mi("markdown",N,H.startBlockId)}else{const H=((b=O==null?void 0:O.noteBlocks)==null?void 0:b.slice(-1)[0])||((y=O==null?void 0:O.blocks)==null?void 0:y.slice(-1)[0]),k=(H==null?void 0:H.id)||(O==null?void 0:O.startBlockId);k?q=await Mi("markdown",N,void 0,k):q=await co("markdown",N,e.currentDocId.value)}const S=((M=(_=(x=q==null?void 0:q[0])==null?void 0:x.doOperations)==null?void 0:_[0])==null?void 0:M.id)||((A=q==null?void 0:q[0])==null?void 0:A.id);S&&(await je(S,{[it]:"true"}),Pe.setBlockAttrOverride(S,{[it]:"true"})),m++}catch(q){console.error(`[SiYuanSlidev] 为第 ${F+1} 页追加讲稿块失败:`,q)}e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功为 ${m} 页追加讲稿备注块`)}catch(I){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",I),ue.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var m;if(i.value)return;const f=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(f.length===0){ue.showMessage("当前文档无幻灯片页面");return}const g=[];for(const b of f)if(b.noteBlocks&&b.noteBlocks.length>0)for(const y of b.noteBlocks)y.id&&g.push({id:y.id,pageIndex:b.pageIndex});if(g.length===0){ue.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(g.map(b=>b.pageIndex)).size,h=g.length;ue.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${h} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ue.showMessage("正在批量删除讲稿块...");let b=0;try{for(const y of g)try{await ol(y.id),Pe.clearBlockAttrOverride(y.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${y.id} 失败:`,x)}e.activeBlockId.value&&g.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(y){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",y),ue.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function Dk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ai]:"true",[Vi]:"true"}),e.activeBlockAttrs.value[Ai]="true",e.activeBlockAttrs.value[Vi]="true"):(await i(Ai,"false"),e.activeBlockAttrs.value[Ai]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(fs,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Vi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(ps,w)}async function c(w){var S;const N=e.activeBlockId.value;if(!N)return;const O=e.rawSnippet.value||"",F=ki(O)||"",q=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const H={[qe]:"background",[ke]:""};q&&F&&(e.pageBackground.value=F,await je(q,{[et]:F}).catch(()=>{}),Pe.setBlockAttrOverride(q,{[et]:F}),tt(q,{[et]:F}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=F)),await n(H)}else(w===hs||w===ms)&&await n({[ke]:w,[qe]:""});else{const H={[qe]:"",[ke]:""};if(e.activeBlockAttrs.value[et]==="true"&&(H[et]=""),q&&F&&e.pageBackground.value===F&&(e.pageBackground.value="",await je(q,{[et]:""}).catch(()=>{}),Pe.setBlockAttrOverride(q,{[et]:""}),tt(q,{[et]:""}),(S=e.targetSlide.value)!=null&&S.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(H),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${N}"]`),E=k==null?void 0:k.closest('[data-type="NodeListItem"]'),j=E==null?void 0:E.getAttribute("data-node-id");if(j&&j!==N){const T={[ke]:"",[qe]:""};tt(j,T),Pe.setBlockAttrOverride(j,T),await je(j,T).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ye,""):i(Ye,"+1")}function f(w){i(Ye,w)}function g(w){i(Gt,w)}function u(w){(e.activeBlockAttrs.value[$e]||"")===w?i($e,""):i($e,w)}function h(w){e.elemShikiLines.value=w,i(Ni,w)}function m(w){e.elemMaxHeight.value=w,i(Bn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i($e,w?"col-1":"left"),ue.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const N={[Ye]:"",[Gt]:"",[$e]:"",[Ni]:"",[Bn]:"",[it]:"","slidev-note":"",[ke]:"",[yt]:"",[qe]:"",[pt]:"",[et]:"",[Bt]:"",[Ai]:"",[fs]:"",[Vi]:"",[ps]:""};if(tt(w,N),await je(w,N),Pe.clearBlockAttrOverride(w),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),F=O==null?void 0:O.closest('[data-type="NodeListItem"]'),q=F==null?void 0:F.getAttribute("data-node-id");q&&q!==w&&(tt(q,N),await je(q,N).catch(()=>{}),Pe.clearBlockAttrOverride(q))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",ue.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Mi("markdown","---",e.activeBlockId.value,void 0),ue.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function _(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Mi("markdown","---",void 0,w),ue.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function M(){if(e.activeBlockId.value)try{await ol(e.activeBlockId.value),ue.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("删除失败")}}async function A(){var w,N;try{let O=null;if(typeof document<"u"){const q=e.activeBlockId.value;if(q){const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`);S&&(O=S.getAttribute("data-type")==="NodeSuperBlock"?S:S.closest('[data-type="NodeSuperBlock"]'))}if(!O){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(S){const H=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(H){let k=H.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const E=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(E){O=E;break}k=k.nextElementSibling}}}else{const H=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const E of k)if(!H||E.compareDocumentPosition(H)&Node.DOCUMENT_POSITION_FOLLOWING){O=E;break}}}}const F=[];if(O){const q=Array.from(O.querySelectorAll(":scope > [data-node-id]"));for(const S of q){const H=S.getAttribute("data-node-id");H&&(F.push(H),S.removeAttribute("style"))}}else if((N=e.targetSlide.value)!=null&&N.blocks){for(const q of e.targetSlide.value.blocks)if(q.children&&q.children.length>=2){for(const S of q.children)S.id&&F.push(S.id);break}}if(F.length>0)for(const q of F)await je(q,{style:""}).catch(()=>{});await s(yt,""),ue.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(O){console.error("[layout-actions] resetSuperBlockWidth error:",O),ue.showMessage("重置超级块比例失败")}}async function I(){var w,N,O;try{let F=null;if(typeof document<"u"){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),H=e.activeBlockId.value;let k=[];if(S){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(T){let B=T.nextElementSibling;for(;B&&!(B.getAttribute("data-type")==="NodeThematicBreak"||(w=B.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(B),B=B.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),B=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const R of B)if(!T||R.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(R);else break}const E=[];let j;for(const T of k){const B=T.getAttribute("data-type");B==="NodeHeading"&&(j=T.getAttribute("data-node-id")||void 0);const R=[];B==="NodeSuperBlock"?R.push(T):R.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const X of R){if((X.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const Y=X.getAttribute("data-node-id")||"";let se=[];const ae=Array.from(X.querySelectorAll('[data-type="NodeListItem"]'));if(ae.length===4&&(se=ae.map(ce=>ce.getAttribute("data-node-id")).filter(Boolean)),se.length!==4){const ce=Array.from(X.querySelectorAll(":scope > [data-node-id]"));ce.length===4&&(se=ce.map(ge=>ge.getAttribute("data-node-id")).filter(Boolean))}se.length===4&&E.push({sbId:Y,itemIds:se,headerId:j})}}E.length>0&&(H&&(F=E.find(T=>{if(T.sbId===H||T.itemIds.includes(H))return!0;const B=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),R=document.querySelector(`.protyle-wysiwyg [data-node-id="${H}"]`);return!!(B&&R&&B.contains(R))})||null),F||(F=E[0]))}if(!F&&((N=e.targetSlide.value)!=null&&N.blocks)){const S=e.targetSlide.value,H=[];for(const E of S.blocks)E.rawNode?H.push(E.rawNode):H.push({id:E.id,type:E.type,content:E.content,markdown:E.rawMarkdown,children:E.children,ial:E.attributes||E.ial||{}});const k=Df(H,e.activeBlockId.value);k&&k.items.length===4&&(F={sbId:k.superBlockNode.id,itemIds:k.items.map(E=>E.id),headerId:(O=k.headerNode)==null?void 0:O.id})}if(!F||F.itemIds.length!==4)return ue.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const q=e.currentPageDividerId.value||e.currentDocId.value;q&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(q,{[ke]:"clover"}),tt(q,{[ke]:"clover"}),await je(q,{[ke]:"clover"}).catch(()=>{})),F.headerId&&(Pe.setBlockAttrOverride(F.headerId,{[$e]:"header"}),tt(F.headerId,{[$e]:"header"}),await je(F.headerId,{[$e]:"header"}).catch(()=>{}));for(let S=0;S<4;S++){const H=F.itemIds[S],k=`col-${S+1}`;Pe.setBlockAttrOverride(H,{[$e]:k}),tt(H,{[$e]:k}),await je(H,{[$e]:k}).catch(()=>{})}return ue.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(F){return console.error("[layout-actions] applyCloverLayout error:",F),ue.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:f,onElemMotionChange:g,onElemSlotChange:u,onElemShikiLinesChange:h,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:_,onDeleteCurrentBlock:M,resetSuperBlockWidth:A,applyCloverLayout:I}}function Lk(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l}=Ak(e),r=Bk(e,{triggerSaveNotice:t}),a=Dk(e,{saveAttr:n,saveAttrs:i,savePageAttr:s});function c(){if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const g=La(e.latestDoc.value);Pa("presentation.html",g)&&ue.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}Ra(e.latestDoc.value)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function f(){var m;if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const g=e.latestDoc.value,u=((m=e.docTitle)==null?void 0:m.value)||g.config.title||"presentation",h=await za(g,{title:u,onProgress:(b,y)=>{ue.showMessage(`正在导出幻灯片图片 (${b} / ${y})...`,2e3)}});h.success?ue.showMessage(`🎉 成功导出 ${h.total||0} 张幻灯片高清图片并已保存为 ZIP 压缩包！`,4e3):ue.showMessage(`导出图片失败：${h.error||"未知异常"}`)}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d,onExportImages:f}}function Pk(e){const t=we(()=>sr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return we(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Pe.getBlockAttrOverride(a);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}const Rk={class:"spm-slidev-inspector"},Ok={class:"spm-inspector-topbar"},Nk={class:"spm-inspector-title"},zk={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Hk={class:"spm-inspector-topbar-actions"},Fk={class:"spm-target-banner"},jk={class:"spm-target-info"},Wk=["aria-label"],Uk={key:0,class:"spm-save-status"},Vk=["title"],Kk={class:"spm-inspector-body"},Gk=It({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=Lt("plugin"),n=he(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=he(""),l=he(""),r=he({}),a=he(""),c=he(""),d=he(""),f=he(""),g=he(""),u=he(""),h=he(""),m=he(""),b=he(null),y=he(""),x=he("");function _(){var be;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(Q).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const M=we(()=>sr(l.value)),A=we(()=>l.value==="NodeCodeBlock"),I=he(!1),w=we(()=>{if(I.value||Me.value)return!0;const Q=a.value||"";return!!ki(Q)}),N=we(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const be=a.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),O=we(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),F=we(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),q=we(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=we(()=>{if(M.value)return"分页符 (---)";if(O.value)return"全局文档";if(N.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return u.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),H=we(()=>M.value?"tag-divider":O.value?"tag-doc":"tag-block"),k=we(()=>r.value[ke]||"default"),E=we(()=>r.value[pt]||"slide-left"),j=he(""),T=he(""),B=we(()=>r.value[kn]||"inherit"),R=we(()=>{var Q;return Ik((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),X=we(()=>{var Q;return((Q=R.value)==null?void 0:Q.notes)||""}),U=we(()=>{var Q,be,Ee;return((Ee=(be=(Q=R.value)==null?void 0:Q.noteBlocks)==null?void 0:be[0])==null?void 0:Ee.id)||""}),Y=we(()=>{var Fe,We,Re,dt,Kn,ui;if(M.value){const Xe=r.value[ke]||r.value["custom-slidev-layout"];if(Xe)return Xe}const Q=r.value[$e]||r.value["custom-slidev-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(g.value)return g.value;const be=f.value||(M.value?o.value:"");if(be){const Xe=Pe.getBlockAttrOverride(be);if(Xe!=null&&Xe[ke])return Xe[ke]}if(be&&((Fe=b.value)!=null&&Fe.slides)){const Xe=b.value.slides.find(ji=>ji.startBlockId===be);if((We=Xe==null?void 0:Xe.frontmatter)!=null&&We.layout)return Xe.frontmatter.layout}if((dt=(Re=R.value)==null?void 0:Re.frontmatter)!=null&&dt.layout)return R.value.frontmatter.layout;if((ui=(Kn=R.value)==null?void 0:Kn.blocks)!=null&&ui.some(Xe=>Xe.slot&&(["col-1","col-2","col-3"].includes(Xe.slot)||/^col-\d+$/.test(Xe.slot))))return"cols-header";const Ee=Pe.getBlockAttrOverride(c.value);return Ee!=null&&Ee[ke]?Ee[ke]:"default"}),se=Pk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:f}),ae=se.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var Q,be;return((be=(Q=R.value)==null?void 0:Q.frontmatter)==null?void 0:be.layoutRatio)||""}}),ce=se.resolvePageAttr({attrKey:Gi,fallback:()=>{var Q,be;return((be=(Q=R.value)==null?void 0:Q.frontmatter)==null?void 0:be.mask)||""}}),ge=se.resolvePageAttr({attrKey:qi,fallback:()=>{var Q,be;return((be=(Q=R.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskRatio)||""}}),Te=se.resolvePageAttr({attrKey:Yi,fallback:()=>{var Q,be;return((be=(Q=R.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskStyle)||"solid"}}),xe=se.resolvePageAttr({attrKey:Zi,fallback:()=>{var Q,be;return((be=(Q=R.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const Fe=Ee.length,We=Ee.map(ui=>{const Xe=ui.getAttribute("style")||"",ji=Xe.match(/calc\(\s*([\d.]+)%/);if(ji)return parseFloat(ji[1]);const pn=Xe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return pn?parseFloat(pn[1]):null});let Re="",dt=!1;if(We.some(ui=>ui!==null)){dt=!0;const ui=We.reduce((Be,ut)=>Be+(ut||0),0),Xe=We.filter(Be=>Be===null).length,ji=Xe>0?Math.max(0,100-ui)/Xe:100/Ee.length,pn=We.map(Be=>Be!==null?Be:ji),Pc=pn.reduce((Be,ut)=>Be+ut,0)||1,hn=pn.map(Be=>Be/Pc*100);if(hn.length===2){const[Be]=hn;if(Be>=48&&Be<=52)Re="1:1";else if(Be>=31&&Be<=35)Re="1:2";else if(Be>=65&&Be<=69)Re="2:1";else if(Be>=28&&Be<=32)Re="3:7";else if(Be>=68&&Be<=72)Re="7:3";else if(Be>=38&&Be<=42)Re="4:6";else if(Be>=58&&Be<=62)Re="6:4";else{const ut=Math.round(Be);Re=`${ut}:${100-ut}`}}else if(hn.length===3){const[Be,ut,fi]=hn;if(Be>=31&&Be<=35&&ut>=31&&ut<=35&&fi>=31&&fi<=35)Re="1:1:1";else if(Be>=23&&Be<=27&&ut>=48&&ut<=52&&fi>=23&&fi<=27)Re="1:2:1";else if(Be>=48&&Be<=52&&ut>=23&&ut<=27&&fi>=23&&fi<=27)Re="2:1:1";else if(Be>=23&&Be<=27&&ut>=23&&ut<=27&&fi>=48&&fi<=52)Re="1:1:2";else{const ar=Math.round(Be),cr=Math.round(ut);Re=`${ar}:${cr}:${100-ar-cr}`}}else Re=hn.map(Be=>Math.round(Be)).join(":")}else dt=!1,Re=Array.from({length:Fe},()=>1).join(":");const Kn=Fe>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Fe,ratio:Re,isCustomWidth:dt,recommendedLayout:Kn}}function Z(Q){if(!(Q!=null&&Q.blocks))return null;for(const be of Q.blocks){const Ee=be.rawNode;if(Ee&&st(Ee)&&Yt(Ee)){const We=un(Ee).length,Re=er(Ee);return{hasSuperBlock:!0,colCount:We,ratio:Re||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const pe=we(()=>{var Q;if(typeof document<"u"){const be=o.value;if(be){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(Fe){const We=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.closest('[data-type="NodeSuperBlock"]');if(We){const Re=fe(We);if(Re)return Re}}}const Ee=f.value||(M.value?o.value:"");if(Ee){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(Fe){let We=Fe.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(Q=We.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Re){const dt=fe(Re);if(dt)return dt}We=We.nextElementSibling}}}else{const Fe=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of We)if(!Fe||Re.compareDocumentPosition(Fe)&Node.DOCUMENT_POSITION_FOLLOWING){const dt=fe(Re);if(dt)return dt}}}return Z(R.value)}),L=we(()=>{var Q;return((Q=pe.value)==null?void 0:Q.ratio)||""}),K=we(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=we(()=>{var Q;return((Q=R.value)==null?void 0:Q.pageIndex)||1}),G=we(()=>!!(r.value[it]||r.value["slidev-note"]));function W(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!Q)return!1;const be=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===o.value}const C=we(()=>{var be;if(r.value[Ye]!==void 0)return r.value[Ye]||"";if(u.value&&W())return m.value||"";if(u.value)return"";const Q=o.value;if(Q&&((be=R.value)!=null&&be.blocks)){const Ee=R.value.blocks.find(Fe=>Fe.id===Q);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),$=we(()=>{var be;if(r.value[Gt])return r.value[Gt];const Q=o.value;if(Q&&((be=R.value)!=null&&be.blocks)){const Ee=R.value.blocks.find(Fe=>Fe.id===Q);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),P=we(()=>{var be;if(r.value[$e])return r.value[$e];const Q=o.value;if(Q&&((be=R.value)!=null&&be.blocks)){const Ee=R.value.blocks.find(Fe=>Fe.id===Q);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),D=he(""),z=he(""),V=we(()=>r.value[Ai]==="true"),J=we(()=>r.value[fs]==="true"),re=we(()=>r.value[Vi]==="true"),oe=we(()=>r.value[ps]!=="false"),me=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.theme)||r.value[En]||"default"}),ie=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.aspectRatio)||r.value[An]||"16/9"}),ne=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.defaultTransition)||r.value[Mn]||"slide-left"}),Ce=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.spacing)||r.value[fo]||"normal"}),Me=we(()=>{var We,Re;if((r.value[qe]||r.value["slidev-role"])===dl||r.value[et]==="true")return"background";const be=r.value[ke]||r.value["slidev-layout"];if(be==="image-left"||be==="image-right")return be;const Ee=a.value||"",Fe=ki(Ee);if(Fe&&((Re=(We=R.value)==null?void 0:We.frontmatter)!=null&&Re.background)){const dt=R.value.frontmatter.background;if(dt===Fe||dt.endsWith(Fe)||Fe.endsWith(dt))return"background"}return""}),Ne=we(()=>!!(r.value[Ye]||r.value[Gt]||r.value[$e]||r.value[Ni]||r.value[it]||r.value["slidev-note"]||r.value[qe]||r.value[ke]||r.value[Ai]||r.value[fs]||r.value[Vi]||r.value[ps])),{saveAttr:Oe,savePageAttr:De,applyPageLayoutAndRatio:Jt,applyCloverLayout:ot,resetSuperBlockWidth:Je,saveDocAttr:Nt,onToggleVideoAutoplay:Hi,onToggleVideoLoop:Fs,onToggleVideoMuted:js,onToggleVideoControls:Vn,onImageRoleChange:xi,onToggleNoteBlock:Fi,onAddNoteBlock:Xa,onLocateNoteBlock:Qa,onGenerateNotesWithAI:ec,isBatchProcessing:tc,onBatchAppendNotes:ic,onBatchDeleteNotes:nc,toggleElemClick:sc,onElemClickStepChange:oc,onElemMotionChange:rc,onElemSlotChange:lc,onElemShikiLinesChange:ac,onElemMaxHeightChange:cc,onSetTwoColsContrast:dc,onClearBlockAttrs:uc,onInsertDividerBefore:fc,onInsertDividerAfter:or,onDeleteCurrentBlock:pc,onExportHtml:hc,onExportPdf:mc,onExportImages:gc}=Lk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:g,parentContainerId:u,parentContainerClicks:m,latestDoc:b,targetSlide:R,currentSlideNoteBlockId:U,currentSlideLayout:Y,isNoteBlock:G,elemClick:C,videoAutoplay:V,videoLoop:J,videoMuted:re,videoControls:oe,pageBackground:j,pageImage:T,elemShikiLines:D,elemMaxHeight:z,saveStatus:y,plugin:i});async function vc(Q){if(Q==="clover"){if(!await ot())return}else Oe(ke,Q)}function bc(Q){De(yt,Q)}function yc(Q){De(Gi,Q)}function kc(Q){De(qi,Q)}function wc(Q){De(Yi,Q)}function xc(Q){De(Zi,Q)}function rr(Q){if(!Q)return;const be=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ee=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");Jt(be,Ee)}function Sc(Q){De(yt,Q)}async function _c(){await Je()}function Cc(Q){Oe(pt,Q)}function $c(Q){j.value=Q,Oe(et,Q)}function Ic(Q){T.value=Q,Oe(Bt,Q)}function Tc(Q){Oe(kn,Q==="inherit"?"":Q)}function Ec(Q){Nt(En,Q)}function Ac(Q){Nt(An,Q)}function Mc(Q){Nt(Mn,Q)}function Bc(Q){Nt(fo,Q)}function lr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Dc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Lc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(Q){o.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,f.value=Q.pageDividerId||"",g.value=Q.pageDividerLayout||"",u.value=Q.parentContainerId||"",h.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),j.value=Q.attrs[et]||"",T.value=Q.attrs[Bt]||"",D.value=Q.attrs[Ni]||"",z.value=Q.attrs[Bn]||"",I.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,be)=>(ee(),te("div",Rk,[p("div",Ok,[p("div",Nk,[(ee(),te("svg",zk,[...be[2]||(be[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=p("span",null,"演示配置",-1))]),p("div",Hk,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Ee=>n.value=!0)},[le(de,{name:"import"}),be[4]||(be[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:lr},[le(de,{name:"split-preview"}),be[5]||(be[5]=p("span",null,"分屏预览",-1))])])]),p("div",Fk,[p("div",jk,[p("span",{class:_e(["spm-target-tag",H.value])},Se(S.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(o.value||c.value),onClick:_},[le(de,{name:"copy"}),p("span",null,"#"+Se(F.value),1)],8,Wk)]),y.value?(ee(),te("span",Uk,"● "+Se(y.value),1)):Le("",!0)]),q.value?(ee(),te("div",{key:0,class:"spm-context-quote",title:a.value},Se(q.value),9,Vk)):Le("",!0),p("div",Kk,[M.value?(ee(),Kt(n1,{key:0,"page-layout":k.value,"page-layout-ratio":ve(ae),"page-mask":ve(ce),"page-mask-ratio":ve(ge),"page-mask-style":ve(Te),"page-mask-initial":ve(xe),"detected-sb-ratio":L.value,"detected-sb-info":pe.value,"page-transition":E.value,"page-background":j.value,"page-spacing":B.value,"page-image":T.value,"page-notes":X.value,"page-index":v.value,"onUpdate:pageLayout":vc,"onUpdate:pageLayoutRatio":bc,"onUpdate:pageMask":yc,"onUpdate:pageMaskRatio":kc,"onUpdate:pageMaskStyle":wc,"onUpdate:pageMaskInitial":xc,onApplySuperBlockLayout:rr,onResetSuperblockRatio:_c,"onUpdate:pageTransition":Cc,"onUpdate:pageBackground":$c,"onUpdate:pageSpacing":Tc,"onUpdate:pageImage":Ic,onAddNoteBlock:ve(Xa),onLocateNoteBlock:ve(Qa),onGenerateNotes:ve(ec),onBatchAppendNotes:ve(ic),onBatchDeleteNotes:ve(nc),"is-batch-processing":ve(tc),onInsertDividerAfter:ve(or),onDeleteDivider:ve(pc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!O.value?(ee(),Kt(Fy,{key:1,"elem-click":C.value,"elem-motion":$.value,"elem-slot":P.value,"elem-shiki-lines":D.value,"elem-max-height":z.value,"is-code-block":A.value,"is-image":w.value,"is-video":N.value,"is-super-block":K.value,"detected-sb-info":pe.value,"video-autoplay":V.value,"video-loop":J.value,"video-muted":re.value,"video-controls":oe.value,"has-block-attrs":Ne.value,"is-note":G.value,"image-role":Me.value,"current-slide-layout":Y.value,"parent-elem-click":m.value,"parent-container-slot":h.value,"parent-container-id":u.value,onToggleNote:ve(Fi),onToggleElemClick:ve(sc),onToggleVideoAutoplay:ve(Hi),onToggleVideoLoop:ve(Fs),onToggleVideoMuted:ve(js),onToggleVideoControls:ve(Vn),"onUpdate:imageRole":ve(xi),"onUpdate:elemClick":ve(oc),"onUpdate:elemMotion":ve(rc),"onUpdate:elemSlot":ve(lc),"onUpdate:elemShikiLines":ve(ac),"onUpdate:elemMaxHeight":ve(cc),onApplySuperBlockLayout:rr,onApplySuperBlockRatio:Sc,onInsertDividerBefore:ve(fc),onInsertDividerAfter:ve(or),onSetTwoColsContrast:ve(dc),onClearBlockAttrs:ve(uc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ee(),Kt(C0,{key:2,"doc-theme":me.value,"doc-aspect-ratio":ie.value,"doc-default-transition":ne.value,"doc-spacing":Ce.value,"onUpdate:docTheme":Ec,"onUpdate:docAspectRatio":Ac,"onUpdate:docDefaultTransition":Mc,"onUpdate:docSpacing":Bc,onOpenBottomPreview:lr,onOpenPresenter:Dc,onAiAutoSplit:Lc,onExportHtml:ve(hc),onExportPdf:ve(mc),onExportImages:ve(gc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf","onExportImages"]))]),n.value?(ee(),Kt($k,{key:1,onClose:be[1]||(be[1]=Ee=>n.value=!1),onSuccess:s})):Le("",!0)]))}}),qk=2e3,Yk=600;function Zk(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ro(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(tl(e))return!0;const t=e.firstElementChild;return!!(t&&tl(t))}function tl(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Jk(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Xk{constructor(){ye(this,"consumers",new Map);ye(this,"seq",0);ye(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=Jk(),l={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=ro(i),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ro(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Zk(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&ro(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},qk))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const ls=new Xk,fn=new Un;function Ka(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=ls.register(e,t,n);return n(),s}let vi=null,Et=null,as=null;function Qk(){return Et}function ew(e,t){vi&&Ga(),vi=Xo(gg),vi.provide("plugin",t),vi.provide("sandboxBridge",fn);const i=vi.mount(e);return Et=i,as=Ka("preview",e,t),i}function Ga(e){as&&(as(),as=null),vi&&(vi.unmount(),vi=null,Et=null)}function tw(){return Et!==null}let bi=null,Di=null;function iw(e,t){return bi&&qa(),bi=Xo($v),bi.provide("plugin",t),bi.provide("sandboxBridge",fn),Di=bi.mount(e),Di}function qa(e){bi&&(bi.unmount(),bi=null,Di=null)}function nw(e){try{const t=new BroadcastChannel("siyuan-slidev-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let yi=null,_t=null,cs=null;function sw(e,t){yi&&Ya(),yi=Xo(Gk),yi.provide("plugin",t),yi.provide("sandboxBridge",fn);const i=yi.mount(e);return _t=i,cs=Ka("dock",e,t),i}function Ya(e){cs&&(cs(),cs=null),yi&&(yi.unmount(),yi=null,_t=null)}function ow(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),Et!=null&&Et.updateDocument?Et.updateDocument(e,t):(fn.updateSlides(e.slides,e.config,e.fullMarkdown),nw(e)),Di!=null&&Di.updateDocument&&Di.updateDocument(e)}function Bo(e){Et!=null&&Et.navigateToBlock?Et.navigateToBlock(e):fn.highlightElement(e)}function ds(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function rw(){return _t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}function lw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const l=e[o];if(Cs(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];Cs(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}const aw=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ei,value:"true"},{key:ke,value:"cover"},{key:pt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ei,value:"true"},{key:ke,value:"two-cols"},{key:pt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ei,value:"true"},{key:ke,value:"fact"},{key:pt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ei,value:"true"},{key:ke,value:"intro"},{key:pt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ei,value:"true"},{key:ke,value:"quote"},{key:pt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ye,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ye,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:$e,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class lo{getPresetTemplates(){return aw}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${pt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${pt}' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[pt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function cw(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{rw()||ue.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await je(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ue.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}const t=await us(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ue.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=lw(i);if(n.length===0){ue.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ue.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Mi("markdown","---",void 0,o.blockId),await je(o.blockId,{"custom-slidev-layout":o.recommendedLayout}),s++}catch(l){console.warn("Failed to insert divider:",l)}ue.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,f;if(!e.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}ue.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await us(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await Mk(i,rl)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await co("markdown",o,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((f=l==null?void 0:l[0])==null?void 0:f.id);r&&(await je(r,{"custom-slidev-note":"true"}),Pe.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Oi(r,e.app)),ue.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new lo,i=t.buildTransitionStatsSql(),n=await nn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ue.showMessage(s)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new lo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ue.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ue.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new lo().batchUpdateTransitions("fade","slide-left",n=>nn(n).catch(()=>[]),(n,s)=>je(n,s));ue.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ue.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ue.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ue.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ue.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",uo);t.success?ue.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ue.showMessage(`同步失败：${t.error}`)}}),e.addCommand({langKey:"slidevExportImagesZip",langText:"Slidev: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const t=e.latestCompiledDoc,i=t.config.title||e.currentDocId||"presentation",n=await za(t,{title:i,onProgress:(s,o)=>{ue.showMessage(`正在导出幻灯片图片 (${s} / ${o})...`,2e3)}});n.success?ue.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ZIP 压缩包！`,4e3):ue.showMessage(`导出图片失败：${n.error||"未知异常"}`)}})}function Za(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ja(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const o=await nn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function dw(e,t,i){var c,d,f;const n=Qk(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&i&&i!==o)return;const l=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ja(e,l));const a=Za(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const g=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of g){const h=u.querySelector(".item__text"),m=((f=h==null?void 0:h.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){h&&(h.textContent=a),u.setAttribute("title",a);break}}}}class uw{constructor(t=400){ye(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function fw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class pw{constructor(t=150){ye(this,"lastBlockId","");ye(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class hw{constructor(){ye(this,"attrCache",new uw);ye(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Pe.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const l=await Do(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:fw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);ds({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Bo(t)}handleBlockClickedFromSlide(t,i,n,s){var a;if(!t)return!1;const o=Oi(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,s);else{let c="",d="";if(s!=null&&s.slides){const f=s.slides.find(g=>{var u,h,m;return g.startBlockId===t||((u=g.blocks)==null?void 0:u.some(b=>b.id===t))||((h=g.allBlockIds)==null?void 0:h.includes(t))||((m=g.noteBlocks)==null?void 0:m.some(b=>b.id===t))});f!=null&&f.startBlockId&&(c=f.startBlockId),(a=f==null?void 0:f.frontmatter)!=null&&a.layout&&(d=f.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async f=>{if(c&&!d){const g=Pe.getBlockAttrOverride(c);if(g!=null&&g[ke]||g!=null&&g["custom-slidev-layout"])d=g[ke]||g["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,s);d=u[ke]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Pe.setBlockAttrOverride(c,u)}}ds({id:t,rootId:n,type:r||"NodeParagraph",attrs:f||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return o}async syncInspectorBlock(t,i,n,s,o){var E,j,T,B,R,X,U,Y;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const se=c.getAttribute("data-node-id");if(se){const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ge={...ae,...ce};(ge[it]||ge["slidev-note"])&&(l=c,r=se,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(d==null?void 0:d.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((E=d==null?void 0:d.classList)!=null&&E.contains("hr")),u=a==="NodeCodeBlock",h=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Pe.getBlockAttrOverride(r)||{},y={...m,...b};let x="",_="";if(g)x=r,_=y[ke]||y["custom-slidev-layout"]||"";else{let se=d.previousElementSibling;for(;se;){const ae=se.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(T=se.classList)!=null&&T.contains("hr")){x=se.getAttribute("data-node-id")||"";break}se=se.previousElementSibling}}if(o!=null&&o.slides){const se=[r,f];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const ge=ae.getAttribute("data-node-id");ge&&!se.includes(ge)&&se.push(ge),ae=ae.parentElement}const ce=o.slides.find(ge=>{var Te,xe,fe;return se.includes(ge.startBlockId)||((Te=ge.blocks)==null?void 0:Te.some(Z=>se.includes(Z.id)))||((xe=ge.allBlockIds)==null?void 0:xe.some(Z=>se.includes(Z)))||((fe=ge.noteBlocks)==null?void 0:fe.some(Z=>se.includes(Z.id)))});ce&&(!x&&ce.startBlockId&&(x=ce.startBlockId),!_&&((B=ce.frontmatter)!=null&&B.layout)&&(_=ce.frontmatter.layout))}if(x){const se=Pe.getBlockAttrOverride(x);if(se&&(ke in se||"custom-slidev-layout"in se)&&(_=se[ke]||se["custom-slidev-layout"]||""),!_&&(o!=null&&o.slides)){const ae=o.slides.find(ce=>ce.startBlockId===x);(R=ae==null?void 0:ae.frontmatter)!=null&&R.layout&&(_=ae.frontmatter.layout)}if(!_){const ae=await this.resolveBlockAttrs(x,o);_=ae[ke]||ae["custom-slidev-layout"]||"",ae&&Object.keys(ae).length>0&&Pe.setBlockAttrOverride(x,ae)}tt(x,{[ke]:_||""})}else if(s){const se=Pe.getBlockAttrOverride(s);se&&(ke in se||"custom-slidev-layout"in se)?_=se[ke]||se["custom-slidev-layout"]||"":!_&&((Y=(U=(X=o==null?void 0:o.slides)==null?void 0:X[0])==null?void 0:U.frontmatter)!=null&&Y.layout)&&(_=o.slides[0].frontmatter.layout)}const M=l.getAttribute(ke)||l.getAttribute("custom-slidev-layout"),A=y[ke]||y["custom-slidev-layout"]||"";M&&M!==A&&tt(r,{[ke]:A});const I=l.getAttribute(qe)||l.getAttribute("custom-slidev-role"),w=y[qe]||y["custom-slidev-role"]||"";I&&I!==w&&tt(r,{[qe]:w});let N="",O="",F="";const q=l.closest('[data-type="NodeListItem"]');if(q&&q!==l){const se=q.getAttribute("data-node-id");if(se){N=se;const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ge={...ae,...ce};O=ge[$e]||"",F=ge[Ye]||"";const Te=ge[ke]||ge["custom-slidev-layout"]||"",xe=q.getAttribute(ke)||q.getAttribute("custom-slidev-layout");xe&&xe!==Te&&tt(se,{[ke]:Te});const fe=ge[qe]||ge["custom-slidev-role"]||"",Z=q.getAttribute(qe)||q.getAttribute("custom-slidev-role");Z&&Z!==fe&&tt(se,{[qe]:fe})}}const S=!!l.querySelector("img, span[data-type='img']"),H=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=S&&H.length<=50;ds({id:r,rootId:s,type:a,content:h,attrs:y,isDivider:g,isCode:u,isImage:k,topBlockId:f,pageDividerId:x,pageDividerLayout:_,parentContainerId:N,parentContainerSlot:O,parentContainerClicks:F})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");tt(n.id,l),Pe.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var s,o,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[ke]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(o=a.ial)!=null&&o[ke]&&(c[ke]=a.ial[ke]),(l=a.ial)!=null&&l[qe]&&(c[qe]=a.ial[qe]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ke]!==void 0&&(c[ke]=a[ke]),a[qe]!==void 0&&(c[qe]=a[qe]),i.set(r,c)}Tk(i)}}const Ii=new hw;class mw{constructor(){ye(this,"inFlightDocId",null);ye(this,"pendingDocId",null);ye(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const gw=150,vw=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,bw="slidev-dock",ao="slidev-preview-tab",il="slidev-presenter-tab",nl=$f;class yw extends ue.Plugin{constructor(){super(...arguments);ye(this,"isMobile",!1);ye(this,"currentDocId","");ye(this,"previewTab",null);ye(this,"latestCompiledDoc",null);ye(this,"cliBridge",new tr);ye(this,"debounceTimer",null);ye(this,"activeCursorBlockId","");ye(this,"compileScheduler",new mw);ye(this,"dirtyDocId",null);ye(this,"inspectorSyncThrottle",new pw);ye(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ye(this,"onWsMainBound",this.onWsMain.bind(this));ye(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ye(this,"onEditorClickBound",this.onEditorClick.bind(this));ye(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ye(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ye(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ue.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(vw),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),cw(this);const n=this;if(this.addTab({type:ao,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,ew(o.element,n);const l=(r=o==null?void 0:o.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Ga(this.element)}}),this.addTab({type:il,init(s){iw((this||s).element,n)},destroy(){qa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:bw,init(){sw(this.element,n)},destroy(){Ya(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(nl),n=If(i);return Bi(n),n}catch{return Bi(ln),ln}}async saveGlobalSettings(i){const n=Hs(),s=Bi({...n,...i||{}});try{await this.saveData(nl,s)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,ls.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),fn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ue.openTab({app:this.app,custom:{id:this.name+ao,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){tw()||await this.openBottomPreviewTab(),await ue.openTab({app:this.app,custom:{id:this.name+il,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ue.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-slidev/slidev-client/index.html","SlidevBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),l=await ue.openTab({app:this.app,custom:{id:this.name+ao,title:o,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ue.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const f=await Do(s).catch(()=>({}));ds({id:s,rootId:s,type:"doc",attrs:f}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,l;const n=i==null?void 0:i.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Za(i)}async fetchDocumentTitle(i){return Ja(this,i)}async updatePreviewTabHeader(i,n){return dw(this,i,n)}getActiveDocumentId(){return Ii.getActiveDocumentId()}resolveDocIdFromElement(i){return Ii.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ii.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ii.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=gw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=ls.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Yk);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ii.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const f=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const f=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Ii.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&ls.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,ow(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ii.purgeStaleDomSlidevAttrs(i)}}module.exports=yw;
