"use strict";var Wc=Object.create;var Ys=Object.defineProperty;var Uc=Object.getOwnPropertyDescriptor;var Vc=Object.getOwnPropertyNames;var Gc=Object.getPrototypeOf,Kc=Object.prototype.hasOwnProperty;var qc=(e,i,t)=>i in e?Ys(e,i,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[i]=t;var Yc=(e,i,t,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let s of Vc(i))!Kc.call(e,s)&&s!==t&&Ys(e,s,{get:()=>i[s],enumerable:!(n=Uc(i,s))||n.enumerable});return e};var Xn=(e,i,t)=>(t=e!=null?Wc(Gc(e)):{},Yc(i||!e||!e.__esModule?Ys(t,"default",{value:e,enumerable:!0}):t,e));var ke=(e,i,t)=>qc(e,typeof i!="symbol"?i+"":i,t);const ue=require("siyuan");async function mt(e,i){const t=await ue.fetchSyncPost(e,i);return t.code===0?t.data:null}async function Zc(){return mt("/api/notebook/lsNotebooks","")}async function Jc(e,i,t){return mt("/api/filetree/createDocWithMd",{notebook:e,path:i,markdown:t})}async function dl(e,i){const t=new FormData;t.append("assetsDirPath",e);for(const s of i)t.append("file[]",s);return mt("/api/asset/upload",t)}async function Bi(e,i,t,n,s){return mt("/api/block/insertBlock",{dataType:e,data:i,nextID:t,previousID:n,parentID:s})}async function go(e,i,t){return mt("/api/block/appendBlock",{dataType:e,data:i,parentID:t})}async function gr(e,i,t){return mt("/api/block/updateBlock",{dataType:e,data:i,id:t})}async function ul(e){return mt("/api/block/deleteBlock",{id:e})}async function Xc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function vs(e){return mt("/api/block/getChildBlocks",{id:e})}async function Qc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function je(e,i){return mt("/api/attr/setBlockAttrs",{id:e,attrs:i})}async function zo(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function rn(e){return mt("/api/query/sql",{stmt:e})}async function vo(e,i,t){const n=new FormData;return n.append("path",e),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",t),mt("/api/file/putFile",n)}async function fl(e){const i="/api/ai/chatGPT";try{const t=await mt(i,{msg:e});return typeof t=="string"&&t.trim().length>0?t.trim():t&&typeof t.content=="string"&&t.content.trim().length>0?t.content.trim():null}catch{return null}}async function ed(){return mt("/api/storage/getInlineStyles","")}const pl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function td(e){const i=[];if(!e)return i;const t=new RegExp(pl.source,"g");let n;for(;(n=t.exec(e))!==null;){const s=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return i}function id(e,i){if(!e)return"";const t=new RegExp(pl.source,"g");return e.replace(t,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(i&&i[s]){const d=i[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const Ln="custom-slides-theme",Pn="custom-slides-aspect-ratio",hl="custom-slides-highlighter",Rn="custom-slides-default-transition",ml="custom-slides-color-schema",bo="custom-slides-spacing",Mi="custom-slides-slide",we="custom-slides-layout",pt="custom-slides-transition",et="custom-slides-background",Dt="custom-slides-image",Zs="custom-slides-notes",Zi="custom-slides-class",Cn="custom-slides-spacing",yt="custom-slides-layout-ratio",Ji="custom-slides-mask",Pi="custom-slides-mask-ratio",Xi="custom-slides-mask-style",Qi="custom-slides-mask-initial",Ye="custom-slides-click",qt="custom-slides-motion",Fi="custom-slides-shiki-lines",$e="custom-slides-slot",it="custom-slides-note",qe="custom-slides-role",On="custom-slides-max-height",Ai="custom-slides-autoplay",bs="custom-slides-loop",Yi="custom-slides-muted",ys="custom-slides-controls",gl="background",ks="image-left",ws="image-right";function Nn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function nd(e,i=2){const t=i===4?[25,50,75,100]:[50,100],n=i===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:t};const s=e.trim();if(!s||i===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:t};const o=s.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:n,breakpoints:t};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const l=o.every((h,u)=>u===0||h>o[u-1]),r=o[o.length-1];if(l&&(r===100||o.some(h=>h>10))){const h=o.map(u=>Math.min(100,Math.round(u*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,u)=>h+u,0);if(c<=0)return{steps:n,breakpoints:t};let d=0;const p=[];for(let h=0;h<o.length;h++)d+=o[h],h===o.length-1?p.push(100):p.push(Math.round(d/c*1e4)/100);return{steps:p.length,breakpoints:p}}function sd(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function od(e){const i={};if(!e)return i;const t=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(t))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";i[o]=l}return i}function vl(e){if(!e)return!1;const i=e.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function bl(e){const i=e.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Et(e,i){if(!vl(e))return e;const t=bl(e);return i!=null&&i.base64Map&&i.base64Map[t]?i.base64Map[t]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${t}`:`/${t}`}function rd(e,i){if(!e)return"";let t=e;return t=t.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Et(o,i);return`![${s}](${l})`}),t=t.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Et(o,i);return`${s}${r}${l}`}),t=t.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Et(o,i);return`${s}${r}${l}`}),t}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ho(e){const i=Object.create(null);for(const t of e.split(","))i[t]=1;return t=>t in i}const Ve={},en=[],Yt=()=>{},yl=()=>!1,Bs=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ds=e=>e.startsWith("onUpdate:"),ct=Object.assign,Fo=(e,i)=>{const t=e.indexOf(i);t>-1&&e.splice(t,1)},ld=Object.prototype.hasOwnProperty,He=(e,i)=>ld.call(e,i),Ie=Array.isArray,tn=e=>Gn(e)==="[object Map]",un=e=>Gn(e)==="[object Set]",vr=e=>Gn(e)==="[object Date]",Me=e=>typeof e=="function",Qe=e=>typeof e=="string",Rt=e=>typeof e=="symbol",Ue=e=>e!==null&&typeof e=="object",kl=e=>(Ue(e)||Me(e))&&Me(e.then)&&Me(e.catch),wl=Object.prototype.toString,Gn=e=>wl.call(e),ad=e=>Gn(e).slice(8,-1),xl=e=>Gn(e)==="[object Object]",jo=e=>Qe(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,_n=Ho(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Ls=e=>{const i=Object.create(null);return(t=>i[t]||(i[t]=e(t)))},cd=/-\w/g,wt=Ls(e=>e.replace(cd,i=>i.slice(1).toUpperCase())),dd=/\B([A-Z])/g,xi=Ls(e=>e.replace(dd,"-$1").toLowerCase()),Ps=Ls(e=>e.charAt(0).toUpperCase()+e.slice(1)),Js=Ls(e=>e?`on${Ps(e)}`:""),Ut=(e,i)=>!Object.is(e,i),ls=(e,...i)=>{for(let t=0;t<e.length;t++)e[t](...i)},Sl=(e,i,t,n=!1)=>{Object.defineProperty(e,i,{configurable:!0,enumerable:!1,writable:n,value:t})},Rs=e=>{const i=parseFloat(e);return isNaN(i)?e:i};let br;const Os=()=>br||(br=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Vt(e){if(Ie(e)){const i={};for(let t=0;t<e.length;t++){const n=e[t],s=Qe(n)?hd(n):Vt(n);if(s)for(const o in s)i[o]=s[o]}return i}else if(Qe(e)||Ue(e))return e}const ud=/;(?![^(]*\))/g,fd=/:([^]+)/,pd=/\/\*[^]*?\*\//g;function hd(e){const i={};return e.replace(pd,"").split(ud).forEach(t=>{if(t){const n=t.split(fd);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function Ce(e){let i="";if(Qe(e))i=e;else if(Ie(e))for(let t=0;t<e.length;t++){const n=Ce(e[t]);n&&(i+=n+" ")}else if(Ue(e))for(const t in e)e[t]&&(i+=t+" ");return i.trim()}const md="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",gd=Ho(md);function Cl(e){return!!e||e===""}function vd(e,i){if(e.length!==i.length)return!1;let t=!0;for(let n=0;t&&n<e.length;n++)t=fn(e[n],i[n]);return t}function fn(e,i){if(e===i)return!0;let t=vr(e),n=vr(i);if(t||n)return t&&n?e.getTime()===i.getTime():!1;if(t=Rt(e),n=Rt(i),t||n)return e===i;if(t=Ie(e),n=Ie(i),t||n)return t&&n?vd(e,i):!1;if(t=Ue(e),n=Ue(i),t||n){if(!t||!n)return!1;const s=Object.keys(e).length,o=Object.keys(i).length;if(s!==o)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=i.hasOwnProperty(l);if(r&&!a||!r&&a||!fn(e[l],i[l]))return!1}}return String(e)===String(i)}function Wo(e,i){return e.findIndex(t=>fn(t,i))}const _l=e=>!!(e&&e.__v_isRef===!0),xe=e=>Qe(e)?e:e==null?"":Ie(e)||Ue(e)&&(e.toString===wl||!Me(e.toString))?_l(e)?xe(e.value):JSON.stringify(e,$l,2):String(e),$l=(e,i)=>_l(i)?$l(e,i.value):tn(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((t,[n,s],o)=>(t[Xs(n,o)+" =>"]=s,t),{})}:un(i)?{[`Set(${i.size})`]:[...i.values()].map(t=>Xs(t))}:Rt(i)?Xs(i):Ue(i)&&!Ie(i)&&!xl(i)?String(i):i,Xs=(e,i="")=>{var t;return Rt(e)?`Symbol(${(t=e.description)!=null?t:i})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class bd{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,t;if(this.scopes){const n=this.scopes.slice();for(i=0,t=n.length;i<t;i++)n[i].pause()}for(i=0,t=this.effects.length;i<t;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,t;if(this.scopes){const s=this.scopes.slice();for(i=0,t=s.length;i<t;i++)s[i].resume()}const n=this.effects.slice();for(i=0,t=n.length;i<t;i++)n[i].resume()}}run(i){if(this._active){const t=lt;try{return lt=this,i()}finally{lt=t}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let i=lt;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let t,n;for(t=0,n=this.effects.length;t<n;t++)this.effects[t].stop();for(this.effects.length=0,t=0,n=this.cleanups.length;t<n;t++)this.cleanups[t]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(t=0,n=s.length;t<n;t++)s[t].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function yd(){return lt}let Ke;const Qs=new WeakSet;class Il{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Qs.has(this)&&(Qs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||El(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,yr(this),Ml(this);const i=Ke,t=Lt;Ke=this,Lt=!0;try{return this.fn()}finally{Al(this),Ke=i,Lt=t,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)Go(i);this.deps=this.depsTail=void 0,yr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Qs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){yo(this)&&this.run()}get dirty(){return yo(this)}}let Tl=0,$n,In;function El(e,i=!1){if(e.flags|=8,i){e.next=In,In=e;return}e.next=$n,$n=e}function Uo(){Tl++}function Vo(){if(--Tl>0)return;if(In){let i=In;for(In=void 0;i;){const t=i.next;i.next=void 0,i.flags&=-9,i=t}}let e;for(;$n;){let i=$n;for($n=void 0;i;){const t=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){e||(e=n)}i=t}}if(e)throw e}function Ml(e){for(let i=e.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Al(e){let i,t=e.depsTail,n=t;for(;n;){const s=n.prevDep;n.version===-1?(n===t&&(t=s),Go(n),kd(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=i,e.depsTail=t}function yo(e){for(let i=e.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Bl(i.dep.computed)||i.dep.version!==i.version))return!0;return!!e._dirty}function Bl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===zn)||(e.globalVersion=zn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!yo(e))))return;e.flags|=2;const i=e.dep,t=Ke,n=Lt;Ke=e,Lt=!0;try{Ml(e);const s=e.fn(e._value);(i.version===0||Ut(s,e._value))&&(e.flags|=128,e._value=s,i.version++)}catch(s){throw i.version++,s}finally{Ke=t,Lt=n,Al(e),e.flags&=-3}}function Go(e,i=!1){const{dep:t,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),t.subs===e&&(t.subs=n,!n&&t.computed)){t.computed.flags&=-5;for(let o=t.computed.deps;o;o=o.nextDep)Go(o,!0)}!i&&!--t.sc&&t.map&&t.map.delete(t.key)}function kd(e){const{prevDep:i,nextDep:t}=e;i&&(i.nextDep=t,e.prevDep=void 0),t&&(t.prevDep=i,e.nextDep=void 0)}let Lt=!0;const Dl=[];function ri(){Dl.push(Lt),Lt=!1}function li(){const e=Dl.pop();Lt=e===void 0?!0:e}function yr(e){const{cleanup:i}=e;if(e.cleanup=void 0,i){const t=Ke;Ke=void 0;try{i()}finally{Ke=t}}}let zn=0;class wd{constructor(i,t){this.sub=i,this.dep=t,this.version=t.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ko{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Ke||!Lt||Ke===this.computed)return;let t=this.activeLink;if(t===void 0||t.sub!==Ke)t=this.activeLink=new wd(Ke,this),Ke.deps?(t.prevDep=Ke.depsTail,Ke.depsTail.nextDep=t,Ke.depsTail=t):Ke.deps=Ke.depsTail=t,Ll(t);else if(t.version===-1&&(t.version=this.version,t.nextDep)){const n=t.nextDep;n.prevDep=t.prevDep,t.prevDep&&(t.prevDep.nextDep=n),t.prevDep=Ke.depsTail,t.nextDep=void 0,Ke.depsTail.nextDep=t,Ke.depsTail=t,Ke.deps===t&&(Ke.deps=n)}return t}trigger(i){this.version++,zn++,this.notify(i)}notify(i){Uo();try{for(let t=this.subs;t;t=t.prevSub)t.sub.notify()&&t.sub.dep.notify()}finally{Vo()}}}function Ll(e){if(e.dep.sc++,e.sub.flags&4){const i=e.dep.computed;if(i&&!e.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)Ll(n)}const t=e.dep.subs;t!==e&&(e.prevSub=t,t&&(t.nextSub=e)),e.dep.subs=e}}const ko=new WeakMap,Ri=Symbol(""),wo=Symbol(""),Hn=Symbol("");function ft(e,i,t){if(Lt&&Ke){let n=ko.get(e);n||ko.set(e,n=new Map);let s=n.get(t);s||(n.set(t,s=new Ko),s.map=n,s.key=t),s.track()}}function ii(e,i,t,n,s,o){const l=ko.get(e);if(!l){zn++;return}const r=a=>{a&&a.trigger()};if(Uo(),i==="clear")l.forEach(r);else{const a=Ie(e),c=a&&jo(t);if(a&&t==="length"){const d=Number(n);l.forEach((p,h)=>{(h==="length"||h===Hn||!Rt(h)&&h>=d)&&r(p)})}else switch((t!==void 0||l.has(void 0))&&r(l.get(t)),c&&r(l.get(Hn)),i){case"add":a?c&&r(l.get("length")):(r(l.get(Ri)),tn(e)&&r(l.get(wo)));break;case"delete":a||(r(l.get(Ri)),tn(e)&&r(l.get(wo)));break;case"set":tn(e)&&r(l.get(Ri));break}}Vo()}function Gi(e){const i=ze(e);return i===e?i:(ft(i,"iterate",Hn),At(e)?i:i.map(Ot))}function Ns(e){return ft(e=ze(e),"iterate",Hn),e}function jt(e,i){return ai(e)?ln(Oi(e)?Ot(i):i):Ot(i)}const xd={__proto__:null,[Symbol.iterator](){return eo(this,Symbol.iterator,e=>jt(this,e))},concat(...e){return Gi(this).concat(...e.map(i=>Ie(i)?Gi(i):i))},entries(){return eo(this,"entries",e=>(e[1]=jt(this,e[1]),e))},every(e,i){return Qt(this,"every",e,i,void 0,arguments)},filter(e,i){return Qt(this,"filter",e,i,t=>t.map(n=>jt(this,n)),arguments)},find(e,i){return Qt(this,"find",e,i,t=>jt(this,t),arguments)},findIndex(e,i){return Qt(this,"findIndex",e,i,void 0,arguments)},findLast(e,i){return Qt(this,"findLast",e,i,t=>jt(this,t),arguments)},findLastIndex(e,i){return Qt(this,"findLastIndex",e,i,void 0,arguments)},forEach(e,i){return Qt(this,"forEach",e,i,void 0,arguments)},includes(...e){return to(this,"includes",e)},indexOf(...e){return to(this,"indexOf",e)},join(e){return Gi(this).join(e)},lastIndexOf(...e){return to(this,"lastIndexOf",e)},map(e,i){return Qt(this,"map",e,i,void 0,arguments)},pop(){return bn(this,"pop")},push(...e){return bn(this,"push",e)},reduce(e,...i){return kr(this,"reduce",e,i)},reduceRight(e,...i){return kr(this,"reduceRight",e,i)},shift(){return bn(this,"shift")},some(e,i){return Qt(this,"some",e,i,void 0,arguments)},splice(...e){return bn(this,"splice",e)},toReversed(){return Gi(this).toReversed()},toSorted(e){return Gi(this).toSorted(e)},toSpliced(...e){return Gi(this).toSpliced(...e)},unshift(...e){return bn(this,"unshift",e)},values(){return eo(this,"values",e=>jt(this,e))}};function eo(e,i,t){const n=Ns(e),s=n[i]();return n!==e&&!At(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=t(o.value)),o}),s}const Sd=Array.prototype;function Qt(e,i,t,n,s,o){const l=Ns(e),r=l!==e&&!At(e),a=l[i];if(a!==Sd[i]){const p=a.apply(e,o);return r?Ot(p):p}let c=t;l!==e&&(r?c=function(p,h){return t.call(this,jt(e,p),h,e)}:t.length>2&&(c=function(p,h){return t.call(this,p,h,e)}));const d=a.call(l,c,n);return r&&s?s(d):d}function kr(e,i,t,n){const s=Ns(e),o=s!==e&&!At(e);let l=t,r=!1;s!==e&&(o?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=jt(e,c)),t.call(this,c,jt(e,d),p,e)}):t.length>3&&(l=function(c,d,p){return t.call(this,c,d,p,e)}));const a=s[i](l,...n);return r?jt(e,a):a}function to(e,i,t){const n=ze(e);ft(n,"iterate",Hn);const s=n[i](...t);return(s===-1||s===!1)&&Zo(t[0])?(t[0]=ze(t[0]),n[i](...t)):s}function bn(e,i,t=[]){ri(),Uo();const n=ze(e)[i].apply(e,t);return Vo(),li(),n}const Cd=Ho("__proto__,__v_isRef,__isVue"),Pl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Rt));function _d(e){Rt(e)||(e=String(e));const i=ze(this);return ft(i,"has",e),i.hasOwnProperty(e)}class Rl{constructor(i=!1,t=!1){this._isReadonly=i,this._isShallow=t}get(i,t,n){if(t==="__v_skip")return i.__v_skip;const s=this._isReadonly,o=this._isShallow;if(t==="__v_isReactive")return!s;if(t==="__v_isReadonly")return s;if(t==="__v_isShallow")return o;if(t==="__v_raw")return n===(s?o?Pd:Hl:o?zl:Nl).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ie(i);if(!s){let a;if(l&&(a=xd[t]))return a;if(t==="hasOwnProperty")return _d}const r=Reflect.get(i,t,Ze(i)?i:n);if((Rt(t)?Pl.has(t):Cd(t))||(s||ft(i,"get",t),o))return r;if(Ze(r)){const a=l&&jo(t)?r:r.value;return s&&Ue(a)?So(a):a}return Ue(r)?s?So(r):zs(r):r}}class Ol extends Rl{constructor(i=!1){super(!1,i)}set(i,t,n,s){let o=i[t];const l=Ie(i)&&jo(t);if(!this._isShallow){const c=ai(o);if(!At(n)&&!ai(n)&&(o=ze(o),n=ze(n)),!l&&Ze(o)&&!Ze(n))return c||(o.value=n),!0}const r=l?Number(t)<i.length:He(i,t),a=Reflect.set(i,t,n,Ze(i)?i:s);return i===ze(s)&&a&&(r?Ut(n,o)&&ii(i,"set",t,n):ii(i,"add",t,n)),a}deleteProperty(i,t){const n=He(i,t);i[t];const s=Reflect.deleteProperty(i,t);return s&&n&&ii(i,"delete",t,void 0),s}has(i,t){const n=Reflect.has(i,t);return(!Rt(t)||!Pl.has(t))&&ft(i,"has",t),n}ownKeys(i){return ft(i,"iterate",Ie(i)?"length":Ri),Reflect.ownKeys(i)}}class $d extends Rl{constructor(i=!1){super(!0,i)}set(i,t){return!0}deleteProperty(i,t){return!0}}const Id=new Ol,Td=new $d,Ed=new Ol(!0);const xo=e=>e,Qn=e=>Reflect.getPrototypeOf(e);function Md(e,i,t){return function(...n){const s=this.__v_raw,o=ze(s),l=tn(o),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=s[e](...n),d=t?xo:i?ln:Ot;return!i&&ft(o,"iterate",a?wo:Ri),ct(Object.create(c),{next(){const{value:p,done:h}=c.next();return h?{value:p,done:h}:{value:r?[d(p[0]),d(p[1])]:d(p),done:h}}})}}function es(e){return function(...i){return e==="delete"?!1:e==="clear"?void 0:this}}function Ad(e,i){const t={get(s){const o=this.__v_raw,l=ze(o),r=ze(s);e||(Ut(s,r)&&ft(l,"get",s),ft(l,"get",r));const{has:a}=Qn(l),c=i?xo:e?ln:Ot;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!e&&ft(ze(s),"iterate",Ri),s.size},has(s){const o=this.__v_raw,l=ze(o),r=ze(s);return e||(Ut(s,r)&&ft(l,"has",s),ft(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=ze(r),c=i?xo:e?ln:Ot;return!e&&ft(a,"iterate",Ri),r.forEach((d,p)=>s.call(o,c(d),c(p),l))}};return ct(t,e?{add:es("add"),set:es("set"),delete:es("delete"),clear:es("clear")}:{add(s){const o=ze(this),l=Qn(o),r=ze(s),a=!i&&!At(s)&&!ai(s)?r:s;return l.has.call(o,a)||Ut(s,a)&&l.has.call(o,s)||Ut(r,a)&&l.has.call(o,r)||(o.add(a),ii(o,"add",a,a)),this},set(s,o){!i&&!At(o)&&!ai(o)&&(o=ze(o));const l=ze(this),{has:r,get:a}=Qn(l);let c=r.call(l,s);c||(s=ze(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Ut(o,d)&&ii(l,"set",s,o):ii(l,"add",s,o),this},delete(s){const o=ze(this),{has:l,get:r}=Qn(o);let a=l.call(o,s);a||(s=ze(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&ii(o,"delete",s,void 0),c},clear(){const s=ze(this),o=s.size!==0,l=s.clear();return o&&ii(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{t[s]=Md(s,e,i)}),t}function qo(e,i){const t=Ad(e,i);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(He(t,s)&&s in n?t:n,s,o)}const Bd={get:qo(!1,!1)},Dd={get:qo(!1,!0)},Ld={get:qo(!0,!1)};const Nl=new WeakMap,zl=new WeakMap,Hl=new WeakMap,Pd=new WeakMap;function Rd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function zs(e){return ai(e)?e:Yo(e,!1,Id,Bd,Nl)}function Od(e){return Yo(e,!1,Ed,Dd,zl)}function So(e){return Yo(e,!0,Td,Ld,Hl)}function Yo(e,i,t,n,s){if(!Ue(e)||e.__v_raw&&!(i&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const l=Rd(ad(e));if(l===0)return e;const r=new Proxy(e,l===2?n:t);return s.set(e,r),r}function Oi(e){return ai(e)?Oi(e.__v_raw):!!(e&&e.__v_isReactive)}function ai(e){return!!(e&&e.__v_isReadonly)}function At(e){return!!(e&&e.__v_isShallow)}function Zo(e){return e?!!e.__v_raw:!1}function ze(e){const i=e&&e.__v_raw;return i?ze(i):e}function Nd(e){return!He(e,"__v_skip")&&Object.isExtensible(e)&&Sl(e,"__v_skip",!0),e}const Ot=e=>Ue(e)?zs(e):e,ln=e=>Ue(e)?So(e):e;function Ze(e){return e?e.__v_isRef===!0:!1}function me(e){return zd(e,!1)}function zd(e,i){return Ze(e)?e:new Hd(e,i)}class Hd{constructor(i,t){this.dep=new Ko,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=t?i:ze(i),this._value=t?i:Ot(i),this.__v_isShallow=t}get value(){return this.dep.track(),this._value}set value(i){const t=this._rawValue,n=this.__v_isShallow||At(i)||ai(i);i=n?i:ze(i),Ut(i,t)&&(this._rawValue=i,this._value=n?i:Ot(i),this.dep.trigger())}}function ve(e){return Ze(e)?e.value:e}const Fd={get:(e,i,t)=>i==="__v_raw"?e:ve(Reflect.get(e,i,t)),set:(e,i,t,n)=>{const s=e[i];return Ze(s)&&!Ze(t)?(s.value=t,!0):Reflect.set(e,i,t,n)}};function Fl(e){return Oi(e)?e:new Proxy(e,Fd)}class jd{constructor(i,t,n){this.fn=i,this.setter=t,this._value=void 0,this.dep=new Ko(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=zn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!t,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ke!==this)return El(this,!0),!0}get value(){const i=this.dep.track();return Bl(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Wd(e,i,t=!1){let n,s;return Me(e)?n=e:(n=e.get,s=e.set),new jd(n,s,t)}const ts={},xs=new WeakMap;let Ei;function Ud(e,i=!1,t=Ei){if(t){let n=xs.get(t);n||xs.set(t,n=[]),n.push(e)}}function Vd(e,i,t=Ve){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=t,c=x=>s?x:At(x)||s===!1||s===0?ni(x,1):ni(x);let d,p,h,u,b=!1,m=!1;if(Ze(e)?(p=()=>e.value,b=At(e)):Oi(e)?(p=()=>c(e),b=!0):Ie(e)?(m=!0,b=e.some(x=>Oi(x)||At(x)),p=()=>e.map(x=>{if(Ze(x))return x.value;if(Oi(x))return c(x);if(Me(x))return a?a(x,2):x()})):Me(e)?i?p=a?()=>a(e,2):e:p=()=>{if(h){ri();try{h()}finally{li()}}const x=Ei;Ei=d;try{return a?a(e,3,[u]):e(u)}finally{Ei=x}}:p=Yt,i&&s){const x=p,$=s===!0?1/0:s;p=()=>ni(x(),$)}const v=yd(),y=()=>{d.stop(),v&&v.active&&Fo(v.effects,d)};if(o&&i){const x=i;i=(...$)=>{const T=x(...$);return y(),T}}let C=m?new Array(e.length).fill(ts):ts;const S=x=>{if(!(!(d.flags&1)||!d.dirty&&!x))if(i){const $=d.run();if(x||s||b||(m?$.some((T,w)=>Ut(T,C[w])):Ut($,C))){h&&h();const T=Ei;Ei=d;try{const w=[$,C===ts?void 0:m&&C[0]===ts?[]:C,u];C=$,a?a(i,3,w):i(...w)}finally{Ei=T}}}else d.run()};return r&&r(S),d=new Il(p),d.scheduler=l?()=>l(S,!1):S,u=x=>Ud(x,!1,d),h=d.onStop=()=>{const x=xs.get(d);if(x){if(a)a(x,4);else for(const $ of x)$();xs.delete(d)}},i?n?S(!0):C=d.run():l?l(S.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function ni(e,i=1/0,t){if(i<=0||!Ue(e)||e.__v_skip||(t=t||new Map,(t.get(e)||0)>=i))return e;if(t.set(e,i),i--,Ze(e))ni(e.value,i,t);else if(Ie(e))for(let n=0;n<e.length;n++)ni(e[n],i,t);else if(un(e)||tn(e))e.forEach(n=>{ni(n,i,t)});else if(xl(e)){for(const n in e)ni(e[n],i,t);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ni(e[n],i,t)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Kn(e,i,t,n){try{return n?e(...n):e()}catch(s){Hs(s,i,t)}}function Nt(e,i,t,n){if(Me(e)){const s=Kn(e,i,t,n);return s&&kl(s)&&s.catch(o=>{Hs(o,i,t)}),s}if(Ie(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Nt(e[o],i,t,n));return s}}function Hs(e,i,t,n=!0){const s=i?i.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Ve;if(i){let r=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${t}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(o){ri(),Kn(o,null,10,[e,a,c]),li();return}}Gd(e,t,s,n,l)}function Gd(e,i,t,n=!0,s=!1){if(s)throw e;console.error(e)}const bt=[];let Ft=-1;const nn=[];let mi=null,Ki=0;const jl=Promise.resolve();let Ss=null;function Cs(e){const i=Ss||jl;return e?i.then(this?e.bind(this):e):i}function Kd(e){let i=Ft+1,t=bt.length;for(;i<t;){const n=i+t>>>1,s=bt[n],o=Fn(s);o<e||o===e&&s.flags&2?i=n+1:t=n}return i}function Jo(e){if(!(e.flags&1)){const i=Fn(e),t=bt[bt.length-1];!t||!(e.flags&2)&&i>=Fn(t)?bt.push(e):bt.splice(Kd(i),0,e),e.flags|=1,Wl()}}function Wl(){Ss||(Ss=jl.then(Vl))}function qd(e){Ie(e)?nn.push(...e):mi&&e.id===-1?mi.splice(Ki+1,0,e):e.flags&1||(nn.push(e),e.flags|=1),Wl()}function wr(e,i,t=Ft+1){for(;t<bt.length;t++){const n=bt[t];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(t,1),t--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Ul(e){if(nn.length){const i=[...new Set(nn)].sort((t,n)=>Fn(t)-Fn(n));if(nn.length=0,mi){mi.push(...i);return}for(mi=i,Ki=0;Ki<mi.length;Ki++){const t=mi[Ki];t.flags&4&&(t.flags&=-2),t.flags&8||t(),t.flags&=-2}mi=null,Ki=0}}const Fn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Vl(e){try{for(Ft=0;Ft<bt.length;Ft++){const i=bt[Ft];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Kn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ft<bt.length;Ft++){const i=bt[Ft];i&&(i.flags&=-2)}Ft=-1,bt.length=0,Ul(),Ss=null,(bt.length||nn.length)&&Vl()}}let at=null,Gl=null;function _s(e){const i=at;return at=e,Gl=e&&e.type.__scopeId||null,i}function Kl(e,i=at,t){if(!i||e._n)return e;const n=(...s)=>{n._d&&Dr(-1);const o=_s(i),l=si.length;let r;try{r=e(...s)}finally{for(let a=si.length;a>l;a--)ir();_s(o),n._d&&Dr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Bt(e,i){if(at===null)return e;const t=Vs(at),n=e.dirs||(e.dirs=[]);for(let s=0;s<i.length;s++){let[o,l,r,a=Ve]=i[s];o&&(Me(o)&&(o={mounted:o,updated:o}),o.deep&&ni(l),n.push({dir:o,instance:t,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Ci(e,i,t,n){const s=e.dirs,o=i&&i.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(ri(),Nt(a,t,8,[e.el,r,e,i]),li())}}function Yd(e,i){if(ht){let t=ht.provides;const n=ht.parent&&ht.parent.provides;n===t&&(t=ht.provides=Object.create(n)),t[e]=i}}function Pt(e,i,t=!1){const n=Ku();if(n||on){let s=on?on._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return t&&Me(i)?i.call(n&&n.proxy):i}}const Zd=Symbol.for("v-scx"),Jd=()=>Pt(Zd);function Ni(e,i,t){return ql(e,i,t)}function ql(e,i,t=Ve){const{immediate:n,deep:s,flush:o,once:l}=t,r=ct({},t),a=i&&n||!i&&o!=="post";let c;if(Wn){if(o==="sync"){const u=Jd();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Yt,u.resume=Yt,u.pause=Yt,u}}const d=ht;r.call=(u,b,m)=>Nt(u,d,b,m);let p=!1;o==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:o!=="sync"&&(p=!0,r.scheduler=(u,b)=>{b?u():Jo(u)}),r.augmentJob=u=>{i&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const h=Vd(e,i,r);return Wn&&(c?c.push(h):a&&h()),h}function Xd(e,i,t){const n=this.proxy,s=Qe(e)?e.includes(".")?Yl(n,e):()=>n[e]:e.bind(n,n);let o;Me(i)?o=i:(o=i.handler,t=i);const l=qn(this),r=ql(s,o.bind(n),t);return l(),r}function Yl(e,i){const t=i.split(".");return()=>{let n=e;for(let s=0;s<t.length&&n;s++)n=n[t[s]];return n}}const Qd=Symbol("_vte"),eu=e=>e.__isTeleport,io=Symbol("_leaveCb");function Xo(e,i){e.shapeFlag&6&&e.component?(e.transition=i,Xo(e.component.subTree,i)):e.shapeFlag&128?(e.ssContent.transition=i.clone(e.ssContent),e.ssFallback.transition=i.clone(e.ssFallback)):e.transition=i}function Tt(e,i){return Me(e)?ct({name:e.name},i,{setup:e}):e}function Zl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function xr(e,i){let t;return!!((t=Object.getOwnPropertyDescriptor(e,i))&&!t.configurable)}const $s=new WeakMap;function Tn(e,i,t,n,s=!1){if(Ie(e)){e.forEach((m,v)=>Tn(m,i&&(Ie(i)?i[v]:i),t,n,s));return}if(sn(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Tn(e,i,t,n.component.subTree);return}const o=n.shapeFlag&4?Vs(n.component):n.el,l=s?null:o,{i:r,r:a}=e,c=i&&i.r,d=r.refs===Ve?r.refs={}:r.refs,p=r.setupState,h=ze(p),u=p===Ve?yl:m=>xr(d,m)?!1:He(h,m),b=(m,v)=>!(v&&xr(d,v));if(c!=null&&c!==a){if(Sr(i),Qe(c))d[c]=null,u(c)&&(p[c]=null);else if(Ze(c)){const m=i;b(c,m.k)&&(c.value=null),m.k&&(d[m.k]=null)}}if(Me(a))Kn(a,r,12,[l,d]);else{const m=Qe(a),v=Ze(a);if(m||v){const y=()=>{if(e.f){const C=m?u(a)?p[a]:d[a]:b()||!e.k?a.value:d[e.k];if(s)Ie(C)&&Fo(C,o);else if(Ie(C))C.includes(o)||C.push(o);else if(m)d[a]=[o],u(a)&&(p[a]=d[a]);else{const S=[o];b(a,e.k)&&(a.value=S),e.k&&(d[e.k]=S)}}else m?(d[a]=l,u(a)&&(p[a]=l)):v&&(b(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const C=()=>{y(),$s.delete(e)};C.id=-1,$s.set(e,C),xt(C,t)}else Sr(e),y()}}}function Sr(e){const i=$s.get(e);i&&(i.flags|=8,$s.delete(e))}Os().requestIdleCallback;Os().cancelIdleCallback;const sn=e=>!!e.type.__asyncLoader,Jl=e=>e.type.__isKeepAlive;function tu(e,i){Xl(e,"a",i)}function iu(e,i){Xl(e,"da",i)}function Xl(e,i,t=ht){const n=e.__wdc||(e.__wdc=()=>{let s=t;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Fs(i,n,t),t){let s=t.parent;for(;s&&s.parent;)Jl(s.parent.vnode)&&nu(n,i,t,s),s=s.parent}}function nu(e,i,t,n){const s=Fs(i,e,n,!0);js(()=>{Fo(n[i],s)},t)}function Fs(e,i,t=ht,n=!1){if(t){const s=t[e]||(t[e]=[]),o=i.__weh||(i.__weh=(...l)=>{ri();const r=qn(t),a=Nt(i,t,e,l);return r(),li(),a});return n?s.unshift(o):s.push(o),o}}const di=e=>(i,t=ht)=>{(!Wn||e==="sp")&&Fs(e,(...n)=>i(...n),t)},su=di("bm"),pn=di("m"),ou=di("bu"),ru=di("u"),Qo=di("bum"),js=di("um"),lu=di("sp"),au=di("rtg"),cu=di("rtc");function du(e,i=ht){Fs("ec",e,i)}const uu="components";function fu(e,i){return hu(uu,e,!0,i)||e}const pu=Symbol.for("v-ndc");function hu(e,i,t=!0,n=!1){const s=at||ht;if(s){const o=s.type;{const r=Xu(o,!1);if(r&&(r===i||r===wt(i)||r===Ps(wt(i))))return o}const l=Cr(s[e]||o[e],i)||Cr(s.appContext[e],i);return!l&&n?o:l}}function Cr(e,i){return e&&(e[i]||e[wt(i)]||e[Ps(wt(i))])}function kt(e,i,t,n){let s;const o=t,l=Ie(e);if(l||Qe(e)){const r=l&&Oi(e);let a=!1,c=!1;r&&(a=!At(e),c=ai(e),e=Ns(e)),s=new Array(e.length);for(let d=0,p=e.length;d<p;d++)s[d]=i(a?c?ln(Ot(e[d])):Ot(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=i(r+1,r,void 0,o)}else if(Ue(e))if(e[Symbol.iterator])s=Array.from(e,(r,a)=>i(r,a,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=i(e[d],d,a,o)}}else s=[];return s}function is(e,i,t={},n,s,o){if(at.ce||at.parent&&sn(at.parent)&&at.parent.ce){const c=t,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),ee(),Kt(Ge,null,[le("slot",c,n&&n())],d?-2:64)}let l=e[i];l&&l._c&&(l._d=!1);const r=si.length;ee();let a;try{const c=l&&Ql(l(t)),d=t.key||o||c&&c.key;a=Kt(Ge,{key:(d&&!Rt(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=si.length;d>r;d--)ir();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Ql(e){return e.some(i=>nr(i)?!(i.type===ci||i.type===Ge&&!Ql(i.children)):!0)?e:null}const Co=e=>e?ya(e)?Vs(e):Co(e.parent):null,En=ct(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Co(e.parent),$root:e=>Co(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ta(e),$forceUpdate:e=>e.f||(e.f=()=>{Jo(e.update)}),$nextTick:e=>e.n||(e.n=Cs.bind(e.proxy)),$watch:e=>Xd.bind(e)}),no=(e,i)=>e!==Ve&&!e.__isScriptSetup&&He(e,i),mu={get({_:e},i){if(i==="__v_skip")return!0;const{ctx:t,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=e;if(i[0]!=="$"){const h=l[i];if(h!==void 0)switch(h){case 1:return n[i];case 2:return s[i];case 4:return t[i];case 3:return o[i]}else{if(no(n,i))return l[i]=1,n[i];if(s!==Ve&&He(s,i))return l[i]=2,s[i];if(He(o,i))return l[i]=3,o[i];if(t!==Ve&&He(t,i))return l[i]=4,t[i];_o&&(l[i]=0)}}const c=En[i];let d,p;if(c)return i==="$attrs"&&ft(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[i]))return d;if(t!==Ve&&He(t,i))return l[i]=4,t[i];if(p=a.config.globalProperties,He(p,i))return p[i]},set({_:e},i,t){const{data:n,setupState:s,ctx:o}=e;return no(s,i)?(s[i]=t,!0):n!==Ve&&He(n,i)?(n[i]=t,!0):He(e.props,i)||i[0]==="$"&&i.slice(1)in e?!1:(o[i]=t,!0)},has({_:{data:e,setupState:i,accessCache:t,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(t[r]||e!==Ve&&r[0]!=="$"&&He(e,r)||no(i,r)||He(o,r)||He(n,r)||He(En,r)||He(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,i,t){return t.get!=null?e._.accessCache[i]=0:He(t,"value")&&this.set(e,i,t.value,null),Reflect.defineProperty(e,i,t)}};function _r(e){return Ie(e)?e.reduce((i,t)=>(i[t]=null,i),{}):e}let _o=!0;function gu(e){const i=ta(e),t=e.proxy,n=e.ctx;_o=!1,i.beforeCreate&&$r(i.beforeCreate,e,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:h,beforeUpdate:u,updated:b,activated:m,deactivated:v,beforeDestroy:y,beforeUnmount:C,destroyed:S,unmounted:x,render:$,renderTracked:T,renderTriggered:w,errorCaptured:P,serverPrefetch:N,expose:H,inheritAttrs:K,components:_,directives:F,filters:k}=i;if(c&&vu(c,n,null),l)for(const A in l){const D=l[A];Me(D)&&(n[A]=D.bind(t))}if(s){const A=s.call(t,t);Ue(A)&&(e.data=zs(A))}if(_o=!0,o)for(const A in o){const D=o[A],O=Me(D)?D.bind(t,t):Me(D.get)?D.get.bind(t,t):Yt,Q=!Me(D)&&Me(D.set)?D.set.bind(t):Yt,W=ye({get:O,set:Q});Object.defineProperty(n,A,{enumerable:!0,configurable:!0,get:()=>W.value,set:q=>W.value=q})}if(r)for(const A in r)ea(r[A],n,t,A);if(a){const A=Me(a)?a.call(t):a;Reflect.ownKeys(A).forEach(D=>{Yd(D,A[D])})}d&&$r(d,e,"c");function j(A,D){Ie(D)?D.forEach(O=>A(O.bind(t))):D&&A(D.bind(t))}if(j(su,p),j(pn,h),j(ou,u),j(ru,b),j(tu,m),j(iu,v),j(du,P),j(cu,T),j(au,w),j(Qo,C),j(js,x),j(lu,N),Ie(H))if(H.length){const A=e.exposed||(e.exposed={});H.forEach(D=>{Object.defineProperty(A,D,{get:()=>t[D],set:O=>t[D]=O,enumerable:!0})})}else e.exposed||(e.exposed={});$&&e.render===Yt&&(e.render=$),K!=null&&(e.inheritAttrs=K),_&&(e.components=_),F&&(e.directives=F),N&&Zl(e)}function vu(e,i,t=Yt){Ie(e)&&(e=$o(e));for(const n in e){const s=e[n];let o;Ue(s)?"default"in s?o=Pt(s.from||n,s.default,!0):o=Pt(s.from||n):o=Pt(s),Ze(o)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):i[n]=o}}function $r(e,i,t){Nt(Ie(e)?e.map(n=>n.bind(i.proxy)):e.bind(i.proxy),i,t)}function ea(e,i,t,n){let s=n.includes(".")?Yl(t,n):()=>t[n];if(Qe(e)){const o=i[e];Me(o)&&Ni(s,o)}else if(Me(e))Ni(s,e.bind(t));else if(Ue(e))if(Ie(e))e.forEach(o=>ea(o,i,t,n));else{const o=Me(e.handler)?e.handler.bind(t):i[e.handler];Me(o)&&Ni(s,o,e)}}function ta(e){const i=e.type,{mixins:t,extends:n}=i,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=e.appContext,r=o.get(i);let a;return r?a=r:!s.length&&!t&&!n?a=i:(a={},s.length&&s.forEach(c=>Is(a,c,l,!0)),Is(a,i,l)),Ue(i)&&o.set(i,a),a}function Is(e,i,t,n=!1){const{mixins:s,extends:o}=i;o&&Is(e,o,t,!0),s&&s.forEach(l=>Is(e,l,t,!0));for(const l in i)if(!(n&&l==="expose")){const r=bu[l]||t&&t[l];e[l]=r?r(e[l],i[l]):i[l]}return e}const bu={data:Ir,props:Tr,emits:Tr,methods:wn,computed:wn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:wn,directives:wn,watch:ku,provide:Ir,inject:yu};function Ir(e,i){return i?e?function(){return ct(Me(e)?e.call(this,this):e,Me(i)?i.call(this,this):i)}:i:e}function yu(e,i){return wn($o(e),$o(i))}function $o(e){if(Ie(e)){const i={};for(let t=0;t<e.length;t++)i[e[t]]=e[t];return i}return e}function vt(e,i){return e?[...new Set([].concat(e,i))]:i}function wn(e,i){return e?ct(Object.create(null),e,i):i}function Tr(e,i){return e?Ie(e)&&Ie(i)?[...new Set([...e,...i])]:ct(Object.create(null),_r(e),_r(i??{})):i}function ku(e,i){if(!e)return i;if(!i)return e;const t=ct(Object.create(null),e);for(const n in i)t[n]=vt(e[n],i[n]);return t}function ia(){return{app:null,config:{isNativeTag:yl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let wu=0;function xu(e,i){return function(n,s=null){Me(n)||(n=ct({},n)),s!=null&&!Ue(s)&&(s=null);const o=ia(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:wu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:ef,get config(){return o.config},set config(d){},use(d,...p){return l.has(d)||(d&&Me(d.install)?(l.add(d),d.install(c,...p)):Me(d)&&(l.add(d),d(c,...p))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,p){return p?(o.components[d]=p,c):o.components[d]},directive(d,p){return p?(o.directives[d]=p,c):o.directives[d]},mount(d,p,h){if(!a){const u=c._ceVNode||le(n,s);return u.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(u,d,h),a=!0,c._container=d,d.__vue_app__=c,Vs(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Nt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return o.provides[d]=p,c},runWithContext(d){const p=on;on=c;try{return d()}finally{on=p}}};return c}}let on=null;const Su=(e,i)=>i==="modelValue"||i==="model-value"?e.modelModifiers:e[`${i}Modifiers`]||e[`${wt(i)}Modifiers`]||e[`${xi(i)}Modifiers`];function Cu(e,i,...t){if(e.isUnmounted)return;const n=e.vnode.props||Ve;let s=t;const o=i.startsWith("update:"),l=o&&Su(n,i.slice(7));l&&(l.trim&&(s=t.map(d=>Qe(d)?d.trim():d)),l.number&&(s=t.map(Rs)));let r,a=n[r=Js(i)]||n[r=Js(wt(i))];!a&&o&&(a=n[r=Js(xi(i))]),a&&Nt(a,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Nt(c,e,6,s)}}const _u=new WeakMap;function na(e,i,t=!1){const n=t?_u:i.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let l={},r=!1;if(!Me(e)){const a=c=>{const d=na(c,i,!0);d&&(r=!0,ct(l,d))};!t&&i.mixins.length&&i.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!o&&!r?(Ue(e)&&n.set(e,null),null):(Ie(o)?o.forEach(a=>l[a]=null):ct(l,o),Ue(e)&&n.set(e,l),l)}function Ws(e,i){return!e||!Bs(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),He(e,i[0].toLowerCase()+i.slice(1))||He(e,xi(i))||He(e,i))}function Er(e){const{type:i,vnode:t,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:h,setupState:u,ctx:b,inheritAttrs:m}=e,v=_s(e);let y,C;try{if(t.shapeFlag&4){const x=s||n,$=x;y=Wt(c.call($,x,d,p,u,h,b)),C=r}else{const x=i;y=Wt(x.length>1?x(p,{attrs:r,slots:l,emit:a}):x(p,null)),C=i.props?r:$u(r)}}catch(x){si.length=0,Hs(x,e,1),y=le(ci)}let S=y;if(C&&m!==!1){const x=Object.keys(C),{shapeFlag:$}=S;x.length&&$&7&&(o&&x.some(Ds)&&(C=Iu(C,o)),S=an(S,C,!1,!0))}return t.dirs&&(S=an(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(t.dirs):t.dirs),t.transition&&Xo(S,t.transition),y=S,_s(v),y}const $u=e=>{let i;for(const t in e)(t==="class"||t==="style"||Bs(t))&&((i||(i={}))[t]=e[t]);return i},Iu=(e,i)=>{const t={};for(const n in e)(!Ds(n)||!(n.slice(9)in i))&&(t[n]=e[n]);return t};function Tu(e,i,t){const{props:n,children:s,component:o}=e,{props:l,children:r,patchFlag:a}=i,c=o.emitsOptions;if(i.dirs||i.transition)return!0;if(t&&a>=0){if(a&1024)return!0;if(a&16)return n?Mr(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let p=0;p<d.length;p++){const h=d[p];if(sa(l,n,h)&&!Ws(c,h))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?Mr(n,l,c):!0:!!l;return!1}function Mr(e,i,t){const n=Object.keys(i);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(sa(i,e,o)&&!Ws(t,o))return!0}return!1}function sa(e,i,t){const n=e[t],s=i[t];return t==="style"&&Ue(n)&&Ue(s)?!fn(n,s):n!==s}function Eu({vnode:e,parent:i,suspense:t},n){for(;i;){const s=i.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=i.vnode).el=n,i=i.parent;else break}t&&t.activeBranch===e&&(t.vnode.el=n)}const oa={},ra=()=>Object.create(oa),la=e=>Object.getPrototypeOf(e)===oa;function Mu(e,i,t,n=!1){const s={},o=ra();e.propsDefaults=Object.create(null),aa(e,i,s,o);for(const l in e.propsOptions[0])l in s||(s[l]=void 0);t?e.props=n?s:Od(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Au(e,i,t,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=e,r=ze(s),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let h=d[p];if(Ws(e.emitsOptions,h))continue;const u=i[h];if(a)if(He(o,h))u!==o[h]&&(o[h]=u,c=!0);else{const b=wt(h);s[b]=Io(a,r,b,u,e,!1)}else u!==o[h]&&(o[h]=u,c=!0)}}}else{aa(e,i,s,o)&&(c=!0);let d;for(const p in r)(!i||!He(i,p)&&((d=xi(p))===p||!He(i,d)))&&(a?t&&(t[p]!==void 0||t[d]!==void 0)&&(s[p]=Io(a,r,p,void 0,e,!0)):delete s[p]);if(o!==r)for(const p in o)(!i||!He(i,p))&&(delete o[p],c=!0)}c&&ii(e.attrs,"set","")}function aa(e,i,t,n){const[s,o]=e.propsOptions;let l=!1,r;if(i)for(let a in i){if(_n(a))continue;const c=i[a];let d;s&&He(s,d=wt(a))?!o||!o.includes(d)?t[d]=c:(r||(r={}))[d]=c:Ws(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=ze(t),c=r||Ve;for(let d=0;d<o.length;d++){const p=o[d];t[p]=Io(s,a,p,c[p],e,!He(c,p))}}return l}function Io(e,i,t,n,s,o){const l=e[t];if(l!=null){const r=He(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Me(a)){const{propsDefaults:c}=s;if(t in c)n=c[t];else{const d=qn(s);n=c[t]=a.call(null,i),d()}}else n=a;s.ce&&s.ce._setProp(t,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===xi(t))&&(n=!0))}return n}const Bu=new WeakMap;function ca(e,i,t=!1){const n=t?Bu:i.propsCache,s=n.get(e);if(s)return s;const o=e.props,l={},r=[];let a=!1;if(!Me(e)){const d=p=>{a=!0;const[h,u]=ca(p,i,!0);ct(l,h),u&&r.push(...u)};!t&&i.mixins.length&&i.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!a)return Ue(e)&&n.set(e,en),en;if(Ie(o))for(let d=0;d<o.length;d++){const p=wt(o[d]);Ar(p)&&(l[p]=Ve)}else if(o)for(const d in o){const p=wt(d);if(Ar(p)){const h=o[d],u=l[p]=Ie(h)||Me(h)?{type:h}:ct({},h),b=u.type;let m=!1,v=!0;if(Ie(b))for(let y=0;y<b.length;++y){const C=b[y],S=Me(C)&&C.name;if(S==="Boolean"){m=!0;break}else S==="String"&&(v=!1)}else m=Me(b)&&b.name==="Boolean";u[0]=m,u[1]=v,(m||He(u,"default"))&&r.push(p)}}const c=[l,r];return Ue(e)&&n.set(e,c),c}function Ar(e){return e[0]!=="$"&&!_n(e)}const er=e=>e==="_"||e==="_ctx"||e==="$stable",tr=e=>Ie(e)?e.map(Wt):[Wt(e)],Du=(e,i,t)=>{if(i._n)return i;const n=Kl((...s)=>tr(i(...s)),t);return n._c=!1,n},da=(e,i,t)=>{const n=e._ctx;for(const s in e){if(er(s))continue;const o=e[s];if(Me(o))i[s]=Du(s,o,n);else if(o!=null){const l=tr(o);i[s]=()=>l}}},ua=(e,i)=>{const t=tr(i);e.slots.default=()=>t},fa=(e,i,t)=>{for(const n in i)(t||!er(n))&&(e[n]=i[n])},Lu=(e,i,t)=>{const n=e.slots=ra();if(e.vnode.shapeFlag&32){const s=i._;s?(fa(n,i,t),t&&Sl(n,"_",s,!0)):da(i,n)}else i&&ua(e,i)},Pu=(e,i,t)=>{const{vnode:n,slots:s}=e;let o=!0,l=Ve;if(n.shapeFlag&32){const r=i._;r?t&&r===1?o=!1:fa(s,i,t):(o=!i.$stable,da(i,s)),l=i}else i&&(ua(e,i),l={default:1});if(o)for(const r in s)!er(r)&&l[r]==null&&delete s[r]},xt=Hu;function Ru(e){return Ou(e)}function Ou(e,i){const t=Os();t.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:h,setScopeId:u=Yt,insertStaticContent:b}=e,m=(L,V,g,G=null,U=null,I=null,E=void 0,R=null,Y=!!V.dynamicChildren)=>{if(L===V)return;L&&!yn(L,V)&&(G=Te(L),q(L,U,I,!0),L=null),V.patchFlag===-2&&(Y=!1,V.dynamicChildren=null);const{type:B,ref:z,shapeFlag:J}=V;switch(B){case Us:v(L,V,g,G);break;case ci:y(L,V,g,G);break;case as:L==null&&C(V,g,G,E);break;case Ge:_(L,V,g,G,U,I,E,R,Y);break;default:J&1?$(L,V,g,G,U,I,E,R,Y):J&6?F(L,V,g,G,U,I,E,R,Y):(J&64||J&128)&&B.process(L,V,g,G,U,I,E,R,Y,Z)}z!=null&&U?Tn(z,L&&L.ref,I,V||L,!V):z==null&&L&&L.ref!=null&&Tn(L.ref,null,I,L,!0)},v=(L,V,g,G)=>{if(L==null)n(V.el=r(V.children),g,G);else{const U=V.el=L.el;V.children!==L.children&&c(U,V.children)}},y=(L,V,g,G)=>{L==null?n(V.el=a(V.children||""),g,G):V.el=L.el},C=(L,V,g,G)=>{[L.el,L.anchor]=b(L.children,V,g,G,L.el,L.anchor)},S=({el:L,anchor:V},g,G)=>{let U;for(;L&&L!==V;)U=h(L),n(L,g,G),L=U;n(V,g,G)},x=({el:L,anchor:V})=>{let g;for(;L&&L!==V;)g=h(L),s(L),L=g;s(V)},$=(L,V,g,G,U,I,E,R,Y)=>{if(V.type==="svg"?E="svg":V.type==="math"&&(E="mathml"),L==null)T(V,g,G,U,I,E,R,Y);else{const B=L.el&&L.el._isVueCE?L.el:null;try{B&&B._beginPatch(),N(L,V,U,I,E,R,Y)}finally{B&&B._endPatch()}}},T=(L,V,g,G,U,I,E,R)=>{let Y,B;const{props:z,shapeFlag:J,transition:ne,dirs:oe}=L;if(Y=L.el=l(L.type,I,z&&z.is,z),J&8?d(Y,L.children):J&16&&P(L.children,Y,null,G,U,so(L,I),E,R),oe&&Ci(L,null,G,"created"),w(Y,L,L.scopeId,E,G),z){for(const ie in z)ie!=="value"&&!_n(ie)&&o(Y,ie,null,z[ie],I,G);"value"in z&&o(Y,"value",null,z.value,I),(B=z.onVnodeBeforeMount)&&Ht(B,G,L)}oe&&Ci(L,null,G,"beforeMount");const he=Nu(U,ne);he&&ne.beforeEnter(Y),n(Y,V,g),((B=z&&z.onVnodeMounted)||he||oe)&&xt(()=>{try{B&&Ht(B,G,L),he&&ne.enter(Y),oe&&Ci(L,null,G,"mounted")}finally{}},U)},w=(L,V,g,G,U)=>{if(g&&u(L,g),G)for(let I=0;I<G.length;I++)u(L,G[I]);if(U){let I=U.subTree;if(V===I||ga(I.type)&&(I.ssContent===V||I.ssFallback===V)){const E=U.vnode;w(L,E,E.scopeId,E.slotScopeIds,U.parent)}}},P=(L,V,g,G,U,I,E,R,Y=0)=>{for(let B=Y;B<L.length;B++){const z=L[B]=R?ti(L[B]):Wt(L[B]);m(null,z,V,g,G,U,I,E,R)}},N=(L,V,g,G,U,I,E)=>{const R=V.el=L.el;let{patchFlag:Y,dynamicChildren:B,dirs:z}=V;Y|=L.patchFlag&16;const J=L.props||Ve,ne=V.props||Ve;let oe;if(g&&_i(g,!1),(oe=ne.onVnodeBeforeUpdate)&&Ht(oe,g,V,L),z&&Ci(V,L,g,"beforeUpdate"),g&&_i(g,!0),B&&(!L.dynamicChildren||L.dynamicChildren.length!==B.length)&&(Y=0,E=!1,B=null),(J.innerHTML&&ne.innerHTML==null||J.textContent&&ne.textContent==null)&&d(R,""),B?H(L.dynamicChildren,B,R,g,G,so(V,U),I):E||D(L,V,R,null,g,G,so(V,U),I,!1),Y>0){if(Y&16)K(R,J,ne,g,U);else if(Y&2&&J.class!==ne.class&&o(R,"class",null,ne.class,U),Y&4&&o(R,"style",J.style,ne.style,U),Y&8){const he=V.dynamicProps;for(let ie=0;ie<he.length;ie++){const se=he[ie],_e=J[se],Ae=ne[se];(Ae!==_e||se==="value")&&o(R,se,_e,Ae,U,g)}}Y&1&&L.children!==V.children&&d(R,V.children)}else!E&&B==null&&K(R,J,ne,g,U);((oe=ne.onVnodeUpdated)||z)&&xt(()=>{oe&&Ht(oe,g,V,L),z&&Ci(V,L,g,"updated")},G)},H=(L,V,g,G,U,I,E)=>{for(let R=0;R<V.length;R++){const Y=L[R],B=V[R],z=Y.el&&(Y.type===Ge||!yn(Y,B)||Y.shapeFlag&198)?p(Y.el):g;m(Y,B,z,null,G,U,I,E,!0)}},K=(L,V,g,G,U)=>{if(V!==g){if(V!==Ve)for(const I in V)!_n(I)&&!(I in g)&&o(L,I,V[I],null,U,G);for(const I in g){if(_n(I))continue;const E=g[I],R=V[I];E!==R&&I!=="value"&&o(L,I,R,E,U,G)}"value"in g&&o(L,"value",V.value,g.value,U)}},_=(L,V,g,G,U,I,E,R,Y)=>{const B=V.el=L?L.el:r(""),z=V.anchor=L?L.anchor:r("");let{patchFlag:J,dynamicChildren:ne,slotScopeIds:oe}=V;oe&&(R=R?R.concat(oe):oe),L==null?(n(B,g,G),n(z,g,G),P(V.children||[],g,z,U,I,E,R,Y)):J>0&&J&64&&ne&&L.dynamicChildren&&L.dynamicChildren.length===ne.length?(H(L.dynamicChildren,ne,g,U,I,E,R),(V.key!=null||U&&V===U.subTree)&&pa(L,V,!0)):D(L,V,g,z,U,I,E,R,Y)},F=(L,V,g,G,U,I,E,R,Y)=>{V.slotScopeIds=R,L==null?V.shapeFlag&512?U.ctx.activate(V,g,G,E,Y):k(V,g,G,U,I,E,Y):M(L,V,Y)},k=(L,V,g,G,U,I,E)=>{const R=L.component=Gu(L,G,U);if(Jl(L)&&(R.ctx.renderer=Z),qu(R,!1,E),R.asyncDep){if(U&&U.registerDep(R,j,E),!L.el){const Y=R.subTree=le(ci);y(null,Y,V,g),L.placeholder=Y.el}}else j(R,L,V,g,U,I,E)},M=(L,V,g)=>{const G=V.component=L.component;if(Tu(L,V,g))if(G.asyncDep&&!G.asyncResolved){A(G,V,g);return}else G.next=V,G.update();else V.el=L.el,G.vnode=V},j=(L,V,g,G,U,I,E)=>{const R=()=>{if(L.isMounted){let{next:J,bu:ne,u:oe,parent:he,vnode:ie}=L;{const Oe=ha(L);if(Oe){J&&(J.el=ie.el,A(L,J,E)),Oe.asyncDep.then(()=>{xt(()=>{L.isUnmounted||B()},U)});return}}let se=J,_e;_i(L,!1),J?(J.el=ie.el,A(L,J,E)):J=ie,ne&&ls(ne),(_e=J.props&&J.props.onVnodeBeforeUpdate)&&Ht(_e,he,J,ie),_i(L,!0);const Ae=Er(L),Ne=L.subTree;L.subTree=Ae,m(Ne,Ae,p(Ne.el),Te(Ne),L,U,I),J.el=Ae.el,se===null&&Eu(L,Ae.el),oe&&xt(oe,U),(_e=J.props&&J.props.onVnodeUpdated)&&xt(()=>Ht(_e,he,J,ie),U)}else{let J;const{el:ne,props:oe}=V,{bm:he,m:ie,parent:se,root:_e,type:Ae}=L,Ne=sn(V);_i(L,!1),he&&ls(he),!Ne&&(J=oe&&oe.onVnodeBeforeMount)&&Ht(J,se,V),_i(L,!0);{_e.ce&&_e.ce._hasShadowRoot()&&_e.ce._injectChildStyle(Ae,L.parent?L.parent.type:void 0);const Oe=L.subTree=Er(L);m(null,Oe,g,G,L,U,I),V.el=Oe.el}if(ie&&xt(ie,U),!Ne&&(J=oe&&oe.onVnodeMounted)){const Oe=V;xt(()=>Ht(J,se,Oe),U)}(V.shapeFlag&256||se&&sn(se.vnode)&&se.vnode.shapeFlag&256)&&L.a&&xt(L.a,U),L.isMounted=!0,V=g=G=null}};L.scope.on();const Y=L.effect=new Il(R);L.scope.off();const B=L.update=Y.run.bind(Y),z=L.job=Y.runIfDirty.bind(Y);z.i=L,z.id=L.uid,Y.scheduler=()=>Jo(z),_i(L,!0),B()},A=(L,V,g)=>{V.component=L;const G=L.vnode.props;L.vnode=V,L.next=null,Au(L,V.props,G,g),Pu(L,V.children,g),ri(),wr(L),li()},D=(L,V,g,G,U,I,E,R,Y=!1)=>{const B=L&&L.children,z=L?L.shapeFlag:0,J=V.children,{patchFlag:ne,shapeFlag:oe}=V;if(ne>0){if(ne&128){Q(B,J,g,G,U,I,E,R,Y);return}else if(ne&256){O(B,J,g,G,U,I,E,R,Y);return}}oe&8?(z&16&&ge(B,U,I),J!==B&&d(g,J)):z&16?oe&16?Q(B,J,g,G,U,I,E,R,Y):ge(B,U,I,!0):(z&8&&d(g,""),oe&16&&P(J,g,G,U,I,E,R,Y))},O=(L,V,g,G,U,I,E,R,Y)=>{L=L||en,V=V||en;const B=L.length,z=V.length,J=Math.min(B,z);let ne;for(ne=0;ne<J;ne++){const oe=V[ne]=Y?ti(V[ne]):Wt(V[ne]);m(L[ne],oe,g,null,U,I,E,R,Y)}B>z?ge(L,U,I,!0,!1,J):P(V,g,G,U,I,E,R,Y,J)},Q=(L,V,g,G,U,I,E,R,Y)=>{let B=0;const z=V.length;let J=L.length-1,ne=z-1;for(;B<=J&&B<=ne;){const oe=L[B],he=V[B]=Y?ti(V[B]):Wt(V[B]);if(yn(oe,he))m(oe,he,g,null,U,I,E,R,Y);else break;B++}for(;B<=J&&B<=ne;){const oe=L[J],he=V[ne]=Y?ti(V[ne]):Wt(V[ne]);if(yn(oe,he))m(oe,he,g,null,U,I,E,R,Y);else break;J--,ne--}if(B>J){if(B<=ne){const oe=ne+1,he=oe<z?V[oe].el:G;for(;B<=ne;)m(null,V[B]=Y?ti(V[B]):Wt(V[B]),g,he,U,I,E,R,Y),B++}}else if(B>ne)for(;B<=J;)q(L[B],U,I,!0),B++;else{const oe=B,he=B,ie=new Map;for(B=he;B<=ne;B++){const ot=V[B]=Y?ti(V[B]):Wt(V[B]);ot.key!=null&&ie.set(ot.key,B)}let se,_e=0;const Ae=ne-he+1;let Ne=!1,Oe=0;const Be=new Array(Ae);for(B=0;B<Ae;B++)Be[B]=0;for(B=oe;B<=J;B++){const ot=L[B];if(_e>=Ae){q(ot,U,I,!0);continue}let Je;if(ot.key!=null)Je=ie.get(ot.key);else for(se=he;se<=ne;se++)if(Be[se-he]===0&&yn(ot,V[se])){Je=se;break}Je===void 0?q(ot,U,I,!0):(Be[Je-he]=B+1,Je>=Oe?Oe=Je:Ne=!0,m(ot,V[Je],g,null,U,I,E,R,Y),_e++)}const Xt=Ne?zu(Be):en;for(se=Xt.length-1,B=Ae-1;B>=0;B--){const ot=he+B,Je=V[ot],zt=V[ot+1],Wi=ot+1<z?zt.el||ma(zt):G;Be[B]===0?m(null,Je,g,Wi,U,I,E,R,Y):Ne&&(se<0||B!==Xt[se]?W(Je,g,Wi,2):se--)}}},W=(L,V,g,G,U=null)=>{const{el:I,type:E,transition:R,children:Y,shapeFlag:B}=L;if(B&6){W(L.component.subTree,V,g,G);return}if(B&128){L.suspense.move(V,g,G);return}if(B&64){E.move(L,V,g,Z);return}if(E===Ge){n(I,V,g);for(let J=0;J<Y.length;J++)W(Y[J],V,g,G);n(L.anchor,V,g);return}if(E===as){S(L,V,g);return}if(G!==2&&B&1&&R)if(G===0)R.persisted&&!I[io]?n(I,V,g):(R.beforeEnter(I),n(I,V,g),xt(()=>R.enter(I),U));else{const{leave:J,delayLeave:ne,afterLeave:oe}=R,he=()=>{L.ctx.isUnmounted?s(I):n(I,V,g)},ie=()=>{const se=I._isLeaving||!!I[io];I._isLeaving&&I[io](!0),R.persisted&&!se?he():J(I,()=>{he(),oe&&oe()})};ne?ne(I,he,ie):ie()}else n(I,V,g)},q=(L,V,g,G=!1,U=!1)=>{const{type:I,props:E,ref:R,children:Y,dynamicChildren:B,shapeFlag:z,patchFlag:J,dirs:ne,cacheIndex:oe,memo:he}=L;if(J===-2&&(U=!1),R!=null&&(ri(),Tn(R,null,g,L,!0),li()),oe!=null&&(V.renderCache[oe]=void 0),z&256){V.ctx.deactivate(L);return}const ie=z&1&&ne,se=!sn(L);let _e;if(se&&(_e=E&&E.onVnodeBeforeUnmount)&&Ht(_e,V,L),z&6)ce(L.component,g,G);else{if(z&128){L.suspense.unmount(g,G);return}ie&&Ci(L,null,V,"beforeUnmount"),z&64?L.type.remove(L,V,g,Z,G):B&&!B.hasOnce&&(I!==Ge||J>0&&J&64)?ge(B,V,g,!1,!0):(I===Ge&&J&384||!U&&z&16)&&ge(Y,V,g),G&&re(L)}const Ae=he!=null&&oe==null;(se&&(_e=E&&E.onVnodeUnmounted)||ie||Ae)&&xt(()=>{_e&&Ht(_e,V,L),ie&&Ci(L,null,V,"unmounted"),Ae&&(L.el=null)},g)},re=L=>{const{type:V,el:g,anchor:G,transition:U}=L;if(V===Ge){ae(g,G);return}if(V===as){x(L);return}const I=()=>{s(g),U&&!U.persisted&&U.afterLeave&&U.afterLeave()};if(L.shapeFlag&1&&U&&!U.persisted){const{leave:E,delayLeave:R}=U,Y=()=>E(g,I);R?R(L.el,I,Y):Y()}else I()},ae=(L,V)=>{let g;for(;L!==V;)g=h(L),s(L),L=g;s(V)},ce=(L,V,g)=>{const{bum:G,scope:U,job:I,subTree:E,um:R,m:Y,a:B}=L;Br(Y),Br(B),G&&ls(G),U.stop(),I&&(I.flags|=8,q(E,L,V,g)),R&&xt(R,V),xt(()=>{L.isUnmounted=!0},V)},ge=(L,V,g,G=!1,U=!1,I=0)=>{for(let E=I;E<L.length;E++)q(L[E],V,g,G,U)},Te=L=>{if(L.shapeFlag&6)return Te(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const V=h(L.anchor||L.el),g=V&&V[Qd];return g?h(g):V};let Se=!1;const fe=(L,V,g)=>{let G;L==null?V._vnode&&(q(V._vnode,null,null,!0),G=V._vnode.component):m(V._vnode||null,L,V,null,null,null,g),V._vnode=L,Se||(Se=!0,wr(G),Ul(),Se=!1)},Z={p:m,um:q,m:W,r:re,mt:k,mc:P,pc:D,pbc:H,n:Te,o:e};return{render:fe,hydrate:void 0,createApp:xu(fe)}}function so({type:e,props:i},t){return t==="svg"&&e==="foreignObject"||t==="mathml"&&e==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:t}function _i({effect:e,job:i},t){t?(e.flags|=32,i.flags|=4):(e.flags&=-33,i.flags&=-5)}function Nu(e,i){return(!e||e&&!e.pendingBranch)&&i&&!i.persisted}function pa(e,i,t=!1){const n=e.children,s=i.children;if(Ie(n)&&Ie(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=ti(s[o]),r.el=l.el),!t&&r.patchFlag!==-2&&pa(l,r)),r.type===Us&&(r.patchFlag===-1&&(r=s[o]=ti(r)),r.el=l.el),r.type===ci&&!r.el&&(r.el=l.el)}}function zu(e){const i=e.slice(),t=[0];let n,s,o,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(s=t[t.length-1],e[s]<c){i[n]=s,t.push(n);continue}for(o=0,l=t.length-1;o<l;)r=o+l>>1,e[t[r]]<c?o=r+1:l=r;c<e[t[o]]&&(o>0&&(i[n]=t[o-1]),t[o]=n)}}for(o=t.length,l=t[o-1];o-- >0;)t[o]=l,l=i[l];return t}function ha(e){const i=e.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:ha(i)}function Br(e){if(e)for(let i=0;i<e.length;i++)e[i].flags|=8}function ma(e){if(e.placeholder)return e.placeholder;const i=e.component;return i?ma(i.subTree):null}const ga=e=>e.__isSuspense;function Hu(e,i){i&&i.pendingBranch?Ie(e)?i.effects.push(...e):i.effects.push(e):qd(e)}const Ge=Symbol.for("v-fgt"),Us=Symbol.for("v-txt"),ci=Symbol.for("v-cmt"),as=Symbol.for("v-stc"),si=[];let It=null;function ee(e=!1){si.push(It=e?null:[])}function ir(){si.pop(),It=si[si.length-1]||null}let jn=1;function Dr(e,i=!1){jn+=e,e<0&&It&&i&&(It.hasOnce=!0)}function va(e){return e.dynamicChildren=jn>0?It||en:null,ir(),jn>0&&It&&It.push(e),e}function te(e,i,t,n,s,o){return va(f(e,i,t,n,s,o,!0))}function Kt(e,i,t,n,s){return va(le(e,i,t,n,s,!0))}function nr(e){return e?e.__v_isVNode===!0:!1}function yn(e,i){return e.type===i.type&&e.key===i.key}const ba=({key:e})=>e??null,cs=({ref:e,ref_key:i,ref_for:t})=>(typeof e=="number"&&(e=""+e),e!=null?Qe(e)||Ze(e)||Me(e)?{i:at,r:e,k:i,f:!!t}:e:null);function f(e,i=null,t=null,n=0,s=null,o=e===Ge?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:i,key:i&&ba(i),ref:i&&cs(i),scopeId:Gl,slotScopeIds:null,children:t,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:at};return r?(Ts(a,t),o&128&&e.normalize(a)):t&&(a.shapeFlag|=Qe(t)?8:16),jn>0&&!l&&It&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&It.push(a),a}const le=Fu;function Fu(e,i=null,t=null,n=0,s=null,o=!1){if((!e||e===pu)&&(e=ci),nr(e)){const r=an(e,i,!0);return t&&Ts(r,t),jn>0&&!o&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Qu(e)&&(e=e.__vccOpts),i){i=ju(i);let{class:r,style:a}=i;r&&!Qe(r)&&(i.class=Ce(r)),Ue(a)&&(Zo(a)&&!Ie(a)&&(a=ct({},a)),i.style=Vt(a))}const l=Qe(e)?1:ga(e)?128:eu(e)?64:Ue(e)?4:Me(e)?2:0;return f(e,i,t,n,s,l,o,!0)}function ju(e){return e?Zo(e)||la(e)?ct({},e):e:null}function an(e,i,t=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=e,c=i?Wu(s||{},i):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&ba(c),ref:i&&i.ref?t&&o?Ie(o)?o.concat(cs(i)):[o,cs(i)]:cs(i):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:i&&e.type!==Ge?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&an(e.ssContent),ssFallback:e.ssFallback&&an(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Xo(d,a.clone(d)),d}function St(e=" ",i=0){return le(Us,null,e,i)}function gt(e,i){const t=le(as,null,e);return t.staticCount=i,t}function Le(e="",i=!1){return i?(ee(),Kt(ci,null,e)):le(ci,null,e)}function Wt(e){return e==null||typeof e=="boolean"?le(ci):Ie(e)?le(Ge,null,e.slice()):nr(e)?ti(e):le(Us,null,String(e))}function ti(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:an(e)}function Ts(e,i){let t=0;const{shapeFlag:n}=e;if(i==null)i=null;else if(Ie(i))t=16;else if(typeof i=="object")if(n&65){const s=i.default;s&&(s._c&&(s._d=!1),Ts(e,s()),s._c&&(s._d=!0));return}else{t=32;const s=i._;!s&&!la(i)?i._ctx=at:s===3&&at&&(at.slots._===1?i._=1:(i._=2,e.patchFlag|=1024))}else if(Me(i)){if(n&65){Ts(e,{default:i});return}i={default:i,_ctx:at},t=32}else i=String(i),n&64?(t=16,i=[St(i)]):t=8;e.children=i,e.shapeFlag|=t}function Wu(...e){const i={};for(let t=0;t<e.length;t++){const n=e[t];for(const s in n)if(s==="class")i.class!==n.class&&(i.class=Ce([i.class,n.class]));else if(s==="style")i.style=Vt([i.style,n.style]);else if(Bs(s)){const o=i[s],l=n[s];l&&o!==l&&!(Ie(o)&&o.includes(l))?i[s]=o?[].concat(o,l):l:l==null&&o==null&&!Ds(s)&&(i[s]=l)}else s!==""&&(i[s]=n[s])}return i}function Ht(e,i,t,n=null){Nt(e,i,7,[t,n])}const Uu=ia();let Vu=0;function Gu(e,i,t){const n=e.type,s=(i?i.appContext:e.appContext)||Uu,o={uid:Vu++,vnode:e,type:n,parent:i,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new bd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(s.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ca(n,s),emitsOptions:na(n,s),emit:null,emitted:null,propsDefaults:Ve,inheritAttrs:n.inheritAttrs,ctx:Ve,data:Ve,props:Ve,attrs:Ve,slots:Ve,refs:Ve,setupState:Ve,setupContext:null,suspense:t,suspenseId:t?t.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=i?i.root:o,o.emit=Cu.bind(null,o),e.ce&&e.ce(o),o}let ht=null;const Ku=()=>ht||at;let Es,To;{const e=Os(),i=(t,n)=>{let s;return(s=e[t])||(s=e[t]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};Es=i("__VUE_INSTANCE_SETTERS__",t=>ht=t),To=i("__VUE_SSR_SETTERS__",t=>Wn=t)}const qn=e=>{const i=ht;return Es(e),e.scope.on(),()=>{e.scope.off(),Es(i)}},Lr=()=>{ht&&ht.scope.off(),Es(null)};function ya(e){return e.vnode.shapeFlag&4}let Wn=!1;function qu(e,i=!1,t=!1){i&&To(i);const{props:n,children:s}=e.vnode,o=ya(e);Mu(e,n,o,i),Lu(e,s,t||i);const l=o?Yu(e,i):void 0;return i&&To(!1),l}function Yu(e,i){const t=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,mu);const{setup:n}=t;if(n){ri();const s=e.setupContext=n.length>1?Ju(e):null,o=qn(e),l=Kn(n,e,0,[e.props,s]),r=kl(l);if(li(),o(),(r||e.sp)&&!sn(e)&&Zl(e),r){if(l.then(Lr,Lr),i)return l.then(a=>{Pr(e,a)}).catch(a=>{Hs(a,e,0)});e.asyncDep=l}else Pr(e,l)}else ka(e)}function Pr(e,i,t){Me(i)?e.type.__ssrInlineRender?e.ssrRender=i:e.render=i:Ue(i)&&(e.setupState=Fl(i)),ka(e)}function ka(e,i,t){const n=e.type;e.render||(e.render=n.render||Yt);{const s=qn(e);ri();try{gu(e)}finally{li(),s()}}}const Zu={get(e,i){return ft(e,"get",""),e[i]}};function Ju(e){const i=t=>{e.exposed=t||{}};return{attrs:new Proxy(e.attrs,Zu),slots:e.slots,emit:e.emit,expose:i}}function Vs(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Fl(Nd(e.exposed)),{get(i,t){if(t in i)return i[t];if(t in En)return En[t](e)},has(i,t){return t in i||t in En}})):e.proxy}function Xu(e,i=!0){return Me(e)?e.displayName||e.name:e.name||i&&e.__name}function Qu(e){return Me(e)&&"__vccOpts"in e}const ye=(e,i)=>Wd(e,i,Wn),ef="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Eo;const Rr=typeof window<"u"&&window.trustedTypes;if(Rr)try{Eo=Rr.createPolicy("vue",{createHTML:e=>e})}catch{}const wa=Eo?e=>Eo.createHTML(e):e=>e,tf="http://www.w3.org/2000/svg",nf="http://www.w3.org/1998/Math/MathML",ei=typeof document<"u"?document:null,Or=ei&&ei.createElement("template"),sf={insert:(e,i,t)=>{i.insertBefore(e,t||null)},remove:e=>{const i=e.parentNode;i&&i.removeChild(e)},createElement:(e,i,t,n)=>{const s=i==="svg"?ei.createElementNS(tf,e):i==="mathml"?ei.createElementNS(nf,e):t?ei.createElement(e,{is:t}):ei.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>ei.createTextNode(e),createComment:e=>ei.createComment(e),setText:(e,i)=>{e.nodeValue=i},setElementText:(e,i)=>{e.textContent=i},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ei.querySelector(e),setScopeId(e,i){e.setAttribute(i,"")},insertStaticContent(e,i,t,n,s,o){const l=t?t.previousSibling:i.lastChild;if(s&&(s===o||s.nextSibling))for(;i.insertBefore(s.cloneNode(!0),t),!(s===o||!(s=s.nextSibling)););else{Or.innerHTML=wa(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Or.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}i.insertBefore(r,t)}return[l?l.nextSibling:i.firstChild,t?t.previousSibling:i.lastChild]}},of=Symbol("_vtc");function rf(e,i,t){const n=e[of];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?e.removeAttribute("class"):t?e.setAttribute("class",i):e.className=i}const Ms=Symbol("_vod"),xa=Symbol("_vsh"),Mo={name:"show",beforeMount(e,{value:i},{transition:t}){e[Ms]=e.style.display==="none"?"":e.style.display,t&&i?t.beforeEnter(e):kn(e,i)},mounted(e,{value:i},{transition:t}){t&&i&&t.enter(e)},updated(e,{value:i,oldValue:t},{transition:n}){!i!=!t&&(n?i?(n.beforeEnter(e),kn(e,!0),n.enter(e)):n.leave(e,()=>{kn(e,!1)}):kn(e,i))},beforeUnmount(e,{value:i}){kn(e,i)}};function kn(e,i){e.style.display=i?e[Ms]:"none",e[xa]=!i}const lf=Symbol(""),af=/(?:^|;)\s*display\s*:/;function cf(e,i,t){const n=e.style,s=Qe(t);let o=!1;if(t&&!s){if(i)if(Qe(i))for(const l of i.split(";")){const r=l.slice(0,l.indexOf(":")).trim();t[r]==null&&xn(n,r,"")}else for(const l in i)t[l]==null&&xn(n,l,"");for(const l in t){l==="display"&&(o=!0);const r=t[l];r!=null?uf(e,l,!Qe(i)&&i?i[l]:void 0,r)||xn(n,l,r):xn(n,l,"")}}else if(s){if(i!==t){const l=n[lf];l&&(t+=";"+l),n.cssText=t,o=af.test(t)}}else i&&e.removeAttribute("style");Ms in e&&(e[Ms]=o?n.display:"",e[xa]&&(n.display="none"))}const Nr=/\s*!important$/;function xn(e,i,t){if(Ie(t))t.forEach(n=>xn(e,i,n));else if(t==null&&(t=""),i.startsWith("--"))e.setProperty(i,t);else{const n=df(e,i);Nr.test(t)?e.setProperty(xi(n),t.replace(Nr,""),"important"):e[n]=t}}const zr=["Webkit","Moz","ms"],oo={};function df(e,i){const t=oo[i];if(t)return t;let n=wt(i);if(n!=="filter"&&n in e)return oo[i]=n;n=Ps(n);for(let s=0;s<zr.length;s++){const o=zr[s]+n;if(o in e)return oo[i]=o}return i}function uf(e,i,t,n){return e.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qe(n)&&t===n}const Hr="http://www.w3.org/1999/xlink";function Fr(e,i,t,n,s,o=gd(i)){n&&i.startsWith("xlink:")?t==null?e.removeAttributeNS(Hr,i.slice(6,i.length)):e.setAttributeNS(Hr,i,t):t==null||o&&!Cl(t)?e.removeAttribute(i):e.setAttribute(i,o?"":Rt(t)?String(t):t)}function jr(e,i,t,n,s){if(i==="innerHTML"||i==="textContent"){t!=null&&(e[i]=i==="innerHTML"?wa(t):t);return}const o=e.tagName;if(i==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,a=t==null?e.type==="checkbox"?"on":"":String(t);(r!==a||!("_value"in e))&&(e.value=a),t==null&&e.removeAttribute(i),e._value=t;return}let l=!1;if(t===""||t==null){const r=typeof e[i];r==="boolean"?t=Cl(t):t==null&&r==="string"?(t="",l=!0):r==="number"&&(t=0,l=!0)}try{e[i]=t}catch{}l&&e.removeAttribute(s||i)}function gi(e,i,t,n){e.addEventListener(i,t,n)}function ff(e,i,t,n){e.removeEventListener(i,t,n)}const Wr=Symbol("_vei");function pf(e,i,t,n,s=null){const o=e[Wr]||(e[Wr]={}),l=o[i];if(n&&l)l.value=n;else{const[r,a]=gf(i);if(n){const c=o[i]=yf(n,s);gi(e,r,c,a)}else l&&(ff(e,r,l,a),o[i]=void 0)}}const hf=/(Once|Passive|Capture)$/,mf=/^on:?(?:Once|Passive|Capture)$/;function gf(e){let i,t;for(;(t=e.match(hf))&&!mf.test(e);)i||(i={}),e=e.slice(0,e.length-t[1].length),i[t[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):xi(e.slice(2)),i]}let ro=0;const vf=Promise.resolve(),bf=()=>ro||(vf.then(()=>ro=0),ro=Date.now());function yf(e,i){const t=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=t.attached)return;const s=t.value;if(Ie(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Nt(c,i,5,r)}}else Nt(s,i,5,[n])};return t.value=e,t.attached=bf(),t}const Ur=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,kf=(e,i,t,n,s,o)=>{const l=s==="svg";i==="class"?rf(e,n,l):i==="style"?cf(e,t,n):Bs(i)?Ds(i)||pf(e,i,t,n,o):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):wf(e,i,n,l))?(jr(e,i,n),!e.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&Fr(e,i,n,l,o,i!=="value")):e._isVueCE&&(xf(e,i)||e._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qe(n)))?jr(e,wt(i),n,o,i):(i==="true-value"?e._trueValue=n:i==="false-value"&&(e._falseValue=n),Fr(e,i,n,l))};function wf(e,i,t,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in e&&Ur(i)&&Me(t));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&e.tagName==="IFRAME"||i==="form"||i==="list"&&e.tagName==="INPUT"||i==="type"&&e.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Ur(i)&&Qe(t)?!1:i in e}function xf(e,i){const t=e._def.props;if(!t)return!1;const n=wt(i);return Array.isArray(t)?t.some(s=>wt(s)===n):Object.keys(t).some(s=>wt(s)===n)}const cn=e=>{const i=e.props["onUpdate:modelValue"]||!1;return Ie(i)?t=>ls(i,t):i};function Sf(e){e.target.composing=!0}function Vr(e){const i=e.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const oi=Symbol("_assign");function Gr(e,i,t){return i&&(e=e.trim()),t&&(e=Rs(e)),e}const Ao={created(e,{modifiers:{lazy:i,trim:t,number:n}},s){e[oi]=cn(s);const o=n||s.props&&s.props.type==="number";gi(e,i?"change":"input",l=>{l.target.composing||e[oi](Gr(e.value,t,o))}),(t||o)&&gi(e,"change",()=>{e.value=Gr(e.value,t,o)}),i||(gi(e,"compositionstart",Sf),gi(e,"compositionend",Vr),gi(e,"change",Vr))},mounted(e,{value:i}){e.value=i??""},beforeUpdate(e,{value:i,oldValue:t,modifiers:{lazy:n,trim:s,number:o}},l){if(e[oi]=cn(l),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Rs(e.value):e.value,a=i??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&i===t||s&&e.value.trim()===a)||(e.value=a)}},ns={deep:!0,created(e,i,t){e[oi]=cn(t),gi(e,"change",()=>{const n=e._modelValue,s=Un(e),o=e.checked,l=e[oi];if(Ie(n)){const r=Wo(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(un(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(Sa(e,o))})},mounted:Kr,beforeUpdate(e,i,t){e[oi]=cn(t),Kr(e,i,t)}};function Kr(e,{value:i,oldValue:t},n){e._modelValue=i;let s;if(Ie(i))s=Wo(i,n.props.value)>-1;else if(un(i))s=i.has(n.props.value);else{if(i===t)return;s=fn(i,Sa(e,!0))}e.checked!==s&&(e.checked=s)}const Cf={deep:!0,created(e,{value:i,modifiers:{number:t}},n){e._modelValue=i,gi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>t?Rs(Un(o)):Un(o));e[oi](e.multiple?un(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Cs(()=>{e._assigning=!1})}),e[oi]=cn(n)},mounted(e,{value:i}){qr(e,i)},beforeUpdate(e,{value:i},t){e._modelValue=i,e[oi]=cn(t)},updated(e,{value:i}){e._assigning||qr(e,i)}};function qr(e,i){const t=e.multiple,n=Ie(i);if(!(t&&!n&&!un(i))){for(let s=0,o=e.options.length;s<o;s++){const l=e.options[s],r=Un(l);if(t)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(r)):l.selected=Wo(i,r)>-1}else l.selected=i.has(r);else if(fn(Un(l),i)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!t&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Un(e){return"_value"in e?e._value:e.value}function Sa(e,i){const t=i?"_trueValue":"_falseValue";return t in e?e[t]:i}const _f=["ctrl","shift","alt","meta"],$f={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,i)=>_f.some(t=>e[`${t}Key`]&&!i.includes(t))},Gt=(e,i)=>{if(!e)return e;const t=e._withMods||(e._withMods={}),n=i.join(".");return t[n]||(t[n]=((s,...o)=>{for(let l=0;l<i.length;l++){const r=$f[i[l]];if(r&&r(s,i))return}return e(s,...o)}))},If={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Tf=(e,i)=>{const t=e._withKeys||(e._withKeys={}),n=i.join(".");return t[n]||(t[n]=(s=>{if(!("key"in s))return;const o=xi(s.key);if(i.some(l=>l===o||If[l]===o))return e(s)}))},Ef=ct({patchProp:kf},sf);let Yr;function Mf(){return Yr||(Yr=Ru(Ef))}const sr=((...e)=>{const i=Mf().createApp(...e),{mount:t}=i;return i.mount=n=>{const s=Bf(n);if(!s)return;const o=i._component;!Me(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=t(s,!1,Af(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},i});function Af(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Bf(e){return Qe(e)?document.querySelector(e):e}const Df="slides-config.json",dn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},vi=zs({...dn});function Lf(e){if(!e||typeof e!="object")return{...dn};const i=e;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():dn.webServeUrl,normalizeHeadingSizes:!!i.normalizeHeadingSizes}}function Di(e){if(!e||typeof e!="object")return{...vi};const i=e;return i.enableWebServeJump!==void 0&&(vi.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(vi.webServeUrl=String(i.webServeUrl)),i.normalizeHeadingSizes!==void 0&&(vi.normalizeHeadingSizes=!!i.normalizeHeadingSizes),{...vi}}function Gs(){return{...vi}}function Ca(e,i,t){const n=(e||dn.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(t==null?void 0:t.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",i),t!=null&&t.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=t!=null&&t.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${o}`}}const $i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Pf(e){var t,n,s,o,l,r;const i=Gs();return e?{theme:((t=e[Ln])==null?void 0:t.trim())||$i.theme,aspectRatio:((n=e[Pn])==null?void 0:n.trim())||$i.aspectRatio,highlighter:((s=e[hl])==null?void 0:s.trim())||$i.highlighter,defaultTransition:((o=e[Rn])==null?void 0:o.trim())||$i.defaultTransition,colorSchema:((l=e[ml])==null?void 0:l.trim())||$i.colorSchema,spacing:((r=e[bo])==null?void 0:r.trim())||$i.spacing,normalizeHeadingSizes:i.normalizeHeadingSizes}:{...$i,normalizeHeadingSizes:i.normalizeHeadingSizes}}function As(e){var t,n,s,o,l;const i=(t=e.ial)==null?void 0:t[Mi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Zr(e){const i={};let t="";if(!e)return{frontmatter:i,notes:t};e[we]&&(i.layout=e[we].trim()),e[pt]&&(i.transition=e[pt].trim()),e[et]&&(i.background=e[et].trim()),e[Dt]&&(i.image=e[Dt].trim()),e[Zi]&&(i.class=e[Zi].trim()),e[Cn]&&(i.spacing=e[Cn].trim()),e[yt]&&(i.layoutRatio=e[yt].trim()),e[Ji]&&(i.mask=e[Ji].trim()),e[Pi]&&(i.maskRatio=e[Pi].trim()),e[Xi]&&(i.maskStyle=e[Xi].trim()),e[Qi]&&(i.maskInitial=e[Qi].trim()),e[Zs]&&(t=e[Zs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![we,yt,Ji,Pi,Xi,Qi,pt,et,Dt,Zi,Cn,Zs,Mi].includes(n)){const o=n.replace(/^custom-slides-/,"");try{i[o]=JSON.parse(s)}catch{i[o]=s}}return{frontmatter:i,notes:t}}function Rf(e){const i={};if(!e)return i;const t=e[it]??e["slides-note"];t!=null&&t!==""&&t!=="false"&&t!=="0"&&(i.isNote=!0);const n=e[qe]??e["slides-role"],s=e[et]??e["slides-background"];(n===gl||s==="true"||s==="1")&&(i.isBackground=!0);const o=e[we]??e["slides-layout"];o===ks||o===ws?i.imageLayout=o:(n===ks||n===ws)&&(i.imageLayout=n);const l=e[Ye]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(l!=null&&(i.clicks=l.trim()),e[qt])try{const r=JSON.parse(e[qt]);typeof r=="object"&&r!==null?i.motion={preset:r.preset||r.type||"fade-in",...r}:i.motion={preset:String(r).trim()}}catch{i.motion={preset:e[qt].trim()}}return e[Fi]&&(i.shikiLines=e[Fi].trim()),e[On]&&(i.maxHeight=e[On].trim()),e[$e]&&(i.slot=e[$e].trim()),e.style&&e.style.trim()&&(i.style=e.style.trim()),i}function wi(e,i){const t=(e||i||"").trim();if(!t)return null;const n=t.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=t.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=t.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Mn(e){if(!e)return"";const i=e.split(/\r?\n/);if(i.length===0)return"";const t=i[0],n=t.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),l=t.length-n[2].length;if(i.length===1)return o;const r=[o];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>s?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function ji(e){if(!e)return!1;const i=(e.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const t=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(t)}function lo(e,i=2){if(!e||typeof e!="string")return`repeat(${i}, 1fr)`;const t=e.trim();if(!t)return`repeat(${i}, 1fr)`;if(t.includes(":")){const s=t.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=t.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function An(e){if(!e)return[];if(st(e)&&Zt(e)&&!ui(e)){const n=hn(e),s=[];for(const o of n)s.push(...An(o));return s}const i=(e.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(ji);if(l.length>0)return l}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return ji(e)?[e]:[]}function or(e){var s;if(!e||!st(e)||!Zt(e)||ui(e))return null;const i=hn(e);if(i.length===0)return null;if(i.length===1&&st(i[0])&&Zt(i[0])){const o=or(i[0]);return o?{items:o.items,nestedSuperBlocks:[i[0],...o.nestedSuperBlocks]}:null}const t=[];for(const o of i)if(st(o)){t.push(o);const l=((s=o.children)==null?void 0:s.filter(st))||[];t.push(...l)}const n=i.map(An);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:t}}if(i.length===2){const o=An(i[0]),l=An(i[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:t}}return null}function Of(e){if(!e||!st(e)||!Zt(e)||ui(e))return null;const i=or(e);if(!i)return null;const{items:t,nestedSuperBlocks:n}=i;if(t.length<2||t.length>6)return null;const s=rr(e)||void 0,o=t.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:t,slots:t.map((l,r)=>`col-${r+1}`),ratio:s}}function _a(e){if(!e||!st(e)||!Zt(e)||ui(e))return null;const i=hn(e);if(i.length===0)return null;const t=[];for(const n of i){const s=An(n);if(s.length===0)return null;t.push(...s)}return t}function Nf(e){if(!e||!st(e)||!Zt(e)||ui(e))return null;const i=_a(e);return!i||i.length===0||i.length>=2&&i.length<=6?null:{superBlockNode:e,items:i}}function zf(e){if(!e||!st(e)||!Zt(e)||ui(e))return null;const i=or(e);if(i&&i.items.length===4)return i.items;const t=_a(e);if(t&&t.length===4)return t;const n=hn(e);return n.length===4?n:null}function Hf(e,i){if(!e||e.length===0)return null;const t=[];function n(r,a){if(st(r)){const c=zf(r);c&&c.length===4&&t.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(t.length===0)return null;let s=null;i&&(s=t.find(r=>{if(r.sbNode.id===i||r.items.some(c=>c.id===i))return!0;const a=c=>c.id===i?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=t[0]);const l=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>$a(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function Ff(e,i,t){var d,p,h,u,b;const n=[],s=[],o=(t==null?void 0:t.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<i.length;m++){const v=i[m];if(As(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(m){const v=[];for(const y of m)st(y)&&v.push(y),y.children&&y.children.length>0&&v.push(...a(y.children));return v}function c(m,v,y){const C={blockId:m,attrs:v,previousAttrs:y};n.push(C),t!=null&&t.onTagChange&&t.onTagChange(C)}for(const m of l){const v=m.pageTargetId,y=i.find(T=>T.id===v),C=o.find(T=>T.pageTargetId===v);if(m.blocks.some(T=>{var w,P;return!!(ui(T)||Bo(T)&&(((w=T.ial)==null?void 0:w[we])==="image-left"||((P=T.ial)==null?void 0:P[we])==="image-right"))})){if(C){const T=C.headerId;if(T){c(T,{[$e]:""});const w=i.find(P=>P.id===T);w!=null&&w.ial&&(w.ial[$e]="")}for(const w of C.itemIds){c(w,{[$e]:""});const P=i.find(N=>N.id===w);P!=null&&P.ial&&(P.ial[$e]="")}}continue}let x=null,$=-1;for(let T=0;T<m.blocks.length;T++){const w=m.blocks[T],P=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const N of P){const H=Of(N);if(H){x=H,$=T;break}}if(x)break}if(x){const{superBlockNode:T,layout:w,items:P,slots:N}=x,K=m.blocks.slice(0,$).find(A=>$a(A)),_=K==null?void 0:K.id,F=((d=y==null?void 0:y.ial)==null?void 0:d[we])||"",k=F==="clover",M=k?"clover":w;if(F!==M&&(c(v,{[we]:M},{[we]:F}),y&&(y.ial||(y.ial={}),y.ial[we]=M)),K){const A=((p=K.ial)==null?void 0:p[$e])||"";A!=="header"&&(c(K.id,{[$e]:"header"},{[$e]:A}),K.ial||(K.ial={}),K.ial[$e]="header")}if(C!=null&&C.headerId&&C.headerId!==_){c(C.headerId,{[$e]:""});const A=i.find(D=>D.id===C.headerId);A&&(A.ial||(A.ial={}),A.ial[$e]="")}const j=[];for(let A=0;A<P.length;A++){const D=P[A],O=N[A];j.push(D.id);const Q=((h=D.ial)==null?void 0:h[$e])||"";if(Q!==O&&(c(D.id,{[$e]:O},{[$e]:Q}),D.ial||(D.ial={}),D.ial[$e]=O),D.children&&D.children.length>0)for(const W of D.children)W.ial||(W.ial={}),W.ial[$e]!==O&&(W.ial[$e]=O)}if(C!=null&&C.itemIds){for(const A of C.itemIds)if(!j.includes(A)){c(A,{[$e]:""});const D=i.find(O=>O.id===A);D&&(D.ial||(D.ial={}),D.ial[$e]="")}}s.push({superBlockId:T.id,nestedSuperBlockIds:(u=x.nestedSuperBlocks)==null?void 0:u.map(A=>A.id),pageTargetId:v,headerId:_,itemIds:j,layout:k?"clover":w})}else{let T=!1;const w=[];for(const H of m.blocks){const K=st(H)?[H,...a(H.children||[])]:H.children?a(H.children):[];for(const _ of K){const F=Nf(_);if(F){T=!0;for(const k of F.items)w.push(k.id)}}}const P=((b=y==null?void 0:y.ial)==null?void 0:b[we])||"",N=Nn(P);if(C||T&&N){c(v,{[we]:""},{[we]:P}),y&&(y.ial||(y.ial={}),y.ial[we]="");const H=C==null?void 0:C.headerId;if(H){c(H,{[$e]:""});const _=i.find(F=>F.id===H);_&&(_.ial||(_.ial={}),_.ial[$e]="")}const K=new Set([...(C==null?void 0:C.itemIds)||[],...w]);for(const _ of K){c(_,{[$e]:""});const F=i.find(k=>k.id===_);F&&(F.ial||(F.ial={}),F.ial[$e]="")}}}}return{changes:n,newTracked:s}}function st(e){if(!e)return!1;const i=(e.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Zt(e){if(!st(e))return!1;const i=(e.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const t=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(t)?!0:!/^\{\{\{row\b/i.test(t)}function Bo(e){return!e||ji(e)||st(e)||!wi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function rr(e){var h;if(!e||!st(e)||!Zt(e))return null;const i=hn(e);if(!i||i.length<2)return null;const t=[];let n=!1;for(const u of i){const b=(((h=u.ial)==null?void 0:h.style)||u.style||"").trim();let m=null;if(b){const v=b.match(/calc\(\s*([\d.]+)%/i);if(v)m=parseFloat(v[1]);else{const y=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(t.push(m),n=!0):t.push(null)}if(!n)return null;const s=i.length,o=t.reduce((u,b)=>u+(b||0),0),l=t.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=t.map(u=>u!==null?u:a),d=c.reduce((u,b)=>u+b,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const b=Math.round(u),m=100-b;return`${b}:${m}`}if(p.length===3){const[u,b,m]=p;if(u>=31&&u<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(u>=23&&u<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(u>=48&&u<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(u>=23&&u<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(u>=18&&u<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const v=Math.round(u),y=Math.round(b),C=100-v-y;return`${v}:${y}:${C}`}return p.map(u=>Math.round(u)).join(":")}function ui(e){if(!e||!st(e)||!Zt(e))return null;const i=(e.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(i.length<2)return null;const t=Bo(i[0]),n=Bo(i[i.length-1]),s=rr(e)||void 0;if(t&&!n){const o=wi(i[0].markdown,i[0].content);if(o)return{imageNode:i[0],imageUrl:o,layout:ks,contentNodes:i.slice(1),ratio:s}}if(!t&&n){const o=wi(i[i.length-1].markdown,i[i.length-1].content);if(o)return{imageNode:i[i.length-1],imageUrl:o,layout:ws,contentNodes:i.slice(0,i.length-1),ratio:s}}return null}function jf(e,i){const t=[];function n(s){for(const o of s){const l=ui(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[we];if(d!==a){const h={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[we]=a,t.push(h),i&&i(h)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),t}function hn(e){return(e.children||[]).filter(i=>{const t=i.type||"";if(t==="NodeSuperBlockOpenMarker"||t==="NodeSuperBlockLayoutMarker"||t==="NodeSuperBlockCloseMarker"||t==="open-marker"||t==="layout-marker"||t==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function $a(e){if(!e)return!1;const i=(e.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const t=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(t)}function Ii(e,i,t){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const C=y[1];if(typeof i=="string"?C.split(/\s+/).includes(i):i.test(C)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,a);const d=a+c;let p=1,h=-1,u=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=d;let m;for(;(m=b.exec(e))!==null;)if(m[0].startsWith("</")){if(p--,p===0){h=m.index,u=m.index+m[0].length;break}}else p++;if(h!==-1&&u!==-1){const v=e.slice(d,h);n+=t(v),s=u}else n+=e.slice(a,d),s=d}return n}function Wf(e){const i=[];let t="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=o.index,a=o[0].length;break}}if(!l){t+=e.slice(n);break}t+=e.slice(n,r);const c=r+a;let d=1,p=-1,h=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let b;for(;(b=u.exec(e))!==null;)if(b[0].startsWith("</")){if(d--,d===0){p=b.index,h=b.index+b[0].length;break}}else d++;if(p!==-1&&h!==-1){const m=e.slice(r,h),v=`__VUE_DIV_TOKEN_${i.length}__`;i.push(m),t+=v,n=h}else t+=e.slice(r,c),n=c}return{text:t,tokens:i}}function Uf(e){const i=[];let t=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});t=t.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});const n=[];t=t.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=Wf(t);t=s;const l=[];t=t.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),t=t.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),t=t.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),t=t.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),t=t.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),t=t.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),t=t.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),t=t.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),t=t.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),t=t.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),t=t.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),t=t.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),t=t.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),t=t.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),t=t.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),t=Ii(t,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),t=Ii(t,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),t=t.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),t=Ii(t,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),t=Ii(t,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),t=Ii(t,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),t=Ii(t,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),t=Ii(t,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),t=t.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),t=t.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),t=t.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),t=t.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),t=t.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),t=t.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),t=t.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),t=t.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),t=t.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),t=t.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),t=t.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),t=t.replace(/<br\s*\/?>/gi,`
`),t=t.replace(/<hr\s*\/?>/gi,`
---
`),t=t.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),t=t.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),t=t.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),t=t.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,h)=>Math.max(p,h.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),t=t.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),t=t.replace(/\*{4}/g,"** **"),t=t.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),t=t.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),t=t.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),t=t.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const h=p.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),t=t.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),t=t.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),t=t.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),t=t.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),t=t.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),t=t.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)t=t.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)t=t.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)t=t.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<i.length;r++)t=t.replace(`__CODE_TOKEN_${r}__`,i[r]);return t=t.replace(/\n{3,}/g,`

`).trim(),t}function Ia(e){if(!e||typeof e!="string")return"";const i=[];let t=e.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return t=t.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),t=t.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),t=t.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),t=t.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),t=t.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),t=t.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),t=t.replace(/\{:[^}]*\}/g,""),t=t.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>i[parseInt(s,10)]||""),t}function Vf(e){const i=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return i.length===0?"":`---
${i.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Gf(e,i){if(!i||!e.startsWith("```"))return e;const t=e.indexOf(`
`);if(t===-1)return e;const n=e.slice(0,t).trim(),s=e.slice(t);return n.includes("{")?e:`${n} {${i}}${s}`}function Ta(e,i){if(i==null)return e;const t=i.trim();return t===""||t==="+1"?`<v-click>

${e}

</v-click>`:t==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${t}">

${e}

</v-click>`}function Kf(e){if(!e||!e.preset)return null;const i=e.preset.toLowerCase().trim();if(!i||i==="none")return null;let t={opacity:0},n={opacity:1};switch(i){case"slide-up":t={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":t={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":t={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":t={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":t={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":t={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:t={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(t={...t,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:t,enter:n}}function ss(e,i,t,n){const s=i!=null&&i.trim()!=="",o=Kf(t),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${e}

</div>`:e;if(s&&!o){if(r){const b=i.trim();let m="v-click";return b==="hide"?m="v-click.hide":b!==""&&b!=="+1"&&(m=`v-click="${b}"`),`<div ${m}${a}>

${e}

</div>`}return Ta(e,i)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${p}${a}>

${e}

</div>`;const h=i.trim();let u="v-click";return h==="hide"?u="v-click.hide":h!==""&&h!=="+1"&&(u=`v-click="${h}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function Ea(e){if(!e)return"";let i=e.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let s=i.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function qf(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const t=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return t?t[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ma(e,i=2){const t=Math.max(2,i);if(!e||e.length===0)return Array.from({length:t},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:t},()=>[]),p=Math.min(t,c.length),h=Math.floor(c.length/p),u=c.length%p;let b=0;for(let m=0;m<p;m++){const v=h+(m<u?1:0);d[m]=c.slice(b,b+v),b+=v}return d}if(e.length===1){const c=e[0],p=(c.slot||"").trim().match(/^col-(\d+)$/i),h=p?parseInt(p[1],10):null,u=(c.rawMarkdown||c.content||"").trim(),b=u.split(/\r?\n/),m=[];for(let C=0;C<b.length;C++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[C])&&m.push(C);if(m.length>=t){const C=Array.from({length:t},()=>[]);let S=0;for(let x=0;x<t;x++){const $=t-x,T=m.length-S,w=Math.ceil(T/$),P=m[S],N=S+w<m.length?m[S+w]:b.length,H=b.slice(P,N).join(`
`);C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:H,content:H}],S+=w}return C}const v=u.match(/<li[\s\S]*?<\/li>/gi);if(v&&v.length>=t){const C=Array.from({length:t},()=>[]);let S=0;for(let x=0;x<t;x++){const $=t-x,T=v.length-S,w=Math.ceil(T/$),P=`<ul>
${v.slice(S,S+w).join(`
`)}
</ul>`;C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:P,content:P}],S+=w}return C}const y=u.split(/\r?\n\s*\r?\n/).filter(C=>C.trim()!=="");if(y.length>=t){const C=Array.from({length:t},()=>[]);let S=0;for(let x=0;x<t;x++){const $=t-x,T=y.length-S,w=Math.ceil(T/$),P=y.slice(S,S+w).join(`

`);C[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:P,content:P}],S+=w}return C}if(h&&h>=1&&h<=t){const C=Array.from({length:t},()=>[]);return C[h-1]=[c],C}return[[c],...Array.from({length:t-1},()=>[])]}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return t===2?2:t;const p=d.match(/^col-(\d+)$/i);if(p){const h=parseInt(p[1],10);if(h>=1&&h<=t)return h}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:t},()=>[]);let b=1;for(const v of e){const y=n(v);y!==null&&(b=y),u[b-1].push(v)}if(!e.some(v=>/^col-\d+$/i.test((v.slot||"").trim()))&&u[0].length===0){const v=u.filter(y=>y.length>0);if(v.length===1)return[v[0],...Array.from({length:t-1},()=>[])]}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),h=t-1;if(p.length>=h){const u=Math.floor(p.length/h),b=p.length%h,m=[d];let v=0;for(let y=0;y<h;y++){const C=u+(y<b?1:0);m.push(p.slice(v,v+C)),v+=C}return m}else if(p.length>0){const u=[d];for(let b=0;b<h;b++)u.push(b<p.length?[p[b]]:[]);return u}else return[d,...Array.from({length:h},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=t){const c=Array.from({length:t},()=>[]);for(let d=0;d<t;d++){const p=r[d],h=d+1<t?r[d+1]:e.length;c[d]=e.slice(p,h)}return c}if(e.length>=t){const c=Array.from({length:t},()=>[]);let d=0;for(let p=0;p<t;p++){const h=t-p,u=e.length-d,b=Math.ceil(u/h);c[p]=e.slice(d,d+b),d+=b}return c}if(e.length>1&&e.length<t){const c=Array.from({length:t},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}const a=Array.from({length:t},()=>[]);return a[0]=e,a}function Jr(e,i,t,n){var d;const s=Pf(i),o=[],l=Zr(i);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),o.push(r);let a=[];for(const p of t){if(As(p)){a=[];const u=Zr(p.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),o.push(r);continue}const h=(u,b)=>{var j,A,D,O;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const Q=W=>{for(const q of W)q.id&&!r.allBlockIds.includes(q.id)&&r.allBlockIds.push(q.id),q.children&&q.children.length>0&&Q(q.children)};Q(u.children)}let m=sd(u),v=u.ial?{...u.ial}:{};const y=m.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(v={...od(y[0]),...v},m=m.slice(0,y.index).trim()),u.type!=="c"&&!m.startsWith("```")&&(m=Ia(m));let C=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(m=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=m.trim());const S=Rf(v);if(m=rd(m,n),m=id(m,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const Q=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],W=q=>{for(const re of q){if(re.ial)for(const[ae,ce]of Object.entries(re.ial))Q.includes(ae)&&!v[ae]&&(v[ae]=ce);re.children&&re.children.length>0&&W(re.children)}};W(u.children)}const x=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(m);if(x){const Q=v["custom-slides-autoplay"]==="true",W=v["custom-slides-loop"]==="true",q=v["custom-slides-muted"]==="true"||Q,re=v["custom-slides-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(ae,ce)=>{let ge=ce;return re?ge=ge.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ge)||(ge+=" controls"),Q&&!/autoplay/i.test(ge)?ge+=" autoplay playsinline":!Q&&v["custom-slides-autoplay"]==="false"&&(ge=ge.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),W&&!/loop/i.test(ge)?ge+=" loop":!W&&v["custom-slides-loop"]==="false"&&(ge=ge.replace(/\bloop\b/gi,"").trim()),q&&!/muted/i.test(ge)?ge+=" muted":!q&&v["custom-slides-muted"]==="false"&&(ge=ge.replace(/\bmuted\b/gi,"").trim()),`<video ${ge.trim()}>`})}if(S.isBackground){const Q=wi(m,u.content);if(Q){r.frontmatter.background=Et(Q,n);return}}const $=ui(u);if($){r.frontmatter.layout=$.layout,r.frontmatter.image=Et($.imageUrl,n),!r.frontmatter.layoutRatio&&$.ratio&&(r.frontmatter.layoutRatio=$.ratio);for(const Q of $.contentNodes)h(Q);return}if(S.imageLayout==="image-left"||S.imageLayout==="image-right"){const Q=wi(m,u.content);if(Q){r.frontmatter.layout=S.imageLayout,r.frontmatter.image=Et(Q,n),!r.frontmatter.layoutRatio&&((j=u.ial)!=null&&j[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const Q of u.children)h(Q);return}const T=!!(S.slot||b!=null&&b.defaultSlot||r.frontmatter.layout==="clover"||Nn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(Q=>{var W,q;return((W=Q.ial)==null?void 0:W[$e])||((q=Q.ial)==null?void 0:q[Ye])})||S.slot||S.clicks||T)){for(const Q of u.children)S.slot&&(!Q.ial||!Q.ial[$e])&&(Q.ial||(Q.ial={}),Q.ial[$e]=S.slot),h(Q,{...b,parentClicks:S.clicks||(b==null?void 0:b.parentClicks),defaultSlot:S.slot||(b==null?void 0:b.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!S.clicks||!!((A=u.children)!=null&&A.some(Q=>{var W;return(W=Q.ial)==null?void 0:W[Ye]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(ji(u)&&u.children&&u.children.length>0&&(T||S.clicks||u.children.some(Q=>{var W;return(W=Q.ial)==null?void 0:W[Ye]}))&&w){const Q=!!(u.children&&u.children.length>=2),W=u.children.find(Se=>!!(Se.markdown||Se.content||"").trim())||u.children[0],q=((D=W==null?void 0:W.ial)==null?void 0:D[Ye])||((O=W==null?void 0:W.ial)==null?void 0:O["custom-slides-click"]),re=!!(!S.clicks&&Q&&q),ae=S.clicks||(re?q:void 0)||(b==null?void 0:b.parentClicks),ce=u.id||(b==null?void 0:b.parentContainerId),ge=S.slot||(b==null?void 0:b.defaultSlot);let Te=!0;for(const Se of u.children){ge&&(!Se.ial||!Se.ial[$e])&&(Se.ial||(Se.ial={}),Se.ial[$e]=ge);const fe=!!(Se.markdown||Se.content||"").trim(),Z=Te&&fe;Z&&(Se.markdown&&(Se.markdown=Mn(Se.markdown)),Se.content&&(Se.content=Mn(Se.content)),Te=!1);let pe=Se;Z&&ae&&Q&&(pe={...Se,ial:{...Se.ial||{}}},delete pe.ial[Ye],delete pe.ial["custom-slides-click"]),h(pe,{parentClicks:ae,parentContainerId:ce,defaultSlot:ge})}return}if(S.isNote){const Q=Ea(m);Q&&(r.notes?r.notes+=`

`+Q:r.notes=Q),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:Q||u.content||"",rawMarkdown:m,isNote:!0,attributes:u.ial});return}S.shikiLines&&(m=Gf(m,S.shikiLines)),C=m.trim();const P=(u.content||"").trim();if(C==="::right::"||P==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const H=qf(u);let K=S.slot,_=S.clicks,F=S.motion,k={...u.ial||{}};if(H!==null){for(;a.length>0&&a[a.length-1].level>=H;)a.pop();const Q=a.length>0?a[a.length-1]:void 0;!K&&(Q!=null&&Q.slot)&&(K=Q.slot),!_&&(Q!=null&&Q.clicks)&&!(b!=null&&b.parentContainerId)&&(_=Q.clicks),!F&&(Q!=null&&Q.motion)&&(F=Q.motion);const W={...(Q==null?void 0:Q.customAttrs)||{}};if(u.ial)for(const[q,re]of Object.entries(u.ial))q.startsWith("custom-slides-")&&!q.startsWith("custom-slides-slide")&&(W[q]=re);b!=null&&b.parentContainerId||a.push({level:H,slot:K,clicks:_,motion:F,customAttrs:W})}else{const Q=a.length>0?a[a.length-1]:void 0;Q&&(!K&&Q.slot&&Q.slot!=="header"&&(K=Q.slot),!_&&Q.clicks&&!(b!=null&&b.parentContainerId)&&(_=Q.clicks),!F&&Q.motion&&(F=Q.motion),Q.customAttrs&&(k={...Q.customAttrs,...k}))}!K&&r.blocks.some(Q=>Q.slot==="slot-divider-right")&&(K="right"),!K&&(b!=null&&b.defaultSlot)&&(K=b.defaultSlot),K&&(k[$e]=K),_&&!k[Ye]&&(k[Ye]=_),F&&!k[qt]&&(k[qt]=JSON.stringify(F)),(x||v["custom-slides-autoplay"]||v["custom-slides-muted"])&&(v["custom-slides-autoplay"]&&(k["custom-slides-autoplay"]=v["custom-slides-autoplay"],v["custom-slides-autoplay"]==="true"&&!v["custom-slides-muted"]&&(k["custom-slides-muted"]="true")),v["custom-slides-loop"]&&(k["custom-slides-loop"]=v["custom-slides-loop"]),v["custom-slides-muted"]&&(k["custom-slides-muted"]=v["custom-slides-muted"]),v["custom-slides-controls"]&&(k["custom-slides-controls"]=v["custom-slides-controls"]));const M={id:u.id,type:u.type,content:u.content||"",rawMarkdown:m,clicks:_,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:F,shikiLines:S.shikiLines,slot:K,attributes:k,rawNode:u};r.blocks.push(M)};h(p)}for(let p=0;p<o.length;p++){const h=o[p],u=[],b={...h.frontmatter};p===0&&(b.theme=s.theme,b.aspectRatio=s.aspectRatio,b.highlighter=s.highlighter,b.transition=h.frontmatter.transition||s.defaultTransition);const m=Vf(b);m&&u.push(m);const v=h.blocks.filter($=>$.slot!=="slot-divider-right"),y=$=>$.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return ss(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),C=$=>{const T=$.filter(H=>!!(H.rawMarkdown||H.content||"").trim());if(T.length===0)return;const w=T[0],P=(w.rawMarkdown||w.content||"").trim();(ji(w)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(w.rawMarkdown=Mn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},S=$=>{var H,K;if($.length===0)return"";C($);const T=(H=$.find(_=>_.parentClicks))==null?void 0:H.parentClicks;if(!T)return $.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var F;return ss(_.rawMarkdown,_.clicks,_.motion,(F=_.attributes)==null?void 0:F.style)}).join(`

`);const w=[];let P=[];const N=()=>{if(P.length===0)return;const _=P.map(F=>(F.rawMarkdown||F.content||"").trim()).filter(Boolean).join(`

`);_&&w.push(Ta(_,T)),P=[]};for(const _ of $){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(N(),w.push(ss(_.rawMarkdown,_.clicks,_.motion,(K=_.attributes)==null?void 0:K.style))):P.push(_)}return N(),w.join(`

`)},x=h.frontmatter.layout||"default";if(x==="clover"||Nn(x)){let $=[];const T=v.filter(_=>_.slot==="header");if(T.length>0)$=T;else if(v.length>0){const _=v.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));_&&($=[_])}const w=v.filter(_=>!$.includes(_));let P=2;if(x==="clover")P=4;else if(x==="three-cols-header")P=3;else if(x==="two-cols-header")P=2;else{let _=0;for(const F of w){const k=(F.slot||"").match(/^col-(\d+)$/i);k&&(_=Math.max(_,parseInt(k[1],10)))}if(_>=2)P=_;else if(h.frontmatter.layoutRatio){const F=h.frontmatter.layoutRatio.trim();if(F.includes(":")){const k=F.split(":").map(M=>parseFloat(M.trim())).filter(M=>!isNaN(M)&&M>0);k.length>=2&&(P=k.length)}else{const k=F.split(/\s+/).filter(Boolean);k.length>=2&&(P=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(P=Math.min(6,w[0].children.length))}const N=Ma(w,P);N.forEach((_,F)=>{const k=`col-${F+1}`;for(const M of _)(!M.slot||M.slot==="default")&&(M.slot=k);C(_)});const H=N.flat();if(w.length===1&&H.length>1){const _=h.blocks.findIndex(F=>F.id===w[0].id);_!==-1&&h.blocks.splice(_,1,...H)}const K=y($);if(K&&u.push(K),x==="two-cols-header"&&P===2){const _=S(N[0]||[]),F=S(N[1]||[]);_&&u.push(`::left::

${_}`),F&&u.push(`::right::

${F}`)}else N.forEach((_,F)=>{const k=S(_);k&&u.push(`::col-${F+1}::

${k}`)})}else if(x==="two-cols"){const $=v.filter(N=>N.slot==="left"),T=v.filter(N=>N.slot==="right");C($),C(T);const w=y($.length>0?$:v.filter(N=>N.slot!=="right")),P=y(T);u.push(w),P&&u.push(`::right::

${P}`)}else for(const $ of v)u.push(ss($.rawMarkdown,$.clicks,$.motion,(d=$.attributes)==null?void 0:d.style));h.notes&&u.push(`<!--
${h.notes}
-->`),h.rawMarkdown=u.join(`

`).trim()}const c=o.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Do=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Yf(e){var s,o,l,r,a,c,d,p,h,u,b,m;if(!e||typeof e!="object")return"";const i=[],t=[];if(Array.isArray(e.styles))for(const v of e.styles){if(!v||!v.id)continue;const y=`--b3-inline-style-${v.id}`;(s=v.light)!=null&&s.color&&i.push(`  ${y}-color: ${v.light.color};`),(o=v.light)!=null&&o.backgroundColor&&i.push(`  ${y}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&t.push(`  ${y}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&t.push(`  ${y}-background-color: ${v.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const v of e.builtin.colors){if(!v||typeof v.index!="number")continue;const y=v.index;(a=v.light)!=null&&a.color&&i.push(`  --b3-font-color${y}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${y}: ${v.light.backgroundColor};`),(d=v.dark)!=null&&d.color&&t.push(`  --b3-font-color${y}: ${v.dark.color};`),(p=v.dark)!=null&&p.backgroundColor&&t.push(`  --b3-font-background${y}: ${v.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const v of e.builtin.styles){if(!v||!v.id)continue;const y=v.id;(h=v.light)!=null&&h.color&&i.push(`  --b3-card-${y}-color: ${v.light.color};`),(u=v.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${y}-background: ${v.light.backgroundColor};`),(b=v.dark)!=null&&b.color&&t.push(`  --b3-card-${y}-color: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&t.push(`  --b3-card-${y}-background: ${v.dark.backgroundColor};`)}if(i.length===0&&t.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),t.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${t.join(`
`)}
}`),n.join(`

`)}function Bn(e){const i=Yf(e);return i?`${Do}

/* Custom Workspace Inline Styles */
${i}`:Do}function ao(e){const i={};if(!e||typeof e!="string")return i;const t=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(t))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";i[o]=l}return i}function Zf(e){const i=String((e==null?void 0:e.type)||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"||i==="l"||i==="nodelist"||i==="i"||i==="nodelistitem"||i==="b"||i==="nodeblockquote"}function Jf(e,i){const t=new Map,n=[];if(!Array.isArray(i)||i.length===0)return{usable:!1,reason:"索引无行",leafPatch:t,rebuildRoots:n};const s=new Map;for(const o of i)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Zf(l)?n.push(o.id):t.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:t,rebuildRoots:n}}function Xf(e){const i=String((e==null?void 0:e.type)||"").toLowerCase();return i==="h"||i==="nodeheading"}function Lo(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Qf(e,i,t,n=8,s){const o=new Map;for(const h of i)h!=null&&h.id&&o.set(h.id,h);const l=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:t(h.id,h.ial),children:[]}),r=h=>{let u=h.parent_id,b=0;for(;u&&u!==e&&b++<16;){const m=o.get(u);if(!m||!Xf(m))return u;u=m.parent_id}return u||e},a=new Map;for(const h of i){if(!(h!=null&&h.id)||h.id===e||s&&s.size>0&&!s.has(h.id))continue;const u=r(h),b=a.get(u);b?b.push(h):a.set(u,[h])}if(s&&s.size>0)for(const h of a.values())h.sort((u,b)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(h,u)=>{const b=l(h);if(c.set(b.id,b),u>=n||!Lo(b))return b;const m=a.get(b.id);return m&&m.length>0&&(b.children=m.map(v=>d(v,u+1))),b};return{topLevel:(a.get(e)||[]).map(h=>d(h,0)),byId:c}}const ep={getBlockAttrs:zo,getChildBlocks:vs,getDocBlocksOrders:Qc,setBlockAttrs:je,sql:rn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ed};class tp{constructor(i){ke(this,"deps");ke(this,"attrOverrides",new Map);ke(this,"trackedListSuperBlocks",new Map);ke(this,"fallbackWarnedDocId","");this.deps={...ep,...i||{}}}setBlockAttrOverride(i,t){if(!i||!t)return;const s={...this.attrOverrides.get(i)||{}};for(const[o,l]of Object.entries(t))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,s)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,t){if(!i)return;if(!t){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[t],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const t=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(t,n);const s=await this.deps.getChildBlocks(i).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(i).catch(()=>[])||[]:[],l=new Map;for(let M=0;M<o.length;M++)o[M]&&l.set(o[M],M);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Jf(s,c),p=new Map;if(Array.isArray(c))for(const M of c)M.id&&M.ial&&p.set(M.id,ao(M.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(u)){for(const M of u)if(M.block_id&&M.name){let j=p.get(M.block_id);j||(j={},p.set(M.block_id,j)),j[M.name]=M.value||""}}const b=(M,j)=>{const A={...p.get(M)||(j?ao(j):{})},D=this.attrOverrides.get(M);return D&&Object.assign(A,D),A},m=Array.isArray(c)&&c.length>0?Qf(i,c,b,8,l):null,v=s.map(M=>M.id).filter(Boolean),y=M=>({id:M.id,parent_id:M.parent_id,root_id:M.root_id||i,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:b(M.id,M.ial),children:M.children}),C=async(M,j=0)=>{if(!M||j>8||!Lo(M))return;const A=await this.deps.getChildBlocks(M.id).catch(()=>[])||[];if(!(!Array.isArray(A)||A.length===0)){M.children=A.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:M.id,root_id:i,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:b(D.id,D.ial),children:[]}));for(const D of M.children)await C(D,j+1)}},S=new Map;for(const M of c)M!=null&&M.id&&S.set(M.id,M);const x=v.every(M=>{const j=S.get(M);return!j||!!j.type});let $=[],T=!1;if(m&&d.usable&&r&&x){this.fallbackWarnedDocId="";for(const[j,A]of d.leafPatch){const D=m.byId.get(j);D&&(D.content=A.content,D.markdown=A.markdown)}const M=new Map;for(const j of s)j!=null&&j.id&&M.set(j.id,j);for(const j of d.rebuildRoots){const A=m.byId.get(j),D=M.get(j);A&&D&&(A.content=D.content||"",A.markdown=D.markdown||""),await C(A)}for(const j of s){if(!(j!=null&&j.id)||m.byId.has(j.id))continue;const A=y(j);await C(A),m.byId.set(A.id,A),m.topLevel.push(A)}$=m.topLevel.filter(j=>l.has(j.id)).sort((j,A)=>(l.get(j.id)??0)-(l.get(A.id)??0))}else v.length>0?(T=!0,this.fallbackWarnedDocId!==i&&(this.fallbackWarnedDocId=i,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${i} 实时顶层=${v.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),$=s.map(M=>y(M))):m&&($=m.topLevel);const w=async(M,j=0)=>{if(!(!M||M.length===0||j>8))for(const A of M){if(Lo(A)&&(!A.children||A.children.length===0)){let O=await this.deps.getChildBlocks(A.id).catch(()=>[]);if(!O||O.length===0){const Q=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${A.id}' ORDER BY sort ASC, created ASC`;O=await this.deps.sql(Q).catch(()=>[])||[]}if(Array.isArray(O)&&O.length>0){const Q=new Set($.map(q=>q.id)),W=O.filter(q=>q.id!==A.id&&!Q.has(q.id));W.length>0&&(A.children=W.map(q=>{const re=p.get(q.id)||(q.ial?ao(q.ial):{}),ae=this.attrOverrides.get(q.id);return ae&&Object.assign(re,ae),{id:q.id,parent_id:q.parent_id||A.id,root_id:q.root_id||i,type:q.type,subType:q.subType,content:q.content||"",markdown:q.markdown||"",ial:re}}))}}A.children&&A.children.length>0&&await w(A.children,j+1)}};T&&await w($);const P=M=>{var j,A;for(const D of M)if(D.children&&D.children.length>0){P(D.children);for(const O of D.children)if(O.ial)for(const[Q,W]of Object.entries(O.ial))Q.startsWith("custom-slides-")&&!((j=D.ial)!=null&&j[Q])&&(D.ial||(D.ial={}),D.ial[Q]=W);if(D.ial){for(const[O,Q]of Object.entries(D.ial))if(O.startsWith("custom-slides-"))for(const W of D.children)(W.type==="video"||W.type==="NodeVideo"||/<video\b/i.test(W.markdown||W.content||""))&&!((A=W.ial)!=null&&A[O])&&(W.ial||(W.ial={}),W.ial[O]=Q)}}};P($),jf($,M=>{const j={[we]:M.layout};this.setBlockAttrOverride(M.blockId,j),(this.deps.setBlockAttrs||je)(M.blockId,j).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const N=this.trackedListSuperBlocks.get(i)||[],H=Ff(i,$,{tracked:N,onTagChange:M=>{this.setBlockAttrOverride(M.blockId,M.attrs),M.blockId===i&&Object.assign(t,M.attrs);const j=D=>{for(const O of D)O.id===M.blockId&&(O.ial||(O.ial={}),Object.assign(O.ial,M.attrs)),O.children&&O.children.length>0&&j(O.children)};j($),(this.deps.setBlockAttrs||je)(M.blockId,M.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(i,H.newTracked);const K=new Set;for(const M of $){const j=M.markdown||M.content||"";if(j.includes("((")){const A=td(j);for(const D of A)K.add(D.blockId)}}const _={};if(K.size>0){const M=Array.from(K).map(A=>`'${A}'`).join(","),j=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${M})`).catch(()=>[])||[];if(Array.isArray(j))for(const A of j)A.id&&(_[A.id]=A.markdown||A.content||"")}const F=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=Jr(i,t,$,{baseUrl:F,refContentMap:_});try{const M=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=Bn(M)}catch{k.customThemeCss=Bn(null)}return k}catch(t){console.error("[DocumentCompilerService] Failed to compile document:",t);const n=Jr(i,{},[],{});return n.customThemeCss=Bn(null),n}}}const Pe=new tp;class lr{constructor(i){ke(this,"devServerUrl","http://localhost:3030");ke(this,"isConnected",!1);ke(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const t=new AbortController,n=setTimeout(()=>t.abort(),i),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:t.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const t=i.config,n=["---",`theme: ${t.theme||"default"}`,`aspectRatio: "${t.aspectRatio||"16/9"}"`,`highlighter: ${t.highlighter||"shiki"}`,`transition: ${t.defaultTransition||"slide-left"}`];t.colorSchema&&t.colorSchema!=="auto"&&n.push(`colorSchema: ${t.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=i.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let h="";d.length>0?h=p?"":`---
${d.join(`
`)}
---

`:p||(h=`---

`);let u="";if(c.layout==="two-cols"){const m=r.blocks.filter(S=>S.slot!=="right"),v=r.blocks.filter(S=>S.slot==="right"),y=m.map(S=>S.rawMarkdown||S.content||"").join(`

`),C=v.map(S=>S.rawMarkdown||S.content||"").join(`

`);u=`${y}

::right::

${C}`}else u=r.blocks.map(m=>m.rawMarkdown||m.content||"").join(`

`);let b="";return r.notes&&r.notes.trim()&&(b=`

<!--
${r.notes.trim()}
-->`),`${h}${u}${b}`}).join(`

`);let l="";return i.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(i,t="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(t,!1,o),{success:!0,path:t}}catch(o){return{success:!1,path:t,error:String(o)}}return{success:!0,path:t}}downloadSlidesMd(i,t="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=t,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}function ip(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function _t(e){const i=ip();if(i)try{return i(e)}catch{try{const t=e.startsWith("node:")?e.slice(5):`node:${e}`;return i(t)}catch{}}}function ar(){var i;if(typeof window<"u"&&window.process)return window.process;const e=_t("process");return e&&e.versions?e:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Aa(){var i,t;const e=ar();if(e&&((i=e.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=_t("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((t=process.versions)!=null&&t.node))}function np(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Vn(){const e=ar();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=_t("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const t=navigator.userAgent.toLowerCase();if(t.includes("win"))return"win32";if(t.includes("mac"))return"darwin";if(t.includes("linux"))return"linux"}return"web"}function Ba(){var n,s;const e=ar(),i={...(e==null?void 0:e.env)||{}};if(Vn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Po(e){var t,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((s=(n=(t=window.siyuan)==null?void 0:t.config)==null?void 0:n.system)!=null&&s.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&e.startsWith("/data/")){const o=e.slice(6);return`${i}/${o}`.replace(/\\/g,"/")}return e}function sp(){const e=_t("os"),i=_t("path");if(e&&typeof e.tmpdir=="function"){const t=e.tmpdir();return i&&typeof i.join=="function"?i.join(t,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${t}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class cr{constructor(i){ke(this,"runner");this.runner=i||cr.defaultRunner}static async defaultRunner(i,t){var n;try{let s=(n=_t("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Vn()==="win32",r=Ba();return await new Promise(a=>{s(i,t,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const i=Aa(),t=Vn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=t==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=t==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:t,isDesktop:i}}}class op{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pageChangedHandlers",[]);ke(this,"readyHandlers",[]);ke(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,t){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...t};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(t=>t!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(t=>t!==i)}}handleWindowMessage(i){const t=i.data;if(!(!t||t.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(t.type==="update-state"&&t.navState){const n=t.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(t.type==="navigate"&&typeof t.no=="number"){this.currentState.no=t.no;for(const n of this.pageChangedHandlers)n(t.no,this.currentState.total||1,this.currentState)}}}}class rp{constructor(i){ke(this,"childProcess",null);ke(this,"activePort",null);ke(this,"isRunning",!1);ke(this,"defaultPort");ke(this,"maxPortRetries");ke(this,"probeTimeoutMs");ke(this,"customSpawner");ke(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let t=_t("net");return t||(t=await import("node:net").catch(()=>({}))),t!=null&&t.createServer?await new Promise(n=>{const s=t.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const t=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=t+n;if(await this.isPortAvailable(s))return s}return t}async pollServerReady(i,t=8e3,n=300){const s=Date.now();for(;Date.now()-s<t;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(i,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(i,t){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(t);this.activePort=n;const o=Vn()==="win32"?"npx.cmd":"npx",l=Po(i),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let p=(a=_t("child_process"))==null?void 0:a.spawn;if(!p){const b=await import("node:child_process").catch(()=>({}));p=b==null?void 0:b.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const h=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ba();this.childProcess=p(o,r,{cwd:h,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Vn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=_t("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Yn{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pendingMessages",[]);ke(this,"slideChangedHandlers",[]);ke(this,"blockClickedHandlers",[]);ke(this,"openInEditorHandlers",[]);ke(this,"clientReadyHandlers",[]);ke(this,"openPeekDrawerHandlers",[]);ke(this,"toggleFullscreenHandlers",[]);ke(this,"openPresenterHandlers",[]);ke(this,"captureProgressHandlers",[]);ke(this,"capturePageDoneHandlers",[]);ke(this,"captureCompleteHandlers",[]);ke(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,t){var s;const n={source:"siyuan-slides-host",action:i,payload:t};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(i,t,n,s){this.postMessage("UPDATE_SLIDES",{slides:i,config:t,fullMarkdown:n,customThemeCss:s})}navigatePage(i,t){const n={pageIndex:i};typeof t=="number"&&(n.step=t),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(i){this.postMessage("START_IMAGE_EXPORT",{captureOptions:i})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(i){return this.captureProgressHandlers.push(i),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(t=>t!==i)}}onCapturePageDone(i){return this.capturePageDoneHandlers.push(i),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(t=>t!==i)}}onCaptureComplete(i){return this.captureCompleteHandlers.push(i),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(t=>t!==i)}}onCaptureError(i){return this.captureErrorHandlers.push(i),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(t=>t!==i)}}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(t=>t!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(t=>t!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(t=>t!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(t=>t!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(t=>t!==i)}}onOpenPresenter(i){return this.openPresenterHandlers.push(i),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(t=>t!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(t=>t!==i)}}handleWindowMessage(i){var n,s;const t=i.data;if(!(!t||t.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&i.source&&i.source!==this.iframe.contentWindow))switch(t.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(t.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)t.payload.currentStep!==void 0||t.payload.maxStep!==void 0?o(t.payload.currentPage,t.payload.totalPages||1,t.payload.currentBlockId||"",t.payload.currentStep,t.payload.maxStep):o(t.payload.currentPage,t.payload.totalPages||1,t.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(t.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(t.payload.clickedBlockId,t.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(t.payload.blockId||t.payload.clickedBlockId){const o=t.payload.blockId||t.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(o,t.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(t.payload.peekType){const o=t.payload.blockId||t.payload.url||"",l={peekType:t.payload.peekType,target:o,title:t.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(t.payload.captureProgress)for(const o of this.captureProgressHandlers)o(t.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(t.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(t.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:t.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(t.payload.captureError||"未知沙箱截图异常");break}}}const Da={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},lp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,ap=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,cp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,dp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,up=`${Do}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function fp(e){var s;const i=[],t=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=t.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!i.includes(o)&&i.push(o)}return i}class pp{constructor(i){ke(this,"workspacePath");ke(this,"slidesFileName");ke(this,"cliBridge",new lr);const t=sp();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=t:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const t={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(t.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(t,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,t){const n=this.buildSlidesMarkdown(i),s=this.generatePackageJson(i.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Po(o),a=Po(l),c=fp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const S of c){const x=Da[S]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${S}
// #endregion snippet
`;d.set(S,x)}i.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",lp),i.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",ap),i.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="clover"})&&d.set("layouts/clover.vue",cp),d.set("setup/root.ts",dp),d.set("styles/index.css",up);const b=_t("fs"),m=_t("path");let v=!1;const y=m!=null&&m.dirname?m.dirname(r):"",C=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(b&&m&&C)try{b.existsSync(y)||b.mkdirSync(y,{recursive:!0}),b.writeFileSync(a,s,"utf-8"),b.writeFileSync(r,n,"utf-8");for(const[S,x]of d.entries()){const $=m.join(y,S),T=m.dirname($);b.existsSync(T)||b.mkdirSync(T,{recursive:!0}),b.existsSync($)||b.writeFileSync($,x,"utf-8")}v=!0}catch{}if(!v&&t)try{const S=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),x=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await t(l,!1,x),await t(o,!1,S);for(const[$,T]of d.entries()){const w=`${this.workspacePath}/${$}`,P=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await t(w,!1,P).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch(S){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String(S)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class hp{constructor(){ke(this,"mode","web-sandbox");ke(this,"webBridge");ke(this,"cliBridge");ke(this,"nativeBridge");ke(this,"processManager");ke(this,"scaffolder");ke(this,"envDetector");this.webBridge=new Yn,this.cliBridge=new lr,this.nativeBridge=new op,this.processManager=new rp,this.scaffolder=new pp,this.envDetector=new cr}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,t){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(i,t);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const mp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},gp={key:0},vp={key:1},bp={key:2},yp={key:3},kp={key:4},wp={key:5},xp={key:6},Sp={key:7},Cp={key:8},_p={key:9},$p={key:10},Ip={key:11},Tp={key:12},Ep={key:13},Mp={key:14},Ap={key:15},Bp={key:16},Dp={key:17},Lp={key:18},Pp={key:19},Rp={key:20},Op={key:21},Np={key:22},zp={key:23},Hp={key:24},Fp={key:25},jp={key:26},Wp={key:27},Up={key:28},Vp={key:29},Gp={key:30},Kp={key:31},qp={key:32},Yp={key:33},Zp={key:34},Jp={key:35},Xp={key:36},Qp={key:37},eh={key:38},th={key:39},ih={key:40},nh={key:41},sh={key:42},oh={key:43},rh={key:44},lh={key:45},ah={key:46},ch={key:47},dh={key:48},uh={key:49},fh={key:50},ph={key:51},hh={key:52},mh={key:53},gh={key:54},vh={key:55},bh={key:56},yh={key:57},kh={key:58},wh={key:59},xh={key:60},Sh={key:61},Ch={key:62},_h={key:63},$h={key:64},Ih={key:65},Th={key:66},Eh={key:67},Mh={key:68},Ah={key:69},Bh={key:70},Dh={key:71},Lh=Tt({__name:"SlidesIcon",props:{name:{}},setup(e){return(i,t)=>(ee(),te("svg",mp,[e.name==="fullscreen"||e.name==="maximize"?(ee(),te("g",gp,[...t[0]||(t[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(ee(),te("g",vp,[...t[1]||(t[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(ee(),te("g",bp,[...t[2]||(t[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(ee(),te("g",yp,[...t[3]||(t[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(ee(),te("g",kp,[...t[4]||(t[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(ee(),te("g",wp,[...t[5]||(t[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(ee(),te("g",xp,[...t[6]||(t[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(ee(),te("g",Sp,[...t[7]||(t[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(ee(),te("g",Cp,[...t[8]||(t[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(ee(),te("g",_p,[...t[9]||(t[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(ee(),te("g",$p,[...t[10]||(t[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(ee(),te("g",Ip,[...t[11]||(t[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(ee(),te("g",Tp,[...t[12]||(t[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(ee(),te("g",Ep,[...t[13]||(t[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(ee(),te("g",Mp,[...t[14]||(t[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(ee(),te("g",Ap,[...t[15]||(t[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(ee(),te("g",Bp,[...t[16]||(t[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(ee(),te("g",Dp,[...t[17]||(t[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(ee(),te("g",Lp,[...t[18]||(t[18]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(ee(),te("g",Pp,[...t[19]||(t[19]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(ee(),te("g",Rp,[...t[20]||(t[20]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(ee(),te("g",Op,[...t[21]||(t[21]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(ee(),te("g",Np,[...t[22]||(t[22]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(ee(),te("g",zp,[...t[23]||(t[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-e1c698ec></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-e1c698ec></path>',5)])])):e.name==="ratio"?(ee(),te("g",Hp,[...t[24]||(t[24]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(ee(),te("g",Fp,[...t[25]||(t[25]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(ee(),te("g",jp,[...t[26]||(t[26]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(ee(),te("g",Wp,[...t[27]||(t[27]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(ee(),te("g",Up,[...t[28]||(t[28]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(ee(),te("g",Vp,[...t[29]||(t[29]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(ee(),te("g",Gp,[...t[30]||(t[30]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(ee(),te("g",Kp,[...t[31]||(t[31]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(ee(),te("g",qp,[...t[32]||(t[32]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(ee(),te("g",Yp,[...t[33]||(t[33]=[f("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(ee(),te("g",Zp,[...t[34]||(t[34]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(ee(),te("g",Jp,[...t[35]||(t[35]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(ee(),te("g",Xp,[...t[36]||(t[36]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(ee(),te("g",Qp,[...t[37]||(t[37]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(ee(),te("g",eh,[...t[38]||(t[38]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(ee(),te("g",th,[...t[39]||(t[39]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(ee(),te("g",ih,[...t[40]||(t[40]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(ee(),te("g",nh,[...t[41]||(t[41]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(ee(),te("g",sh,[...t[42]||(t[42]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(ee(),te("g",oh,[...t[43]||(t[43]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-e1c698ec></path><polyline points="14 2 14 8 20 8" data-v-e1c698ec></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-e1c698ec></line><line x1="16" y1="17" x2="8" y2="17" data-v-e1c698ec></line><line x1="10" y1="9" x2="8" y2="9" data-v-e1c698ec></line>',5)])])):e.name==="focus"||e.name==="target"?(ee(),te("g",rh,[...t[44]||(t[44]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(ee(),te("g",lh,[...t[45]||(t[45]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(ee(),te("g",ah,[...t[46]||(t[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-e1c698ec></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-e1c698ec></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-e1c698ec></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-e1c698ec></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(ee(),te("g",ch,[...t[47]||(t[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-e1c698ec></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-e1c698ec></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-e1c698ec></line><line x1="5" y1="15" x2="8" y2="15" data-v-e1c698ec></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-e1c698ec></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-e1c698ec></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-e1c698ec></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(ee(),te("g",dh,[...t[48]||(t[48]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-e1c698ec></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-e1c698ec></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-e1c698ec></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-e1c698ec></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-e1c698ec></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(ee(),te("g",uh,[...t[49]||(t[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-e1c698ec></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-e1c698ec></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-e1c698ec></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-e1c698ec></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-e1c698ec></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-e1c698ec></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-e1c698ec></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(ee(),te("g",fh,[...t[50]||(t[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="5" y1="7" x2="13" y2="7" data-v-e1c698ec></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-e1c698ec></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-e1c698ec></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-e1c698ec></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-e1c698ec></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-e1c698ec></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(ee(),te("g",ph,[...t[51]||(t[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" data-v-e1c698ec></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-e1c698ec></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-e1c698ec></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-e1c698ec></line><circle cx="15.5" cy="8.5" r="1.2" data-v-e1c698ec></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-e1c698ec></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(ee(),te("g",hh,[...t[52]||(t[52]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><line x1="12" y1="4" x2="12" y2="20" data-v-e1c698ec></line><circle cx="6" cy="8.5" r="1.2" data-v-e1c698ec></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-e1c698ec></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-e1c698ec></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-e1c698ec></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-e1c698ec></line>',7)])])):e.name==="layout-center"||e.name==="center"?(ee(),te("g",mh,[...t[53]||(t[53]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(ee(),te("g",gh,[...t[54]||(t[54]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><circle cx="8" cy="9" r="1.5" data-v-e1c698ec></circle><line x1="14" y1="8" x2="9" y2="14" data-v-e1c698ec></line><circle cx="15" cy="13" r="1.5" data-v-e1c698ec></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-e1c698ec></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(ee(),te("g",vh,[...t[55]||(t[55]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><circle cx="7.5" cy="9.5" r="2" data-v-e1c698ec></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-e1c698ec></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-e1c698ec></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-e1c698ec></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-e1c698ec></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(ee(),te("g",bh,[...t[56]||(t[56]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-e1c698ec></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-e1c698ec></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-e1c698ec></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-e1c698ec></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(ee(),te("g",yh,[...t[57]||(t[57]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(ee(),te("g",kh,[...t[58]||(t[58]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(ee(),te("g",wh,[...t[59]||(t[59]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(ee(),te("g",xh,[...t[60]||(t[60]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(ee(),te("g",Sh,[...t[61]||(t[61]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(ee(),te("g",Ch,[...t[62]||(t[62]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(ee(),te("g",_h,[...t[63]||(t[63]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-e1c698ec></line><line x1="4" y1="10" x2="4" y2="3" data-v-e1c698ec></line><line x1="12" y1="21" x2="12" y2="12" data-v-e1c698ec></line><line x1="12" y1="8" x2="12" y2="3" data-v-e1c698ec></line><line x1="20" y1="21" x2="20" y2="16" data-v-e1c698ec></line><line x1="20" y1="12" x2="20" y2="3" data-v-e1c698ec></line><line x1="1" y1="14" x2="7" y2="14" data-v-e1c698ec></line><line x1="9" y1="8" x2="15" y2="8" data-v-e1c698ec></line><line x1="17" y1="16" x2="23" y2="16" data-v-e1c698ec></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(ee(),te("g",$h,[...t[64]||(t[64]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(ee(),te("g",Ih,[...t[65]||(t[65]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(ee(),te("g",Th,[...t[66]||(t[66]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(ee(),te("g",Eh,[...t[67]||(t[67]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(ee(),te("g",Mh,[...t[68]||(t[68]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-e1c698ec></rect><line x1="13" y1="8" x2="19" y2="8" data-v-e1c698ec></line><line x1="13" y1="12" x2="19" y2="12" data-v-e1c698ec></line><line x1="13" y1="16" x2="17" y2="16" data-v-e1c698ec></line>',5)])])):e.name==="image-right"?(ee(),te("g",Ah,[...t[69]||(t[69]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-e1c698ec></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-e1c698ec></rect><line x1="5" y1="8" x2="11" y2="8" data-v-e1c698ec></line><line x1="5" y1="12" x2="11" y2="12" data-v-e1c698ec></line><line x1="5" y1="16" x2="9" y2="16" data-v-e1c698ec></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(ee(),te("g",Bh,[...t[70]||(t[70]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(ee(),te("g",Dh,[...t[71]||(t[71]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Jt=(e,i)=>{const t=e.__vccOpts||e;for(const[n,s]of i)t[n]=s;return t},de=Jt(Lh,[["__scopeId","data-v-e1c698ec"]]),Ph={class:"spm-immersion-header"},Rh={class:"spm-immersion-header__left"},Oh={class:"spm-immersion-title"},Nh={class:"spm-immersion-header__center"},zh={class:"spm-immersion-header__actions"},Hh=["aria-label"],Fh={class:"spm-immersion-body"},jh=Tt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:i}){const t=e,n=i;function s(){n("update:visible",!1),n("close")}function o(){t.closeOnClickMask&&s()}function l(){n("update:isMaximized",!t.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Bt((ee(),te("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Gt(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:o}),f("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",Ph,[f("div",Rh,[is(a.$slots,"header-left",{},()=>[f("span",Oh,xe(e.title),1)])]),f("div",Nh,[is(a.$slots,"header-center",{},void 0)]),f("div",zh,[is(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Hh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[le(de,{name:"close"})])])]),f("div",Fh,[is(a.$slots,"default",{},void 0)])],2)],34)),[[Mo,e.visible]])}}),Wh=Jt(jh,[["__scopeId","data-v-1359fecb"]]),Uh={class:"spm-protyle-drawer"},Vh={class:"spm-protyle-drawer__subbar"},Gh={class:"spm-protyle-drawer__nav"},Kh=["title"],qh={class:"spm-protyle-drawer__actions"},Yh=["aria-label"],Zh=["aria-label"],Jh=Tt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:i}){const t=i,n=e,s=me(n.blockId),o=me(n.title||""),l=me(!1),r=me(!0),a=me(!1),c=me(""),d=vi,p=me([]),h=me(null);let u=null;Ni(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",p.value=[],m(w))}),pn(()=>{s.value&&m(s.value)}),Qo(()=>{v()});async function b(w){try{const P=await rn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(P)&&P.length>0){const N=P[0];c.value=N.root_id||"";const H=N.id===N.root_id||N.type==="d";a.value=H,r.value=!H,!o.value&&N.content&&(o.value=N.content.trim().slice(0,30));return}}catch(P){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",P)}a.value=!1,r.value=!0}async function m(w,P){if(!h.value||!w)return;v(),await b(w),typeof P=="boolean"&&(r.value=!a.value&&P);let N,H;r.value&&!a.value?(N=["cb-get-all","cb-get-hl","cb-get-focus"],H={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(N=["cb-get-context","cb-get-hl"],H={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new ue.Protyle(n.plugin.app,h.value,{blockId:w,action:N,render:H}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function v(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}h.value&&(h.value.innerHTML="")}function y(){a.value||(r.value=!r.value,m(s.value,r.value))}function C(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(s.value)try{ue.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function x(){var N;if(!s.value)return;const w=Gs(),P=Ca(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const H=_t("electron");(N=H==null?void 0:H.shell)!=null&&N.openExternal?H.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}t("external-jump",P)}function $(){if(p.value.length>0){const w=p.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,m(w.blockId,w.isFocusMode))}}function T(w){const P=w.target;if(!P)return;const N=P.closest('[data-type="block-ref"]');if(N){const K=N.getAttribute("data-id");if(K&&K!==s.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=K,o.value=N.innerText.trim()||K,m(K);return}}const H=P.closest("a");if(H&&H.href&&H.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const K=H.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==s.value&&(p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=K,o.value=H.innerText.trim()||K,m(K))}}return(w,P)=>(ee(),te("div",Uh,[f("div",Vh,[f("div",Gh,[p.value.length>0?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:$},[le(de,{name:"arrow-left"}),P[0]||(P[0]=f("span",null,"返回",-1))])):Le("",!0),f("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xe(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:o.value||s.value},xe(o.value||s.value),9,Kh)]),f("div",qh,[a.value?Le("",!0):(ee(),te("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[le(de,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,xe(r.value?"块聚焦":"展开全文"),1)],10,Yh)),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:C},[le(de,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,xe(l.value?"编辑中":"只读"),1)],10,Zh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[le(de,{name:"window"}),P[1]||(P[1]=f("span",null,"独立窗口",-1))]),ve(d).enableWebServeJump?(ee(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:x},[le(de,{name:"external-link"}),P[2]||(P[2]=f("span",null,"外跳",-1))])):Le("",!0)])]),f("div",{ref_key:"mountEl",ref:h,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),Xh=Jt(Jh,[["__scopeId","data-v-0d6e2df3"]]),Qh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,em=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Xr(e){let i=e||"";try{i=decodeURIComponent(i)}catch{}i=i.replace(/\\/g,"/");const t=/(?:^|\/)data\/assets\/(.+)$/i.exec(i);if(t)return`/assets/${t[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(i);return n?`/plugins/${n[1]}`:null}function La(e){const i=(e||"").replace(/^file:\/\//i,"");let t=i;try{t=decodeURIComponent(i)}catch{}if(t.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(t)?t.slice(1):t;const n=t.indexOf("/");return n>=0?t.slice(n):t}function tm(e){const i=e.split(/[/?#]/)[0];return!i||em.test(i)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(i)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(i)}function im(e){const i=e.indexOf("#"),t=i>=0?e.slice(i):"",n=i>=0?e.slice(0,i):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${t}`)}function Pa(e){const i=nm(e);return i.external||!i.url?i:{url:im(i.url),external:!1}}function nm(e){const i=(e||"").trim();if(!i)return{url:"",external:!1};if(/^https?:\/\//i.test(i))return{url:i,external:!1};if(i.startsWith("//"))return{url:`https:${i}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(i))return{url:i,external:!1};if(vl(i))return{url:`/${bl(i)}`,external:!1};if(/^file:/i.test(i)){const n=Xr(La(i));return n?{url:n,external:!1}:{url:i,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(i)||i.startsWith("\\\\")){const n=Xr(i);return n?{url:n,external:!1}:{url:i,external:!0}}return Qh.test(i)?{url:i,external:!0}:tm(i)?{url:`https://${i}`,external:!1}:{url:`/${i.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const sm={class:"spm-webview-drawer"},om={class:"spm-webview-toolbar"},rm={class:"spm-webview-toolbar__nav"},lm=["disabled"],am=["disabled"],cm=["aria-label"],dm={class:"spm-webview-toolbar__address"},um=["aria-label"],fm={class:"spm-webview-toolbar__actions"},pm=["aria-label"],hm={class:"spm-zoom-controller"},mm=["disabled"],gm=["disabled"],vm={key:1,class:"spm-webview-fallback"},bm=["src"],ym={key:2,class:"spm-load-error"},km={class:"spm-load-error__code"},wm={class:"spm-load-error__code-num"},xm={class:"spm-load-error__url"},Sm={class:"spm-load-error__hint"},Cm={class:"spm-load-error__actions"},Qr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Ra="siyuan-slides-peek-view-mode";let Oa="desktop";function _m(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Ra);if(e==="mobile"||e==="desktop")return e}catch{}return Oa}function $m(e){if(Oa=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Ra,e)}catch{}}function Im(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Tm=Tt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:i}){const t=i,n=e,s=me(Aa()&&!np()),o=me(n.url),l=me(n.url),r=n.url,a=me(!1),c=me(null),d=me(!1),p=me(!1),h=me(1),u=me(!1),b=me(_m());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const v=ye(()=>b.value==="mobile"?Qr:m||void 0),y=me(null),C=me(null);let S=null,x=null,$=null;Ni(()=>n.url,Z=>{Z&&Z!==o.value&&(o.value=Z,l.value=Z,b.value==="mobile"&&H(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z))}),Ni(()=>n.visible,Z=>{if(Z)re(),b.value==="mobile"&&H(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),pn(()=>{T(),C.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const Z=y.value;if(Z&&typeof Z.invalidate=="function")try{Z.invalidate()}catch{}}),S.observe(C.value)),x=Z=>{var L;const pe=Z.message||((L=Z.error)==null?void 0:L.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return Z.preventDefault(),Z.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),$=Z=>{const pe=Z.reason,L=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&Z.preventDefault()},window.addEventListener("unhandledrejection",$)}),Qo(()=>{if(w(),S&&(S.disconnect(),S=null),x&&(window.removeEventListener("error",x,!0),x=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function T(){const Z=y.value;Z&&(Z.addEventListener("dom-ready",P),Z.addEventListener("did-start-loading",K),Z.addEventListener("did-stop-loading",k),Z.addEventListener("did-navigate",M),Z.addEventListener("did-navigate-in-page",j),Z.addEventListener("new-window",A),Z.addEventListener("did-fail-load",_),Z.addEventListener("did-fail-provisional-load",_))}function w(){const Z=y.value;if(Z)try{Z.removeEventListener("dom-ready",P),Z.removeEventListener("did-start-loading",K),Z.removeEventListener("did-stop-loading",k),Z.removeEventListener("did-navigate",M),Z.removeEventListener("did-navigate-in-page",j),Z.removeEventListener("new-window",A),Z.removeEventListener("did-fail-load",_),Z.removeEventListener("did-fail-provisional-load",_)}catch{}}function P(){const Z=y.value;if(Z&&typeof Z.getUserAgent=="function"&&!m)try{const pe=Z.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}b.value==="mobile"&&H(!1),re(),D()}function N(){const Z=b.value==="mobile"?"desktop":"mobile";b.value=Z,$m(Z),H(!0)}function H(Z=!1){const pe=y.value;if(!pe)return;const L=b.value==="mobile"?Qr:m;if(typeof pe.setUserAgent=="function"&&L)try{pe.setUserAgent(L)}catch(V){console.warn("[WebviewPeekDrawer] setUserAgent error:",V)}if(Z&&typeof pe.reload=="function")try{pe.reload()}catch(V){console.warn("[WebviewPeekDrawer] reload error:",V)}}function K(){a.value=!0,c.value=null}function _(Z){if(Z&&Z.isMainFrame===!1||Z&&Number(Z.errorCode)===-3)return;const pe=String((Z==null?void 0:Z.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Z==null?void 0:Z.errorCode)??0),description:pe,validatedURL:String((Z==null?void 0:Z.validatedURL)||o.value),hint:Im(pe)},a.value=!1}function F(){c.value=null,W()}function k(){if(a.value=!1,D(),y.value&&typeof y.value.getURL=="function"){const Z=y.value.getURL();Z&&Z!=="about:blank"&&(o.value=Z,l.value=Z)}}function M(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),D()}function j(Z){Z!=null&&Z.url&&(o.value=Z.url,l.value=Z.url),D()}function A(Z){Z&&Z.url&&(Z.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url))}function D(){const Z=y.value;Z&&(typeof Z.canGoBack=="function"&&(d.value=Z.canGoBack()),typeof Z.canGoForward=="function"&&(p.value=Z.canGoForward()))}function O(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function Q(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function W(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function q(){const Z=Pa(l.value);if(Z.url){if(Z.external){o.value=Z.url,fe();return}o.value=Z.url,l.value=Z.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Z.url)}}function re(){const Z=y.value;if(Z&&typeof Z.setZoomFactor=="function")try{Z.setZoomFactor(h.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ae(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),re()}function ce(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),re()}function ge(){h.value=1,re()}function Te(Z){Z.preventDefault(),Z.deltaY<0?ae():Z.deltaY>0&&ce()}async function Se(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Z){console.warn("Copy url failed:",Z)}}function fe(){var pe;const Z=o.value;if(typeof window<"u"){const L=_t("electron");(pe=L==null?void 0:L.shell)!=null&&pe.openExternal?L.shell.openExternal(Z).catch(()=>{window.open(Z,"_blank")}):window.open(Z,"_blank")}t("external-jump",Z)}return(Z,pe)=>{const L=fu("webview");return ee(),te("div",sm,[f("div",om,[f("div",rm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:O},[le(de,{name:"arrow-left"})],8,lm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:Q},[le(de,{name:"arrow-right"})],8,am),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:W},[le(de,{name:"refresh"})],8,cm)]),f("div",dm,[Bt(f("input",{"onUpdate:modelValue":pe[0]||(pe[0]=V=>l.value=V),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Tf(q,["enter"])},null,544),[[Ao,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:Se},[le(de,{name:"copy"})],8,um)]),f("div",fm,[f("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:N},[le(de,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,pm),f("div",hm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:ce},[le(de,{name:"minus"})],8,mm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ge},xe(Math.round(h.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:ae},[le(de,{name:"plus"})],8,gm)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[le(de,{name:"external-link"}),pe[1]||(pe[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:C,class:Ce(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:Gt(Te,["ctrl"])},[f("div",{class:Ce(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[s.value?(ee(),Kt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:ve(r),useragent:v.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ee(),te("div",vm,[f("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,bm),f("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(ee(),te("div",ym,[le(de,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",km,[St(xe(c.value.description)+" ",1),f("span",wm,"("+xe(c.value.errorCode)+")",1)]),f("div",xm,xe(c.value.validatedURL),1),f("p",Sm,xe(c.value.hint),1),f("div",Cm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:F},[le(de,{name:"refresh"}),pe[3]||(pe[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[le(de,{name:"external-link"}),pe[4]||(pe[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Le("",!0)],2)],34)])}}}),Em=Jt(Tm,[["__scopeId","data-v-6e363f73"]]);class Mm{constructor(){ke(this,"timers",new Map)}debounce(i,t,n=150){this.cancel(i);const s=setTimeout(()=>{this.timers.delete(i),t()},n);this.timers.set(i,s)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Am{constructor(i){ke(this,"blockToPageMap",new Map);ke(this,"debounceCtrl",new Mm);ke(this,"activeBlockId","");ke(this,"activePageIndex",1);ke(this,"currentDocId","");ke(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const t of i){t.startBlockId&&this.blockToPageMap.set(t.startBlockId,t.pageIndex);for(const n of t.blocks)this.blockToPageMap.set(n.id,t.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let t=this.getPageByBlockId(i);!t&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(t=1),t&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=t,this.bridge&&(this.bridge.navigatePage(t),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const t=this.getPageByBlockId(i);t&&(this.activePageIndex=t)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let $t=null,ds=null,us="";function Dn(){var e,i;if(ds&&(clearTimeout(ds),ds=null),$t){try{$t.classList.remove("protyle-wysiwyg--select"),us?$t.style.outline=us:typeof((e=$t.style)==null?void 0:e.removeProperty)=="function"?$t.style.removeProperty("outline"):$t.style&&($t.style.outline=""),typeof((i=$t.style)==null?void 0:i.removeProperty)=="function"?$t.style.removeProperty("transition"):$t.style&&($t.style.transition="")}catch(t){console.warn("[SelectionMirror] clear activeHighlightEl failed:",t)}$t=null,us=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,l;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((l=n.style)==null?void 0:l.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function zi(e,i){var l,r,a,c;if(!e||typeof document>"u")return Dn(),!1;Dn();const t=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!n){if(i)try{return ue.openTab({app:i,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(d){console.warn("[SelectionMirror] openTab fallback failed:",d)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(a=n.focus)==null||a.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return us=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),$t=n,ds=setTimeout(()=>{Dn()},500),!0}function Bm(e){if(!e)return"";const i=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return i.map(l=>rt(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of i){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function Dm(e){if(e.length===0)return"";const i=[],t=e[0],n=t.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();i.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else i.push(`<p class="slide-list-item-title">${rt(t)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>rt(a)).join("<br/>");i.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();i.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else o.push(r)}l()}return i.join(`
`)+(i.length>0?`
`:"")}function Na(e,i,t){var h,u,b,m;const n=e.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const o=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const y=n[v];if(!y.trim())continue;const C=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(C){const T=C[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:C[2].toLowerCase()==="x",text:C[3],media:[]});continue}const S=y.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const T=S[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:S[2],media:[]});continue}const x=y.match(/^(\s*)\d+\.\s+(.*)$/);if(x){l.length===0&&(r=!0);const T=x[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:x[2],media:[]});continue}const $=y.trim();if(!(!$||/^\{:.*?\}$/.test($)))if(l.length>0){const T=$.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const N=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(T[1])}" src="${T[2]}" class="${N}" /></div>`);continue}if($.match(/^<img\b[\s\S]*?\/?>$/i)){const P=$.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${P}</div>`);continue}if(/<video\b/i.test($)){let P=$;if(!/<\/video>/i.test(P))for(;v+1<n.length&&!/<\/video>/i.test(P);)v++,P+=" "+n[v].trim();const N=((h=t==null?void 0:t.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(P),H=((u=t==null?void 0:t.attributes)==null?void 0:u["custom-slides-loop"])==="true"||/loop/i.test(P),K=((b=t==null?void 0:t.attributes)==null?void 0:b["custom-slides-muted"])==="true"||N||/muted/i.test(P),_=((m=t==null?void 0:t.attributes)==null?void 0:m["custom-slides-controls"])==="false",F=P.match(/\bsrc=["']([^"']+)["']/i),k=F?F[1]:"",M=['class="slide-video-player"'];_||M.push("controls"),N&&(M.push("autoplay"),M.push("playsinline")),H&&M.push("loop"),K&&M.push("muted"),M.push('preload="metadata"'),k&&M.push(`src="${k}"`);const j=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=j?j[1].trim():"";!A&&k&&(A=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${K?"true":"false"}"><video ${M.join(" ")}>${A}</video></div>`);continue}l[l.length-1].text+=`
`+$}else o.push($)}if(l.length===0)return null;const a=r?"ol":"ul",c=(i==null?void 0:i.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(v=>{const y=Bm(v.text),C=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",S=v.level||0,x=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",$=S>0?" slide-list-item--nested":"";if(v.type==="task"){const w=v.checked?' checked=""':"";return`<li class="pdf-task-item${$}"${x}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${C}</li>`}return`<li${$?` class="${$.trim()}"`:""}${x}>${y}${C}</li>`}).join(`
`);return`${Dm(o)}<${a} class="${c}">
${d}
</${a}>`}function Lm(e,i,t){const n=(i==null?void 0:i.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(!p){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]);let h=p;if(!/<\/video>/i.test(h))for(;c+1<s.length&&!/<\/video>/i.test(h);)c++,h+=`
`+s[c];o.push(h);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var b,m,v,y;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const C=p[1].length;return`<h${C} class="slide-list-item-title">${rt(p[2].trim())}</h${C}>`}const h=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const C=/\.gif(?:\?|$)/i.test(h[2]),S=(i==null?void 0:i.imageClassName)||(C?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(h[1])}" src="${h[2]}" class="${S}" /></div>`}if(/<video\b/i.test(d)){const C=((b=t==null?void 0:t.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(d),S=((m=t==null?void 0:t.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(d),x=((v=t==null?void 0:t.attributes)==null?void 0:v["custom-slides-muted"])==="true"||C||/muted/i.test(d),$=((y=t==null?void 0:t.attributes)==null?void 0:y["custom-slides-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",P=['class="slide-video-player"'];$||P.push("controls"),C&&P.push("autoplay playsinline"),S&&P.push("loop"),x&&P.push("muted"),P.push('preload="metadata"'),w&&P.push(`src="${w}"`);const N=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let H=N?N[1].trim():"";return!H&&w&&(H=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${C?"true":"false"}" data-muted="${x?"true":"false"}"><video ${P.join(" ")}>${H}</video></div>`}const u=Na(d,i,t);if(u)return r=!1,u;if(r){r=!1;const C=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(C.length===1)return`<p class="slide-list-item-title">${rt(C[0])}</p>`;const S=C[0],$=C.slice(1).map(T=>rt(T)).join("<br/>");return`<p class="slide-list-item-title">${rt(S)}</p>
<p class="slide-list-item-desc">${$}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function co(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const i=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(i)}function za(e,i){var r,a,c,d,p,h,u,b;const t=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=t==="cover"?null:s.find(co);if(t==="two-cols"){const m=s.some(K=>K.slot==="right");let v=[],y=[];if(m)v=s.filter(K=>K.slot!=="right"),y=s.filter(K=>K.slot==="right");else{const K=Math.ceil(s.length/2);v=s.slice(0,K),y=s.slice(K)}const C=K=>{const _=K.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(_.length>0){const F=_[0],k=(F.rawMarkdown||F.content||"").trim();(ji(F)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(F.rawMarkdown=Mn(F.rawMarkdown||F.content||""),F.content=F.rawMarkdown)}};C(v),C(y);const S=v.map(K=>hi(K,i)).join(`
`),x=y.map(K=>hi(K,i)).join(`
`),$=(i==null?void 0:i.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(i==null?void 0:i.leftColClass)||"pdf-col pdf-col--left",P=(i==null?void 0:i.rightColClass)||"pdf-col pdf-col--right",H=`style="grid-template-columns: ${lo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${$}${T}" ${H}>
        <div class="${w}">${S}</div>
        <div class="${P}">${x}</div>
      </div>
    `}if(t==="clover"||Nn(t)){const m=t==="clover";let v=[];const y=s.filter(M=>M.slot==="header");if(y.length>0)v=y;else if(s.length>0){const M=s.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));M&&(v=[M])}const C=s.filter(M=>!v.includes(M));let S=2;if(m)S=4;else if(t==="three-cols-header")S=3;else if(t==="two-cols-header")S=2;else{let M=0;for(const j of C){const A=(j.slot||"").match(/^col-(\d+)$/i);A&&(M=Math.max(M,parseInt(A[1],10)))}if(M>=2)S=M;else if((d=e.frontmatter)!=null&&d.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const A=j.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);A.length>=2&&(S=A.length)}else{const A=j.split(/\s+/).filter(Boolean);A.length>=2&&(S=A.length)}}else C.length===1&&C[0].children&&C[0].children.length>=2&&(S=Math.min(6,C[0].children.length))}const x=Ma(C,S),$=C.some(M=>M.slot&&/^(?:col-\d+|left|right)$/i.test(M.slot)),T=t==="clover"||t==="two-cols-header"||t==="three-cols-header"||Nn(t)&&$,w=M=>{const j=M.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(T&&j.length>0){const D=j[0],O=(D.rawMarkdown||D.content||"").trim();(ji(D)||/^(?:[-*+]|\d+\.)\s+/.test(O))&&(D.rawMarkdown=Mn(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const A=T?j.find(co):null;return j.map(D=>hi(D,{...i,extraClassName:D===A?"slides-col-first-heading-block":""})).join(`
`)},P=v.find(co),N=v.map(M=>hi(M,{...i,extraClassName:M===P?"slides-page-first-heading-block":""})).join(`
`),H=m?"repeat(2, minmax(0, 1fr))":lo((p=e.frontmatter)==null?void 0:p.layoutRatio,S),K=m?`style="grid-template-columns: ${H}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${H};"`,_=[m?"layout-clover-container":"layout-cols-header-container",S===2?"layout-two-cols-header-container":"",S===3?"layout-three-cols-header-container":"",`layout-${t}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),F=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",S===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",S===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),k=x.map((M,j)=>{const A=j+1;return`<div class="${["pdf-col",S===2&&A===1?"pdf-col--left":"",S===2&&A===2?"pdf-col--right":"",`pdf-col--${A}`,`col-${A}`].filter(Boolean).join(" ")}">${w(M)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${N}</div>
        <div class="${F}" ${K}>
          ${k}
        </div>
      </div>
    `}if(t==="image-right"||t==="image-left"){const m=t==="image-right",v=s.map(T=>hi(T,i)).join(`
`),y=((h=e.frontmatter)==null?void 0:h.image)||((u=e.frontmatter)==null?void 0:u.background)||"",C=`<div class="pdf-image-col" style="background-image:url('${nt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,S=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,x=m?`${S}
${C}`:`${C}
${S}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${lo((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${x}
      </div>
    `}return t==="fact"?`<div class="layout-fact-container">${s.map(v=>hi(v,i)).join(`
`)}</div>`:t==="cover"?`<div class="layout-cover-container">${s.map(v=>hi(v,i)).join(`
`)}</div>`:s.map(m=>hi(m,{...i,extraClassName:m===l?"slides-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Pm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const i=new Set,t=e.split("|");for(const n of t){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)i.add(c)}else{const o=parseInt(s,10);isNaN(o)||i.add(o)}}return i}const Rm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const i=Ia(e),t=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!Rm.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?t.push("</mark>"):t.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${t.length-1}%%`}return t.push(o),`%%SAFE_HTML_${t.length-1}%%`});let s=nt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return t[r]||""}),s}function Om(e,i="pdf-table"){if(e.length<2)return"";const t=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=t[0];let s=[],o=1;e.length>=2&&t[1].every(a=>/^:?-+:?$/.test(a))&&(s=t[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=t.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${r}</tbody></table>`}function uo(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function el(e,i="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${uo(e)}</span>`;const t=[];function n(o,l){return t.push(`<span class="${o}">${uo(l)}</span>`),`__TOK_${t.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=uo(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>t[parseInt(l,10)]||""),s}function Nm(e,i){if(!e)return null;const t=e.frontmatter||{};if(t.hideInToc===!0||t.hideInToc==="true")return null;let n=(t.title||"").trim(),s=t.level?parseInt(t.level,10):0;if(!n){const o=e.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||i,title:n,level:s}):null}function zm(e,i=1,t={}){const n=t.minDepth!==void 0?Number(t.minDepth):1,s=t.maxDepth!==void 0?Number(t.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=Nm(c,d+1);p&&o.push(p)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const p=[];for(const h of c){const u=a(h.children,d+1);d>=n?p.push({...h,children:u}):p.push(...u)}return p}return a(l,1)}function Hm(e,i=1,t={}){const n=zm(e,i,t),s=t.columns?Number(t.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=t.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slides-toc-list slides-toc-list-level-${d}`,h=c.map(u=>{const b=u.active?" slides-toc-item-active":u.hasActiveChild?" slides-toc-item-parent-active":"",m=u.children&&u.children.length>0?r(u.children,d+1):"";let v=rt(u.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${u.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${v}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${p}">${h}</ol>`}const a=r(n,1);return`<div class="slides-toc${l}"${o}>${a}</div>`}function hi(e,i){var $,T,w,P,N,H,K,_,F,k;let t="",n="",s="";const o=[];($=e.motion)!=null&&$.preset&&e.motion.preset!=="none"&&(t=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${nt(o.join(";"))}"`);const r=(i==null?void 0:i.containerClassName)||"pdf-block",a=i!=null&&i.extraClassName?` ${i.extraClassName}`:"",c=i!=null&&i.blockClassResolver?i.blockClassResolver(e):"",d=c?` ${c}`:"",p=`${r}${t}${s}${a}${d}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${p}"${n}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${p}"${n}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const M=h.slice(2,-2).trim();return`<div class="${p} katex-display-container"${n}><div class="katex-display font-math"><em>${nt(M)}</em></div></div>`}const u=h.match(/^(#{1,6})\s+(.*)$/);if(u){const M=u[1].length,j=rt(u[2]),D=!!(e.isColFirst||e.type==="i"&&((w=i==null?void 0:i.extraClassName)!=null&&w.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><h${M}${D}>${j}</h${M}></div>`}if(h.startsWith(":::")){const M=h.split(`
`),A=M[0].replace(/^:::\s*/,"").trim()||"info",D=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),O=(i==null?void 0:i.calloutClassName)||"pdf-callout";return`<div class="${p}"${n}><div class="${O} ${O}--${A}"><div class="${O}-title">${A.toUpperCase()}</div><div class="${O}-body">${rt(D)}</div></div></div>`}if(h.startsWith("<<<")){const A=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((W,q)=>`<span class="code-line shiki-focus"><span class="line-no">${q+1}</span><span class="line-content">${el(W,"ts")}</span></span>`).join(`
`),D=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",O=((P=e.attrs)==null?void 0:P["custom-slides-max-height"])||e.maxHeight||"",Q=O?` style="max-height:${nt(O)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${D}"${Q}><span class="lang-badge">TS</span><code>${A}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const M=h.split(`
`),j=M[0].slice(3).trim(),A=j.match(/^([^\s{\[]+)/),D=A?A[1]:"",O=j.match(/\[([^\]]+)\]/),Q=O?O[1]:"",W=j.includes("twoslash"),q=e.shikiLines||((N=j.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",re=Pm(q),ae=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[h.slice(3).replace(/```$/,"")],ce=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",ge=Q?`${ce} has-filename`:ce,Te=re!=="all",Se=ae.map((V,g)=>{const G=g+1,I=re==="all"||re.has(G)?"code-line shiki-focus":Te?"code-line shiki-dimmed":"code-line";let R=(i==null?void 0:i.highlight)===!0?el(V,D):nt(V);return W&&V.includes("doubled.value = 2")?(R=R.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${R}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${I}"><span class="line-no">${G}</span><span class="line-content">${R}</span></span>`}).join(`
`),fe=D?`<span class="lang-badge">${nt(D)}</span>`:"",Z=Q?`<span class="code-filename">${nt(Q)}</span>`:"",pe=((H=e.attrs)==null?void 0:H["custom-slides-max-height"])||e.maxHeight||"",L=pe?` style="max-height:${nt(pe)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${ge}"${L}>${Z}${fe}<code>${Se}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=h.split(`
`).filter(A=>A.trim().startsWith("|")),j=Om(M,i==null?void 0:i.tableClassName);return`<div class="${p}"${n}>${j}</div>`}if(h.startsWith("> ")){const M=(i==null?void 0:i.quoteClassName)||"pdf-quote";return`<div class="${p}"${n}><blockquote class="${M}"><p>${rt(h.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),v=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(b&&!m&&!v&&!h.includes(`
`)){const M=((K=e.attributes)==null?void 0:K["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),j=((_=e.attributes)==null?void 0:_["custom-slides-loop"])==="true"||/loop/i.test(h),A=((F=e.attributes)==null?void 0:F["custom-slides-muted"])==="true"||M||/muted/i.test(h),D=((k=e.attributes)==null?void 0:k["custom-slides-controls"])==="false",O=h.match(/\bsrc=["']([^"']+)["']/i),Q=O?O[1]:"",W=['class="slide-video-player"'];D||W.push("controls"),M&&(W.push("autoplay"),W.push("playsinline")),j&&W.push("loop"),A&&W.push("muted"),W.push('preload="auto"'),Q&&W.push(`src="${Q}"`);const q=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=q?q[1].trim():"";return!re&&Q&&(re=`<source src="${Q}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${A?"true":"false"}"${n}><video ${W.join(" ")}>${re}</video></div>`}const y=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const M=(i==null?void 0:i.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${n}><img alt="${nt(y[1])}" src="${y[2]}" class="${M}" /></div>`}const C=Na(h,i,e);if(C)return`<div class="${p} pdf-list-item"${n}>${C}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const M=h.match(/minDepth=["']?(\d+)["']?/i),j=h.match(/maxDepth=["']?(\d+)["']?/i),A=h.match(/columns=["']?(\d+)["']?/i),D=(i==null?void 0:i.allSlides)||[];return`<div class="${p}"${n}>${Hm(D,(i==null?void 0:i.currentPageIndex)||1,{minDepth:M?parseInt(M[1],10):1,maxDepth:j?parseInt(j[1],10):1/0,columns:A?parseInt(A[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||v){const M=Lm(h,i,e);if(M)return`<div class="${p}"${n}>${M}</div>`}const x=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><p${x}>${rt(h)}</p></div>`}function Fm(e){return`
    ${Bn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function jm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Wm(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Um(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function Vm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function Gm(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function Km(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function qm(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function Ym(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function Zm(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Jm(){return[jm(),Wm(),Um(),Vm(),Gm(),Km(),qm(),Ym(),Zm()].join("")}function Ha(e,i){const t="即现演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(t)}</title>
  <style>
${Fm(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Jm()}
  <\/script>
</body>
</html>`}function Fa(e,i){if(typeof document>"u")return!1;const t=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(t),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function Xm(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Qm(e){const i=Xm(e==null?void 0:e.pageRatio);return`
    ${Bn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function eg(e,i){const t="即现演示讲义",n="16:9",s="light",o=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=za(l),h=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(t)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(t)} - 高保真讲义</title>
  <style>
    ${Qm({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function ja(e,i){var s;if(typeof window>"u"||typeof document>"u")return!1;const t=eg(e,i);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(t),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(t),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var os=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function tg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function rs(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var fo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var tl;function ig(){return tl||(tl=1,(function(e,i){(function(t){e.exports=t()})(function(){return(function t(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var p=typeof rs=="function"&&rs;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(b){var m=n[c][1][b];return l(m||b)},u,u.exports,t,n,s,o)}return s[c].exports}for(var r=typeof rs=="function"&&rs,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(t,n,s){var o=t("./utils"),l=t("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,p,h,u,b,m,v=[],y=0,C=a.length,S=C,x=o.getTypeOf(a)!=="string";y<a.length;)S=C-y,p=x?(c=a[y++],d=y<C?a[y++]:0,y<C?a[y++]:0):(c=a.charCodeAt(y++),d=y<C?a.charCodeAt(y++):0,y<C?a.charCodeAt(y++):0),h=c>>2,u=(3&c)<<4|d>>4,b=1<S?(15&d)<<2|p>>6:64,m=2<S?63&p:64,v.push(r.charAt(h)+r.charAt(u)+r.charAt(b)+r.charAt(m));return v.join("")},s.decode=function(a){var c,d,p,h,u,b,m=0,v=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var C,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&S--,a.charAt(a.length-2)===r.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(C=l.uint8array?new Uint8Array(0|S):new Array(0|S);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(h=r.indexOf(a.charAt(m++)))>>4,d=(15&h)<<4|(u=r.indexOf(a.charAt(m++)))>>2,p=(3&u)<<6|(b=r.indexOf(a.charAt(m++))),C[v++]=c,u!==64&&(C[v++]=d),b!==64&&(C[v++]=p);return C}},{"./support":30,"./utils":32}],2:[function(t,n,s){var o=t("./external"),l=t("./stream/DataWorker"),r=t("./stream/Crc32Probe"),a=t("./stream/DataLengthProbe");function c(d,p,h,u,b){this.compressedSize=d,this.uncompressedSize=p,this.crc32=h,this.compression=u,this.compressedContent=b}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,h){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(h)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(t,n,s){var o=t("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=t("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(t,n,s){var o=t("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,p,h){var u=l,b=h+p;c^=-1;for(var m=h;m<b;m++)c=c>>>8^u[255&(c^d[m])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,h){var u=l,b=h+p;c^=-1;for(var m=h;m<b;m++)c=c>>>8^u[255&(c^d.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(t,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(t,n,s){var o=null;o=typeof Promise<"u"?Promise:t("lie"),n.exports={Promise:o}},{lie:37}],7:[function(t,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=t("pako"),r=t("./utils"),a=t("./stream/GenericWorker"),c=o?"uint8array":"array";function d(p,h){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=h,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(h){p.push({data:h,meta:p.meta})}},s.compressWorker=function(p){return new d("Deflate",p)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(t,n,s){function o(u,b){var m,v="";for(m=0;m<b;m++)v+=String.fromCharCode(255&u),u>>>=8;return v}function l(u,b,m,v,y,C){var S,x,$=u.file,T=u.compression,w=C!==c.utf8encode,P=r.transformTo("string",C($.name)),N=r.transformTo("string",c.utf8encode($.name)),H=$.comment,K=r.transformTo("string",C(H)),_=r.transformTo("string",c.utf8encode(H)),F=N.length!==$.name.length,k=_.length!==H.length,M="",j="",A="",D=$.dir,O=$.date,Q={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(Q.crc32=u.crc32,Q.compressedSize=u.compressedSize,Q.uncompressedSize=u.uncompressedSize);var W=0;b&&(W|=8),w||!F&&!k||(W|=2048);var q=0,re=0;D&&(q|=16),y==="UNIX"?(re=798,q|=(function(ce,ge){var Te=ce;return ce||(Te=ge?16893:33204),(65535&Te)<<16})($.unixPermissions,D)):(re=20,q|=(function(ce){return 63&(ce||0)})($.dosPermissions)),S=O.getUTCHours(),S<<=6,S|=O.getUTCMinutes(),S<<=5,S|=O.getUTCSeconds()/2,x=O.getUTCFullYear()-1980,x<<=4,x|=O.getUTCMonth()+1,x<<=5,x|=O.getUTCDate(),F&&(j=o(1,1)+o(d(P),4)+N,M+="up"+o(j.length,2)+j),k&&(A=o(1,1)+o(d(K),4)+_,M+="uc"+o(A.length,2)+A);var ae="";return ae+=`
\0`,ae+=o(W,2),ae+=T.magic,ae+=o(S,2),ae+=o(x,2),ae+=o(Q.crc32,4),ae+=o(Q.compressedSize,4),ae+=o(Q.uncompressedSize,4),ae+=o(P.length,2),ae+=o(M.length,2),{fileRecord:p.LOCAL_FILE_HEADER+ae+P+M,dirRecord:p.CENTRAL_FILE_HEADER+o(re,2)+ae+o(K.length,2)+"\0\0\0\0"+o(q,4)+o(v,4)+P+M+K}}var r=t("../utils"),a=t("../stream/GenericWorker"),c=t("../utf8"),d=t("../crc32"),p=t("../signature");function h(u,b,m,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=v,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,a),h.prototype.push=function(u){var b=u.meta.percent||0,m=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-v-1))/m:100}}))},h.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var b=this.streamFiles&&!u.file.dir;if(b){var m=l(u,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(u){this.accumulate=!1;var b=this.streamFiles&&!u.file.dir,m=l(u,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(v){return p.DATA_DESCRIPTOR+o(v.crc32,4)+o(v.compressedSize,4)+o(v.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var u=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-u,v=(function(y,C,S,x,$){var T=r.transformTo("string",$(x));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(C,4)+o(S,4)+o(T.length,2)+T})(this.dirRecords.length,m,u,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(u){this._sources.push(u);var b=this;return u.on("data",function(m){b.processChunk(m)}),u.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),u.on("error",function(m){b.error(m)}),this},h.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(u){var b=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var m=0;m<b.length;m++)try{b[m].error(u)}catch{}return!0},h.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,b=0;b<u.length;b++)u[b].lock()},n.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(t,n,s){var o=t("../compressions"),l=t("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(h,u){p++;var b=(function(C,S){var x=C||S,$=o[x];if(!$)throw new Error(x+" is not a valid compression method !");return $})(u.options.compression,a.compression),m=u.options.compressionOptions||a.compressionOptions||{},v=u.dir,y=u.date;u._compressWorker(b,m).withStreamInfo("file",{name:h,dir:v,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(h){d.error(h)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(t,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=t("./object")).loadAsync=t("./load"),o.support=t("./support"),o.defaults=t("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=t("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(t,n,s){var o=t("./utils"),l=t("./external"),r=t("./utf8"),a=t("./zipEntries"),c=t("./stream/Crc32Probe"),d=t("./nodejsUtils");function p(h){return new l.Promise(function(u,b){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(v){b(v)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(h,u){var b=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(h)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,u.optimizedBinaryString,u.base64).then(function(m){var v=new a(u);return v.load(m),v}).then(function(m){var v=[l.Promise.resolve(m)],y=m.files;if(u.checkCRC32)for(var C=0;C<y.length;C++)v.push(p(y[C]));return l.Promise.all(v)}).then(function(m){for(var v=m.shift(),y=v.files,C=0;C<y.length;C++){var S=y[C],x=S.fileNameStr,$=o.resolve(S.fileNameStr);b.file($,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(b.file($).unsafeOriginalName=x)}return v.zipComment.length&&(b.comment=v.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(t,n,s){var o=t("../utils"),l=t("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(t,n,s){var o=t("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(p,h){d.push(p)||d._helper.pause(),c&&c(h)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}t("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(t,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(t,n,s){function o($,T,w){var P,N=r.getTypeOf(T),H=r.extend(w||{},d);H.date=H.date||new Date,H.compression!==null&&(H.compression=H.compression.toUpperCase()),typeof H.unixPermissions=="string"&&(H.unixPermissions=parseInt(H.unixPermissions,8)),H.unixPermissions&&16384&H.unixPermissions&&(H.dir=!0),H.dosPermissions&&16&H.dosPermissions&&(H.dir=!0),H.dir&&($=y($)),H.createFolders&&(P=v($))&&C.call(this,P,!0);var K=N==="string"&&H.binary===!1&&H.base64===!1;w&&w.binary!==void 0||(H.binary=!K),(T instanceof p&&T.uncompressedSize===0||H.dir||!T||T.length===0)&&(H.base64=!1,H.binary=!0,T="",H.compression="STORE",N="string");var _=null;_=T instanceof p||T instanceof a?T:b.isNode&&b.isStream(T)?new m($,T):r.prepareContent($,T,H.binary,H.optimizedBinaryString,H.base64);var F=new h($,_,H);this.files[$]=F}var l=t("./utf8"),r=t("./utils"),a=t("./stream/GenericWorker"),c=t("./stream/StreamHelper"),d=t("./defaults"),p=t("./compressedObject"),h=t("./zipObject"),u=t("./generate"),b=t("./nodejsUtils"),m=t("./nodejs/NodejsStreamInputAdapter"),v=function($){$.slice(-1)==="/"&&($=$.substring(0,$.length-1));var T=$.lastIndexOf("/");return 0<T?$.substring(0,T):""},y=function($){return $.slice(-1)!=="/"&&($+="/"),$},C=function($,T){return T=T!==void 0?T:d.createFolders,$=y($),this.files[$]||o.call(this,$,null,{dir:!0,createFolders:T}),this.files[$]};function S($){return Object.prototype.toString.call($)==="[object RegExp]"}var x={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function($){var T,w,P;for(T in this.files)P=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&$(w,P)},filter:function($){var T=[];return this.forEach(function(w,P){$(w,P)&&T.push(P)}),T},file:function($,T,w){if(arguments.length!==1)return $=this.root+$,o.call(this,$,T,w),this;if(S($)){var P=$;return this.filter(function(H,K){return!K.dir&&P.test(H)})}var N=this.files[this.root+$];return N&&!N.dir?N:null},folder:function($){if(!$)return this;if(S($))return this.filter(function(N,H){return H.dir&&$.test(N)});var T=this.root+$,w=C.call(this,T),P=this.clone();return P.root=w.name,P},remove:function($){$=this.root+$;var T=this.files[$];if(T||($.slice(-1)!=="/"&&($+="/"),T=this.files[$]),T&&!T.dir)delete this.files[$];else for(var w=this.filter(function(N,H){return H.name.slice(0,$.length)===$}),P=0;P<w.length;P++)delete this.files[w[P].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function($){var T,w={};try{if((w=r.extend($||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var P=w.comment||this.comment||"";T=u.generateWorker(this,w,P)}catch(N){(T=new a("error")).error(N)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function($,T){return this.generateInternalStream($).accumulate(T)},generateNodeStream:function($,T){return($=$||{}).type||($.type="nodebuffer"),this.generateInternalStream($).toNodejsStream(T)}};n.exports=x},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(t,n,s){n.exports=t("stream")},{stream:void 0}],17:[function(t,n,s){var o=t("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}t("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===a&&this.data[h+1]===c&&this.data[h+2]===d&&this.data[h+3]===p)return h-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),h=this.readData(4);return a===h[0]&&c===h[1]&&d===h[2]&&p===h[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(t,n,s){var o=t("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(t,n,s){var o=t("./Uint8ArrayReader");function l(r){o.call(this,r)}t("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(t,n,s){var o=t("./DataReader");function l(r){o.call(this,r)}t("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(t,n,s){var o=t("./ArrayReader");function l(r){o.call(this,r)}t("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(t,n,s){var o=t("../utils"),l=t("../support"),r=t("./ArrayReader"),a=t("./StringReader"),c=t("./NodeBufferReader"),d=t("./Uint8ArrayReader");n.exports=function(p){var h=o.getTypeOf(p);return o.checkSupport(h),h!=="string"||l.uint8array?h==="nodebuffer"?new c(p):l.uint8array?new d(o.transformTo("uint8array",p)):new r(o.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(t,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(t,n,s){var o=t("./GenericWorker"),l=t("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(t,n,s){var o=t("./GenericWorker"),l=t("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}t("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(t,n,s){var o=t("../utils"),l=t("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(t,n,s){var o=t("../utils"),l=t("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(t,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(t,n,s){var o=t("../utils"),l=t("./ConvertWorker"),r=t("./GenericWorker"),a=t("../base64"),c=t("../support"),d=t("../external"),p=null;if(c.nodestream)try{p=t("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(b,m){return new d.Promise(function(v,y){var C=[],S=b._internalType,x=b._outputType,$=b._mimeType;b.on("data",function(T,w){C.push(T),m&&m(w)}).on("error",function(T){C=[],y(T)}).on("end",function(){try{var T=(function(w,P,N){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",P),N);case"base64":return a.encode(P);default:return o.transformTo(w,P)}})(x,(function(w,P){var N,H=0,K=null,_=0;for(N=0;N<P.length;N++)_+=P[N].length;switch(w){case"string":return P.join("");case"array":return Array.prototype.concat.apply([],P);case"uint8array":for(K=new Uint8Array(_),N=0;N<P.length;N++)K.set(P[N],H),H+=P[N].length;return K;case"nodebuffer":return Buffer.concat(P);default:throw new Error("concat : unsupported type '"+w+"'")}})(S,C),$);v(T)}catch(w){y(w)}C=[]}).resume()})}function u(b,m,v){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=v,o.checkSupport(y),this._worker=b.pipe(new l(y)),b.lock()}catch(C){this._worker=new r("error"),this._worker.error(C)}}u.prototype={accumulate:function(b){return h(this,b)},on:function(b,m){var v=this;return b==="data"?this._worker.on(b,function(y){m.call(v,y.data,y.meta)}):this._worker.on(b,function(){o.delay(m,arguments,v)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(t,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!t("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(t,n,s){for(var o=t("./utils"),l=t("./support"),r=t("./nodejsUtils"),a=t("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function h(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(b){var m,v,y,C,S,x=b.length,$=0;for(C=0;C<x;C++)(64512&(v=b.charCodeAt(C)))==55296&&C+1<x&&(64512&(y=b.charCodeAt(C+1)))==56320&&(v=65536+(v-55296<<10)+(y-56320),C++),$+=v<128?1:v<2048?2:v<65536?3:4;for(m=l.uint8array?new Uint8Array($):new Array($),C=S=0;S<$;C++)(64512&(v=b.charCodeAt(C)))==55296&&C+1<x&&(64512&(y=b.charCodeAt(C+1)))==56320&&(v=65536+(v-55296<<10)+(y-56320),C++),v<128?m[S++]=v:(v<2048?m[S++]=192|v>>>6:(v<65536?m[S++]=224|v>>>12:(m[S++]=240|v>>>18,m[S++]=128|v>>>12&63),m[S++]=128|v>>>6&63),m[S++]=128|63&v);return m})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(b){var m,v,y,C,S=b.length,x=new Array(2*S);for(m=v=0;m<S;)if((y=b[m++])<128)x[v++]=y;else if(4<(C=c[y]))x[v++]=65533,m+=C-1;else{for(y&=C===2?31:C===3?15:7;1<C&&m<S;)y=y<<6|63&b[m++],C--;1<C?x[v++]=65533:y<65536?x[v++]=y:(y-=65536,x[v++]=55296|y>>10&1023,x[v++]=56320|1023&y)}return x.length!==v&&(x.subarray?x=x.subarray(0,v):x.length=v),o.applyFromCharCode(x)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(p,a),p.prototype.processChunk=function(u){var b=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var v=(function(C,S){var x;for((S=S||C.length)>C.length&&(S=C.length),x=S-1;0<=x&&(192&C[x])==128;)x--;return x<0||x===0?S:x+c[C[x]]>S?x:S})(b),y=b;v!==b.length&&(l.uint8array?(y=b.subarray(0,v),this.leftOver=b.subarray(v,b.length)):(y=b.slice(0,v),this.leftOver=b.slice(v,b.length))),this.push({data:s.utf8decode(y),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=p,o.inherits(h,a),h.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(t,n,s){var o=t("./support"),l=t("./base64"),r=t("./nodejsUtils"),a=t("./external");function c(m){return m}function d(m,v){for(var y=0;y<m.length;++y)v[y]=255&m.charCodeAt(y);return v}t("setimmediate"),s.newBlob=function(m,v){s.checkSupport("blob");try{return new Blob([m],{type:v})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(m,v,y){var C=[],S=0,x=m.length;if(x<=y)return String.fromCharCode.apply(null,m);for(;S<x;)v==="array"||v==="nodebuffer"?C.push(String.fromCharCode.apply(null,m.slice(S,Math.min(S+y,x)))):C.push(String.fromCharCode.apply(null,m.subarray(S,Math.min(S+y,x)))),S+=y;return C.join("")},stringifyByChar:function(m){for(var v="",y=0;y<m.length;y++)v+=String.fromCharCode(m[y]);return v},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var v=65536,y=s.getTypeOf(m),C=!0;if(y==="uint8array"?C=p.applyCanBeUsed.uint8array:y==="nodebuffer"&&(C=p.applyCanBeUsed.nodebuffer),C)for(;1<v;)try{return p.stringifyByChunk(m,y,v)}catch{v=Math.floor(v/2)}return p.stringifyByChar(m)}function u(m,v){for(var y=0;y<m.length;y++)v[y]=m[y];return v}s.applyFromCharCode=h;var b={};b.string={string:c,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:function(m){return d(m,r.allocBuffer(m.length))}},b.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return u(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:h,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:h,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,v){if(v=v||"",!m)return v;s.checkSupport(m);var y=s.getTypeOf(v);return b[y][m](v)},s.resolve=function(m){for(var v=m.split("/"),y=[],C=0;C<v.length;C++){var S=v[C];S==="."||S===""&&C!==0&&C!==v.length-1||(S===".."?y.pop():y.push(S))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var v,y,C="";for(y=0;y<(m||"").length;y++)C+="\\x"+((v=m.charCodeAt(y))<16?"0":"")+v.toString(16).toUpperCase();return C},s.delay=function(m,v,y){setImmediate(function(){m.apply(y||null,v||[])})},s.inherits=function(m,v){function y(){}y.prototype=v.prototype,m.prototype=new y},s.extend=function(){var m,v,y={};for(m=0;m<arguments.length;m++)for(v in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],v)&&y[v]===void 0&&(y[v]=arguments[m][v]);return y},s.prepareContent=function(m,v,y,C,S){return a.Promise.resolve(v).then(function(x){return o.blob&&(x instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(x))!==-1)&&typeof FileReader<"u"?new a.Promise(function($,T){var w=new FileReader;w.onload=function(P){$(P.target.result)},w.onerror=function(P){T(P.target.error)},w.readAsArrayBuffer(x)}):x}).then(function(x){var $=s.getTypeOf(x);return $?($==="arraybuffer"?x=s.transformTo("uint8array",x):$==="string"&&(S?x=l.decode(x):y&&C!==!0&&(x=(function(T){return d(T,o.uint8array?new Uint8Array(T.length):new Array(T.length))})(x))),x):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(t,n,s){var o=t("./reader/readerFor"),l=t("./utils"),r=t("./signature"),a=t("./zipEntry"),c=t("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(h)+", expected "+l.pretty(p)+")")}},isSignature:function(p,h){var u=this.reader.index;this.reader.setIndex(p);var b=this.reader.readString(4)===h;return this.reader.setIndex(u),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",u=l.transformTo(h,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,h,u,b=this.zip64EndOfCentralSize-44;0<b;)p=this.reader.readInt(2),h=this.reader.readInt(4),u=this.reader.readData(h),this.zip64ExtensibleData[p]={id:p,length:h,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,h;for(p=0;p<this.files.length;p++)h=this.files[p],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var h=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var b=h-u;if(0<b)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(p){this.reader=o(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(t,n,s){var o=t("./reader/readerFor"),l=t("./utils"),r=t("./compressedObject"),a=t("./crc32"),c=t("./utf8"),d=t("./compressions"),p=t("./support");function h(u,b){this.options=u,this.loadOptions=b}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var b,m;if(u.skip(22),this.fileNameLength=u.readInt(2),m=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(v){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===v)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var b=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(b),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var b,m,v,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)b=u.readInt(2),m=u.readInt(2),v=u.readData(m),this.extraFields[b]={id:b,length:m,value:v};u.setIndex(y)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var b=o(u.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var b=o(u.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(u.length-5))}return null}},n.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(t,n,s){function o(b,m,v){this.name=b,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=m,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=t("./stream/StreamHelper"),r=t("./stream/DataWorker"),a=t("./utf8"),c=t("./compressedObject"),d=t("./stream/GenericWorker");o.prototype={internalStream:function(b){var m=null,v="string";try{if(!b)throw new Error("No output type specified.");var y=(v=b.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),m=this._decompressWorker();var C=!this._dataBinary;C&&!y&&(m=m.pipe(new a.Utf8EncodeWorker)),!C&&y&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(S){(m=new d("error")).error(S)}return new l(m,v,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)o.prototype[p[u]]=h;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(t,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(b),p=o.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var h=new o.MessageChannel;h.port1.onmessage=b,l=function(){h.port2.postMessage(0)}}var u=[];function b(){var m,v;r=!0;for(var y=u.length;y;){for(v=u,u=[],m=-1;++m<y;)v[m]();y=u.length}r=!1}n.exports=function(m){u.push(m)!==1||r||l()}}).call(this,typeof os<"u"?os:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(t,n,s){var o=t("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&m(this,y)}function h(y,C,S){this.promise=y,typeof C=="function"&&(this.onFulfilled=C,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(y,C,S){o(function(){var x;try{x=C(S)}catch($){return r.reject(y,$)}x===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,x)})}function b(y){var C=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof C=="function")return function(){C.apply(y,arguments)}}function m(y,C){var S=!1;function x(w){S||(S=!0,r.reject(y,w))}function $(w){S||(S=!0,r.resolve(y,w))}var T=v(function(){C($,x)});T.status==="error"&&x(T.value)}function v(y,C){var S={};try{S.value=y(C),S.status="success"}catch(x){S.status="error",S.value=x}return S}(n.exports=p).prototype.finally=function(y){if(typeof y!="function")return this;var C=this.constructor;return this.then(function(S){return C.resolve(y()).then(function(){return S})},function(S){return C.resolve(y()).then(function(){throw S})})},p.prototype.catch=function(y){return this.then(null,y)},p.prototype.then=function(y,C){if(typeof y!="function"&&this.state===c||typeof C!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?y:C,this.outcome):this.queue.push(new h(S,y,C)),S},h.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},h.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},h.prototype.callRejected=function(y){r.reject(this.promise,y)},h.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,C){var S=v(b,C);if(S.status==="error")return r.reject(y,S.value);var x=S.value;if(x)m(y,x);else{y.state=c,y.outcome=C;for(var $=-1,T=y.queue.length;++$<T;)y.queue[$].callFulfilled(C)}return y},r.reject=function(y,C){y.state=a,y.outcome=C;for(var S=-1,x=y.queue.length;++S<x;)y.queue[S].callRejected(C);return y},p.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},p.reject=function(y){var C=new this(l);return r.reject(C,y)},p.all=function(y){var C=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,x=!1;if(!S)return this.resolve([]);for(var $=new Array(S),T=0,w=-1,P=new this(l);++w<S;)N(y[w],w);return P;function N(H,K){C.resolve(H).then(function(_){$[K]=_,++T!==S||x||(x=!0,r.resolve(P,$))},function(_){x||(x=!0,r.reject(P,_))})}},p.race=function(y){var C=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,x=!1;if(!S)return this.resolve([]);for(var $=-1,T=new this(l);++$<S;)w=y[$],C.resolve(w).then(function(P){x||(x=!0,r.resolve(T,P))},function(P){x||(x=!0,r.reject(T,P))});var w;return T}},{immediate:36}],38:[function(t,n,s){var o={};(0,t("./lib/utils/common").assign)(o,t("./lib/deflate"),t("./lib/inflate"),t("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(t,n,s){var o=t("./zlib/deflate"),l=t("./utils/common"),r=t("./utils/strings"),a=t("./zlib/messages"),c=t("./zlib/zstream"),d=Object.prototype.toString,p=0,h=-1,u=0,b=8;function m(y){if(!(this instanceof m))return new m(y);this.options=l.assign({level:h,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var C=this.options;C.raw&&0<C.windowBits?C.windowBits=-C.windowBits:C.gzip&&0<C.windowBits&&C.windowBits<16&&(C.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=o.deflateInit2(this.strm,C.level,C.method,C.windowBits,C.memLevel,C.strategy);if(S!==p)throw new Error(a[S]);if(C.header&&o.deflateSetHeader(this.strm,C.header),C.dictionary){var x;if(x=typeof C.dictionary=="string"?r.string2buf(C.dictionary):d.call(C.dictionary)==="[object ArrayBuffer]"?new Uint8Array(C.dictionary):C.dictionary,(S=o.deflateSetDictionary(this.strm,x))!==p)throw new Error(a[S]);this._dict_set=!0}}function v(y,C){var S=new m(C);if(S.push(y,!0),S.err)throw S.msg||a[S.err];return S.result}m.prototype.push=function(y,C){var S,x,$=this.strm,T=this.options.chunkSize;if(this.ended)return!1;x=C===~~C?C:C===!0?4:0,typeof y=="string"?$.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?$.input=new Uint8Array(y):$.input=y,$.next_in=0,$.avail_in=$.input.length;do{if($.avail_out===0&&($.output=new l.Buf8(T),$.next_out=0,$.avail_out=T),(S=o.deflate($,x))!==1&&S!==p)return this.onEnd(S),!(this.ended=!0);$.avail_out!==0&&($.avail_in!==0||x!==4&&x!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf($.output,$.next_out))):this.onData(l.shrinkBuf($.output,$.next_out)))}while((0<$.avail_in||$.avail_out===0)&&S!==1);return x===4?(S=o.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===p):x!==2||(this.onEnd(p),!($.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=v,s.deflateRaw=function(y,C){return(C=C||{}).raw=!0,v(y,C)},s.gzip=function(y,C){return(C=C||{}).gzip=!0,v(y,C)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(t,n,s){var o=t("./zlib/inflate"),l=t("./utils/common"),r=t("./utils/strings"),a=t("./zlib/constants"),c=t("./zlib/messages"),d=t("./zlib/zstream"),p=t("./zlib/gzheader"),h=Object.prototype.toString;function u(m){if(!(this instanceof u))return new u(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||m&&m.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,v.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new p,o.inflateGetHeader(this.strm,this.header)}function b(m,v){var y=new u(v);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(m,v){var y,C,S,x,$,T,w=this.strm,P=this.options.chunkSize,N=this.options.dictionary,H=!1;if(this.ended)return!1;C=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?w.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?w.input=new Uint8Array(m):w.input=m,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(P),w.next_out=0,w.avail_out=P),(y=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&N&&(T=typeof N=="string"?r.string2buf(N):h.call(N)==="[object ArrayBuffer]"?new Uint8Array(N):N,y=o.inflateSetDictionary(this.strm,T)),y===a.Z_BUF_ERROR&&H===!0&&(y=a.Z_OK,H=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||C!==a.Z_FINISH&&C!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=r.utf8border(w.output,w.next_out),x=w.next_out-S,$=r.buf2string(w.output,S),w.next_out=x,w.avail_out=P-x,x&&l.arraySet(w.output,w.output,S,x,0),this.onData($)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(H=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(C=a.Z_FINISH),C===a.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):C!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(m){this.chunks.push(m)},u.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=u,s.inflate=b,s.inflateRaw=function(m,v){return(v=v||{}).raw=!0,b(m,v)},s.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(t,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,h){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),h);else for(var u=0;u<p;u++)a[h+u]=c[d+u]},flattenChunks:function(a){var c,d,p,h,u,b;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(b=new Uint8Array(p),c=h=0,d=a.length;c<d;c++)u=a[c],b.set(u,h),h+=u.length;return b}},r={arraySet:function(a,c,d,p,h){for(var u=0;u<p;u++)a[h+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(t,n,s){var o=t("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,h){if(h<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(p,h));for(var u="",b=0;b<h;b++)u+=String.fromCharCode(p[b]);return u}a[254]=a[254]=1,s.string2buf=function(p){var h,u,b,m,v,y=p.length,C=0;for(m=0;m<y;m++)(64512&(u=p.charCodeAt(m)))==55296&&m+1<y&&(64512&(b=p.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(b-56320),m++),C+=u<128?1:u<2048?2:u<65536?3:4;for(h=new o.Buf8(C),m=v=0;v<C;m++)(64512&(u=p.charCodeAt(m)))==55296&&m+1<y&&(64512&(b=p.charCodeAt(m+1)))==56320&&(u=65536+(u-55296<<10)+(b-56320),m++),u<128?h[v++]=u:(u<2048?h[v++]=192|u>>>6:(u<65536?h[v++]=224|u>>>12:(h[v++]=240|u>>>18,h[v++]=128|u>>>12&63),h[v++]=128|u>>>6&63),h[v++]=128|63&u);return h},s.buf2binstring=function(p){return d(p,p.length)},s.binstring2buf=function(p){for(var h=new o.Buf8(p.length),u=0,b=h.length;u<b;u++)h[u]=p.charCodeAt(u);return h},s.buf2string=function(p,h){var u,b,m,v,y=h||p.length,C=new Array(2*y);for(u=b=0;u<y;)if((m=p[u++])<128)C[b++]=m;else if(4<(v=a[m]))C[b++]=65533,u+=v-1;else{for(m&=v===2?31:v===3?15:7;1<v&&u<y;)m=m<<6|63&p[u++],v--;1<v?C[b++]=65533:m<65536?C[b++]=m:(m-=65536,C[b++]=55296|m>>10&1023,C[b++]=56320|1023&m)}return d(C,b)},s.utf8border=function(p,h){var u;for((h=h||p.length)>p.length&&(h=p.length),u=h-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?h:u+a[p[u]]>h?u:h}},{"./common":41}],43:[function(t,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(t,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(t,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,p=c+a;l^=-1;for(var h=c;h<p;h++)l=l>>>8^d[255&(l^r[h])];return-1^l}},{}],46:[function(t,n,s){var o,l=t("../utils/common"),r=t("./trees"),a=t("./adler32"),c=t("./crc32"),d=t("./messages"),p=0,h=4,u=0,b=-2,m=-1,v=4,y=2,C=8,S=9,x=286,$=30,T=19,w=2*x+1,P=15,N=3,H=258,K=H+N+1,_=42,F=113,k=1,M=2,j=3,A=4;function D(g,G){return g.msg=d[G],G}function O(g){return(g<<1)-(4<g?9:0)}function Q(g){for(var G=g.length;0<=--G;)g[G]=0}function W(g){var G=g.state,U=G.pending;U>g.avail_out&&(U=g.avail_out),U!==0&&(l.arraySet(g.output,G.pending_buf,G.pending_out,U,g.next_out),g.next_out+=U,G.pending_out+=U,g.total_out+=U,g.avail_out-=U,G.pending-=U,G.pending===0&&(G.pending_out=0))}function q(g,G){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,G),g.block_start=g.strstart,W(g.strm)}function re(g,G){g.pending_buf[g.pending++]=G}function ae(g,G){g.pending_buf[g.pending++]=G>>>8&255,g.pending_buf[g.pending++]=255&G}function ce(g,G){var U,I,E=g.max_chain_length,R=g.strstart,Y=g.prev_length,B=g.nice_match,z=g.strstart>g.w_size-K?g.strstart-(g.w_size-K):0,J=g.window,ne=g.w_mask,oe=g.prev,he=g.strstart+H,ie=J[R+Y-1],se=J[R+Y];g.prev_length>=g.good_match&&(E>>=2),B>g.lookahead&&(B=g.lookahead);do if(J[(U=G)+Y]===se&&J[U+Y-1]===ie&&J[U]===J[R]&&J[++U]===J[R+1]){R+=2,U++;do;while(J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&J[++R]===J[++U]&&R<he);if(I=H-(he-R),R=he-H,Y<I){if(g.match_start=G,B<=(Y=I))break;ie=J[R+Y-1],se=J[R+Y]}}while((G=oe[G&ne])>z&&--E!=0);return Y<=g.lookahead?Y:g.lookahead}function ge(g){var G,U,I,E,R,Y,B,z,J,ne,oe=g.w_size;do{if(E=g.window_size-g.lookahead-g.strstart,g.strstart>=oe+(oe-K)){for(l.arraySet(g.window,g.window,oe,oe,0),g.match_start-=oe,g.strstart-=oe,g.block_start-=oe,G=U=g.hash_size;I=g.head[--G],g.head[G]=oe<=I?I-oe:0,--U;);for(G=U=oe;I=g.prev[--G],g.prev[G]=oe<=I?I-oe:0,--U;);E+=oe}if(g.strm.avail_in===0)break;if(Y=g.strm,B=g.window,z=g.strstart+g.lookahead,J=E,ne=void 0,ne=Y.avail_in,J<ne&&(ne=J),U=ne===0?0:(Y.avail_in-=ne,l.arraySet(B,Y.input,Y.next_in,ne,z),Y.state.wrap===1?Y.adler=a(Y.adler,B,ne,z):Y.state.wrap===2&&(Y.adler=c(Y.adler,B,ne,z)),Y.next_in+=ne,Y.total_in+=ne,ne),g.lookahead+=U,g.lookahead+g.insert>=N)for(R=g.strstart-g.insert,g.ins_h=g.window[R],g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+N-1])&g.hash_mask,g.prev[R&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=R,R++,g.insert--,!(g.lookahead+g.insert<N)););}while(g.lookahead<K&&g.strm.avail_in!==0)}function Te(g,G){for(var U,I;;){if(g.lookahead<K){if(ge(g),g.lookahead<K&&G===p)return k;if(g.lookahead===0)break}if(U=0,g.lookahead>=N&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),U!==0&&g.strstart-U<=g.w_size-K&&(g.match_length=ce(g,U)),g.match_length>=N)if(I=r._tr_tally(g,g.strstart-g.match_start,g.match_length-N),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=N){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else I=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(I&&(q(g,!1),g.strm.avail_out===0))return k}return g.insert=g.strstart<N-1?g.strstart:N-1,G===h?(q(g,!0),g.strm.avail_out===0?j:A):g.last_lit&&(q(g,!1),g.strm.avail_out===0)?k:M}function Se(g,G){for(var U,I,E;;){if(g.lookahead<K){if(ge(g),g.lookahead<K&&G===p)return k;if(g.lookahead===0)break}if(U=0,g.lookahead>=N&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=N-1,U!==0&&g.prev_length<g.max_lazy_match&&g.strstart-U<=g.w_size-K&&(g.match_length=ce(g,U),g.match_length<=5&&(g.strategy===1||g.match_length===N&&4096<g.strstart-g.match_start)&&(g.match_length=N-1)),g.prev_length>=N&&g.match_length<=g.prev_length){for(E=g.strstart+g.lookahead-N,I=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-N),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=E&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,U=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=N-1,g.strstart++,I&&(q(g,!1),g.strm.avail_out===0))return k}else if(g.match_available){if((I=r._tr_tally(g,0,g.window[g.strstart-1]))&&q(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return k}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(I=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<N-1?g.strstart:N-1,G===h?(q(g,!0),g.strm.avail_out===0?j:A):g.last_lit&&(q(g,!1),g.strm.avail_out===0)?k:M}function fe(g,G,U,I,E){this.good_length=g,this.max_lazy=G,this.nice_length=U,this.max_chain=I,this.func=E}function Z(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=C,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*$+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),Q(this.dyn_ltree),Q(this.dyn_dtree),Q(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(P+1),this.heap=new l.Buf16(2*x+1),Q(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*x+1),Q(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(g){var G;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(G=g.state).pending=0,G.pending_out=0,G.wrap<0&&(G.wrap=-G.wrap),G.status=G.wrap?_:F,g.adler=G.wrap===2?0:1,G.last_flush=p,r._tr_init(G),u):D(g,b)}function L(g){var G=pe(g);return G===u&&(function(U){U.window_size=2*U.w_size,Q(U.head),U.max_lazy_match=o[U.level].max_lazy,U.good_match=o[U.level].good_length,U.nice_match=o[U.level].nice_length,U.max_chain_length=o[U.level].max_chain,U.strstart=0,U.block_start=0,U.lookahead=0,U.insert=0,U.match_length=U.prev_length=N-1,U.match_available=0,U.ins_h=0})(g.state),G}function V(g,G,U,I,E,R){if(!g)return b;var Y=1;if(G===m&&(G=6),I<0?(Y=0,I=-I):15<I&&(Y=2,I-=16),E<1||S<E||U!==C||I<8||15<I||G<0||9<G||R<0||v<R)return D(g,b);I===8&&(I=9);var B=new Z;return(g.state=B).strm=g,B.wrap=Y,B.gzhead=null,B.w_bits=I,B.w_size=1<<B.w_bits,B.w_mask=B.w_size-1,B.hash_bits=E+7,B.hash_size=1<<B.hash_bits,B.hash_mask=B.hash_size-1,B.hash_shift=~~((B.hash_bits+N-1)/N),B.window=new l.Buf8(2*B.w_size),B.head=new l.Buf16(B.hash_size),B.prev=new l.Buf16(B.w_size),B.lit_bufsize=1<<E+6,B.pending_buf_size=4*B.lit_bufsize,B.pending_buf=new l.Buf8(B.pending_buf_size),B.d_buf=1*B.lit_bufsize,B.l_buf=3*B.lit_bufsize,B.level=G,B.strategy=R,B.method=U,L(g)}o=[new fe(0,0,0,0,function(g,G){var U=65535;for(U>g.pending_buf_size-5&&(U=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ge(g),g.lookahead===0&&G===p)return k;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var I=g.block_start+U;if((g.strstart===0||g.strstart>=I)&&(g.lookahead=g.strstart-I,g.strstart=I,q(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-K&&(q(g,!1),g.strm.avail_out===0))return k}return g.insert=0,G===h?(q(g,!0),g.strm.avail_out===0?j:A):(g.strstart>g.block_start&&(q(g,!1),g.strm.avail_out),k)}),new fe(4,4,8,4,Te),new fe(4,5,16,8,Te),new fe(4,6,32,32,Te),new fe(4,4,16,16,Se),new fe(8,16,32,32,Se),new fe(8,16,128,128,Se),new fe(8,32,128,256,Se),new fe(32,128,258,1024,Se),new fe(32,258,258,4096,Se)],s.deflateInit=function(g,G){return V(g,G,C,15,8,0)},s.deflateInit2=V,s.deflateReset=L,s.deflateResetKeep=pe,s.deflateSetHeader=function(g,G){return g&&g.state?g.state.wrap!==2?b:(g.state.gzhead=G,u):b},s.deflate=function(g,G){var U,I,E,R;if(!g||!g.state||5<G||G<0)return g?D(g,b):b;if(I=g.state,!g.output||!g.input&&g.avail_in!==0||I.status===666&&G!==h)return D(g,g.avail_out===0?-5:b);if(I.strm=g,U=I.last_flush,I.last_flush=G,I.status===_)if(I.wrap===2)g.adler=0,re(I,31),re(I,139),re(I,8),I.gzhead?(re(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),re(I,255&I.gzhead.time),re(I,I.gzhead.time>>8&255),re(I,I.gzhead.time>>16&255),re(I,I.gzhead.time>>24&255),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(re(I,255&I.gzhead.extra.length),re(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(g.adler=c(g.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(re(I,0),re(I,0),re(I,0),re(I,0),re(I,0),re(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),re(I,3),I.status=F);else{var Y=C+(I.w_bits-8<<4)<<8;Y|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(Y|=32),Y+=31-Y%31,I.status=F,ae(I,Y),I.strstart!==0&&(ae(I,g.adler>>>16),ae(I,65535&g.adler)),g.adler=1}if(I.status===69)if(I.gzhead.extra){for(E=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending!==I.pending_buf_size));)re(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){E=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending===I.pending_buf_size)){R=1;break}R=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,re(I,R)}while(R!==0);I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),R===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){E=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),W(g),E=I.pending,I.pending===I.pending_buf_size)){R=1;break}R=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,re(I,R)}while(R!==0);I.gzhead.hcrc&&I.pending>E&&(g.adler=c(g.adler,I.pending_buf,I.pending-E,E)),R===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&W(g),I.pending+2<=I.pending_buf_size&&(re(I,255&g.adler),re(I,g.adler>>8&255),g.adler=0,I.status=F)):I.status=F),I.pending!==0){if(W(g),g.avail_out===0)return I.last_flush=-1,u}else if(g.avail_in===0&&O(G)<=O(U)&&G!==h)return D(g,-5);if(I.status===666&&g.avail_in!==0)return D(g,-5);if(g.avail_in!==0||I.lookahead!==0||G!==p&&I.status!==666){var B=I.strategy===2?(function(z,J){for(var ne;;){if(z.lookahead===0&&(ge(z),z.lookahead===0)){if(J===p)return k;break}if(z.match_length=0,ne=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++,ne&&(q(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(q(z,!0),z.strm.avail_out===0?j:A):z.last_lit&&(q(z,!1),z.strm.avail_out===0)?k:M})(I,G):I.strategy===3?(function(z,J){for(var ne,oe,he,ie,se=z.window;;){if(z.lookahead<=H){if(ge(z),z.lookahead<=H&&J===p)return k;if(z.lookahead===0)break}if(z.match_length=0,z.lookahead>=N&&0<z.strstart&&(oe=se[he=z.strstart-1])===se[++he]&&oe===se[++he]&&oe===se[++he]){ie=z.strstart+H;do;while(oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&oe===se[++he]&&he<ie);z.match_length=H-(ie-he),z.match_length>z.lookahead&&(z.match_length=z.lookahead)}if(z.match_length>=N?(ne=r._tr_tally(z,1,z.match_length-N),z.lookahead-=z.match_length,z.strstart+=z.match_length,z.match_length=0):(ne=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++),ne&&(q(z,!1),z.strm.avail_out===0))return k}return z.insert=0,J===h?(q(z,!0),z.strm.avail_out===0?j:A):z.last_lit&&(q(z,!1),z.strm.avail_out===0)?k:M})(I,G):o[I.level].func(I,G);if(B!==j&&B!==A||(I.status=666),B===k||B===j)return g.avail_out===0&&(I.last_flush=-1),u;if(B===M&&(G===1?r._tr_align(I):G!==5&&(r._tr_stored_block(I,0,0,!1),G===3&&(Q(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),W(g),g.avail_out===0))return I.last_flush=-1,u}return G!==h?u:I.wrap<=0?1:(I.wrap===2?(re(I,255&g.adler),re(I,g.adler>>8&255),re(I,g.adler>>16&255),re(I,g.adler>>24&255),re(I,255&g.total_in),re(I,g.total_in>>8&255),re(I,g.total_in>>16&255),re(I,g.total_in>>24&255)):(ae(I,g.adler>>>16),ae(I,65535&g.adler)),W(g),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?u:1)},s.deflateEnd=function(g){var G;return g&&g.state?(G=g.state.status)!==_&&G!==69&&G!==73&&G!==91&&G!==103&&G!==F&&G!==666?D(g,b):(g.state=null,G===F?D(g,-3):u):b},s.deflateSetDictionary=function(g,G){var U,I,E,R,Y,B,z,J,ne=G.length;if(!g||!g.state||(R=(U=g.state).wrap)===2||R===1&&U.status!==_||U.lookahead)return b;for(R===1&&(g.adler=a(g.adler,G,ne,0)),U.wrap=0,ne>=U.w_size&&(R===0&&(Q(U.head),U.strstart=0,U.block_start=0,U.insert=0),J=new l.Buf8(U.w_size),l.arraySet(J,G,ne-U.w_size,U.w_size,0),G=J,ne=U.w_size),Y=g.avail_in,B=g.next_in,z=g.input,g.avail_in=ne,g.next_in=0,g.input=G,ge(U);U.lookahead>=N;){for(I=U.strstart,E=U.lookahead-(N-1);U.ins_h=(U.ins_h<<U.hash_shift^U.window[I+N-1])&U.hash_mask,U.prev[I&U.w_mask]=U.head[U.ins_h],U.head[U.ins_h]=I,I++,--E;);U.strstart=I,U.lookahead=N-1,ge(U)}return U.strstart+=U.lookahead,U.block_start=U.strstart,U.insert=U.lookahead,U.lookahead=0,U.match_length=U.prev_length=N-1,U.match_available=0,g.next_in=B,g.input=z,g.avail_in=Y,U.wrap=R,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(t,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(t,n,s){n.exports=function(o,l){var r,a,c,d,p,h,u,b,m,v,y,C,S,x,$,T,w,P,N,H,K,_,F,k,M;r=o.state,a=o.next_in,k=o.input,c=a+(o.avail_in-5),d=o.next_out,M=o.output,p=d-(l-o.avail_out),h=d+(o.avail_out-257),u=r.dmax,b=r.wsize,m=r.whave,v=r.wnext,y=r.window,C=r.hold,S=r.bits,x=r.lencode,$=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{S<15&&(C+=k[a++]<<S,S+=8,C+=k[a++]<<S,S+=8),P=x[C&T];t:for(;;){if(C>>>=N=P>>>24,S-=N,(N=P>>>16&255)===0)M[d++]=65535&P;else{if(!(16&N)){if((64&N)==0){P=x[(65535&P)+(C&(1<<N)-1)];continue t}if(32&N){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}H=65535&P,(N&=15)&&(S<N&&(C+=k[a++]<<S,S+=8),H+=C&(1<<N)-1,C>>>=N,S-=N),S<15&&(C+=k[a++]<<S,S+=8,C+=k[a++]<<S,S+=8),P=$[C&w];i:for(;;){if(C>>>=N=P>>>24,S-=N,!(16&(N=P>>>16&255))){if((64&N)==0){P=$[(65535&P)+(C&(1<<N)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&P,S<(N&=15)&&(C+=k[a++]<<S,(S+=8)<N&&(C+=k[a++]<<S,S+=8)),u<(K+=C&(1<<N)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(C>>>=N,S-=N,(N=d-p)<K){if(m<(N=K-N)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(F=y,(_=0)===v){if(_+=b-N,N<H){for(H-=N;M[d++]=y[_++],--N;);_=d-K,F=M}}else if(v<N){if(_+=b+v-N,(N-=v)<H){for(H-=N;M[d++]=y[_++],--N;);if(_=0,v<H){for(H-=N=v;M[d++]=y[_++],--N;);_=d-K,F=M}}}else if(_+=v-N,N<H){for(H-=N;M[d++]=y[_++],--N;);_=d-K,F=M}for(;2<H;)M[d++]=F[_++],M[d++]=F[_++],M[d++]=F[_++],H-=3;H&&(M[d++]=F[_++],1<H&&(M[d++]=F[_++]))}else{for(_=d-K;M[d++]=M[_++],M[d++]=M[_++],M[d++]=M[_++],2<(H-=3););H&&(M[d++]=M[_++],1<H&&(M[d++]=M[_++]))}break}}break}}while(a<c&&d<h);a-=H=S>>3,C&=(1<<(S-=H<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<h?h-d+257:257-(d-h),r.hold=C,r.bits=S}},{}],49:[function(t,n,s){var o=t("../utils/common"),l=t("./adler32"),r=t("./crc32"),a=t("./inffast"),c=t("./inftrees"),d=1,p=2,h=0,u=-2,b=1,m=852,v=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function C(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(_){var F;return _&&_.state?(F=_.state,_.total_in=_.total_out=F.total=0,_.msg="",F.wrap&&(_.adler=1&F.wrap),F.mode=b,F.last=0,F.havedict=0,F.dmax=32768,F.head=null,F.hold=0,F.bits=0,F.lencode=F.lendyn=new o.Buf32(m),F.distcode=F.distdyn=new o.Buf32(v),F.sane=1,F.back=-1,h):u}function x(_){var F;return _&&_.state?((F=_.state).wsize=0,F.whave=0,F.wnext=0,S(_)):u}function $(_,F){var k,M;return _&&_.state?(M=_.state,F<0?(k=0,F=-F):(k=1+(F>>4),F<48&&(F&=15)),F&&(F<8||15<F)?u:(M.window!==null&&M.wbits!==F&&(M.window=null),M.wrap=k,M.wbits=F,x(_))):u}function T(_,F){var k,M;return _?(M=new C,(_.state=M).window=null,(k=$(_,F))!==h&&(_.state=null),k):u}var w,P,N=!0;function H(_){if(N){var F;for(w=new o.Buf32(512),P=new o.Buf32(32),F=0;F<144;)_.lens[F++]=8;for(;F<256;)_.lens[F++]=9;for(;F<280;)_.lens[F++]=7;for(;F<288;)_.lens[F++]=8;for(c(d,_.lens,0,288,w,0,_.work,{bits:9}),F=0;F<32;)_.lens[F++]=5;c(p,_.lens,0,32,P,0,_.work,{bits:5}),N=!1}_.lencode=w,_.lenbits=9,_.distcode=P,_.distbits=5}function K(_,F,k,M){var j,A=_.state;return A.window===null&&(A.wsize=1<<A.wbits,A.wnext=0,A.whave=0,A.window=new o.Buf8(A.wsize)),M>=A.wsize?(o.arraySet(A.window,F,k-A.wsize,A.wsize,0),A.wnext=0,A.whave=A.wsize):(M<(j=A.wsize-A.wnext)&&(j=M),o.arraySet(A.window,F,k-M,j,A.wnext),(M-=j)?(o.arraySet(A.window,F,k-M,M,0),A.wnext=M,A.whave=A.wsize):(A.wnext+=j,A.wnext===A.wsize&&(A.wnext=0),A.whave<A.wsize&&(A.whave+=j))),0}s.inflateReset=x,s.inflateReset2=$,s.inflateResetKeep=S,s.inflateInit=function(_){return T(_,15)},s.inflateInit2=T,s.inflate=function(_,F){var k,M,j,A,D,O,Q,W,q,re,ae,ce,ge,Te,Se,fe,Z,pe,L,V,g,G,U,I,E=0,R=new o.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return u;(k=_.state).mode===12&&(k.mode=13),D=_.next_out,j=_.output,Q=_.avail_out,A=_.next_in,M=_.input,O=_.avail_in,W=k.hold,q=k.bits,re=O,ae=Q,G=h;e:for(;;)switch(k.mode){case b:if(k.wrap===0){k.mode=13;break}for(;q<16;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(2&k.wrap&&W===35615){R[k.check=0]=255&W,R[1]=W>>>8&255,k.check=r(k.check,R,2,0),q=W=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&W)<<8)+(W>>8))%31){_.msg="incorrect header check",k.mode=30;break}if((15&W)!=8){_.msg="unknown compression method",k.mode=30;break}if(q-=4,g=8+(15&(W>>>=4)),k.wbits===0)k.wbits=g;else if(g>k.wbits){_.msg="invalid window size",k.mode=30;break}k.dmax=1<<g,_.adler=k.check=1,k.mode=512&W?10:12,q=W=0;break;case 2:for(;q<16;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(k.flags=W,(255&k.flags)!=8){_.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){_.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=W>>8&1),512&k.flags&&(R[0]=255&W,R[1]=W>>>8&255,k.check=r(k.check,R,2,0)),q=W=0,k.mode=3;case 3:for(;q<32;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.head&&(k.head.time=W),512&k.flags&&(R[0]=255&W,R[1]=W>>>8&255,R[2]=W>>>16&255,R[3]=W>>>24&255,k.check=r(k.check,R,4,0)),q=W=0,k.mode=4;case 4:for(;q<16;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.head&&(k.head.xflags=255&W,k.head.os=W>>8),512&k.flags&&(R[0]=255&W,R[1]=W>>>8&255,k.check=r(k.check,R,2,0)),q=W=0,k.mode=5;case 5:if(1024&k.flags){for(;q<16;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.length=W,k.head&&(k.head.extra_len=W),512&k.flags&&(R[0]=255&W,R[1]=W>>>8&255,k.check=r(k.check,R,2,0)),q=W=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(O<(ce=k.length)&&(ce=O),ce&&(k.head&&(g=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,M,A,ce,g)),512&k.flags&&(k.check=r(k.check,M,ce,A)),O-=ce,A+=ce,k.length-=ce),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(O===0)break e;for(ce=0;g=M[A+ce++],k.head&&g&&k.length<65536&&(k.head.name+=String.fromCharCode(g)),g&&ce<O;);if(512&k.flags&&(k.check=r(k.check,M,ce,A)),O-=ce,A+=ce,g)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(O===0)break e;for(ce=0;g=M[A+ce++],k.head&&g&&k.length<65536&&(k.head.comment+=String.fromCharCode(g)),g&&ce<O;);if(512&k.flags&&(k.check=r(k.check,M,ce,A)),O-=ce,A+=ce,g)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;q<16;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(W!==(65535&k.check)){_.msg="header crc mismatch",k.mode=30;break}q=W=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),_.adler=k.check=0,k.mode=12;break;case 10:for(;q<32;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}_.adler=k.check=y(W),q=W=0,k.mode=11;case 11:if(k.havedict===0)return _.next_out=D,_.avail_out=Q,_.next_in=A,_.avail_in=O,k.hold=W,k.bits=q,2;_.adler=k.check=1,k.mode=12;case 12:if(F===5||F===6)break e;case 13:if(k.last){W>>>=7&q,q-=7&q,k.mode=27;break}for(;q<3;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}switch(k.last=1&W,q-=1,3&(W>>>=1)){case 0:k.mode=14;break;case 1:if(H(k),k.mode=20,F!==6)break;W>>>=2,q-=2;break e;case 2:k.mode=17;break;case 3:_.msg="invalid block type",k.mode=30}W>>>=2,q-=2;break;case 14:for(W>>>=7&q,q-=7&q;q<32;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if((65535&W)!=(W>>>16^65535)){_.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&W,q=W=0,k.mode=15,F===6)break e;case 15:k.mode=16;case 16:if(ce=k.length){if(O<ce&&(ce=O),Q<ce&&(ce=Q),ce===0)break e;o.arraySet(j,M,A,ce,D),O-=ce,A+=ce,Q-=ce,D+=ce,k.length-=ce;break}k.mode=12;break;case 17:for(;q<14;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(k.nlen=257+(31&W),W>>>=5,q-=5,k.ndist=1+(31&W),W>>>=5,q-=5,k.ncode=4+(15&W),W>>>=4,q-=4,286<k.nlen||30<k.ndist){_.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;q<3;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.lens[Y[k.have++]]=7&W,W>>>=3,q-=3}for(;k.have<19;)k.lens[Y[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,U={bits:k.lenbits},G=c(0,k.lens,0,19,k.lencode,0,k.work,U),k.lenbits=U.bits,G){_.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;fe=(E=k.lencode[W&(1<<k.lenbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=q);){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(Z<16)W>>>=Se,q-=Se,k.lens[k.have++]=Z;else{if(Z===16){for(I=Se+2;q<I;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(W>>>=Se,q-=Se,k.have===0){_.msg="invalid bit length repeat",k.mode=30;break}g=k.lens[k.have-1],ce=3+(3&W),W>>>=2,q-=2}else if(Z===17){for(I=Se+3;q<I;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}q-=Se,g=0,ce=3+(7&(W>>>=Se)),W>>>=3,q-=3}else{for(I=Se+7;q<I;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}q-=Se,g=0,ce=11+(127&(W>>>=Se)),W>>>=7,q-=7}if(k.have+ce>k.nlen+k.ndist){_.msg="invalid bit length repeat",k.mode=30;break}for(;ce--;)k.lens[k.have++]=g}}if(k.mode===30)break;if(k.lens[256]===0){_.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,U={bits:k.lenbits},G=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,U),k.lenbits=U.bits,G){_.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,U={bits:k.distbits},G=c(p,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,U),k.distbits=U.bits,G){_.msg="invalid distances set",k.mode=30;break}if(k.mode=20,F===6)break e;case 20:k.mode=21;case 21:if(6<=O&&258<=Q){_.next_out=D,_.avail_out=Q,_.next_in=A,_.avail_in=O,k.hold=W,k.bits=q,a(_,ae),D=_.next_out,j=_.output,Q=_.avail_out,A=_.next_in,M=_.input,O=_.avail_in,W=k.hold,q=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;fe=(E=k.lencode[W&(1<<k.lenbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=q);){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(fe&&(240&fe)==0){for(pe=Se,L=fe,V=Z;fe=(E=k.lencode[V+((W&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&E,!(pe+(Se=E>>>24)<=q);){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}W>>>=pe,q-=pe,k.back+=pe}if(W>>>=Se,q-=Se,k.back+=Se,k.length=Z,fe===0){k.mode=26;break}if(32&fe){k.back=-1,k.mode=12;break}if(64&fe){_.msg="invalid literal/length code",k.mode=30;break}k.extra=15&fe,k.mode=22;case 22:if(k.extra){for(I=k.extra;q<I;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.length+=W&(1<<k.extra)-1,W>>>=k.extra,q-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;fe=(E=k.distcode[W&(1<<k.distbits)-1])>>>16&255,Z=65535&E,!((Se=E>>>24)<=q);){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if((240&fe)==0){for(pe=Se,L=fe,V=Z;fe=(E=k.distcode[V+((W&(1<<pe+L)-1)>>pe)])>>>16&255,Z=65535&E,!(pe+(Se=E>>>24)<=q);){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}W>>>=pe,q-=pe,k.back+=pe}if(W>>>=Se,q-=Se,k.back+=Se,64&fe){_.msg="invalid distance code",k.mode=30;break}k.offset=Z,k.extra=15&fe,k.mode=24;case 24:if(k.extra){for(I=k.extra;q<I;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}k.offset+=W&(1<<k.extra)-1,W>>>=k.extra,q-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){_.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(Q===0)break e;if(ce=ae-Q,k.offset>ce){if((ce=k.offset-ce)>k.whave&&k.sane){_.msg="invalid distance too far back",k.mode=30;break}ge=ce>k.wnext?(ce-=k.wnext,k.wsize-ce):k.wnext-ce,ce>k.length&&(ce=k.length),Te=k.window}else Te=j,ge=D-k.offset,ce=k.length;for(Q<ce&&(ce=Q),Q-=ce,k.length-=ce;j[D++]=Te[ge++],--ce;);k.length===0&&(k.mode=21);break;case 26:if(Q===0)break e;j[D++]=k.length,Q--,k.mode=21;break;case 27:if(k.wrap){for(;q<32;){if(O===0)break e;O--,W|=M[A++]<<q,q+=8}if(ae-=Q,_.total_out+=ae,k.total+=ae,ae&&(_.adler=k.check=k.flags?r(k.check,j,ae,D-ae):l(k.check,j,ae,D-ae)),ae=Q,(k.flags?W:y(W))!==k.check){_.msg="incorrect data check",k.mode=30;break}q=W=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;q<32;){if(O===0)break e;O--,W+=M[A++]<<q,q+=8}if(W!==(4294967295&k.total)){_.msg="incorrect length check",k.mode=30;break}q=W=0}k.mode=29;case 29:G=1;break e;case 30:G=-3;break e;case 31:return-4;case 32:default:return u}return _.next_out=D,_.avail_out=Q,_.next_in=A,_.avail_in=O,k.hold=W,k.bits=q,(k.wsize||ae!==_.avail_out&&k.mode<30&&(k.mode<27||F!==4))&&K(_,_.output,_.next_out,ae-_.avail_out)?(k.mode=31,-4):(re-=_.avail_in,ae-=_.avail_out,_.total_in+=re,_.total_out+=ae,k.total+=ae,k.wrap&&ae&&(_.adler=k.check=k.flags?r(k.check,j,ae,_.next_out-ae):l(k.check,j,ae,_.next_out-ae)),_.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(re==0&&ae===0||F===4)&&G===h&&(G=-5),G)},s.inflateEnd=function(_){if(!_||!_.state)return u;var F=_.state;return F.window&&(F.window=null),_.state=null,h},s.inflateGetHeader=function(_,F){var k;return _&&_.state?(2&(k=_.state).wrap)==0?u:((k.head=F).done=!1,h):u},s.inflateSetDictionary=function(_,F){var k,M=F.length;return _&&_.state?(k=_.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,F,M,0)!==k.check?-3:K(_,F,M,M)?(k.mode=31,-4):(k.havedict=1,h):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(t,n,s){var o=t("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,h,u,b,m,v,y){var C,S,x,$,T,w,P,N,H,K=y.bits,_=0,F=0,k=0,M=0,j=0,A=0,D=0,O=0,Q=0,W=0,q=null,re=0,ae=new o.Buf16(16),ce=new o.Buf16(16),ge=null,Te=0;for(_=0;_<=15;_++)ae[_]=0;for(F=0;F<u;F++)ae[p[h+F]]++;for(j=K,M=15;1<=M&&ae[M]===0;M--);if(M<j&&(j=M),M===0)return b[m++]=20971520,b[m++]=20971520,y.bits=1,0;for(k=1;k<M&&ae[k]===0;k++);for(j<k&&(j=k),_=O=1;_<=15;_++)if(O<<=1,(O-=ae[_])<0)return-1;if(0<O&&(d===0||M!==1))return-1;for(ce[1]=0,_=1;_<15;_++)ce[_+1]=ce[_]+ae[_];for(F=0;F<u;F++)p[h+F]!==0&&(v[ce[p[h+F]]++]=F);if(w=d===0?(q=ge=v,19):d===1?(q=l,re-=257,ge=r,Te-=257,256):(q=a,ge=c,-1),_=k,T=m,D=F=W=0,x=-1,$=(Q=1<<(A=j))-1,d===1&&852<Q||d===2&&592<Q)return 1;for(;;){for(P=_-D,H=v[F]<w?(N=0,v[F]):v[F]>w?(N=ge[Te+v[F]],q[re+v[F]]):(N=96,0),C=1<<_-D,k=S=1<<A;b[T+(W>>D)+(S-=C)]=P<<24|N<<16|H|0,S!==0;);for(C=1<<_-1;W&C;)C>>=1;if(C!==0?(W&=C-1,W+=C):W=0,F++,--ae[_]==0){if(_===M)break;_=p[h+v[F]]}if(j<_&&(W&$)!==x){for(D===0&&(D=j),T+=k,O=1<<(A=_-D);A+D<M&&!((O-=ae[A+D])<=0);)A++,O<<=1;if(Q+=1<<A,d===1&&852<Q||d===2&&592<Q)return 1;b[x=W&$]=j<<24|A<<16|T-m|0}}return W!==0&&(b[T+W]=_-D<<24|64<<16|0),y.bits=j,0}},{"../utils/common":41}],51:[function(t,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(t,n,s){var o=t("../utils/common"),l=0,r=1;function a(E){for(var R=E.length;0<=--R;)E[R]=0}var c=0,d=29,p=256,h=p+1+d,u=30,b=19,m=2*h+1,v=15,y=16,C=7,S=256,x=16,$=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],P=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],N=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],H=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(h+2));a(K);var _=new Array(2*u);a(_);var F=new Array(512);a(F);var k=new Array(256);a(k);var M=new Array(d);a(M);var j,A,D,O=new Array(u);function Q(E,R,Y,B,z){this.static_tree=E,this.extra_bits=R,this.extra_base=Y,this.elems=B,this.max_length=z,this.has_stree=E&&E.length}function W(E,R){this.dyn_tree=E,this.max_code=0,this.stat_desc=R}function q(E){return E<256?F[E]:F[256+(E>>>7)]}function re(E,R){E.pending_buf[E.pending++]=255&R,E.pending_buf[E.pending++]=R>>>8&255}function ae(E,R,Y){E.bi_valid>y-Y?(E.bi_buf|=R<<E.bi_valid&65535,re(E,E.bi_buf),E.bi_buf=R>>y-E.bi_valid,E.bi_valid+=Y-y):(E.bi_buf|=R<<E.bi_valid&65535,E.bi_valid+=Y)}function ce(E,R,Y){ae(E,Y[2*R],Y[2*R+1])}function ge(E,R){for(var Y=0;Y|=1&E,E>>>=1,Y<<=1,0<--R;);return Y>>>1}function Te(E,R,Y){var B,z,J=new Array(v+1),ne=0;for(B=1;B<=v;B++)J[B]=ne=ne+Y[B-1]<<1;for(z=0;z<=R;z++){var oe=E[2*z+1];oe!==0&&(E[2*z]=ge(J[oe]++,oe))}}function Se(E){var R;for(R=0;R<h;R++)E.dyn_ltree[2*R]=0;for(R=0;R<u;R++)E.dyn_dtree[2*R]=0;for(R=0;R<b;R++)E.bl_tree[2*R]=0;E.dyn_ltree[2*S]=1,E.opt_len=E.static_len=0,E.last_lit=E.matches=0}function fe(E){8<E.bi_valid?re(E,E.bi_buf):0<E.bi_valid&&(E.pending_buf[E.pending++]=E.bi_buf),E.bi_buf=0,E.bi_valid=0}function Z(E,R,Y,B){var z=2*R,J=2*Y;return E[z]<E[J]||E[z]===E[J]&&B[R]<=B[Y]}function pe(E,R,Y){for(var B=E.heap[Y],z=Y<<1;z<=E.heap_len&&(z<E.heap_len&&Z(R,E.heap[z+1],E.heap[z],E.depth)&&z++,!Z(R,B,E.heap[z],E.depth));)E.heap[Y]=E.heap[z],Y=z,z<<=1;E.heap[Y]=B}function L(E,R,Y){var B,z,J,ne,oe=0;if(E.last_lit!==0)for(;B=E.pending_buf[E.d_buf+2*oe]<<8|E.pending_buf[E.d_buf+2*oe+1],z=E.pending_buf[E.l_buf+oe],oe++,B===0?ce(E,z,R):(ce(E,(J=k[z])+p+1,R),(ne=w[J])!==0&&ae(E,z-=M[J],ne),ce(E,J=q(--B),Y),(ne=P[J])!==0&&ae(E,B-=O[J],ne)),oe<E.last_lit;);ce(E,S,R)}function V(E,R){var Y,B,z,J=R.dyn_tree,ne=R.stat_desc.static_tree,oe=R.stat_desc.has_stree,he=R.stat_desc.elems,ie=-1;for(E.heap_len=0,E.heap_max=m,Y=0;Y<he;Y++)J[2*Y]!==0?(E.heap[++E.heap_len]=ie=Y,E.depth[Y]=0):J[2*Y+1]=0;for(;E.heap_len<2;)J[2*(z=E.heap[++E.heap_len]=ie<2?++ie:0)]=1,E.depth[z]=0,E.opt_len--,oe&&(E.static_len-=ne[2*z+1]);for(R.max_code=ie,Y=E.heap_len>>1;1<=Y;Y--)pe(E,J,Y);for(z=he;Y=E.heap[1],E.heap[1]=E.heap[E.heap_len--],pe(E,J,1),B=E.heap[1],E.heap[--E.heap_max]=Y,E.heap[--E.heap_max]=B,J[2*z]=J[2*Y]+J[2*B],E.depth[z]=(E.depth[Y]>=E.depth[B]?E.depth[Y]:E.depth[B])+1,J[2*Y+1]=J[2*B+1]=z,E.heap[1]=z++,pe(E,J,1),2<=E.heap_len;);E.heap[--E.heap_max]=E.heap[1],(function(se,_e){var Ae,Ne,Oe,Be,Xt,ot,Je=_e.dyn_tree,zt=_e.max_code,Wi=_e.stat_desc.static_tree,Ks=_e.stat_desc.has_stree,qs=_e.stat_desc.extra_bits,Zn=_e.stat_desc.extra_base,Si=_e.stat_desc.max_length,Ui=0;for(Be=0;Be<=v;Be++)se.bl_count[Be]=0;for(Je[2*se.heap[se.heap_max]+1]=0,Ae=se.heap_max+1;Ae<m;Ae++)Si<(Be=Je[2*Je[2*(Ne=se.heap[Ae])+1]+1]+1)&&(Be=Si,Ui++),Je[2*Ne+1]=Be,zt<Ne||(se.bl_count[Be]++,Xt=0,Zn<=Ne&&(Xt=qs[Ne-Zn]),ot=Je[2*Ne],se.opt_len+=ot*(Be+Xt),Ks&&(se.static_len+=ot*(Wi[2*Ne+1]+Xt)));if(Ui!==0){do{for(Be=Si-1;se.bl_count[Be]===0;)Be--;se.bl_count[Be]--,se.bl_count[Be+1]+=2,se.bl_count[Si]--,Ui-=2}while(0<Ui);for(Be=Si;Be!==0;Be--)for(Ne=se.bl_count[Be];Ne!==0;)zt<(Oe=se.heap[--Ae])||(Je[2*Oe+1]!==Be&&(se.opt_len+=(Be-Je[2*Oe+1])*Je[2*Oe],Je[2*Oe+1]=Be),Ne--)}})(E,R),Te(J,ie,E.bl_count)}function g(E,R,Y){var B,z,J=-1,ne=R[1],oe=0,he=7,ie=4;for(ne===0&&(he=138,ie=3),R[2*(Y+1)+1]=65535,B=0;B<=Y;B++)z=ne,ne=R[2*(B+1)+1],++oe<he&&z===ne||(oe<ie?E.bl_tree[2*z]+=oe:z!==0?(z!==J&&E.bl_tree[2*z]++,E.bl_tree[2*x]++):oe<=10?E.bl_tree[2*$]++:E.bl_tree[2*T]++,J=z,ie=(oe=0)===ne?(he=138,3):z===ne?(he=6,3):(he=7,4))}function G(E,R,Y){var B,z,J=-1,ne=R[1],oe=0,he=7,ie=4;for(ne===0&&(he=138,ie=3),B=0;B<=Y;B++)if(z=ne,ne=R[2*(B+1)+1],!(++oe<he&&z===ne)){if(oe<ie)for(;ce(E,z,E.bl_tree),--oe!=0;);else z!==0?(z!==J&&(ce(E,z,E.bl_tree),oe--),ce(E,x,E.bl_tree),ae(E,oe-3,2)):oe<=10?(ce(E,$,E.bl_tree),ae(E,oe-3,3)):(ce(E,T,E.bl_tree),ae(E,oe-11,7));J=z,ie=(oe=0)===ne?(he=138,3):z===ne?(he=6,3):(he=7,4)}}a(O);var U=!1;function I(E,R,Y,B){ae(E,(c<<1)+(B?1:0),3),(function(z,J,ne,oe){fe(z),re(z,ne),re(z,~ne),o.arraySet(z.pending_buf,z.window,J,ne,z.pending),z.pending+=ne})(E,R,Y)}s._tr_init=function(E){U||((function(){var R,Y,B,z,J,ne=new Array(v+1);for(z=B=0;z<d-1;z++)for(M[z]=B,R=0;R<1<<w[z];R++)k[B++]=z;for(k[B-1]=z,z=J=0;z<16;z++)for(O[z]=J,R=0;R<1<<P[z];R++)F[J++]=z;for(J>>=7;z<u;z++)for(O[z]=J<<7,R=0;R<1<<P[z]-7;R++)F[256+J++]=z;for(Y=0;Y<=v;Y++)ne[Y]=0;for(R=0;R<=143;)K[2*R+1]=8,R++,ne[8]++;for(;R<=255;)K[2*R+1]=9,R++,ne[9]++;for(;R<=279;)K[2*R+1]=7,R++,ne[7]++;for(;R<=287;)K[2*R+1]=8,R++,ne[8]++;for(Te(K,h+1,ne),R=0;R<u;R++)_[2*R+1]=5,_[2*R]=ge(R,5);j=new Q(K,w,p+1,h,v),A=new Q(_,P,0,u,v),D=new Q(new Array(0),N,0,b,C)})(),U=!0),E.l_desc=new W(E.dyn_ltree,j),E.d_desc=new W(E.dyn_dtree,A),E.bl_desc=new W(E.bl_tree,D),E.bi_buf=0,E.bi_valid=0,Se(E)},s._tr_stored_block=I,s._tr_flush_block=function(E,R,Y,B){var z,J,ne=0;0<E.level?(E.strm.data_type===2&&(E.strm.data_type=(function(oe){var he,ie=4093624447;for(he=0;he<=31;he++,ie>>>=1)if(1&ie&&oe.dyn_ltree[2*he]!==0)return l;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(he=32;he<p;he++)if(oe.dyn_ltree[2*he]!==0)return r;return l})(E)),V(E,E.l_desc),V(E,E.d_desc),ne=(function(oe){var he;for(g(oe,oe.dyn_ltree,oe.l_desc.max_code),g(oe,oe.dyn_dtree,oe.d_desc.max_code),V(oe,oe.bl_desc),he=b-1;3<=he&&oe.bl_tree[2*H[he]+1]===0;he--);return oe.opt_len+=3*(he+1)+5+5+4,he})(E),z=E.opt_len+3+7>>>3,(J=E.static_len+3+7>>>3)<=z&&(z=J)):z=J=Y+5,Y+4<=z&&R!==-1?I(E,R,Y,B):E.strategy===4||J===z?(ae(E,2+(B?1:0),3),L(E,K,_)):(ae(E,4+(B?1:0),3),(function(oe,he,ie,se){var _e;for(ae(oe,he-257,5),ae(oe,ie-1,5),ae(oe,se-4,4),_e=0;_e<se;_e++)ae(oe,oe.bl_tree[2*H[_e]+1],3);G(oe,oe.dyn_ltree,he-1),G(oe,oe.dyn_dtree,ie-1)})(E,E.l_desc.max_code+1,E.d_desc.max_code+1,ne+1),L(E,E.dyn_ltree,E.dyn_dtree)),Se(E),B&&fe(E)},s._tr_tally=function(E,R,Y){return E.pending_buf[E.d_buf+2*E.last_lit]=R>>>8&255,E.pending_buf[E.d_buf+2*E.last_lit+1]=255&R,E.pending_buf[E.l_buf+E.last_lit]=255&Y,E.last_lit++,R===0?E.dyn_ltree[2*Y]++:(E.matches++,R--,E.dyn_ltree[2*(k[Y]+p+1)]++,E.dyn_dtree[2*q(R)]++),E.last_lit===E.lit_bufsize-1},s._tr_align=function(E){ae(E,2,3),ce(E,S,K),(function(R){R.bi_valid===16?(re(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(E)}},{"../utils/common":41}],53:[function(t,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(t,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,p,h=1,u={},b=!1,m=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(x){process.nextTick(function(){C(x)})}:(function(){if(l.postMessage&&!l.importScripts){var x=!0,$=l.onmessage;return l.onmessage=function(){x=!1},l.postMessage("","*"),l.onmessage=$,x}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(x){l.postMessage(p+x,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(x){C(x.data)},function(x){d.port2.postMessage(x)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(x){var $=m.createElement("script");$.onreadystatechange=function(){C(x),$.onreadystatechange=null,c.removeChild($),$=null},c.appendChild($)}):function(x){setTimeout(C,0,x)},v.setImmediate=function(x){typeof x!="function"&&(x=new Function(""+x));for(var $=new Array(arguments.length-1),T=0;T<$.length;T++)$[T]=arguments[T+1];var w={callback:x,args:$};return u[h]=w,a(h),h++},v.clearImmediate=y}function y(x){delete u[x]}function C(x){if(b)setTimeout(C,0,x);else{var $=u[x];if($){b=!0;try{(function(T){var w=T.callback,P=T.args;switch(P.length){case 0:w();break;case 1:w(P[0]);break;case 2:w(P[0],P[1]);break;case 3:w(P[0],P[1],P[2]);break;default:w.apply(r,P)}})($)}finally{y(x),b=!1}}}}function S(x){x.source===l&&typeof x.data=="string"&&x.data.indexOf(p)===0&&C(+x.data.slice(p.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof os<"u"?os:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(fo)),fo.exports}var ng=ig();const Wa=tg(ng);function Ua(e){const i=(e||"").trim();return i?`即现（${i}）`:"即现"}async function Va(e,i){var t,n,s;if(!i)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||(e.getActiveDocumentId()===i?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===i){const o=(t=e.latestCompiledDoc.slides)==null?void 0:t[0],l=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const o=await rn(`SELECT content FROM blocks WHERE id = '${i}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function sg(e,i,t){var c,d,p;const n=aw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&t&&t!==o)return;const l=t||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(i||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Va(e,l));const a=Ua(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of h){const b=u.querySelector(".item__text"),m=((p=b==null?void 0:b.textContent)==null?void 0:p.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){b&&(b.textContent=a),u.setAttribute("title",a);break}}}}function Sn(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Hi(e,i,t){var s,o;const n=i||(e==null?void 0:e.docId)||"";if(t&&typeof t.fetchDocumentTitle=="function"&&n)try{const l=await t.fetchDocumentTitle(n);if(l&&l.trim())return Sn(l)}catch{}if(typeof document<"u")try{const l=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Sn(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Sn(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Sn(a)}return"presentation"}function og(e,i){if(typeof document>"u")return!1;const t=URL.createObjectURL(i),n=document.createElement("a");return n.href=t,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(t),!0}function il(e,i){if(typeof document>"u")return!1;const t=document.createElement("a");return t.href=i,t.download=e,document.body.appendChild(t),t.click(),document.body.removeChild(t),!0}async function rg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const t=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[t.type||"image/png"]:t})]),!0}catch(i){return console.warn("[image-exporter] 复制图像至剪贴板失败:",i),!1}}async function Ro(e,i){return new Promise(t=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(a=>a()),n=[]};s=setTimeout(()=>{o(),t({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{o(),t({success:!0,dataUrl:a.dataUrl})});n.push(l);const r=e.onCaptureError(a=>{o(),t({success:!1,error:a})});n.push(r),e.startImageExport({mode:"current",scale:(i==null?void 0:i.scale)||2,format:(i==null?void 0:i.format)||"png"})})}async function Ga(e,i){const t=[],n=Sn((i==null?void 0:i.title)||"presentation");return new Promise(s=>{let o=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),o.forEach(u=>u()),o=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(u=>{var b;a(),(b=i==null?void 0:i.onProgress)==null||b.call(i,u.current,u.total,u.pageIndex)});o.push(c);const d=e.onCapturePageDone(u=>{a(),(u.mode==="all"||!u.mode)&&t.push({pageIndex:u.pageIndex,dataUrl:u.dataUrl})});o.push(d);const p=async()=>{r();try{if(t.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const u=new Wa,b=(i==null?void 0:i.format)==="jpeg"?"jpg":"png";for(const y of t){const C=String(y.pageIndex).padStart(2,"0"),S=y.dataUrl.split(",")[1];u.file(`slide-${C}.${b}`,S,{base64:!0})}const m=await u.generateAsync({type:"blob",compression:"DEFLATE"}),v=og(`${n}.zip`,m);s({success:v,total:t.length})}catch(u){s({success:!1,error:(u==null?void 0:u.message)||String(u)})}};o.push(e.onCaptureComplete(p));const h=e.onCaptureError(u=>{r(),s({success:!1,error:u})});o.push(h),e.startImageExport({mode:"all",scale:(i==null?void 0:i.scale)||2,format:(i==null?void 0:i.format)||"png"})})}async function Ka(e,i){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const t=document.createElement("iframe");t.style.position="fixed",t.style.left="-9999px",t.style.top="-9999px",t.style.width="1920px",t.style.height="1080px",t.style.opacity="0",t.style.pointerEvents="none",t.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(t);const n=new Yn;n.attach(t);try{if(await new Promise((s,o)=>{const l=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(l),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(i==null?void 0:i.mode)==="current"){const s=await Ro(n,i);return{success:s.success,total:1,error:s.error}}else{const s=(i==null?void 0:i.title)||await Hi(e,e.docId);return await Ga(n,{...i,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),t.remove()}}const lg=1500,ag=500,cg=4,dg=new Set(["INPUT","TEXTAREA","SELECT"]);function qa(e){const i=e;return!i||!i.tagName?!1:dg.has(i.tagName)||i.isContentEditable===!0}function ug(e){let i="",t=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:i,invalid:t})}function l(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){l(),i="",t=!1,o()}function a(){n&&clearTimeout(n),n=setTimeout(r,lg)}function c(){n&&(clearTimeout(n),n=null),t=!0,o(),s&&clearTimeout(s),s=setTimeout(r,ag)}function d(p){if(e.isEnabled&&!e.isEnabled()||qa(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return t||i.length>=cg||(i+=p.key,o(),a()),!0;if(p.key==="Enter"){if(!i||t)return!1;const u=parseInt(i,10),b=e.getTotalPages();return!isNaN(u)&&u>=1&&b>0&&u<=b?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(i||t)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:i,invalid:t}),clear:r}}const fg={class:"spm-slides-tab__toolbar"},pg={class:"spm-slides-tab__nav"},hg=["disabled"],mg={class:"spm-page-badge"},gg=["disabled"],vg=["aria-label"],bg=["aria-label"],yg={class:"spm-slides-tab__tools"},kg={class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},wg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},xg=["src"],Sg=Tt({__name:"SlidesPreviewTab",setup(e,{expose:i}){const t=Pt("plugin"),n=Pt("sandboxBridge",new Yn),s=new Am(n),o=new hp,l=me("web-sandbox"),r=me(3030),a=me(null),c=me(!1),d=me(null),p=me(1),h=me(1),u=me(!1),b=me(!1),m=me(!1),v=me("siyuan"),y=me(""),C=me(""),S=me(""),x=me(!1),$=me(!1),T=me(""),w=me(""),P=me(!1),N=ug({getTotalPages:()=>h.value,isEnabled:()=>!b.value,onJump:B=>_(B),onStateChange:B=>{w.value=B.display,P.value=B.invalid}});function H(B){if(B.key==="o"||B.key==="O"){if(b.value||B.isComposing||B.ctrlKey||B.metaKey||B.altKey||qa(B.target))return;B.preventDefault(),K();return}N.handleKeydown(B)&&B.preventDefault()}function K(){var B,z;if(l.value==="pro-cli"){(B=d.value)==null||B.focus(),ue.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(z=d.value)==null||z.focus()}function _(B){var z;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B),(z=d.value)==null||z.focus()}const F=me("/plugins/siyuan-live-slides/slides-client/index.html");let k=null,M=null,j=null,A=null,D=null,O=null,Q=null,W=null;pn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),k=n.onSlideChanged((B,z)=>{p.value=B,h.value=z}),M=n.onBlockClicked((B,z)=>{p.value=z,s.setActiveBlockId(B),B||Dn(),t&&typeof t.handleBlockClickedFromSlide=="function"?t.handleBlockClickedFromSlide(B,z):B&&zi(B,t==null?void 0:t.app)}),j=n.onOpenInEditor((B,z)=>{p.value=z,s.setActiveBlockId(B),zi(B,t==null?void 0:t.app)}),A=o.nativeBridge.onPageChanged((B,z)=>{p.value=B,h.value=z}),D=n.onOpenPeekDrawer(async B=>{const z=Gs();if(B.peekType==="siyuan"&&z.enableWebServeJump){let J=!1;if(W&&W.docId===B.target)J=!0;else if(W&&W.slides&&W.slides.some(ne=>{var oe;return(oe=ne.blocks)==null?void 0:oe.some(he=>he.id===B.target)}))J=!1;else try{const ne=await rn(`SELECT id, root_id, type FROM blocks WHERE id = '${B.target}' LIMIT 1`);ne&&ne.length>0&&(J=ne[0].type==="d"||ne[0].id===ne[0].root_id)}catch(ne){console.warn("[SlidesPreviewTab] detect block type failed:",ne)}v.value="web",x.value=!0,C.value=Ca(z.webServeUrl,B.target,{focus:!J}),S.value=B.title||`${J?"思源文档":"思源块"}: ${B.target.slice(0,8)}`,b.value=!0,n.freezeKeyboardNav(!0)}else{if(v.value=B.peekType,B.peekType==="siyuan")y.value=B.target,S.value=B.title||`块速览: ${B.target.slice(0,8)}`;else{const J=Pa(B.target);if(J.external){pe(B.target);return}x.value=!0,C.value=J.url,S.value=B.title||J.url}b.value=!0,n.freezeKeyboardNav(!0)}}),O=n.onRequestToggleFullscreen(()=>{V()}),Q=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",L)}),js(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",L),D&&D(),O&&O(),Q&&Q(),k&&k(),M&&M(),j&&j(),A&&A(),n.detach(),N.clear(),s.destroy(),o.destroy()});async function q(){if(l.value==="web-sandbox"){if(!W){ue.showMessage("请先在主编辑区打开演示文档");return}ue.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const B=await o.startProMode(W,vo);if(!B.success){ue.showMessage(`无法启动官方 Pro 模式：${B.error}`);return}l.value="pro-cli",r.value=B.port||3030,F.value=B.url,d.value&&o.nativeBridge.attach(d.value),ue.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",F.value="/plugins/siyuan-live-slides/slides-client/index.html",d.value&&n.attach(d.value),ue.showMessage("已切回内置高保真沙箱")}function re(){$.value=!$.value,$.value?(T.value=(W==null?void 0:W.docId)||"",t&&typeof t.updatePreviewTabHeader=="function"&&t.updatePreviewTabHeader("",T.value)):(T.value="",Se(),t&&typeof t.updatePreviewTabHeader=="function"&&t.updatePreviewTabHeader())}let ae=0;function ce(B){if(b.value||Math.abs(B.deltaY)<Math.abs(B.deltaX)||Math.abs(B.deltaY)<15)return;const z=Date.now();z-ae<280||(ae=z,B.deltaY>0?Te():ge())}function ge(){if(p.value>1){const B=p.value-1;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Te(){if(p.value<h.value){const B=p.value+1;p.value=B,l.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Se(){t&&typeof t.compileCurrentDocument=="function"?t.compileCurrentDocument():t!=null&&t.eventBus&&typeof t.eventBus.emit=="function"&&t.eventBus.emit("slides:request-compile")}function fe(){b.value=!1,n.freezeKeyboardNav(!1)}function Z(){fe()}function pe(B){var oe,he;const z=/^file:/i.test(B),J=z||/^[a-zA-Z]:[\\/]/.test(B),ne=_t("electron");if(J&&typeof((oe=ne==null?void 0:ne.shell)==null?void 0:oe.openPath)=="function"){ne.shell.openPath(z?La(B):B),ue.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((he=ne==null?void 0:ne.shell)==null?void 0:he.openExternal)=="function"?ne.shell.openExternal(B).catch(()=>{typeof window<"u"&&window.open(B,"_blank")}):typeof window<"u"&&window.open(B,"_blank"),ue.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function L(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function V(){const B=a.value||d.value;B&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):B.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){t&&typeof t.openPresenterTab=="function"&&t.openPresenterTab()}function G(){if(!W){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const B=Ha(W);Fa("presentation.html",B)&&ue.showMessage("已开始下载单文件离线 HTML 演示包")}function U(){if(!W){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ja(W)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const I=me(!1);async function E(){if(I.value){ue.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!W){ue.showMessage("请先在主编辑区打开幻灯片文档");return}I.value=!0;try{ue.showMessage("正在逐页导出幻灯片图片...",2e3);const B=await Hi(W,t==null?void 0:t.currentDocId,t),z=await Ga(n,{title:B,onProgress:(J,ne)=>{ue.showMessage(`正在导出幻灯片图片 (${J} / ${ne})...`,1500)}});z.success?ue.showMessage(`🎉 成功导出 ${z.total||0} 张高清图片并保存为 ${B}.zip！`,4e3):ue.showMessage(`导出图片失败：${z.error||"未知异常"}`)}finally{I.value=!1}}async function R(){if(!W){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在导出当前幻灯片图片...",1500);const B=await Ro(n);if(B.success&&B.dataUrl){const z=await Hi(W,t==null?void 0:t.currentDocId,t),J=p.value||1,oe=(h.value||1)>1?`${z}-${J}.png`:`${z}.png`;il(oe,B.dataUrl),ue.showMessage(`已下载当前页高清图片 (${oe})`)}else ue.showMessage(`导出当前页图片失败：${B.error||"未知异常"}`)}async function Y(){if(!W){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const B=await Ro(n);if(B.success&&B.dataUrl)if(await rg(B.dataUrl))ue.showMessage(`已成功将第 ${p.value||1} 页幻灯片复制到剪贴板！`);else{const J=await Hi(W,t==null?void 0:t.currentDocId,t),ne=p.value||1,he=(h.value||1)>1?`${J}-${ne}.png`:`${J}.png`;il(he,B.dataUrl),ue.showMessage(`剪贴板权限不可用，已自动下载为 ${he}`)}else ue.showMessage(`复制失败：${B.error||"未知异常"}`)}return i({updateDocument(B,z){$.value&&T.value&&z&&z!==T.value||(W=B,$.value&&!T.value&&(T.value=B.docId),h.value=B.slides.length,s.setDocId(B.docId),s.updateSlidesIndex(B.slides),l.value==="pro-cli"?o.scaffolder.scaffold(B,vo).catch(()=>{}):n.updateSlides(B.slides,B.config,B.fullMarkdown,B.customThemeCss),t&&typeof t.updatePreviewTabHeader=="function"&&t.updatePreviewTabHeader("",B.docId))},navigateToBlock(B){s.onCursorFocusBlock(B)},isPinned:$,pinnedDocId:T,engineMode:l,toggleEngineMode:q}),(B,z)=>(ee(),te("div",{class:"spm-slides-preview-tab",onKeydown:H},[f("div",fg,[f("div",pg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:ge},[le(de,{name:"chevron-left"})],8,hg),f("span",mg,xe(p.value)+" / "+xe(h.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=h.value,"aria-label":"下一页",onClick:Te},[le(de,{name:"chevron-right"})],8,gg),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":$.value}]),"aria-label":$.value?"已锁定当前文档（点击解除）："+T.value:"点击锁定当前文档（不随主编辑区切换）",onClick:re},[le(de,{name:"pin"}),f("span",null,xe($.value?"已锁定":"跟随"),1)],10,vg),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:q},[le(de,{name:"rocket"}),f("span",null,xe(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,bg)]),f("div",yg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[le(de,{name:"columns"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[le(de,{name:"presenter"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:G},[le(de,{name:"export-html"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:U},[le(de,{name:"export-pdf"})]),f("div",kg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:E},[le(de,{name:"export-image"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:z[0]||(z[0]=Gt(J=>u.value=!u.value,["stop"]))},[le(de,{name:"chevron-down"})]),u.value?(ee(),te("div",wg,[f("button",{class:"b3-menu__item",onClick:z[1]||(z[1]=J=>{E(),u.value=!1})},[...z[6]||(z[6]=[f("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[2]||(z[2]=J=>{R(),u.value=!1})},[...z[7]||(z[7]=[f("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[3]||(z[3]=J=>{Y(),u.value=!1})},[...z[8]||(z[8]=[f("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Le("",!0)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Se},[le(de,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:V},[le(de,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:ce},[f("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slides-tab__iframe",src:F.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,xg),le(Wh,{visible:b.value,"onUpdate:visible":z[4]||(z[4]=J=>b.value=J),"is-maximized":m.value,"onUpdate:isMaximized":z[5]||(z[5]=J=>m.value=J),title:S.value,onClose:fe},{default:Kl(()=>[v.value==="siyuan"&&y.value?(ee(),Kt(Xh,{key:0,"block-id":y.value,title:S.value,plugin:ve(t),onExternalJump:Z},null,8,["block-id","title","plugin"])):Le("",!0),x.value?Bt((ee(),Kt(Em,{key:1,visible:b.value&&v.value==="web",url:C.value,title:S.value,onExternalJump:Z},null,8,["visible","url","title"])),[[Mo,v.value==="web"]]):Le("",!0)]),_:1},8,["visible","is-maximized","title"]),Bt(f("div",{class:Ce(["spm-jump-badge",{"is-invalid":P.value}])},xe(w.value),3),[[Mo,w.value]])],544)],32))}}),Cg=Jt(Sg,[["__scopeId","data-v-6bf82068"]]);function Ya(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const i=new Map,t=new Map,n=new Map;let s=0;const o=(r,a)=>{i.set(r,a);const c=r.id||r.blockId;c&&t.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const h=parseInt(p,10);s=Math.max(s,h),n.set(r.parentContainerId,h)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const p=n.get(r.parentContainerId);o(r,{type:"step",step:p})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const h=Math.min(Number(p[0]),Number(p[1])),u=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(h)&&!isNaN(u)){s=Math.max(s,u),o(r,{type:"range",min:h,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;s+=p,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;s=Math.max(1,s-p),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){s=Math.max(s,p),o(r,{type:"step",step:p});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:i,idMap:t}}function _g(e,i,t){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=t.blockMap.get(e)||(n?t.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?i>=s.min&&i<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?i<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?i>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Oo=980;function $g(e){if(!e)return 0;const t=Ya(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return t;const o=nd(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(t,r)}function Ig(e,i=Oo){const t=(e||"16/9").trim();let n=16/9;if(t==="4/3"||t==="4:3")n=4/3;else if(t==="16/10"||t==="16:10")n=16/10;else if(t.includes("/")||t.includes(":")){const o=t.includes("/")?"/":":",l=t.split(o).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const o=parseFloat(t);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(i/n);return{baseWidth:i,baseHeight:s,ratio:n}}function nl(e,i,t=Oo,n=552,s=16){const o=t>0?t:Oo,l=n>0?n:552,r=Math.max(0,e-s),a=Math.max(0,i-s);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/o,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(l*d))}}function Tg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0,motion:i.motion?{...i.motion}:void 0,children:Array.isArray(i.children)?i.children.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0})):void 0})):[]}}function sl(e,i){if(!e)return"";const t=Tg(e),n=t.frontmatter||{},s=n.layout||"default",o=(i==null?void 0:i.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const l=typeof(i==null?void 0:i.currentStep)=="number",r=l?Math.max(0,i.currentStep):0,a=l?Ya(t.blocks||[]):null,d=za(t,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(i==null?void 0:i.allSlides)||[],currentPageIndex:(i==null?void 0:i.pageIndex)||t.pageIndex||1,highlight:!0,blockClassResolver:a?S=>{if(_g(S,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const $=S.id||S.blockId,T=a.blockMap.get(S)||($?a.idMap.get($):void 0);if((T==null?void 0:T.type)==="step"&&T.step===r||(T==null?void 0:T.type)==="range"&&T.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(S,x)=>{let $=x.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test($)||($+=" muted"),`<video ${$.trim()}>`}),p=n.spacing,h=p&&p!=="inherit"?p:o.spacing||"normal",u=["slide-content",`layout-${s}`,`spacing-${h}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),b=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const S=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;b.push(`background-image:url('${nt(S)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${nt(m)};`);const v=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(v)&&v>0?v:1;y!==1&&b.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const C=b.length>0?` style="${b.join("")}"`:"";return`<div class="${nt(u)}"${C}>${d}</div>`}const Eg={class:"presenter-header"},Mg={class:"presenter-title-area"},Ag={class:"presenter-brand"},Bg={class:"header-pills"},Dg={class:"pill pill-page"},Lg={key:0,class:"pill pill-step"},Pg={class:"header-toolbar"},Rg={class:"timer-capsule"},Og={class:"timer-digits"},Ng={class:"timer-actions"},zg=["aria-label"],Hg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Fg={key:0,class:"presenter-grid"},jg={class:"slide-panels"},Wg={class:"panel-box current-slide-panel"},Ug={class:"panel-header"},Vg={class:"panel-header-left"},Gg={class:"panel-page-num"},Kg={class:"panel-header-meta"},qg={key:0,class:"panel-step-pill"},Yg={class:"panel-layout-pill"},Zg=["aria-label"],Jg=["data-theme","data-slides-theme","data-normalize-headings","innerHTML"],Xg={key:1,class:"panel-fallback"},Qg=["aria-label"],ev={class:"panel-header"},tv={class:"panel-header-left"},iv={key:0,class:"panel-page-num"},nv={class:"panel-header-meta"},sv={key:0,class:"panel-end-pill"},ov={key:1,class:"panel-layout-pill"},rv=["aria-label"],lv=["data-theme","data-slides-theme","data-normalize-headings","innerHTML"],av={key:1,class:"panel-fallback"},cv={class:"notes-panel"},dv={class:"panel-header"},uv={class:"panel-header-left"},fv={class:"notes-size-controls"},pv=["disabled"],hv={class:"notes-size-value"},mv=["disabled"],gv={key:1,class:"presenter-empty"},vv={class:"empty-icon-wrap"},bv={class:"empty-actions"},yv={class:"presenter-actions"},kv={class:"nav-btn-group"},wv=["disabled"],xv=["disabled"],Sv={class:"actions-center"},Cv={class:"center-meta"},_v={class:"progress-pill"},$v={class:"nav-btn-group"},Iv=["aria-label"],Tv={class:"step-dots-text"},Ev=["disabled"],Mv=["disabled"],Av=280,Bv=15,Dv=Tt({__name:"SlidesPresenterTab",setup(e,{expose:i}){const t=Pt("plugin"),n=Pt("sandboxBridge",new Yn),s=me([]),o=me({}),l=me(1),r=me(0),a=me(0),c=me(0),d=ye(()=>s.value.length||a.value),p=me(null),h=me(null),u=me({width:0,height:0}),b=me({width:0,height:0}),m=ye(()=>{var ie;return Ig((ie=o.value)==null?void 0:ie.aspectRatio)}),v=ye(()=>{var ie;return((ie=o.value)==null?void 0:ie.theme)||"default"}),y=ye(()=>{var ie;return((ie=o.value)==null?void 0:ie.colorSchema)==="light"?"light":"dark"}),C=ye(()=>{var ie;return!!((ie=o.value)!=null&&ie.normalizeHeadingSizes)}),S=ye(()=>nl(u.value.width,u.value.height,m.value.baseWidth,m.value.baseHeight,14)),x=ye(()=>nl(b.value.width,b.value.height,m.value.baseWidth,m.value.baseHeight,14));function $(){p.value&&(u.value={width:p.value.clientWidth,height:p.value.clientHeight}),h.value&&(b.value={width:h.value.clientWidth,height:h.value.clientHeight})}let T=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(T||(T=new window.ResizeObserver(()=>{$()})),T.disconnect(),p.value&&T.observe(p.value),h.value&&T.observe(h.value))}Ni([p,h,d],()=>{Cs(()=>{w(),$()})},{flush:"post"});const P=me(0),N=me(!0);let H=null;const K=ye(()=>{const ie=String(Math.floor(P.value/60)).padStart(2,"0"),se=String(P.value%60).padStart(2,"0");return`${ie}:${se}`});function _(){N.value=!N.value}function F(){P.value=0}const k=me("");let M=null;function j(){const ie=new Date,se=String(ie.getHours()).padStart(2,"0"),_e=String(ie.getMinutes()).padStart(2,"0");k.value=`${se}:${_e}`}const A=ye(()=>s.value.length===0?null:s.value[l.value-1]||null),D=ye(()=>l.value>=s.value.length?null:s.value[l.value]||null),O=ye(()=>A.value?$g(A.value):c.value),Q=ye(()=>l.value>1||r.value>0),W=ye(()=>l.value<d.value||r.value<O.value),q=ye(()=>sl(A.value,{config:o.value,allSlides:s.value,pageIndex:l.value,currentStep:r.value})),re=ye(()=>sl(D.value,{config:o.value,allSlides:s.value,pageIndex:l.value+1})),ae=ye(()=>{var se;if(!A.value)return"无内容";const ie=(se=A.value.blocks)==null?void 0:se[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value} 页`});function ce(ie){return(ie||[]).slice(1).map(se=>(se.content||se.rawMarkdown||"").trim()).filter(se=>se&&!/^(image\s+)?assets\/\S*$/i.test(se)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(se)).join(" | ").slice(0,120)}const ge=ye(()=>{var ie;return ce((ie=A.value)==null?void 0:ie.blocks)}),Te=ye(()=>{var se;if(!D.value)return"演示结束";const ie=(se=D.value.blocks)==null?void 0:se[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value+1} 页`}),Se=ye(()=>D.value?ce(D.value.blocks):"这是最后一页"),fe=ye(()=>{var ie;return((ie=A.value)==null?void 0:ie.notes)||""}),Z=me(20);function pe(){Z.value<36&&(Z.value+=2)}function L(){Z.value>14&&(Z.value-=2)}const V=ye(()=>d.value<=1?100:Math.round(l.value/d.value*100));let g=null;try{g=new BroadcastChannel("siyuan-slides-sync"),g.onmessage=ie=>{const se=ie.data;if(se&&(se.type==="SYNC_PAGE"&&typeof se.page=="number"&&(l.value=se.page,r.value=typeof se.step=="number"?Math.max(0,se.step):0,typeof se.maxStep=="number"&&(c.value=Math.max(0,se.maxStep))),se.type==="SYNC_SLIDES"&&Array.isArray(se.slides)&&(s.value=se.slides,se.config&&typeof se.config=="object"&&(o.value=se.config)),se.type==="REQUEST_SYNC"&&s.value.length>0))try{g==null||g.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),g==null||g.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:O.value})}catch{}}}catch{g=null}function G(ie,se=0){const _e=Number(ie)||1,Ae=Math.max(0,Number(se)||0);n.navigatePage(_e,Ae);try{g==null||g.postMessage({type:"SYNC_PAGE",page:_e,step:Ae,maxStep:O.value})}catch{}}function U(){if(r.value<O.value){r.value++,G(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function I(){if(r.value>0){r.value--,G(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,G(l.value,0))}function E(){l.value<d.value&&(l.value++,r.value=0,G(l.value,0))}function R(){l.value>1&&(l.value--,r.value=0,G(l.value,0))}function Y(){l.value=1,r.value=0,F(),G(1,0)}function B(){const ie=t;typeof(ie==null?void 0:ie.openBottomPreviewTab)=="function"&&ie.openBottomPreviewTab()}function z(){const ie=t;typeof(ie==null?void 0:ie.openStandalonePreviewWindow)=="function"&&ie.openStandalonePreviewWindow()}function J(ie){var se,_e;if(!(ie.key===" "&&((_e=(se=ie.target)==null?void 0:se.closest)!=null&&_e.call(se,"button")))){if(ie.shiftKey&&ie.key==="ArrowRight"||ie.key==="ArrowDown"){ie.preventDefault(),E();return}if(ie.shiftKey&&ie.key==="ArrowLeft"||ie.key==="ArrowUp"){ie.preventDefault(),R();return}ie.key==="ArrowRight"||ie.key===" "||ie.key==="PageDown"?(ie.preventDefault(),U()):(ie.key==="ArrowLeft"||ie.key==="PageUp")&&(ie.preventDefault(),I())}}let ne=0;function oe(ie){var Ae,Ne;if(Math.abs(ie.deltaY)<Bv)return;const se=(Ne=(Ae=ie.target)==null?void 0:Ae.closest)==null?void 0:Ne.call(Ae,".notes-content");if(se){const Oe=se.scrollHeight-se.clientHeight;if(Oe>2&&(ie.deltaY>0&&se.scrollTop<Oe-1||ie.deltaY<0&&se.scrollTop>1))return}const _e=Date.now();_e-ne<Av||(ne=_e,ie.deltaY>0?U():I())}let he=null;return pn(()=>{var se;H=window.setInterval(()=>{N.value&&P.value++},1e3),j(),M=window.setInterval(j,1e3),he=n.onSlideChanged((_e,Ae,Ne,Oe,Be)=>{l.value=_e,Ae>0&&(a.value=Ae),typeof Oe=="number"&&(r.value=Math.max(0,Oe)),typeof Be=="number"&&(c.value=Math.max(0,Be))});try{g==null||g.postMessage({type:"REQUEST_SYNC"})}catch{}const ie=t==null?void 0:t.latestCompiledDoc;(se=ie==null?void 0:ie.slides)!=null&&se.length&&(s.value=ie.slides,ie.config&&(o.value=ie.config)),typeof window<"u"&&window.addEventListener("resize",$),Cs(()=>{w(),$()})}),js(()=>{H&&(window.clearInterval(H),H=null),M&&(window.clearInterval(M),M=null),he&&he(),typeof window<"u"&&window.removeEventListener("resize",$),T&&(T.disconnect(),T=null);try{g==null||g.close()}catch{}g=null}),i({updateDocument(ie){var se;(se=ie==null?void 0:ie.slides)!=null&&se.length&&(s.value=ie.slides),ie!=null&&ie.config&&(o.value=ie.config)}}),(ie,se)=>{var _e,Ae,Ne;return ee(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:J,onWheel:oe},[f("header",Eg,[f("div",Mg,[f("div",Ag,[le(de,{name:"presenter",class:"brand-icon"}),se[1]||(se[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Bg,[f("span",Dg,"P."+xe(l.value)+" / "+xe(d.value||1),1),O.value>0?(ee(),te("span",Lg,[le(de,{name:"step",class:"pill-icon"}),St(" 步进 "+xe(r.value)+" / "+xe(O.value),1)])):Le("",!0)])]),f("div",Pg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:z},[le(de,{name:"window"}),se[2]||(se[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",Rg,[le(de,{name:"clock",class:"timer-icon"}),f("span",Og,xe(K.value),1),f("div",Ng,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":N.value?"暂停计时":"继续计时",onClick:_},[le(de,{name:N.value?"pause":"play"},null,8,["name"])],8,zg),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:F},[le(de,{name:"reset"})])])]),f("div",Hg,[f("span",null,xe(k.value),1)])])]),d.value>0?(ee(),te("main",Fg,[f("section",jg,[f("div",Wg,[f("div",Ug,[f("div",Vg,[se[3]||(se[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",Gg,"P."+xe(l.value),1)]),f("div",Kg,[O.value>0?(ee(),te("span",qg," 步进 "+xe(r.value)+" / "+xe(O.value),1)):Le("",!0),f("span",Yg,xe(((Ae=(_e=A.value)==null?void 0:_e.frontmatter)==null?void 0:Ae.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":ae.value},[A.value?(ee(),te("div",{key:0,class:"presenter-thumb-box",style:Vt({width:S.value.boxWidth+"px",height:S.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+v.value]),"data-theme":y.value,"data-slides-theme":v.value,"data-normalize-headings":C.value?"true":"false",style:Vt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+S.value.scale+")"}),innerHTML:q.value},null,14,Jg)],4)):(ee(),te("div",Xg,[f("h2",null,xe(ae.value),1),f("p",null,xe(ge.value),1)]))],8,Zg)]),f("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!D.value,"b3-tooltips b3-tooltips__n":!!D.value}]),"aria-label":D.value?"点击直接跳至下一页":"",onClick:se[0]||(se[0]=Oe=>D.value&&E())},[f("div",ev,[f("div",tv,[se[4]||(se[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<d.value?(ee(),te("span",iv,"P."+xe(l.value+1),1)):Le("",!0)]),f("div",nv,[l.value>=d.value?(ee(),te("span",sv,"已到尾页")):D.value?(ee(),te("span",ov,xe(((Ne=D.value.frontmatter)==null?void 0:Ne.layout)||"default"),1)):Le("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":Te.value},[D.value?(ee(),te("div",{key:0,class:"presenter-thumb-box",style:Vt({width:x.value.boxWidth+"px",height:x.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+v.value]),"data-theme":y.value,"data-slides-theme":v.value,"data-normalize-headings":C.value?"true":"false",style:Vt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+x.value.scale+")"}),innerHTML:re.value},null,14,lv)],4)):(ee(),te("div",av,[f("h2",null,xe(Te.value),1),f("p",null,xe(Se.value),1)]))],8,rv)],10,Qg)]),f("section",cv,[f("div",dv,[f("div",uv,[le(de,{name:"notes",class:"panel-title-icon"}),se[5]||(se[5]=f("span",null,"讲稿备忘",-1))]),f("div",fv,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:Z.value<=14,onClick:L},[le(de,{name:"minus"})],8,pv),f("span",hv,xe(Z.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:Z.value>=36,onClick:pe},[le(de,{name:"plus"})],8,mv)])]),f("div",{class:Ce(["notes-content",{"is-empty":!fe.value}]),style:Vt({fontSize:Z.value+"px"})},xe(fe.value||"（本页未设置演讲者备忘录）"),7)])])):(ee(),te("main",gv,[f("div",vv,[le(de,{name:"refresh",class:"empty-icon"})]),se[8]||(se[8]=f("h2",null,"等待大屏放映数据",-1)),se[9]||(se[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",bv,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:B},[le(de,{name:"presenter"}),se[6]||(se[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:z},[le(de,{name:"window"}),se[7]||(se[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",yv,[f("div",kv,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:R},[le(de,{name:"chevrons-left"}),se[10]||(se[10]=f("span",null,"上一页",-1))],8,wv),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Q.value,"aria-label":"回退一步 (←)",onClick:I},[le(de,{name:"chevron-left"}),se[11]||(se[11]=f("span",null,"上一步",-1))],8,xv)]),f("div",Sv,[f("div",Cv,[f("span",_v,xe(V.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Y},[le(de,{name:"reset"}),se[12]||(se[12]=f("span",null,"重头放映",-1))])]),f("div",$v,[O.value>0?(ee(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${O.value}`},[(ee(!0),te(Ge,null,kt(O.value,Oe=>(ee(),te("span",{key:Oe,class:Ce(["step-dot",{"is-active":Oe<=r.value}])},null,2))),128)),f("span",Tv,xe(r.value)+"/"+xe(O.value),1)],8,Iv)):Le("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!W.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:U},[se[13]||(se[13]=f("span",null,"下一步",-1)),le(de,{name:"chevron-right"})],8,Ev),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:E},[se[14]||(se[14]=f("span",null,"下一页",-1)),le(de,{name:"chevrons-right"})],8,Mv)])])],32)}}}),Lv=Jt(Dv,[["__scopeId","data-v-9cec5e4a"]]),Pv={class:"spm-layout-picker"},Rv={class:"spm-layout-picker__grid"},Ov=["title","onClick"],Nv={class:"spm-layout-icon"},zv={class:"spm-layout-label"},Hv=Tt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:i}){const t=e,n=i,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return t.modelValue===r||r==="cols-header"&&(t.modelValue==="two-cols-header"||t.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ee(),te("div",Pv,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",Rv,[(ee(),te(Ge,null,kt(s,c=>f("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[f("div",Nv,[le(de,{name:"layout-"+c.name},null,8,["name"])]),f("span",zv,xe(c.label),1)],10,Ov)),64))])]))}}),Fv=Jt(Hv,[["__scopeId","data-v-96c8a248"]]),jv={key:0,class:"spm-transition-selector__header"},Wv={class:"spm-transition-list"},Uv=["onClick"],Vv={class:"spm-transition-meta"},Gv={class:"spm-transition-label"},Kv={class:"spm-transition-name"},qv={class:"spm-transition-preview-box"},Yv=Tt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:i}){const t=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){t("update:modelValue",o),t("change",o)}return(o,l)=>(ee(),te("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Le("",!0):(ee(),te("div",jv,xe(e.title||"转场动效"),1)),f("div",Wv,[(ee(),te(Ge,null,kt(n,r=>f("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>s(r.name)},[f("div",Vv,[f("span",Gv,xe(r.label),1),f("span",Kv,"("+xe(r.name)+")",1)]),f("div",qv,[f("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Uv)),64))])],2))}}),Za=Jt(Yv,[["__scopeId","data-v-8597e99e"]]),Zv={class:"spm-section spm-section--page"},Jv={class:"spm-section-header"},Xv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Qv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},eb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},tb={key:1,class:"spm-card-control"},ib={class:"spm-control-header"},nb={class:"spm-control-title-group"},sb={class:"spm-control-title"},ob={class:"spm-quick-chips"},rb=["onClick"],lb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},ab=["value"],cb=["aria-label"],db={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},ub={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},fb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},pb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},hb={class:"spm-card-control"},mb={class:"spm-control-header"},gb={class:"spm-control-title-group"},vb={class:"spm-control-title"},bb={class:"spm-segmented-group"},yb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},kb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},wb=["aria-label"],xb={class:"spm-quick-chips"},Sb=["onClick"],Cb=["value"],_b={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},$b={style:{display:"flex",gap:"8px","margin-top":"2px"}},Ib={style:{flex:"1"}},Tb={class:"spm-segmented-group"},Eb={style:{flex:"1"}},Mb={class:"spm-segmented-group"},Ab={class:"spm-card-control"},Bb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Pb={class:"spm-segmented-group"},Rb={class:"spm-card-control"},Ob={class:"spm-control-header"},Nb={class:"spm-control-title-group"},zb={class:"spm-control-title"},Hb={class:"spm-quick-chips"},Fb=["onClick"],jb=["value"],Wb={key:2,class:"spm-card-control"},Ub={class:"spm-control-header"},Vb={class:"spm-control-title-group"},Gb={class:"spm-control-title"},Kb={class:"spm-quick-chips"},qb=["onClick"],Yb=["value"],Zb={class:"spm-card-control"},Jb={class:"spm-control-header"},Xb={class:"spm-control-title-group"},Qb={class:"spm-control-title"},e1={key:0,class:"spm-note-status-box"},t1=["title"],i1={class:"spm-action-grid",style:{"margin-top":"6px"}},n1={key:1,class:"spm-note-empty-box"},s1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},o1={class:"spm-action-grid"},r1=["disabled"],l1=["disabled"],a1={class:"spm-card-control"},c1={class:"spm-action-grid"},d1=Tt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:i}){const t=e,n=i,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const S=t.pageMask;return S==="clockwise"||S==="counter-clockwise"||S==="cw"||S==="ccw"}),l=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>t.pageMaskRatio||l.value);function a(S){n("update:pageMask",S),(!t.pageMaskRatio||t.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(S){n("update:pageMask",S),(!t.pageMaskRatio||t.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const d=ye(()=>t.pageMask==="clockwise"||t.pageMask==="counter-clockwise"||t.pageMask==="cw"||t.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),p=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(t.pageLayout)),h=ye(()=>{var $,T;if(t.pageLayout==="two-cols-header"||t.pageLayout==="two-cols"||t.pageLayout==="image-left"||t.pageLayout==="image-right")return 2;if(t.pageLayout==="three-cols-header")return 3;const S=(t.pageLayoutRatio||"").trim();if(S.includes(":")){const w=S.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}const x=(t.detectedSbRatio||"").trim();if(x.includes(":")){const w=x.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}if(($=t.detectedSbInfo)!=null&&$.colCount&&t.detectedSbInfo.colCount>=2)return Math.min(t.detectedSbInfo.colCount,6);if((T=t.detectedSbInfo)!=null&&T.slots&&Array.isArray(t.detectedSbInfo.slots)){const w=t.detectedSbInfo.slots.length;if(w>=2&&w<=6)return w}return 2}),u=ye(()=>{const S=h.value;return S===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:S===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:S===5?[{label:"默认 1:1:1:1:1",value:""}]:S===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ye(()=>t.pageLayoutRatio||"");function m(){const S=h.value||2,x=Array(S).fill("1").join(":");n("update:pageLayoutRatio",x),n("resetSuperblockRatio")}const v=ye(()=>{if(!t.pageNotes)return"";const S=t.pageNotes.replace(/[\r\n]+/g," ").trim();return S.length>50?S.slice(0,50)+"...":S}),y=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],C=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(S,x)=>(ee(),te("div",Zv,[f("div",Jv,[f("span",null,"幻灯片页面设置"+xe(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(Fv,{"model-value":e.pageLayout,onChange:x[0]||(x[0]=$=>S.$emit("update:pageLayout",$))},null,8,["model-value"]),!p.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(ee(),te("div",Xv,[f("div",Qv,[f("div",eb,[le(de,{name:"sparkles"}),f("span",null,[x[33]||(x[33]=St("检测到本页横向超级块列宽比例：",-1)),f("b",null,xe(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:x[1]||(x[1]=$=>S.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(de,{name:"columns"}),x[34]||(x[34]=f("span",null,"设为分栏",-1))])])])):Le("",!0),p.value?(ee(),te("div",tb,[f("div",ib,[f("div",nb,[f("div",sb,[le(de,{name:"ratio"}),x[35]||(x[35]=f("span",null,"分栏比例 (Ratio)",-1))]),x[36]||(x[36]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",ob,[(ee(!0),te(Ge,null,kt(u.value,$=>(ee(),te("button",{key:$.value,class:Ce(["spm-chip",{active:b.value===$.value}]),onClick:T=>S.$emit("update:pageLayoutRatio",$.value)},xe($.label),11,rb))),128))]),f("div",lb,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:x[2]||(x[2]=$=>S.$emit("update:pageLayoutRatio",$.target.value)),onChange:x[3]||(x[3]=$=>S.$emit("update:pageLayoutRatio",$.target.value))},null,40,ab),e.detectedSbRatio?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:x[4]||(x[4]=$=>S.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(de,{name:"sparkles"}),x[37]||(x[37]=f("span",null,"读取",-1))],8,cb)):(ee(),te("button",db,[le(de,{name:"sparkles"}),x[38]||(x[38]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[le(de,{name:"reset"}),x[39]||(x[39]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(ee(),te("div",ub,[le(de,{name:"ratio"}),x[40]||(x[40]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",fb,xe(e.detectedSbRatio),1)])):(ee(),te("div",pb,[le(de,{name:"ratio"}),x[41]||(x[41]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Le("",!0),le(Za,{"model-value":e.pageTransition,onChange:x[5]||(x[5]=$=>S.$emit("update:pageTransition",$))},null,8,["model-value"]),f("div",hb,[f("div",mb,[f("div",gb,[f("div",vb,[le(de,{name:"sparkles"}),x[42]||(x[42]=f("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),x[43]||(x[43]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",bb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:x[6]||(x[6]=$=>S.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:x[7]||(x[7]=$=>c("down"))}," 从上至下 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:x[8]||(x[8]=$=>c("right"))}," 从左至右 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:x[9]||(x[9]=$=>a("clockwise"))}," 顺时针 ↻ ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:x[10]||(x[10]=$=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(ee(),te("div",yb,[f("div",kb,[x[45]||(x[45]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":d.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[le(de,{name:"help"}),x[44]||(x[44]=f("span",null,"输入规则",-1))],8,wb)]),f("div",xb,[(ee(),te(Ge,null,kt(s,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:r.value===$.value}]),onClick:T=>S.$emit("update:pageMaskRatio",$.value)},xe($.label),11,Sb)),64))]),f("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:x[11]||(x[11]=$=>S.$emit("update:pageMaskRatio",$.target.value)),onChange:x[12]||(x[12]=$=>S.$emit("update:pageMaskRatio",$.target.value))},null,40,Cb),f("div",_b,xe(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),f("div",$b,[f("div",Ib,[x[46]||(x[46]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Tb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:x[13]||(x[13]=$=>S.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:x[14]||(x[14]=$=>S.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",Eb,[x[47]||(x[47]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Mb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:x[15]||(x[15]=$=>S.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:x[16]||(x[16]=$=>S.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Le("",!0)]),f("div",Ab,[f("div",Bb,[f("div",Db,[f("div",Lb,[le(de,{name:"ratio"}),x[48]||(x[48]=f("span",null,"页面间距 (Spacing)",-1))]),x[49]||(x[49]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",Pb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:x[17]||(x[17]=$=>S.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:x[18]||(x[18]=$=>S.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:x[19]||(x[19]=$=>S.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:x[20]||(x[20]=$=>S.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",Rb,[f("div",Ob,[f("div",Nb,[f("div",zb,[le(de,{name:"palette"}),x[50]||(x[50]=f("span",null,"页面背景 (Background)",-1))]),x[51]||(x[51]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",Hb,[(ee(),te(Ge,null,kt(y,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:e.pageBackground===$.value}]),onClick:T=>S.$emit("update:pageBackground",$.value)},xe($.label),11,Fb)),64))]),f("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:x[21]||(x[21]=$=>S.$emit("update:pageBackground",$.target.value)),onChange:x[22]||(x[22]=$=>S.$emit("update:pageBackground",$.target.value))},null,40,jb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(ee(),te("div",Wb,[f("div",Ub,[f("div",Vb,[f("div",Gb,[le(de,{name:"image"}),x[52]||(x[52]=f("span",null,"页面图片 (Image)",-1))]),x[53]||(x[53]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Kb,[(ee(),te(Ge,null,kt(C,$=>f("button",{key:$.value,class:Ce(["spm-chip",{active:e.pageImage===$.value}]),onClick:T=>S.$emit("update:pageImage",$.value)},xe($.label),11,qb)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:x[23]||(x[23]=$=>S.$emit("update:pageImage",$.target.value)),onChange:x[24]||(x[24]=$=>S.$emit("update:pageImage",$.target.value))},null,40,Yb)])):Le("",!0),f("div",Zb,[f("div",Jb,[f("div",Xb,[f("div",Qb,[le(de,{name:"presenter"}),x[54]||(x[54]=f("span",null,"演讲者提词 (Notes)",-1))]),x[55]||(x[55]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),f("button",{class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:x[25]||(x[25]=$=>S.$emit("generateNotes"))},[le(de,{name:"sparkles"}),x[56]||(x[56]=f("span",null,"AI 讲稿",-1))])]),e.pageNotes?(ee(),te("div",e1,[x[59]||(x[59]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},xe(v.value),9,t1),f("div",i1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:x[26]||(x[26]=$=>S.$emit("locateNoteBlock"))},[le(de,{name:"search"}),x[57]||(x[57]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:x[27]||(x[27]=$=>S.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[58]||(x[58]=f("span",null,"追加讲稿块",-1))])])])):(ee(),te("div",n1,[x[61]||(x[61]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:x[28]||(x[28]=$=>S.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[60]||(x[60]=f("span",null,"添加讲稿备注块",-1))])])),f("div",s1,[f("div",o1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Vt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:x[29]||(x[29]=$=>S.$emit("batchAppendNotes"))},[le(de,{name:"insert-below"}),x[62]||(x[62]=f("span",null,"全部追加",-1))],12,r1),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Vt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:x[30]||(x[30]=$=>S.$emit("batchDeleteNotes"))},[le(de,{name:"trash"}),x[63]||(x[63]=f("span",null,"全部删除",-1))],12,l1)])])]),f("div",a1,[x[66]||(x[66]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",c1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:x[31]||(x[31]=$=>S.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),x[64]||(x[64]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:x[32]||(x[32]=$=>S.$emit("deleteDivider"))},[le(de,{name:"trash"}),x[65]||(x[65]=f("span",null,"删除此页",-1))])])])]))}}),u1=Jt(d1,[["__scopeId","data-v-996b7aec"]]),f1={class:"spm-section spm-section--block"},p1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},h1={class:"spm-control-header"},m1={class:"spm-control-title-group"},g1={class:"spm-control-title"},v1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},b1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},y1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},k1={key:0},w1={key:1},x1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},S1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},C1={class:"spm-action-grid"},_1={class:"spm-card-control"},$1={class:"spm-control-header"},I1={class:"spm-control-title-group"},T1={class:"spm-control-title"},E1=["aria-label"],M1=["checked"],A1={key:1,class:"spm-card-control"},B1={class:"spm-control-header"},D1={class:"spm-control-title-group"},L1={class:"spm-control-title"},P1={class:"spm-quick-chips"},R1={key:2,class:"spm-card-control"},O1={class:"spm-control-header"},N1={class:"spm-control-title-group"},z1={class:"spm-control-title"},H1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},F1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},j1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},W1=["aria-label"],U1=["checked"],V1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},G1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},K1=["aria-label"],q1=["checked"],Y1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Z1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},J1=["aria-label"],X1=["checked"],Q1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ey={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ty=["aria-label"],iy=["checked"],ny={class:"spm-card-control"},sy={class:"spm-control-header"},oy={class:"spm-control-title-group"},ry={class:"spm-control-title"},ly=["aria-label"],ay=["checked"],cy={key:0,class:"spm-quick-chips"},dy=["onClick"],uy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},fy={class:"spm-card-control"},py={class:"spm-control-header"},hy={class:"spm-control-title-group"},my={class:"spm-control-title"},gy=["aria-label"],vy=["checked"],by={key:0,class:"spm-quick-chips"},yy=["onClick"],ky={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},wy={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},xy={style:{display:"flex",gap:"6px"}},Sy=["value"],Cy=["value"],_y={key:3,class:"spm-card-control"},$y={class:"spm-control-header"},Iy={class:"spm-control-title-group"},Ty={class:"spm-control-title"},Ey={class:"spm-control-desc"},My={class:"spm-segmented-group"},Ay=["onClick"],By={key:4,class:"spm-card-control"},Dy={class:"spm-control-header"},Ly={class:"spm-control-title-group"},Py={class:"spm-control-title"},Ry={class:"spm-quick-chips"},Oy=["onClick"],Ny=["value"],zy={key:5,class:"spm-card-control"},Hy={class:"spm-control-header"},Fy={class:"spm-control-title-group"},jy={class:"spm-control-title"},Wy={class:"spm-quick-chips"},Uy=["onClick"],Vy=["value"],Gy={class:"spm-card-control"},Ky={class:"spm-action-grid"},qy=["aria-label"],Yy=Tt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:i}){const t=e,n=ye(()=>{const T=t.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(t.elemSlot)?"cols-header":T}),s=ye(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),o=ye(()=>{var w,P,N,H;if((w=t.detectedSbInfo)!=null&&w.colCount&&t.detectedSbInfo.colCount>=2)return Math.min(t.detectedSbInfo.colCount,6);const T=(P=t.elemSlot)==null?void 0:P.match(/^col-(\d+)$/);if(T){const K=parseInt(T[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(t.currentSlideLayout==="three-cols-header")return 3;if(t.currentSlideLayout==="two-cols-header"||t.currentSlideLayout==="two-cols")return 2;if((H=(N=t.detectedSbInfo)==null?void 0:N.ratio)!=null&&H.includes(":")){const K=t.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),l=ye(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=ye(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,P=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let N=1;N<=w;N++)P.push({value:`col-${N}`,label:`第 ${N} 栏`});return P});function c(T){const w=t.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&o.value===3||T==="col-2"&&w==="right"&&o.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=i,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=ye(()=>{if(!t.elemMotion||t.elemMotion.trim()===""||t.elemMotion.trim()==="none")return null;try{const T=JSON.parse(t.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:t.elemMotion.trim(),duration:0,delay:0}}),u=ye(()=>!!h.value),b=ye(()=>{var T;return((T=h.value)==null?void 0:T.preset)||"slide-up"}),m=ye(()=>{var T;return((T=h.value)==null?void 0:T.duration)||0}),v=ye(()=>{var T;return((T=h.value)==null?void 0:T.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function C(T){$(T,m.value,v.value)}function S(T){$(b.value,T,v.value)}function x(T){$(b.value,m.value,T)}function $(T,w,P){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!P){d("update:elemMotion",T);return}const N={preset:T};w>0&&(N.duration=w),P>0&&(N.delay=P),d("update:elemMotion",JSON.stringify(N))}return(T,w)=>{var P,N,H,K,_,F;return ee(),te("div",f1,[w[62]||(w[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(P=e.detectedSbInfo)!=null&&P.hasSuperBlock?(ee(),te("div",p1,[f("div",h1,[f("div",m1,[f("div",g1,[le(de,{name:"ratio"}),w[24]||(w[24]=f("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",v1,[f("div",b1,[f("div",y1,[le(de,{name:"ratio"}),(N=e.detectedSbInfo)!=null&&N.isCustomWidth?(ee(),te("span",k1,"已识别自定义列宽比例")):(ee(),te("span",w1,"识别到 "+xe(((H=e.detectedSbInfo)==null?void 0:H.colCount)||2)+" 列超级块分栏",1))]),f("code",x1,xe(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),f("div",S1,xe((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",C1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(de,{name:"sparkles"}),w[26]||(w[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var M;return T.$emit("applySuperBlockRatio",((M=e.detectedSbInfo)==null?void 0:M.ratio)||"1:1")})},[le(de,{name:"check"}),f("span",null,"应用比例 ("+xe(((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1")+")",1)])])])):Le("",!0),f("div",_1,[f("div",$1,[f("div",I1,[f("div",T1,[le(de,{name:"presenter"}),w[27]||(w[27]=f("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>T.$emit("toggleNote"))},null,40,M1),w[29]||(w[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,E1)])]),e.isImage||e.imageRole?(ee(),te("div",A1,[f("div",B1,[f("div",D1,[f("div",L1,[le(de,{name:"image"}),w[30]||(w[30]=f("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",P1,[f("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>T.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>T.$emit("update:imageRole","background"))},[le(de,{name:"image"}),w[32]||(w[32]=f("span",null,"背景图",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>T.$emit("update:imageRole","image-left"))},[le(de,{name:"image-left"}),w[33]||(w[33]=f("span",null,"图左",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>T.$emit("update:imageRole","image-right"))},[le(de,{name:"image-right"}),w[34]||(w[34]=f("span",null,"图右",-1))],2)])])):Le("",!0),e.isVideo?(ee(),te("div",R1,[f("div",O1,[f("div",N1,[f("div",z1,[le(de,{name:"video"}),w[35]||(w[35]=f("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",H1,[f("div",F1,[f("span",j1,[le(de,{name:"sliders"}),w[37]||(w[37]=St(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>T.$emit("toggleVideoControls"))},null,40,U1),w[38]||(w[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,W1)]),f("div",V1,[f("span",G1,[le(de,{name:"video"}),w[39]||(w[39]=St(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>T.$emit("toggleVideoAutoplay"))},null,40,q1),w[40]||(w[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,K1)]),f("div",Y1,[f("span",Z1,[le(de,{name:"repeat"}),w[41]||(w[41]=St(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>T.$emit("toggleVideoLoop"))},null,40,X1),w[42]||(w[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,J1)]),f("div",Q1,[f("span",ey,[le(de,{name:"volume-x"}),w[43]||(w[43]=St(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>T.$emit("toggleVideoMuted"))},null,40,iy),w[44]||(w[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,ty)])])])):Le("",!0),f("div",ny,[f("div",sy,[f("div",oy,[f("div",ry,[le(de,{name:"step"}),w[45]||(w[45]=f("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>T.$emit("toggleElemClick"))},null,40,ay),w[47]||(w[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,ly)]),e.elemClick?(ee(),te("div",cy,[(ee(),te(Ge,null,kt(["+1","1","2","hide"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemClick===k}]),onClick:M=>T.$emit("update:elemClick",k)},xe(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,dy)),64))])):e.parentElemClick?(ee(),te("div",uy,[le(de,{name:"check"}),w[48]||(w[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Le("",!0)]),f("div",fy,[f("div",py,[f("div",hy,[f("div",my,[le(de,{name:"motion"}),w[49]||(w[49]=f("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[f("input",{type:"checkbox",checked:u.value,onChange:y},null,40,vy),w[51]||(w[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,gy)]),u.value?(ee(),te("div",by,[(ee(),te(Ge,null,kt(p,k=>f("button",{key:k.value,class:Ce(["spm-chip",{active:b.value===k.value}]),onClick:M=>C(k.value)},xe(k.label),11,yy)),64))])):Le("",!0),u.value?(ee(),te("div",ky,[f("div",wy,[f("span",null,"时长: "+xe(m.value?m.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+xe(v.value?v.value+"ms":"0ms"),1)]),f("div",xy,[f("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:w[12]||(w[12]=k=>S(Number(k.target.value)))},[...w[52]||(w[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,Sy),f("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:w[13]||(w[13]=k=>x(Number(k.target.value)))},[...w[53]||(w[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,Cy)])])):Le("",!0)]),s.value||e.elemSlot?(ee(),te("div",_y,[f("div",$y,[f("div",Iy,[f("div",Ty,[le(de,{name:"columns"}),f("span",null,xe(l.value),1)]),f("span",Ey,xe(r.value),1)])]),f("div",My,[(ee(!0),te(Ge,null,kt(a.value,k=>(ee(),te("button",{key:k.value,class:Ce(["spm-segmented-item",{active:c(k.value)}]),onClick:M=>T.$emit("update:elemSlot",k.value)},xe(k.label),11,Ay))),128))])])):Le("",!0),e.isCodeBlock?(ee(),te("div",By,[f("div",Dy,[f("div",Ly,[f("div",Py,[le(de,{name:"code"}),w[54]||(w[54]=f("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",Ry,[(ee(),te(Ge,null,kt(["1-3","all","1|2|3","2-5"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemShikiLines===k}]),onClick:M=>T.$emit("update:elemShikiLines",k)},xe(k),11,Oy)),64)),e.elemShikiLines?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Le("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>T.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>T.$emit("update:elemShikiLines",k.target.value))},null,40,Ny)])):Le("",!0),e.isCodeBlock?(ee(),te("div",zy,[f("div",Hy,[f("div",Fy,[f("div",jy,[le(de,{name:"code"}),w[56]||(w[56]=f("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",Wy,[(ee(),te(Ge,null,kt(["240px","320px","400px","50vh"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:M=>T.$emit("update:elemMaxHeight",k)},xe(k),11,Uy)),64)),e.elemMaxHeight?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Le("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>T.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>T.$emit("update:elemMaxHeight",k.target.value))},null,40,Vy)])):Le("",!0),f("div",Gy,[w[61]||(w[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",Ky,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>T.$emit("insertDividerBefore"))},[le(de,{name:"insert-above"}),w[58]||(w[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>T.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),w[59]||(w[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>T.$emit("setTwoColsContrast"))},[le(de,{name:"columns"}),f("span",null,xe(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,qy),e.hasBlockAttrs?(ee(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:w[23]||(w[23]=k=>T.$emit("clearBlockAttrs"))},[le(de,{name:"broom"}),w[60]||(w[60]=f("span",null,"清除属性",-1))])):Le("",!0)])])])}}}),Zy={class:"spm-section spm-section--doc"},Jy={class:"spm-card-control"},Xy={class:"spm-control-header"},Qy={class:"spm-control-title-group"},e0={class:"spm-control-title"},t0={class:"spm-segmented-group"},i0=["aria-label","onClick"],n0={class:"spm-card-control"},s0={class:"spm-control-header"},o0={class:"spm-control-title-group"},r0={class:"spm-control-title"},l0={class:"spm-segmented-group"},a0={class:"spm-card-control"},c0={class:"spm-control-header"},d0={class:"spm-control-title-group"},u0={class:"spm-control-title"},f0={class:"spm-segmented-group"},p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},v0={class:"spm-card-control"},b0={class:"spm-control-header"},y0={class:"spm-control-title-group"},k0={class:"spm-control-title"},w0=["aria-label"],x0=["checked"],S0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},C0=["value"],_0={class:"spm-card-control"},$0={class:"spm-control-header"},I0={class:"spm-control-title-group"},T0={class:"spm-control-title"},E0=["aria-label"],M0=["checked"],A0={class:"spm-card-control"},B0={class:"spm-action-grid"},D0=["disabled","aria-label"],L0=Tt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const i=Pt("plugin"),t=vi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Di({enableWebServeJump:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Di({normalizeHeadingSizes:a}),i&&typeof i.saveGlobalSettings=="function"&&await i.saveGlobalSettings({normalizeHeadingSizes:a}),i&&typeof i.compileCurrentDocument=="function"&&i.compileCurrentDocument(i.currentDocId||((c=i.getActiveDocumentId)==null?void 0:c.call(i)))}function l(a){Di({webServeUrl:a})}function r(a){Di({webServeUrl:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ee(),te("div",Zy,[c[40]||(c[40]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",Jy,[f("div",Xy,[f("div",Qy,[f("div",e0,[le(de,{name:"palette"}),c[19]||(c[19]=f("span",null,"幻灯片主题 (Theme)",-1))]),c[20]||(c[20]=f("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),f("div",t0,[(ee(),te(Ge,null,kt(n,d=>f("button",{key:d.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},xe(d.label),11,i0)),64))])]),f("div",n0,[f("div",s0,[f("div",o0,[f("div",r0,[le(de,{name:"ratio"}),c[21]||(c[21]=f("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[22]||(c[22]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",l0,[f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",a0,[f("div",c0,[f("div",d0,[f("div",u0,[le(de,{name:"ratio"}),c[23]||(c[23]=f("span",null,"间距风格 (Spacing)",-1))]),c[24]||(c[24]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",f0,[f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),f("div",p0,[f("div",h0,[f("div",m0,[f("div",g0,[le(de,{name:"transition"}),c[25]||(c[25]=f("span",null,"全局默认转场",-1))]),c[26]||(c[26]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),le(Za,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),f("div",v0,[f("div",b0,[f("div",y0,[f("div",k0,[le(de,{name:"external-link"}),c[27]||(c[27]=f("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[28]||(c[28]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(t).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:ve(t).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,x0),c[29]||(c[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,w0)]),ve(t).enableWebServeJump?(ee(),te("div",S0,[f("input",{value:ve(t).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Gt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Gt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,C0),c[30]||(c[30]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Le("",!0)]),f("div",_0,[f("div",$0,[f("div",I0,[f("div",T0,[le(de,{name:"type"}),c[31]||(c[31]=f("span",null,"固定特定标题大小",-1))]),c[32]||(c[32]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(t).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:ve(t).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,M0),c[33]||(c[33]=f("span",{class:"spm-switch-slider"},null,-1))],8,E0)])]),f("div",A0,[c[39]||(c[39]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",B0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[le(de,{name:"split-preview"}),c[34]||(c[34]=f("span",null,"分屏预览",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[le(de,{name:"presenter"}),c[35]||(c[35]=f("span",null,"演讲者视图",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[le(de,{name:"sparkles"}),c[36]||(c[36]=f("span",null,"AI 智能分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[le(de,{name:"export-html"}),c[37]||(c[37]=f("span",null,"导出 HTML",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[le(de,{name:"export-pdf"}),c[38]||(c[38]=f("span",null,"导出 PDF",-1))]),f("button",{class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:c[18]||(c[18]=d=>a.$emit("exportImages"))},[le(de,{name:"export-image"}),f("span",null,xe(e.isExportingImages?"正在导出...":"导出图片"),1)],10,D0)])])]))}}),P0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,R0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function O0(e){const i=await Wa.loadAsync(e),t={},n=[];let s="",o="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||R0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");t[c]=d;const p=c.split("/");p.length>1&&(t[p.slice(1).join("/")]=d)}else if(P0.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:h})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:t,assets:n}}function N0(e,i){if(Object.keys(i).length===0)return e;function t(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(i[o])return i[o];const r=o.replace(/^\.?\//,"");return i[r]?i[r]:i[l]?i[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=t(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=t(r);return a?`src="${a}"`:l}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],l=t(o);l&&(s.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=t(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function Ja(e){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(e))return i.readFileSync(e,"utf-8")}}catch{}return null}function z0(e,i){const t=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!t)return null;const n=t[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[b,m]of Object.entries(a))if(b.endsWith(`/${r}`)||u&&b.endsWith(`/${u}`)){c=m;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const b=require("path");u.push(b.resolve(i.baseDir,r)),u.push(b.resolve(i.baseDir,o))}catch{}try{const b=require("path");u.push(b.resolve(process.cwd(),r))}catch{}for(const b of u){const m=Ja(b);if(m!==null){c=m;break}}}if(!c){const u=Da||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,v]of Object.entries(u))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=v;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(u);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(m?m[1]:"")+b[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function H0(e){let i=!1,t=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!t)i=!i;else if(s==='"'&&!i)t=!t;else if(s==="#"&&!i&&!t)return e.slice(0,n).trim()}return e.trim()}function fs(e){const i={},t=e.split(/\r?\n/);let n=0;for(;n<t.length;){const s=t[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<t.length;){const p=t[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),b=u?u[1].length:0;if(d===-1&&(d=b),b<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=H0(a),!a){let c=n+1;const d=[];let p=-1;for(;c<t.length;){const h=t[c],u=h.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const b=h.match(/^(\s+)/),m=b?b[1].length:0;if(p===-1)if(m>0)p=m;else break;if(m<p)break;d.push(h.slice(p)),c++}if(d.length>0){i[r]=fs(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[r]=a}n++}return i}const F0=/^\s*```ya?ml([\s\S]*?)```/;function ol(e){let i={},t=e.trim();const n=t.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=fs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return i=o,t=t.slice(n[0].length).trim(),{frontmatter:i,content:t}}if(t.startsWith("---")){const o=t.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(t=t.slice(o[0].length).trim())}const s=t.match(F0);if(s)i=fs(s[1]),t=t.slice(s[0].length).trim();else{const o=t.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(i=fs(l.join(`
`)),t=o.slice(r).join(`
`).trim())}return{frontmatter:i,content:t}}function j0(e){const i=e.split(/\r?\n/),t=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=i.slice(n,l).join(`
`).trim();r&&t.push(r),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<i.length&&!i[p].trimStart().startsWith(d);p++);p<i.length&&(l=p)}}return n<i.length&&o(i.length),t}function ps(e,i={}){const{stripNotesFromMarkdown:t=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=j0(d),h={};let u="",b="",m=0;if(p.length>0){const H=p[0],K=ol(H),_=Object.keys(K.frontmatter).length>0,F=K.content.length>0;_&&!F&&p.length>1?(m=1,v(K.frontmatter)):_&&v(K.frontmatter)}function v(H){u=H.title||"",H.theme&&(h[Ln]=String(H.theme)),H.aspectRatio&&(h[Pn]=String(H.aspectRatio)),H.highlighter&&(h[hl]=String(H.highlighter)),H.transition&&(h[Rn]=String(H.transition)),H.colorSchema&&(h[ml]=String(H.colorSchema)),H.layout&&(h[we]=String(H.layout)),H.background&&(h[et]=String(H.background)),H.image&&(h[Dt]=String(H.image)),H.class&&(h[Zi]=String(H.class));for(const[K,_]of Object.entries(H))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(h[`custom-slides-${K}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let C=0,S=0,x=0,$=0;const T=new Set,w={};let P=1;for(let H=m;H<p.length;H++){const K=p[H],{frontmatter:_,content:F}=ol(K),k=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),M=_.src||(k?k[1]:void 0);if(M){const fe=String(M).trim().replace(/^['"]|['"]$/g,"");let Z=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!Z){const L=fe.replace(/^\.\//,""),V=[];if(i.baseDir)try{const g=require("path");V.push(g.resolve(i.baseDir,L)),V.push(g.resolve(i.baseDir,fe))}catch{}try{const g=require("path");V.push(g.resolve(process.cwd(),L)),V.push(g.resolve(process.cwd(),fe))}catch{}for(const g of V){const G=Ja(g);if(G!==null){Z=G;break}}}const pe={};_.layout&&(pe[we]=String(_.layout)),_.transition&&(pe[pt]=String(_.transition)),_.background&&(pe[et]=String(_.background)),_.image&&(pe[Dt]=String(_.image)),_.class&&(pe[Zi]=String(_.class));for(const[L,V]of Object.entries(_))["src","layout","transition","background","image","class"].includes(L)||(pe[`custom-slides-${L}`]=typeof V=="object"?JSON.stringify(V):String(V));if(Z){const L=ps(Z,{...i,virtualFiles:c});for(const V of L.slides){V.pageIndex=P++,V.pageAttrs={...pe,...V.pageAttrs},y.push(V);const g=V.pageAttrs[we]||"default";w[g]=(w[g]||0)+1}continue}else{y.push({pageIndex:P++,pageAttrs:{...pe,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=pe[we]||"default";w[L]=(w[L]||0)+1;continue}}const j={};_.layout&&(j[we]=String(_.layout)),_.transition&&(j[pt]=String(_.transition)),_.background&&(j[et]=String(_.background)),_.image&&(j[Dt]=String(_.image)),_.class&&(j[Zi]=String(_.class)),_.mask&&(j[Ji]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(j[Pi]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(j[Xi]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(j[Qi]=String(_.maskInitial||_["mask-initial"]));for(const[fe,Z]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(j[`custom-slides-${fe}`]=typeof Z=="object"?JSON.stringify(Z):String(Z));let A=F;const D=[];let O=A.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const Z=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(fe),Z});O=O.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const Z=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(fe),Z});let Q="";const W=Array.from(O.matchAll(/<!--([\s\S]*?)-->/g));if(W.length>0){const fe=W[W.length-1],Z=O.slice(fe.index+fe[0].length).trim();if(!Z||!Z.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=fe[1].trim();L.startsWith("TODO:")||(Q=L,C++),t&&(O=O.slice(0,fe.index).trimEnd()+O.slice(fe.index+fe[0].length))}}t&&(O=O.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<D.length;fe++)O=O.replace(`__CODE_TOKEN_NOTE_${fe}__`,D[fe]);if(A=O,Q){for(let pe=0;pe<D.length;pe++)Q=Q.replace(`__CODE_TOKEN_NOTE_${pe}__`,D[pe]);const Z=`> [!NOTE] 💡 演讲备注
${Q.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slides-note="true"}`;A=A?`${A}

${Z}`:Z}let q=!1;if(/<style\b/i.test(A)){q=!0;const fe=A.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const Z of fe){const pe=Z.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${pe}`:pe}l&&(A=A.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const re=A.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);re&&(S+=re.length);const ae=A.match(/```\w+\s+\{[^}]+\}/g);ae&&(x+=ae.length);const ce=A.match(/::\w+::|<template\s+#[^>]+>/g);if(ce&&($+=ce.length),A=A.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>z0(fe,{...i,virtualFiles:c})||fe),n&&(A=A.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(A=A.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),A=A.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(A=A.replace(/^::\w+::\s*$/gm,"")),r&&(A=Uf(A)),a){let fe=A.trim(),Z="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(Z=fe.slice(pe),fe=fe.slice(0,pe).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const L=String(_.image).trim(),V=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${L})
{: custom-slides-layout="${V}" }`;_.layout==="image-left"?fe=`{{{col

${g}

${fe}

}}}`:fe=`{{{col

${fe}

${g}

}}}`}if(_.background){const V=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${V}

${fe}`:V}A=Z?`${fe}

${Z}`:fe}const ge=W0(A);j[et]&&ge.push(j[et]),j[Dt]&&ge.push(j[Dt]);for(const fe of ge)T.add(fe);const Te=/<[A-Z][a-zA-Z0-9]+/.test(A),Se=j[we]||(P===1?h[we]||"cover":"default");w[Se]=(w[Se]||0)+1,y.push({pageIndex:P++,pageAttrs:j,notes:Q,rawMarkdown:A,hasVueComponent:Te,hasStyleTag:q,assetReferences:ge})}if(!u&&y.length>0){const H=y[0].rawMarkdown.match(/^#\s+(.+)$/m);H&&(u=H[1].trim())}b&&(h["custom-slides-custom-css"]=b);let N=y.map(H=>`---

${H.rawMarkdown}`).join(`

`);return N.trimStart().startsWith("---")||(N=`---

${N.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:h,slides:y,totalSlides:y.length,stats:{totalNotes:C,totalVClicks:S,totalShikiHighlights:x,totalSlots:$,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:N,customCss:b}}function W0(e){const i=[],t=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=t.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&i.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&i.push(o)}return i}function Xa(e){if(!e)return!1;const i=String(e.type||"").toLowerCase(),t=String(e.markdown||"").trim(),n=String(e.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||t==="---"||t==="***"||n==="---"||n==="***"}function U0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function V0(e,i,t=je){const n=e.filter(Xa);let s=0;if(n.length>=i.length)for(let o=0;o<i.length;o++){const l=i[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await t(r.id,l.pageAttrs),s++)}else for(let o=1;o<i.length;o++){const l=i[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await t(r.id,l.pageAttrs),s++)}return s}async function G0(e,i=je){let t=!1,n=0;for(const s of e){if(Xa(s)){t=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){t=!0;continue}t&&s.id&&(await i(s.id,{[$e]:"right"}).catch(()=>{}),n++)}return n}async function K0(e,i,t=dl){const n={};if(!i||i.length===0)return n;const s=[];for(const o of i){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await t("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&N0(e,n),n}async function q0(e){var x;const{presentation:i,notebookId:t,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||dl,d=a.createDocFn||Jc,p=a.setAttrsFn||je,h=a.getChildBlocksFn||vs,u=a.openTabFn||ue.openTab,b=a.showMessageFn||ue.showMessage;o&&s.length>0&&await K0(i,s,c);const m=U0(n),v=`/${m}`,y=await d(t,v,i.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const C=((x=i.slides[0])==null?void 0:x.pageAttrs)||{};await p(y,{...C,...i.docRootAttrs});const S=await h(y).catch(()=>[]);return Array.isArray(S)&&S.length>0&&(await V0(S,i.slides,p),await G0(S,p)),b(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function Y0(e){const i=me("file"),t=me(!1),n=me(!1),s=me(""),o=me(null),l=me(null),r=me(""),a=me(0),c=me(""),d=me([]),p=me(null),h=me(""),u=me([]),b=me(""),m=me(!0),v=me(!0),y=me(!0),C=me(!0),S=ye(()=>{const j=a.value;if(j===0)return"0 B";const A=1024,D=["B","KB","MB","GB"],O=Math.floor(Math.log(j)/Math.log(A));return`${(j/A**O).toFixed(1)} ${D[O]}`}),x=ye(()=>{var j;return((j=p.value)==null?void 0:j.docRootAttrs["custom-slides-theme"])||"default"}),$=ye(()=>{var j;return d.value.length>0?d.value.length:((j=p.value)==null?void 0:j.stats.discoveredAssets.length)||0}),T=ye(()=>{var A;const j=((A=p.value)==null?void 0:A.stats.layoutDistribution)||{};return Object.entries(j).map(([D,O])=>({name:D,count:O}))});async function w(j=Zc){try{const A=await j();A!=null&&A.notebooks&&Array.isArray(A.notebooks)&&(u.value=A.notebooks.filter(D=>!D.closed),u.value.length>0&&!b.value&&(b.value=u.value[0].id))}catch(A){console.warn("获取笔记本列表失败:",A)}}function P(){var j;(j=o.value)==null||j.click()}function N(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],s.value=""}async function H(j){s.value="",l.value=j,r.value=j.name,a.value=j.size;try{if(j.name.toLowerCase().endsWith(".zip")){const D=await j.arrayBuffer(),O=await O0(D);if(!O.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=O.assets;const Q=ps(O.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:O.virtualFiles});p.value=Q,h.value=Q.docTitle||j.name.replace(/\.zip$/i,"")}else{const D=await j.text();d.value=[];const O=j.path||"",Q=O?O.replace(/[\\/][^\\/]+$/,""):"",W=ps(D,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Q||void 0});p.value=W,h.value=W.docTitle||j.name.replace(/\.md$/i,"")}}catch(A){console.error("解析文件失败:",A),s.value=`解析文件失败: ${A.message||String(A)}`}}function K(){if(s.value="",!c.value.trim()){p.value=null;return}try{const j=ps(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});p.value=j,h.value=j.docTitle||"Slidev 演示文稿"}catch(j){s.value=`解析 Markdown 源码失败: ${j.message||String(j)}`}}async function _(){l.value?await H(l.value):c.value&&K()}async function F(j){const A=j.target;A.files&&A.files[0]&&await H(A.files[0])}async function k(j){var A;t.value=!1,(A=j.dataTransfer)!=null&&A.files&&j.dataTransfer.files[0]&&await H(j.dataTransfer.files[0])}async function M(j=e){if(p.value){if(!b.value&&u.value.length>0&&(b.value=u.value[0].id),!b.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await q0({presentation:p.value,notebookId:b.value,docTitle:h.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:C.value,plugin:j})}catch(A){console.error("导入 Slidev 演示失败:",A),s.value=`导入执行失败: ${A.message||String(A)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:t,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:h,notebooks:u,selectedNotebookId:b,optCleanHtml:m,optStripNotes:v,optUploadAssets:y,optAutoPreview:C,formattedFileSize:S,currentTheme:x,extractedAssetsCount:$,layoutChips:T,fetchNotebooks:w,triggerFileInput:P,clearFile:N,processFile:H,onFileSelected:F,onFileDrop:k,onTextChange:K,reprocessCurrentInput:_,handleConfirmImport:M}}const Z0={class:"spm-import-dialog"},J0={class:"spm-tabs-header"},X0={class:"spm-dialog-body"},Q0={key:0,class:"spm-file-section"},ek={key:0,class:"spm-dropzone-prompt"},tk={class:"spm-dropzone-icon"},ik={key:1,class:"spm-dropzone-active"},nk={class:"spm-file-badge"},sk={class:"spm-file-size"},ok={key:1,class:"spm-text-section"},rk={key:2,class:"spm-error-banner"},lk={key:3,class:"spm-preview-card"},ak={class:"spm-preview-card__header"},ck={style:{display:"inline-flex","align-items":"center",gap:"4px"}},dk={class:"spm-config-grid"},uk={class:"spm-form-item"},fk={class:"spm-form-item"},pk=["value"],hk={class:"spm-stats-grid"},mk={class:"spm-stat-box"},gk={class:"spm-stat-value"},vk={class:"spm-stat-box"},bk={class:"spm-stat-value"},yk={class:"spm-stat-box"},kk={class:"spm-stat-value"},wk={class:"spm-stat-box"},xk={class:"spm-stat-value"},Sk={key:0,class:"spm-chips-row"},Ck={class:"spm-options-group"},_k={class:"spm-checkbox-label"},$k={class:"spm-checkbox-label"},Ik={class:"spm-checkbox-label"},Tk={class:"spm-checkbox-label"},Ek={class:"spm-dialog-footer"},Mk=["disabled"],Ak=["disabled"],Bk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Dk={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Lk=Tt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:i}){const t=i,n=Pt("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:h,customDocTitle:u,notebooks:b,selectedNotebookId:m,optCleanHtml:v,optStripNotes:y,optUploadAssets:C,optAutoPreview:S,formattedFileSize:x,currentTheme:$,layoutChips:T,fetchNotebooks:w,triggerFileInput:P,clearFile:N,onFileSelected:H,onFileDrop:K,onTextChange:_,reprocessCurrentInput:F,handleConfirmImport:k}=Y0(n);pn(async()=>{await w()});async function M(){const A=await k();A&&(t("success",{docId:A}),t("close"))}function j(){t("close")}return(A,D)=>(ee(),te("div",{class:"spm-modal-overlay",onClick:Gt(j,["self"])},[f("div",Z0,[f("div",{class:"spm-dialog-header"},[D[18]||(D[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlides"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),f("div",J0,[f("button",{class:Ce(["spm-tab-btn",{active:ve(s)==="file"}]),onClick:D[0]||(D[0]=O=>s.value="file")},[le(de,{name:"package"}),D[19]||(D[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:Ce(["spm-tab-btn",{active:ve(s)==="text"}]),onClick:D[1]||(D[1]=O=>s.value="text")},[le(de,{name:"notes"}),D[20]||(D[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",X0,[ve(s)==="file"?(ee(),te("div",Q0,[f("div",{class:Ce(["spm-dropzone",{dragover:ve(o),"has-file":!!ve(c)}]),onDragover:D[4]||(D[4]=Gt(O=>o.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Gt(O=>o.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Gt((...O)=>ve(K)&&ve(K)(...O),["prevent"])),onClick:D[7]||(D[7]=(...O)=>ve(P)&&ve(P)(...O))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...O)=>ve(H)&&ve(H)(...O))},null,544),ve(c)?(ee(),te("div",ik,[f("span",nk,[le(de,{name:"notes"}),St(" "+xe(ve(c)),1)]),f("span",sk,"("+xe(ve(x))+")",1),f("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Gt((...O)=>ve(N)&&ve(N)(...O),["stop"]))},"更换文件")])):(ee(),te("div",ek,[f("span",tk,[le(de,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=f("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(ee(),te("div",ok,[Bt(f("textarea",{"onUpdate:modelValue":D[8]||(D[8]=O=>Ze(d)?d.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...O)=>ve(_)&&ve(_)(...O))},null,544),[[Ao,ve(d)]])])),ve(r)?(ee(),te("div",rk," ⚠️ "+xe(ve(r)),1)):Le("",!0),ve(h)?(ee(),te("div",lk,[f("div",ak,[f("span",ck,[le(de,{name:"sparkles"}),D[23]||(D[23]=St(" 演示解析摘要",-1))]),D[24]||(D[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",dk,[f("div",uk,[D[25]||(D[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Bt(f("input",{"onUpdate:modelValue":D[10]||(D[10]=O=>Ze(u)?u.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ao,ve(u)]])]),f("div",fk,[D[26]||(D[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Bt(f("select",{"onUpdate:modelValue":D[11]||(D[11]=O=>Ze(m)?m.value=O:null),class:"spm-select"},[(ee(!0),te(Ge,null,kt(ve(b),O=>(ee(),te("option",{key:O.id,value:O.id},xe(O.name),9,pk))),128))],512),[[Cf,ve(m)]])])]),f("div",hk,[f("div",mk,[f("span",gk,xe(ve(h).totalSlides),1),D[27]||(D[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",vk,[f("span",bk,xe(ve($)),1),D[28]||(D[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",yk,[f("span",kk,xe(ve(h).stats.totalNotes),1),D[29]||(D[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",wk,[f("span",xk,xe(ve(p)),1),D[30]||(D[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ve(T).length>0?(ee(),te("div",Sk,[D[31]||(D[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ee(!0),te(Ge,null,kt(ve(T),O=>(ee(),te("span",{key:O.name,class:"spm-chip-badge"},xe(O.name)+": "+xe(O.count),1))),128))])):Le("",!0),f("div",Ck,[f("label",_k,[Bt(f("input",{"onUpdate:modelValue":D[12]||(D[12]=O=>Ze(v)?v.value=O:null),type:"checkbox",onChange:D[13]||(D[13]=(...O)=>ve(F)&&ve(F)(...O))},null,544),[[ns,ve(v)]]),D[32]||(D[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",$k,[Bt(f("input",{"onUpdate:modelValue":D[14]||(D[14]=O=>Ze(y)?y.value=O:null),type:"checkbox",onChange:D[15]||(D[15]=(...O)=>ve(F)&&ve(F)(...O))},null,544),[[ns,ve(y)]]),D[33]||(D[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",Ik,[Bt(f("input",{"onUpdate:modelValue":D[16]||(D[16]=O=>Ze(C)?C.value=O:null),type:"checkbox"},null,512),[[ns,ve(C)]]),D[34]||(D[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",Tk,[Bt(f("input",{"onUpdate:modelValue":D[17]||(D[17]=O=>Ze(S)?S.value=O:null),type:"checkbox"},null,512),[[ns,ve(S)]]),D[35]||(D[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Le("",!0)]),f("div",Ek,[f("button",{class:"spm-btn-secondary",disabled:ve(l),onClick:j}," 取消 ",8,Mk),f("button",{class:"spm-btn-primary",disabled:!ve(h)||ve(l),onClick:M},[ve(l)?(ee(),te("span",Bk,[le(de,{name:"refresh"}),D[36]||(D[36]=St(" 正在导入生成中...",-1))])):(ee(),te("span",Dk,[le(de,{name:"rocket"}),D[37]||(D[37]=St(" 确认导入思源笔记",-1))]))],8,Ak)])])]))}}),Pk=Jt(Lk,[["__scopeId","data-v-c56a3d7e"]]);function dr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Rk(e,i){var r;if(!e||e.length===0)return null;const t=i.activeBlockId||"",n=i.currentTopBlockId||t,s=i.currentPageDividerId||"",o=i.activeBlockType||"";if(dr(o)&&t){let a=e.find(c=>c.startBlockId===t);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===t}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(t)}),a))return a}if(s){let a=e.find(c=>c.startBlockId===s);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===s}),a))return a}if(t){let a=e.find(d=>d.startBlockId===t);if(a||(a=e.find(d=>{var p,h;return((p=d.blocks)==null?void 0:p.some(u=>u.id===t))||((h=d.allBlockIds)==null?void 0:h.includes(t))}),a)||n&&n!==t&&(a=e.find(d=>{var p,h;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((h=d.allBlockIds)==null?void 0:h.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(h=>h.id===t||h.id===n)}),a))return a;const c=(r=i.activeBlockAttrs)==null?void 0:r[$e];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,h;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((h=d.blocks)==null?void 0:h.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function tt(e,i){var s;if(typeof document>"u"||!e)return;const t=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${t}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(i))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function Ok(e){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${we}], .protyle-wysiwyg [${qe}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,t=document.querySelectorAll(i);!t||t.length===0||t.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(we),n.removeAttribute("custom-slides-layout"),n.removeAttribute(qe),n.removeAttribute("custom-slides-role");return}const o=e.get(s),l=(o==null?void 0:o[we])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(we)||n.getAttribute("custom-slides-layout");r&&r!==l&&(l?n.setAttribute(we,l):(n.removeAttribute(we),n.removeAttribute("custom-slides-layout")));const a=(o==null?void 0:o[qe])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(qe)||n.getAttribute("custom-slides-role");c&&c!==a&&(a?n.setAttribute(qe,a):(n.removeAttribute(qe),n.removeAttribute("custom-slides-role")))})}function Nk(e,i){if(!i)return!1;if(e===i||typeof document>"u")return!0;const t=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!t)return!1;const n=t.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function zk(e){let i=null;function t(c="已同步"){e.saveStatus.value=c,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const d=()=>{e.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(d,1200):i=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[b,m]of Object.entries(c))e.activeBlockAttrs.value[b]=m;Pe.setBlockAttrOverride(d,c),tt(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,h=!!(p&&Nk(d,p));if(Ye in c&&h&&p){const b=c[Ye];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Pe.setBlockAttrOverride(p,{[Ye]:b}),tt(p,{[Ye]:b}),je(p,{[Ye]:b}).catch(()=>{})}if(we in c){const b=c[we];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(yt in c){const b=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}t("保存中...");try{await je(d,c),t("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{t("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=o();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Pe.setBlockAttrOverride(p,{[c]:d}),tt(p,{[c]:d}),c===we&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),t("保存中...");try{await je(p,{[c]:d}),t("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{t("同步失败")}}}async function r(c,d){const p=o();if(!p)return;const h={[we]:c,[yt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[we]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(p,h),tt(p,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),t("应用排版中...");try{await je(p,h),t("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{t("应用失败")}}async function a(c,d){var h;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Pe.setBlockAttrOverride(p,{[c]:d}),tt(p,{[c]:d}),(h=e.latestDoc.value)!=null&&h.config&&(c===Ln&&(e.latestDoc.value.config.theme=d),c===Pn&&(e.latestDoc.value.config.aspectRatio=d),c===Rn&&(e.latestDoc.value.config.defaultTransition=d)),t("更新中...");try{await je(p,{[c]:d}),t("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{t("更新失败")}}}return{triggerSaveNotice:t,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function rl(e,i){const t=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of t){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function Qa(e,i){const t=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&t){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${t}`;try{const s=await i(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:rl(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:rl(e),isAiGenerated:!1}}async function Hk(e,i){return(await Qa(e,i)).notes}function Fk(e,i){const t=me(!1),{triggerSaveNotice:n}=i;async function s(p){var x,$,T,w,P,N,H,K;const b=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slides-note="true"}`,m=((x=e.latestDoc.value)==null?void 0:x.slides)||[],v=e.targetSlide.value,y=v?m.findIndex(_=>_===v):-1;let C=null;if(y!==-1&&y<m.length-1){const _=m[y+1];C=await Bi("markdown",b,_.startBlockId)}else{const _=(($=v==null?void 0:v.noteBlocks)==null?void 0:$.slice(-1)[0])||((T=v==null?void 0:v.blocks)==null?void 0:T.slice(-1)[0]),F=(_==null?void 0:_.id)||(v==null?void 0:v.startBlockId);F?C=await Bi("markdown",b,void 0,F):C=await go("markdown",b,e.currentDocId.value)}const S=((N=(P=(w=C==null?void 0:C[0])==null?void 0:w.doOperations)==null?void 0:P[0])==null?void 0:N.id)||((H=C==null?void 0:C[0])==null?void 0:H.id);return S&&(await je(S,{[it]:"true"}),Pe.setBlockAttrOverride(S,{[it]:"true"}),zi(S,(K=e.plugin)==null?void 0:K.app)),e.plugin&&await e.plugin.compileCurrentDocument(),S}async function o(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){n("取消中...");try{await je(p,{[it]:"","slides-note":""}),Pe.setBlockAttrOverride(p,{[it]:"","slides-note":""}),tt(p,{[it]:"","slides-note":""}),delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ue.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(h){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",h),n("取消失败"),ue.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let h=e.rawSnippet.value;try{const v=await Xc(p);v!=null&&v.kramdown&&(h=v.kramdown)}catch{}const m=`> [!NOTE] 💡 演讲备注
${(Ea(h)||h.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slides-note="true"}`;await gr("markdown",m,p),await je(p,{[it]:"true"}),Pe.setBlockAttrOverride(p,{[it]:"true"}),tt(p,{[it]:"true"}),e.activeBlockAttrs.value[it]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ue.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(h){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",h),n("设置失败"),ue.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await s(),ue.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){ue.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var u;const p=e.currentSlideNoteBlockId.value;if(!p){ue.showMessage("未找到本页关联的讲稿备注块");return}zi(p,(u=e.plugin)==null?void 0:u.app)?ue.showMessage("已在编辑区定位讲稿备注块"):ue.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ue.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const h=await Qa(p,fl);if(h.notes){const b=e.currentSlideNoteBlockId.value;if(b){const m=`> [!NOTE] 💡 演讲备注
${h.notes.split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slides-note="true"}`;await gr("markdown",m,b),await je(b,{[it]:"true"}),Pe.setBlockAttrOverride(b,{[it]:"true"}),zi(b,(u=e.plugin)==null?void 0:u.app)}else await s(h.notes);h.isAiGenerated?ue.showMessage("思源 AI 演讲提词卡生成成功！"):ue.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var b;if(t.value)return;const p=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(p.length===0){ue.showMessage("当前文档无幻灯片页面");return}const h=p.map((m,v)=>({slide:m,idx:v})).filter(({slide:m})=>{var C;const v=Array.isArray(m.noteBlocks)&&m.noteBlocks.length>0,y=!!((C=m.notes)!=null&&C.trim());return!v&&!y});if(h.length===0){ue.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=h.length;ue.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var v,y,C,S,x,$;if(t.value)return;t.value=!0,ue.showMessage("正在批量追加讲稿块...");let m=0;try{const P=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:H}of h)try{let K=null;if(H<p.length-1){const F=p[H+1];K=await Bi("markdown",P,F.startBlockId)}else{const F=((v=N==null?void 0:N.noteBlocks)==null?void 0:v.slice(-1)[0])||((y=N==null?void 0:N.blocks)==null?void 0:y.slice(-1)[0]),k=(F==null?void 0:F.id)||(N==null?void 0:N.startBlockId);k?K=await Bi("markdown",P,void 0,k):K=await go("markdown",P,e.currentDocId.value)}const _=((x=(S=(C=K==null?void 0:K[0])==null?void 0:C.doOperations)==null?void 0:S[0])==null?void 0:x.id)||(($=K==null?void 0:K[0])==null?void 0:$.id);_&&(await je(_,{[it]:"true"}),Pe.setBlockAttrOverride(_,{[it]:"true"})),m++}catch(K){console.error(`[SiYuanLiveSlides] 为第 ${H+1} 页追加讲稿块失败:`,K)}e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功为 ${m} 页追加讲稿备注块`)}catch(T){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",T),ue.showMessage("批量追加讲稿块时出现异常")}finally{t.value=!1}})}async function d(){var m;if(t.value)return;const p=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(p.length===0){ue.showMessage("当前文档无幻灯片页面");return}const h=[];for(const v of p)if(v.noteBlocks&&v.noteBlocks.length>0)for(const y of v.noteBlocks)y.id&&h.push({id:y.id,pageIndex:v.pageIndex});if(h.length===0){ue.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(h.map(v=>v.pageIndex)).size,b=h.length;ue.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${b} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(t.value)return;t.value=!0,ue.showMessage("正在批量删除讲稿块...");let v=0;try{for(const y of h)try{await ul(y.id),Pe.clearBlockAttrOverride(y.id),v++}catch(C){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${y.id} 失败:`,C)}e.activeBlockId.value&&h.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[it],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功删除全部 ${v} 个讲稿备注块`)}catch(y){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",y),ue.showMessage("批量删除讲稿块时出现异常")}finally{t.value=!1}})}return{isBatchProcessing:t,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function jk(e,i){const{saveAttr:t,saveAttrs:n,savePageAttr:s}=i;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ai]:"true",[Yi]:"true"}),e.activeBlockAttrs.value[Ai]="true",e.activeBlockAttrs.value[Yi]="true"):(await t(Ai,"false"),e.activeBlockAttrs.value[Ai]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await t(bs,w)}async function r(){const w=e.videoMuted.value?"false":"true";await t(Yi,w)}async function a(){const w=e.videoControls.value?"false":"true";await t(ys,w)}async function c(w){var _;const P=e.activeBlockId.value;if(!P)return;const N=e.rawSnippet.value||"",H=wi(N)||"",K=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const F={[qe]:"background",[we]:""};K&&H&&(e.pageBackground.value=H,await je(K,{[et]:H}).catch(()=>{}),Pe.setBlockAttrOverride(K,{[et]:H}),tt(K,{[et]:H}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=H)),await n(F)}else(w===ks||w===ws)&&await n({[we]:w,[qe]:""});else{const F={[qe]:"",[we]:""};if(e.activeBlockAttrs.value[et]==="true"&&(F[et]=""),K&&H&&e.pageBackground.value===H&&(e.pageBackground.value="",await je(K,{[et]:""}).catch(()=>{}),Pe.setBlockAttrOverride(K,{[et]:""}),tt(K,{[et]:""}),(_=e.targetSlide.value)!=null&&_.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(F),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`),M=k==null?void 0:k.closest('[data-type="NodeListItem"]'),j=M==null?void 0:M.getAttribute("data-node-id");if(j&&j!==P){const A={[we]:"",[qe]:""};tt(j,A),Pe.setBlockAttrOverride(j,A),await je(j,A).catch(()=>{})}}}}function d(){e.elemClick.value?t(Ye,""):t(Ye,"+1")}function p(w){t(Ye,w)}function h(w){t(qt,w)}function u(w){(e.activeBlockAttrs.value[$e]||"")===w?t($e,""):t($e,w)}function b(w){e.elemShikiLines.value=w,t(Fi,w)}function m(w){e.elemMaxHeight.value=w,t(On,w)}async function v(){const w=e.currentSlideLayout.value==="three-cols-header";await t($e,w?"col-1":"left"),ue.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const P={[Ye]:"",[qt]:"",[$e]:"",[Fi]:"",[On]:"",[it]:"","slides-note":"",[we]:"",[yt]:"",[qe]:"",[pt]:"",[et]:"",[Dt]:"",[Ai]:"",[bs]:"",[Yi]:"",[ys]:""};if(tt(w,P),await je(w,P),Pe.clearBlockAttrOverride(w),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),H=N==null?void 0:N.closest('[data-type="NodeListItem"]'),K=H==null?void 0:H.getAttribute("data-node-id");K&&K!==w&&(tt(K,P),await je(K,P).catch(()=>{}),Pe.clearBlockAttrOverride(K))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",ue.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function C(){if(e.activeBlockId.value)try{await Bi("markdown","---",e.activeBlockId.value,void 0),ue.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function S(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Bi("markdown","---",void 0,w),ue.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function x(){if(e.activeBlockId.value)try{await ul(e.activeBlockId.value),ue.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("删除失败")}}async function $(){var w,P;try{let N=null;if(typeof document<"u"){const K=e.activeBlockId.value;if(K){const _=document.querySelector(`.protyle-wysiwyg [data-node-id="${K}"]`);_&&(N=_.getAttribute("data-type")==="NodeSuperBlock"?_:_.closest('[data-type="NodeSuperBlock"]'))}if(!N){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(_){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(F){let k=F.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const M=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(M){N=M;break}k=k.nextElementSibling}}}else{const F=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of k)if(!F||M.compareDocumentPosition(F)&Node.DOCUMENT_POSITION_FOLLOWING){N=M;break}}}}const H=[];if(N){const K=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const _ of K){const F=_.getAttribute("data-node-id");F&&(H.push(F),_.removeAttribute("style"))}}else if((P=e.targetSlide.value)!=null&&P.blocks){for(const K of e.targetSlide.value.blocks)if(K.children&&K.children.length>=2){for(const _ of K.children)_.id&&H.push(_.id);break}}if(H.length>0)for(const K of H)await je(K,{style:""}).catch(()=>{});await s(yt,""),ue.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),ue.showMessage("重置超级块比例失败")}}async function T(){var w,P,N;try{let H=null;if(typeof document<"u"){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),F=e.activeBlockId.value;let k=[];if(_){const A=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(A){let D=A.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(D),D=D.nextElementSibling}}else{const A=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const O of D)if(!A||O.compareDocumentPosition(A)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(O);else break}const M=[];let j;for(const A of k){const D=A.getAttribute("data-type");D==="NodeHeading"&&(j=A.getAttribute("data-node-id")||void 0);const O=[];D==="NodeSuperBlock"?O.push(A):O.push(...Array.from(A.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const Q of O){if((Q.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const q=Q.getAttribute("data-node-id")||"";let re=[];const ae=Array.from(Q.querySelectorAll('[data-type="NodeListItem"]'));if(ae.length===4&&(re=ae.map(ce=>ce.getAttribute("data-node-id")).filter(Boolean)),re.length!==4){const ce=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));ce.length===4&&(re=ce.map(ge=>ge.getAttribute("data-node-id")).filter(Boolean))}re.length===4&&M.push({sbId:q,itemIds:re,headerId:j})}}M.length>0&&(F&&(H=M.find(A=>{if(A.sbId===F||A.itemIds.includes(F))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${A.sbId}"]`),O=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`);return!!(D&&O&&D.contains(O))})||null),H||(H=M[0]))}if(!H&&((P=e.targetSlide.value)!=null&&P.blocks)){const _=e.targetSlide.value,F=[];for(const M of _.blocks)M.rawNode?F.push(M.rawNode):F.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const k=Hf(F,e.activeBlockId.value);k&&k.items.length===4&&(H={sbId:k.superBlockNode.id,itemIds:k.items.map(M=>M.id),headerId:(N=k.headerNode)==null?void 0:N.id})}const K=e.currentPageDividerId.value||e.currentDocId.value;if(K&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(K,{[we]:"clover"}),tt(K,{[we]:"clover"}),await je(K,{[we]:"clover"}).catch(()=>{})),H&&H.itemIds.length>0){H.headerId&&(Pe.setBlockAttrOverride(H.headerId,{[$e]:"header"}),tt(H.headerId,{[$e]:"header"}),await je(H.headerId,{[$e]:"header"}).catch(()=>{}));const _=Math.min(4,H.itemIds.length);for(let F=0;F<_;F++){const k=H.itemIds[F],M=`col-${F+1}`;Pe.setBlockAttrOverride(k,{[$e]:M}),tt(k,{[$e]:M}),await je(k,{[$e]:M}).catch(()=>{})}}return ue.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(H){return console.error("[layout-actions] applyCloverLayout error:",H),ue.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:h,onElemSlotChange:u,onElemShikiLinesChange:b,onElemMaxHeightChange:m,onSetTwoColsContrast:v,onClearBlockAttrs:y,onInsertDividerBefore:C,onInsertDividerAfter:S,onDeleteCurrentBlock:x,resetSuperBlockWidth:$,applyCloverLayout:T}}function Wk(e){const{triggerSaveNotice:i,saveAttrs:t,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l}=zk(e),r=Fk(e,{triggerSaveNotice:i}),a=jk(e,{saveAttr:n,saveAttrs:t,savePageAttr:s});async function c(){var y;if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const u=e.latestDoc.value,b=await Hi(u,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Ha(u);Fa(`${b}.html`,m)&&ue.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function d(){if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ja(e.latestDoc.value)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const p=me(!1);async function h(){var u;if(p.value){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}p.value=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,m=await Hi(b,(u=e.currentDocId)==null?void 0:u.value,e.plugin),v=await Ka(b,{title:m,onProgress:(y,C)=>{ue.showMessage(`正在导出幻灯片图片 (${y} / ${C})...`,2e3)}});v.success?ue.showMessage(`🎉 成功导出 ${v.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ue.showMessage(`导出图片失败：${v.error||"未知异常"}`)}finally{p.value=!1}}return{triggerSaveNotice:i,saveAttrs:t,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,isExportingImages:p,onExportHtml:c,onExportPdf:d,onExportImages:h}}function Uk(e){const i=ye(()=>dr(e.activeBlockType.value));function t(n){const{attrKey:s,fallback:o,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(i.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const a=e.currentPageDividerId.value||(i.value?e.activeBlockId.value:"");if(a){const c=Pe.getBlockAttrOverride(a);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:i,resolvePageAttr:t}}const Vk={class:"spm-slides-inspector"},Gk={class:"spm-inspector-topbar"},Kk={class:"spm-inspector-title"},qk={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Yk={class:"spm-inspector-topbar-actions"},Zk={class:"spm-target-banner"},Jk={class:"spm-target-info"},Xk=["aria-label"],Qk={key:0,class:"spm-save-status"},ew=["title"],tw={class:"spm-inspector-body"},iw=Tt({__name:"SlidesInspectorDockView",setup(e,{expose:i}){const t=Pt("plugin"),n=me(!1);function s(X){n.value=!1,c.value=X.docId,t!=null&&t.compileCurrentDocument&&t.compileCurrentDocument(X.docId)}const o=me(""),l=me(""),r=me({}),a=me(""),c=me(""),d=me(""),p=me(""),h=me(""),u=me(""),b=me(""),m=me(""),v=me(null),y=me(""),C=me("");function S(){var be;const X=o.value||c.value;X&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(X).then(()=>{C.value="已复制！",setTimeout(()=>{C.value=""},1500)}).catch(()=>{})}const x=ye(()=>dr(l.value)),$=ye(()=>l.value==="NodeCodeBlock"),T=me(!1),w=ye(()=>{if(T.value||Ae.value)return!0;const X=a.value||"";return!!wi(X)}),P=ye(()=>{const X=l.value||"";if(X==="NodeVideo"||X==="video")return!0;const be=a.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),N=ye(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),H=ye(()=>{const X=o.value||c.value||"";return X.length>8?X.slice(-8):X||"无"}),K=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(x.value)return"分页符 (---)";if(N.value)return"全局文档";if(P.value)return"视频块";let X="内容块";switch(l.value){case"NodeHeading":X="标题块";break;case"NodeParagraph":X="段落块";break;case"NodeCodeBlock":X="代码块";break;case"NodeVideo":X="视频块";break;case"NodeList":case"NodeListItem":X="列表项";break;case"NodeBlockquote":X="引述块";break;case"NodeTable":X="表格块";break;case"NodeSuperBlock":case"s":case"sb":X="超级块";break;default:X="内容块";break}return u.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${X}`:`分栏容器 › ${X}`:X}),F=ye(()=>x.value?"tag-divider":N.value?"tag-doc":"tag-block"),k=ye(()=>r.value[we]||"default"),M=ye(()=>r.value[pt]||"slide-left"),j=me(""),A=me(""),D=ye(()=>r.value[Cn]||"inherit"),O=ye(()=>{var X;return Rk((X=v.value)==null?void 0:X.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),Q=ye(()=>{var X;return((X=O.value)==null?void 0:X.notes)||""}),W=ye(()=>{var X,be,Ee;return((Ee=(be=(X=O.value)==null?void 0:X.noteBlocks)==null?void 0:be[0])==null?void 0:Ee.id)||""}),q=ye(()=>{var Fe,We,Re,dt,Jn,fi;if(x.value){const Xe=r.value[we]||r.value["custom-slides-layout"];if(Xe)return Xe}const X=r.value[$e]||r.value["custom-slides-slot"];if(X&&(["col-1","col-2","col-3"].includes(X)||/^col-\d+$/.test(X)))return"cols-header";if(h.value)return h.value;const be=p.value||(x.value?o.value:"");if(be){const Xe=Pe.getBlockAttrOverride(be);if(Xe!=null&&Xe[we])return Xe[we]}if(be&&((Fe=v.value)!=null&&Fe.slides)){const Xe=v.value.slides.find(Vi=>Vi.startBlockId===be);if((We=Xe==null?void 0:Xe.frontmatter)!=null&&We.layout)return Xe.frontmatter.layout}if((dt=(Re=O.value)==null?void 0:Re.frontmatter)!=null&&dt.layout)return O.value.frontmatter.layout;if((fi=(Jn=O.value)==null?void 0:Jn.blocks)!=null&&fi.some(Xe=>Xe.slot&&(["col-1","col-2","col-3"].includes(Xe.slot)||/^col-\d+$/.test(Xe.slot))))return"cols-header";const Ee=Pe.getBlockAttrOverride(c.value);return Ee!=null&&Ee[we]?Ee[we]:"default"}),re=Uk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),ae=re.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var X,be;return((be=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:be.layoutRatio)||""}}),ce=re.resolvePageAttr({attrKey:Ji,fallback:()=>{var X,be;return((be=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:be.mask)||""}}),ge=re.resolvePageAttr({attrKey:Pi,fallback:()=>{var X,be;return((be=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:be.maskRatio)||""}}),Te=re.resolvePageAttr({attrKey:Xi,fallback:()=>{var X,be;return((be=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:be.maskStyle)||"solid"}}),Se=re.resolvePageAttr({attrKey:Qi,fallback:()=>{var X,be;return((be=(X=O.value)==null?void 0:X.frontmatter)==null?void 0:be.maskInitial)||"hidden"}});function fe(X){if(!X||(X.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(X.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const Fe=Ee.length,We=Ee.map(fi=>{const Xe=fi.getAttribute("style")||"",Vi=Xe.match(/calc\(\s*([\d.]+)%/);if(Vi)return parseFloat(Vi[1]);const gn=Xe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return gn?parseFloat(gn[1]):null});let Re="",dt=!1;if(We.some(fi=>fi!==null)){dt=!0;const fi=We.reduce((De,ut)=>De+(ut||0),0),Xe=We.filter(De=>De===null).length,Vi=Xe>0?Math.max(0,100-fi)/Xe:100/Ee.length,gn=We.map(De=>De!==null?De:Vi),jc=gn.reduce((De,ut)=>De+ut,0)||1,vn=gn.map(De=>De/jc*100);if(vn.length===2){const[De]=vn;if(De>=48&&De<=52)Re="1:1";else if(De>=31&&De<=35)Re="1:2";else if(De>=65&&De<=69)Re="2:1";else if(De>=28&&De<=32)Re="3:7";else if(De>=68&&De<=72)Re="7:3";else if(De>=38&&De<=42)Re="4:6";else if(De>=58&&De<=62)Re="6:4";else{const ut=Math.round(De);Re=`${ut}:${100-ut}`}}else if(vn.length===3){const[De,ut,pi]=vn;if(De>=31&&De<=35&&ut>=31&&ut<=35&&pi>=31&&pi<=35)Re="1:1:1";else if(De>=23&&De<=27&&ut>=48&&ut<=52&&pi>=23&&pi<=27)Re="1:2:1";else if(De>=48&&De<=52&&ut>=23&&ut<=27&&pi>=23&&pi<=27)Re="2:1:1";else if(De>=23&&De<=27&&ut>=23&&ut<=27&&pi>=48&&pi<=52)Re="1:1:2";else{const hr=Math.round(De),mr=Math.round(ut);Re=`${hr}:${mr}:${100-hr-mr}`}}else Re=vn.map(De=>Math.round(De)).join(":")}else dt=!1,Re=Array.from({length:Fe},()=>1).join(":");const Jn=Fe>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Fe,ratio:Re,isCustomWidth:dt,recommendedLayout:Jn}}function Z(X){if(!(X!=null&&X.blocks))return null;for(const be of X.blocks){const Ee=be.rawNode;if(Ee&&st(Ee)&&Zt(Ee)){const We=hn(Ee).length,Re=rr(Ee);return{hasSuperBlock:!0,colCount:We,ratio:Re||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const pe=ye(()=>{var X;if(typeof document<"u"){const be=o.value;if(be){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(Fe){const We=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.closest('[data-type="NodeSuperBlock"]');if(We){const Re=fe(We);if(Re)return Re}}}const Ee=p.value||(x.value?o.value:"");if(Ee){const Fe=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(Fe){let We=Fe.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(X=We.classList)!=null&&X.contains("protyle-wysiwyg__block--hr"));){const Re=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Re){const dt=fe(Re);if(dt)return dt}We=We.nextElementSibling}}}else{const Fe=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of We)if(!Fe||Re.compareDocumentPosition(Fe)&Node.DOCUMENT_POSITION_FOLLOWING){const dt=fe(Re);if(dt)return dt}}}return Z(O.value)}),L=ye(()=>{var X;return((X=pe.value)==null?void 0:X.ratio)||""}),V=ye(()=>{const X=l.value||"";if(X==="NodeSuperBlock"||X==="s"||X==="sb")return!0;if(typeof document<"u"&&o.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=ye(()=>{var X;return((X=O.value)==null?void 0:X.pageIndex)||1}),G=ye(()=>!!(r.value[it]||r.value["slides-note"]));function U(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const X=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!X)return!1;const be=X.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===o.value}const I=ye(()=>{var be;if(r.value[Ye]!==void 0)return r.value[Ye]||"";if(u.value&&U())return m.value||"";if(u.value)return"";const X=o.value;if(X&&((be=O.value)!=null&&be.blocks)){const Ee=O.value.blocks.find(Fe=>Fe.id===X);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),E=ye(()=>{var be;if(r.value[qt])return r.value[qt];const X=o.value;if(X&&((be=O.value)!=null&&be.blocks)){const Ee=O.value.blocks.find(Fe=>Fe.id===X);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),R=ye(()=>{var be;if(r.value[$e])return r.value[$e];const X=o.value;if(X&&((be=O.value)!=null&&be.blocks)){const Ee=O.value.blocks.find(Fe=>Fe.id===X);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),Y=me(""),B=me(""),z=ye(()=>r.value[Ai]==="true"),J=ye(()=>r.value[bs]==="true"),ne=ye(()=>r.value[Yi]==="true"),oe=ye(()=>r.value[ys]!=="false"),he=ye(()=>{var X,be;return((be=(X=v.value)==null?void 0:X.config)==null?void 0:be.theme)||r.value[Ln]||"default"}),ie=ye(()=>{var X,be;return((be=(X=v.value)==null?void 0:X.config)==null?void 0:be.aspectRatio)||r.value[Pn]||"16/9"}),se=ye(()=>{var X,be;return((be=(X=v.value)==null?void 0:X.config)==null?void 0:be.defaultTransition)||r.value[Rn]||"slide-left"}),_e=ye(()=>{var X,be;return((be=(X=v.value)==null?void 0:X.config)==null?void 0:be.spacing)||r.value[bo]||"normal"}),Ae=ye(()=>{var We,Re;if((r.value[qe]||r.value["slides-role"])===gl||r.value[et]==="true")return"background";const be=r.value[we]||r.value["slides-layout"];if(be==="image-left"||be==="image-right")return be;const Ee=a.value||"",Fe=wi(Ee);if(Fe&&((Re=(We=O.value)==null?void 0:We.frontmatter)!=null&&Re.background)){const dt=O.value.frontmatter.background;if(dt===Fe||dt.endsWith(Fe)||Fe.endsWith(dt))return"background"}return""}),Ne=ye(()=>!!(r.value[Ye]||r.value[qt]||r.value[$e]||r.value[Fi]||r.value[it]||r.value["slides-note"]||r.value[qe]||r.value[we]||r.value[Ai]||r.value[bs]||r.value[Yi]||r.value[ys])),{saveAttr:Oe,savePageAttr:Be,applyPageLayoutAndRatio:Xt,applyCloverLayout:ot,resetSuperBlockWidth:Je,saveDocAttr:zt,onToggleVideoAutoplay:Wi,onToggleVideoLoop:Ks,onToggleVideoMuted:qs,onToggleVideoControls:Zn,onImageRoleChange:Si,onToggleNoteBlock:Ui,onAddNoteBlock:sc,onLocateNoteBlock:oc,onGenerateNotesWithAI:rc,isBatchProcessing:lc,onBatchAppendNotes:ac,onBatchDeleteNotes:cc,toggleElemClick:dc,onElemClickStepChange:uc,onElemMotionChange:fc,onElemSlotChange:pc,onElemShikiLinesChange:hc,onElemMaxHeightChange:mc,onSetTwoColsContrast:gc,onClearBlockAttrs:vc,onInsertDividerBefore:bc,onInsertDividerAfter:ur,onDeleteCurrentBlock:yc,onExportHtml:kc,onExportPdf:wc,onExportImages:xc,isExportingImages:Sc}=Wk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:h,parentContainerId:u,parentContainerClicks:m,latestDoc:v,targetSlide:O,currentSlideNoteBlockId:W,currentSlideLayout:q,isNoteBlock:G,elemClick:I,videoAutoplay:z,videoLoop:J,videoMuted:ne,videoControls:oe,pageBackground:j,pageImage:A,elemShikiLines:Y,elemMaxHeight:B,saveStatus:y,plugin:t});async function Cc(X){if(X==="clover"){if(!await ot())return}else Oe(we,X)}function _c(X){Be(yt,X)}async function $c(X){await Be(Ji,X),(X==="clockwise"||X==="counter-clockwise"||X==="cw"||X==="ccw")&&(!ge.value||ge.value==="1:1")&&await Be(Pi,"1:1:1:1")}function Ic(X){Be(Pi,X)}function Tc(X){Be(Xi,X)}function Ec(X){Be(Qi,X)}function fr(X){if(!X)return;const be=X.recommendedLayout||(X.colCount&&X.colCount>=2?"cols-header":"two-cols"),Ee=X.ratio||(X.colCount?Array(X.colCount).fill(1).join(":"):"1:1");Xt(be,Ee)}function Mc(X){Be(yt,X)}async function Ac(){await Je()}function Bc(X){Oe(pt,X)}function Dc(X){j.value=X,Oe(et,X)}function Lc(X){A.value=X,Oe(Dt,X)}function Pc(X){Oe(Cn,X==="inherit"?"":X)}function Rc(X){zt(Ln,X)}function Oc(X){zt(Pn,X)}function Nc(X){zt(Rn,X)}function zc(X){zt(bo,X)}function pr(){t!=null&&t.openBottomPreviewTab&&t.openBottomPreviewTab()}function Hc(){t!=null&&t.openPresenterTab&&t.openPresenterTab()}function Fc(){t!=null&&t.executeCommand&&t.executeCommand("slidesAiSplit")}return i({setActiveBlock(X){o.value=X.id,l.value=X.type,r.value={...X.attrs},a.value=X.content||X.markdown||"",d.value=X.topBlockId||X.id,p.value=X.pageDividerId||"",h.value=X.pageDividerLayout||"",u.value=X.parentContainerId||"",b.value=X.parentContainerSlot||"",m.value=X.parentContainerClicks||"",X.rootId?c.value=X.rootId:(X.type==="doc"||X.type==="NodeDocument")&&X.id&&(c.value=X.id),j.value=X.attrs[et]||"",A.value=X.attrs[Dt]||"",Y.value=X.attrs[Fi]||"",B.value=X.attrs[On]||"",T.value=!!X.isImage},updateDocument(X){v.value=X,c.value=X.docId},openImportDialog(){n.value=!0},setCurrentDocId(X){c.value=X}}),(X,be)=>(ee(),te("div",Vk,[f("div",Gk,[f("div",Kk,[(ee(),te("svg",qk,[...be[2]||(be[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=f("span",null,"演示配置",-1))]),f("div",Yk,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Ee=>n.value=!0)},[le(de,{name:"import"}),be[4]||(be[4]=f("span",null,"导入",-1))]),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:pr},[le(de,{name:"split-preview"}),be[5]||(be[5]=f("span",null,"分屏预览",-1))])])]),f("div",Zk,[f("div",Jk,[f("span",{class:Ce(["spm-target-tag",F.value])},xe(_.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":C.value||"点击复制 ID: "+(o.value||c.value),onClick:S},[le(de,{name:"copy"}),f("span",null,"#"+xe(H.value),1)],8,Xk)]),y.value?(ee(),te("span",Qk,"● "+xe(y.value),1)):Le("",!0)]),K.value?(ee(),te("div",{key:0,class:"spm-context-quote",title:a.value},xe(K.value),9,ew)):Le("",!0),f("div",tw,[x.value?(ee(),Kt(u1,{key:0,"page-layout":k.value,"page-layout-ratio":ve(ae),"page-mask":ve(ce),"page-mask-ratio":ve(ge),"page-mask-style":ve(Te),"page-mask-initial":ve(Se),"detected-sb-ratio":L.value,"detected-sb-info":pe.value,"page-transition":M.value,"page-background":j.value,"page-spacing":D.value,"page-image":A.value,"page-notes":Q.value,"page-index":g.value,"onUpdate:pageLayout":Cc,"onUpdate:pageLayoutRatio":_c,"onUpdate:pageMask":$c,"onUpdate:pageMaskRatio":Ic,"onUpdate:pageMaskStyle":Tc,"onUpdate:pageMaskInitial":Ec,onApplySuperBlockLayout:fr,onResetSuperblockRatio:Ac,"onUpdate:pageTransition":Bc,"onUpdate:pageBackground":Dc,"onUpdate:pageSpacing":Pc,"onUpdate:pageImage":Lc,onAddNoteBlock:ve(sc),onLocateNoteBlock:ve(oc),onGenerateNotes:ve(rc),onBatchAppendNotes:ve(ac),onBatchDeleteNotes:ve(cc),"is-batch-processing":ve(lc),onInsertDividerAfter:ve(ur),onDeleteDivider:ve(yc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!N.value?(ee(),Kt(Yy,{key:1,"elem-click":I.value,"elem-motion":E.value,"elem-slot":R.value,"elem-shiki-lines":Y.value,"elem-max-height":B.value,"is-code-block":$.value,"is-image":w.value,"is-video":P.value,"is-super-block":V.value,"detected-sb-info":pe.value,"video-autoplay":z.value,"video-loop":J.value,"video-muted":ne.value,"video-controls":oe.value,"has-block-attrs":Ne.value,"is-note":G.value,"image-role":Ae.value,"current-slide-layout":q.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":u.value,onToggleNote:ve(Ui),onToggleElemClick:ve(dc),onToggleVideoAutoplay:ve(Wi),onToggleVideoLoop:ve(Ks),onToggleVideoMuted:ve(qs),onToggleVideoControls:ve(Zn),"onUpdate:imageRole":ve(Si),"onUpdate:elemClick":ve(uc),"onUpdate:elemMotion":ve(fc),"onUpdate:elemSlot":ve(pc),"onUpdate:elemShikiLines":ve(hc),"onUpdate:elemMaxHeight":ve(mc),onApplySuperBlockLayout:fr,onApplySuperBlockRatio:Mc,onInsertDividerBefore:ve(bc),onInsertDividerAfter:ve(ur),onSetTwoColsContrast:ve(gc),onClearBlockAttrs:ve(vc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ee(),Kt(L0,{key:2,"doc-theme":he.value,"doc-aspect-ratio":ie.value,"doc-default-transition":se.value,"doc-spacing":_e.value,"is-exporting-images":ve(Sc),"onUpdate:docTheme":Rc,"onUpdate:docAspectRatio":Oc,"onUpdate:docDefaultTransition":Nc,"onUpdate:docSpacing":zc,onOpenBottomPreview:pr,onOpenPresenter:Hc,onAiAutoSplit:Fc,onExportHtml:ve(kc),onExportPdf:ve(wc),onExportImages:ve(xc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","onExportHtml","onExportPdf","onExportImages"]))]),n.value?(ee(),Kt(Pk,{key:1,onClose:be[1]||(be[1]=Ee=>n.value=!1),onSuccess:s})):Le("",!0)]))}}),nw=2e3,sw=600;function ow(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function po(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(ll(e))return!0;const i=e.firstElementChild;return!!(i&&ll(i))}function ll(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function rw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class lw{constructor(){ke(this,"consumers",new Map);ke(this,"seq",0);ke(this,"verifyTimer",null)}register(i,t,n){if(!t)return()=>{};const s=++this.seq,o=rw(),l={kind:i,element:t,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(t)):l.visible=po(t),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var i;for(const t of this.consumers.values())(i=t.observer)==null||i.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const i of this.consumers.values())if(i.measureOnDemand?po(i.element):this.isRecordVisible(i))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(i){return i.visible?!0:!ow(i.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let i=!1;for(const t of this.consumers.values())if(!t.measureOnDemand){i=!0;break}i&&(this.verifyTimer=setTimeout(()=>{var t;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&po(n.element)){n.visible=!0,(t=n.onVisible)==null||t.call(n);return}},nw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const hs=new lw,mn=new Yn;function ec(e,i,t){const n=()=>{var o;try{(o=t==null?void 0:t.flushDirtyCompile)==null||o.call(t)}catch{}},s=hs.register(e,i,n);return n(),s}let bi=null,Mt=null,ms=null;function aw(){return Mt}function cw(e,i){bi&&tc(),bi=sr(Cg),bi.provide("plugin",i),bi.provide("sandboxBridge",mn);const t=bi.mount(e);return Mt=t,ms=ec("preview",e,i),t}function tc(e){ms&&(ms(),ms=null),bi&&(bi.unmount(),bi=null,Mt=null)}function dw(){return Mt!==null}let yi=null,Li=null;function uw(e,i){return yi&&ic(),yi=sr(Lv),yi.provide("plugin",i),yi.provide("sandboxBridge",mn),Li=yi.mount(e),Li}function ic(e){yi&&(yi.unmount(),yi=null,Li=null)}function fw(e){try{const i=new BroadcastChannel("siyuan-slides-sync");i.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),i.close()}catch{}}let ki=null,Ct=null,gs=null;function pw(e,i){ki&&nc(),ki=sr(iw),ki.provide("plugin",i),ki.provide("sandboxBridge",mn);const t=ki.mount(e);return Ct=t,gs=ec("dock",e,i),t}function nc(e){gs&&(gs(),gs=null),ki&&(ki.unmount(),ki=null,Ct=null)}function hw(e,i){Ct!=null&&Ct.updateDocument&&Ct.updateDocument(e),Mt!=null&&Mt.updateDocument?Mt.updateDocument(e,i):(mn.updateSlides(e.slides,e.config,e.fullMarkdown),fw(e)),Li!=null&&Li.updateDocument&&Li.updateDocument(e)}function No(e){Mt!=null&&Mt.navigateToBlock?Mt.navigateToBlock(e):mn.highlightElement(e)}function qi(e){Ct!=null&&Ct.setActiveBlock&&Ct.setActiveBlock(e)}function mw(){return Ct!=null&&Ct.openImportDialog?(Ct.openImportDialog(),!0):!1}function gw(e,i){const t=[];let s=0;for(let o=0;o<e.length;o++){const l=e[o];if(As(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){t.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){t.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];As(c)||(t.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return t}const vw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Mi,value:"true"},{key:we,value:"cover"},{key:pt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Mi,value:"true"},{key:we,value:"two-cols"},{key:pt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Mi,value:"true"},{key:we,value:"fact"},{key:pt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Mi,value:"true"},{key:we,value:"intro"},{key:pt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Mi,value:"true"},{key:we,value:"quote"},{key:pt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ye,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ye,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:$e,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Fi,value:"1-3"}]}];class ho{getPresetTemplates(){return vw}buildScanSlidesBlocksSql(i="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${pt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,t,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${pt}' AND value = '${i}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[pt]:t}),r++)}return{updatedCount:r}}async batchUpdateLayout(i,t,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slides-layout' AND value = '${i}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slides-layout":t}),r++)}return{updatedCount:r}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function bw(e){e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{mw()||ue.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await je(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ue.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidesAiSplit",langText:"即现 AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const l=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(l==null?void 0:l.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}const t=await vs(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ue.showMessage("当前文档无内容，无需断页");return}const n=t.map(l=>({id:l.id,type:l.type,subType:l.subType,content:l.content||"",markdown:l.markdown||""})),s=gw(n);if(s.length===0){ue.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ue.showMessage(`AI 分析完毕：发现 ${s.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const l of s)try{await Bi("markdown","---",void 0,l.blockId),await je(l.blockId,{"custom-slides-layout":l.recommendedLayout}),o++}catch(r){console.warn("Failed to insert divider:",r)}ue.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var c,d,p,h;if(!e.currentDocId){const u=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(u==null?void 0:u.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}ue.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await vs(e.currentDocId).catch(()=>[]),n={startBlockId:e.currentDocId,blocks:t.map(u=>({id:u.id,type:u.type,content:u.content||"",rawMarkdown:u.markdown||""})),rawMarkdown:""},l=`> [!NOTE] 💡 演讲备注
${(await Hk(n,fl)).split(/\r?\n/).map(u=>`> ${u}`).join(`
`)}
{: custom-slides-note="true"}`,r=await go("markdown",l,e.currentDocId).catch(()=>null),a=((p=(d=(c=r==null?void 0:r[0])==null?void 0:c.doOperations)==null?void 0:d[0])==null?void 0:p.id)||((h=r==null?void 0:r[0])==null?void 0:h.id);a&&(await je(a,{"custom-slides-note":"true"}),Pe.setBlockAttrOverride(a,{"custom-slides-note":"true"}),zi(a,e.app)),ue.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new ho,n=t.buildTransitionStatsSql(),s=await rn(n).catch(()=>[]),o=t.formatTransitionSummary(s||[]);ue.showMessage(o)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const n=new ho().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(n),ue.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ue.showMessage(`已生成模板数据（请在控制台查看）：
`+n)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const n=await new ho().batchUpdateTransitions("fade","slide-left",s=>rn(s).catch(()=>[]),(s,o)=>je(s,o));ue.showMessage(`全库批量替换完成：已将 ${n.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ue.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ue.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ue.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ue.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",vo);t.success?ue.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ue.showMessage(`同步失败：${t.error}`)}});let i=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(i){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}i=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const t=e.latestCompiledDoc,n=await Hi(t,e.currentDocId,e),s=await Ka(t,{title:n,onProgress:(o,l)=>{ue.showMessage(`正在导出幻灯片图片 (${o} / ${l})...`,2e3)}});s.success?ue.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ue.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{i=!1}}})}class yw{constructor(i=400){ke(this,"entries",new Map);this.ttlMs=i}get(i,t=Date.now()){if(!i)return;const n=this.entries.get(i);if(n){if(t-n.at>this.ttlMs){this.entries.delete(i);return}return n.attrs}}set(i,t,n=Date.now()){!i||!t||this.entries.set(i,{attrs:t,at:n})}invalidate(i){i?this.entries.delete(i):this.entries.clear()}get size(){return this.entries.size}}function kw(e){const i=new Map;if(!(e!=null&&e.slides))return i;const t=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&i.set(s.id,s.ial)};for(const n of e.slides)t(n.blocks),t(n.noteBlocks);return i}class ww{constructor(i=150){ke(this,"lastBlockId","");ke(this,"lastAt",0);this.windowMs=i}shouldSkip(i,t=Date.now()){return i&&i===this.lastBlockId&&t-this.lastAt<this.windowMs?!0:(this.lastBlockId=i,this.lastAt=t,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class xw{constructor(){ke(this,"attrCache",new yw);ke(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(i,t){if(!i)return{};const n=Pe.getBlockAttrOverride(i),s=this.getCompiledIal(t,i);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(i);if(o)return o;const l=await zo(i).catch(()=>({}))||{};return this.attrCache.set(i,l),l}getCompiledIal(i,t){if(i)return this.compiledIalIndex.doc!==i&&(this.compiledIalIndex={doc:i,map:kw(i)}),this.compiledIalIndex.map.get(t)}invalidateAttrCache(i){this.attrCache.invalidate(i)}getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),t=i==null?void 0:i.getAttribute("data-node-id");if(t)return t;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,t=""){const n=i.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=i.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||t}async switchToDocGlobalInspector(i,t){var o;if(!i)return;let n=t||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(i,null);qi({id:i,rootId:i,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),No(i)}handleBlockClickedFromSlide(i,t,n,s,o){var c,d,p,h;if(!i){Dn();const u=typeof o=="number"&&o>0?o:1,b=((c=s==null?void 0:s.slides)==null?void 0:c[u-1])||((d=s==null?void 0:s.slides)==null?void 0:d[0]);if(b){const m=b.startBlockId||"",v=((p=b.frontmatter)==null?void 0:p.layout)||"",y={"custom-slides-layout":v,...b.frontmatter};return qi({id:m,rootId:n,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:v}),this.resolveBlockAttrs(m,s).then(C=>{C&&Object.keys(C).length>0&&qi({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...y,...C},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:v})}),!0}else return this.switchToDocGlobalInspector(n),!0}const l=zi(i,t),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,i,a,n,s);else{let u="",b="";if(s!=null&&s.slides){const m=s.slides.find(v=>{var y,C,S;return v.startBlockId===i||((y=v.blocks)==null?void 0:y.some(x=>x.id===i))||((C=v.allBlockIds)==null?void 0:C.includes(i))||((S=v.noteBlocks)==null?void 0:S.some(x=>x.id===i))});m!=null&&m.startBlockId&&(u=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(b=m.frontmatter.layout)}this.resolveBlockAttrs(i,s).then(async m=>{if(u&&!b){const v=Pe.getBlockAttrOverride(u);if(v!=null&&v[we]||v!=null&&v["custom-slides-layout"])b=v[we]||v["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(u,s);b=y[we]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Pe.setBlockAttrOverride(u,y)}}qi({id:i,rootId:n,type:a||"NodeParagraph",attrs:m||{},pageDividerId:u,pageDividerLayout:b})}).catch(()=>{})}return l}async syncInspectorBlock(i,t,n,s,o){var M,j,A,D,O,Q,W,q;let l=i,r=t,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const re=c.getAttribute("data-node-id");if(re){const ae=await this.resolveBlockAttrs(re,o),ce=Pe.getBlockAttrOverride(re)||{},ge={...ae,...ce};(ge[it]||ge["slides-note"])&&(l=c,r=re,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,h=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((M=d==null?void 0:d.classList)!=null&&M.contains("hr")),u=a==="NodeCodeBlock",b=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,o),v=Pe.getBlockAttrOverride(r)||{},y={...m,...v};let C="",S="";if(h)C=r,S=y[we]||y["custom-slides-layout"]||"";else{let re=d.previousElementSibling;for(;re;){const ae=re.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(A=re.classList)!=null&&A.contains("hr")){C=re.getAttribute("data-node-id")||"";break}re=re.previousElementSibling}}if(o!=null&&o.slides){const re=[r,p];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const ge=ae.getAttribute("data-node-id");ge&&!re.includes(ge)&&re.push(ge),ae=ae.parentElement}const ce=o.slides.find(ge=>{var Te,Se,fe;return re.includes(ge.startBlockId)||((Te=ge.blocks)==null?void 0:Te.some(Z=>re.includes(Z.id)))||((Se=ge.allBlockIds)==null?void 0:Se.some(Z=>re.includes(Z)))||((fe=ge.noteBlocks)==null?void 0:fe.some(Z=>re.includes(Z.id)))});ce&&(!C&&ce.startBlockId&&(C=ce.startBlockId),!S&&((D=ce.frontmatter)!=null&&D.layout)&&(S=ce.frontmatter.layout))}if(C){const re=Pe.getBlockAttrOverride(C);if(re&&(we in re||"custom-slides-layout"in re)&&(S=re[we]||re["custom-slides-layout"]||""),!S&&(o!=null&&o.slides)){const ae=o.slides.find(ce=>ce.startBlockId===C);(O=ae==null?void 0:ae.frontmatter)!=null&&O.layout&&(S=ae.frontmatter.layout)}if(!S){const ae=await this.resolveBlockAttrs(C,o);S=ae[we]||ae["custom-slides-layout"]||"",ae&&Object.keys(ae).length>0&&Pe.setBlockAttrOverride(C,ae)}tt(C,{[we]:S||""})}else if(s){const re=Pe.getBlockAttrOverride(s);re&&(we in re||"custom-slides-layout"in re)?S=re[we]||re["custom-slides-layout"]||"":!S&&((q=(W=(Q=o==null?void 0:o.slides)==null?void 0:Q[0])==null?void 0:W.frontmatter)!=null&&q.layout)&&(S=o.slides[0].frontmatter.layout)}const x=l.getAttribute(we)||l.getAttribute("custom-slides-layout"),$=y[we]||y["custom-slides-layout"]||"";x&&x!==$&&tt(r,{[we]:$});const T=l.getAttribute(qe)||l.getAttribute("custom-slides-role"),w=y[qe]||y["custom-slides-role"]||"";T&&T!==w&&tt(r,{[qe]:w});let P="",N="",H="";const K=l.closest('[data-type="NodeListItem"]');if(K&&K!==l){const re=K.getAttribute("data-node-id");if(re){P=re;const ae=await this.resolveBlockAttrs(re,o),ce=Pe.getBlockAttrOverride(re)||{},ge={...ae,...ce};N=ge[$e]||"",H=ge[Ye]||"";const Te=ge[we]||ge["custom-slides-layout"]||"",Se=K.getAttribute(we)||K.getAttribute("custom-slides-layout");Se&&Se!==Te&&tt(re,{[we]:Te});const fe=ge[qe]||ge["custom-slides-role"]||"",Z=K.getAttribute(qe)||K.getAttribute("custom-slides-role");Z&&Z!==fe&&tt(re,{[qe]:fe})}}const _=!!l.querySelector("img, span[data-type='img']"),F=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=_&&F.length<=50;qi({id:r,rootId:s,type:a,content:b,attrs:y,isDivider:h,isCode:u,isImage:k,topBlockId:p,pageDividerId:C,pageDividerLayout:S,parentContainerId:P,parentContainerSlot:N,parentContainerClicks:H})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const t of i.data)if(Array.isArray(t==null?void 0:t.doOperations)){for(const n of t.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");tt(n.id,l),Pe.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidesAttrs(i){var s,o,l;if(typeof document>"u"||!i)return;const t=new Map;if(Array.isArray(i.slides))for(const r of i.slides){if(r.startBlockId){const a=t.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[we]=r.frontmatter.layout),t.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=t.get(a.id)||{};(o=a.ial)!=null&&o[we]&&(c[we]=a.ial[we]),(l=a.ial)!=null&&l[qe]&&(c[qe]=a.ial[qe]),Object.keys(c).length>0&&t.set(a.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=t.get(r)||{};a[we]!==void 0&&(c[we]=a[we]),a[qe]!==void 0&&(c[qe]=a[qe]),t.set(r,c)}Ok(t)}}const Ti=new xw;class Sw{constructor(){ke(this,"inFlightDocId",null);ke(this,"pendingDocId",null);ke(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(i){return this.inFlightDocId!==null?(this.pendingDocId=i,null):(this.inFlightDocId=i,++this.generation)}isStale(i){return i!==this.generation}finish(){this.inFlightDocId=null;const i=this.pendingDocId;return this.pendingDocId=null,i}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const Cw=150,_w=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,$w="slides-dock",mo="slides-preview-tab",al="slides-presenter-tab",cl=Df;class Iw extends ue.Plugin{constructor(){super(...arguments);ke(this,"isMobile",!1);ke(this,"currentDocId","");ke(this,"previewTab",null);ke(this,"latestCompiledDoc",null);ke(this,"cliBridge",new lr);ke(this,"debounceTimer",null);ke(this,"activeCursorBlockId","");ke(this,"compileScheduler",new Sw);ke(this,"dirtyDocId",null);ke(this,"inspectorSyncThrottle",new ww);ke(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ke(this,"onWsMainBound",this.onWsMain.bind(this));ke(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ke(this,"onEditorClickBound",this.onEditorClick.bind(this));ke(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ke(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ke(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const t=ue.getFrontend();this.isMobile=t==="mobile"||t==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(_w),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),bw(this);const n=this;if(this.addTab({type:mo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,cw(o.element,n);const l=(r=o==null?void 0:o.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),tc(this.element)}}),this.addTab({type:al,init(s){uw((this||s).element,n)},destroy(){ic(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:$w,init(){pw(this.element,n)},destroy(){nc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(t){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const t=await this.loadData(cl),n=Lf(t);return Di(n),n}catch{return Di(dn),dn}}async saveGlobalSettings(t){const n=Gs(),s=Di({...n,...t||{}});try{await this.saveData(cl,s)}catch(l){console.error("保存即现全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,hs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),mn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const t=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(t);await ue.openTab({app:this.app,custom:{id:this.name+mo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(t,this.currentDocId)}async openPresenterTab(){dw()||await this.openBottomPreviewTab(),await ue.openTab({app:this.app,custom:{id:this.name+al,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"})}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const t=ue.getFrontend();if(t==="browser-desktop"||t==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),l=await ue.openTab({app:this.app,custom:{id:this.name+mo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ue.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(t){var l,r,a,c,d;const n=(l=t.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const p=await zo(s).catch(()=>({}));qi({id:s,rootId:s,type:"doc",attrs:p}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(t){var o,l;const n=t==null?void 0:t.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(t){return Ua(t)}async fetchDocumentTitle(t){return Va(this,t)}async updatePreviewTabHeader(t,n){return sg(this,t,n)}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(t){return Ti.resolveDocIdFromElement(t,this.currentDocId)}async switchToDocGlobalInspector(t,n){t&&(this.activeCursorBlockId=t,this.currentDocId=t,await Ti.switchToDocGlobalInspector(t,n))}onWsMain(t){const n=t.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(t){const n=t||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(t=Cw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=hs.getVisibility();if(n==="none")return;const s=n==="visible"?t:Math.max(t,sw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(t,n){return this.activeCursorBlockId=t,Ti.handleBlockClickedFromSlide(t,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(t){const n=(t==null?void 0:t.detail)||t;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(t){const n=t.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),h=p==null?void 0:p.querySelector(".protyle-title__input"),u=((h==null?void 0:h.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,No(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const t=window.getSelection();if(!t||t.rangeCount===0)return;const n=t.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),h=p==null?void 0:p.querySelector(".protyle-title__input"),u=((h==null?void 0:h.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,No(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(t,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(t,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(t,n){const s=(n==null?void 0:n.reason)??"explicit";let o=t||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&hs.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,hw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidesAttrs(t){Ti.purgeStaleDomSlidesAttrs(t)}}module.exports=Iw;
